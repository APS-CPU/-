assets/audio/  —— 外部音效（可选）

规则：文件名对上 data/audio.js 里 AUDIO_FILE 的表就行。
      放进来就播文件，没放就继续用游戏里的 WebAudio 合成音，不会变哑。

gun/    pistol.mp3  shotgun.mp3  rifle.mp3  dry.mp3  reload.mp3  switch.mp3
hit/    flesh.mp3   crit.mp3     wall.mp3   kill.mp3
chain/  pull.mp3    clank.mp3    lock.mp3   stamp.mp3  drag.mp3  whoosh.mp3
boss/   waveclear.mp3  slam.mp3
ui/     click.mp3   pick.mp3     levelup.mp3

建议：mp3 128kbps 单声道即可；时长控制在 0.3~2 秒；
      统一 -3dB 左右峰值，剩下的交给游戏里的音量设置。

[gun/uzi.mp3]  玩家的 Uzi 冲铋枪开枪声
  来源：用户提供的 UZI.mp3 切出单发（第 2 发，原文件 8.59s 里的 1.119s 处）
  处理：取 0.36s、去低频轰鸣、归一到 -0.7dB、尾部 80ms 淡出
  用法：开枪时自动播；文件不在就自动回落合成音，不会变哑

[gun/pistol.mp3]        手枪开枪（用户提供，已柔化）
[gun/uzi_reload.mp3]    Uzi 换弹（用户提供，已加速到 2.2s 对齐 reloadDur）
[gun/pistol_reload.mp3] 手枪换弹（用户提供，已加速到 1.46s）
  柔化链路：highpass 110Hz → lowpass 6.5–6.8kHz → 3kHz 降 3.5dB → 5.5kHz 降 2dB
  音量：面板「武器音量」（CFG.gunVol，默认 70%）乘在 sndPlay 里

[gun/shotgun_load.mp3]   霰弹一颗一颗装填的那一声（喷子枪胆塞入子弹）
[gun/shotgun_pump.mp3]   拉枪膛（装完 / 打断时播）
  两段都来自用户录音，已按游戏节奏变速（pump ×1.3）

[gun/shotgun.mp3]        霰弹开枪（实录），2.32s 源，只切头发 0.92s

[gun/enemy_*_{l,c,r}.mp3] 敌人开枪（9 个）：比玩家闷一点、沉一点，已把左/中/右声像写进文件

[gun/shotgun_pump.mp3] 拉枪膀（装填前摇），0.91s，已对齐 SHELL_PUMP_T=0.85

[素材说明] 本目录音效与音乐部分来自外部素材，版权归原作者所有，仅用于非商业交流。
          如你是权利人且不希望被使用，请邮件 3386616669@qq.com，会立即替换或删除。
          代码适用根目录 LICENSE 里的使用许可，音频素材不包含在该许可范围内。
