/* ------------------------------------------------------------------
   皮卡货斗：民用皮卡的车斗能装货（8×5 = 40 格，比大背包还大）。
   - 在车边打开背包，右栏显示货斗，可拖放或用设置里的快捷键搬货。
   - 车被打烂 → 货斗里的东西**全烧掉**（这就是运货的风险）。
   ------------------------------------------------------------------ */
var CARGO_W = 8, CARGO_H = 5;
const CARGO_ACCESS_RANGE = 130;
var cargoOpenTruck = null;      /* 当前开着货斗的那辆车 */
var cargoSel = 0;               /* 列表选中项（键盘用） */
var cargoScroll = 0;

function truckIsCargo(t){ return !!t && t.type === 'truck_civil' && t.veh === 'pickup'; }
function cargoCanUse(t){ return truckIsCargo(t) && !t.wreck && !t.dead && t.tstate !== 'gone' && trucks.includes(t); }
function truckCargoOf(t){ if (!t) return []; if (!Array.isArray(t.cargo)) t.cargo = []; return t.cargo; }

function cargoOccupancy(t){
  const occ = Array.from({length:CARGO_H}, () => new Array(CARGO_W).fill(null));
  for (const c of truckCargoOf(t)){
    for (let y = c.y; y < c.y + c.h; y++) for (let x = c.x; x < c.x + c.w; x++){
      if (occ[y] && x >= 0 && x < CARGO_W) occ[y][x] = c;
    }
  }
  return occ;
}

function cargoFreeAt(occ, w, h, x, y){
  if (x < 0 || y < 0 || x + w > CARGO_W || y + h > CARGO_H) return false;
  for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (occ[yy][xx]) return false;
  return true;
}

/* 空位：能放就返回坐标。 */
function cargoFree(t, w, h){
  const occ = cargoOccupancy(t);
  for (let y = 0; y + h <= CARGO_H; y++) for (let x = 0; x + w <= CARGO_W; x++){
    if (cargoFreeAt(occ, w, h, x, y)) return { x, y };
  }
  return null;
}

/* 复制物资时保留数量、品质和朝向。背包 uid 只在背包里有意义。 */
function cargoInsert(t, it, x, y, w = it.w || 1, h = it.h || 1){
  const {uid, ...props} = it;
  truckCargoOf(t).push({...props, x, y, w, h});
}

function cargoRemoveCell(t, item){
  if (!cargoCanUse(t)) return false;
  const cells = truckCargoOf(t), index = cells.indexOf(item);
  if (index < 0) return false;
  cells.splice(index, 1);
  return true;
}

function cargoPutCell(t,it){
  const cells = truckCargoOf(t);
  const w = it.w || 1, h = it.h || 1;
  const spot = cargoFree(t,w,h);
  if (spot){ cargoInsert(t,it,spot.x,spot.y,w,h); return true; }
  const turned = w!==h && cargoFree(t,h,w);
  if (turned){ cargoInsert(t,{...it,rot:it.rot ? 0 : 1},turned.x,turned.y,h,w); return true; }
  const plan = planGridPacking([...cells,{w,h}],CARGO_W,CARGO_H);
  if (!plan) return false;
  for (let i=0;i<cells.length;i++){
    const c=cells[i], p=plan[i];
    if (p.w!==c.w) c.rot=c.rot ? 0 : 1;
    Object.assign(c,p);
  }
  const p=plan[cells.length];
  cargoInsert(t,{...it,rot:!!it.rot !== (p.w!==w) ? 1 : 0},p.x,p.y,p.w,p.h);
  return true;
}

/* 背包里的东西塞进货斗；成功才移除原物品。 */
function cargoPut(t, it){
  if (!cargoCanUse(t) || !it || it.eq || !bagItems().includes(it)) return false;
  if (!cargoPutCell(t,it)) return false;
  bagRemoveItem(it);
  bagRebuild();
  return true;
}

/* 身上穿着的装备（防弹衣 / 热成像）直接拖进货斗：先卸下来，再当成普通物品装车。
   以前这条路径被 it.eq 整体拦掉、只弹一句"先卸下来再装车"，玩家得先摘到背包里再拖一次。 */
function cargoPutEquipped(t, it){
  if (!cargoCanUse(t) || !it || !it.eq) return false;
  if (typeof player === 'undefined' || !player) return false;
  if (it.eq === 'thermal'){
    if (!player.heatWorn) return false;
    const cell = {k:'thermal', ...thermalPower(player), w:GRID_W.thermal, h:GRID_H.thermal};
    if (!cargoPutCell(t,cell)){ setMsg('货斗满了', 1.4); return false; }
    thermalSetWorn(null);
    setMsg('热成像装车', 1.5);
    return true;
  }
  if (it.eq === 'armor'){
    const a = player.armor;
    if (!a) return false;
    const w = GRID_W.armor || 2, h = GRID_H.armor || 2;
    const cell = {k:'armor',ak:a.kind,hp:a.hp,maxHp:a.maxHp,q:a.q,w,h};
    if (!cargoPutCell(t,cell)){ setMsg('货斗满了', 1.4); return false; }
    player.armor = null;
    setMsg('防弹衣装车', 1.5);
    return true;
  }
  return false;
}

/* 货斗里的东西拿回背包；背包塞不下就留原地。 */
function cargoTake(t, cell){
  if (!cargoCanUse(t) || !cell) return false;
  const arr = truckCargoOf(t), i = arr.indexOf(cell);
  if (i < 0) return false;
  const {x, y, ...extra} = cell;
  if (!bagAddCell(cell.k, extra)){
    const count = inventoryUnits(cell);
    const stack = bagItems().find(item => inventorySameStack(item, cell) &&
      inventoryStackLimit(item) - inventoryUnits(item) >= count);
    if (!stack) return false;
    inventorySetUnits(stack, inventoryUnits(stack) + count);
  }
  arr.splice(i, 1);
  bagRebuild();
  return true;
}

/* 附近可以装货的皮卡（80px 内、没报废） */
function cargoNear(range){
  if (!player || typeof trucks === 'undefined') return null;
  const R = range || 80;
  let best = null, bd = R * R;
  for (const t of trucks){
    if (!truckIsCargo(t) || t.wreck || t.dead || t.tstate === 'gone') continue;
    const dx = t.x - player.x, dy = t.y - player.y, d = dx * dx + dy * dy;
    if (d < bd){ bd = d; best = t; }
  }
  return best;
}

function cargoTryOpen(){
  if (cargoOpenTruck){ cargoClose(); return true; }
  const t = cargoNear(CARGO_ACCESS_RANGE);
  if (!t) return false;
  cargoOpenTruck = t;
  cargoSel = 0; cargoScroll = 0;
  setMsg('货斗：' + truckCargoOf(t).length + ' / ' + (CARGO_W * CARGO_H) + ' 格', 1.6);
  return true;
}

function cargoClose(){ cargoOpenTruck = null; }

/* 车被打烂：货斗里的东西全没了 */
function cargoBurnAll(t){
  const arr = truckCargoOf(t);
  if (!arr.length) return 0;
  const n = arr.length;
  arr.length = 0;
  setMsg('车炸了 · 货斗里的 ' + n + ' 件东西全烧了', 2.4);
  return n;
}

/* ---------------- 面板布局 ---------------- */
function cargoPanelGeom(){
  const pw = 720, ph = 470;
  const G = { x: (W - pw) / 2, y: (H - ph) / 2, w: pw, h: ph };
  const cell = 44, gap = 3;
  const gridW = CARGO_W * (cell + gap) - gap;
  const gridH = CARGO_H * (cell + gap) - gap;
  G.listX = G.x + 24; G.listY = G.y + 92; G.listW = 246; G.listRowH = 34;
  G.listRows = 9;
  G.gridX = G.x + G.w - 24 - gridW; G.gridY = G.y + 108;
  G.cell = cell; G.gap = gap; G.gridW = gridW; G.gridH = gridH;
  G.close = { x: G.x + G.w - 108, y: G.y + G.h - 44, w: 84, h: 30 };
  return G;
}

function cargoBagList(){
  if (typeof bagItems !== 'function') return [];
  return bagItems().filter(it => it && it.k !== 'key');   /* 钥匙是工具，别搬走 */
}

function cargoGridRect(G, idx){
  const x = G.gridX + (idx % CARGO_W) * (G.cell + G.gap);
  const y = G.gridY + Math.floor(idx / CARGO_W) * (G.cell + G.gap);
  return { x:x, y:y, w:G.cell, h:G.cell };
}
function cargoCellRect(G, c){
  return { x: G.gridX + c.x * (G.cell + G.gap), y: G.gridY + c.y * (G.cell + G.gap),
           w: c.w * (G.cell + G.gap) - G.gap, h: c.h * (G.cell + G.gap) - G.gap };
}

/* ---------------- 点击 ---------------- */
function cargoClick(mx, my){
  const t = cargoOpenTruck;
  if (!t) return false;
  const G = cargoPanelGeom();
  if (mx < G.x || mx > G.x + G.w || my < G.y || my > G.y + G.h){
    cargoClose(); return true;
  }
  if (mx >= G.close.x && mx <= G.close.x + G.close.w && my >= G.close.y && my <= G.close.y + G.close.h){
    cargoClose(); return true;
  }
  /* 货斗格：点一下拿回背包 */
  for (const c of truckCargoOf(t)){
    const r = cargoCellRect(G, c);
    if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h){
      if (cargoTake(t, c)) setMsg('拿回背包 · ' + (c.label || cargoName(c)), 1.2);
      else setMsg('背包塞不下它', 1.4);
      return true;
    }
  }
  /* 背包列表：点一下塞进货斗 */
  const list = cargoBagList();
  const maxOff = Math.max(0, list.length - G.listRows);
  if (cargoScroll > maxOff) cargoScroll = maxOff;
  for (let i = 0; i < G.listRows; i++){
    const idx = cargoScroll + i;
    if (idx >= list.length) break;
    const y = G.listY + i * G.listRowH;
    if (my >= y && my <= y + G.listRowH - 4 && mx >= G.listX && mx <= G.listX + G.listW){
      const it = list[idx];
      if (cargoPut(t, it)) setMsg('装进货斗 · ' + (it.label || cargoName(it)), 1.2);
      else setMsg('货斗放不下它', 1.4);
      return true;
    }
  }
  return true;
}

function cargoWheel(dy){
  if (!cargoOpenTruck) return false;
  const G = cargoPanelGeom();
  const list = cargoBagList();
  const maxOff = Math.max(0, list.length - G.listRows);
  cargoScroll = Math.max(0, Math.min(maxOff, cargoScroll + (dy > 0 ? 1 : -1)));
  return true;
}

/* 名字：优先 label，其次按 kind 给个通用名 */
function cargoName(it){
  if (!it) return '东西';
  if (it.label) return it.label;
  if (it.k === 'med'){
    const base = (it.r === 'big') ? '大药' : '小药';
    return (typeof qualityPrefix === 'function' ? qualityPrefix(it.q || 0) : '') + base;
  }
  if (it.k === 'ammo'){
    const CN = { pistol:'手枪弹', shotgun:'霰弹', rifle:'冲锋枪弹', ar:'步枪弹',
                 rocket:'火箭弹', flare:'信号弹' };
    const nm = CN[it.t] || (typeof AMMO !== 'undefined' && AMMO[it.t] && AMMO[it.t].name) || '弹药';
    return (typeof qualityPrefix === 'function' ? qualityPrefix(it.q || 0) : '') + nm + (it.n ? ' ×' + it.n : '');
  }
  if (it.k === 'attach'){
    const d = (typeof attachDef === 'function') ? attachDef(it.aid) : null;
    return d ? d.name : '配件';
  }
  if (it.k === 'armor'){
    const d = (typeof armorDef === 'function') ? armorDef(it.ak) : null;
    return d ? d.label : '防弹衣';
  }
  const M = { nade:'手雷', smoke:'烟雾弹', bag:'背包', thermal:'热成像', heatcell:'电池',
              shield:'盾牌', key:'万能钥匙', gun:'枪' };
  return M[it.k] || '东西';
}

/* ---------------- 绘制 ---------------- */
function drawCargoPanel(){
  return;   /* 已并入背包面板（Tab） */
  const t = cargoOpenTruck;
  if (!t) return;
  const G = cargoPanelGeom();
  const T = (typeof UI !== 'undefined' && UI) ? UI : null;
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(26,22,18,0.97)';
  ctx.strokeStyle = 'rgba(196,160,96,0.9)';
  ctx.lineWidth = 1.5;
  roundRect(G.x, G.y, G.w, G.h, 8); ctx.fill(); ctx.stroke();

  ctx.fillStyle = '#e8d1a4';
  ctx.font = 'bold 17px system-ui, "Microsoft YaHei", sans-serif';
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillText('皮卡货斗', G.x + 24, G.y + 36);
  ctx.font = '11px system-ui, "Microsoft YaHei", sans-serif';
  ctx.fillStyle = 'rgba(232,209,164,0.7)';
  ctx.fillText('能装 ' + (CARGO_W * CARGO_H) + ' 格 · 车被打烂里面的东西就全没了', G.x + 108, G.y + 36);

  ctx.fillStyle = 'rgba(232,209,164,0.85)';
  ctx.font = '12px system-ui, "Microsoft YaHei", sans-serif';
  ctx.fillText('你的背包（点一下装进去）', G.listX, G.y + 78);

  /* 左：背包列表 */
  const list = cargoBagList();
  const maxOff = Math.max(0, list.length - G.listRows);
  if (cargoScroll > maxOff) cargoScroll = maxOff;
  for (let i = 0; i < G.listRows; i++){
    const idx = cargoScroll + i;
    const y = G.listY + i * G.listRowH;
    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    ctx.fillRect(G.listX, y, G.listW, G.listRowH - 4);
    const it = list[idx];
    if (!it) continue;
    ctx.fillStyle = 'rgba(232,209,164,0.92)';
    ctx.font = '12px system-ui, "Microsoft YaHei", sans-serif';
    ctx.fillText(cargoName(it), G.listX + 10, y + 19);
    ctx.fillStyle = 'rgba(232,209,164,0.5)';
    ctx.fillText((it.w || 1) + '×' + (it.h || 1), G.listX + G.listW - 44, y + 19);
  }
  if (list.length > G.listRows){
    ctx.fillStyle = 'rgba(232,209,164,0.45)';
    ctx.font = '10px system-ui, "Microsoft YaHei", sans-serif';
    ctx.fillText('滚轮翻页（' + (cargoScroll + 1) + '-' + Math.min(list.length, cargoScroll + G.listRows) +
                 ' / 共 ' + list.length + ' 件）', G.listX, G.listY + G.listRows * G.listRowH + 12);
  } else if (!list.length){
    ctx.fillStyle = 'rgba(232,209,164,0.45)';
    ctx.font = '11px system-ui, "Microsoft YaHei", sans-serif';
    ctx.fillText('背包是空的', G.listX + 10, G.listY + 18);
  }

  /* 右：货斗格 */
  ctx.fillStyle = 'rgba(232,209,164,0.85)';
  ctx.font = '12px system-ui, "Microsoft YaHei", sans-serif';
  ctx.fillText('货斗 ' + truckCargoOf(t).length + ' 件（点一下拿回背包）', G.gridX, G.y + 78);
  for (let i = 0; i < CARGO_W * CARGO_H; i++){
    const r = cargoGridRect(G, i);
    ctx.fillStyle = 'rgba(255,255,255,0.045)';
    roundRect(r.x, r.y, r.w, r.h, 4); ctx.fill();
    ctx.strokeStyle = 'rgba(196,160,96,0.18)';
    ctx.lineWidth = 1; ctx.stroke();
  }
  for (const c of truckCargoOf(t)){
    const r = cargoCellRect(G, c);
    ctx.fillStyle = 'rgba(196,160,96,0.18)';
    roundRect(r.x, r.y, r.w, r.h, 4); ctx.fill();
    ctx.strokeStyle = 'rgba(196,160,96,0.75)'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = 'rgba(240,226,198,0.95)';
    ctx.font = '11px system-ui, "Microsoft YaHei", sans-serif';
    ctx.fillText(cargoName(c), r.x + 6, r.y + 20);
    ctx.fillStyle = 'rgba(240,226,198,0.55)';
    ctx.font = '10px system-ui, "Microsoft YaHei", sans-serif';
    ctx.fillText((c.w || 1) + '×' + (c.h || 1), r.x + 6, r.y + r.h - 8);
  }

  /* 关闭按钮 */
  ctx.fillStyle = 'rgba(196,160,96,0.22)';
  roundRect(G.close.x, G.close.y, G.close.w, G.close.h, 6); ctx.fill();
  ctx.strokeStyle = 'rgba(196,160,96,0.8)'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.fillStyle = '#f0e2c6';
  ctx.font = 'bold 13px system-ui, "Microsoft YaHei", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('关闭 (Esc)', G.close.x + G.close.w / 2, G.close.y + 20);
  ctx.textAlign = 'left';
  ctx.restore();
}

/* 站在皮卡旁边的提示（已停用，改成 Tab 面板） */
function drawCargoHint(){
  return;   /* 改成 Tab，车边不再堆文字 */
  if (!player || cargoOpenTruck || state !== 'play') return;
  const t = cargoNear(130);
  if (!t) return;
  const sx = t.x - cam.x, sy = t.y - cam.y;
  const n = truckCargoOf(t).length;
  ctx.save();
  ctx.font = 'bold 12px system-ui, "Microsoft YaHei", sans-serif';
  ctx.textAlign = 'center';
  const txt = 'Tab 背包 · 货斗 ' + n + ' / ' + (CARGO_W * CARGO_H);
  const w = ctx.measureText(txt).width + 16;
  ctx.fillStyle = 'rgba(12,14,18,0.78)';
  roundRect(sx - w / 2, sy - 66, w, 20, 5); ctx.fill();
  ctx.fillStyle = 'rgba(196,160,96,0.95)';
  ctx.fillText(txt, sx, sy - 52);
  ctx.restore();
}

/* ===== 货斗并进背包面板（Tab）：左边背包、右边货斗 ===== */
var cargoBagGeom = null;

function cargoPanelAttach(){
  const t = cargoCanUse(playerTruck) ? playerTruck : cargoNear(CARGO_ACCESS_RANGE);
  if (!t){ cargoPanelDetach(); return false; }
  cargoOpenTruck = t; truckCargoOf(t);
  return true;
}
function cargoPanelDetach(){ cargoOpenTruck = null; cargoBagGeom = null; }

function cargoBagRect(G){
  const cell = 32, gap = 3, cols = CARGO_W, rows = CARGO_H;
  const w = cols * cell + (cols - 1) * gap, h = rows * cell + (rows - 1) * gap;
  return { x: Math.round(G.ix + (G.iw - w) / 2), y: G.iy + 70, cell: cell, gap: gap,
           cols: cols, rows: rows, w: w, h: h };
}
function cargoBagItemRects(){
  const R0 = cargoBagGeom, t = cargoOpenTruck;
  if (!R0 || !cargoCanUse(t)) return [];
  return truckCargoOf(t).map(function(c){
    return { c: c,
      x: R0.x + c.x * (R0.cell + R0.gap), y: R0.y + c.y * (R0.cell + R0.gap),
      w: c.w * R0.cell + (c.w - 1) * R0.gap, h: c.h * R0.cell + (c.h - 1) * R0.gap };
  });
}
function cargoBagHit(mx, my){
  const arr = cargoBagItemRects();
  for (let i = 0; i < arr.length; i++){
    const r = arr[i];
    if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) return r;
  }
  return null;
}
function cargoBagInside(mx, my){
  const R0 = cargoBagGeom; if (!R0) return false;
  return mx >= R0.x - 8 && mx <= R0.x + R0.w + 8 && my >= R0.y - 8 && my <= R0.y + R0.h + 8;
}
function cargoBagPut(it){
  const t = cargoOpenTruck;
  if (!cargoCanUse(t) || !it) return '';
  if (!cargoPut(t, it)){ setMsg('货斗放不下这堆物资', 1.4); return ''; }
  const nm = cargoName(it);
  setMsg('装进货斗：' + nm, 1.2);
  return 'move';
}
function cargoBagTakeOut(r){
  if (!r || !cargoOpenTruck) return '';
  const nm = cargoName(r.c);
  if (!cargoTake(cargoOpenTruck, r.c)){ setMsg('背包塞不下这件 · 先清个格子', 1.5); return ''; }
  setMsg('拿回背包：' + nm, 1.2);
  return 'move';
}
function cargoBagDropOut(r){
  if (!r || !cargoOpenTruck) return '';
  const arr = truckCargoOf(cargoOpenTruck);
  const i = arr.indexOf(r.c);
  if (i < 0) return '';
  const nm = cargoName(r.c);
  if (typeof bagLootFromItem !== 'function') return '';
  arr.splice(i, 1);
  bagLootFromItem(r.c);
  setMsg('丢在地上：' + nm, 1.2);
  return 'drop';
}

/* 在背包面板右栏画货斗（8×5） */
function drawCargoInBag(G){
  const t = cargoOpenTruck;
  if (!cargoCanUse(t)) return;
  const R0 = G.cargo || cargoBagRect(G);
  cargoBagGeom = R0;
  const arr = truckCargoOf(t);
  ctx.save();
  /* 标题 */
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = 'rgba(214,178,110,0.98)';
  ctx.font = 'bold 14px "Microsoft YaHei",system-ui,sans-serif';
  ctx.fillText('皮卡货斗', R0.x, R0.y - 34);
  /* m19692：玩家会误以为货斗里的东西也能算撤离物资 —— 这里挂一条醒目警告 */
  const _t2 = '⚠ 车炸 → 货斗全没 · 车里物资不算撤离物资，带不回仓库';
  ctx.save();
  ctx.font = 'bold 15px "Microsoft YaHei",system-ui,sans-serif';
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  const _wy = R0.y - 58;
  const _ww = Math.min(R0.w + 40, ctx.measureText(_t2).width + 24);
  ctx.fillStyle = 'rgba(158,34,26,0.42)';
  ctx.beginPath(); ctx.roundRect(R0.x - 8, _wy - 19, _ww, 27, 6); ctx.fill();
  ctx.strokeStyle = 'rgba(248,132,104,0.9)'; ctx.lineWidth = 1.6; ctx.stroke();
  ctx.fillStyle = 'rgba(255,196,164,1)';
  ctx.fillText(_t2, R0.x + 4, _wy);
  ctx.restore();

  const _cnt = arr.length + ' / ' + (CARGO_W * CARGO_H) + ' 格';
  ctx.font = '12px "Microsoft YaHei",system-ui,sans-serif';
  ctx.textAlign = 'right';
  ctx.fillStyle = 'rgba(214,178,110,0.75)';
  ctx.fillText(_cnt, R0.x + R0.w, R0.y - 34);
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(196,160,96,0.32)';
  ctx.fillRect(R0.x, R0.y - 24, R0.w, 1);
  /* 提示 */
  ctx.font = '11px "Microsoft YaHei",system-ui,sans-serif';
  ctx.fillStyle = 'rgba(226,196,140,0.62)';
  ctx.fillText(keyLabel(BINDS.cargoQuickMove) + ' 整堆搬运，按住可连续扫过', R0.x, R0.y + R0.h + 20, R0.w);
  ctx.fillStyle = 'rgba(226,196,140,0.45)';
  ctx.fillText('车被打烂，货斗里的东西全烧掉', R0.x, R0.y + R0.h + 38);
  /* 格子 */
  for (let y = 0; y < R0.rows; y++) for (let x = 0; x < R0.cols; x++){
    const cx = R0.x + x * (R0.cell + R0.gap), cy = R0.y + y * (R0.cell + R0.gap);
    ctx.beginPath(); ctx.roundRect(cx, cy, R0.cell, R0.cell, 4);
    ctx.fillStyle = 'rgba(0,0,0,0.26)'; ctx.fill();
    ctx.strokeStyle = 'rgba(196,160,96,0.20)'; ctx.lineWidth = 1; ctx.stroke();
  }
  /* 里面的东西 */
  const hv = cargoBagHit(mouse.x, mouse.y);
  for (const r of cargoBagItemRects()){
    ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 4);
    ctx.fillStyle = 'rgba(0,0,0,0.30)'; ctx.fill();
    ctx.strokeStyle = (hv && hv.c === r.c) ? 'rgba(240,206,138,0.95)' : 'rgba(196,160,96,0.34)';
    ctx.lineWidth = (hv && hv.c === r.c) ? 1.6 : 1; ctx.stroke();
    const _sz = Math.min(r.w, r.h) - 8;
    bagDrawItemIcon(r.c, r.x + r.w / 2, r.y + r.h / 2, _sz);
    if (r.c.n !== undefined){
      ctx.font = 'bold 12px system-ui, sans-serif'; ctx.textAlign = 'right';
      ctx.fillStyle = '#f0e2c6'; ctx.fillText(r.c.n, r.x + r.w - 4, r.y + r.h - 4);
      ctx.textAlign = 'left';
    }
  }
  ctx.restore();
}
