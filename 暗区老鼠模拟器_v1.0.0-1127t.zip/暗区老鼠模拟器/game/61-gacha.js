/* ============================================================================
   抽奖商人（中立 NPC）—— 目前只在测试区
   ----------------------------------------------------------------------------
   规则
     1) 中立：不主动打人；敌人也不打他。只有被打到才反击（angry 9 秒）。
     2) 按 E 开抽奖盘：
          左：押注格 4×3（按体积占格，火箭弹 2×1；枪不能押）
          中：点击自动押入，也可以拖到指定位置；点击已押物品取回
          右：奖品清单，先选自己想要的
        中奖率 = clamp(8%, 90%, 55% × 押注总价值 / 奖品价值)
     3) 开转 → 转盘 3.2 秒 → 中：押注退还 + 拿走奖品；不中：押注全没。
   全部数据驱动：押注估值 GACHA_VAL、奖品表 GACHA_PRIZES。
   ============================================================================ */

var traders = [];        /* 商人实体（测试区里只有一个） */

/* 押注估值表 GACHA_VAL 与奖品表 GACHA_PRIZES 已搬到 data/gacha.js
   （那里是唯一来源 —— 改奖品价值/上新奖品去那个文件，这里不再放数据）。
   稀有度倍率仍在下面的 gachaCellValue() 里，因为它是"怎么算"的逻辑。 */

function newGachaRun(){ return {
  open: false,
  page: 'setup',        /* setup | spin | result */
  sel: 0,
  bets: [],             /* [{ c:<背包格子对象>, gx, gy, gw, gh, rot }] */
  drag: null,
  prop: 0,
  ang: 0, a0: 0, a1: 0,
  t: 0, dur: 4.8,
  win: false,
  wheel: 12, scrollMine: 0,
  pity: 0, sameSel: 0, lastSel: -1, lastRatio: 0,     /* 连输次数 / 连着押同一个奖品的次数 */
  lastLayout: null,                     /* 上一次开转时的押注布局，可一键照摆 */
  phase: 0, holdT: 0, snapT: 0,         /* 转盘三拍：转 → 停在最后一格前 → 滑进去 */
  aHold: 0, aSnap0: 0, step: 0,
  msg: '', msgT: 0, tickIdx: 0,
  awarded: new Map()
}; }
const GACHA = newGachaRun();

function resetGachaRun(){
  if (!traders) return;
  // 旧局所有押注已经随该局结束，不能退到新玩家的背包里。
  Object.assign(GACHA,newGachaRun());
  traders.length = 0;
}
function gachaRemaining(prize){
  return prize.stock === undefined ? undefined : Math.max(0,prize.stock-(GACHA.awarded.get(prize.id)||0));
}
const GACHA_GW = 4, GACHA_GH = 3, GACHA_CELL = 44;

/* 押注格里的东西就是背包格子对象本身，所以字段是 ak / bk / r / t / n */
function gachaQ(c){ const q = c && c.q; return (q === 0 || q) ? Math.max(0, Math.min(3, q)) : 0; }
function gachaCellValue(c){
  if (!c) return 0;
  /* 金条是固定收购价，不乘品质倍率 */
  if (c.k === 'rare') return (GACHA_VAL.rare || 450);
  let v = 0;
  if (c.k === 'med') v = (c.r === 1 ? GACHA_VAL.med.big : GACHA_VAL.med.small);
  else if (c.k === 'armor') v = GACHA_VAL.armor * (c.ak === 'elite' ? 1.8 : c.ak === 'heavy' ? 1.3 : 1);
  else if (c.k === 'bag') v = GACHA_VAL.bag * (c.bk === 'big' ? 1.9 : c.bk === 'mid' ? 1.3 : 1);
  else if (c.k === 'ammo'){
    /* 弹药按【发】算价：一发火箭弹顶一堆手枪弹，60 发手枪弹也不该跟 1 发一个价 */
    const per = (c.t === 'rocket') ? 45 : (c.t === 'rifle' || c.t === 'ar') ? 0.55 : (c.t === 'shotgun') ? 0.85 : 0.40;
    v = Math.max(6, per * Math.max(1, c.n | 0));
  }
  else if (c.k === 'heatcell' || c.k === 'nade' || c.k === 'smoke') v = (GACHA_VAL[c.k] || 12) * Math.max(1, c.n | 0);
  else v = (GACHA_VAL[c.k] || 12);
  return Math.round(v * (1 + gachaQ(c) * 0.25));
}
function gachaBetValue(){ let v = 0; for (const b of GACHA.bets) v += gachaCellValue(b.c); return v; }
/* 转盘只有 12 格，概率量化到 1/12 —— 显示多少就是多少，别让玩家自己算对不上 */
/* 面板显示用：现在概率是连续的，不再量化到 12 格（以前压成 1/12 会让"放一件和放一堆"都显示 8%） */
function gachaChanceQ(){ return gachaChance(); }
/* 中奖率：一条连续曲线，不再是"12 格里数几格"。
   押得越多越接近上限，但期望一直是负的 —— 以小博大靠的是"押得少、赔率高"，
   不是"押得多就赚"。用户要求"押得少别太惨"，所以指数取 0.65（曲线更平）。 */
function gachaChanceRaw(){
  const prize = GACHA_PRIZES[GACHA.sel];
  if (!prize) return 0;
  const bv = Math.min(gachaBetValue(), prize.value);
  if (bv <= 0) return 0;
  const ratio = bv / Math.max(1, prize.value);
  const p = 0.45 * Math.pow(ratio, 0.65);
  return Math.max(0.06, Math.min(0.45, p));
}
/* 连输保底：每输 2 次 +3%，封顶 +25%；连着押同一个奖品每次 +3%，封顶 +9%。
   注意"防刷"：只有押注值到奖品值 30% 以上才计入连输，扔垃圾刷保底没用。 */
function gachaPityAdd(){ return Math.min(0.25, Math.floor((GACHA.pity || 0) / 2) * 0.03); }
function gachaSameAdd(){ return Math.min(0.09, (GACHA.sameSel || 0) * 0.03); }
function gachaChance(){
  const raw = gachaChanceRaw();
  if (raw <= 0) return 0;
  return Math.max(0.02, Math.min(0.95, raw + gachaPityAdd() + gachaSameAdd()));
}

/* ---------------- 体积 ---------------- */
function gachaShape(c){
  if (!c) return { w:1, h:1 };
  /* 占格必须和背包里一模一样：防弹衣 3×3、背包 2×3、热成像 1×2、火箭弹 2×1，
     不然押注盘上一件甲只占一格，看着就像"能白嫖 9 格" */
  if (c.k === 'ammo') return (typeof ammoCellSize === 'function') ? ammoCellSize(c.t) : { w:1, h:1 };
  const w = (typeof GRID_W !== 'undefined' && GRID_W[c.k]) || 1;
  const h = (typeof GRID_H !== 'undefined' && GRID_H[c.k]) || 1;
  return { w:w, h:h };
}
function gachaOverlaps(a, b){
  return a.gx < b.gx + b.gw && a.gx + a.gw > b.gx &&
         a.gy < b.gy + b.gh && a.gy + a.gh > b.gy;
}
function gachaInside(b){
  return b.gx >= 0 && b.gy >= 0 && b.gx + b.gw <= GACHA_GW && b.gy + b.gh <= GACHA_GH;
}
function gachaFootprint(c, rot){
  const {w, h} = gachaShape(c);
  return {gw:rot ? h : w, gh:rot ? w : h, rot:!!rot};
}
function gachaFindPlacement(c, preferred){
  const rot = preferred?.rot ?? !!c.rot;
  const shape = gachaFootprint(c, rot);
  const free = p => gachaInside(p) && !GACHA.bets.some(b => gachaOverlaps(p,b));
  const exact = preferred && {...shape, gx:preferred.gx, gy:preferred.gy};
  if (exact && free(exact)) return exact;
  for (const face of shape.gw === shape.gh ? [shape] : [shape, gachaFootprint(c,!rot)]){
    for (let gy = 0; gy + face.gh <= GACHA_GH; gy++)
      for (let gx = 0; gx + face.gw <= GACHA_GW; gx++){
        const p = {...face, gx, gy};
        if (free(p)) return p;
      }
  }
  return null;
}
function gachaPacking(target, bet, shape){
  const others = GACHA.bets.filter(b => b!==bet);
  const item = target ? {x:target.gx,y:target.gy,w:target.gw,h:target.gh} : {w:shape.gw,h:shape.gh};
  const packed = planGridPacking([...others.map(b=>({w:b.gw,h:b.gh})),item],GACHA_GW,GACHA_GH,target ? item : null);
  if (!packed) return null;
  const pos = (p, before) => ({gx:p.x,gy:p.y,gw:p.w,gh:p.h,rot:!!before.rot !== (p.w!==before.gw)});
  return {moves:others.map((b,i)=>({item:b,...pos(packed[i],b)})),
    spot:pos(packed[others.length],shape || target)};
}
function gachaAutoPlan(c, preferred){
  const spot = gachaFindPlacement(c,preferred);
  return spot ? {spot,moves:[]} : gachaPacking(null,null,gachaFootprint(c,preferred?.rot ?? c.rot));
}
function gachaPlace(c, placement = gachaAutoPlan(c)){
  if (!placement) return false;
  gachaApplyPlan(placement.moves);
  GACHA.bets.push({c,...placement.spot});
  return true;
}

/* 在临时布局上置换。优先把压住的物品摆回拖出后腾空的位置。 */
function gachaMovePlan(bet, target){
  if (!gachaInside(target)) return null;
  const area = GACHA.bets.reduce((sum,b) => b === bet ? sum : sum+b.gw*b.gh, target.gw*target.gh);
  if (area > GACHA_GW*GACHA_GH) return null;
  const hit = [], fixed = [target];
  for (const other of GACHA.bets){
    if (other === bet) continue;
    (gachaOverlaps(target,other) ? hit : fixed).push(other);
  }
  hit.sort((a,b) => b.gw*b.gh - a.gw*a.gh);
  const plan = [];
  function placeNext(i){
    if (i === hit.length) return true;
    const item = hit[i];
    const origin = [], positions = [];
    for (let gy=0; gy+item.gh<=GACHA_GH; gy++)
      for (let gx=0; gx+item.gw<=GACHA_GW; gx++){
        const p = {gx,gy,gw:item.gw,gh:item.gh};
        if (fixed.some(other => gachaOverlaps(p,other))) continue;
        const inOrigin = bet && gx>=bet.gx && gy>=bet.gy && gx+p.gw<=bet.gx+bet.gw && gy+p.gh<=bet.gy+bet.gh;
        (inOrigin ? origin : positions).push(p);
      }
    for (const p of origin.concat(positions)){
      fixed.push(p); plan.push({item,gx:p.gx,gy:p.gy});
      if (placeNext(i+1)) return true;
      fixed.pop(); plan.pop();
    }
    return false;
  }
  return placeNext(0) ? plan : gachaPacking(target,bet)?.moves;
}
function gachaApplyPlan(plan){
  for (const {item,...position} of plan) Object.assign(item,position);
}
function gachaWhereBet(gx, gy){
  for (let i = 0; i < GACHA.bets.length; i++){
    const b = GACHA.bets[i];
    if (gx >= b.gx && gx < b.gx + b.gw && gy >= b.gy && gy < b.gy + b.gh) return i;
  }
  return -1;
}

/* ---------------- 可押列表 ---------------- */
function gachaLabel(c){
  if (!c) return '东西';
  if (c.k === 'med') return ((MED_DEF[c.r === 1 ? 'big' : 'small']) || {}).label || '药';
  if (c.k === 'ammo'){ const a = (typeof AMMO !== 'undefined' && AMMO[c.t]) || null; return (a && (a.name || a.label)) || c.t; }
  if (c.k === 'armor') return ((ARMOR_DEF[c.ak]) || {}).label || '护甲';
  if (c.k === 'bag') return ((BAG_DEF[c.bk]) || {}).label || '背包';
  if (c.k === 'attach') return ((attachDef(c.aid)) || {}).name || '配件';
  if (c.k === 'nade') return '手雷';
  if (c.k === 'smoke') return '烟雾弹';
  if (c.k === 'thermal') return '热成像';
  if (c.k === 'heatcell') return '热成像电池';
  if (c.k === 'key') return '万能钥匙';
  if (c.k === 'flare') return '信号弹';
  if (c.k === 'shield') return '防弹盾牌';
  return c.k;
}
/* 列表顺序：同类摆在一起，同类里再按口径/档位/品质排 */
const GACHA_KIND_ORDER = ['med', 'ammo', 'nade', 'smoke', 'armor', 'bag', 'thermal', 'heatcell', 'attach', 'key', 'shield', 'flare'];
function gachaSortKey(it){
  const g = GACHA_KIND_ORDER.indexOf(it.k);
  let sub = 0;
  if (it.k === 'med') sub = (it.r === 1 || it.r === 'big') ? 1 : 0;
  else if (it.k === 'ammo') sub = ['pistol','shotgun','rifle','ar','rocket'].indexOf(it.t);
  else if (it.k === 'armor') sub = ['light','heavy','elite'].indexOf(it.ak);
  else if (it.k === 'bag') sub = ['small','mid','big'].indexOf(it.bk);
  else if (it.k === 'attach') sub = it.aid === 'choke_long' ? 2 : it.aid === 'choke_tight' ? 1 : 0;
  return (g < 0 ? 99 : g) * 1000 + (sub < 0 ? 0 : sub) * 100 - ((it.q | 0) * 1);
}
function gachaBetTable(){
  const out = [];
  const items = (typeof bagItems === 'function') ? bagItems() : [];
  for (const it of items){
    if (it.k === 'gun') continue;          /* 枪不能押 */
    out.push(it);                          /* 直接给背包格子对象 */
  }
  out.sort((a, b) => gachaSortKey(a) - gachaSortKey(b));
  return out;
}

/* 一发多少钱（拆分押注时用；gachaCellValue 里对小堆有 max(6,…) 保底，这里要线性的） */
function gachaAmmoUnit(t){
  return (t === 'rocket') ? 45 : (t === 'rifle' || t === 'ar') ? 0.55 : (t === 'shotgun') ? 0.85 : 0.40;
}
/* 这一堆子弹该押几发：刚好够到奖品值就停；已经够了就押 1 发试试 */
function gachaAmmoTakeCount(it, cap, bet){
  const total = (it && (it.n | 0)) || 0;
  if (total <= 1) return total;
  const need = Math.max(0, (cap || 0) - (bet || 0));
  if (need <= 0) return 1;
  const unit = gachaAmmoUnit(it.t);
  return Math.min(total, Math.max(1, Math.ceil(need / unit)));
}
/* 从背包里的一堆子弹里只拿 n 发出来（剩下的留在原格） */
function gachaTakeAmmoPart(uid, n){
  const items = (typeof bagItems === 'function') ? bagItems() : [];
  const it = items.find(x => x.uid === uid);
  if (!it || it.k !== 'ammo') return null;
  const total = it.n | 0;
  if (n >= total) return gachaTakeFromBag(uid);
  it.n = total - n;
  bagRebuild();
  return { k:'ammo', t: it.t, n: n, q: it.q || 0 };
}

/* ---------------- 转账：背包 ↔ 押注格 ---------------- */
function gachaGiveBack(c){
  if (!c) return;
  const ok = bagAddCell(c.k, c);
  bagRebuild();
  if (!ok) gachaLoot(c);
}
function gachaTakeFromBag(uid){
  const items = (typeof bagItems === 'function') ? bagItems() : [];
  const it = items.find(x => x.uid === uid);
  if (!it) return null;
  if (typeof bagRemoveItem !== 'function') return null;
  bagRemoveItem(it);
  bagRebuild();
  return it;
}

/* 掉脚边（背包满的兜底） */
function gachaLoot(c){
  if (!player || !c) return;
  const l = { x: player.x + rand(-20, 20), y: player.y + rand(-20, 20), taken:false, cool:0.6, gear:true, kind:c.k, q:gachaQ(c) };
  if (c.k === 'armor'){ l.kind = 'armor'; l.armor = c.ak; l.hp = c.hp; l.maxHp = c.maxHp; }
  else if (c.k === 'attach'){ l.kind = 'attach'; l.aid = c.aid; }
  else if (c.k === 'med'){ l.kind = 'med'; l.rarity = medR(c.r); l.du = medDuOf(c); }
  else if (c.k === 'ammo'){ l.kind = 'ammo'; l.ammo = c.t; l.n = c.n; }
  else if (c.k === 'bag'){ l.kind = 'bag'; l.bag = c.bk; }
  else if (c.k === 'gun'){ l.kind = 'gun'; l.wid = c.wid; }
  /* 落点自动躲开地上已有的东西，免得全堆在脚边糊成一团 */
  const _sp = (typeof lootSpot === 'function') ? lootSpot(l.x, l.y) : l;
  l.x = _sp.x; l.y = _sp.y;
  loots.push(l);
}

/* ---------------- 发奖品 ---------------- */
function gachaGrant(prize){
  if (!prize) return;
  const g = prize.give || {};
  const drop = (c) => { if (typeof gachaLoot === 'function') gachaLoot(c); };
  const times = (n, fn) => { for (let i = 0; i < Math.max(1, n || 1); i++) fn(i); };
  /* 全部掉在脚边：玩家自己捡，走的是"正常掉落"那条路，
     不会因为某个 give 字段没写分支就变成"中了啥也没给" */
  if (g.k === 'gun'){
    drop({ k:'gun', wid: g.wid || 'pistol' });
  } else if (g.k === 'armor'){
    const d = (typeof ARMOR_DEF !== 'undefined' && ARMOR_DEF[g.kind]) ? ARMOR_DEF[g.kind] : { dur: 100 };
    drop({ k:'armor', ak: g.kind || 'light', hp: d.dur, maxHp: d.dur });
  } else if (g.k === 'bag'){
    drop({ k:'bag', bk: g.kind || 'mid' });
  } else if (g.k === 'thermal'){
    drop({ k:'thermal' });
  } else if (g.k === 'attach'){
    drop({ k:'attach', aid: g.aid });
  } else if (g.k === 'med'){
    times(g.n, () => drop({ k:'med', r: g.r, q: (g.q === undefined ? 0 : g.q) }));
  } else if (g.k === 'heatcell'){
    times(g.n, () => drop({ k:'heatcell' }));
  } else if (g.k === 'nade'){
    times(g.n, () => drop({ k:'nade' }));
  } else if (g.k === 'intel'){
    drop({ k:'intel' });
  } else if (g.k === 'smoke'){
    times(g.n, () => drop({ k:'smoke' }));
  } else if (g.k === 'ammo'){
    if (g.t === 'rocket') times(g.n, () => drop({ k:'ammo', t:'rocket', n:1 }));
    else drop({ k:'ammo', t: g.t, n: g.n || 1 });
  }
  bagRebuild();
  if (typeof logInfo === 'function')
    logInfo('item', '抽奖中了 · ' + (prize.label || '') + '（掉在脚边）');
}

/* 列表能滚多少：可视行数不够就按件数夹住 */
function gachaMineOff(list){
  const rows = 5;                     /* 与 L.mine.rows 一致 */
  const max = Math.max(0, (list ? list.length : 0) - rows);
  GACHA.scrollMine = Math.max(0, Math.min(max, GACHA.scrollMine | 0));
  return GACHA.scrollMine;
}
/* 鼠标滚轮：面板开着且指在列表上时翻列表，其余情况不抢滚轮 */
function gachaWheel(dy){
  if (!GACHA.open || GACHA.page !== 'setup' || !dy) return false;
  const list = gachaBetTable();
  if (list.length <= 5) return false;
  const mx = (typeof mouse !== 'undefined' && mouse) ? mouse.x : -1;
  const my = (typeof mouse !== 'undefined' && mouse) ? mouse.y : -1;
  const L2 = gachaListGeom();
  if (!(mx >= L2.mine.x - 12 && mx <= L2.mine.x + L2.mine.w && my >= L2.mine.y - 24 && my <= L2.mine.y + 5 * L2.mine.rowH + 20)) return false;
  GACHA.scrollMine = (GACHA.scrollMine | 0) + (dy > 0 ? 1 : -1);
  gachaMineOff(list);
  return true;
}

/* ---------------- 开/关 ---------------- */
function gachaOpen(){
  if (GACHA.open) return;
  GACHA.open = true;
  GACHA.page = 'setup';
  GACHA.drag = null;
  GACHA.t = 0; GACHA.win = false; GACHA.prop = 0;
  GACHA.msg = ''; GACHA.msgT = 0; GACHA.scrollMine = 0;
  if (typeof ui !== 'undefined' && ui && ui.inv) ui.inv.open = false;
  mouse.fire = false; mouse.down = false;
  if (typeof sfxTraderHi === 'function') sfxTraderHi(1 + ((GACHA.sel || 0) % 3) * 0.06);
}
/* 按上次的布局，从背包里挑同样的东西摆回去 */
function gachaSameSpec(a, b){
  if (!a || !b) return false;
  if (a.k !== b.k) return false;
  if (a.k === 'med') return (a.r === 1 || a.r === 'big') === (b.r === 1 || b.r === 'big');
  if (a.k === 'ammo') return a.t === b.t;
  if (a.k === 'armor') return a.ak === b.ak;
  if (a.k === 'bag') return a.bk === b.bk;
  if (a.k === 'attach') return a.aid === b.aid;
  return true;
}
function gachaRestoreLayout(){
  const lay = GACHA.lastLayout;
  if (!lay || !lay.length){ GACHA.msg = '还没有上次的摆法'; GACHA.msgT = 2; return 0; }
  /* 先把现在盘里的退回背包，再照上次摆 */
  for (const b of GACHA.bets) gachaGiveBack(b.c);
  GACHA.bets = [];
  bagRebuild();
  let n = 0;
  for (const spec of lay){
    const list = gachaBetTable();
    let pick = list.find(x => gachaSameSpec(x, spec) && ((x.q | 0) === (spec.q | 0)));
    if (!pick) pick = list.find(x => gachaSameSpec(x, spec));      /* 品质对不上也认 */
    if (!pick) continue;
    const spot = gachaAutoPlan(pick, spec);
    if (!spot) continue;
    const c = gachaTakeFromBag(pick.uid);
    if (c && gachaPlace(c, spot)) n++;
  }
  GACHA.msg = n ? ('照上次摆了 ' + n + ' 件') : '背包里凑不齐上次那些东西了';
  GACHA.msgT = 2.2;
  return n;
}

function gachaClose(force){
  /* 转盘已经开转就不能中途关面板：不然没中之前关掉＝押注全退回，等于零成本抽奖。
     只有"已经不在局内"（死了 / 结算 / 回放）才允许强关。 */
  if (!force && GACHA.page === 'spin' && typeof state === 'string' && state === 'play'){
    GACHA.msg = '转盘转完再说'; GACHA.msgT = 1.6;
    return false;
  }
  for (const b of GACHA.bets) gachaGiveBack(b.c);
  GACHA.bets = [];
  GACHA.open = false;
  GACHA.drag = null;
  bagRebuild();
  return true;
}

/* ---------------- 转盘 ---------------- */
function gachaSpinStart(){
  const _pz = GACHA_PRIZES[GACHA.sel];
  if (_pz && gachaRemaining(_pz) === 0){
    GACHA.msg = '这个奖品已经售罄了'; GACHA.msgT = 2.2; return false;
  }
  const p = gachaChance();
  if (p <= 0){ GACHA.msg = '先往押注格里放点东西'; GACHA.msgT = 2.2; return false; }
  GACHA.prop = p;
  /* 记下这次押注的"含金量"：太低就不给保底，免得拿垃圾刷连输 */
  GACHA.lastRatio = _pz ? Math.min(gachaBetValue(), _pz.value) / Math.max(1, _pz.value) : 0;
  GACHA.win = Math.random() < p;
  GACHA.page = 'spin';
  GACHA.t = 0;
  GACHA.a0 = GACHA.ang;

  /* 金色弧占 p 圈；指针落在弧里就是中 */
  const TAU2 = Math.PI * 2;
  const gold = p * TAU2;
  let th;
  if (GACHA.win) th = (0.08 + Math.random() * 0.84) * gold;
  else {
    const rest = Math.max(0.0001, TAU2 - gold);
    th = gold + (0.06 + Math.random() * 0.88) * rest;
  }
  let a1 = -Math.PI / 2 - th;
  while (a1 < GACHA.a0 + TAU2 * 5) a1 += TAU2;
  GACHA.a1 = a1;
  GACHA.step = TAU2 / GACHA.wheel;
  /* 记下这次怎么摆的，赢了以后可以照着摆回去 */
  GACHA.lastLayout = GACHA.bets.map(b => ({ k:b.c.k, ak:b.c.ak, bk:b.c.bk, r:b.c.r, t:b.c.t,
                                            n:b.c.n, aid:b.c.aid, q:b.c.q, gx:b.gx, gy:b.gy, rot:b.rot }));
  GACHA.phase = 0; GACHA.holdT = 0; GACHA.snapT = 0;
  GACHA.tickIdx = Math.floor(GACHA.ang / Math.max(0.0001, GACHA.step));
  if (typeof sfxGachaSpin === 'function') sfxGachaSpin();
  return true;
}
function gachaSpinDone(){
  GACHA.page = 'result';
  GACHA.ang = GACHA.a1;
  if (GACHA.sel !== GACHA.lastSel){ GACHA.sameSel = 0; GACHA.lastSel = GACHA.sel; }
  if (GACHA.win){
    for (const b of GACHA.bets) gachaGiveBack(b.c);
    GACHA.bets = [];
    const pz = GACHA_PRIZES[GACHA.sel];
    gachaGrant(pz);
    if (gachaRemaining(pz) > 0) GACHA.awarded.set(pz.id,(GACHA.awarded.get(pz.id)||0)+1);
    GACHA.pity = 0; GACHA.sameSel = 0;
    GACHA.msg = '中了：' + pz.label + '（押注已退回 · 奖品掉在脚边）';
    if (typeof sfxGachaWin === 'function') sfxGachaWin();
    if (typeof sfxPick === 'function') sfxPick();
    if (typeof setMsg === 'function') setMsg('抽奖中了！' + pz.label + ' · 掉在脚边', 2.4);
  } else {
    const n = GACHA.bets.length;
    GACHA.bets = [];
    /* 押注不到奖品值三成，不记连输 —— 不然扔垃圾刷保底 */
    if ((GACHA.lastRatio || 0) >= 0.3) GACHA.pity = (GACHA.pity || 0) + 1;
    if ((GACHA.lastRatio || 0) >= 0.3) GACHA.sameSel = (GACHA.sameSel || 0) + 1;
    /* 不中也给点渣：25% 返一小把子弹，别让人连空手三次就想砸键盘 */
    let _tip = '';
    if (Math.random() < 0.25){
      if (typeof bagAddAmmo === 'function'){ bagAddAmmo('pistol', 12); bagRebuild(); _tip = ' · 捡到 12 发手枪弹'; }
    }
    GACHA.msg = '没中…… 押注的 ' + n + ' 件东西全没了' + _tip;
    if (typeof sfxGachaLose === 'function') sfxGachaLose();
    if (typeof setMsg === 'function') setMsg('抽奖没中，' + n + ' 件押注物没了', 2.4);
  }
  GACHA.msgT = 9;
}
function gachaTick(dt){
  if (!dt || dt <= 0) return;
  if (GACHA.msgT > 0) GACHA.msgT -= dt;
  if (!GACHA.open || GACHA.page !== 'spin') return;
  /* 一次滑到位：四次方缓出，尾巴长但不"再蹭一格" */
  GACHA.t = Math.min(1, GACHA.t + dt / GACHA.dur);
  const e = 1 - Math.pow(1 - GACHA.t, 4);
  const _prevAng = GACHA.ang;
  GACHA.ang = GACHA.a0 + (GACHA.a1 - GACHA.a0) * e;
  /* 格格响：指针每跨过一格来一下，越接近停下越闷越轻 */
  if (typeof sfxGachaTick === 'function' && GACHA.step > 0){
    const _i = Math.floor(GACHA.ang / GACHA.step);
    if (_i !== GACHA.tickIdx){
      const _sp = Math.min(1, Math.abs(GACHA.ang - _prevAng) / (GACHA.step || 1));
      sfxGachaTick(_sp * 1.6 > 1 ? 1 : _sp * 1.6);
      GACHA.tickIdx = _i;
    }
  }
  if (GACHA.t >= 1){
    GACHA.ang = GACHA.a1;
    if (typeof sfxGachaStop === 'function') sfxGachaStop();
    if (typeof sfxClickGun === 'function') sfxClickGun(false);
    gachaSpinDone();
  }
}

/* ---------------- 面板几何 ---------------- */
function gachaGeom(){
  const w = 900, h = 470;
  return { x: Math.round((W - w) / 2), y: Math.round((H - h) / 2), w:w, h:h };
}
function gachaBetRect(i){
  const G = gachaGeom();
  return {
    x: G.x + 24 + (i % GACHA_GW) * (GACHA_CELL + 6),
    y: G.y + 86 + Math.floor(i / GACHA_GW) * (GACHA_CELL + 6),
    w: GACHA_CELL, h: GACHA_CELL
  };
}
function gachaHitBet(mx, my){
  for (let i = 0; i < GACHA.bets.length; i++){
    const b = GACHA.bets[i];
    const r = gachaRect(b);
    if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) return i;
  }
  return -1;
}
function gachaListGeom(){
  const G = gachaGeom();
  return {
    mine:  { x:G.x + 250, y:G.y + 86, w:252, rows:5, rowH:40 },
    prize: { x:G.x + 530, y:G.y + 86, w:346, rows:10, rowH:30 },   /* rows 必须 ≥ GACHA_PRIZES.length，否则排在后面的奖品根本点不到（情报就被挡在 9 行外面过） */
    spin:  { x:G.x + 24,  y:G.y + 300, w:196, h:52 },
    last:  { x:G.x + 24,  y:G.y + 362, w:196, h:30 },
    close: { x:G.x + G.w - 108, y:G.y + G.h - 52, w:84, h:36 }
  };
}

function gachaMineHit(mx, my, geom){
  const {x,y,w,rowH,rows} = geom;
  const row = Math.floor((my-y)/rowH);
  if (mx < x || mx > x+w || row < 0 || row >= rows) return null;
  const list = gachaBetTable();
  return list[gachaMineOff(list)+row] || null;
}
function gachaBetItem(it, target){
  const moves = target && gachaMovePlan(null,target);
  const spot = target ? (moves && {spot:target,moves}) : gachaAutoPlan(it);
  if (!spot){
    GACHA.msg = '押注格放不下了'; GACHA.msgT = 2;
    return;
  }
  const cap = GACHA_PRIZES[GACHA.sel]?.value ?? 9999;
  const value = gachaBetValue();
  const total = it.n | 0;
  const count = it.k === 'ammo' ? gachaAmmoTakeCount(it,cap,value) : 0;
  const item = count > 0 && count < total ? gachaTakeAmmoPart(it.uid,count) : gachaTakeFromBag(it.uid);
  if (!item){ GACHA.msg = '拿不出来（背包变了）'; GACHA.msgT = 2; return; }
  gachaPlace(item,spot);
  if (count > 0 && count < total){
    GACHA.msg = '只押了 ' + count + ' 发，剩下 ' + (total-count) + ' 发留在背包';
    GACHA.msgT = 2;
  } else if (value + gachaCellValue(item) > cap){
    GACHA.msg = '押注值已经超过奖品值了 · 多出来的部分是白搭';
    GACHA.msgT = 2.8;
  }
}
function gachaRect(spot){
  const base = gachaBetRect(spot.gy*GACHA_GW + spot.gx);
  return {x:base.x,y:base.y,w:spot.gw*(GACHA_CELL+6)-6,h:spot.gh*(GACHA_CELL+6)-6};
}
function gachaStartDrag(mx, my, bet, item){
  const shape = gachaFootprint(item,bet ? bet.rot : item.rot);
  const rect = bet && gachaRect(bet);
  GACHA.drag = {bet,item,shape,sx:mx,sy:my,forced:false,
    u:rect ? (mx-rect.x)/rect.w : 0.5, v:rect ? (my-rect.y)/rect.h : 0.5};
}
function gachaDragMoved(drag, mx, my){
  return drag.forced || Math.hypot(mx-drag.sx,my-drag.sy)>6;
}
function gachaDragTarget(drag, mx, my){
  const first = gachaBetRect(0), last = gachaBetRect(GACHA_GW*GACHA_GH-1);
  if (mx < first.x || my < first.y || mx > last.x+last.w || my > last.y+last.h) return null;
  const step = GACHA_CELL+6;
  const {gw,gh} = drag.shape;
  return {...drag.shape,
    gx:Math.round((mx-first.x-drag.u*(gw*step-6))/step),
    gy:Math.round((my-first.y-drag.v*(gh*step-6))/step)};
}
function gachaEndDrag(mx, my){
  const drag = GACHA.drag;
  GACHA.drag = null;
  if (!drag || !GACHA.open || GACHA.page !== 'setup' || state !== 'play') return;
  if (!gachaDragMoved(drag,mx,my)){
    if (drag.bet) gachaReturnBet(drag.bet);
    else gachaBetItem(drag.item);
    return;
  }
  const target = gachaDragTarget(drag,mx,my);
  if (!target){
    const mine = gachaListGeom().mine;
    if (drag.bet && mx>=mine.x && mx<=mine.x+mine.w && my>=mine.y && my<mine.y+mine.rows*mine.rowH) gachaReturnBet(drag.bet);
    return;
  }
  if (!drag.bet){ gachaBetItem(drag.item,target); return; }
  const plan = gachaMovePlan(drag.bet,target);
  if (plan){ gachaApplyPlan(plan); Object.assign(drag.bet,target); }
}
function gachaReturnBet(bet){
  const i = GACHA.bets.indexOf(bet);
  if (i < 0) return;
  GACHA.bets.splice(i,1);
  gachaGiveBack(bet.c);
}
function gachaRotate(mx, my){
  if (GACHA.page !== 'setup') return;
  const drag = GACHA.drag;
  if (drag){
    if (drag.shape.gw === drag.shape.gh) return;
    drag.shape = gachaFootprint(drag.item,!drag.shape.rot);
    [drag.u,drag.v] = [1-drag.v,drag.u];
    drag.forced = true;
    return;
  }
  const bet = GACHA.bets[gachaHitBet(mx,my)];
  if (!bet || bet.gw === bet.gh) return;
  const target = {...gachaFootprint(bet.c,!bet.rot),gx:bet.gx,gy:bet.gy};
  const plan = gachaMovePlan(bet,target);
  if (plan){ gachaApplyPlan(plan); Object.assign(bet,target); }
  else { GACHA.msg = '这里转不开 · 按住拖到空位再放'; GACHA.msgT = 2; }
}

/* ---------------- 点击 ---------------- */
function gachaClick(mx, my, right, allowDrag = false){
  if (!GACHA.open) return false;
  if (GACHA.drag) return true;
  /* 已经不在局内（死了 / 回放 / 结算）：先把面板收掉，别再抢点击 */
  if (state !== 'play'){ gachaClose(true); return true; }
  const L = gachaListGeom();
  if (mx >= L.close.x && mx <= L.close.x + L.close.w && my >= L.close.y && my <= L.close.y + L.close.h){
    gachaClose(); return true;
  }
  if (GACHA.page === 'spin') return true;
  if (GACHA.page === 'result'){
    /* 右边「再来一把」：回押注页、奖品不变，省掉重新挑奖品的操作 */
    const bw = 96, bh = 36, bx = L.close.x - bw - 12, by = L.close.y;
    if (mx >= bx && mx <= bx + bw && my >= by && my <= by + bh){ GACHA.page = 'setup'; GACHA.msgT = 0; return true; }
    GACHA.page = 'setup'; GACHA.msgT = 0; return true;
  }

  /* 押注格里：取回 */
  const bi = gachaHitBet(mx, my);
  if (bi >= 0){
    const bet = GACHA.bets[bi];
    if (allowDrag && !right) gachaStartDrag(mx,my,bet,bet.c);
    else gachaReturnBet(bet);
    return true;
  }
  /* 奖品 */
  if (mx >= L.prize.x && mx <= L.prize.x + L.prize.w && my >= L.prize.y){
    const i = Math.floor((my - L.prize.y) / L.prize.rowH);
    if (i >= 0 && i < Math.min(L.prize.rows, GACHA_PRIZES.length)){
      const _p = GACHA_PRIZES[i];
      if (_p && gachaRemaining(_p) === 0){ GACHA.msg = '这个奖品已经售罄了'; GACHA.msgT = 2; return true; }
      GACHA.sel = i; return true;
    }
  }
  const item = gachaMineHit(mx,my,L.mine);
  if (item){
    if (allowDrag && !right) gachaStartDrag(mx,my,null,item);
    else gachaBetItem(item);
    return true;
  }
  /* 照上次摆 */
  if (mx >= L.last.x && mx <= L.last.x + L.last.w && my >= L.last.y && my <= L.last.y + L.last.h){
    gachaRestoreLayout(); return true;
  }
  /* 开转 */
  if (mx >= L.spin.x && mx <= L.spin.x + L.spin.w && my >= L.spin.y && my <= L.spin.y + L.spin.h){
    gachaSpinStart(); return true;
  }
  return true;   /* 面板开着时把点击都吃掉，别打到人 */
}

/* ---------------- 商人本体 ---------------- */
function traderSpawn(){
  const _dz = (typeof dzLvl !== 'undefined' && dzLvl) ? dzLvl : null;
  const _tz = (typeof isTestZone === 'function') ? isTestZone() : false;
  if (!_dz && !_tz){ traders.length = 0; return; }
  if (!player) return;
  if (_dz){
    /* 死亡地带：四个角落各摆一个，跑图路上顺路能碰到 */
    const L = _dz;
    if (traders.length === 4 && traders[0]._dz === L) return;
    traders.length = 0;
    /* 角落里各摆一个。pad 必须大于地图边缘的浓雾宽度（12%），
       否则商人站在黑里，玩家根本看不见 —— 之前就是 130 被雾吃掉了。
       再往内挪一点，并且如果落在墙里/房间里就继续往里找。 */
    const pad = Math.max(420, Math.round(Math.min(L.w, L.h) * 0.16));
    const spots = [
      { x: pad,          y: pad },
      { x: L.w - pad,    y: pad },
      { x: pad,          y: L.h - pad },
      { x: L.w - pad,    y: L.h - pad }
    ];
    const clearAt = (x, y) => {
      const r = 34;
      if (x < 80 || y < 80 || x > L.w - 80 || y > L.h - 80) return false;
      if (typeof dzOnLand === 'function' && dzIsland && !dzOnLand(x, y, 20)) return false;
      for (const q of L.walls){
        if (q.dead) continue;
        if (x + r > q.x && x - r < q.x + q.w && y + r > q.y && y - r < q.y + q.h) return false;
      }
      for (const q of (L.brk || [])){
        if (x + r > q.x && x - r < q.x + q.w && y + r > q.y && y - r < q.y + q.h) return false;
      }
      return true;
    };
    for (const sp of spots){
      /* 朝地图中心推，直到找到一块空地（最多 14 步） */
      let bx = sp.x, by = sp.y;
      const cx = L.w / 2, cy = L.h / 2;
      for (let i = 0; i < 14; i++){
        if (clearAt(bx, by)) break;
        bx += (cx - bx) * 0.08;
        by += (cy - by) * 0.08;
      }
      traders.push({
        x: Math.round(bx), y: Math.round(by),
        hp: 600, maxHp: 600, r: 15,
        angry: 0, cd: 0, aim: 0, dead: false, _dz: L
      });
    }
    return;
  }
  /* 测试区：就摆一个在玩家旁边 */
  if (traders.length) return;
  traders.push({
    x: player.x + 190, y: player.y - 30,
    hp: 600, maxHp: 600, r: 15,
    angry: 0, cd: 0, aim: 0, dead: false
  });
}
function traderNear(r){
  if (!player || !traders.length) return null;
  let best = null, bd = (r || 62);
  for (const t of traders){
    if (t.dead) continue;
    const d = Math.hypot(t.x - player.x, t.y - player.y);
    if (d < bd){ bd = d; best = t; }
  }
  return best;
}
function traderRayHit(ax, ay, a, maxT){
  if (!traders.length) return null;
  const dx = Math.cos(a), dy = Math.sin(a);
  let best = null, bt = maxT;
  for (const t of traders){
    if (t.dead) continue;
    const vx = t.x - ax, vy = t.y - ay;
    const tt = vx * dx + vy * dy;
    if (tt <= 0 || tt >= bt) continue;
    const px = ax + dx * tt, py = ay + dy * tt;
    if (Math.hypot(px - t.x, py - t.y) > t.r + 4) continue;
    if (typeof losBlocked === 'function' && losBlocked(ax, ay, t.x, t.y, true)) continue;
    best = t; bt = tt;
  }
  return best ? { e:best, t:bt } : null;
}
function traderHurt(t, dmg){
  if (!t || t.dead) return;
  t.hp -= dmg;
  t.angry = Math.max(t.angry || 0, 9);
  if (typeof spawnPart === 'function') spawnPart(t.x, t.y - 8, 'blood');
  if (typeof hurtNum === 'function') hurtNum(dmg, t.x, t.y - 16);
  if (t.hp <= 0){
    t.dead = true;
    if (typeof setMsg === 'function') setMsg('你把抽奖商人打死了……押注也跟着没了', 2.6);
    return;
  }
  if (typeof setMsg === 'function') setMsg('别打他！抽奖商人会还手', 1.6);
}
function traderShoot(t){
  if (!player || player.hp <= 0 || player.god) return;
  const a = Math.atan2(player.y - t.y, player.x - t.x);
  if (typeof losBlocked === 'function' && losBlocked(t.x, t.y, player.x, player.y, false)) return;
  const dmg = 9;
  const _bdm = (typeof guardDamage === 'function') ? guardDamage(dmg) : dmg;
  player.hp -= (typeof absorbArmor === 'function') ? absorbArmor(_bdm, 'bullet') : _bdm;
  if (typeof hurtNum === 'function') hurtNum(_bdm);
  player.flash = 1; hitFlash = 1; camShake = Math.max(camShake || 0, 0.35);
  if (typeof stOnHurt === 'function') stOnHurt(dmg, 'bullet');
  if (typeof sfxHurt === 'function') sfxHurt();
  /* 弹道火花 */
  if (typeof spawnPart === 'function'){
    for (let i = 1; i <= 6; i++){
      const k = i / 7;
      spawnPart(t.x + (player.x - t.x) * k, t.y + (player.y - t.y) * k, 'spark');
    }
  }
  if (player.hp <= 0 && typeof markDeath === 'function') markDeath('bullet', t, _bdm, a);
}
function traderTick(dt){
  if (!dt || dt <= 0) return;
  /* 离开测试区/死亡地带：押注退回、面板收起，免得转场之后还挂着一个盘 */
  if (GACHA.open && !(typeof dzLvl !== 'undefined' && dzLvl) && (typeof isTestZone !== 'function' || !isTestZone())) gachaClose(true);
  /* 躺着 / 回放 / 结算的时候也不该留着面板（不然死亡页点不动） */
  if (GACHA.open && state !== 'play') gachaClose(true);
  traderSpawn();
  for (const t of traders){
    if (t.dead) continue;
    t.angry = Math.max(0, (t.angry || 0) - dt);
    t.cd = Math.max(0, (t.cd || 0) - dt);
    if (player) t.aim = Math.atan2(player.y - t.y, player.x - t.x);
    /* 站在旁边时偶尔低哼一声，别让摊子像块石头 */
    if (player && typeof sfxTraderHum === 'function'){
      const _d2 = (player.x - t.x) * (player.x - t.x) + (player.y - t.y) * (player.y - t.y);
      /* 第一次凑到跟前：招呼一声（之后靠低哼维持存在感） */
      if (!t.greeted && _d2 < 150 * 150){ t.greeted = 1; if (typeof sfxTraderHi === 'function') sfxTraderHi(1); }
      if (_d2 < 300 * 300){
        t.humT = Math.max(0, (t.humT || 0) - dt);
        if (t.humT <= 0){ sfxTraderHum(); t.humT = 7 + Math.random() * 6; }
      }
    }
    if (t.angry > 0 && player && player.hp > 0 && t.cd <= 0){
      traderShoot(t);
      t.cd = 1.15;
    }
  }
}

/* ---------------- 绘制：商人 ---------------- */
function drawTraders(){
  if (!traders.length || typeof cullPt !== 'function') return;
  const near = traderNear(70);
  for (const t of traders){
    if (!cullPt(t.x, t.y, 100)) continue;
    if (t.dead){
      /* 倒在地上的一小团 */
      ctx.fillStyle = 'rgba(46,90,74,0.55)';
      ctx.beginPath(); ctx.ellipse(t.x, t.y + 4, 14, 7, 0.3, 0, Math.PI * 2); ctx.fill();
      continue;
    }
    ctx.save();
    ctx.translate(t.x, t.y);

    ctx.fillStyle = 'rgba(0,0,0,0.42)';
    ctx.beginPath(); ctx.ellipse(0, 13, 16, 6, 0, 0, Math.PI * 2); ctx.fill();

    /* 中立金圈（生气变红） */
    ctx.strokeStyle = t.angry > 0 ? 'rgba(255,120,90,0.9)' : 'rgba(255,205,90,0.8)';
    ctx.lineWidth = 1.6;
    ctx.setLineDash([5, 5]);
    ctx.beginPath(); ctx.arc(0, 0, 25, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);

    /* 大衣 */
    ctx.fillStyle = '#2f6b57';
    ctx.beginPath();
    ctx.moveTo(-11, 13); ctx.lineTo(-8, -7); ctx.lineTo(8, -7); ctx.lineTo(11, 13);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#245546';
    ctx.beginPath();
    ctx.moveTo(-11, 13); ctx.lineTo(11, 13); ctx.lineTo(9, 5); ctx.lineTo(-9, 5);
    ctx.closePath(); ctx.fill();

    /* 金围巾 + 头 + 礼帽 */
    ctx.fillStyle = '#e8b93f';
    ctx.beginPath(); ctx.ellipse(0, -8, 7.6, 3.2, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#f0d6b4';
    ctx.beginPath(); ctx.arc(0, -14, 6.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#1d2b33';
    ctx.beginPath(); ctx.ellipse(0, -19, 10, 3, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillRect(-5.4, -26, 10.8, 7.4);
    ctx.fillStyle = '#e8b93f';
    ctx.fillRect(-5.4, -20.6, 10.8, 1.7);

    /* 钱袋 */
    ctx.fillStyle = '#c98f3a';
    ctx.beginPath(); ctx.arc(10, 3, 4.8, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#f0c964';
    ctx.beginPath(); ctx.arc(9, 1.5, 1.7, 0, Math.PI * 2); ctx.fill();

    /* 招牌 */
    ctx.fillStyle = 'rgba(8,12,16,0.62)';
    const lw = 76;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(-lw / 2, -51, lw, 16, 5); else ctx.rect(-lw / 2, -51, lw, 16);
    ctx.fill();
    ctx.fillStyle = t.angry > 0 ? '#ff9a86' : '#ffd76a';
    ctx.font = 'bold 11px system-ui, "Microsoft YaHei", sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    if (!window.uiHideAll) ctx.fillText(t.angry > 0 ? '被惹毛了' : '抽奖商人', 0, -43);

    if (near === t && !GACHA.open){
      ctx.fillStyle = 'rgba(8,12,16,0.72)';
      const bw = 124;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(-bw / 2, 24, bw, 18, 6); else ctx.rect(-bw / 2, 24, bw, 18);
      ctx.fill();
      ctx.fillStyle = '#ffe9a8';
      ctx.font = 'bold 11px system-ui, "Microsoft YaHei", sans-serif';
      if (!window.uiHideAll) ctx.fillText('E 抽奖（押东西）', 0, 33);
    }
    ctx.restore();
  }
}

/* ---------------- 绘制：面板 ---------------- */
function gachaFont(px, bold){
  ctx.font = (bold ? 'bold ' : '') + px + 'px system-ui, "Microsoft YaHei", sans-serif';
}
function gachaRR(x, y, w, h, r){
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h);
}
function drawGacha(){
  if (!GACHA.open) return;
  const G = gachaGeom(), L = gachaListGeom();

  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(26,22,18,0.975)';
  ctx.strokeStyle = 'rgba(214,178,106,0.85)';
  ctx.lineWidth = 2;
  gachaRR(G.x, G.y, G.w, G.h, 12); ctx.fill(); ctx.stroke();

  ctx.fillStyle = '#f2d79a'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  gachaFont(20, true);
  ctx.fillText('抽奖商人', G.x + 24, G.y + 34);
  ctx.fillStyle = 'rgba(226,204,166,0.72)'; gachaFont(12, false);
  ctx.fillText('押东西 → 选奖品 → 开转。中了退还押注并拿走奖品；不中押注全没。押注值超过奖品值不会拦你，但多出来的算白搭。', G.x + 120, G.y + 35);

  if (GACHA.page !== 'setup'){
    gachaDrawWheel(G);
    ctx.fillStyle = 'rgba(255,255,255,0.10)';
    ctx.strokeStyle = 'rgba(214,178,106,0.7)'; ctx.lineWidth = 1.4;
    gachaRR(L.close.x, L.close.y, L.close.w, L.close.h, 8); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#e8d3a4'; ctx.textAlign = 'center'; gachaFont(13, true);
    ctx.fillText(GACHA.page === 'result' ? '收下' : '关闭', L.close.x + L.close.w / 2, L.close.y + L.close.h / 2);
    if (GACHA.page === 'result'){
      const bw = 96, bh = 36, bx = L.close.x - bw - 12, by = L.close.y;
      ctx.fillStyle = 'rgba(255,205,90,0.16)';
      ctx.strokeStyle = 'rgba(255,205,90,0.75)'; ctx.lineWidth = 1.4;
      gachaRR(bx, by, bw, bh, 8); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#ffe3a6'; gachaFont(13, true);
      ctx.fillText('再来一把', bx + bw / 2, by + bh / 2);
    }
    return;
  }

  /* 押注格 */
  ctx.fillStyle = 'rgba(232,209,164,0.9)'; ctx.textAlign = 'left'; gachaFont(13, true);
  ctx.fillText('押注（4×3） · 拖动摆放 · R 旋转', G.x + 24, G.y + 66);
  for (let gy = 0; gy < GACHA_GH; gy++)
    for (let gx = 0; gx < GACHA_GW; gx++){
      if (gachaWhereBet(gx, gy) >= 0) continue;
      const r = gachaBetRect(gy * GACHA_GW + gx);
      ctx.fillStyle = 'rgba(255,255,255,0.05)';
      ctx.strokeStyle = 'rgba(214,178,106,0.35)'; ctx.lineWidth = 1;
      gachaRR(r.x, r.y, r.w, r.h, 6); ctx.fill(); ctx.stroke();
    }
  for (const b of GACHA.bets){
    const r = gachaRect(b);
    ctx.fillStyle = 'rgba(255,214,120,0.10)';
    ctx.strokeStyle = 'rgba(255,206,110,0.85)'; ctx.lineWidth = 1.4;
    gachaRR(r.x, r.y, r.w, r.h, 6); ctx.fill(); ctx.stroke();
    bagDrawItemIcon({...b.c, rot:b.rot}, r.x + r.w / 2, r.y + r.h / 2, Math.min(r.w, r.h) - 8);
    if (gachaQ(b.c) > 0 && typeof qualityCol === 'function'){
      ctx.fillStyle = qualityCol(gachaQ(b.c));
      ctx.beginPath(); ctx.arc(r.x + r.w - 6, r.y + 6, 3, 0, Math.PI * 2); ctx.fill();
    }
  }

  /* 概率 */
  const p = gachaChance(), bv = gachaBetValue();
  const prize = GACHA_PRIZES[GACHA.sel];
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(232,209,164,0.9)'; gachaFont(12, false);
  {
    const _capV = prize ? prize.value : 0;
    const _over = Math.max(0, bv - _capV);
    ctx.fillStyle = _over > 0 ? 'rgba(255,170,110,0.95)' : 'rgba(226,232,238,0.92)';
    ctx.fillText('押注值 ' + bv + ' / 奖品值 ' + _capV +
      (_over > 0 ? '　（超出 ' + Math.round(_over * 10) / 10 + ' · 算白搭）' : ''), G.x + 24, G.y + 252);
  }
  ctx.fillStyle = p > 0 ? '#8ef0b0' : 'rgba(200,200,200,0.45)';
  gachaFont(30, true);
  /* 一位小数：45.0% 比 45% 更能看出押注值在动 */
  ctx.fillText(p > 0 ? (p * 100).toFixed(1) + '%' : '—', G.x + 24, G.y + 280);

  if (p > 0){
    /* 拆开写明：基础多少 + 保底加了多少 + 连押加了多少 */
    const _base = gachaChanceRaw() * 100;
    const _add = gachaPityAdd() * 100;
    const _sadd = gachaSameAdd() * 100;
    /* 拆分写在面板下方空白处（左边小牌会压到"你的东西"那一列） */
    ctx.textAlign = 'left';
    ctx.fillStyle = '#ffd76a'; gachaFont(11, true);
    ctx.fillText('押注值占奖品 ' + Math.round((prize ? Math.min(bv, prize.value) / Math.max(1, prize.value) : 0) * 100) + '%' +
                 '　基础 ' + _base.toFixed(1) + '% + 保底 ' + _add.toFixed(1) + '% + 连押 ' + _sadd.toFixed(1) + '%',
                 G.x + 24, G.y + 400);

    const _toNext = Math.max(0, 2 - ((GACHA.pity || 0) % 2));
    /* 防刷规则要说出来：押注值不到奖品 30% 的局不计连输，玩家否则会以为保底坏了 */
    const _ratioNow = prize ? Math.min(bv, prize.value) / Math.max(1, prize.value) : 0;
    if (_ratioNow < 0.3){
      ctx.fillStyle = 'rgba(255,150,120,0.95)'; gachaFont(10, true);
      ctx.fillText('押注值不到奖品的 30%　这一局不算连输保底（防刷）',
                   G.x + 24, G.y + 416);
    } else {
      ctx.fillStyle = 'rgba(232,209,164,0.72)'; gachaFont(10, false);
      ctx.fillText((GACHA.pity ? '已连输 ' + GACHA.pity + ' 次' : '还没连输过') +
                   '　再连输 ' + _toNext + ' 次 保底再 +3%' +
                   (_sadd < 9 ? '　连押同一个再 +3%' : '　连押已满'),
                   G.x + 24, G.y + 416);
    }
  }

  /* 开转 */
  const sp = L.spin, on = p > 0;
  ctx.fillStyle = on ? 'rgba(255,205,90,0.92)' : 'rgba(120,120,120,0.32)';
  gachaRR(sp.x, sp.y, sp.w, sp.h, 10); ctx.fill();
  ctx.fillStyle = on ? '#2a1d08' : 'rgba(230,230,230,0.5)';
  ctx.textAlign = 'center'; gachaFont(18, true);
  ctx.fillText('开 转', sp.x + sp.w / 2, sp.y + sp.h / 2);

  /* 照上次摆：赢了以后押注都退回背包了，一键按上次的摆法摆回来 */
  const lay = GACHA.lastLayout;
  const lp = gachaListGeom().last;
  const canLay = !!(lay && lay.length);
  ctx.fillStyle = canLay ? 'rgba(255,255,255,0.10)' : 'rgba(120,120,120,0.10)';
  ctx.strokeStyle = canLay ? 'rgba(214,178,106,0.7)' : 'rgba(150,150,150,0.35)'; ctx.lineWidth = 1.2;
  gachaRR(lp.x, lp.y, lp.w, lp.h, 8); ctx.fill(); ctx.stroke();
  ctx.fillStyle = canLay ? '#e8d3a4' : 'rgba(200,200,200,0.4)';
  ctx.textAlign = 'center'; gachaFont(13, true);
  ctx.fillText('照上次摆（' + (canLay ? lay.length : 0) + ' 件）', lp.x + lp.w / 2, lp.y + lp.h / 2);

  /* 我的东西 */
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(232,209,164,0.9)'; gachaFont(13, true);
  ctx.fillText('你的东西（点击自动摆放，也可拖入）', L.mine.x, G.y + 66);
  const list = gachaBetTable();
  const off = gachaMineOff(list);
  for (let i = 0; i < Math.min(L.mine.rows, list.length - off); i++){
    const it = list[off + i];
    const ry = L.mine.y + i * L.mine.rowH;
    ctx.fillStyle = (i % 2) ? 'rgba(255,255,255,0.035)' : 'rgba(255,255,255,0.06)';
    gachaRR(L.mine.x, ry + 1, L.mine.w, L.mine.rowH - 3, 6); ctx.fill();
    if (typeof bagDrawItemIcon === 'function') bagDrawItemIcon(it, L.mine.x + 20, ry + L.mine.rowH / 2, (it.k === 'ammo' && it.t === 'rocket') ? 18 : 28);
    ctx.fillStyle = '#efe0c4'; ctx.textAlign = 'left'; gachaFont(13, false);
    const qp = (typeof qualityPrefix === 'function') ? qualityPrefix(gachaQ(it)) : '';
    let lbl = qp + gachaLabel(it);
    if (it.k === 'ammo' && it.n) lbl += ' ×' + it.n;
    ctx.fillText(lbl, L.mine.x + 40, ry + L.mine.rowH / 2 - 5);
    ctx.fillStyle = 'rgba(232,209,164,0.55)'; gachaFont(11, false);
    ctx.fillText('值 ' + gachaCellValue(it), L.mine.x + 40, ry + L.mine.rowH / 2 + 9);
  }
  if (!list.length){
    ctx.fillStyle = 'rgba(220,200,170,0.55)'; gachaFont(12, false);
    ctx.fillText('背包里没东西可押', L.mine.x, L.mine.y + 20);
  }
  /* 列表比可视行多：滚轮翻页 + 右侧一条滚动条 */
  const _maxOff = Math.max(0, list.length - L.mine.rows);
  if (_maxOff > 0){
    const lh = L.mine.rows * L.mine.rowH;
    ctx.fillStyle = 'rgba(255,255,255,0.07)';
    gachaRR(L.mine.x + L.mine.w - 5, L.mine.y, 4, lh, 2); ctx.fill();
    const bh = Math.max(18, lh * (L.mine.rows / list.length));
    const by = L.mine.y + (lh - bh) * (off / _maxOff);
    ctx.fillStyle = 'rgba(255,205,90,0.75)';
    gachaRR(L.mine.x + L.mine.w - 5, by, 4, bh, 2); ctx.fill();
    ctx.fillStyle = 'rgba(232,209,164,0.5)'; ctx.textAlign = 'left'; gachaFont(11, false);
    ctx.fillText('滚轮上下翻（' + (off + 1) + '-' + Math.min(list.length, off + L.mine.rows) + ' / 共 ' + list.length + ' 件）',
      L.mine.x, L.mine.y + lh + 16);
  }

  /* 奖品 */
  ctx.fillStyle = 'rgba(232,209,164,0.9)'; gachaFont(13, true);
  ctx.fillText('想要的奖品', L.prize.x, G.y + 66);
  for (let i = 0; i < Math.min(L.prize.rows, GACHA_PRIZES.length); i++){
    const pz = GACHA_PRIZES[i];
    const ry = L.prize.y + i * L.prize.rowH;
    const sel = i === GACHA.sel;
    ctx.fillStyle = sel ? 'rgba(255,205,90,0.18)' : ((i % 2) ? 'rgba(255,255,255,0.035)' : 'rgba(255,255,255,0.06)');
    gachaRR(L.prize.x, ry + 1, L.prize.w, L.prize.rowH - 3, 6); ctx.fill();
    if (sel){
      ctx.strokeStyle = 'rgba(255,205,90,0.9)'; ctx.lineWidth = 1.5;
      gachaRR(L.prize.x, ry + 1, L.prize.w, L.prize.rowH - 3, 6); ctx.stroke();
    }
    const remaining = gachaRemaining(pz);
    const _sold = remaining === 0;
    /* 重要商品镶金边：这件东西不换会卡住推进（情报），要让人一眼看见 */
    if (pz.gold && !_sold && !sel){
      const _gp = 0.55 + 0.45 * Math.abs(Math.sin((typeof uiT === 'number' ? uiT : 0) * 2.4));
      ctx.save();
      ctx.strokeStyle = 'rgba(255,206,92,' + (0.55 + 0.35 * _gp).toFixed(3) + ')';
      ctx.lineWidth = 2.2;
      ctx.shadowColor = 'rgba(255,190,70,0.75)'; ctx.shadowBlur = 7 * _gp;
      gachaRR(L.prize.x + 1, ry + 2, L.prize.w - 2, L.prize.rowH - 5, 6); ctx.stroke();
      ctx.restore();
    }
    ctx.fillStyle = _sold ? 'rgba(180,170,150,0.5)' : (sel ? '#ffe9a8' : (pz.gold ? '#ffd98a' : '#e8d3a4'));
    ctx.textAlign = 'left'; gachaFont(13, true);
    const _lbl = (pz.gold && !_sold ? '★ ' : '') + pz.label;
    ctx.fillText(_lbl, L.prize.x + 12, ry + L.prize.rowH / 2 - 5);
    /* 金边商品的'重要'跟着标题走，别钉在右边（右边留给长描述会被顶出面板） */
    if (pz.gold && !_sold){
      const _w = ctx.measureText(_lbl).width;
      ctx.fillStyle = 'rgba(255,200,84,0.9)'; ctx.textAlign = 'left'; gachaFont(11, true);
      ctx.fillText('· 重要', L.prize.x + 16 + _w, ry + L.prize.rowH / 2 - 4);
    }
    ctx.fillStyle = 'rgba(226,204,166,0.62)'; gachaFont(11, false);
    ctx.fillText(pz.desc + ' · 值 ' + pz.value +
                 (remaining !== undefined ? ' · 剩 ' + remaining : ''),
                 L.prize.x + 12, ry + L.prize.rowH / 2 + 9);
    if (_sold){
      ctx.fillStyle = 'rgba(255,120,110,0.95)'; ctx.textAlign = 'right'; gachaFont(12, true);
      ctx.fillText('售罄', L.prize.x + L.prize.w - 12, ry + L.prize.rowH / 2 + 1);
    }
  }

  if (GACHA.msgT > 0 && GACHA.msg){
    ctx.fillStyle = 'rgba(255,196,120,0.95)'; ctx.textAlign = 'left'; gachaFont(13, true);
    ctx.fillText(GACHA.msg, G.x + 240, G.y + G.h - 30);
  }

  ctx.fillStyle = 'rgba(255,255,255,0.10)';
  ctx.strokeStyle = 'rgba(214,178,106,0.7)'; ctx.lineWidth = 1.4;
  gachaRR(L.close.x, L.close.y, L.close.w, L.close.h, 8); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#e8d3a4'; ctx.textAlign = 'center'; gachaFont(13, true);
  ctx.fillText('关闭', L.close.x + L.close.w / 2, L.close.y + L.close.h / 2);
  drawGachaDrag();
}

function drawGachaDrag(){
  const drag = GACHA.drag;
  if (!drag || !gachaDragMoved(drag,mouse.x,mouse.y)) return;
  const target = gachaDragTarget(drag,mouse.x,mouse.y);
  const valid = target && gachaMovePlan(drag.bet,target);
  ctx.save();
  if (target && gachaInside(target)){
    const r = gachaRect(target);
    ctx.fillStyle = valid ? 'rgba(110,230,155,0.22)' : 'rgba(255,110,90,0.22)';
    ctx.strokeStyle = valid ? '#8de7a7' : '#ff9b85';
    ctx.lineWidth = 2;
    gachaRR(r.x,r.y,r.w,r.h,6); ctx.fill(); ctx.stroke();
  }
  const {gw,gh,rot} = drag.shape;
  const w = gw*(GACHA_CELL+6)-6, h = gh*(GACHA_CELL+6)-6;
  ctx.globalAlpha = 0.85;
  bagDrawItemIcon({...drag.item,rot},mouse.x+(0.5-drag.u)*w,mouse.y+(0.5-drag.v)*h,Math.min(w,h)-8);
  ctx.restore();
}

function gachaDrawWheel(G){
  const cx = G.x + G.w / 2, cy = G.y + 252, R = 138;
  const TAU = Math.PI * 2;
  const p = Math.max(0, Math.min(1, GACHA.prop || 0));
  const gold = p * TAU;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU);
  ctx.fillStyle = 'rgba(44,52,60,0.96)'; ctx.fill();
  ctx.strokeStyle = 'rgba(20,16,12,0.55)'; ctx.lineWidth = 2; ctx.stroke();

  ctx.save();
  ctx.rotate(GACHA.ang);
  /* 金色弧的长度 = 中奖率，指针停在金色里就中 */
  if (gold > 0.0005){
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, R, 0, gold);
    ctx.closePath();
    ctx.fillStyle = 'rgba(255,205,90,0.95)'; ctx.fill();
    ctx.strokeStyle = 'rgba(255,232,160,0.9)'; ctx.lineWidth = 1.5; ctx.stroke();
  }
  /* 刻度线只是参照，不再是"格子" */
  ctx.strokeStyle = 'rgba(20,16,12,0.42)'; ctx.lineWidth = 1;
  for (let i = 0; i < GACHA.wheel; i++){
    const a = i * TAU / GACHA.wheel;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * R * 0.16, Math.sin(a) * R * 0.16);
    ctx.lineTo(Math.cos(a) * R, Math.sin(a) * R);
    ctx.stroke();
  }
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  if (gold > 0.22){
    ctx.save(); ctx.rotate(gold / 2);
    ctx.fillStyle = '#2a1d08'; gachaFont(15, true);
    ctx.fillText('中', R * 0.66, 0);
    ctx.restore();
  }
  if (TAU - gold > 0.52){
    ctx.save(); ctx.rotate(gold + (TAU - gold) / 2);
    ctx.fillStyle = 'rgba(230,220,200,0.72)'; gachaFont(13, true);
    ctx.fillText('空', R * 0.66, 0);
    ctx.restore();
  }
  ctx.restore();
  ctx.restore();

  /* 指针在正中间：从轴心朝上伸出的一支针，指到哪个扇区就是哪个 */
  const _pc = (GACHA.page === 'result') ? (GACHA.win ? '#7ef0a0' : '#ff8a7a') : '#ffe08a';
  ctx.beginPath();
  ctx.moveTo(cx, cy - R * 0.54);
  ctx.lineTo(cx - 9, cy - 15);
  ctx.lineTo(cx + 9, cy - 15);
  ctx.closePath();
  ctx.fillStyle = _pc;
  ctx.fill();
  ctx.strokeStyle = 'rgba(30,22,14,0.9)'; ctx.lineWidth = 1.5; ctx.stroke();

  /* 轴心压在针尾上 */
  ctx.beginPath(); ctx.arc(cx, cy, 21, 0, Math.PI * 2);
  ctx.fillStyle = '#2c2118'; ctx.fill();
  ctx.strokeStyle = _pc; ctx.lineWidth = 3; ctx.stroke();

  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  if (GACHA.page === 'result'){
    ctx.fillStyle = GACHA.win ? '#7ef0a0' : '#ff8a7a';
    gachaFont(34, true);
    ctx.fillText(GACHA.win ? '中 了' : '没 中', cx, G.y + 74);
    ctx.fillStyle = '#f0e2c6'; gachaFont(14, false);
    ctx.fillText(GACHA.msg || '', cx, cy + R + 30);
    ctx.fillStyle = 'rgba(232,209,164,0.6)'; gachaFont(11, false);
    ctx.fillText('点面板任意处继续', cx, cy + R + 50);
  } else {
    ctx.fillStyle = '#f0e2c6'; gachaFont(13, false);
    ctx.fillText('中奖率 ' + Math.round(p * 100) + '%', cx, G.y + 74);
  }
}
