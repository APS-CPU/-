/* ================= 测试区（开发者） =================
   只在 rules.devTest 的关卡里生效。正式关卡不会走到这里，
   因为它们没有 gun / meds / hp 这些字段。 */
/* ============================================================================
 * UI_STATE —— 界面状态的唯一真相源
 * ----------------------------------------------------------------------------
 * 所有"界面开着没有 / 选了哪个 / 正在拖哪件"都住在这里。
 * 绘制函数只允许读 UI_STATE 与 uiBagViewModel() 的产物，不许自己判断游戏逻辑。
 * 以后加新界面：在下面加一节（如 UI_STATE.map），写个 render 挂进 UI_SCREENS 即可。
 * ========================================================================== */
const UI_STATE = {
  inv:   { open: false, drag: null, gunDrag: null, carry: null, sweep: null, tripTap: null, selUid: 0, hoverUid: 0 },   /* 背包 */
  map:   { open: false },
  panel: { open: false },
  log:   { open: false }
};
const ui = UI_STATE;
let invGeom = null;      /* 背包面板的格子布局，点击就靠它命中 */
let dmgNums = pooledView(DAMAGE_NUMBER_POOL_CAPACITY);
let hurtNums = pooledView(DAMAGE_NUMBER_POOL_CAPACITY);
function spawnDamageNum(x, y, val, kill, crit){
  const d = poolTake(DAMAGE_NUMBER_POOL, dmgNums, hurtNums);
  if (!d) return null;
  d.x=x; d.y=y; d.t=0; d.val=val; d.kill=!!kill; d.crit=!!crit; d.pop=0; d.txt='';
  return d;
}
function spawnHurtNum(x, y, val){
  const d = poolTake(DAMAGE_NUMBER_POOL, hurtNums, dmgNums);
  if (!d) return null;
  d.x=x; d.y=y; d.t=0; d.val=val; d.kill=false; d.crit=false; d.pop=1; d.txt='';
  return d;
}
/* 连续挨打保护：割草模式非简单难度、1~20 波时，1.5 秒内的第二/三/四次挨打依次只吃 70% / 50% / 40% */
let hurtStreakT = 0, hurtStreakN = 0;
const HURT_GUARD_WAVE_MAX = 20;
const HURT_GUARD_WINDOW = 1.5;
const HURT_GUARD_K = [1, 0.70, 0.50, 0.40];
function guardDamage(raw){
  if (!ar) return raw;                       /* 只在割草（波次）模式生效 */
  if (diffName === 'easy') return raw;        /* 简单难度不保护 */
  if ((ar.wave | 0) > HURT_GUARD_WAVE_MAX) return raw;   /* 21 波起保护取消 */
  const n = hurtStreakT > 0 ? hurtStreakN : 0;
  hurtStreakN = Math.min(n + 1, HURT_GUARD_K.length - 1);
  hurtStreakT = HURT_GUARD_WINDOW;
  return raw * HURT_GUARD_K[n];
}                              /* 玩家自己挨的伤害数字（红色，往上飘） */
let tracers = [];       /* 玩家打出去的子弹轨迹 */
/* 曳光弹飞多快：按距离给时长，速度恒定 ≈ TRACER_SPD，
   近处（贴脸一枪）几乎是一闪，远处（720px 打歪）也就 5 帧左右，
   不会像原来固定 0.05s 那样"远的飞得像光、近的像没动"。 */
const TRACER_SPD = 9000;
function tracerDur(x0, y0, x1, y1){
  const d = Math.hypot(x1 - x0, y1 - y0);
  const v = TRACER_SPD * fxRand(0.86, 1.14);           /* 每颗快慢略有差异，别叠成一坨 */
  /* 下限 0.05s：贴脸一枪也得能看见 3 帧，不然 130px 那颗一帧就飞完了 */
  return Math.max(0.050, Math.min(0.110, d / v));
}
let slashFx = [];       /* 刀砍在身上的那一下，黑暗里也要看得见 */
let hurtArcs = [];      /* 从哪个方向挨的打：玩家的屏幕上要能看出来 */

/* 抬手的声音：留一个"他要砍了"的听觉起手（视觉上是把刀举起来） */
function sfxBladeWind(){
  beep(300, 0.16, 'sawtooth', 0.05, 520);
  noiseBurst(0.10, 1500, 0.06, 1.1);
}

/* 挨打：给方向、洒血、留一圈红弧。ang 是"从哪儿打来的"（世界坐标角度） */
function hurtDir(ang, dmg){
  /* 几个人同时砍你的时候，不要满屏都是箭头：
     方向差不多就刷新旧的那一条，数量也只留最新的两条。 */
  for (const h of hurtArcs){
    if (Math.abs(normAng(h.a - ang)) < 0.6){
      h.t = 0; h.a = ang; h.dmg = Math.max(h.dmg | 0, dmg | 0);
      return;
    }
  }
  if (hurtArcs.length > 2) hurtArcs.splice(0, hurtArcs.length - 2);
  for (let i = 0; i < 12; i++)
    spawnPart(player.x, player.y, ang + Math.PI + fxRand(-0.55, 0.55), fxRand(120, 380), fxRand(0.18, 0.42), 'blood', fxRand(2.0, 3.8));
  spawnPart(player.x, player.y, 0, 0, 0.22, 'ring', 17);
}

/* 屏幕空间：玩家脚下一道红弧 + 屏幕边缘一个指向凶手的箭头 */
function drawDeathFade(){
  /* 死了之后一秒里画面逐渐变暗、边缘泛红，别一下子切走 */
  /* 死了之后一直是灰白的：不光那一秒，倒地定格、回放、结算都保持去色，
     UI 是后面才画的，不会跟着变灰。 */
  const _deadNow = !!(player && player.hp <= 0);
  let k = 0;
  if (dyingT > 0) k = 1 - Math.max(0, Math.min(1, dyingT / 1.0));
  else if (_deadNow) k = 1;
  if (k <= 0.001) return;
  ctx.save();
  /* 1) 先把画面抽成灰白（饱和度归零），死了之后眼里就没颜色了 */
  if (typeof ctx.globalCompositeOperation === 'string'){
    ctx.globalCompositeOperation = 'saturation';
    ctx.fillStyle = 'rgba(128,128,128,' + (0.92 * k).toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
    ctx.globalCompositeOperation = 'source-over';
  }
  /* 2) 死的那一下压一层淡淡的暗红；倒地定格之后就不再压了，不然看不清尸体和四周 */
  if (!_deadNow){
    ctx.fillStyle = 'rgba(28,4,6,' + (0.34 * k).toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
    const vg = ctx.createRadialGradient(W/2, H/2, H*0.10, W/2, H/2, H*0.70);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(140,0,10,' + (0.42 * k).toFixed(3) + ')');
    ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
  }
  ctx.restore();
}

/* 刀光：刀手挥出来的一道白弧（世界坐标，画在敌人那一层） */
function drawBladeSwings(){
  for (const e of enemies){
    /* 黑夜里"人看不见"的条件必须和画身体那一处**完全一致**，否则就会出现
       用户 m04267 看到的现象：人整个被黑夜藏起来了，只有一道白弧飘在那里。
       （身体那处的判断在 44-sfxcombat.js 的敌人循环里：nightDark 且没闪电、
         距离超过 nightR+26、又没有同伴共享视野 → 连轮廓都不画。） */
    if (typeof nightDark === 'function' && nightDark() && flashK < 0.18 && player){
      const _nd = dist(e.x, e.y, player.x, player.y);
      const _nr = (cur() && cur().rules && cur().rules.nightR) || 0;
      if (_nd > _nr + 26 && !(typeof companionSharedSees === 'function' && companionSharedSees(e))) continue;
    }
    if (e.trail && e.trail.length){
      for (const _tr of e.trail){
        const _k = _tr.t / _tr.dur;
        ctx.save();
        ctx.globalAlpha = (1 - _k) * 0.34;
        ctx.fillStyle = 'rgba(214,238,255,0.95)';
        ctx.beginPath();
        ctx.arc(_tr.x, _tr.y, e.r * (0.95 - 0.35 * _k), 0, TAU);
        ctx.fill();
        ctx.restore();
      }
    }
    if (!(e.slashT > 0)) continue;
    /* 刀光：沿挥刀方向拖出一道**渐细的尾巴**，而不是一整条等粗的白弧。
       以前是一条从 -1.0 到 +1.0 的等宽弧（最粗 5px），暗关里看着像凭空多出一道
       圆弧（用户 m04267 报的就是这个）。现在：
         · 只从刀锋往后拖 1.55 弧度，越往后越细越淡 —— 读起来是"挥过"不是"一个圈"
         · 半径贴着刀身（e.r + 8），不再比人还大一圈
         · 外圈那条红线删掉（原来像一道划痕）
         · 整条随 slashT 一起收，0.26 秒内消失 */
    const k = e.slashT / 0.26;                 /* 1 → 0 */
    ctx.save();
    ctx.translate(e.x, e.y);
    ctx.lineCap = 'round';
    const _sa = (e.slashA || 0);
    const _R = e.r + 8 + 5 * k;
    const _a0 = _sa - 1.55;                    /* 尾巴 */
    const _a1 = _sa + 0.55;                    /* 刀锋 */
    const _SEG = 8;
    for (let _i = 0; _i < _SEG; _i++){
      const _t0 = _a0 + (_a1 - _a0) * (_i / _SEG);
      const _t1 = _a0 + (_a1 - _a0) * ((_i + 1) / _SEG);
      const _f = _i / (_SEG - 1);              /* 0 = 尾巴, 1 = 刀锋 */
      ctx.globalAlpha = (0.10 + 0.72 * _f * _f) * k;
      ctx.strokeStyle = 'rgba(238,246,255,0.96)';
      ctx.lineWidth = (0.6 + 2.1 * _f) * (0.55 + 0.45 * k);
      ctx.beginPath(); ctx.arc(0, 0, _R, _t0, _t1); ctx.stroke();
    }
    ctx.restore();
  }
}

/* ---------- 打击感（只在测试区的枪上用） ----------
   一枪打实的"手感"是几层叠出来的，缺一层就会觉得是空的：
     定格 → 镜头往弹道方向推 → 目标白闪 → 血渣/火星 → 冲击环 → 伤害数字 → 闷响
   世界定格是里面最贵的一层：几十毫秒不动，大脑立刻认为"这一下真打上了"。 */
let hitStopT = 0;                    /* 世界定格剩余秒数 */
let slowT = 0;                       /* 定格之后的极短慢放 */
let fxParts = pooledView(SPARK_POOL_CAPACITY); /* 血渣 / 火星 / 冲击环 / 白闪 */
/* 火箭弹尾迹：沿飞行路径盖下来的烟团，比粒子活得久、会自己胀开飘散 */
let rocketTrail = [];
let hitMarks = [];                   /* 准星上的命中标记 */
let splats = [];                     /* 溅到屏幕上的血点 */
let fxFlash = 0;                     /* 全屏白闪余量 */
let critFlash = 0;                   /* 暴击的金色闪光余量 */
let zoomP = 0;                       /* 镜头冲击缩放余量 */
let critChance = 0.15;               /* 暴击率（测试里会临时设成 0 或 1） */
const CRIT_MULT = 2.0;               /* 暴击倍率 */
let punchT = 0, punchAX = 1, punchAY = 0;   /* 镜头往弹道方向推的余量 */
let punchAmp = 7;                    /* 这一下的位移幅度：枪越猛越大 */
/* 打中的闷响：一段窄带噪声 + 一个往下掉的低频。短、闷，像打在肉上。
   暴击时把中心频率整体抬高、加长一点尾巴，听起来更"脆"。 */
function sfxHit(killed, crit){
  if (sndPlay('hit.flesh', 0.7)) return;
  if (!actx) return;
  try {
    const t0 = actx.currentTime;
    const hi = crit ? 1.7 : 1;
    const src = actx.createBufferSource(); src.buffer = noiseBuf;
    const bp = actx.createBiquadFilter(); bp.type = 'bandpass';
    bp.frequency.setValueAtTime((killed ? 1000 : 640) * hi, t0);
    bp.frequency.exponentialRampToValueAtTime((killed ? 380 : 260) * hi, t0 + 0.12);
    bp.Q.value = 1.1;
    const g = actx.createGain();
    g.gain.setValueAtTime(crit ? 0.44 : (killed ? 0.50 : 0.30), t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + (killed ? 0.30 : 0.17));
    src.connect(bp); bp.connect(g); g.connect(duckBus());
    src.start(t0); src.stop(t0 + 0.34);
    const o = actx.createOscillator(); const og = actx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(killed ? 190 : 135, t0);
    o.frequency.exponentialRampToValueAtTime(42, t0 + 0.20);
    og.gain.setValueAtTime(killed ? 0.44 : 0.26, t0);
    og.gain.exponentialRampToValueAtTime(0.001, t0 + 0.22);
    o.connect(og); og.connect(duckBus());
    o.start(t0); o.stop(t0 + 0.24);
    /* 一声很短的"咔"：给闷响加个锋利的头，不然只有低频会糊 */
    const o2 = actx.createOscillator(); const og2 = actx.createGain();
    o2.type = 'triangle';
    o2.frequency.setValueAtTime(killed ? 2600 : 2100, t0);
    o2.frequency.exponentialRampToValueAtTime(900, t0 + 0.05);
    og2.gain.setValueAtTime(killed ? 0.16 : 0.11, t0);
    og2.gain.exponentialRampToValueAtTime(0.001, t0 + 0.06);
    o2.connect(og2); og2.connect(duckBus());
    o2.start(t0); o2.stop(t0 + 0.07);
  } catch(e){}
}

/* 暴击的"叮"：两条高频正弦错开几毫秒，像金属被磕了一下，尾巴很短 */
function sfxCrit(){
  if (sndPlay('hit.crit', 0.7)) return;
  if (!actx) return;
  try {
    const t0 = actx.currentTime;
    [1860, 2790].forEach((f, i)=>{
      const o = actx.createOscillator(); const g = actx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(f, t0 + i*0.012);
      o.frequency.exponentialRampToValueAtTime(f*0.62, t0 + i*0.012 + 0.22);
      g.gain.setValueAtTime(0.0001, t0 + i*0.012);
      g.gain.exponentialRampToValueAtTime(i ? 0.06 : 0.11, t0 + i*0.012 + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + i*0.012 + 0.26);
      o.connect(g); g.connect(duckBus());
      o.start(t0 + i*0.012); o.stop(t0 + i*0.012 + 0.30);
    });
  } catch(e){}
}

function spawnPart(x, y, ang, spd, life, kind, size){
  const p = poolTake(SPARK_POOL, fxParts);
  if (!p) return null;
  p.x=x; p.y=y; p.ang=ang; p.spd=spd; p.t=0; p.dur=life; p.kind=kind; p.size=size;
  return p;
}

/* 打在人身上：血渣 + 火星 + 冲击环 + 白闪。暴击再补一圈金色的迸溅 */
function impactFx(x, y, ang, big, rad, isCrit){
  const n = big ? 26 : (isCrit ? 22 : 13);
  /* 血渣：有几颗甩得特别远，静态截图里也能一眼看见"打进去了" */
  for (let i=0;i<n;i++)
    spawnPart(x, y, ang + fxRand(-0.85,0.85), fxRand(170, big ? 560 : 430), fxRand(0.20,0.52), 'blood', fxRand(2.0,4.2));
  for (let i=0;i<(big ? 8 : 5);i++)
    spawnPart(x, y, ang + fxRand(-0.55,0.55), fxRand(520, 880), fxRand(0.24,0.40), 'blood', fxRand(2.4,3.6));
  /* 火星：更快更亮，只活一瞬 */
  for (let i=0;i<(big ? 14 : (isCrit ? 18 : 7));i++)
    spawnPart(x, y, fxRand(0, TAU), fxRand(230, 560), fxRand(0.08,0.20), isCrit ? 'gold' : 'spark', fxRand(1.3,2.6));
  spawnPart(x, y, 0, 0, big ? 0.40 : (isCrit ? 0.34 : 0.24), 'ring', big ? 30 : (isCrit ? 26 : 17));
  spawnPart(x, y, 0, 0, big ? 0.30 : (isCrit ? 0.26 : 0.16), 'flash', (rad||12)*1.5);
  if (isCrit){
    /* 六道金色放射线，像"打穿了" */
    spawnPart(x, y, ang, 0, 0.34, 'critstar', 34);
  }
}

/* BOSS 级爆炸：三层冲击环 + 一团闪光 + 大量火星/尘土/血渣，屏幕还要抖一下 */
function bossBlastFx(x, y, R, screenFeedback=true){
  for (let i = 0; i < 3; i++)
    spawnPart(x, y, 0, 0, 0.52 + i*0.14, 'ring', R * (0.55 + i*0.34));
  spawnPart(x, y, 0, 0, 0.34, 'flash', R * 0.85);
  for (let i = 0; i < 44; i++)
    spawnPart(x, y, fxRand(0, TAU), fxRand(260, 780), fxRand(0.22, 0.55), 'spark', fxRand(2.0, 4.0));
  for (let i = 0; i < 26; i++)
    spawnPart(x, y, fxRand(0, TAU), fxRand(110, 520), fxRand(0.40, 0.95), 'dust', fxRand(3, 7.5));
  for (let i = 0; i < 16; i++)
    spawnPart(x, y, fxRand(0, TAU), fxRand(200, 700), fxRand(0.30, 0.70), 'blood', fxRand(2.5, 5));
  if(screenFeedback){
    fxFlash = Math.max(fxFlash, 0.85);
    camShake = Math.max(camShake, 1.15);
  }
}

/* 打在墙上：一小撮灰，别让打空变成"什么都没发生" */
/* ---------- 掩体材质：同一枪打在铁皮和土墙上，出来的东西必须是两回事 ---------- */
function wallMat(w){ return (w && w.mat) || 'stone'; }
/* 找命中的是哪一块墙 */
function wallAtPoint(x, y){
  const L = cur(); if (!L || !L.walls) return null;
  for (const w of L.walls){
    if (w.dead) continue;
    if (x >= w.x - 2 && x <= w.x + w.w + 2 && y >= w.y - 2 && y <= w.y + w.h + 2) return w;
  }
  return null;
}
function impactWallFx(x, y, ang){
  /* 子弹打在玩家身边（掩体边缘/脚边墙）时给一点"贴着耳朵过"的压力：
     轻微镜头抖 + 一瞬间视野收窄。只在人机开火的关卡、且不是自己打的才触发。 */
  if (typeof player !== 'undefined' && player && (typeof humanOn !== 'function' || humanOn(cur()))){
    const _d = dist(x, y, player.x, player.y);
    if (_d < 86 && _d > 4){
      const _k = 1 - _d / 86;
      if (typeof camShake === 'function') camShake(2.2 * _k);
      player.nearHitT = Math.max(player.nearHitT || 0, 0.18);
      player.nearHitK = Math.max(player.nearHitK || 0, _k * 0.55);
    }
  }
  const w = wallAtPoint(x, y);
  const mat = wallMat(w);
  if (mat === 'metal'){
    for (let i = 0; i < 13; i++){
      const a = ang + Math.PI + fxRand(-1.15, 1.15);
      spawnPart(x, y, a, fxRand(240, 760), fxRand(0.10, 0.30), 'mspark', fxRand(1.1, 2.6));
    }
    spawnPart(x, y, 0, 0, 0.10, 'flash', 7);
    spawnPart(x, y, 0, 0, 0.20, 'ring', 10);
    hotMarks.push({x:x, y:y, t:0, dur:2.2});
    sfxMetalHit(x, y);
  } else {
    for (let i = 0; i < 9; i++)
      spawnPart(x, y, ang + Math.PI + fxRand(-0.85,0.85), fxRand(45,185), fxRand(0.14,0.34), 'dust', fxRand(1.6,3.1));
    for (let i = 0; i < 3; i++)
      spawnPart(x, y, ang + Math.PI + fxRand(-0.9,0.9), fxRand(70,190), fxRand(0.18,0.36), 'chip', fxRand(1.0,2.0));
    spawnPart(x, y, ang, 0, 0.42, 'smoke', 9);
    spawnPart(x, y, 0, 0, 0.13, 'ring', 7);
    sfxDirtHit(x, y);
  }
}

/* 一次命中的全部反馈。三档，别什么都是一套：
   普通命中 —— 只有一点点震和手感的推，不慢放、不白闪、不缩放。打十枪不该被慢十次。
   暴击     —— 金字、金色迸溅、一声金属"叮"，短定格，轻微推镜。
   击杀     —— 重的一下：定格 + 慢放 + 屏幕血点 + 白闪。 */
function registerHit(e, ang, dmg, killed, crit, source=player){
  e._lodUrgentUntil=timeAlive+1;
  const hx = e.x - Math.cos(ang)*(e.r||10)*0.4;
  const hy = e.y - Math.sin(ang)*(e.r||10)*0.4;
  const tier = killed ? 2 : (crit ? 1 : 0);
  /* 活人感：探头摸到一枪，下意识就是缩回去 */
  if (!killed && (!e.structureEngaged || source !== e.structureEngaged) && behaviorOf(e).flinchOnHit && humanOn(cur()) && eStatusHas(e, 'fear')){
    /* 吓破胆：立刻中断开枪、缩回掩体、把朵避时间重新刷满 */
    e.tucked = true; e.peekPhase = 'tuck';
    e.peekT = Math.max(e.peekT || 0, HUMAN.scareT * reactK(e));
    e.fireCd = Math.max(e.fireCd || 0, 0.55);
    e.feinted = true;
    eStatusSet(e, 'fear', HUMAN.fearDur * 0.85);
    voiceSay(e, 'hurt', 0.6, 3);          /* 中枪那一下的痛呼 */
  }
  impactFx(hx, hy, ang, tier === 2, e.r || 12, tier === 1);
  if(typeof mobaSuppressCombatFeedback==='function' && mobaSuppressCombatFeedback(source))return;
  hitMarks.push({t:0, dur: killed ? 0.42 : (crit ? 0.32 : 0.20), kill:!!killed, crit:!!crit});

  if (tier === 2){
    for (let i=0;i<5;i++){
      splats.push({x: fxRand(W*0.07, W*0.93), y: fxRand(H*0.07, H*0.93), r: fxRand(10, 22),
                   t:0, dur: fxRand(0.5, 0.85), rot: fxRand(0,TAU)});
    }
    fxFlash = Math.max(fxFlash, 0.85);
    slowT = Math.max(slowT, 0.22);
    hitStopT = Math.max(hitStopT, 0.17);
    zoomP = Math.max(zoomP, 1.0);
    camShake = Math.max(camShake, 1.0);
    punchT = 0.26; punchAmp = 12;
  } else if (tier === 1){
    fxFlash = Math.max(fxFlash, 0.30);        /* 金色的一下闪光 */
    critFlash = Math.max(critFlash, 1);
    slowT = Math.max(slowT, 0.055);
    hitStopT = Math.max(hitStopT, 0.05);
    zoomP = Math.max(zoomP, 0.55);
    /* 暴击叠到一半以上之后几乎每一枪都是暴击，再用 0.42 就是一直在抖 */
    const _critShake = Math.max(0.10, 0.42 - (ar ? Math.min(0.30, (ar.crit || 0) * 0.75) : 0));
    camShake = Math.max(camShake, _critShake);
    punchT = 0.20; punchAmp = 9;
  } else {
    /* 普通命中：只留"手感"，别的全关掉 */
    hitStopT = 0;
    zoomP = Math.max(zoomP, 0.10);
    camShake = Math.max(camShake, 0.13);
    punchT = 0.12; punchAmp = 4;
  }
  /* 战斗，爽！！：一局要打死几百个，每杀一个都定格 0.17 秒就等于走不动路。
     所以普通杀只留震屏和血点；但**射掉一波的最后一个**要重重地定一下 —— 那是一波的句号。 */
  if (ar){
    const waveClear = killed && (ar.spawnLeft || 0) <= 0 && enemies.length <= 1;
    if (waveClear){
      /* 命中那一瞬间直接定格（0.5 秒），不慢放 */
      hitStopT = Math.max(hitStopT, 0.9);
    if (ar) ar.shotAng = ang;
      slowT = 0;
      zoomP = Math.max(zoomP, 0.55);
      camShake = Math.max(camShake, 0.9);
      fxFlash = Math.max(fxFlash, 0.5);
    } else {
      hitStopT = Math.min(hitStopT, killed ? 0.045 : 0.02);
      slowT = 0;
      zoomP = Math.min(zoomP, 0.35);
    }
  }
  punchAX = Math.cos(ang); punchAY = Math.sin(ang);

  if (tier !== 2 && e.r){
    /* 被打得往后一顿：配上火星才看得出来是"被推了一下" */
    /* BOSS 压根量大：同样的子弹打在小兵身上能推开，打在 BOSS 身上只能让它晃一下。
       （疯狗就是被这个“每枪 4px”硬生生顶住的：手枪一秒六枪就是 24px/s，加上它自己那 10px 就跑不到人跟前） */
    const push = (tier === 1 ? 9 : 4) * (e.boss ? 0.35 : 1);
    e.x += Math.cos(ang)*push; e.y += Math.sin(ang)*push;
    const L = cur();
    if (L && L.walls) for (const w of collisionWalls(L,e.x,e.y,e.r)) pushOutCircle(e, e.r, w);
    for (const t of trucks) if (t.solid) pushOutTruckCircle(e, t);
  }
  sfxHit(!!killed, !!crit);
  if (tier === 1) sfxCrit();
}

function trimFx(){

  /* 旧画面上限仍保留；回收改用 swap-pop，避免高峰时 splice 搬移数组。 */
  while (fxParts.length > 240) poolReleaseAt(fxParts, 0);

  if (tracers.length > 48) tracers.splice(0, tracers.length - 48);

}



function updateImpactFx(dt){
  if (punchT > 0) punchT = Math.max(0, punchT - dt);
  if (fxFlash > 0) fxFlash = Math.max(0, fxFlash - dt*4.2);
  if (critFlash > 0) critFlash = Math.max(0, critFlash - dt*7.5);
  if (zoomP > 0) zoomP = Math.max(0, zoomP - dt*6.5);
  for (let i=splats.length-1;i>=0;i--){
    splats[i].t += dt;
    if (splats[i].t >= splats[i].dur) splats.splice(i,1);
  }
  if (typeof devFrozen === "function" && devFrozen()) return;
  updateWreckFx(dt);
  updateAsh(dt);
  for (let i=fxParts.length-1;i>=0;i--){
    const p = fxParts[i];
    p.t += dt;
    if (p.t >= p.dur){ poolReleaseAt(fxParts, i); continue; }
    if (p.kind === 'ring' || p.kind === 'flash') continue;
    const k = Math.max(0, 1 - p.t/p.dur);
    const sp = p.spd * (0.2 + 0.8*k);
    p.x += Math.cos(p.ang)*sp*dt;
    p.y += Math.sin(p.ang)*sp*dt;
    if (p.kind === 'blood') p.y += 260*dt*dt;       /* 一点点下坠 */
  }
  for (let i=hitMarks.length-1;i>=0;i--){
    hitMarks[i].t += dt;
    if (hitMarks[i].t >= hitMarks[i].dur) hitMarks.splice(i,1);
  }
  trimFx();
}

/* ---- glow sprite cache (perf) ----
   each particle used to createRadialGradient every frame, each tracer used shadowBlur;
   a shotgun burst + several enemies firing in one frame meant dozens of blurs -> fps crash.
   bake the gradient once into a canvas, then just drawImage. */
var _glowCache = Object.create(null);