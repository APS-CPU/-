
function setMsg(t, dur){ msg = t; msgT = dur || 2.2; }

/* 普通敌人移动是逐敌逐帧热路径；复用请求对象，避免 facade 结构化参数制造 GC。 */
const _ENEMY_MOVE_REQUEST = {angle:0, dt:0, step:0};

/* ---------------- 更新 ---------------- */
/* 刀手的前突/撤离也走碰撞；细分高速位移，不能一步穿过薄墙。 */
/* 刀刃的阻挡只看实际墙体（包括玻璃），不能套用人物行走的膨胀半径。 */
function bladeStrikeClear(L, e, target){
  const t=target||player;
  for (const w of L.walls) if (segHitsRect(e.x,e.y,t.x,t.y,w)) return false;
  for (const d of doors) if (doorSolid(d) && segHitsRect(e.x,e.y,t.x,t.y,d)) return false;
  return true;
}

function bladeMove(L, e, a, distance, radius=groundSqueezeRadius(L,e)??e.r){
  const _step = (ang) => {
    const steps = Math.max(1, Math.ceil(distance / 6));
    for (let i = 0; i < steps; i++){
      e.x += Math.cos(ang) * distance / steps;
      e.y += Math.sin(ang) * distance / steps;
      for (const w of collisionWalls(L,e.x,e.y,radius)) pushOutCircle(e, radius, w);
      for (const t of trucks) if (t.solid) pushOutTruckCircle(e, t);
      /* 门正在为它开的时候别再拿整块门框把人顶出去：那会形成
         "靠近 → 门开 → 被推出去 → 门又关" 的拉锯，永远过不了门槛 */
      for (const d of doors) if (doorSolid(d) && !((d.enemyHold || 0) > 0 && (d.open || 0) > 0.12)) pushOutCircle(e, radius, d);
      e.x = clamp(e.x, radius + 2, L.w - radius - 2);
      e.y = clamp(e.y, radius + 2, L.h - radius - 2);
    }
  };
  const ox = e.x, oy = e.y;
  _step(a);
  let moved = dist(ox, oy, e.x, e.y);
  /* 撞在柱子拐角 / 墙角上时，直着走会被 pushOut 一帧一帧顶回来，
     看起来就是贴着墙角抽搐。这里补一次"沿墙滑"：挪不动就试试切向。 */
  if (moved < distance * 0.55){
    const bx = e.x, by = e.y;
    let bestX = bx, bestY = by, bestMoved = moved;
    for (const off of [0.55, -0.55, 1.0, -1.0, 1.4, -1.4]){
      e.x = ox; e.y = oy;
      _step(a + off);
      const m = dist(ox, oy, e.x, e.y);
      if (m > bestMoved + 0.4){ bestMoved = m; bestX = e.x; bestY = e.y; break; }
    }
    e.x = bestX; e.y = bestY;
    moved = bestMoved;
  }
  return moved;
}

const _BLADE_RETREAT_PATH_START={x:0,y:0}, _BLADE_RETREAT_PATH_GOAL={x:0,y:0};
/* 一次选定可达掩体，沿前突方向优先；到达/受阻才重选，避免逐帧左右摇摆。 */
function bladeRetreatGoal(L, e, speed){
  const forward = e.lungeA === undefined ? e.ang : e.lungeA;
  const pad = e.r + 20, candidates = [];
  for (const w of L.walls){
    if (w.glass) continue;
    const xs = [w.x-pad, w.x+w.w/2, w.x+w.w+pad];
    const ys = [w.y-pad, w.y+w.h/2, w.y+w.h+pad];
    for (let ix=0;ix<3;ix++) for (let iy=0;iy<3;iy++){
      if (ix===1 && iy===1) continue;
      const x=xs[ix], y=ys[iy], d=dist(e.x,e.y,x,y);
      if (d<12 || d>500 || x<20 || y<20 || x>L.w-20 || y>L.h-20) continue;
      if (dist(x,y,player.x,player.y)<110 || !losBlocked(player.x,player.y,x,y)) continue;
      if (L.walls.some(w2 => x>w2.x-pad/2 && x<w2.x+w2.w+pad/2 && y>w2.y-pad/2 && y<w2.y+w2.h+pad/2)) continue;
      const align = Math.cos(Math.atan2(y-e.y,x-e.x)-forward);
      candidates.push({x,y,score:d-align*120});
    }
  }
  candidates.sort((a,b)=>a.score-b.score);
  _BLADE_RETREAT_PATH_START.x=e.x;_BLADE_RETREAT_PATH_START.y=e.y;
  for (const c of candidates){
    _BLADE_RETREAT_PATH_GOAL.x=c.x;_BLADE_RETREAT_PATH_GOAL.y=c.y;
    const path = NavQuery.findPath(L,_BLADE_RETREAT_PATH_START,_BLADE_RETREAT_PATH_GOAL);
    if (!path || !path.length) continue;
    const first = path.find(p=>dist(e.x,e.y,p[0],p[1])>10) || path[path.length-1];
    if (Math.cos(Math.atan2(first[1]-e.y,first[0]-e.x)-forward)<-0.15) continue;
    return {x:c.x,y:c.y};
  }
  /* 没有可达掩体就沿空旷方向拉开距离；墙挡前方时允许侧向绕开。 */
  let best={x:e.x,y:e.y}, score=-Infinity;
  const reach = Math.max(100, speed * (e.recoverT || 0) + 60);
  for (const offset of [0,0.45,-0.45,0.9,-0.9,1.5,-1.5,2.2,-2.2,Math.PI]){
    const a=forward+offset, len=Math.max(0,freeLen(L,e.x,e.y,a,reach,e.r+2)-8);
    const x=clamp(e.x+Math.cos(a)*len,20,L.w-20), y=clamp(e.y+Math.sin(a)*len,20,L.h-20);
    const d=dist(e.x,e.y,x,y);
    const sc=d+Math.cos(offset)*90+dist(x,y,player.x,player.y)*0.4;
    if (d>12 && sc>score){ score=sc;best={x,y}; }
  }
  return best;
}

/* ---------------- 手动拾取 ----------------
   以前走进 30px 就自动收下，于是"把背包里的东西丢到地上"会在一瞬间被自己重新捡回去。
   现在只有两条路：鼠标点地上那件，或者按 E 捡脚边最近的一件。 */
const LOOT_REACH = 34;
/* 自动拾取只收这些：消耗品。枪 / 甲 / 包 / 盾要玩家自己点，免得走两步枪就换了 */
const AUTO_PICK_KINDS = { med:1, ammo:1, smoke:1 };
function lootPickable(l){
  if (!l || l.taken || l.cool > 0) return false;
  if (state !== 'play' || !player || player.hp <= 0) return false;
  return dist(player.x, player.y, l.x, l.y) <= LOOT_REACH;
}
function lootUnderPoint(x, y){
  /* 传进来的是屏幕坐标（mouse.x/y），库存在世界坐标里 —— 必须先加相机偏移，
     否则永远点不中，点击就会往下走去开枪。 */
  const wx = x + cam.x, wy = y + cam.y;
  let best = null, bd = 1e9;
  for (const l of loots){
    if (!lootPickable(l)) continue;
    const d = dist(wx, wy, l.x, l.y);
    if (d < 26 && d < bd){ bd = d; best = l; }
  }
  return best;
}
function pickNearestLoot(){
  let best = null, bd = 1e9;
  for (const l of loots){
    if (!lootPickable(l)) continue;
    const d = dist(player.x, player.y, l.x, l.y);
    if (d < bd){ bd = d; best = l; }
  }
  if (!best){ setMsg('附近没有可以捡的东西', 1.2); return false; }
  return pickLoot(best);
}
/* 往地上放东西时，自动躲开脚边已经有的掉落物：
   现在的道具越来越多，全叠在一个点上眼睛就糊了。按同心圆找最近的空位。 */
function lootSpot(x, y){
  if (typeof loots === 'undefined' || !loots) return { x:x, y:y };
  const busy = (px, py) => {
    for (const l of loots){
      if (l.taken) continue;
      const dx = l.x - px, dy = l.y - py;
      if (dx * dx + dy * dy < 24 * 24) return true;
    }
    return false;
  };
  if (!busy(x, y)) return { x:x, y:y };
  for (let ring = 1; ring <= 6; ring++){
    const rad = ring * 24, n = 6 + ring * 2;
    for (let i = 0; i < n; i++){
      const a = (i / n) * Math.PI * 2 + ring * 0.7;
      const px = x + Math.cos(a) * rad, py = y + Math.sin(a) * rad;
      if (!busy(px, py)) return { x:px, y:py };
    }
  }
  return { x:x, y:y };
}
function pickLoot(l){
  if (!lootPickable(l)) return false;
  const L = cur();
  /* 背包类（弹药/枪/药/甲）由 LOOT_KINDS 决定怎么收。take() 说"收不了"时
     东西必须留在地上 —— 以前这里接着往下走把 l.taken 标成 true，
     于是"捡第二件防弹衣"看着像被吞了。 */
  qualityRollFor(l, l.qBias || 0);       /* 先定品质：捡到提示、数值浮动都读它 */
  const KS = LOOT_KINDS[l.kind];
  if (KS && KS.take){
    if (KS.take(l)){ l.taken = true; /* 金条是拿去换钱的货，不算撤离物资 */
      if (!l.killDrop && !l.gear && l.kind !== 'attach' && l.kind !== 'rare') player.loot++; return true; }
    if (hasFeat('loot')){ l.cool = 0.6; return false; }
  }
  l.taken = true; if (!l.killDrop) player.loot++; sfxPick();
  logInfo('loot', '捡到物资 ' + player.loot + ' / ' + lootTotal);
  /* 教程关：摄像头正看着你的时候拿走，就是"把整栋楼的人都叫来" */
  if (L && L.rules && L.rules.tutorial){
    const cam = enemies.find(e => enemyType(e).static);
    if (cam && enemySees(cam, concealed)){
      tutorialHorde(L);            /* 只叫一次；摄像头那边可能已经叫过了 */
    } else {
      setMsg('好，就这么办 —— 趁着烟没散，走', 2.2);
      logInfo('tutorial', '在摄像头看不见的时候拿到了物资 · 教科书做法');
    }
  } else setMsg('拿到第 ' + player.loot + ' 件货', 1.6);
  return true;
}

/* 可选协同层。只由 canFlank:true 的入口调用；状态不保存对象互相引用，兼容快照。 */
let flankActorSeq = 0, flankPairSeq = 0, flankPlanAfter = 0;
function tacticTargetAlive(t){
  return !!t&&!t.dead&&!t.gone&&(t.hp===undefined||t.hp>0);
}
function tacticTargetId(t){
  if(!t)return null;
  if(t===player)return 'player';
  return (typeof combatId==='function')?combatId(t):(t.id||null);
}
function tacticTargetById(id){
  if(!id)return null;
  if(id==='player')return tacticTargetAlive(player)?player:null;
  for(const o of enemies)if(o&&tacticTargetId(o)===id&&tacticTargetAlive(o))return o;
  for(const o of allies)if(o&&tacticTargetId(o)===id&&tacticTargetAlive(o))return o;
  return null;
}
/* 看见、听见、受击记忆都能给协同提供目标；不再假设目标永远是玩家。 */
function flankTargetOf(e){
  let t=(typeof enemyTargetEntity==='function')?enemyTargetEntity(e):null;
  if(tacticTargetAlive(t)&&factionWantsFight(e,t))return t;
  for(const q of [e.lastKnownSource,e.heardSource])
    if(tacticTargetAlive(q)&&factionWantsFight(e,q))return q;
  return e.flank?tacticTargetById(e.flank.targetId):null;
}
function flankReady(e){
  const t = enemyType(e);
  return !e.dead && !e._dying && e.hp > 0 && !e.boss && !t.static && !t.fly && t.canShoot &&
    t.kind !== 'blade' && !weaponCore(e.wid).rocket && !weaponCore(e.wid).melee &&
    !enemyLowHp(e) && !e.fleeing && !eStatusHas(e,'stun') && !eStatusHas(e,'fear') &&
    !eStatusHas(e,'hurt') && !eStatusHas(e,'suppress') && !e.bound && !(e.boundHold>0);
}
function flankEnd(e, reason){
  const state = e.flank;
  if (!state) return;
  for (const o of enemies){
    if (!o.flank || o.flank.pair !== state.pair) continue;
    if(o.suppressOwner==='flank'){eStatusClear(o,'suppress');o.suppressOwner=null;o.suppressPoints=null;}
    o.flank = null; o.flankRetryAt = uiT + DataFLANK.retryDelay; o.flankResult = reason;
    o.path = null; o.goal = null; o.bladeNavPath = null; o.chk = null; o.stuckT = 0;
  }
  // 也允许清理已经从 enemies 移除的调用者。
  if(e.suppressOwner==='flank'){eStatusClear(e,'suppress');e.suppressOwner=null;e.suppressPoints=null;}
  e.flank = null; e.flankRetryAt = uiT + DataFLANK.retryDelay; e.flankResult = reason;
}
function flankWalk(L, radius, x1, y1, x2, y2){
  return bladeWalkLine(L,radius,x1,y1,x2,y2);
}
/* m44631：敌人也**能听见脚步**（以前只有玩家脚下有声音，敌人只画声纹，
   所以"精英/火箭筒兵走路没声"其实是所有敌人都没声）。
   响度 = 距离衰减 × 该兵种 stepLoud × 负重（重甲/扛筒的踩得更沉）。
   返回实际音量，方便测试；0 表示不该出声。 */
const ENEMY_STEP_R = 720;
/* 所有"敌人脚步/动静"声纹都从这里入队，密度由 data/ai.js 的 DataSfxFoot 控制，
   不要在别处直接 enemySteps.push（否则又会各自堆回满屏圈）。 */
function pushEnemyStep(x, y, hot, big, e){
  const D = (typeof DataSfxFoot !== 'undefined') ? DataSfxFoot : null;
  if (D && D.on === false) return;
  const cap = (D && D.maxAlive) || 6;
  const jit = (D && D.jitter) || 4;
  /* 同一个兵不要每一步都留印：声纹是"刚才有人在这"的延迟线索，
     不是实时雷达。间隔由 DataSfxFoot.gap 控制。 */
  if (!big && e){
    const gap = (D && D.gap) || 1.15;
    const now = (typeof uiT !== 'undefined') ? uiT : 0;
    if (e._ripAt !== undefined && (now - e._ripAt) < gap) return;
    e._ripAt = now;
  }
  if (!big && enemySteps.length >= cap) enemySteps.splice(0, enemySteps.length - cap + 1);
  enemySteps.push({
    x: x + fxRand(-jit, jit), y: y + fxRand(-jit, jit), t: 0,
    life: big ? ((D && D.bigLife) || 1.9) : ((D && D.life) || 1.55),
    hot: !!hot, big: !!big
  });
}

/* m32149：脚步音效预算。硬核一局 380 个人，几十个人同时踩会把 WebAudio 灌成
   『密集的颗粒噪音』（每踩一下就新建一组 buffer/filter/gain），人多时又吵又费 CPU。
   这里每 0.1 秒最多放 3 声，多的直接丢 —— 只影响听得到的音频，
   画面声纹（玩家的信息）和 AI 听觉逻辑一律照旧。 */
let _stepSfxWin = -1, _stepSfxN = 0;
function stepSfxAllow(){
  if (!audioRateLimit) return true;
  const t = ((typeof performance !== 'undefined' ? performance.now() : Date.now())) * 0.001;
  if (_stepSfxWin < 0 || t - _stepSfxWin > 0.1){ _stepSfxWin = t; _stepSfxN = 0; }
  if (_stepSfxN >= 3) return false;
  _stepSfxN++;
  return true;
}
function sfxEnemyStep(e){
  if (!e || typeof player === 'undefined' || !player) return 0;
  const T = (typeof enemyType === 'function') ? enemyType(e) : null;
  const loud = (T && T.stepLoud !== undefined) ? T.stepLoud : 1;
  if (!(loud > 0)) return 0;                       /* 固定哨/无人机这类不出声 */
  const R = (typeof maskedHearR === 'function') ? maskedHearR(ENEMY_STEP_R) : ENEMY_STEP_R;
  const d = Math.hypot(e.x - player.x, e.y - player.y);
  if (!(d < R)) return 0;
  const k = 1 - d / R;                              /* 0..1，越近越响 */
  const _ty = e.ty || '';
  /* 重装/扛筒的踩得更沉：1.6 倍是为了让"精英甲 + 70% 静音"之后仍然比普通兵响，
     否则听觉上还是"精英走路没声"。 */
  const heavy = (_ty === 'rocketman' || _ty === 'guard' || _ty === 'spec' ||
                 e.armorKind === 'elite' || (T && T.armorKind === 'elite')) ? 1.6 : 1;
  const vol = (0.020 + 0.052 * k * k) * loud * heavy;
  /* 扛筒的脚步更闷（低通更低），听起来就是"重物 + 金属" */
  audioDiagCount('step');
  if (stepSfxAllow() && typeof sfxStep === 'function') sfxStep(vol, _ty === 'rocketman' ? 240 : 330, true);
  else audioDiagBlock('脚步窗口', _ty, d);
  return vol;
}
/* 包抄也是"走"，也该漏出声纹。正常移动的脚步声写在 update 的通用分支里，
   而 flankTick 成功时是 continue 掉的 —— 不在这里补一发，侧翼那两个人就是无声幽灵。 */
function flankSteps(L, e, dt){
  e.stepT = (e.stepT || 0) - dt;
  if (e.stepT > 0) return;
  e.stepT = e.mode === 1 ? 0.32 : 0.48;
  if(typeof factionHearStep==='function')factionHearStep(e,e.x,e.y);
  if (typeof sfxEnemyStep === 'function') sfxEnemyStep(e);
  if (footstepMode(L) === 0) return;
  const hid = (e.visA === undefined) ? true : (e.visA < 0.5);
  if ((footstepMode(L) === 1 || hid) && dist(e.x, e.y, player.x, player.y) < maskedHearR(CFG.hearR * 1.7)){
    pushEnemyStep(e.x, e.y, e.mode === 1, false, e);
  }
}
const _FLANK_PATH_START={x:0,y:0}, _FLANK_PATH_GOAL={x:0,y:0};
const _FLANK_PATH_OPTIONS={walkClear:null,navOverride:null};
/* 算某一名成员前往一个攻击位的完整路线。路线不能穿过目标脚下，也只有终点
   能直视目标才算有效；这样“到位”表示真的形成了一条射线，而不是只站到坐标。 */
function flankPathTo(L, actor, tx, ty, x, y){
  /* 下车点不是攻击位。即便车门口刚好有射界，也必须先离开车身周围再布交叉火力，
     否则第一个人会把出生坐标当“已就位”，四个人继续堵在车旁。 */
  if(actor.fromTruck&&Number.isFinite(actor.deployX)&&Number.isFinite(actor.deployY)&&
      dist(x,y,actor.deployX,actor.deployY)<60)return null;
  if(!flankWalk(L,actor.r,x,y,x,y)||losBlocked(x,y,tx,ty))return null;
  const walk=(map,x1,y1,x2,y2)=>{
    if(!flankWalk(map,actor.r,x1,y1,x2,y2))return false;
    const dx=x2-x1,dy=y2-y1,dd=dx*dx+dy*dy;
    const k=dd?clamp(((tx-x1)*dx+(ty-y1)*dy)/dd,0,1):0;
    return dist(x1+dx*k,y1+dy*k,tx,ty)>=100;
  };
  _FLANK_PATH_START.x=actor.x;_FLANK_PATH_START.y=actor.y;
  _FLANK_PATH_GOAL.x=x;_FLANK_PATH_GOAL.y=y;
  _FLANK_PATH_OPTIONS.walkClear=walk;_FLANK_PATH_OPTIONS.navOverride=null;
  const path=dist(actor.x,actor.y,x,y)<1?[[x,y]]:
    (walk(L,actor.x,actor.y,x,y)?[[x,y]]:NavQuery.findPath(L,_FLANK_PATH_START,_FLANK_PATH_GOAL,_FLANK_PATH_OPTIONS));
  if(navWork.deferred||!path||!path.length)return null;
  const tail=path[path.length-1];
  if(dist(tail[0],tail[1],x,y)>2)return null;
  let px=actor.x,py=actor.y,length=0,exposed=0;
  for(const p of path){
    if(!walk(L,px,py,p[0],p[1]))return null;
    const dx=p[0]-px,dy=p[1]-py,leg=Math.hypot(dx,dy);
    length+=leg;
    const mx=(px+p[0])*.5,my=(py+p[1])*.5;
    if(!losBlocked(tx,ty,mx,my))exposed+=leg;
    px=p[0];py=p[1];
  }
  if(length>DataFLANK.maxRoute)return null;
  return {path,x,y,length,exposed,score:length+exposed*.75};
}

function flankRoute(L, runner, support, tx, ty, relax){
  navWork.deferred=false;
  const F=DataFLANK,lvl=Math.max(0,Math.min(F.relaxMax||0,relax|0));
  const sep=Math.max(F.minAngle||0.55,F.angle*(1-lvl*(F.relaxStep||0)));
  const radii=[F.radiusNear,F.radiusFar];
  if(lvl>=1)radii.push(F.radiusFar*(F.relaxRadius||1.3));

  /* A 也有明确攻击位：当前位置已经拥有射界时它就是第一个候选；没有射界时，
     沿当前这一侧寻找最近的可达射界。B 的终点再从 A 的最终射线量出夹角。 */
  const front=Math.atan2(support.y-ty,support.x-tx),supportCands=[];
  const sd=dist(support.x,support.y,tx,ty);
  if(sd>=120&&sd<=F.targetRadius&&!losBlocked(support.x,support.y,tx,ty))
    supportCands.push({x:support.x,y:support.y,cost:0});
  for(const off of [0,.32,-.32,.64,-.64,.96,-.96,1.25,-1.25])for(const r of radii){
    const a=front+off,x=tx+Math.cos(a)*r,y=ty+Math.sin(a)*r;
    if(!supportCands.some(q=>dist(q.x,q.y,x,y)<10))supportCands.push({x,y,cost:dist(support.x,support.y,x,y)});
  }
  supportCands.sort((a,b)=>a.cost-b.cost);
  let best=null,tests=0;
  for(const sc of supportCands){
    /* 双人各算一条路，比旧版只算 B 的路线需要更多候选；只对 canFlank 精英执行。 */
    if(tests++>=F.maxPathTests*3)break;
    const sr=flankPathTo(L,support,tx,ty,sc.x,sc.y);
    if(!sr)continue;
    const base=Math.atan2(sr.y-ty,sr.x-tx);
    for(const side of [-1,1])for(const r of radii){
      const a=base+side*sep,x=tx+Math.cos(a)*r,y=ty+Math.sin(a)*r;
      const rr=flankPathTo(L,runner,tx,ty,x,y);
      if(!rr)continue;
      const actual=Math.abs(normAng(Math.atan2(rr.y-ty,rr.x-tx)-base));
      if(actual<Math.min(F.minSeparation,sep*.92))continue;
      const score=sr.score+rr.score;
      if(!best||score<best.score)best={path:rr.path,x:rr.x,y:rr.y,side,sep,
        length:rr.length,exposed:rr.exposed,supportPath:sr.path,sx:sr.x,sy:sr.y,
        supportLength:sr.length,score};
    }
  }
  return best;
}
function flankTryPair(L, e){
  const F=DataFLANK;
  const target=flankTargetOf(e);
  /* 直接看见目标时不依赖 alertT；声音/记忆发起才要求仍处于警戒期。 */
  if (!target || !e.lastKnown || (!e.sees && !(e.alertT>0)) || e.mode!==1 ||
      dist(e.x,e.y,e.lastKnown.x,e.lastKnown.y)>F.targetRadius) return;
  if (uiT < flankPlanAfter) return;
  flankPlanAfter=uiT+F.planGap;
  const tx=e.sees?target.x:e.lastKnown.x,ty=e.sees?target.y:e.lastKnown.y;
  const targetId=tacticTargetId(target),ownFaction=combatFaction(e);
  let ally=null,near=Infinity;
  for (const o of enemies){
    if (o===e || combatFaction(o)!==ownFaction || behaviorOf(o).canFlank !== true || o.flank ||
        (o.flankRetryAt||0)>uiT || !flankReady(o) || !factionWantsFight(o,target)) continue;
    const d=dist(e.x,e.y,o.x,o.y);
    if (d>F.allyRadius || d>=near || dist(o.x,o.y,tx,ty)>F.targetRadius) continue;
    ally=o;near=d;
  }
  if (!ally) return;
  /* 交叉火力要求两个人到位后能同时开枪；任意一人正在装填或没有弹药就不启动。 */
  const canFight=o=>o.ammo>0 && !(o.reloading>0);
  if(!canFight(e)||!canFight(ally))return;
  const support=e,runner=ally;
  /* 同一个地方连续失败就把要求放宽一档：先 2 次，之后每 2 次再放一档，最多 relaxMax 档。 */
  const relax=Math.min(F.relaxMax||0,Math.floor((e.flankFail||0)/Math.max(1,F.relaxAfter||2)));
  const route=flankRoute(L,runner,support,tx,ty,relax);
  if (!route){
    if(navWork.deferred)return;
    e.flankFail=(e.flankFail||0)+1;ally.flankFail=(ally.flankFail||0)+1;
    e.flankRetryAt=ally.flankRetryAt=uiT+F.retryDelay;e.flankResult=ally.flankResult='no-path';return;
  }
  e.flankFail=0;ally.flankFail=0;
  // 读档后的数字标识也要避开，防止与下一次手动生成的队伍撞号。
  for(const o of enemies){
    flankActorSeq=Math.max(flankActorSeq,o.flankId||0);
    flankPairSeq=Math.max(flankPairSeq,o.flank?.pair||0);
  }
  if (!support.flankId) support.flankId=++flankActorSeq;
  if (!runner.flankId) runner.flankId=++flankActorSeq;
  const pair=++flankPairSeq;
  if (typeof tacBump === 'function') tacBump('flank');
  for (const o of [support,runner]){
    const isSupport=o===support;
    o.flank={pair,peer:isSupport?runner.flankId:support.flankId,role:isSupport?'support':'flank',
      phase:'move',targetId,tx,ty,startedAt:uiT,seenAt:e.sees?uiT:0,
      knownAt:e.sees?uiT:(e.heardAt||uiT),side:route.side,sep:route.sep,
      x:isSupport?route.sx:route.x,y:isSupport?route.sy:route.y,
      path:isSupport?route.supportPath:route.path,index:0,best:1e30,stall:0,arrivedAt:0,ready:false,syncAt:0};
    o.mode=1;o.lastKnown={x:tx,y:ty};o.lastKnownSource=target;o.heardSource=target;
    o.alertT=Math.max(o.alertT||0,CFG.eMemory);
    o.hideGoal=null;o.tucked=false;o.peekPhase=null;o.tacticPhase=null;o.tacStage=null;
    o.blindShot=false;o.holding=0;o.lookT=0;o.slideT=0;o.cornerWatch=null;
    o.path=null;o.goal=null;o.bladeNavPath=null;
    setBark(o,isSupport?'交叉就位，等口令！':'绕侧翼，同步开火！',2,2);
  }
}
/* ------------------------------------------------------------
   紧急呼叫支援 / 抱团（DataBACKUP）
   ------------------------------------------------------------
   数据：data/ai.js 的 DataBACKUP；兵种开关 behavior.canCallBackup。
   流程：backupTick 每帧判定 → eStatusSet(call) 进 3 秒硬直 →
         STATUS_TICK_FNS.call 到点调 backupDispatch 广播 →
         响应者 mode=1、目标点=呼叫者位置、吃 rushT 加速。
   优先级：正在包抄 / 正在转掩体的人不接呼叫，包抄不会被一句话拆散。
   ------------------------------------------------------------ */
function backupDef(){
  const D = (typeof DataBACKUP !== 'undefined') ? DataBACKUP : null;
  if (!D) return { on:false, hpPct:0.5, windup:3, barkAt:1.5, callR:800, maxResponders:3, cd:30, spdK:1.25, rushT:8, arriveR:140 };
  return D;
}
/* 正在干高优先级战术活的人：不接呼叫，也不在包抄中途喊人 */
function backupBusy(e){
  if (!e) return true;
  if (e.flank) return true;                                     /* 正在包抄 */
  if (e.peekPhase === 'run') return true;                       /* 正在转掩体 */
  if (e.hideGoal && (e.hideT || 0) <= 0.02) return true;
  return false;
}
/* 身边有几个同伙（不含自己、不含假人、不含死的）——落单才值得喊人 */
function backupAllyCount(e, r){
  if (!e) return 0;
  const R = r || 300;
  const fac = (typeof combatFaction === 'function') ? combatFaction(e) : 'enemy';
  let n = 0;
  for (const o of enemies){
    if (o === e || o.dead || !(o.hp > 0) || o.dummy) continue;
    if (dist(o.x, o.y, e.x, e.y) > R) continue;
    if ((typeof combatFaction === 'function' ? combatFaction(o) : 'enemy') !== fac) continue;
    n++;
  }
  return n;
}
/* 是不是"现在就该喊"：血量低于一半或已经看见玩家，**并且身边没人** */
function backupWants(e){
  const D = backupDef();
  if (D.on === false) return false;
  if (!e || e.dead || e.hp <= 0 || e._dying) return false;
  if (behaviorOf(e).canCallBackup !== true) return false;
  if (eStatusHas(e, 'call') || eStatusHas(e, 'stun')) return false;
  if ((e.backupCd || 0) > 0) return false;
  if ((e.callWindT || 0) > 0) return false;      /* 已经在喊了，别重复起手 */
  if (backupBusy(e)) return false;
  /* m40657：周围已经一堆同伙时，喊人来毫无意义；只有落单时才叫 */
  if (backupAllyCount(e, D.soloR || 300) > (D.soloMax || 0)) return false;
  const _low = e.maxHp ? (e.hp / e.maxHp) <= (D.hpPct || 0.5) : false;
  return _low || !!e.sees;
}
/* 在掩体后面：你这一边看不见他、两侧也都被挡着 */
function backupInCover(e, threat){
  threat = threat || enemyThreatOf(e);
  return !!threat && bodyBlind(e.x, e.y, (e.r || 12) * 0.92, threat);
}
/* 没在掩体后就先挑一个挡住视线的点挪过去；
   挪到了或实在找不到（超 seekMax）都返回 true —— 不能让他永远不喊。 */
function backupSeekCover(L, e, dt, threat){
  const D = backupDef();
  threat = threat || enemyThreatOf(e);
  if (D.seekCover === false) return true;
  if (backupInCover(e, threat)){ e.callSeekT = 0; e.hideGoal = null; return true; }
  e.callSeekT = (e.callSeekT || 0) + dt;
  if (e.callSeekT > (D.seekMax || 3.2)){ e.callSeekT = 0; e.hideGoal = null; return true; }
  const g = EnemyPerception.selectedCover(e);
  if (!g){
    const sp = (typeof pickHideSpot === 'function') ? pickHideSpot(L, e, 0, false, threat) : null;
    if (sp && sp.x !== undefined){ e.hideGoal = { x: sp.x, y: sp.y }; e.hideT = 0.05; }
    else e.callSeekT = (D.seekMax || 3.2) + 1;
    return false;
  }
  const ga = Math.atan2(g.y - e.y, g.x - e.x);
  const gd = Math.hypot(g.x - e.x, g.y - e.y);
  /* 不写 e.ang：朝向由主循环按"看得见就盯人"决定。
     以前这里直接 e.ang = ga，和盯人的那句每帧互相覆盖，
     人会一边横着平移一边被抽成九十度。 */
  if (gd > 12){
    const step = Math.min(gd, (CFG.eSpeed || 96) * 1.10 * dt);
    const nx = e.x + Math.cos(ga) * step, ny = e.y + Math.sin(ga) * step;
    if (clearWalkLine(L, e.x, e.y, nx, ny)){ e.x = nx; e.y = ny; }
    else e.hideGoal = null;
  }
  if (gd <= 14 || backupInCover(e, threat)){ e.callSeekT = 0; e.hideGoal = null; return true; }
  return false;
}
function backupCanStart(e){ return backupWants(e) && backupInCover(e, enemyThreatOf(e)); }
/* 广播：只叫 callR 内、闲着的人，最多 maxResponders 个 */
function backupDispatch(caller, D){
  D = D || backupDef();
  if (!caller || caller.dead || caller.hp <= 0) return 0;
  const R = D.callR || 800;
  const maxN = Math.max(1, (D.maxResponders | 0) || 3);
  const own = (typeof combatFaction === 'function') ? combatFaction(caller) : 'enemy';
  const list = [];
  const laneCall = caller.mobaSide !== undefined && mobaOn();
  for (const o of enemies){
    if (!o || o === caller || o.dead || o.hp <= 0 || o._dying) continue;
    if (typeof combatFaction === 'function' && combatFaction(o) !== own) continue;
    if (laneCall && !mobaBackupFollower(caller,o)) continue;
    if (o.static || o.bossKind || isAlarmer(o)) continue;
    if (o.dummy) continue;
    if (!behaviorOf(o).canChase) continue;
    if (eStatusHas(o, 'stun') || eStatusHas(o, 'fear') || eStatusHas(o, 'call')) continue;
    if (eStatusHas(o, 'hurt') || eStatusHas(o, 'suppress')) continue;
    if (backupBusy(o)) continue;                                /* 包抄 / 转掩体：不打断 */
    const d = dist(o.x, o.y, caller.x, caller.y);
    if (d > R) continue;
    list.push({ e: o, d: d });
  }
  list.sort(function(a, b){ return a.d - b.d; });
  const take = list.slice(0, maxN);
  for (const it of take){
    const o = it.e;
    o.mode = 1; o.heard = true; o.lookT = 0;
    o.lastKnown = { x: caller.x + (laneCall ? 0 : rand(-14, 14)), y: caller.y + rand(-14, 14) };
    o.alertT = Math.max(o.alertT || 0, CFG.eMemory + 10);
    o.chk = null; o.path = null; o.goal = null; o.stuckT = 0;
    o.backupRushT = (D.rushT || 8);
    voiceSay(o, 'comrade', 0.85, 3);
  }
  if (take.length) setBark(caller, '压上去！', 1.8, 2, false);
  /* m40657：真正的"支援"是从外面调人——附近没人可叫的时候，得真的来人 */
  const extra = backupReinforce(caller, D);
  logInfo('backup', '呼叫支援：' + take.length + ' 人响应' + (extra ? ' · 增援 ' + extra + ' 人' : ''));
  return take.length + extra;
}
/* 从地图边缘（背离玩家的那一侧）调一批同兵种的人过来 */
function backupReinforce(caller, D){
  D = D || backupDef();
  const L = cur();
  const n = Math.max(0, D.reinforceN | 0);
  if (!n || !caller || !L) return 0;
  const cap = D.reinforceMax || 40;
  if (enemies.length >= cap) return 0;
  /* 从“当前威胁 → 呼叫者”的方向再往外走；A/B 交战时不再默认参考玩家。 */
  const threat = enemyThreatOf(caller) || player;
  const laneCall = caller.mobaSide !== undefined && mobaOn(L);
  let a = laneCall ? (caller.mobaSide ? 0 : Math.PI)
                   : Math.atan2(caller.y - threat.y, caller.x - threat.x);
  if (!isFinite(a)) a = rand(0, TAU);
  const _dist = D.spawnDist || 620;
  const fac = (typeof combatFaction === 'function') ? combatFaction(caller) : 'enemy';
  const kind = (caller.type && caller.type !== 'dummy') ? caller.type : 'grunt';
  const T = enemyType({ type: kind });
  let made = 0;
  for (let i = 0; i < n; i++){
    if (enemies.length >= cap) break;
    const side = (i - (n - 1) / 2) * 96;
    const px = clamp(caller.x + Math.cos(a) * _dist + Math.cos(a + Math.PI / 2) * side, 40, L.w - 40);
    const py = clamp(caller.y + Math.sin(a) * _dist + Math.sin(a + Math.PI / 2) * side, 40, L.h - 40);
    const sp = safeSpot(L, { x: px, y: py }, 24);
    if (laneCall && (caller.mobaSide ? -1 : 1)*(caller.x-sp.x)<=0) continue;
    const hp = Math.max(1, T.hp || 100);
    const e2 = {
      type: kind,
      x: sp.x, y: sp.y, r: T.r || 12, ang: a + Math.PI,
      wp: [[sp.x, sp.y]], i: 0, wait: 0, mode: 1,
      lastKnown: { x: caller.x, y: caller.y },
      alertT: Math.max(60, CFG.eMemory + 10),
      sees: false, heard: false, chk: null,
      ammo: CFG.mag, fireCd: rand(0.4, 1.1), reloading: 0, muzzle: 0,
      hp: hp, maxHp: hp, fleeCd: 0,
      faction: fac,
      factionTint: caller.factionTint,
      backupRushT: D.rushT || 8,
      backupFresh: true
    };
    if (laneCall){
      mobaAssignRoute(e2,caller.mobaSide,caller.mobaLane);
      e2.mobaKind='reinforcement';
    }
    if (T.armorKind) e2.armor = armorOf(T.armorKind);
    enemies.push(e2);
    assignWeapon(e2);
    made++;
  }
  if (made) setMsg('有人叫来了增援 · ' + made + ' 人朝这边赶来', 1.8);
  return made;
}
/* 前摇里：站定、面朝玩家（冻结由调用处 continue 保证） */
function backupHold(e){
  const D = backupDef();
  if (D.on === false) return false;
  const threat = enemyThreatOf(e);
  if (e.sees && threat) e.ang = Math.atan2(threat.y - e.y, threat.x - e.x);
  e.backupHoldT = (e.backupHoldT || 0) + 1 / 60;
  return true;
}
/* 每帧：赶路计时、看见人就转正面交火、开喊（开喊前要求没在包抄/转掩体）
   m40657：不再进 'call' 硬直——喊话这两秒照常走位、照常开枪，
   否则"叫支援"等于把自己定住两秒，反而是削弱。 */
function backupTick(L, e, dt){
  const D = backupDef();
  if (D.on === false) return false;
  if ((e.backupRushT || 0) > 0) e.backupRushT = Math.max(0, e.backupRushT - dt);
  if (e.sees && (e.backupRushT || 0) > 0) e.backupRushT = 0;    /* 路上撞见玩家：直接打 */
  /* 前摇计时（不冻结） */
  if ((e.callWindT || 0) > 0){
    /* 被打晕：这一嗓子咽回去（冷却已经吃掉了，就当喊失败） */
    if (eStatusHas(e, 'stun')){
      e.callWindT = 0; e.callDone = true;
      return false;
    }
    const before = e.callWindT;
    e.callWindT = Math.max(0, e.callWindT - dt);
    if (!e.callBark && before > (D.barkAt || 1) && e.callWindT <= (D.barkAt || 1)){
      e.callBark = true;
      setBark(e, '请求支援！', 1.4, 3, false);
    }
    if (e.callWindT <= 0 && !e.callDone){
      e.callDone = true;
      backupDispatch(e, D);
    }
    return false;              /* false = 不接管这一帧：照常走位、照常开枪 */
  }
  if (backupWants(e)){
    const threat = enemyThreatOf(e);
    if (!backupInCover(e, threat) && !backupSeekCover(L, e, dt, threat)) return true;
    e.callBark = false; e.callDone = false;
    e.callWindT = D.windup || 2;
    eCdSet(e, 'backupCd', D.cd || 30);
    e.path = null; e.goal = null; e.chk = null;
    setBark(e, '呼叫支援！', 1.4, 3, false);
    logWarn('backup', '人机开始呼叫支援');
    return true;
  }
  return false;
}
function flankTick(L,e,dt){
  const F=DataFLANK;
  if (!flankReady(e)){if(e.flank)flankEnd(e,'interrupted');return false;}
  if (!e.flank){
    if (uiT<(e.flankRetryAt||0) || uiT<(e.flankSearchAt||0)) return false;
    e.flankSearchAt=uiT+F.searchGap;
    flankTryPair(L,e);
    if (!e.flank) return false;
  }
  const s=e.flank;
  const peer=enemies.find(o=>o.flankId===s.peer && o.flank && o.flank.pair===s.pair);
  if (!peer || behaviorOf(peer).canFlank !== true || !flankReady(peer)){flankEnd(e,'partner-lost');return false;}
  const target=tacticTargetById(s.targetId)||flankTargetOf(e);
  if(!tacticTargetAlive(target)||!factionWantsFight(e,target)){flankEnd(e,'target-lost');return false;}
  const seenTarget=e.sees&&enemyTargetEntity(e)===target;
  if(seenTarget){
    if(dist(target.x,target.y,s.tx,s.ty)>F.targetDrift){flankEnd(e,'target-moved');return false;}
    for(const q of [s,peer.flank]){q.seenAt=uiT;q.knownAt=uiT;q.tx=target.x;q.ty=target.y;}
  }else if(e.lastKnownSource===target&&(e.heardAt||0)>(s.knownAt||0)){
    if(dist(e.lastKnown.x,e.lastKnown.y,s.tx,s.ty)>F.targetDrift){flankEnd(e,'target-moved');return false;}
    for(const q of [s,peer.flank]){q.knownAt=e.heardAt;q.tx=e.lastKnown.x;q.ty=e.lastKnown.y;}
  }
  const lastSeen=Math.max(s.seenAt||0,peer.flank.seenAt||0);
  const lastKnown=Math.max(s.knownAt||0,peer.flank.knownAt||0);
  const stale=lastSeen>0?(F.staleAfter||2.5):(F.heardStaleAfter||6);
  if(uiT-Math.max(lastSeen,lastKnown)>stale){flankEnd(e,'target-lost');return false;}
  if (uiT-s.startedAt>F.timeout){flankEnd(e,'timeout');return false;}
  // 射击始终走公共武器分支；协同层只负责让两人形成两条不同射线。
  if (!e.sees) e.ang=Math.atan2(s.ty-e.y,s.tx-e.x);
  if (s.phase==='crossfire'){
    if (uiT-s.arrivedAt>=F.crossfireTime){flankEnd(e,'complete');return false;}
    return true;
  }
  if(s.phase==='hold'){
    /* 先到位的人留在攻击位正常观察和射击，但不恢复旧版左右出口盲扫。 */
    pushOutTrucks(e);return true;
  }
  if (dist(e.x,e.y,s.x,s.y)<=F.arriveRadius){
    s.ready=true;s.phase='hold';s.arrivedAt=uiT;
    if(peer.flank.ready){
      const a=Math.atan2(e.y-s.ty,e.x-s.tx),b=Math.atan2(peer.y-s.ty,peer.x-s.tx);
      /* 两条射线都要覆盖目标所在掩体，并保持足够夹角；少一条都不叫交叉火力。 */
      const need=Math.min(F.minSeparation,(s.sep||F.minSeparation)*.92);
      if(Math.abs(normAng(a-b))<need||losBlocked(e.x,e.y,s.tx,s.ty)||
          losBlocked(peer.x,peer.y,s.tx,s.ty)){
        flankEnd(e,'no-crossfire');return false;
      }
      const syncAt=uiT+(F.syncDelay||.12);
      for(const o of [e,peer]){
        o.flank.phase='crossfire';o.flank.arrivedAt=uiT;o.flank.syncAt=syncAt;
        o.spotT=0;o.fireCd=Math.min(o.fireCd||0,F.syncDelay||.12);o.specShotRecovery=0;
        o.blindShot=false;
      }
      setBark(e,'交叉火力——开火！',2,2);
    }
    return true;
  }
  if ((e.spotT||0)>0) return true;
  const p=s.path && s.path[s.index];
  if (!p){flankEnd(e,'path-ended');return false;}
  if (!flankWalk(L,e.r,e.x,e.y,p[0],p[1])){flankEnd(e,'path-blocked');return false;}
  const distance=dist(e.x,e.y,p[0],p[1]);
  if (distance<1){s.index++;s.best=1e30;s.stall=0;return true;}
  if (distance<s.best-1){s.best=distance;s.stall=0;}else s.stall+=dt;
  if (s.stall>F.stallTime){flankEnd(e,'stuck');return false;}
  flankSteps(L, e, dt);
  bladeMove(L,e,Math.atan2(p[1]-e.y,p[0]-e.x),Math.min(distance,CFG.eSpeed*F.speedK*eMoveK(e)*enemyMoveK(e)*dt));
  return true;
}

/* 玩家这一脚能传多远：静步/难度给出基础半径，雷声再压一层。
   抽成函数是为了让测试能直接调它，而不用伪造"玩家在移动"的输入状态。 */
function playerStepNoise(dt){
  /* 斗蛐蛐观战图：玩家只是镜头，没有脚步声（用户 m40173 说"为什么还有玩家脚步声"）。
     连涟漪也不画 —— 那是"AI 能听见"的可见反馈，观战图里不该出现。 */
  if (typeof spectatorViewOn === 'function' && spectatorViewOn()){ player.moving = false; return; }
  if (typeof godSilent === 'function' && godSilent()){ player.stepT = 0.2; return; }   /* 上帝模式：没脚步声 */
  player.stepT -= dt;
  if (!player.moving){
    player.stepT = Math.min(player.stepT, 0.12);
    return;
  }
  if (player.stepT > 0) return;
  player.stepT = player.crouch ? 0.52 : 0.34;
  if (!sfxFoot()) sfxStep(player.crouch ? 0.062 : 0.085, player.crouch ? 250 : 380);
  const rad = maskedHearR(playerHearR());
  stepRipples.push({x:player.x, y:player.y, r0:player.r+2, r1:rad, t:0, life:0.62, crouch:player.crouch});
  if(typeof factionEmitNoise==='function')factionEmitNoise(player,'step',player.x,player.y,rad);
  else for (const e of enemies){
    if(typeof factionWantsFight==='function'&&!factionWantsFight(e,player))continue;
    const er = rad * (e.HM !== undefined ? e.HM : enemyType(e).hearMul);
    if (dist(e.x,e.y,player.x,player.y) < er) alertBySound(e,player.x,player.y,player,'step');
  }
}

/* 望远镜：按住左键慢慢举起（0.7 秒），松开慢慢放下（0.45 秒）。
   不是瞬时开关 —— 用户要的就是"慢慢变窄、慢慢拉远"那段过程。
   单独一个函数，测试可直接喂 dt 走时间轴。 */
function updateBinoK(dt){
  if (!player) return;
  const want = (mouse.fire && player.gun && player.gun.tool && state === 'play' && player.hp > 0) ? 1 : 0;
  const cur0 = player.binoK || 0;
  /* 只在"还没到目标"时动它。原来写成 want > cur0 ? 升 : 降，
     举满那一帧 want 和 cur0 都等于 1，条件是 false，于是白降一帧再爬回去 ——
     画面每三帧缩一次，看起来就是在抽。 */
  if (want > cur0) player.binoK = Math.min(1, cur0 + dt / 0.7);
  else if (want < cur0) player.binoK = Math.max(0, cur0 - dt / 0.45);
}

/* 单个敌人的一帧：从 update() 里抽出来的大循环体。
   顶层 continue 已换成 return（= "这个人机这帧就到这里"），嵌套循环里的 continue 原样保留。
   acc 是跨敌人的统计袋（谁看见玩家、最近的追击距离），由调用方创建并在循环后写回。 */
/* 刀手（ET.kind === "blade"）那一帧：起手 → 前突 → 撤离。
   返回 true 表示"这一帧到此为止"（原来这段里的 continue 换成了 return true）。 */
const _BLADE_NPC_DAMAGE_REQUEST={source:null,target:null,damage:0,kind:'blade',angle:0};
function enemyBladeTick(L, e, dt, ET){
      const _seenTarget=enemyTargetEntity(e);
      e.bladeCd = Math.max(0, (e.bladeCd || 0) - dt);
      e.recoverT = Math.max(0, (e.recoverT || 0) - dt);
      /* 僵直只停止行动，挥刀和突刺残影继续按原寿命淡出。 */
      if ((e.slashT || 0) > 0) e.slashT = Math.max(0, e.slashT - dt);
      if (e.trail && e.trail.length){
        for (let i = e.trail.length - 1; i >= 0; i--){
          e.trail[i].t += dt;
          if (e.trail[i].t >= e.trail[i].dur) e.trail.splice(i, 1);
        }
      }
      /* 3-4 专用：砍完这一刀之后原地定住几秒，给玩家逃跑窗口。
         只在这一关的关卡规则开了 knifeLock 时才生效（数据在 data/ai.js 的 DataKnifeLock）。 */
      if ((e.knifeLockT || 0) > 0 && (e.lungeT || 0) <= 0){
        e.knifeLockT = Math.max(0, e.knifeLockT - dt);
        if (e.knifeLockA !== undefined) e.ang = e.knifeLockA;
        return true;                        /* 定住期间：不走位、不起手、不追击 */
      }
      /* 记忆：闪电亮起的那一下看见了你，就算黑下去也该摸过来。
         没有记忆的话他连"刚才看见过谁"都不记得，只能站一辈子。 */
      if (e.sees&&_seenTarget){ e.memo = {x: _seenTarget.x, y: _seenTarget.y}; e.memoT = 6.5; }
      if (e.nadeDodgeThreat && !(e.windup > 0 || e.lungeT > 0)) return true;
      if (!e.nadeDodgeThreat && !e.sees && (e.memoT || 0) > 0) e.memoT = Math.max(0, e.memoT - dt);
      const bd = _seenTarget ? dist(e.x,e.y,_seenTarget.x,_seenTarget.y) : 1e9;
      /* 他还有耳朵：跑起来很响、蹲着几乎没声，下雨也不行（雨声只盖脚步的三成半） */
      const _obs = (typeof spectatorViewOn === 'function' && spectatorViewOn()) || player.god === true || (typeof godOn === 'function' && godOn());
      const _hearR = ((_seenTarget===player&&player.crouch&&!_obs) ? 96 : 250) * (ET.hearMul || 1) * (weatherHasRain() ? 0.65 : 1) * hearMaskK();
      const _heard = !!_seenTarget && bd < _hearR && factionWantsFight(e,_seenTarget);
      if (!e.nadeDodgeThreat && _heard && !e.sees && !losBlocked(e.x, e.y, _seenTarget.x, _seenTarget.y)){
        e.memo = {x: _seenTarget.x, y: _seenTarget.y}; e.memoT = 3.4;
      } else if (!e.nadeDodgeThreat && _heard && !e.sees && (e.memoT || 0) <= 0){
        /* 听见就把"那边有人"记下来，摸过去看一眼 —— 不然永远在原地发呆 */
        e.memo = safeSpot(L, {x: _seenTarget.x + rand(-70, 70), y: _seenTarget.y + rand(-70, 70)}, e.r + 2);
        e.memoT = 3.4;
      }
      const _aware = e.sees || (e.memoT || 0) > 0 || bd < 40 || _heard;
      /* 追击与起手共用实际刀长，不能提前停在攻击范围外。 */
      e.huntT = _aware ? 1.5 : Math.max(0, (e.huntT || 0) - dt);
      const _isDao = (e.wid === 'dao');
      const _reach = (ET.bladeReach || 40) + (_isDao ? (ET.daoReachBonus || 14) : 0) + ((_seenTarget&&_seenTarget.r)||11) + 4;
      /* 前突和后摇优先于重新起手；移动始终经过墙体碰撞。 */
      if ((e.lungeT || 0) > 0){
        const stepT = Math.min(dt, e.lungeT);
        e.lungeT = Math.max(0, e.lungeT - dt);
        bladeMove(L, e, e.lungeA, 470 * eMoveK(e) * stepT);
        e.ang = e.lungeA;
        if (!e.trail) e.trail = [];
        e.trail.push({x:e.x, y:e.y, a:e.lungeA, t:0, dur:0.24});
        if (e.trail.length > 12) e.trail.shift();
        return true;
      }
      if (e.recoverT > 0){
        const speed = CFG.eSpeed * 1.30 * eMoveK(e);
        if ((e.retreatRunT || 0) > 0){
          const stepT = Math.min(dt, e.retreatRunT);
          e.retreatRunT = Math.max(0, e.retreatRunT - dt);
          const moved = bladeMove(L, e, e.lungeA, speed * stepT);
          e.ang = e.lungeA;
          if (moved < speed * stepT * 0.5) e.retreatRunT = 0;
          else return true;
        }
        const _hidePoint=_seenTarget||e.memo;
        const hidden = !!_hidePoint && dist(e.x,e.y,_hidePoint.x,_hidePoint.y)>100 && losBlocked(_hidePoint.x,_hidePoint.y,e.x,e.y);
        if (hidden) return true;  /* 已在掩体后：等完整冷却，不往回贴脸。 */
        if (!e.retreatGoal || dist(e.x,e.y,e.retreatGoal.x,e.retreatGoal.y) < 12 || (e.stuckT || 0) > 0.4){
          e.retreatGoal = bladeRetreatGoal(L, e, speed);
          e.path = null; e.goal = null; e.stuckT = 0;
        }
        const g = e.retreatGoal;
        const a = navSteer(L, e, g.x, g.y, dt);
        const step = Math.min(speed * enemyMoveK(e) * dt, dist(e.x,e.y,g.x,g.y), e.bladeNavDistance);
        const moved = bladeMove(L, e, a, step);
        e.stuckT = moved < step * 0.3 ? (e.stuckT || 0) + dt : 0;
        e.ang = a;
        return true;
      }
      if (e.retreatGoal || e.retreatRunT){
        e.retreatGoal = null; e.retreatRunT = 0;
        e.path = null; e.goal = null; e.stuckT = 0;
      }


      /* 已经抬手了：站定、把刀举向你，0.34 秒后落下。这一帧不走位 */
      if ((e.windup || 0) > 0 && eStatusHas(e, 'stun')){ e.windup = 0; return true; }
      if ((e.windup || 0) > 0){
        const _strikeTarget=(e.bladeTarget&&!e.bladeTarget.dead&&e.bladeTarget.hp>0)?e.bladeTarget:_seenTarget;
        e.windup = Math.max(0, e.windup - dt);
        if(_strikeTarget)e.ang = Math.atan2(_strikeTarget.y - e.y, _strikeTarget.x - e.x);
        if (e.windup <= 0){
          e.bladeCd = ((cur().rules && cur().rules.bladeSlow) ? 1.25 : 0.62);
          e.slashT = 0.26; e.slashA = e.ang;
          /* m36523：恢复 2026-11-08 原版 —— 落刀这一帧只设 lungeT=0.16，
             实际位移交给下面的 lunge 分支逐帧推进（每帧带 trail 尾迹，这才是原来的"冲刺效果"）。
             不要在这里一帧挪完，也不要自己补 trail 点（会变成地面残影 / 瞬移）。 */
          e.lungeT = 0.16; e.lungeA = e.ang; e.recoverT = e.bladeCd; e.trail = [];
          e.retreatRunT = 0.18; e.retreatGoal = null;
          e.path = null; e.goal = null; e.stuckT = 0;
          const _sr=(ET.bladeReach||40)+(_isDao?(ET.daoReachBonus||14):0)+((_strikeTarget&&_strikeTarget.r)||11)+4;
          const still = !!_strikeTarget && dist(e.x,e.y,_strikeTarget.x,_strikeTarget.y)<=_sr+12
            && (_strikeTarget!==player||player.grace<=0) && bladeStrikeClear(L,e,_strikeTarget);
          if (still && _strikeTarget===player && playerTruck){
            /* 人坐在铁壳里：刀砍的是车厢装甲，砍不到人。
               给一点车损 + 金属火花，让他"砍得响但砍不进去"。 */
            const _kd = Math.max(1, Math.round(CFG.eDmg * 0.22));
            const _hx = playerTruck.x + Math.cos(e.ang) * 40;
            const _hy = playerTruck.y + Math.sin(e.ang) * 40;
            for (let _i = 0; _i < 8; _i++)
              spawnPart(_hx, _hy, e.ang + Math.PI + fxRand(-0.9, 0.9), fxRand(140, 420),
                        fxRand(0.10, 0.26), 'mspark', fxRand(1.0, 2.2));
            hotMarks.push({ x: _hx, y: _hy, t: 0, dur: 1.2 });
            damageTruck(playerTruck, _kd, e.ang);
            sfxMetalHit(_hx, _hy);
            sfxBladeHit();
            camShake = Math.max(camShake, 0.25);
            return true;                       /* 玩家的血一点都不掉 */
          }
          let damageDealt = 0;
          if (still && _strikeTarget===player && !player.god){
            const bDmg = Math.round(CFG.eDmg * (ET.bladeDmg || 1.6) * (_isDao ? (ET.daoDmgMul || 1.35) : 1));
            const _bdm = guardDamage(bDmg * (ar ? (1 - (ar.armor || 0)) : 1));
            damageDealt = absorbArmor(_bdm, 'blade');
            if (!(damageDealt > 0)){ sfxBladeSwing(); return true; }
            player.hp -= damageDealt;
            hurtNum(_bdm);
      stOnHurt(bDmg * (ar ? (1 - (ar.armor || 0)) : 1), 'blade');
            if (cur().healHint) player.hintT = 5;
            player.flash = 1; hitFlash = Math.max(hitFlash, 0.55);
            camShake = Math.max(camShake, 0.62);
            sfxBladeHit();
            /* 方向 + 血 + 刀光：挨了刀要能看出"哪边砍的、砍出多少血" */
            hurtDir(e.ang, bDmg);
            if (player.hp <= 0) markDeath('blade', e, bDmg, e.ang);
            logWarn('hurt', '刀手砍了你 · -' + bDmg + ' HP · 剩 ' + Math.max(0, Math.round(player.hp)));
          } else if(still && _strikeTarget!==player){
            const bDmg=Math.round(CFG.eDmg*(ET.bladeDmg||1.6)*(_isDao?(ET.daoDmgMul||1.35):1));
            _BLADE_NPC_DAMAGE_REQUEST.target=_strikeTarget;
            _BLADE_NPC_DAMAGE_REQUEST.damage=bDmg;
            _BLADE_NPC_DAMAGE_REQUEST.source=e;
            _BLADE_NPC_DAMAGE_REQUEST.angle=e.ang;
            damageDealt = CombatDamage.applyNPC(_BLADE_NPC_DAMAGE_REQUEST);
            sfxBladeHit();camShake=Math.max(camShake,.28);
          } else {
            sfxBladeSwing();            /* 躲开了：只有挥空声，不掉血 */
          }
          /* 3-4：实际伤到角色的这一刀，突刺完成后进入僵直。 */
          if (damageDealt > 0 && typeof knifeLockOn === 'function' && knifeLockOn()){
            const _lk = knifeLockSec();
            if (_lk > 0){ e.knifeLockT = _lk; e.knifeLockA = e.ang; }
          }
        }
        return true;                        /* 抬手期间不走位 */
      }

      if (_seenTarget && _aware && bd <= _reach && e.bladeCd <= 0 && (_seenTarget!==player||player.grace<=0)
          && !eStatusHas(e, 'stun') && bladeStrikeClear(L,e,_seenTarget)){
        e.windup = (cur().rules && cur().rules.bladeSlow) ? 0.62 : 0.34;                 /* 起手：听得见、看得见，0.34 秒够你退一步 */
        e.bladeTarget=_seenTarget;
        e.ang = Math.atan2(_seenTarget.y - e.y, _seenTarget.x - e.x);
        sfxBladeWind();
        return true;
      }
  return false;
}

/* 通用移动与交战：寻路、追/巡、掩体、投雷、贴墙滑行、卡住统计，
   一直到把这一帧的位置写完。原来是 enemyTick 的后半段，纯尾部搬出来的。 */
function enemyMoveTick(L, e, dt, ET, _stunned, ei, acc, throwAdvanced){
  segBegin('AI 移动');
  try {
    const {targetPoint:_target,targetEntity:_targetEntity}=EnemyPerception.read(e,_ENEMY_PERCEPTION_SAMPLE);
    const _threat=(_targetEntity&&_targetEntity!==e)?_targetEntity:((_target&&_target!==e)?_target:null);
    /* 移动：看见了就快步；只听见就走到那个位置，站着找一圈再走 */
    if (ET.kind !== 'blade' && e.trail && e.trail.length){
      for (let _ti = e.trail.length - 1; _ti >= 0; _ti--){ e.trail[_ti].t += dt; if (e.trail[_ti].t >= e.trail[_ti].dur) e.trail.splice(_ti, 1); }
    }
    if (e.barkT > 0) e.barkT -= dt;
    if (e.voiceCd > 0) e.voiceCd = Math.max(0, e.voiceCd - dt);
    if ((e.chargeCd || 0) > 0) e.chargeCd = Math.max(0, e.chargeCd - dt);
    /* 通用发甲：第一次跑到这里就把甲穿上（早退只是一个属性检查，别怕每帧调） */
    ensureEnemyArmor(e);
    /* 已在 enemyTick 推进过的投雷前摇不能再减一次；尚未开始的投雷仍在这里判定，
       保持“室内搜索只续完既有动作，不会边搜边新掏一颗雷”的原行为。 */
    if (!throwAdvanced) enemyThrowTick(L, e, dt);
    let tx = e.x, ty = e.y, speed = 0;
    const gapClue=(ET.canShoot||ET.kind==='blade')&&!ET.fly&&!ET.static&&!e.devOrd&&!e.bossKind&&!e.fleeing&&e.mode===1
      ? e.lastKnown : null;
    const wallGap=gapClue||enemyWallGaps.has(e) ? enemyWallGapGoal(L,e,gapClue) : null;
    if(!_stunned&&!(e.throwT>0)&&!e.fleeing&&!e.devOrd&&navRecoveryPatrolTick(L,e,dt))return;
    if(e.sees||(e.mode!==1&&!(e.huntT>0)))e.navRecovery=null;
    if (_stunned){
      /* 站住：不追、不逃、不找掩体、不架枪、不扔烟 */
      tx = e.x; ty = e.y; speed = 0;
      /* 站着不动的人也要被车壳顶开：pushOutTrucks 原来只写在 `if (speed > 0)` 里，
         被晕住 / 站着的人会被倒车的车头直接碾进车壳里（人被"吞"进车厢，看着像没撞到）。 */
      pushOutTrucks(e);
    } else if ((e.throwT || 0) > 0){
      /* 掏雷/拉环的硬直：站住不动、不开枪，只把头顶那个"雷"图标亮着 */
      tx = e.x; ty = e.y; speed = 0;
      pushOutTrucks(e);
    } else if (wallGap && dist(e.x,e.y,gapClue.x,gapClue.y)>24){
      tx=gapClue.x;ty=gapClue.y;speed=CFG.eSpeed*.72*eMoveK(e);
    } else if (ET.kind === 'blade' && (e.huntT || 0) > 0 && e.memo){
      const _bladeTarget=enemyTargetEntity(e);
      const reach = (ET.bladeReach || 40) + (e.wid === 'dao' ? (ET.daoReachBonus || 14) : 0) + ((_bladeTarget&&_bladeTarget.r)||11) + 4;
      const canStrike = !!_bladeTarget && dist(e.x,e.y,_bladeTarget.x,_bladeTarget.y) <= reach && bladeStrikeClear(L,e,_bladeTarget);
      if(_bladeTarget===player){acc.anyHunt = true; acc.nearestHunt = Math.min(acc.nearestHunt, dist(e.x,e.y,player.x,player.y));}
      if (canStrike){
        e.ang = Math.atan2(_bladeTarget.y-e.y,_bladeTarget.x-e.x);
        tx = e.x; ty = e.y; speed = 0;
      } else {
        /* 追人也走枪手那套 A*：以前是直线怼着记忆点走，
           碰上窄墙缝就会在缝口来回蹭（"抽搐着过来"）。 */
        /* 到达记忆点后留在现场搜索，记忆过期再回巡逻。 */
        /* 走到了旧坐标、人不在：别在原地发呆，换个点继续摸 */
        if (dist(e.x,e.y,e.memo.x,e.memo.y)<24 &&
            bladeWalkLine(L,groundSqueezeRadius(L,e)??e.r,e.x,e.y,e.memo.x,e.memo.y,false,undefined,true)){
          e.memo = null; e.memoT = 0; e.huntT = 0;
          if (e.wp && e.wp.length){ e.i = ((e.i | 0) + 1) % e.wp.length; e.wait = rand(0.2, 0.6); }
          e.path = null; e.goal = null;
          return;
        }
        const _ca = (e.sees||DataCHASE.on===false) ? navSteer(L,e,e.memo.x,e.memo.y,dt) : enemyChaseHeading(L,e,e.memo.x,e.memo.y,dt);
        if(_ca===null)return;
        const _cstep = Math.min(CFG.eSpeed * 1.05 * eMoveK(e) * enemyMoveK(e) * dt, e.bladeNavDistance);
        if (_cstep > 0) bladeMove(L, e, _ca, _cstep);
        e.ang = _ca;
        return;                      /* 移动已经做完了，别再落到通用的 steerAngle */
      }
    } else if (e.bossKind === 'shield' && (e.dashT > 0 || e.dashWind > 0)){
      speed = 0;                                  /* 冲撞由 arenaBossTick 直接推 */
    } else if (e.bossKind === 'warlord' && (e.wDashT > 0 || e.wWind > 0)){
      speed = 0;                                  /* 督军冲锋也由 arenaBossTick 推 */
    } else if (e.bossKind === 'charger' && (e.sees || e.fuse > 0 || e.mode === 1)){
      /* 疯狗：不绕路、不找掩体，直线扑过来（点火后更快，后摇时慢） */
      tx = _target.x; ty = _target.y;
      speed = CFG.eSpeed * (e.fuse > 0 ? 2.05 : (e.boomRecover > 0 ? 0.5 : 1.45)) * eMoveK(e);
      acc.anyHunt = true;
    } else if (e.chargeT > 0){
      e.chargeT -= dt;
      if (e.chargeT <= 0){ e.chargeT = 0; e.chargeCd = Math.max(e.chargeCd || 0, 4); }
      if (e.sees || !e.chargeGoal){ e.chargeT = 0; e.chargeCd = Math.max(e.chargeCd || 0, 5); }
      else {
        tx = e.chargeGoal.x; ty = e.chargeGoal.y;
        if (dist(e.x, e.y, tx, ty) < 46){ e.chargeT = 0; e.chargeCd = 5; }
        else { speed = CFG.eSpeed * 1.42; acc.anyHunt = true; }
      }
    } else if ((e.singleCoverPhase || (humanOn(L) && eStatusHas(e, 'fear'))) && e.hideGoal){
      /* \u8eb2\uff1a\u5148\u8dd1\u5230\u6700\u8fd1\u7684\u63a9\u4f53\u540e\u9762\uff0c\u7136\u540e\u5f00\u59cb\u7f29\u5934 / \u63a2\u5934 */
      let g = e.hideGoal;
      e.blindShot = false;
      /* 掩体不真（你根本看得见那个点）：立刻换一个真的。只验一次，
         不能每帧都重算，否则 hideT 永远归零（贴墙喘气 / 不抖动 / 判定埋伏全失效） */
      if (!e.coverOK){
        e.coverOK = losBlocked(_target.x, _target.y, g.x, g.y) ? 1 : 0;
        if (!e.coverOK){
          const _real = pickHideSpot(L, e, 120, true, _threat);
          if (_real && dist(e.x, e.y, _real.x, _real.y) > 26){
            e.hideGoal = {x:_real.x, y:_real.y}; g = e.hideGoal; e.coverOK = 1;
            e.peekPhase = 'run'; e.tucked = false; e.hideT = 0; e.peekT = 0;
            e.path = null; e.goal = null; e.chk = null; e.stuckT = 0;
          }
        }
      }
      const dg = dist(e.x, e.y, g.x, g.y);
      if (e.peekPhase === 'run' && dg > 18 && !e.holding){
        if (behaviorOf(e).corpseGlance && (e.glanceT || 0) > 0){
          /* 跑着跑着忽然停下来回头看眼刚刚死的人 */
          if (e.glanceAt) e.ang = Math.atan2(e.glanceAt.y - e.y, e.glanceAt.x - e.x);
          tx = e.x; ty = e.y; speed = 0;
        } else {
          if (behaviorOf(e).corpseGlance && e.glanceAt && arenaRandom() < HUMAN.glanceP * dt) e.glanceT = HUMAN.glanceT;
          /* 太慌了，跑不成直线：全身上下摇着过去 */
          e.swayT = (e.swayT || 0) + dt;
          const _base = Math.atan2(g.y - e.y, g.x - e.x);
          const _sw = (behaviorOf(e).sway || 0) * Math.sin(e.swayT * HUMAN.swayHz * 6.283 + (e.swayPh || 0)) * HUMAN.swayAmp;
          const _near = dg < 110 ? 0.35 : 1;   /* 快到掩体了就别再大幅度扭，免得在墙边蹭 */
          const _ss = safeSpot(L, {x: e.x + Math.cos(_base + _sw * _near) * 46,
                                   y: e.y + Math.sin(_base + _sw * _near) * 46}, 14);
          // 绕墙时必须把真正的掩体交给寻路，不能每帧追逐前方 46px 的临时点。
          if(behaviorOf(e).straightToCover || !clearWalkLine(L,e.x,e.y,g.x,g.y)){tx=g.x;ty=g.y;}
          else {tx=_ss.x;ty=_ss.y;}
          /* 冲刺：压出 / 追人这两种「主动往玩家方向挪」才加速，
             普通换掩体不加速 —— 不然人家一点都看不出区别 */
          const _rush = e.pushing || ((e.followT || 0) > 0 && dist(e.x, e.y, _target.x, _target.y) > TAC.followR);
          const _crk = Math.min(behaviorOf(e).coverRunSpdK, HUMAN.coverRunCap);
          speed = CFG.eSpeed * _crk * eMoveK(e) *
                  ((_rush && behaviorOf(e).useRunBoost) ? TAC.runBoost : 1);
          /* 倒着走要打折：他还看着你，却在往后撤 —— 腿是朝前的，身体是朝你的，
             不打折就是"举着枪平移倒飞"。正面压上不受影响。 */
          {
            /* 记忆点带有听觉/受击误差；判断“是否倒着跑”要看这次记忆对应的
               实体方向，否则随机误差会让同一次撤退忽快忽慢。B 势力目标同样适用。 */
            const _faceTarget=(e.lastKnownSource&&!e.lastKnownSource.dead&&
              factionWantsFight(e,e.lastKnownSource))?e.lastKnownSource:_target;
            const _toP = Math.atan2(_faceTarget.y - e.y, _faceTarget.x - e.x);
            /* 用 _base（朝掩体的方向）判断，别用 _aRaw：后者在下面才声明 */
            if (Math.cos(_base - _toP) < -0.35) speed *= (HUMAN.backpedalK || 0.72);
          }
          /* 边跑边盲扫：枪口对着你最后一次露头的位置，边冲边打，不追求命中 */
          if (_rush && e.ammo > 0 && e.reloading <= 0){
            if(!behaviorOf(e).ownCooldown) e.fireCd = (e.fireCd || 0) - dt;
            if (e.fireCd <= 0){
              e.blindShot = true;
              if (enemyFireWeapon(e, ei)){
                e.fireCd = Math.max(e.fireCd, TAC.pushFireGap);
              } else e.fireCd = 0.16;
            }
          }
        }
      } else {
        if (e.peekPhase === 'run' || !e.peekPhase){
          e.peekPhase = 'tuck'; e.peekT = HUMAN.tuck * reactK(e); e.tucked = true; e.feinted = false; e.hideT = 0; e.scanLook = false;
          e.pushing = 0; e.followT = 0;          /* 到了掩体，冲刺结束 */
          voiceSay(e, 'panic', 0.55, 2);        /* 刚进掩体：品着气自言自语一句 */
        }
        e.hideT = (e.hideT || 0) + dt;
        /* ---- ① 玩家换弹：压出去 ---- */
        e.pushCd = Math.max(0, (e.pushCd || 0) - dt);
        const _pdNow = dist(e.x, e.y, _target.x, _target.y);
        /* 架枪判定提到最前面：架着的时候 ①② 都不许抢位置 */
        const _targetReloading=enemyTargetReloading(e);
        const _holdNow = !e.sees && !e.tacticPhase && _pdNow < TAC.holdR && !_targetReloading &&
                         losBlocked(e.x, e.y, _target.x, _target.y);
        if (!_holdNow && _targetReloading && !enemyLowHp(e) && e.reloading <= 0 && e.ammo > 0 &&
            (e.pushCd || 0) <= 0 && _pdNow < TAC.pushR * behaviorOf(e).aggression && !e.tacticPhase){
          e.pushCd = TAC.pushCd;
            const _adv = pickAdvanceSpot(L, e, _threat);
          if (_adv && dist(e.x, e.y, _adv.x, _adv.y) > 24){
            /* 有更靠前的掩体：压过去，路上边跑边扫 */
            e.hideGoal = { x: _adv.x, y: _adv.y }; e.coverOK = 0; e.peekPhase = 'run';
            e.tucked = false; e.hideT = 0; e.pushing = 1;
            e.path = null; e.goal = null; e.chk = null; e.stuckT = 0;
          } else {
            /* 没有更近的掩体：不挪窝，直接拉出去打一轮 */
            e.tacticPhase = 'blind_fire';
    if (typeof tacBump === 'function') tacBump('blindFire'); e.tacStage = 'fire'; e.tacT = 0.9;
    if (typeof tacBump === 'function') tacBump('blindFire');
            e.tacLeft = 6; e.tacDir = (arenaRandom() < 0.5 ? -1 : 1);
            e.blindShot = true; e.tucked = false; e.peekPhase = 'tuck';
          }
        }
        /* ---- ② 玩家跑远了：换一个更靠前的掩体跟上（不朝玩家直线走） ---- */
        if (behaviorOf(e).canChase && !_holdNow && !enemyLowHp(e) && !e.sees && !e.pushing && _pdNow > TAC.followR){
          e.followT = (e.followT || 0) + dt;
          if (e.followT > TAC.followWait){
            const _adv2 = pickAdvanceSpot(L, e, _threat);
            if (_adv2 && dist(e.x, e.y, _adv2.x, _adv2.y) > 26){
              e.hideGoal = { x: _adv2.x, y: _adv2.y }; e.coverOK = 0; e.peekPhase = 'run';
              e.tucked = false; e.hideT = 0; e.followT = 0;
              e.path = null; e.goal = null; e.chk = null; e.stuckT = 0;
            } else e.followT = TAC.followWait * 0.5;
          }
        } else if (e.followT) e.followT = 0;
        /* ---- ③ 架枪：看不见你、离得近 —— 枪口压在你可能出现的位置，
                没机会就慢慢后退拉身位；一有机会立刻打，但**不改**缩头/探头状态。
                架枪是一个"占住"的状态：只要它在架，就不许 ①② 抢走位置，
                也不许后面的探头/巡逻状态机把枪口拧走。 ---- */
        if (_holdNow){
          e.holding = 1;
          enemyWatchCorner(e,e.lastKnown);
          if (enemyCanTakeShot(e, false, _threat) && (e.fireCd || 0) <= 0 && e.reloading <= 0 && e.ammo > 0){
            e.blindShot = true;
            if (enemyFireWeapon(e, ei)){
              /* 打出去了：fireCd 由武器自己的节奏决定 */
            } else e.fireCd = 0.16;
          }
          e.holdBackT = (e.holdBackT || 0) + dt;
          if (e.holdBackT < TAC.holdBackMax){
            /* 贴着枪口那面墙慢慢退，把身位优势拉回来；
               但只退「退了还在墙后」的那一步 —— 退成露头就不叫架枪了 */
            const _ba = Math.atan2(e.y - _target.y, e.x - _target.x);
            const _bp = safeSpot(L, { x: e.x + Math.cos(_ba) * TAC.holdBackSpd * dt,
                                      y: e.y + Math.sin(_ba) * TAC.holdBackSpd * dt }, e.r + 2);
            if (bodyBlind(_bp.x, _bp.y, e.r, _threat)){ e.x = _bp.x; e.y = _bp.y; }
            else e.holdBackT = TAC.holdBackMax + TAC.holdBackPause + 1;   /* 退无可退：就此站住 */
          } else if (e.holdBackT > TAC.holdBackMax + TAC.holdBackPause){
            e.holdBackT = 0;
          }
        } else { e.holding = 0; e.holdBackT = 0; }
        e.shakeOff = e.hideT < HUMAN.hideBuf;   /* 刚跑到掩体后先贴着墙喘口气，0.5 秒内不抖 */
        e.peekT = (e.peekT || 0) - dt;
        /* 看不见你的时候不能傻站：隔一会儿探头找一圈，或者贴着掩体挪半步 */
        if (!e.sees && e.peekPhase === 'tuck') e.scanT = (e.scanT || 0) + dt;
        if (!e.sees && e.peekPhase === 'tuck' && e.hideT > 0.6 && e.peekT <= 0.45){
          if ((e.scanT || 0) > 0.9){
            e.scanT = 0;
            if (arenaRandom() < 0.55){
              e.peekPhase = 'peek'; e.peekT = 0.5 * rand(0.8, 1.25);
              if (typeof tacBump === 'function') tacBump('peek');
              e.tucked = false; e.scanLook = true;
            } else {
              e.hideGoal = {x: g.x + rand(-26, 26), y: g.y + rand(-26, 26)};
              g = e.hideGoal; e.coverOK = 0;
              e.peekPhase = 'run'; e.tucked = false; e.hideT = 0; e.scanLook = false;
            }
          }
        }
        /* 缩头乌龟治不好的那种：在掩体后躲够了（或者你正在换弹 / 根本没朝这边看），
           就不要再等缩头计时器，立刻探出去 —— 这就是「打一枪就缩回」的骚扰，
           而不是躲到天荒地老。探头之后仍遵守上一发的枪械冷却。 */
        if (e.peekPhase === 'tuck' && !e.tacticPhase && !e.holding
            && e.ammo > 0 && e.reloading <= 0
            && (typeof tacticsPlus !== 'function' || tacticsPlus(e, L))
            && (((e.hideT || 0) > HUMAN.snapHold && (e.hideT || 0) < HUMAN.hideMax) || _targetReloading || !enemyTargetLookingAt(e,e.x,e.y))){
          /* 每次只记一次：这个状态下 peekPhase 会在 tuck/peek 之间来回切，
             用 dt 倒计时去抖（不用 uiT —— 测试里只跑 update，uiT 不会走），
             否则统计出来的是一串抖动而不是"闪了几次"。 */
          e.snapPeekLock = Math.max(0, (e.snapPeekLock || 0) - dt);
          if (typeof tacBump === 'function' && e.snapPeekLock <= 0){
            tacBump('snapPeek'); e.snapPeekLock = 0.35;
          }
          e.snapPeek = true;
          e.feinted = true;          /* 这一段别再插入假动作，先把枪打出去 */
          e.blindShot = false;
          e.peekPhase = 'peek';
          e.peekT = HUMAN.snapPeek;
          e.tucked = false;
          e.scanLook = false;
          /* 探头不增加瞄准延迟，但必须等上一发的枪械冷却结束。 */
        }
        if (e.peekT <= 0){
          if (e.peekPhase === 'tuck'){
            if (!e.feinted && (typeof tacticsPlus !== 'function' || tacticsPlus(e, L)) && arenaRandom() < HUMAN.feintP){
              /* 假动作：先快速探一下就缩回去，试探一下你的枪口 */
              e.feinted = true;
              e.peekPhase = 'feint'; e.peekT = (HUMAN.feintT || HUMAN.pushPeek) * reactK(e); e.tucked = false;
              if (typeof tacBump === 'function') tacBump('feint');
            } else {
              e.feinted = false;
              e.blindShot = false;   /* 要真探头了，盲射状态清掉 */
            e.peekPhase = 'peek'; e.peekT = HUMAN.peek * rand(0.85, 1.2) * reactK(e); e.tucked = false;
            if (typeof tacBump === 'function') tacBump('peek');
            }
          } else {
            e.peekPhase = 'tuck'; e.peekT = HUMAN.tuck * rand(0.8, 1.3) * reactK(e); e.tucked = true; e.snapPeek = false;
            e.scanLook = false;
          }
        }
        /* 躲太久：玩家一直架着就别傻等，盲射一枪或者换个掩体 */
        if (e.hideT > HUMAN.hideMax){
          e.hideT = 0;
          const _pd = dist(e.x, e.y, _target.x, _target.y);
          const _lk = e.lastKnown;
          if (_lk && dist(e.x, e.y, _lk.x, _lk.y) < 520 && (e.blindCd || 0) <= 0 && e.reloading <= 0 && e.ammo > 0
              && (typeof tacticsPlus !== 'function' || tacticsPlus(e, L))){
            e.blindCd = HUMAN.blindCd * reactK(e);
            /* 老六连招：贴着掩体横着拉出去半个身位，打两枪，再缩回来 */
            e.tacticPhase = 'blind_fire';
    if (typeof tacBump === 'function') tacBump('blindFire');
            e.tacStage = 'out';
            e.tacT = HUMAN.tacOut;
            e.tacLeft = HUMAN.tacShots;
            e.tacDir = (arenaRandom() < 0.5 ? -1 : 1);
            e.blindShot = true;
            e.tucked = false;
            e.peekPhase = 'tuck';
            /* 没什么好犹豫的：拉出去那一下就开枪，不等轮到 fire 阶段。
               必须把「上次看到你的方向」显式传进去：他还盯着你（sees 为真）时，
               enemyShoot 会改成直接朝你打，然后被自己面前的掩体挡下来，一枪都放不出去。 */
            if (e.fireCd<=0 && enemyFireWeapon(e, ei, Math.atan2(_lk.y - e.y, _lk.x - e.x))){ e.fireCd = Math.max(e.fireCd,HUMAN.tacGap); }
          } else if (!e.sees || _pd > HUMAN.closeR){
            const _alt = pickHideSpot(L, e, 170, false, _threat);
            if (_alt && (Math.abs(_alt.x - g.x) > 4 || Math.abs(_alt.y - g.y) > 4)){
              e.hideGoal = _alt; e.coverOK = 0; e.peekPhase = 'run'; e.tucked = false; e.hideT = 0;
            }
          }
        }
        tx = e.x; ty = e.y; speed = 0;
        /* 身位露在死角外（你侧移找了角度 / 刚挨了一枪）：贴着掩体边缘滑步挪回去 */
        /* 战术：拉出掩体快打两枪，再缩回来（直接改坐标，避免被后面的'站住'逻辑顶回去） */
        if (e.tacticPhase){
          const _pa3 = Math.atan2(e.y - _target.y, e.x - _target.x) + Math.PI / 2;
          const _side = e.tacDir || 1;
          e.tacT = (e.tacT || 0) - dt;
          e.tucked = false;                  /* 露在外面这几帧，打得到 */
          let _mv = 0;
          if (e.tacStage === 'out'){
            _mv = HUMAN.slideSpd * dt;
            if (e.tacT <= 0){ e.tacStage = 'fire'; e.tacT = 0; }
          } else if (e.tacStage === 'fire'){
            if(!behaviorOf(e).ownCooldown) e.fireCd = (e.fireCd || 0) - dt;
            if (e.fireCd <= 0 && (e.tacLeft || 0) > 0 && e.ammo > 0){
              e.blindShot = true;           /* 朝上次看到你的位置打，散布大，只求压制 */
              /* 同样要显式给方向：他还看得见你时，不给方向就会朝你本人打，
                 然后被自己面前的掩体挡下 —— 连招射几枪全是空扣扳机。 */
              const _lk2 = e.lastKnown;
              if (enemyFireWeapon(e, ei, _lk2 ? Math.atan2(_lk2.y - e.y, _lk2.x - e.x) : undefined)){
                voiceSay(e, 'blind', 0.45, 2);   /* 虚张声势：一边乱开枪一边喊 */
                e.tacLeft--;
                e.fireCd = Math.max(e.fireCd||0,HUMAN.tacGap);
              } else {
                /* 对着墙：这一发跳过，但连招照样往下走，别卡死在 fire 阶段。
                   连续两次打不出去 = 这个掩体根本放不出枪，直接换位，别原地空扣扳机。 */
                e.tacLeft--;
                e.tacFail = (e.tacFail || 0) + 1;
                e.fireCd = Math.max(e.fireCd||0,HUMAN.tacGap);
                if (e.tacFail >= 2){
                  e.tacFail = 0; e.tacticPhase = null; e.tacStage = null; e.blindShot = false;
                  const _alt2 = pickHideSpot(L, e, 170, false, _threat);
                  if (_alt2){ e.hideGoal = _alt2; e.coverOK = 0; e.peekPhase = 'run'; e.tucked = false; e.hideT = 0; }
                }
              }
            }
            if ((e.tacLeft || 0) <= 0){ e.tacStage = 'back'; e.tacT = HUMAN.tacBack; }
          } else {
            _mv = -HUMAN.slideSpd * 1.15 * dt;
            if (e.tacT <= 0){
              e.tacticPhase = null; e.tacStage = null; e.blindShot = false;
              e.tucked = true; e.peekPhase = 'tuck';
              e.peekT = HUMAN.tuck * rand(0.9, 1.2) * reactK(e);
              e.hideGoal = {x: e.x, y: e.y}; e.coverOK = 1; e.hideT = 0;
              e.bbT = 0; e.bbOK = bodyBlind(e.x, e.y, e.r, _threat) ? 1 : 0;
              e.bbPX = _target.x; e.bbPY = _target.y;
            }
          }
          if (_mv !== 0){
            const _sp2 = safeSpot(cur(), {x: e.x + Math.cos(_pa3) * _side * _mv, y: e.y + Math.sin(_pa3) * _side * _mv}, (e.r || 12) + 2);
            e.x = _sp2.x; e.y = _sp2.y;
          }
          tx = e.x; ty = e.y; speed = 0;
        }
        /* bodyBlind 要打三条射线，别每帧都算：缓存 0.12s，玩家挪动超过 14px 立刻重算 */
        if ((e.bbT || 0) <= 0){ e.bbT = 0.12; e.bbPX = _target.x; e.bbPY = _target.y;
          e.bbOK = bodyBlind(e.x,e.y,e.r,_threat) ? 1 : 0; }
        else if (Math.abs(_target.x - (e.bbPX || 0)) > 14 || Math.abs(_target.y - (e.bbPY || 0)) > 14){ e.bbT = 0; }
        if (!e.tacticPhase && !e.blindShot && !(e.slideT > 0) && !e.bbOK && (e.slideCd || 0) <= 0){
          const _pa = Math.atan2(e.y - _target.y, e.x - _target.x) + Math.PI / 2;
          let _sd = 0;
          /* 先试他上回躲的那一边：能缩回原位就缩回去，别左右来回抽 */
          const _pref = e.slidePref || 0;
          for (const _s of (_pref ? [_pref, -_pref] : [1, -1])){
            if (bodyBlind(e.x + Math.cos(_pa) * _s * 26, e.y + Math.sin(_pa) * _s * 26, e.r, _threat)){ _sd = _s; break; }
          }
          if (_sd){ e.slideDir = _sd; e.slidePref = _sd; e.slideT = HUMAN.slideDur; }
          else {
            /* 两边都露：这个掩体废了，换一个安全点跑过去 */
            const _nb = pickHideSpot(L, e, 120, true, _threat);   /* 只认真掩体：没墙的地方别瞎跑 */
            if (_nb && dist(e.x, e.y, _nb.x, _nb.y) > 30){
              e.hideGoal = {x: _nb.x, y: _nb.y}; e.coverOK = 0; e.peekPhase = 'run';
              e.tucked = false; e.hideT = 0; e.path = null; e.goal = null; e.chk = null; e.stuckT = 0;
            }
            /* 换不了就干脆别动：站着一微米一微米地蹭，看起来才像抽搐 */
            e.slideCd = 1.1;
          }
        }
        if ((e.slideCd || 0) > 0) e.slideCd = Math.max(0, e.slideCd - dt);
        if ((e.slideT || 0) > 0){
          e.slideT -= dt;
          e.tucked = false;                       /* 滑的时候身子是露的，但一直在挪 */
          const _pa2 = Math.atan2(e.y - _target.y, e.x - _target.x) + Math.PI / 2;
          tx = e.x + Math.cos(_pa2) * (e.slideDir || 1) * 34;
          ty = e.y + Math.sin(_pa2) * (e.slideDir || 1) * 34;
          speed = HUMAN.slideSpd * eMoveK(e);
          if (e.slideT <= 0 || bodyBlind(e.x, e.y, e.r, _threat)){
            /* 收尾时先确认一次：真的躲好了才停，别滑一半又开始下一次 */
            const _okNow = bodyBlind(e.x, e.y, e.r, _threat);
            e.slideT = 0;
            if (!_okNow){
              /* 还没到位：小步慢挪，别再触发新一轮滑步 */
              e.slideCd = 0.5;
            } else {
              e.slideDir = 0;
            }
            /* 刚刚可能已经进了 feint/peek，别把它打断 */
            if (e.peekPhase !== 'peek' && e.peekPhase !== 'feint'){ e.tucked = true; e.peekPhase = 'tuck'; }
            e.hideGoal = {x: e.x, y: e.y}; e.coverOK = 1;
          }
        }
        if (e.sees) e.ang = Math.atan2(_target.y - e.y, _target.x - e.x);
        else if(e.scanLook) enemyWatchCorner(e,e.lastKnown);
        /* \u53ea\u6709\u63a2\u5934\u90a3\u4e00\u4e0b\u624d\u6562\u5f00\u67aa */
        /* 职业兵：缩在墙后看不见你的时候，往两人中间丢一颗烟。
           每秒大约 smokeP 概率想扔，扔完进 smokeCd 冷却，所以一局里有节奏地断视线。 */
        if ((e.smokeCd || 0) > 0) e.smokeCd = Math.max(0, e.smokeCd - dt);
        if (e.tucked && !e.sees && enemyType(e).smokeP && arenaRandom() < enemyType(e).smokeP * dt * 3.0){
          enemyThrowSmoke(e, _threat);
        }
        if (!e.tacticPhase && enemyCanTakeShot(e, e.peekPhase === 'peek', _threat) && !e.tucked){
        if (!behaviorOf(e).ownCooldown) e.fireCd -= dt;
          /* 火力压制：只要还有子弹、还能照着那个方向打，就一直露着打，不按老节奏缩回去；
             打空了才缩回来换弹 —— 这样才有「拉出去一直压」的感觉 */
          if (e.peekPhase === 'peek' && !e.tacticPhase){
            /* 强制探头（snap peek）：那是「打一枪就缩回」的骚扰，不能让它一直压着打 */
            if (e.snapPeek){
              e.peekT = 0;
              e.suppT = 0;
            } else {
              /* 压着打，但别打成一个不会缩的木头人：最多连压 2.2 秒，然后强制缩回去换口气 */
              e.suppT = (e.suppT || 0) + dt;
              if (e.suppT > 2.2){ e.peekT = 0; e.suppT = 0; }
              else e.peekT = Math.max(e.peekT, TAC.suppressMin);
            }
          } else e.suppT = 0;
          if (e.fireCd <= 0){
            if (enemyFireWeapon(e, ei)){
              /* 打一枪就缩回：不问计时器，开完枪当场把身子收回去 */
              if (e.snapPeek){
                e.snapPeek = false;
                e.peekPhase = 'tuck'; e.tucked = true;
                e.peekT = HUMAN.snapTuck * rand(0.9, 1.15) * reactK(e);
                e.hideT = 0; e.scanLook = false;
              }
              if (e.ammo <= 0){
                e.reloading = enemyReloadTime(e);
                e.tucked = true; e.peekPhase = 'tuck';
                e.peekT = HUMAN.tuck * rand(0.85, 1.2) * reactK(e);
              }
            } else {
              /* 枪口正对着墙：这一发没打出去，等视线开了再说，别空扣扳机白白耗弹 */
              e.fireCd = 0.16;
            }
          }
        }
      }
    } else if (e.mode === 1 && e.lastKnown){
      acc.anyHunt = true;
      if(_targetEntity===player)acc.nearestHunt = Math.min(acc.nearestHunt, dist(e.x, e.y, player.x, player.y));
      tx = e.lastKnown.x; ty = e.lastKnown.y;
      const d = dist(e.x,e.y,tx,ty);
      e.alertT -= dt;
      if ((e.rushT || 0) > 0) e.rushT = Math.max(0, e.rushT - dt);

      if (e.lookT > 0){
        /* 到了现场：原地环视 1.5 秒，找到就咬住，找不到才撤 */
        e.lookT -= dt; speed = 0;
        if (!e.sees) e.ang = e.lookA + Math.sin((1.5-e.lookT)*2.2)*0.55;
        if (e.lookT <= 0){
          if (!e.sees){
            e.mode = 0; e.heard = false; e.sees = false;
            e.lastKnown = null; e.chk = null; e.stuckT = 0; e.path = null; e.goal = null;
            if (!(e.wait > 0)) e.wait = 0.5;
            logInfo('calm', '人机#' + (ei+1) + ' 到场看了一圈，没人 · 回巡逻');
          } else e.lookT = 0;
        }
      } else if (d < 26 && clearWalkLine(L, e.x, e.y, tx, ty)){
        /* 到场的判据必须带上「中间没有墙」：墙厚 26px 时，人贴在墙这一面，
           离墙那面的声音点也可能不到 26px —— 只看距离就会当场宣布「到了」，
           原地环视 1.5 秒再放弃，下一步脚步又把它叫回来，永远在墙根上下晃。 */
        e.lookT = 1.5; e.lookA = e.ang;
      } else {
        /* 卡住阈值放到 4.5 秒：撞墙先绕，别一顶墙就放弃 */
        /* 判断"有没有在推进"要看路走到第几个点，而不是直线距离——
           绕远路时直线距离会变大，旧写法会把正常绕行误判成走不过去 */
        if (!e.chk) e.chk = { pi: e.pi|0, t: 0, bestD: Infinity };
        if ((e.pi|0) > e.chk.pi){ e.chk.pi = e.pi|0; e.chk.t = 0; if (e.alertT < 3) e.alertT = 3; }
        else if (!e.path) e.chk.t += dt;
        /* 只在"真的靠近了"才续命：低难度敌人走得慢，走到一半 6 秒就到了，
           以前它会把"还在路上"当成"走不过去"而回头 —— 用户看到的就是
           "走到一半又转头走回去，然后再转头"。按距离进步续命，慢一点也不冤枉。 */
        {
          const _kd2 = dist(e.x, e.y, tx, ty);
          /* 门槛 40px：小于这个数的抖动（贴墙蹭）不算"有进展"，
             也不去动 chaseStall —— B 计划的 4 秒放弃仍然照旧生效，
             否则被箱子围死的敌人会永远不放弃。 */
          if (!isFinite(e.chk.bestD) || _kd2 < e.chk.bestD - 40){
            e.chk.bestD = _kd2;
            e.chk.t = 0;
            if (e.alertT < 3) e.alertT = 3;
          } else if (_kd2 < e.chk.bestD) e.chk.bestD = _kd2;
        }
        /* B 计划第二步：完全没有路线（门关了 / 被围住 / 墙挡住了）就不靠寻路，
           朝目标方向强行直线蹭（steerAngle 会贴墙滑），
           只有「蹭了 4 秒还没靠近 24px」才认定走不过去。 */
        const _DC = (typeof DataCHASE === 'object' && DataCHASE) ? DataCHASE : null;
        const _noRoute = !e.path || e.pi >= e.path.length;
        const _B = !!_DC && _DC.on !== false;
        /* 没路线时别只是"直线蹭"：先沿墙左右探一段，找个真能过去的缺口。
           玩家一进屋就卡在外面，十有八九是蹭错了方向。
           注意别在"路刚走完"那一刻抢方向盘：那时人已经站在门口了，
           再把他拽去院子另一头，就变成永远在门外转圈。 */
        /* 进度只看「到目标点最近到过多近」：目标点被新的脚步刷新得太远就重置基准 */
        if (_B){
          const _eps = _DC.progressEps || 24;
          if (!e.chaseRef || dist(e.chaseRef.x, e.chaseRef.y, tx, ty) > 300){
            e.chaseRef = { x: tx, y: ty }; e.chaseBest = d; e.chaseStall = 0;
            e.chaseWin = 0; e.chaseWinMin = d;
          }
          /* 每 1 秒结算一次：这一秒里离目标最近过多少，比之前的最好成绩还近 _eps 才算在推进 */
          e.chaseWinMin = (e.chaseWinMin === undefined) ? d : Math.min(e.chaseWinMin, d);
          e.chaseWin = (e.chaseWin || 0) + dt;
          if (e.chaseWin >= 1.0){
            if (d < _eps) { e.chaseBest = 0; e.chaseStall = 0; }
            else if (e.chaseWinMin < (e.chaseBest === undefined ? 1e9 : e.chaseBest) - _eps){
              e.chaseBest = e.chaseWinMin; e.chaseStall = 0;
            } else e.chaseStall = (e.chaseStall || 0) + e.chaseWin;
            e.chaseWin = 0; e.chaseWinMin = undefined;
          }
          e.chaseDirect = _noRoute ? 1 : 0;
        }
        if (_B && (e.chaseStall || 0) < 1.0) e.alertT = Math.max(e.alertT || 0, 1.2);
        const _giveUp = (_B
          ? ((e.chaseStall || 0) > (_DC.directGiveUp || 4.0) || e.stuckT > 4.5)
          : (e.chk.t > 6 || e.stuckT > 4.5));
        if (!e.navRecovery && (e.alertT <= 0 || _giveUp)){
          const why = e.alertT <= 0 ? '记忆耗尽' : (_B ? '靠近不了（直线也蹭不过去）' : (e.chk.t > 6 ? '走不过去' : '卡住太久'));
          /* 刚放弃的这块地方，几秒内别被"同一处"的脚步声立刻又叫回去 ——
             否则就是"走一半回头 → 又转头过去"的来回抖。声音换地方（>90px）照样立刻出动。 */
          if (e.lastKnown){
            e.deafSpot = { x: e.lastKnown.x, y: e.lastKnown.y };
            e.deafT = 3.0;
          }
          e.mode = 0; e.heard = false; e.sees = false;
          e.lastKnown = null; e.chk = null; e.stuckT = 0; e.lookT = 0; e.path = null; e.goal = null;
          e.chaseDirect = 0; e.chaseBest = undefined; e.chaseStall = 0; e.chaseRef = null;
          e.chaseWin = 0; e.chaseWinMin = undefined; e.pathViaDoor = false;
          e.doorTgt = null; e.sameRoom = false;
          if (!(e.wait > 0)) e.wait = 0.5;
          logInfo('calm', '人机#' + (ei+1) + ' 放弃追击（' + why + '）· 回巡逻');
        } else {
          /* 开发者指挥（m43351）：速度由"多少秒到达"反算成 e.devSpd（px/s），直接当本帧速度用 */
          speed = ((e.devOrd && e.devSpd) ? e.devSpd
                    : (e.sees ? CFG.eSpeed : CFG.eSpeed * (e.heard ? 0.55 : 0.8))) * eMoveK(e)
            * (arenaEventOn('frenzy') ? 1.4 : 1)
            * ((e.backupRushT || 0) > 0 ? (backupDef().spdK || 1) : 1);
        }
        /* 交战安全距离（仅测试区）：拿枪的不往前顶，被逼近就边退边打 */
        if (humanOn(L) && ET.canShoot && e.sees && !eStatusHas(e, 'fear')){
          const _pd = dist(e.x, e.y, _target.x, _target.y);
          const _safe=roomEngageDistance(L,e,_targetEntity||_target,ENGAGE.safe);
          if (_pd < _safe){
            tx = e.x; ty = e.y; speed = 0;
            if (_pd < _safe - ENGAGE.back){
              const _ba = Math.atan2(e.y - _target.y, e.x - _target.x);
              const _bx=e.x+Math.cos(_ba)*46,_by=e.y+Math.sin(_ba)*46;
              if(!levelRoomAt(L,e.x,e.y)||bladeWalkLine(L,e.r,e.x,e.y,_bx,_by)){
                tx=_bx;ty=_by;speed=ENGAGE.backSpd*eMoveK(e);
              }
            }
          }
        }
        /* 找射界（仅测试区）：知道你在那儿但被掩体挡着，就左右横移试角度，
           一旦视线通了，下一帧 enemySees() 自然为 true，它就停下开枪 */
        /* 架枪位（boundHold）不许横移找射界：它的任务就是钉在那儿压制，
           否则"站住的架枪手"会被这套横移拖着在场上来回蹭（实测 1.5 秒漂 110px）。 */
        if (humanOn(L) && ET.canShoot && !e.sees && !e.heard && e.lastKnown && !eStatusHas(e, 'fear')
            && !(e.bound&&e.bound.role==='over') && !(e.boundHold > 0)){
          const _kd = dist(e.x, e.y, e.lastKnown.x, e.lastKnown.y);
          if (_kd < ENGAGE.safe + 140 && losBlocked(e.x, e.y, e.lastKnown.x, e.lastKnown.y)){
            e.strafeT = (e.strafeT || 0) + dt;
            if (!e.strafeDir) e.strafeDir = (arenaRandom() < 0.5 ? -1 : 1);
            if (e.strafeT > ENGAGE.strafeHold){ e.strafeT = 0; e.strafeDir = -e.strafeDir; }
            const _bk = Math.atan2(e.y - e.lastKnown.y, e.x - e.lastKnown.x);
            const _pp2 = _bk + Math.PI / 2 * e.strafeDir;
            tx = e.x + Math.cos(_pp2) * 52; ty = e.y + Math.sin(_pp2) * 52;
            speed = ENGAGE.strafeSpd * eMoveK(e);
          } else { e.strafeT = 0; }
        }
        /* 远程挨枪的"压上"窗口。三条规矩（用户 m31080）：
           ① 不能直线送死 —— 每走 HIT_RUSH_LEG 秒就找掩体歇 HIT_RUSH_PAUSE 秒，还带一点绕行；
           ② 连挨两枪/吃爆炸就中断（在 absorbEnemyArmor 里处理）；
           ③ 压到 HIT_RUSH_STOP 就必须收手，转掩体对枪，绝不贴脸。 */
        if ((e.rushT || 0) > 0 && (e.rushLockT || 0) <= 0 && ET.canShoot && !eStatusHas(e, 'stun')){
          const _rd = dist(e.x, e.y, _target.x, _target.y);
          if (_rd <= HIT_RUSH_STOP || _rd <= ENGAGE.safe * HIT_RUSH_KEEP){
            /* 到点了：收手，就地找掩体进正常对枪 */
            e.rushT = 0; e.rushLeg = 0; e.rushPause = 0; e.rushCov = null;
            specSeekCover(e, _threat);
          } else if ((e.rushPause || 0) > 0){
            /* 躲那一下：挪到这一步挑好的掩体，挪到就停 */
            e.rushPause = Math.max(0, e.rushPause - dt);
            const _cv = e.rushCov;
            speed = 0;
            if (_cv){
              const _cd2 = dist(e.x, e.y, _cv.x, _cv.y);
              if (_cd2 > 10){
                tx = _cv.x; ty = _cv.y;
                speed = CFG.eSpeed * 0.92 * eMoveK(e);
              } else {
                e.rushCov = null;
              }
            }
            e.strafeT = 0;
          } else {
            /* 走这一步 */
            e.rushLeg = (e.rushLeg || 0) + dt;
            if (HIT_RUSH_LEG > 0 && e.rushLeg >= HIT_RUSH_LEG){
              e.rushLeg = 0; e.rushPause = HIT_RUSH_PAUSE;
              const _p = pickHideSpot(cur(), e, 120, false, _threat);
              e.rushCov = (_p && dist(e.x, e.y, _p.x, _p.y) < 420) ? { x: _p.x, y: _p.y } : null;
              if (!e.rushCov) e.rushPause = Math.min(e.rushPause, 0.45);
            } else {
              const _ra = Math.atan2(_target.y - e.y, _target.x - e.x);
              const _sw = HIT_RUSH_SWAY > 0 ? Math.sin((e.rushT || 0) * 5.2) * HIT_RUSH_SWAY : 0;
              tx = e.x + Math.cos(_ra + _sw) * 64; ty = e.y + Math.sin(_ra + _sw) * 64;
              speed = CFG.eSpeed * HIT_RUSH_SPD * eMoveK(e);
              e.strafeT = 0;
            }
          }
        }
      }
    } else {
      e.chk = null; e.stuckT = 0;
  e.slideT = 0; e.slideDir = 0; e.coverOK = 0; e.lookT = 0;
      if (e.mobaRoute && !e.devOrd){
        const point=mobaMarchPoint(e);
        if(point){ tx=point[0]; ty=point[1];
          /* m21343：军团推塔用自己的行军速度（不跟 CFG.eSpeed / 难度走） */
          speed = (e.mobaSpd || CFG.eSpeed * (e.marchK || 1)); }
      } else {
        if (!e.wp || !e.wp.length) e.wp = [[e.x, e.y]];
        e.i = ((e.i|0) % e.wp.length + e.wp.length) % e.wp.length;
        const w = e.wp[e.i];
        tx = w[0]; ty = w[1];
        if (dist(e.x,e.y,tx,ty) < 8){
          e.wait -= dt; speed = 0;
          if (e.wait <= 0){ e.i = (e.i+1)%e.wp.length; e.wait = (L.rules && L.rules.patrolWait != null) ? L.rules.patrolWait : 1.4; }
        } else speed = CFG.eSpeed * (e.marchK || 1);
        /* 巡逻点要是压在墙里 / 走不过去，就会一直撞         墙发抖。持续一秒没推进就换下一个点。 */
        const _pp = e._patrolPrev;
        const _pstep = _pp ? Math.hypot(e.x - _pp.x, e.y - _pp.y) : 99;
        e._patrolPrev = {x: e.x, y: e.y};
        if (speed > 0 && _pstep < 0.5){
          e.patrolStuck = (e.patrolStuck || 0) + dt;
          if (e.patrolStuck > 1.0){
            e.patrolStuck = 0;
            e.i = (e.i + 1) % e.wp.length;
            e.wait = (L.rules && L.rules.patrolWait != null) ? L.rules.patrolWait : 0.4;
            /* 听声调查时保留已经锁定的绕房路线。脱困方向也会优先朝当前路点，
               清掉路径会让下一帧 A* 在上下两个等价出口之间重新抽签。 */
            if(!(e.heard&&e.path&&e.pi<e.path.length)){e.path = null; e.goal = null;}
          }
        } else {
          e.patrolStuck = 0;
        }
      }
    }
    /* 愣神那 0.3 秒站在原地，不跑位 */
    if (humanOn(L) && (e.spotT || 0) > 0) speed = 0;
    /* 掩护位：架枪的那个人站住不动（boundTick 每帧续 0.2 秒） */
    if ((e.bound&&e.bound.role==='over')||(e.boundHold || 0) > 0){
      speed = 0; e.boundHold = Math.max(0, e.boundHold - dt);
    }
    /* 交替掩护里"跃进的那个"是冲过去的，不是走过去的 */
    if ((e.boundSpdK || 1) > 1) speed *= e.boundSpdK;
    /* 后坐力那一瞬间人被顶住：这 0.1 秒不走位，否则 AI 又把他走回来，
       屏幕上就只剩枪在抖、人纹丝不动 */
    if (humanOn(L) && behaviorOf(e).recoilStops && (e.recPush || 0) > 0.15) speed = 0;
    if (e.boostT > 0){
      e.boostT -= dt;
      speed *= (enemyType(e).boostMul || 1.6);    /* 被警报叫过来的路上跑得更急 */
    }
    /* m21422：速度封顶已移除 —— 用户要的是"该加速的时候加速"，
       之前一刀切封在巡航速度×1.12，把追击/冲刺也压平了。 */
    if (speed > 0){
      /* 敌人的脚步会漏出声纹，位置带一点抖动，只能判断个大概。
         停电关一直画（本来也看不见）；4-1 这种"视野外隐身"的关只在看不见的时候画。 */
      const _fsm = footstepMode(L);
      e.stepT = (e.stepT || 0) - dt;
      if (e.stepT <= 0){
        e.stepT = e.mode === 1 ? 0.32 : 0.48;
        if(typeof factionHearStep==='function')factionHearStep(e,e.x,e.y);
        if (typeof sfxEnemyStep === 'function') sfxEnemyStep(e);
        const _hid = (e.visA === undefined) ? true : (e.visA < 0.5);
        /* 声纹只是玩家看到的反馈；AI 听觉已经通过固定容量事件队列投递。 */
        if (_fsm && (_fsm === 1 || _hid) && dist(e.x, e.y, player.x, player.y) < maskedHearR(CFG.hearR * 1.7)){
          pushEnemyStep(e.x, e.y, e.mode === 1, false, e);
        }
      }
      /* 追"最后已知位置"时，如果中间隔着墙，就用算出来的路线拐进去。
         贴墙滑行只会沿墙皮平移，人在门口它也能从门口滑过去（玩家一进屋就卡门外）。
         只在这种"看得见目标就直冲、看不见才绕路"的情形下生效，开阔地不受影响。 */
      /* 自己算到路就照路走，不再让 navSteer 重算一遍把 e.pi 打回 0（会在门口来回抽） */
      const recoverChase=DataCHASE.on!==false&&e.mode===1&&!e.sees&&!e.fleeing&&!e.devOrd&&!e.bossKind&&!ET.fly&&!!e.lastKnown &&
        dist(tx,ty,e.lastKnown.x,e.lastKnown.y)<90;
      const _aRaw=recoverChase ? enemyChaseHeading(L,e,tx,ty,dt) : navSteer(L,e,tx,ty,dt);
      if(_aRaw===null)return;
      /* 转身滞后：刚看不见你还要再盯一会儿。
         没有这个，转身去掩体会立刻丢视野 → 又想转回来盯 → 来回翻，
         表现就是"九十度转弯再转弯、而且转得飞快"。 */
      if (e.sees) e.faceHoldT = (HUMAN.faceHold !== undefined ? HUMAN.faceHold : 0.55);
      else e.faceHoldT = Math.max(0, (e.faceHoldT || 0) - dt);
      if (!e.sees && !(e.faceHoldT > 0)) e.ang = normAng(e.ang + normAng(_aRaw-e.ang)*Math.min(1, dt*6));
      const ox = e.x, oy = e.y, squeeze=groundSqueezeRadius(L,e);
      const _wMoveK = enemyMoveK(e);          /* 扛火箭筒的走得慢 */
  let _wantStep = (ET.kind === 'blade' || ET.canShoot) ? Math.min(speed * _wMoveK * dt, e.bladeNavDistance) : speed * _wMoveK * dt;
  /* 人机同样吃风：顺风跑得快、逆风被顶住（和玩家用同一套 windMoveK，方向用转向后的 a） */
      /* 转向限速 + 拐角抄弧线：方向是转过去的，不是切过去的 */
      _ENEMY_MOVE_REQUEST.angle = _aRaw;
      _ENEMY_MOVE_REQUEST.dt = dt;
      _ENEMY_MOVE_REQUEST.step = _wantStep;
      const _mv = NavQuery.resolveMovement(L, e, _ENEMY_MOVE_REQUEST);
      const a = _mv.a;
      _wantStep *= _mv.k * ((typeof windMoveK === 'function') ? windMoveK(Math.cos(a), Math.sin(a)) : 1);
      e.x += Math.cos(a)*_wantStep;
      e.y += Math.sin(a)*_wantStep;
      unstickFromWalls(L,e,3,ox,oy,squeeze);
      pushOutTrucks(e);
      /* 贴墙滑行：直着走被墙卡住，就沿墙面的切线绕过去。
         不加这一段，人机会一直用胸口顶着墙角，看着就像卡在墙边。 */
      const _gotStep = Math.hypot(e.x - ox, e.y - oy);
      if (_wantStep > 0.2 && _gotStep < _wantStep * 0.55){
        const _pad = Math.max(8,squeeze??e.r);
        const _offs = [0.55, -0.55, 0.95, -0.95, 1.35, -1.35, 1.75, -1.75];
        let _entered = false;
        /* 第一优先：这条切线方向**能看见目标**——说明前面就是门洞/缺口，
           该拐进去，而不是继续沿着墙皮平移（玩家一进屋就卡门外的真正原因）。
           只在"直走被挡、正在滑行"时才算，开阔地不受影响。 */
        for (const _off of _offs){
          const _a2 = a + _off;
          if (freeLen(L, ox, oy, _a2, _wantStep + 8, _pad) < _wantStep + 2) continue;
          const _px2 = ox + Math.cos(_a2) * (_wantStep + e.r + 6);
          const _py2 = oy + Math.sin(_a2) * (_wantStep + e.r + 6);
          if (!clearWalkLine(L, _px2, _py2, tx, ty)) continue;
          e.x = ox + Math.cos(_a2)*_wantStep;
          e.y = oy + Math.sin(_a2)*_wantStep;
          for (const w3 of collisionWalls(L,e.x,e.y,squeeze??e.r)) pushOutCircle(e,squeeze??e.r,w3);
          pushOutTrucks(e);
          e.gapInT = 0.6;
          _entered = true;
          break;
        }
        if (!_entered){
          for (const _off of _offs){
            const _a2 = a + _off;
            if (freeLen(L, ox, oy, _a2, _wantStep + 8, _pad) < _wantStep + 2) continue;
            e.x = ox + Math.cos(_a2)*_wantStep;
            e.y = oy + Math.sin(_a2)*_wantStep;
            for (const w3 of collisionWalls(L,e.x,e.y,squeeze??e.r)) pushOutCircle(e,squeeze??e.r,w3);
            pushOutTrucks(e);
            break;
          }
        }
      }
      if ((e.gapInT || 0) > 0) e.gapInT = Math.max(0, e.gapInT - dt);
      /* 来回抽也算"没走"：按 1.2 秒的净位移判断，而不是单帧位移 */
      e.netT = (e.netT || 0) + dt;
      if (e.netT >= 1.2){
        if (e.netX === undefined){ e.netX = e.x; e.netY = e.y; e.netT = 0; }
        else {
        const net = dist(e.x, e.y, e.netX, e.netY);
        if (net < 26 && !e.forceT){
          e.stuckCount = (e.stuckCount || 0) + 1;
          /* 同一个坑里反复卡住就越逃越久：0.7s → 1.4s → 2.1s，不再反复试探 */
          e.forceT = 0.7 * Math.min(3, e.stuckCount);
          e.prevForceA = e.forceA; e.forceA = null;
          e.path = null; e.goal = null;
          logWarn('stuck', '人机#' + (ei+1) + ' 原地打滑（1.2 秒只挪了 ' + Math.round(net) + 'px）· 位置 ' + Math.round(e.x) + ',' + Math.round(e.y));
        }
        e.netX = e.x; e.netY = e.y; e.netT = 0;
        }
      }
      if (e.forceT > 0){
        e.forceT -= dt;
        if (!e.forceA){
          /* 找一条真正走得通的方向：16 个方向里挑空得最多的，尽量朝目标 */
          let bestA2 = null, bestS = -1e9;
          const _forceWp=(e.heard&&e.path&&e.pi<e.path.length)?e.path[e.pi]:null;
          const wantA = _forceWp?Math.atan2(_forceWp[1]-e.y,_forceWp[0]-e.x):Math.atan2(ty-e.y, tx-e.x);
          for (let k = 0; k < 16; k++){
            const a2 = k*Math.PI/8;
            const f2 = freeLen(L, e.x, e.y, a2, 160, 8);
            let da = Math.abs(a2-wantA); if (da > Math.PI) da = 2*Math.PI-da;
            let sc = f2 - da*22;
            /* 上一次往哪边躲就继续往那边：不加这个，
               目标正在正前方、左右一样空时，会两边一直来回抽 */
            if (e.prevForceA !== null && e.prevForceA !== undefined){
              sc += Math.cos(a2 - e.prevForceA) * 34;
            }
            /* 不要选一个“比现在更偏离目标”的逆向方向：
               人卡住后往后退一段再走回来，看起来就是左右晃。
               给“逆向”重罚，宁可沿着墙慢慢挪也别往回跑。 */
            sc += Math.cos(a2 - e.ang) * 55;
            if (Math.cos(a2 - wantA) < -0.2) sc -= 240;
            if (sc > bestS){ bestS = sc; bestA2 = a2; }
          }
          e.forceA = bestA2;
        }
        if (e.forceA !== null){
          const ox2 = e.x, oy2 = e.y;
          e.x += Math.cos(e.forceA)*speed*dt;
          e.y += Math.sin(e.forceA)*speed*dt;
          for (const w3 of collisionWalls(L,e.x,e.y,squeeze??e.r)) pushOutCircle(e,squeeze??e.r,w3);
      pushOutTrucks(e);
          e.x = clamp(e.x, 14, L.w-14); e.y = clamp(e.y, 14, L.h-14);
          if (!e.sees) e.ang = lerp(e.ang, e.forceA, Math.min(1, dt*6));
          if (dist(ox2,oy2,e.x,e.y) < speed*dt*0.3) e.forceT = Math.min(e.forceT, 0.05);
          return;
        }
      }
      /* 走了等于没走（顶着墙），累计卡住时间 */
      const moved = dist(ox,oy,e.x,e.y);
      if (moved > 0.4) e.walkAcc = (e.walkAcc || 0) + moved;
      else if ((e.walkAcc || 0) > 60){ e.walkAcc = 0; e.stuckCount = 0; }
      if (moved < speed*dt*0.3) e.stuckT = (e.stuckT || 0) + dt;
      else e.stuckT = Math.max(0, (e.stuckT || 0) - dt*0.8);
      e.x = clamp(e.x, 14, L.w-14); e.y = clamp(e.y, 14, L.h-14);

      const ls = e.logStuck || 0;
      if (e.stuckT > 3 && ls < 2){
        e.logStuck = 2;
        logError('stuck', '人机#' + (ei+1) + ' 卡死 3 秒没脱困 · 位置 ' + Math.round(e.x) + ',' + Math.round(e.y) + ' · 模式 ' + (e.mode === 1 ? '追' : '巡'));
      } else if (e.stuckT > 0.8 && ls < 1){
        e.logStuck = 1;
        logWarn('stuck', '人机#' + (ei+1) + ' 卡墙 0.8s · 位置 ' + Math.round(e.x) + ',' + Math.round(e.y));
      } else if (e.stuckT === 0 && ls > 0){
        e.logStuck = 0;
        logInfo('stuck', '人机#' + (ei+1) + ' 脱困，继续走');
      }
    }
  } finally { segEnd(); }
}

/* 建筑交战临时接管脚步，原巡逻和兵线路点由正常移动继续消费。 */
function enemyStructureEngage(L,e,dt,ET,ei){
  if (!ET.canShoot || e.sees || e.devCalm || eStatusNo(e,'noFire') || eStatusHas(e,'call') ||
      e.singleCoverPhase || (e.fromTruck && !e.deployCleared) || (nightBlindsAi() && flashK < 0.18))
    return false;
  const aim = enemyStructureTarget(L,e);
  if (!aim) return false;
  const {x,y,distance,wall} = aim;
  const angle = Math.atan2(wall.y+wall.h/2-e.y,wall.x+wall.w/2-e.x);
  if (e.roomSearch) roomSearchRelease(e);
  e.structureEngaged = wall;
  ensureEnemyArmor(e);
  if (e.barkT > 0) e.barkT -= dt;
  if (e.voiceCd > 0) e.voiceCd -= dt;
  e.ang = angle;
  if (!behaviorOf(e).ownCooldown) e.fireCd = Math.max(0,(e.fireCd || 0)-dt);
  const W = weaponCore(e.wid);
  const minRange = W.rocket ? (rpgDef().minRange || 130) + 2 : 0;
  const step = CFG.eSpeed * eMoveK(e) * enemyMoveK(e) * dt;
  if (!ET.static && distance < minRange){
    bladeMove(L,e,angle+Math.PI,Math.min(step,minRange-distance+1));
    return true;
  }
  if (!ET.static && distance > ENGAGE.safe + ENGAGE.back/4){
    const travel = distance - ENGAGE.safe;
    const tx = e.x + Math.cos(angle)*travel, ty = e.y + Math.sin(angle)*travel;
    if (bladeWalkLine(L,e.r,e.x,e.y,tx,ty)){
      /* 逼近建筑时吃 structFight 倍率：以前只乘 marchK（观战里 0.52），
         看着就是"慢吞吞走过去被机枪塔白打" —— 用户反馈的就是这一条 */
      bladeMove(L,e,angle,Math.min(step*structFightMarchK(e, e.marchK)*structFightSpdK(e),travel));
      return true;
    }
  }
  if (e.reloading <= 0 && e.ammo <= 0) e.reloading = enemyReloadTime(e);
  if (e.reloading <= 0 && e.ammo > 0 && e.fireCd <= 0)
    enemyFireWeapon(e,ei,undefined,undefined,{x,y,structureWall:wall});
  pushOutTrucks(e);
  return true;
}

/* ---------- 爆点（用户 m04521） ----------
   看见玩家的兵把位置喊给附近同伙，解决「一个兵发现你、旁边的队友还在原地找」。
   只在娱乐模式（calloutOn）生效。
   冲突处理：接收方只认离自己更近的点，换点要求领先 switchGain 且过了 recdCd，
   所以两个人同时爆点时不会两点来回覆盖让人机抽搐；自己看得见玩家的人不接收通报。 */
/* 还没落地的喊话：{at, x, y, from}。死了的发起人不再补发。 */
const _calloutQueue = [];
function calloutFlush(D, now){
  for (let i = _calloutQueue.length - 1; i >= 0; i--){
    const q = _calloutQueue[i];
    if (now < q.at) continue;
    _calloutQueue.splice(i, 1);
    const e = q.from;
    if (!e || e.dead || e.dummy) continue;
    calloutSpread(q.x, q.y, e, D);
  }
}
function calloutReceive(o, x, y, from, D){
  const now = (typeof uiT !== 'undefined') ? uiT : 0;
  const j = D.jitter || 0;
  const nx = x + (typeof fxRand === 'function' ? fxRand(-j, j) : 0);
  const ny = y + (typeof fxRand === 'function' ? fxRand(-j, j) : 0);
  const cur0 = o.calloutPt;
  if (cur0 && (now - cur0.t) < (D.staleT || 6)){
    /* 还有点没过期：只有明显更近才换，而且要隔一会儿，否则两个点会来回抢 */
    if ((now - cur0.t) < (D.recdCd || 0.9)) return false;
    const dNew = dist(o.x, o.y, nx, ny);
    const dOld = dist(o.x, o.y, cur0.x, cur0.y);
    if (dNew > dOld - (D.switchGain || 60)) return false;
  }
  o.calloutPt = { x: nx, y: ny, t: now, from: from };
  if (!o.sees){
    o.lastKnown = { x: nx, y: ny };
    o.lastKnownSource = null;
    o.mode = 1;
    o.heard = true;
    const mem = (typeof CFG !== 'undefined' && CFG.eMemory) ? CFG.eMemory : 6;
    o.alertT = Math.max(o.alertT || 0, mem + (D.alertExtra || 4));
  }
  return true;
}
/* 把一条喊话派发给附近听不到的同伙（真正落地的时刻由队列控制） */
function calloutSpread(px, py, e, D){
  const R = (typeof calloutRadius === 'function') ? calloutRadius() : (D.radius || 820);
  const R2 = R * R;
  const fac = (typeof combatFaction === 'function') ? combatFaction(e) : 'enemy';
  let told = 0;
  for (const o of enemies){
    if (o === e || o.dead || o.dummy || !(o.hp > 0)) continue;
    if (o.sees) continue;                       /* 自己看得见，不用别人报 */
    /* 正在包抄 / 转掩体 / 躲的人不接新点：他们已经有计划，换点会被拽着来回走 */
    if (typeof backupBusy === 'function' && backupBusy(o)) continue;
    if ((typeof combatFaction === 'function' ? combatFaction(o) : 'enemy') !== fac) continue;
    const dx = o.x - px, dy = o.y - py;
    if (dx*dx + dy*dy > R2) continue;           /* 以玩家为圆心：离战场太远的听不到 */
    if (calloutReceive(o, px, py, e, D)) told++;
    if (told >= (D.maxTold || 8)) break;
  }
  return told;
}
function enemyCalloutTick(L, e, dt){
  const D = (typeof DataCallout !== 'undefined') ? DataCallout : null;
  if (!D || D.on === false) return;
  if (typeof calloutOn === 'function' && !calloutOn()) return;
  const now = (typeof uiT !== 'undefined') ? uiT : 0;
  /* 到期的喊话先落地（不管当前这个兵在不在冷却里，队列是全局的） */
  if (_calloutQueue.length) calloutFlush(D, now);
  if ((e.calloutCd || 0) > 0) e.calloutCd = Math.max(0, e.calloutCd - dt);
  if ((e.calloutCd || 0) > 0) return;
  if (!e.sees || e.dead || e.dummy) return;
  if (typeof player === 'undefined' || !player || !(player.hp > 0)) return;
  /* 喊话有延迟：先出声，信息过 delay 秒才落到同伙耳朵里，给玩家留反应窗口 */
  const dj = (D.delayJitter || 0);
  const wait = Math.max(0, (D.delay === undefined ? 0.55 : D.delay) +
    (typeof fxRand === 'function' ? fxRand(-dj, dj) : 0));
  _calloutQueue.push({ at: now + wait, x: player.x, y: player.y, from: e });
  e.calloutCd = (D.cd || 2.4);
  if (typeof voiceSay === 'function') voiceSay(e, 'tac', 1, 2);
}

const _ENEMY_PERCEPTION_SAMPLE={};
function enemyTick(e, ei, frameDt, L, acc){
    if(!e)return;
    const ET=enemyType(e);
    let dt=lodEnemyStep(L,e,frameDt,ei);
    if(!dt)return;
    const dodging = !!e.nadeDodgeThreat;
    if (typeof enemyCalloutTick === 'function') enemyCalloutTick(L, e, dt);
    e.structureEngaged = null;
    /* m21393：推塔的兵有拴绳——目标离自己太远就放掉，回去沿路线推进，
       不然小兵会顺着追击链一路追进野区，三路就散了。 */
    if (e.mobaCreep && e.chk && typeof enemyIsFortification === 'function' && !enemyIsFortification(e.chk)){
      if (dist(e.x, e.y, e.chk.x, e.chk.y) > 340){ e.chk = null; e.lastKnown = null; e.lastKnownSource = null; e.heard = false; e.alertT = 0; }
    }
    const rememberedStructure = e.lastKnownSource;
    if (enemyIsFortification(rememberedStructure) &&
        (rememberedStructure.dead || rememberedStructure.destroyed || !(rememberedStructure.hp > 0))){
      e.lastKnownSource = e.lastKnown = e.chk = null;
      if (e.heardSource === rememberedStructure) e.heardSource = null;
      e.heard = false; e.alertT = 0; e.mode = 0;
      if (e.mobaRoute && !e.singleCoverPhase){
        if (eStatusClear(e,'fear')) Object.assign(e,ESTATUS_DEF.fear.onEnd);
        eStatusClear(e,'suppress');
        e.blindShot=false;
        e.path=e.goal=null;
      }
    }
    /* "刚放弃过这块地方"的静音计时（见放弃追击处）：跟状态机无关，每帧都走 */
    if((e.deafT||0)>0)e.deafT=Math.max(0,e.deafT-dt);
    if(behaviorOf(e).ownCooldown){
      e.fireCd=Math.max(0,(e.fireCd||0)-dt);
      e.specShotRecovery=Math.max(0,(e.specShotRecovery||0)-dt);
      e.specCoverCd=Math.max(0,(e.specCoverCd||0)-dt);
      if(e.tacticPhase&&(!e.hideGoal||!eStatusHas(e,'fear'))){e.tacticPhase=null;e.tacStage=null;e.tucked=false;}
    }
    // 关闭时不调用协同函数、不搜索队友、不创建协同状态。
    if (behaviorOf(e).canFlank === true && e.flank && !flankReady(e)) flankEnd(e, 'interrupted');
    if (e._dying) return;                  /* 自爆动画期间站定 */
    if (e.muzzle > 0) e.muzzle -= dt;
    /* 压上计时与压制锁：不管他现在是追人、躲掩体还是发呆都要走，否则躲起来就永远解不开锁 */
    if ((e.rushT || 0) > 0) e.rushT = Math.max(0, e.rushT - dt);
    if ((e.rushLockT || 0) > 0) e.rushLockT = Math.max(0, e.rushLockT - dt);
    /* 冷却与状态：全游戏只在这里递时间。
       写在别处的 "xxx -= dt" 都会被 _tStatusDef.js 的源码扫描抓出来。 */
    eCdTick(e, dt);
    eStatusTick(e, dt);
    if(e.towerOn && (e.towerOn.dead || e.towerOn.occ!==e))towerEnemyLeave(e);
    if(e.towerOn){
      enemyPerceive(e,concealed,dt);
      if(e.seesPlayer){
        acc.anySees=true;
        acc.nearestSeer=Math.min(acc.nearestSeer,dist(e.x,e.y,player.x,player.y));
      }
      if(e.barkT>0)e.barkT-=dt;
      if(e.voiceCd>0)e.voiceCd=Math.max(0,e.voiceCd-dt);
      return;
    }
    /* 投雷前摇是已经承诺的动作，必须先于室内搜索、负伤撤退、呼叫支援等
       会提前 return 的移动所有者推进。以前它只在 enemyMoveTick 里计时；
       roomSearchTick 一接管，这里永远走不到，throwT 和整只敌人就一起卡死。
       本帧若仍在前摇则保持站定；撒手/取消后才把控制权交给后续状态。 */
    let throwAdvanced = false;
    if ((e.throwT || 0) > 0){
      throwAdvanced = true;
      enemyThrowTick(L, e, dt);
      if (!dodging && (e.throwT || 0) > 0){
        if (e.barkT > 0) e.barkT -= dt;
        if (e.voiceCd > 0) e.voiceCd = Math.max(0, e.voiceCd - dt);
        /* 不再整只冻住：以 35% 速度边挪边拉环（m38055） */
        if (typeof enemyThrowShuffle === 'function') enemyThrowShuffle(L, e, dt);
        else pushOutTrucks(e);
        return;
      }
    }
    const allyTarget=companionEnemyTarget(e);
    if(!dodging&&allyTarget&&!eStatusHas(e,'stun')){
      if(e.roomSearch)roomSearchRelease(e);
      if(!behaviorOf(e).ownCooldown)e.fireCd=Math.max(0,(e.fireCd||0)-dt);
      if(e.reloading>0){e.reloading=Math.max(0,e.reloading-dt);if(!e.reloading)e.ammo=weaponCore(e.wid).cap;}
      if(e.ammo<=0&&e.reloading<=0)e.reloading=enemyReloadTime(e);
      companionEnemyEngage(e,allyTarget,dt);return;
    }
    const _stunned = eStatusHas(e, 'stun');
    /* 活人感：恐惧计时、看不见时愣神也要计时 */
    if (humanOn(L)){
      e.spotCd = Math.max(0, (e.spotCd || 0) - dt);
      e.recT = Math.max(0, (e.recT || 0) - dt);
      /* 后坐力真位移：recKick 这段时间里把 recPush 匀速退完 */
      if ((e.recPush || 0) > 0.15){
        const _rs = Math.min(e.recPush, e.recPush * Math.min(1, dt / Math.max(0.02, HUMAN.recKick)));
        const _ra = (e.recAng === undefined ? e.ang : e.recAng);
        const _rx = e.x - Math.cos(_ra) * _rs;
        const _ry = e.y - Math.sin(_ra) * _rs;
        // 后坐力只能移动这一小段；贴墙时不能用安全点搜索把人弹到另一边。
        if(bladeWalkLine(L,e.r||12,e.x,e.y,_rx,_ry)){e.x=_rx;e.y=_ry;}
        /* m44971：后坐力只查了墙，车壳没查 —— 背后停着一辆车时会被顶进车壳里（穿模）。
           推到这儿就得把车壳也算上，和正常走路同一把尺子。 */
        if (typeof pushOutTrucks === 'function') pushOutTrucks(e);
        e.recPush -= _rs;
      } else if (e.recPush){ e.recPush = 0; }
      e.glanceT = Math.max(0, (e.glanceT || 0) - dt);
      e.blindCd = Math.max(0, (e.blindCd || 0) - dt);
      e.bbT = Math.max(0, (e.bbT || 0) - dt);
      /* 转身动画：e.ang 仍是真实朝向（视野、射击用它），
         画面上用 e.angS 以固定角速度追过去，不再瞬间拗过来 */
      /* 角被写坏（NaN）时就地兜底；不做 2π 归一 —— π 会被翻成 -π，和测试/显示都对不上 */
      if (!Number.isFinite(e.ang)) e.ang = 0;
      if (e.angS === undefined || !Number.isFinite(e.angS) || Math.abs(e.angS) > 1e4) e.angS = e.ang;
      let _ad = e.ang - e.angS;
      while (_ad > Math.PI) _ad -= TAU;
      while (_ad < -Math.PI) _ad += TAU;
      const _amax = HUMAN.turnSpd * dt;
      e.angS += Math.abs(_ad) <= _amax ? _ad : (_ad > 0 ? _amax : -_amax);
      if (!Number.isFinite(e.angS)) e.angS = Number.isFinite(e.ang) ? e.ang : 0;
      /* 收敛后直接对齐；不要在这里按 2π 归一 —— 目标角在 π 附近时会被翻到 -π，差出一整圈 */
      if (Math.abs(e.ang - e.angS) < 0.02) e.angS = e.ang;
      /* 视野锥不能直接用 e.ang：开火、贴墙环视、环视扫动都会让 e.ang 单帧跳一大截，
         身体有 angS 兜着看不出来，锥子却会像抽筋一样左右甩。这里再给锥子单独做一个限速的显示角。 */
      if (!Number.isFinite(e.coneA)) e.coneA = e.angS;
      if (!Number.isFinite(e.coneA)) e.coneA = 0;
      if (!Number.isFinite(e.angS)) e.angS = e.coneA;
      {
        /* 不用 while 归一：万一角被写坏成一个巨大值，while 会真的转上亿次把页面卡死 */
        let _cd = e.angS - e.coneA;
        _cd = _cd - TAU * Math.round(_cd / TAU);
        const _cmax = 9.0 * dt;
        const _step = _cd > _cmax ? _cmax : (_cd < -_cmax ? -_cmax : _cd);
        e.coneA = e.coneA + _step;
        e.coneA = e.coneA - TAU * Math.round(e.coneA / TAU);
      }
      /* 恐惧的计时与"到期续不续"全在 eStatusTick 的 fear 钩子里（上面已经递过时间） */
      if (!e.sees && (e.spotT || 0) > 0) e.spotT = Math.max(0, e.spotT - dt);
    }
    const wasSees = e.sees;
    /* 被打下来的无人机不该继续报警。
       感知改成「看见当前敌对目标」：玩家照旧走 enemySees，
       另外允许看见敌对阵营的 NPC（A 打 B / B 打 A，见 52-factions.js） */
    if (typeof enemyPerceive === 'function') enemyPerceive(e, concealed, dt);
    else e.sees = enemySees(e, concealed);
    /* 车门口先清场：下车后至少离出生点 60px，才允许视野/战术把巡逻推进打断。
       否则一落地看见目标就会被安全射击距离钉在车旁，四个人堵成一团。 */
    if(e.fromTruck&&!e.deployCleared&&Number.isFinite(e.deployX)&&Number.isFinite(e.deployY)){
      if(dist(e.x,e.y,e.deployX,e.deployY)>=60)e.deployCleared=true;
      else{e.sees=false;e.seesPlayer=false;}
    }
    /* 火箭兵让开友军射界 / 拉开自爆距离：走一小段平滑位移再交还 AI。
       以前 rpgSidestep/rpgBackpedal 直接改坐标，受击唤醒反击时看起来会瞬移闪烁。 */
    if (!dodging && typeof rpgRepositionTick === 'function' && rpgRepositionTick(L, e, dt)){
      pushOutTrucks(e);
      return;
    }
    if (!dodging && typeof singleShotCoverTick === 'function') singleShotCoverTick(L, e, dt);
    // 健康且可追击的枪手不能无限续守同一个掩体；没射界时给等待设上限。
    if(!dodging && !e.singleCoverPhase && behaviorOf(e).canChase && !e.sees && e.hideGoal && e.lastKnown &&
       !enemyLowHp(e) && !e.fleeing && !eStatusHas(e,'stun') && !eStatusHas(e,'hurt') && !eStatusHas(e,'suppress')){
      e.coverWaitT=(e.coverWaitT||0)+(e.peekPhase==='run'?0:dt);
      if(e.coverWaitT>=2.4){
        e.coverWaitT=0;eStatusClear(e,'fear');e.hideGoal=null;e.coverOK=0;e.peekPhase=null;e.peekT=0;e.hideT=0;
        e.holding=0;e.tucked=false;e.cornerWatch=null;e.tacticPhase=null;e.tacStage=null;e.blindShot=false;
        e.slideT=0;e.slideDir=0;e.lookT=0;e.path=null;e.goal=null;e.chk=null;e.stuckT=0;
        e.mode=1;e.heard=true;e.alertT=Math.max(e.alertT||0,CFG.eMemory+4);
      }
    }else if(!dodging) e.coverWaitT=0;

    if (_stunned) e.sees = false;
    if (_stunned){
      /* 被震懵了：不清醒、不认路、不做任何战术动作。
         以前只把 spdK 压到 0.18，它照样有意识地往掩体挪、照样权衡要不要探头 ——
         那不是被炸懵，那是慢动作的战术大师。 */
      eStatusHold(e, 'stun');      /* 清哪些字段由 ESTATUS_DEF.stun.clear 说了算 */
      e.sees = false;
      /* 原地打转：隔一会儿换一个方向，谁也看不出他在看哪 */
      e.stunSpinT = (e.stunSpinT || 0) - dt;
      if (e.stunSpinT <= 0){
        e.stunSpinT = rand(0.45, 1.1);
        e.stunSpin = rand(0.5, 1.7) * (rand(0, 1) < 0.5 ? -1 : 1);
      }
      e.stunWob = (e.stunWob || 0) + dt;
      e.ang = normAng(e.ang + (e.stunSpin || 0) * dt);
    } else { e.stunSpin = 0; e.stunWob = 0; e.stunSpinT = 0; }    /* 被震懵：这期间什么都看不见 */
    /* 雨夜：黑暗里谁也看不见谁。闪电把街区照亮的那一下，你看得见他，他也看得见你 */
    if (nightBlindsAi() && flashK < 0.18) e.sees = false;
    /* 开发者指挥：被下令的单位整段路程"装作没看见人"，只按路点走（m42994） */
    if (e.devCalm){
      e.sees = false; e.seesPlayer = false;
      e.alertT = 0; e.mode = 0; e.lastKnown = null; e.heard = false;
    }
    if(behaviorOf(e).dropTacticR && e.sees && enemyTargetDistance(e)<behaviorOf(e).dropTacticR && e.tacticPhase){
      e.tacticPhase=null;e.tacStage=null;e.blindShot=false;e.tucked=false;
    }

    /* 摄像头 / 无人机：不打人，看见就拉警报叫人 */
    if (isAlarmer(e)){
      e.alarmCd = Math.max(0, (e.alarmCd || 0) - dt);
      e.pulse = Math.max(0, (e.pulse || 0) - dt*1.4);
      if (e.seesPlayer && factionWantsFight(e,player)){
        acc.anySees = true;
        acc.nearestSeer = Math.min(acc.nearestSeer, dist(e.x,e.y,player.x,player.y));
        if (!wasSees) e.pulse = 1;
        acc.anyAlarmSees = true;
        if (e.alarmCd <= 0) cameraAlarm(e);
      }
      return;
    }
    /* 兵线遭重创先脱离，撤退中的支援由 fleeCallBackup 处理。已经开始的呼叫可完成。 */
    if (!dodging && !_stunned && hasFeatL(L,'aiFlee') &&
        (e.mobaRoute ? (e.fleeing || (!eStatusHas(e,'call') && !(e.callWindT>0))) : !backupWants(e)) &&
        updateWoundedFlee(L,e,dt)){
      if(e.roomSearch)roomSearchRelease(e);
      return;
    }   /* 懵了：连逃跑都不会 */

    if (e.sees && !wasSees){
      const perceived=EnemyPerception.read(e,_ENEMY_PERCEPTION_SAMPLE);
      logWarn('spot', '人机#' + (ei+1) + ' 发现目标 · 距离 ' + Math.round(dist(e.x,e.y,perceived.targetX,perceived.targetY)));
    }
    if (e.seesPlayer && factionWantsFight(e,player) && e.sentinel && hunters.length && hunters.some(h => h.state === 'patrol')){
      let best = null, bdMin = 0;
      for (const h of hunters){
        const d = dist(h.x, h.y, player.x, player.y);
        if (!best || d < bdMin){ best = h; bdMin = d; }
      }
      if (best){ best.lastKnown = {x:player.x, y:player.y}; best.state = 'chase'; }
      logWarn('boss', '哨兵把猎手喊过来了');
    }

    /* 单发重武器撤向掩体的途中也在装填。否则简单难度会先跑路数秒、到位后
       才开始六秒换弹，既拖沓，也让目标记忆在重新接战前先过期。 */
    if (e.reloading > 0){
      e.reloading -= dt;
      if (e.reloading <= 0){
        const _rw = weaponCore(e.wid);
        e.ammo = isSingleShotWeapon(_rw) ? Math.max(1, _rw.cap | 0) : CFG.mag;
        logInfo('reload', '人机#' + (ei+1) + ' 换弹完成');
      }
    }

    if (dodging){
      if(e.seesPlayer){
        acc.anySees=true;
        acc.nearestSeer=Math.min(acc.nearestSeer,dist(e.x,e.y,player.x,player.y));
      }
      if(e.barkT>0)e.barkT-=dt;
      if(e.voiceCd>0)e.voiceCd=Math.max(0,e.voiceCd-dt);
      if(ET.kind==='blade')enemyBladeTick(L,e,dt,ET);
      return;
    }

    if (!_stunned && enemyStructureEngage(L,e,dt,ET,ei)) return;

    if ((e.suppressCd || 0) > 0) e.suppressCd = Math.max(0, e.suppressCd - dt);

    /* 爆炸武器可以直接向“刚听到的敌对声纹区域”开火，不必先走到现场并获得视觉。
       这条在视觉分支之前执行；真正看见目标时仍交给下面原有的精确交战逻辑。 */
    if (!_stunned && !e.sees && typeof explosiveSoundFireTick === 'function')
      explosiveSoundFireTick(e,ei,dt);

    /* 挨了枪之后的一小段：不管看不看得见，朝那个方向乱打一气
       （计时与"打完给冷却"在 eStatusTick 的 suppress 钩子里） */
    if (eStatusHas(e, 'suppress')){
      /* 架枪位（bound over）即使看得见也要压：它的任务是"让你不敢探头"，
         不是"看你一眼再决定"。原来这里只允许 !sees，导致跃进时一枪不放。 */
      const _boundOver = !!(e.bound && e.bound.role === 'over');
      const _tacticalOver=_boundOver;
      if ((!e.singleCoverPhase || e.singleCoverPhase === 'peek') && (!e.sees || _tacticalOver) && e.reloading <= 0 && e.ammo > 0 && (e.suppressN || 0) > 0){
        /* 架枪位是"持续压制"，不吃"打一枪要缓一会儿"的 ownCooldown 恢复时间 */
        if (!behaviorOf(e).ownCooldown || _tacticalOver) e.fireCd -= dt;
        if (e.fireCd <= 0){
          const _jit = e.suppressJit || 0.6;
          const _idx = e.suppressI | 0;
          const _step = e.suppressStep || (_jit * 2 / Math.max(1, (e.suppressN || 1)));
          const _off = (-_jit + _idx * _step) * (e.suppressDir || 1);
          const _pts=_tacticalOver&&Array.isArray(e.suppressPoints)?e.suppressPoints:null;
          const _sp=_pts&&_pts.length?_pts[_idx%_pts.length]:null;
          /* 战术压制只在一到两个真实出口点之间交替；普通受击盲扫仍保留扇面。 */
          const _shotA=_sp?Math.atan2(_sp.y-e.y,_sp.x-e.x)+rand(-.012,.012)
                          :e.suppressAng+_off+rand(-0.05,0.05);
          const _ssPrev = e.suppressShot;
          e.suppressShot = _tacticalOver;
          /* 架枪位是持续压制：清零"打一枪缓一会儿"的恢复计时，
             否则每一发之后 enemyShoot 都会因为 ownCooldown 拒掉下一发（实测 40 次只成 1 次）。 */
          if (_tacticalOver) e.specShotRecovery = 0;
          const _hit = enemyFireWeapon(e, ei, _shotA, _tacticalOver?1.35:2.8, _sp||undefined);
          e.suppressShot = _ssPrev;
          if (_hit){
            e.suppressI = _idx + 1;
            e.suppressN--;
            /* 盲扫要比瞄准射击慢不少，且必须遵守这把枪自己的射速：
               散弹枪不能像突击步枪那样一次打光一弹匣 */
            /* 盲扫也要按这把枪的射速来；散弹枪再加一道硬冷却，
               不然 8 颗弹丸连着喷就像没有冷却 */
            /* 压制射击本来就比瞄准射击快：架枪位允许把射速提到 suppressGap，
               但仍然不许突破枪本身的上限（霰弹枪另有 0.58 硬间隔，不能连喷）。 */
            const _erof = weaponCore(e.wid).rof;
            const _tacGap=_boundOver?(BOUND_DEF.sprayStep||.085):_erof;
            const _rof2 = _tacticalOver ? Math.min(_erof,_tacGap) : _erof;
            const _minGap = (e.wid === 'shotgun') ? 0.58 : 0;
            e.fireCd = Math.max(e.fireCd, e.suppressGap || 0.26, _rof2, _minGap);
            if (e.ammo <= 0){
              e.reloading = enemyReloadTime(e);
              logInfo('reload', '人机#' + (ei+1) + ' 弹匣打空 · 换弹 ' + e.reloading.toFixed(1) + 's');
            }
          } else e.fireCd = 0.16;
        }
      }
    }

    if (e.sees){
      const {targetX,targetY}=EnemyPerception.read(e,_ENEMY_PERCEPTION_SAMPLE);
      if (e.mode === 0) sfxAlarm();
      e.mode = 1; e.heard = false; e.lookT = 0;
      e.alertT = CFG.eMemory;
      e.lastKnown = {x:targetX, y:targetY};
      /* 刚看见你的那一瞬间不立刻开枪：先愣 walkDelay 秒再把脸转过来（白天反应更快） */
      if (!wasSees){
        const _hum = humanOn(L);
        /* 看到你就愣一下很真实，但每次都愣就傻了：同一个人有冷却 */
        e.spotT = _hum ? ((e.spotCd || 0) > 0 ? 0 : HUMAN.spot) : (L.rules ? L.rules.walkDelay : 0.32);
        if(behaviorOf(e).instantAim){
          e.spotT=Math.min(e.spotT||0,behaviorOf(e).instantAimClamp);
          e.fireCd=Math.min(e.fireCd||0,behaviorOf(e).instantAimClamp);
        }
        if (_hum && (e.spotCd || 0) <= 0) e.spotCd = HUMAN.spotCd;
        /* 发现你的那一睈：喊一声（不看弹出率，只靠冷却） */
        voiceSay(e, 'spot', 0.85, 3);
      }
      e.spotT = Math.max(0, (e.spotT || 0) - dt);
      if (e.spotT <= 0) e.ang = Math.atan2(targetY-e.y, targetX-e.x);
      if(e.seesPlayer&&factionWantsFight(e,player)){
        acc.anySees = true;
        acc.nearestSeer = Math.min(acc.nearestSeer, dist(e.x,e.y,player.x,player.y));
      }

      /* 包抄途中照常还击：只要真实看见当前敌对目标就允许按武器节奏开火。
         这里没有恢复包抄专用的墙角扫射；看不见目标时仍不会凭协同状态乱开枪。 */
      if ((!e.singleCoverPhase || e.singleCoverPhase === 'peek') && !e.tacticPhase && e.reloading <= 0 && e.ammo > 0 && e.spotT <= 0){
        if (!behaviorOf(e).ownCooldown) e.fireCd -= dt;
        if (e.fireCd <= 0 && enemyFireWeapon(e, ei)){
          /* 督军：一梭子三发，间隔压到 0.09 秒，站着对枪会被按住 */
          if (e.bossKind === 'warlord'){
            if ((e.burstLeft | 0) > 0){ e.burstLeft--; e.fireCd = 0.09; }
            else e.burstLeft = 2;
          }
          if (e.ammo <= 0){
            e.reloading = enemyReloadTime(e);
            logInfo('reload', '人机#' + (ei+1) + ' 弹匣打空 · 换弹 ' + e.reloading.toFixed(1) + 's');
          }
        }
      }
    }

    // 感知、状态和武器冷却照常处理；协同只接管主动移动，不能被普通追击覆盖路径。
    /* 紧急呼叫支援：前摇里站定（速度 0）、只做面朝玩家，不参与包抄/战术，但照常开枪 */
    /* 单发武器循环拥有主动移动权，不能在撤退途中被包抄/呼援/房间搜索改写目标。 */
    if (!_stunned && e.singleCoverPhase){
      if(e.roomSearch)roomSearchRelease(e);
      enemyMoveTick(L,e,dt,ET,_stunned,ei,acc,throwAdvanced);return;
    }
    if (!_stunned && eStatusHas(e, 'call')){
      if(e.roomSearch)roomSearchRelease(e);
      backupHold(e);return;
    }
    if (behaviorOf(e).canFlank === true && !e.roomSearch && flankTick(L, e, dt)) return;
    /* 紧急呼叫支援：走到这里说明没在包抄（包抄优先级更高），可以开喊了 */
    /* 被眩晕时下面不会进 backupTick，所以这里要把没喊完的那嗓子掐掉
       （否则它会一直挂着 callWindT，醒了照常喊完 —— 等于眩晕没打断） */
    if (_stunned && (e.callWindT || 0) > 0){ e.callWindT = 0; e.callDone = true; }
    if (!_stunned && backupTick(L, e, dt)){
      e.healK=0;
      if(e.roomSearch)roomSearchRelease(e);
      return;
    }
    if (roomSearchTick(L,e,dt)){
      if(enemyTargetEntity(e)===player){acc.anyHunt=true;acc.nearestHunt=Math.min(acc.nearestHunt,dist(e.x,e.y,player.x,player.y));}
      if(e.barkT>0)e.barkT-=dt;
      if(e.voiceCd>0)e.voiceCd=Math.max(0,e.voiceCd-dt);
      return;
    }

    /* 刀手：起手 → 前突 → 撤离/掩体等待，冷却结束才重新追击。 */
    if (ET.kind === 'blade' && enemyBladeTick(L, e, dt, ET)) return;

    enemyMoveTick(L, e, dt, ET, _stunned, ei, acc, throwAdvanced);
}

/* m23255 AI 分帧摊平：
   一帧最多在"敌人决策"上花 AI_BUDGET_MS 毫秒；花完就从断点收摊，
   下一帧接着往下轮（指针 aiCarry），于是 380 人的活被摊到好几帧。
   代价：慢机器上个别敌人的决策会晚 1~2 帧（≈16~33ms），肉眼基本看不出；
   收益：原本一帧 12~13ms 的 AI 峰值被压到一个预算以内，掉帧点变平滑。
   快机器上一帧就全干完了，行为与以前完全一致。 */
const AI_BUDGET_MS = 3.0;
let aiCarry = 0;
function aiNowMs(){
  return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
}
function updateEnemyFrame(L, frameDt, frozen){
  const enemyCount=enemies.length;
  const lodOn=!!(L.rules&&L.rules.lod);
  const first=lodOn&&enemyCount?(aiCarry%enemyCount):0;
  const acc={anySees:false,anyHunt:false,nearestSeer:9999,nearestHunt:9999,anyAlarmSees:false};
  segBegin('AI 决策');
  let done=0;
  const minN=Math.max(8,Math.ceil(enemyCount/3));
  const t0=aiNowMs();
  /* m23255：分帧摊平之后，某个敌人这一帧可能没轮到。
     但玩家贴到脸上必须立刻醒 —— 否则玩家能趁它没轮到的时候摸到背后。
     这里先做一趟只看距离的廉价唤醒（不思考、不寻路，380 人也就 0.02ms）。 */
  if(lodOn&&enemyCount&&player&&player.hp>0){
    const _wr=LOD_WAKE_R*LOD_WAKE_R;
    for(let i=0;i<enemyCount;i++){
      const e=enemies[i];
      if(!e||e.dead||e._lodTier!==2)continue;
      const dx=e.x-player.x, dy=e.y-player.y;
      if(dx*dx+dy*dy<=_wr){e._lodTier=0;e._lodSleep=0;}
    }
  }
  try {
    if(typeof factionFrameBegin==='function')factionFrameBegin();
    const counts=perfOn&&lodOn&&!frozen ? {near:0,mid:0,far:0,sleep:0} : null;
    for(let offset=0;offset<enemyCount&&!frozen;offset++){
      const index=(first+offset)%enemyCount, enemy=enemies[index];
      enemyTick(enemy,index,frameDt,L,acc);
      done++;
      /* 至少干 1/3（保证 3 帧内所有人轮到一次），再按预算收摊 */
      /* 每 16 个才看一次表：380 个人每帧都 performance.now() 本身就要 0.3ms */
      if((done&15)===0&&done>=minN&&aiNowMs()-t0>AI_BUDGET_MS)break;
      if (counts && enemy && !enemy.dead){
        if (enemy._lodSleep) counts.sleep++;
        else if (enemy._lodTier===2) counts.far++;
        else if (enemy._lodTier===1) counts.mid++;
        else counts.near++;
      }
    }
    if (counts) perfLod=counts;
  } finally { aiCarry=(aiCarry+done)||0; segEnd(); }
  return acc;
}

const _MAIN_PROJECTILE_PERMISSION_REQUEST={source:null,target:null};
const _MAIN_PROJECTILE_PERMISSION_RESULT={};
function mainProjectilePermission(source,target){
  _MAIN_PROJECTILE_PERMISSION_REQUEST.source=source;
  _MAIN_PROJECTILE_PERMISSION_REQUEST.target=target;
  return CombatQuery.projectilePermission(_MAIN_PROJECTILE_PERMISSION_REQUEST,_MAIN_PROJECTILE_PERMISSION_RESULT).allowed;
}
function updateMainProjectiles(L, dt, _frz){
  /* 子弹 */
  for (let i=bullets.length-1;i>=0;i--){
    const b = bullets[i];
    if (_frz){
      const _lv = (typeof devFreezeLv === 'function') ? devFreezeLv() : 1;
      if (_lv >= 2) continue;                /* Lv2：连玩家自己打出去的也冻住 */
      if (b.by !== player) continue;          /* Lv1：别人的子弹原地冻住 */
    }
    b.px = b.x; b.py = b.y;
    b.x += b.vx*dt; b.y += b.vy*dt;
    b.life -= dt;
    /* 火箭弹尾迹：按"飞过的距离"铺烟，而不是按时间 ——
       弹速 1000px/s，按时间铺会在高速时拉成一串稀稀拉拉的圆点。
       每 7px 盖一枚，烟团活 2.4~3.8 秒，慢慢胀开、往后飘、才散掉。 */
    if (b.rocket){
      if (typeof sfxRocketFly === 'function') sfxRocketFly(b.x, b.y);
      const _ra = Math.atan2(b.vy, b.vx);
      /* 按累计飞行距离等距铺点：帧内位置用上一帧→这一帧插值取，
         否则高速时同一帧的几个点会挤在一起，画出来是一串珠子 */
      const _seg = Math.hypot(b.x - b.px, b.y - b.py);
      if (b.trD === undefined) b.trD = 0;
      if (b.trNext === undefined) b.trNext = 0;
      const _d0 = b.trD;
      b.trD += _seg;
      const _px = Math.cos(_ra + Math.PI / 2), _py = Math.sin(_ra + Math.PI / 2);
      while (b.trNext <= b.trD){
        const _f = _seg > 0.0001 ? clamp((b.trNext - _d0) / _seg, 0, 1) : 1;
        const _sx = b.px + (b.x - b.px) * _f;
        const _sy = b.py + (b.y - b.py) * _f;
        const _off = fxRand(-4.5, 4.5);              /* 横向抖一点，烟柱才不像尺子画的 */
        rocketTrail.push({
          x: _sx + _px * _off, y: _sy + _py * _off, t: 0,
          dur: 2.8 + fxRand(0, 1.8),
          r0: 9.0 + fxRand(0, 3.0),
          r1: 38 + fxRand(0, 20),
          a: 0.34 + fxRand(0, 0.14),
          dx: -Math.cos(_ra) * fxRand(4, 18) + fxRand(-8, 8),
          dy: -Math.sin(_ra) * fxRand(4, 18) + fxRand(-8, 8)
        });
        b.trNext += 5 + fxRand(0, 2);
      }
      /* 贴着喷口再补一团更浓的，弹屁股后面不断档 */
      b.trHot = (b.trHot || 0) - dt;
      if (b.trHot <= 0){
        b.trHot = 0.09;
        rocketTrail.push({
          x: b.x - Math.cos(_ra) * 7, y: b.y - Math.sin(_ra) * 7, t: 0,
          dur: 0.8 + fxRand(0, 0.3), r0: 4.0, r1: 12 + fxRand(0, 5),
          a: 0.38, dx: -Math.cos(_ra) * 30, dy: -Math.sin(_ra) * 30
        });
      }
    }

    let dead = b.life <= 0 || b.x < -60 || b.x > L.w+60 || b.y < -60 || b.y > L.h+60;
    const truckHit=dead?null:projectileTruckHit(b);
    if(!dead&&companionBulletHit(b,truckHit)){poolReleaseAt(bullets,i);continue;}
    /* 门：子弹打得穿（扣门的血、不减速不改向）；火箭弹撞上就地炸。
       m45306：炮塔的穿墙炮弹直接穿过去，门也算建筑。 */
    if (!dead && doors.length && !b.turretRocket){
      if (b.rocket){ if (rocketDoorHit(b)) dead = true; }
      else doorHitAlongShot(b);
    }
    /* 物资堆：矮堆子不拦子弹，但擦过去会散（和门一个道理，只是不挡路） */
    if (!dead && typeof pileHitAlongShot === 'function') pileHitAlongShot(b);
    if (!dead && typeof decorHitAlongShot === 'function') decorHitAlongShot(b);
    if (dead && b.rocket && b.life <= 0) rocketBlast(b.x, b.y,b.by);   /* 飞到期了就地炸 */
    /* 车壳接触点和人体命中排序用同一个旋转车壳结果。 */
    if(!dead&&truckHit){
      const t=truckHit.truck;
      b.x=truckHit.x;b.y=truckHit.y;
      const angle=Math.atan2(b.vy,b.vx);
      // 引爆点向来路退半像素，避免爆炸视线从车壳边界发出时被自己遮断。
      if(b.rocket)rocketBlast(b.x-Math.cos(angle)*.5,b.y-Math.sin(angle)*.5,b.by);
      if (t === playerTruck && b.by !== player && mainProjectilePermission(b.by,player)) damageTruck(t,b.dmg||10,angle);
      truckSparks(b.x,b.y,angle);
      dead=true;
    }
    if (!dead && !playerInWall){
      for (const w of L.walls){
        if (segHitsRect(b.px,b.py,b.x,b.y,w)){
          /* m45306：炮塔的炮弹是"穿墙弹"，飞过整栋楼都不炸，只炸到人或飞到期 */
          if (b.turretRocket) continue;
          const _bAng = Math.atan2(b.vy, b.vx);
          /* 火箭弹：玻璃拦不住它（碎玻璃、引信不响、继续飞） */
          if (b.rocket && w.glass){ shatterGlass(w, b.x, b.y, _bAng); continue; }
          if (b.rocket){
            /* 这一帧可能已经飞进墙里 10 几像素，爆炸点要用射线进入墙面的精确交点，
               否则爆炸点会落在墙体内部，判遮挡时又被这堵墙自己挡住 → 近侧的人吃不到伤害 */
            const _len = Math.hypot(b.x - b.px, b.y - b.py) || 0.0001;
            const _t2 = rayEnter(b.px, b.py, Math.cos(_bAng), Math.sin(_bAng), w, _len);
            const _hx = (_t2 >= 0 && _t2 <= _len) ? b.px + Math.cos(_bAng) * _t2 : b.x;
            const _hy = (_t2 >= 0 && _t2 <= _len) ? b.py + Math.sin(_bAng) * _t2 : b.y;
            rocketBlast(_hx, _hy,b.by);
            if (w.brk || w.decor) damageWall(w, 620, _hx, _hy, _bAng,b.by);
            dead = true; break;
          }
          if (w.brk || w.decor) damageWall(w, (b.dmg || 10) * 0.55, b.x, b.y, _bAng,b.by);
          else impactWallFx(b.x, b.y, _bAng);
          dead = true; break;
        }
      }
    }
    if(!dead && b.turretRocket && b.by!==player && mainProjectilePermission(b.by,player)){
      const dx=b.x-b.px,dy=b.y-b.py,n=dx*dx+dy*dy;
      const t=n?clamp(((player.x-b.px)*dx+(player.y-b.py)*dy)/n,0,1):0;
      if(dist(b.px+dx*t,b.py+dy*t,player.x,player.y)<player.r+5){rocketBlast(b.px+dx*t,b.py+dy*t,b.by);dead=true;}
    }
    /* 火箭弹撞到敌人：以接触点引爆 */
    if (!dead && b.rocket && typeof enemies !== 'undefined' && enemies){
      for (const e of enemies){
        if (!e || e.dead || e===b.by) continue;
        if (!mainProjectilePermission(b.by,e)) continue;
        if (dist(b.x, b.y, e.x, e.y) < (e.r || 12) + 8){ rocketBlast(b.x, b.y,b.by); dead = true; break; }
      }
    }
    /* 门、车、墙和落点前的人体都已先判定；仍在飞的火箭抵达计算落点时精确空炸，
       不能再沿同一射线飞到地图另一头。 */
    if(!dead&&b.rocket&&typeof rocketLandingFusePoint==='function'){
      const _fuse=rocketLandingFusePoint(b);
      if(_fuse){b.x=_fuse.x;b.y=_fuse.y;rocketBlast(_fuse.x,_fuse.y,b.by);dead=true;}
    }
    if (!dead && !b.rocket && mainProjectilePermission(b.by,player)){
      const shieldHit=playerShieldBulletHit(b);
      if(shieldHit){playerShieldImpact(b,shieldHit);dead=true;}
    }
    if (!dead && !b.rocket && !player.god && mainProjectilePermission(b.by,player) && dist(b.x,b.y,player.x,player.y) < player.r + 3){
      if (player.god){
        player.flash = 1; hitFlash = 0.5; camShake = 0.22;
        logInfo('god', '无敌挡下 ' + b.dmg + ' 点伤害');
        dead = true;
      } else {
        const _bdm2 = guardDamage(b.dmg * (ar ? (1 - (ar.armor || 0)) : 1));
        player.hp -= absorbArmor(_bdm2, 'bullet');
        hurtNum(_bdm2);
        if (cur().healHint) player.hintT = 5;      /* 受伤了：提示该打药了 */
        player.flash = 1; hitFlash = 1; camShake = 0.55;
        stOnHurt(b.dmg, 'bullet');
        if (player.hp <= 0) markDeath('bullet', b.by, _bdm2, Math.atan2(b.vy, b.vx));
        logWarn('hurt', '中弹 · -' + b.dmg + ' HP · 剩 ' + Math.max(0, Math.round(player.hp)));
        sfxHurt();
        dead = true;
      }
    }
    if (dead) poolReleaseAt(bullets,i);
  }
}
const ProjectileSystem=Object.freeze({
  update:function(L,dt,frozen){
    /* 火箭尾迹：自己胀开、往后飘、慢慢淡掉 */
    for (let index = rocketTrail.length - 1; index >= 0; index--){
      const trail = rocketTrail[index];
      trail.t += dt;
      if (trail.t >= trail.dur){ rocketTrail.splice(index, 1); continue; }
      trail.x += trail.dx * dt;
      trail.y += trail.dy * dt;
      const damping = Math.max(0, 1 - dt * 0.55);
      trail.dx *= damping; trail.dy *= damping;
    }
    segBegin('弹道');
    try { updateMainProjectiles(L,dt,frozen); } finally { segEnd(); }
  }
});

function update(dt,shareNavBudget=false){
  /* m36161：加载门期间时间冻住，一切都不推进 */
  if (typeof state !== "undefined" && state === "dzload") return;
  if(!shareNavBudget)resetNavigationWork(!!cur().rules?.lod);
  if (arenaSlotUI) return;
  lastDt = Math.min(Math.max(dt, 0), 0.05);
  if (!(typeof devFrozen === "function" && devFrozen())) try { updateDummies(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('42-actors', err); }
  /* 大地图分块：只在玩家跨格子时重算 */
  if (player) { segBegin('分块'); try { updateChunks(player.x, player.y, cur()); } catch (err){ if (typeof reportErr === 'function') reportErr('42-actors', err); } segEnd(); }
  /* 每帧的重算预算：网格变过之后，只有 3 个敌人能在这帧重新寻路，
     剩下的继续走旧路，下一秒轮到。摊平补丁带来的尖峰。 */
  navRepathBudget = NAV_REPATH_PER_FRAME;
  /* 命中定格：这几十毫秒里世界不动，只有特效和镜头继续走。
     放在最前面，连玩家自己的移动也一起定住 —— 这才是"顿"一下。 */
  if (hitStopT > 0){
    const _was = hitStopT;
    hitStopT = Math.max(0, hitStopT - dt);
    if (_was > 0 && hitStopT === 0 && ar && ar.cinePending) finalizeCineKill();
    updateImpactFx(dt);
    if (camShake > 0) camShake = Math.max(0, camShake - dt*3);
    if (hitFlash > 0) hitFlash = Math.max(0, hitFlash - dt*2.2);
    if (armorBreakT > 0) armorBreakT = Math.max(0, armorBreakT - dt*2.4);
    updateBrkFx(dt);          /* 定格时碎块也照飞：这一下砸得才够实 */
    return;
  }
  /* 定格之后的极短慢放：让"打实了"这一下在时间里多待几帧 */
  if (slowT > 0){ slowT = Math.max(0, slowT - dt); dt *= 0.42; }
  const L = cur();
  /* 观战图（斗蛐蛐）：玩家保持隐形无敌，没交火的人继续往对面走。放在玩家移动之前，
     这样 grace/god 在 AI 那一帧里就已经生效了。 */
  if (typeof mobaTick === 'function' && typeof mobaOn === 'function' && mobaOn(L)) mobaTick(dt, L);
  if (typeof cricketTick === 'function' && typeof cricketOn === 'function' && cricketOn(L)) cricketTick(dt, L);
  /* 开发者暂停：整个世界冻住，只有玩家和玩家自己的子弹照常走 */
  const _frz = (typeof devFrozen === "function") && devFrozen();
  /* 抽卡展示是“暂停着看”的，计时得在 freeze 早退之前走，不然动画会卡住 */
  if (ar && ar.drawShow && !ar.drawShow.closed) ar.drawShow.t += dt;
  /* 老实抽卡的整屏界面同样把世界定住了：摇奖计时必须走在这里，
     放在 arenaUpdate 里的话 freeze 早退会让它永远停在“她在翻你的牌…” */
  if (ar && ar.er && !ar.over && typeof erTick === 'function') erTick(dt);
  /* 自救 2：处决特写（cinePending）是靠 hitStop 归零那一刻收尾的。
     如果这一下是爆炸/火箭打死的（当时没有 hitStop），收尾就永远不会来：
     boss 一直躺着不死、清波奖励也发不出来，人就卡在那儿了。等 1.2 秒强制收尾。 */
  if (ar && ar.cinePending && !ar.over){
    if (hitStopT > 0){ ar._cineWait = 0; }
    else {
      ar._cineWait = (ar._cineWait || 0) + dt;
      if (ar._cineWait > 1.2){ ar._cineWait = 0; try { finalizeCineKill(); } catch (err){ if (typeof reportErr === 'function') reportErr('42-actors', err); } }
    }
  } else if (ar) ar._cineWait = 0;
  /* 自救：整屏界面已经关了（er / 洗牌 / 选卡 / 翻牌都没了），却还挂着 freeze ——
     再往下就会半边黑、HUD 全没、人也动不了。这里统一把过期标志放行。 */
  if (ar && ar.freeze && !ar.over && !(ar.er && ar.er.stage) && !ar.shuf && !ar.choices
      && !(ar.drawShow && !ar.drawShow.closed)) ar.freeze = false;
  if (ar && (ar.freeze || ar.shuf || ar.choices || (ar.drawShow && !ar.drawShow.closed))){
    ar.freeze = true;              /* 界面存在就暂停，不让过期的 freeze 标志放行战斗 */
    return;
  }
  const activeDt = !_frz && player.hp > 0 ? dt : 0;
  timeAlive += activeDt;
  if(activeDt && blastComradeQueue.size){
    segBegin('爆炸后战术反应');
    try { tickBlastComradeFalls(L); } finally { segEnd(); }
  }
  if(navWork.limited){
    segBegin('寻路队列');
    try { advanceNavigationWork(L); } finally { segEnd(); }
  }
  if (!_frz) try { updateNades(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('42-actors', err); }
  if (!_frz) try { if (typeof updateTrips === 'function') updateTrips(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('42-actors', err); }
  try { if (typeof updateBlastFilter === 'function') updateBlastFilter(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('42-actors', err); }
    try { if (typeof updateRocketFx === 'function') updateRocketFx(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('42-actors', err); }
  if (!_frz) try { updateFlares(dt); updateAirdrops(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('42-actors', err); }
  player.grace = Math.max(0, player.grace - dt);
  if (msgT > 0) msgT -= dt;
  if (barkCoolT > 0) barkCoolT = Math.max(0, barkCoolT - dt);
  if (ar && ar.tierMsgT > 0) ar.tierMsgT -= dt;
  if (runBannerT > 0) runBannerT -= dt;
  if (exitOpen) runT += dt;
  if (camShake > 0) camShake = Math.max(0, camShake - dt*3);
  if (hitFlash > 0) hitFlash = Math.max(0, hitFlash - dt*2.2);
  if (armorBreakT > 0) armorBreakT = Math.max(0, armorBreakT - dt*2.4);
  updateImpactFx(dt);
  updateBrkFx(dt);
  /* 墙挨打时亮一下的那个白闪 */
  for (const w of L.walls){
    if (!w.brk) continue;
    if (w.hitT > 0){
      w.hitT = Math.max(0, w.hitT - dt);
      if (w.hitT === 0) staticInvalidate();      /* 白闪结束：把它还回静态层，不然后面就一直白着 */
    }
    if (w.sndT > 0) w.sndT = Math.max(0, w.sndT - dt);
  }
  /* 受击硬直的时间由每个敌人的 eStatusTick 统一走（这里不再手写递减） */
  if (brkShake > 0){ camShake = Math.max(camShake, brkShake * 0.6); }
  /* 玩家 */
  let mx=0, my=0;
  if (keys[BINDS.left]||keys['ArrowLeft'])  mx -= 1;
  if (keys[BINDS.right]||keys['ArrowRight']) mx += 1;
  if (keys[BINDS.up]||keys['ArrowUp'])    my -= 1;
  if (keys[BINDS.down]||keys['ArrowDown'])  my += 1;
  /* 坐在驾驶室里：走的是车，不是人 */
  if (playerTruck){
    if (player.hp <= 0) truckExit();
    else { truckDrive(dt, mx, my); mx = 0; my = 0; }
  }
  /* 静步：默认按住；设置里改成"点击切换"之后，按一下切静步、再按一下跑起来 */
  const _walkKey = !!(keys[BINDS.crouch] || keys['ControlLeft']);
  if (CFG.walkToggle){
    if (_walkKey && !player.walkKeyPrev) player.walkToggleOn = !player.walkToggleOn;
    player.walkKeyPrev = _walkKey;
    player.crouch = !!player.walkToggleOn;
  } else {
    player.walkKeyPrev = false;
    player.walkToggleOn = false;
    /* walkInvert 的关卡：默认就是静步，按住 Shift 才是跑 */
    const _inv = !!(cur().rules && cur().rules.walkInvert);
    player.crouch = _inv ? !_walkKey : _walkKey;
  }
  if (L.boss && player.crouchLock) player.crouch = true;   /* 拉满三个电闸前只能静步 */
  /* 坐在椅子上：人钉在椅子正前方那一点，按方向键或 E 起身 */
  if (player.seat){
    if (mx || my){ standUp(); }
    else {
      mx = 0; my = 0;
      if (player.seatPos){
        player.x = player.seatPos.x;
        player.y = player.seatPos.y;
        player.vx = 0; player.vy = 0;
      }
      /* 椅子被打碎了就自动站起来，别整个人悬在空中 */
      if (player.seat.dead || player.seat.broken) standUp();
    }
  }
  player.moving = !!(mx||my);
  if (player.stunT > 0){ player.moving = false; }   /* 被撞晕：这半秒动不了 */
  if (dyingT > 0){ player.moving = false; player.lungeT = 0; player.recoverT = 0; player.kickX = 0; player.kickY = 0; }
  /* 体力：只在写了 rules.stamina 的关卡里生效（目前只有 3-4），
     不会影响其他关卡，也不会影响割草。跑走耗体力，静步缓慢回。 */
  if (state === 'play'){
    const _sl = cur();
    if (_sl && _sl.rules && _sl.rules.stamina){
      const _max = player.stamMax || 100;
      if (player.moving && !player.crouch) player.stam -= 26 * dt;
      else if (player.crouch) player.stam += 8.5 * dt;
      else player.stam += 13 * dt;
      player.stam = clamp(player.stam, 0, _max);
      if (player.stam <= 0.01){
        player.stamLock = true;
        if (player.stamMsgT <= 0){ setMsg('气喘不过来了 · 只能慢走', 1.4); player.stamMsgT = 2.2; }
      }
      if (player.stam > _max * 0.35) player.stamLock = false;
      if (player.stamLock) player.crouch = true;
      if (player.stamMsgT > 0) player.stamMsgT -= dt;
    }
  }
  if (player.moving){
    const len = Math.hypot(mx,my);
    const healK = (player.heal && !ar) ? 0.30 : 1;   /* 打药时走得很慢；战斗，爽！！不减速 */
    /* 「无视地形」：人在墙里的时候走得极慢 */
    let sunkK = 1;
    if (ar && ar.noclip){
      for (const w of L.walls){
        if (player.x > w.x - player.r && player.x < w.x + w.w + player.r &&
            player.y > w.y - player.r && player.y < w.y + w.h + player.r){ sunkK = 0.22; break; }
      }
    }
    const recK = (player.recoverT > 0) ? 0.35 : 1;
    /* 举着盾走不快：一块钢板举在身前，跑起来重心全乱 */
    const shieldK = playerShieldUp() ? 0.58 : 1;
    /* 端着火箭筒走路沉：按武器表里的 moveK 算 */
    const _wMoveK = (player.gun && WEAPONS[player.gun.wid] && WEAPONS[player.gun.wid].moveK) || 1;
    /* 铁丝网：踩在网里走不动（0.42 倍），这是它唯一的"物理"作用 */
    const wireK = player.inWire ? ((typeof WIRE_DEF !== 'undefined' && WIRE_DEF.slowK) || 0.45) : 1;
    /* 扔完手雷的后摇：收势那半秒走不快 */
    const nadeK = (player.throwCd > 0) ? NADE_RECOVER_K : 1;
    /* 大风：顺着跑更快、顶着风跑不动（只影响玩家自己的移动） */
    const windK = (typeof windMoveK === 'function') ? windMoveK(mx/len, my/len) : 1;
    const _obsCam = (typeof spectatorViewOn === 'function' && spectatorViewOn());   /* 观战图：玩家只是摄像机，蹲下不该拖慢镜头 */
  const sp = CFG.pSpeed * (ar ? ar.spdMul : 1) * ((player.crouch && !_obsCam)?0.55:1) * healK * sunkK * recK * shieldK * _wMoveK * wireK * nadeK * (player.cricketSpdK || 1) * windK * dt;
    player.x += mx/len*sp; player.y += my/len*sp;
  }
  /* 后坐力的"余速"：开枪那一下给一个往后的速度，然后像刹车一样衰减掉。
     这样跑着开枪是"被推了一下"，而不是移动被硬生生掐断 —— 之前那版是直接改坐标，
     和奔跑的位移打架，看起来就像卡了一帧。放在碰撞之前，所以还是撞不进墙。 */
  if (player.kickX || player.kickY){
    player.x += player.kickX*dt; player.y += player.kickY*dt;
    const damp = Math.max(0, 1 - dt*9.5);
    player.kickX *= damp; player.kickY *= damp;
    if (Math.abs(player.kickX) < 4) player.kickX = 0;
    if (Math.abs(player.kickY) < 4) player.kickY = 0;
  }
  if (player.recoverT > 0) player.recoverT = Math.max(0, player.recoverT - dt);
  /* 体力恢复：停手一小会儿才开始慢慢回，不能连续冲刺 */
  if (player.meleeStaDelay > 0) player.meleeStaDelay = Math.max(0, player.meleeStaDelay - dt);
  else if ((player.meleeSta || 0) < (player.meleeStaMax || 100))
    player.meleeSta = Math.min(player.meleeStaMax || 100, (player.meleeSta || 0) + 12 * dt);
  for (let _ti = meleeTrail.length - 1; _ti >= 0; _ti--){
    meleeTrail[_ti].t += dt;
    if (meleeTrail[_ti].t >= meleeTrail[_ti].dur) meleeTrail.splice(_ti, 1);
  }
  /* 观战图里玩家就是一台摄像机：不跟人挤、不撞墙、不撞车、不挡门 ——
     否则掩体一多，左右挪视角会被墙卡住，看不了全场 */
  const _crkCam = (typeof spectatorViewOn === 'function' && spectatorViewOn(L));
  /* 前突及紧接的撤离允许刀手越过玩家，避免把玩家一路推在刀前。 */
  for (const e of enemies){
    if (_crkCam) break;
    if (e.dead) continue;
    if (enemyType(e).kind === 'blade' && ((e.lungeT || 0) > 0 || (e.retreatRunT || 0) > 0)) continue;
    const _rr = player.r + (e.r || 12);
    const _dx = player.x - e.x, _dy = player.y - e.y;
    const _d2 = _dx*_dx + _dy*_dy;
    if (_d2 < _rr*_rr){
      const _d = Math.sqrt(_d2);
      if (_d < 0.001){
        /* 两个人完全重合了，任意一个方向撞出去就行 */
        player.x = e.x + _rr;
      } else {
        player.x = e.x + _dx/_d*_rr;
        player.y = e.y + _dy/_d*_rr;
      }
    }
  }
  const _godNo = (typeof godNoclip === 'function' && godNoclip());
  if (!playerTruck && !(ar && ar.noclip) && !_crkCam && !_godNo) for (const w of L.walls) pushOutCircle(player, player.r, w);
  /* 停稳的车也是障碍：玩家绕着走，不能穿过去（自己开着的那辆除外） */
  if (!_crkCam && !_godNo) for (const t of trucks) if (t.solid && t !== playerTruck) pushOutTruckCircle(player, t);
  if (!_crkCam && !_godNo) for (const d of doors) if (doorSolid(d)) pushOutCircle(player, player.r, d);
  /* 近战突进：出手那一下人向前蹲一段，每帧留一个重影。
     m23255：这段必须"分小步推进 + 每一步撞墙"。以前是一帧直接把 500*dt 加到坐标上，
     掉帧时一帧就能前进 20~28px（墙才 30 厚），pushOutCircle 会按"最近的那条边"把人推出去 ——
     推穿到墙对面，表现就是"贴着墙挥刀就穿墙了"。现在每步 ≤4px，撞住就停。 */
  if (player.lungeT > 0){
    const _ca = Math.cos(player.lungeA), _sa = Math.sin(player.lungeA);
    const _ls = (player.lungeSpeed || 520) * dt;
    player.lungeT = Math.max(0, player.lungeT - dt);
    const _stp = Math.max(1, Math.ceil(_ls / 4));
    const _sd = _ls / _stp;
    const _collide = !playerTruck && !(ar && ar.noclip) && !_crkCam && !_godNo;
    for (let _s = 0; _s < _stp; _s++){
      const _ox = player.x, _oy = player.y;
      player.x += _ca * _sd; player.y += _sa * _sd;
      if (!_collide) continue;
      for (const w of L.walls) pushOutCircle(player, player.r, w);
      for (const d of doors) if (doorSolid(d)) pushOutCircle(player, player.r, d);
      if (Math.abs(player.x - _ox) < 0.01 && Math.abs(player.y - _oy) < 0.01){ player.lungeT = 0; break; }
    }
    meleeTrail.push({x: player.x, y: player.y, a: player.lungeA, t: 0, dur: 0.26});
  }
  player.x = clamp(player.x, 16, L.w-16);
  player.y = clamp(player.y, 16, L.h-16);
  /* 岛图：下不了水 —— 越界就往最近的海岸线里退 10px（不是撞墙，是"走不进去"） */
  if (typeof dzIsland !== 'undefined' && dzIsland && L && L.rules && L.rules.dz && !dzOnLand(player.x, player.y, 8)){
    const c = dzPolyClamp(player.x, player.y, dzIsland.poly, 12);
    player.x = c.x; player.y = c.y;
  }

  /* 无视地形：墙不是免费的休息室 —— 子弹照样打得到你、不能打药、每秒掉血，
     待满 3 秒还会被墙挤出去。想拿它绕近路可以，想蹲在墙里养伤不行 */
  playerInWall = false;
  if (ar && ar.noclip){
    let _hitW = null;
    for (const w of L.walls){
      if (player.x > w.x - 2 && player.x < w.x + w.w + 2 &&
          player.y > w.y - 2 && player.y < w.y + w.h + 2){ _hitW = w; break; }
    }
    if (_hitW){
      playerInWall = true;
      player.wallT = (player.wallT || 0) + dt;
      player.hp = Math.max(0, player.hp - arenaMaxHp() * 0.06 * dt);
      if (player.wallT >= 3){
        /* 挑离得最近的那条边把人挤出去 */
        const dL = player.x - _hitW.x, dR = _hitW.x + _hitW.w - player.x;
        const dT = player.y - _hitW.y, dB = _hitW.y + _hitW.h - player.y;
        const m = Math.min(dL, dR, dT, dB);
        if (m === dL) player.x = _hitW.x - player.r - 3;
        else if (m === dR) player.x = _hitW.x + _hitW.w + player.r + 3;
        else if (m === dT) player.y = _hitW.y - player.r - 3;
        else player.y = _hitW.y + _hitW.h + player.r + 3;
        player.wallT = 0;
        setMsg('墙把你挤出来了 · 别拿墙当掩体', 1.8);
        beep(140, 0.18, 'sawtooth', 0.10, 60);
      }
    } else {
      player.wallT = 0;
    }
  }

  /* 朝向：第三关用它决定"你正在看哪"，所以要跟着鼠标走 */
  if (dyingT <= 0 && player.hp > 0) player.aim = Math.atan2(mouseWorldY() - player.y, mouseWorldX() - player.x);

  /* 突击步枪：按住左键就一直打。cd 在 tryShoot 里管着射速 */
  if (mouse.fire && player.gun && hasFeat('guns') && gunDef(player.gun).auto){
    tryShoot();
  }

  updateBinoK(dt);
  if (typeof traderTick === 'function'){ traderTick(dt); gachaTick(dt); }

  /* 脚步声：自己听得见；敌人按 hearR 判断能不能听见。
     雷响的那一秒多，脚步也被雷盖住（hearMaskK），传出去的距离只剩三成。 */
  playerStepNoise(dt);
  if (typeof godKeepAlive === 'function') godKeepAlive();   /* 上帝模式：无敌 */

  for (let i=stepRipples.length-1;i>=0;i--){
    const rp = stepRipples[i]; rp.t += dt;
    if (rp.t >= rp.life) stepRipples.splice(i,1);
  }

  /* 手雷 */
  for (let i=grenades.length-1;i>=0;i--){
    const g = grenades[i];
    g.t += dt;
    const p = clamp(g.t/g.dur,0,1);
    g.x = lerp(g.x0,g.x1,p); g.y = lerp(g.y0,g.y1,p);
    if (p >= 1){
      /* 敌人扔的烟自己带半径/时长（g.r/g.life），没带就用玩家那套默认值 */
      const _sr = g.r || CFG.smokeR, _sl = g.life || CFG.smokeLife;
      smokes.push({x:g.x1, y:g.y1, r:_sr, age:0, life:_sl, byEnemy:!!g.byEnemy, seed:fxRand(0,TAU)});
      grenades.splice(i,1); sfxPop();
      if (!g.byEnemy) logInfo('smoke', '烟雾生效 · 半径 ' + _sr + ' · 持续 ' + _sl.toFixed(0) + 's · 位置 ' + Math.round(g.x1) + ',' + Math.round(g.y1));
    }
  }

  for (let i=enemySteps.length-1;i>=0;i--){
    const es = enemySteps[i]; es.t += dt;
    if (es.t >= es.life) enemySteps.splice(i,1);
  }

  /* 烟 */
  for (let i=smokes.length-1;i>=0;i--){
    const s = smokes[i];
    s.age += dt; s.life -= dt;
    if (s.life <= 0){ smokes.splice(i,1); logInfo('smoke', '烟雾消散'); }
  }
  /* 只有自己扔的烟才算"藏住了"：敌人丢的烟只挡你的视线，不挡他们的眼 */
  const cov = smokesCovering(player.x, player.y, true);
  concealed = cov.length > 0;
  concealLeft = 0;
  for (const s of cov) concealLeft = Math.max(concealLeft, s.life);

  /* 热成像（全局规则，所有关卡都吃这套）
     按一下开机 → 之后只能一直戴到没电，中途关不掉；
     没电了先进冷却（冷却期间不充电），冷却完才开始慢慢回电；
     越难的档越费电、回电越慢。 */
  if (L.boss){
    /* 猎场这一层断电，热成像彻底不可用 */
    player.thermal = false; player.thermalOn = false; player.heatCd = 0;
    player.battery = Number.isFinite(player.battery) ? player.battery : 100;
  }
  const heatBanned = !!(L && L.rules && L.rules.thermal === false);   /* 本关没收热成像 */
  /* v2：新关卡 / 死亡地带专用。续航拉长到 25 秒（100 电量 / 4 每秒），
     开机不再要门槛、没电也不罚冷却，但**绝不自动回电** —— 只能靠热成像电池。 */
  const heatV2 = !!(L && L.rules && L.rules.thermalV2) || !!player.heatV2Batt;
  /* m35945：死亡地带电容量 ×10（默认电量不变，续航靠容量，耗电速率也不变） */
  /* m35945-fix：死亡地带的 L 上没有 dz 标记，必须走 heatCapNow()（只看 rules.thermalV2），
     否则容量还是 100 → 电池充满后会被 clamp 回 100，看起来像「电池没用/状态错」 */
  const _heatCap = (typeof heatCapNow === 'function') ? heatCapNow() : ((L && L.rules && L.rules.thermalV2) ? 1000 : 100);
  const HEAT_DRAIN_V2 = 4;                           /* v2 耗电：100 / 4 = 25 秒续航 */
  const heatDev = !!(CFG.dev && CFG.heatInf);        /* 开发者：热成像无限，第四关也能看 */
  const _heatDiff = Math.max(0, DIFF_ORDER.indexOf(diffName));
  const heatDrainK = 1 + _heatDiff * 0.15;           /* 难度越高越费电：简单 1.0 → 噩梦 1.45 */
  const heatRegenK = 1 / (1 + _heatDiff * 0.28);     /* 难度越高充得越慢：简单 1.0 → 噩梦 0.54 */
  const heatJam = false;                             /* 「卡壳」不再动热成像，改砍射速 */

  const _heatKey = !!keys[(typeof BINDS !== 'undefined' && BINDS.thermal) || 'Space'];
  const _heatEdge = _heatKey && !player.heatKeyPrev; /* 只有"按下"那一下算 */
  player.heatKeyPrev = _heatKey;
  player.thermalOn = !!player.thermalOn;
  player.heatCd = Math.max(0, player.heatCd || 0);
  if (typeof heatCellTick === 'function') heatCellTick(dt);   /* 换电池倒计时 */

  if (heatDev){
    player.battery = 100; player.thermalOn = true; player.heatCd = 0; player.batLock = false;
  }
  const heatOutfit = !!player.heatWorn;              /* 身上有没有戴这台机器 */
  if (!heatOutfit && !heatDev){
    /* 没戴 = 根本没有这功能：不亮、不耗电、也不充电 */
    player.thermal = false; player.thermalOn = false; player.batLock = false;
    if (_heatEdge) setMsg('没戴热成像 · 背包里拖到「热成像」栏', 1.8);
  } else if (!L.boss && !heatDev){
    if (heatBanned){
      player.thermal = false;
      player.thermalOn = false;
      player.batLock = true;
    } else if (player.heatCd > 0){
      /* 冷却：既不亮也不充，就是硬等 */
      player.heatCd = Math.max(0, player.heatCd - dt);
      player.batLock = true;
      player.thermalOn = false;
      player.thermal = false;
      if (player.heatCd === 0){
        setMsg('热成像冷却结束 · 开始充电', 1.8);
        logInfo('battery', '热成像冷却结束');
      }
    } else if (heatJam){
      if (player.thermalOn){
        setMsg('热成像被干扰 · 强制关机', 2.0);
        logWarn('battery', '热成像被干扰事件强制关机');
      }
      player.thermalOn = false;
      player.thermal = false;
      player.batLock = false;
    } else if (player.thermalOn){
      /* 开着就一直烧电；现在可以随时按空格关掉 */
      player.thermal = true;
      player.battery -= (heatV2 ? HEAT_DRAIN_V2 : 13) * heatDrainK * dt;
      if (_heatEdge){
        player.thermalOn = false;
        player.thermal = false;
        setMsg(heatV2 ? '热成像关机' : '热成像关机 · 3 秒后开始回电', 1.5);
        beep(520, 0.06, 'square', 0.035, 900);
        player.heatOffT = heatV2 ? 0 : 3;   /* 新版没有"关机冷却"这一说 */
        logInfo('battery', '热成像关机');
      }
      if (player.battery <= 0){
        player.battery = 0;
        player.thermal = false;
        player.thermalOn = false;
        /* v2 不罚冷却：没电就是没电，换电池立刻能用 */
        player.heatCd = heatV2 ? 0 : (6 + _heatDiff * 3);   /* 冷却：简单 6 秒 → 噩梦 15 秒 */
        player.heatOffT = 0;                          /* 已经罚过一次冷却，回电别再等 */
        player.batLock = true;
        if (heatV2) setMsg('热成像没电了 · 用热成像电池充（点背包里那格）', 2.6);
        else setMsg('热成像没电了 · 冷却 ' + Math.round(player.heatCd) + ' 秒', 2.2);
        logWarn('battery', '热成像电量耗尽' + (heatV2 ? '' : ' · 冷却 ' + Math.round(player.heatCd) + ' 秒'));
      }
    } else {
      /* 关机状态：先冷 3 秒，然后才慢慢回电；30% 以上才允许开机 */
      player.thermal = false;
      player.batLock = false;
      if ((player.heatOffT || 0) > 0) player.heatOffT = Math.max(0, player.heatOffT - dt);
      /* v2：电量只掉不回 —— 想继续看见，就得往兜里揣电池 */
      else if (!heatV2) player.battery = Math.min(100, player.battery + 4.5 * heatRegenK * dt);
      if (_heatEdge){
        if (heatV2 ? player.battery > 0 : player.battery >= 30){
          player.thermalOn = true;
          player.thermal = true;
          player.heatOffT = 0;
          setMsg('热成像开机 · 再按一下空格关机', 2.0);
          beep(880, 0.08, 'square', 0.05, 1200);
          logInfo('battery', '热成像开机 · 电量 ' + Math.round(player.battery) + '%');
        } else if (heatV2){
          setMsg('热成像一点电都没有了 · 用热成像电池充（点背包里那格）', 2.2);
        } else {
          setMsg('电量不够开机（要 30%）· 现在 ' + Math.round(player.battery) + '%', 1.8);
        }
      }
    }
  } else if (heatDev){
    player.thermal = true;
  }
  player.battery = clamp(player.battery, 0, _heatCap);

  /* 地上道具的冷却：丢出去的那一下不能被自己瞬间捡回来。
     顺手把捡走的（l.taken）从数组里压掉 —— 以前它们会一直留着，
     割草打一局能攒到几千条，每帧七八趟遍历全在扫空气。
     用下标写指针原地压缩，不新建数组（每帧都跑，别制造垃圾）。 */
  let _lw = 0;
  for (let _li = 0; _li < loots.length; _li++){
    const l = loots[_li];
    if (l.taken) continue;
    if (l.cool > 0) l.cool -= dt;
    if (l.autoT > 0) l.autoT -= dt;
    if (l.newT > 0) l.newT -= dt;      /* 刚搜出来的高亮计时 */
    loots[_lw++] = l;
  }
  if (_lw !== loots.length) loots.length = _lw;
  /* 自动拾取：走近就收。
     - 割草（战斗爽）是纯爽局，地上什么都能自动收；
     - 普通关卡只自动收消耗品（药 / 子弹 / 烟雾弹），枪和装备仍然要自己点，
       否则走着走着手上的枪会被地上的枪换掉。
     - 玩家自己从背包里丢出来的东西带 autoT（5 秒），这期间不会被自动捡回去。
     slice() 是为了防止 take() 里换甲等操作往 loots 里塞东西时改了正在遍历的数组。 */
  if (state === 'play' && player && player.hp > 0){
    const autoAll = !!ar;
    /* m23255：以前每帧 loots.slice() 复制整张表；改成按下标走，长度先拍快照
       （take() 里可能会往 loots 里塞东西，但新塞的这帧不处理正好）。 */
    const _autoLen = loots.length;
    for (let _ai = 0; _ai < _autoLen; _ai++){
      const l = loots[_ai];
      if (!l) continue;
      if (l.autoT > 0) continue;
      /* 黑匣子：整局的目标物，必须玩家自己走过去按 E / 点一下，任何模式下都不自动收 */
      if (l.kind === 'blackbox') continue;
      /* 箱子 / 物资堆里刚翻出来的：一律不自动收，必须玩家自己按 E 或点一下。
         否则读条一结束东西就没了，玩家根本来不及看清是什么。 */
      if (l.fromSearch) continue;
      if (!autoAll && !AUTO_PICK_KINDS[l.kind]) continue;
      if (!lootPickable(l)) continue;
      /* 血满的时候自动拾取别去碰药：走过去也吃不下，只会每 0.6 秒
         弹一次"血是满的，先不浪费"，还把冷却一遍遍刷掉。
         手动按 E 仍然会提示，那是玩家自己想确认。 */
      if (autoAll && l.kind === 'med' && player.hp >= arenaMaxHp() - 0.5) continue;
      pickLoot(l);
    }
  }

  if (selfSayT > 0) selfSayT = Math.max(0, selfSayT - dt);
  if (player && player._shieldClickT > 0) player._shieldClickT = Math.max(0, player._shieldClickT - dt);

  /* 雨夜：雨一直在下，雷隔一阵来一个；闪电亮一下之后指数式暗回去 */
  if (heatGlitch > 0) heatGlitch = Math.max(0, heatGlitch - dt);
  if (meleeT > 0) meleeT = Math.max(0, meleeT - dt);
  if (typeof windTick === 'function') windTick(dt);
  if (typeof weatherTick === 'function') weatherTick(dt);
  if (weatherActive() && state === 'play'){
    if (weatherHasRain()) rainTick();
    /* 每次回闪都是一个独立的衰减包，取当前最亮的那个当画面亮度 */
    flashT += dt;
    const _fl = flashLevel();
    flashK = _fl > 0.002 ? _fl : Math.max(0, flashK - dt * 1.8);
    thunderMaskTick(dt);   /* 雷声掩盖：起手渐入 + 满遮盖 + 缓慢回落（m13205） */
    if (weatherHasThunder()){
      thunderWait -= dt;
      if (thunderWait <= 0){
        /* rules.thunderK：同一档天气下控制打雷密度（死亡地带要的是'偶尔一道'，不是 3-4 那种节奏） */
        thunderWait = nextThunderWait();
        thunderStrike();
      }
    }
  } else if (flashK > 0){
    flashK = Math.max(0, flashK - dt * 1.8);
  }
  if (selfScript.length && timeAlive >= selfScript[0].t && player.hp > 0){
    const _it = selfScript.shift();
    saySelf(_it.txt, 4.2);
  }

  /* 枪的冷却/换弹是"玩家自己的计时"，暂停时也得走 ——
     否则暂停里只能开一枪、换弹条卡死（m35918） */
  if (hasFeat('guns')) updateTestZone(dt);
  if (!_frz){
  updateTimers(dt);          /* 计世界时器：暂停时冻住 */
  updateRocketTurrets(dt);
  if (typeof updateMgSentries === 'function') updateMgSentries(dt);
  updateCompanions(dt);
  }

  /* 门每帧都要推进：不分关卡 */
  if (!_frz){
  segBegin('门更新');
  try { updateDoors(dt); } finally { segEnd(); }
  if (L.boss){
    updateSwitches(dt);
    updateBoss(dt);
  }
  }

  /* 敌人 */
  if (!_frz){
  if (L.rules && L.rules.charge) squadCharge(L, dt);
  reinforce(L, dt);
  }
  /* 第三方：运兵车自己走状态机，和敌人 AI 完全不共用 */
  if (!_frz) TruckSystem.update(dt);
    if (!_frz && typeof vehEngineTick === 'function') vehEngineTick(dt);
  if (!_frz) nadeDodgeTick(dt);
  const {anySees,anyHunt,nearestSeer,nearestHunt,anyAlarmSees}=updateEnemyFrame(L,dt,_frz);

  // 移动/探头状态不能把已锁定的架枪朝向覆盖成墙后玩家的位置。
  for(const e of enemies){
    if(_frz)break;
    if(e.dead||!enemyType(e).canShoot)continue;
    /* 开火那一瞬间：真实朝向立刻对准弹道，但"身体"不许跟着瞬间掰过去 ——
       以前这里连 e.angS 一起写，每打一枪身体就瞬间转一个角度，
       跑掩体时连开两枪看起来就是"九十度转弯再转弯，速度极快"。 */
    if(!e.fleeing && e.muzzle>0 && Number.isFinite(e.shotAng)){
      e.ang=e.shotAng;e.cornerWatch=null;
      /* 大角度转向时"身体"必须跟上：angS 是按 6.2 rad/s 慢慢转的，
         要是这一枪是转身后立刻打的，枪口会还挂在旧方向上 ——
         看起来就是"子弹从背后飞出来"。小角度仍然保持平滑转身。

         但「正在跑向掩体」是例外：那本来就是一次转身，边跑边打的瞬间把身体
         掰过去，连着两枪就成了"九十度转弯再转弯、快得像瞬移"（_tFaceHold 逮住过
         一次 1.28rad/帧 = 76.9rad/s）。跑掩体期间交给 turnSpd 慢慢追，
         枪口偏一点无所谓，弹道用的是 e.ang，不靠这个。 */
      if(Number.isFinite(e.angS)){
        const _dSnap=Math.abs(normAng(e.ang-e.angS));
        if(_dSnap>1.05 && e.peekPhase!=='run'){e.angS=e.ang;if(Number.isFinite(e.coneA))e.coneA=e.ang;}
      }
      continue;
    }
    if(e.sees){e.cornerWatch=null;continue;}
    if(e.cornerWatch && e.lastKnown)enemyWatchCorner(e,e.lastKnown);
  }
  /* ---- 无人机：直线飞，不看墙，被烟一挡就瞎 ---- */
  /* 刀手：这里只平滑显示朝向，位置由寻路/前突/撤离统一更新。 */
  for (const e of enemies){
    if (_frz) break;
    if (enemyType(e).kind !== 'blade') continue;
    /* 不能把等待搜索、掩体后摇误判为卡墙并额外推移。 */
    const _mvx = e.x - (e._sx === undefined ? e.x : e._sx);
    const _mvy = e.y - (e._sy === undefined ? e.y : e._sy);
    const _mv = Math.hypot(_mvx, _mvy);
    e._sx = e.x; e._sy = e.y;
    /* --- 朝向：走着的时候朝着脚的方向，抬手/落刀才盯人 --- */
    let _want = e.ang;
    const _bodyA = Math.atan2(_mvy, _mvx);
    const _busy = (e.windup > 0) || (e.slashT > 0) || (e.lungeT > 0);
    if (!_busy && _mv > 0.35) _want = _bodyA;
    if (e.angS === undefined) e.angS = e.ang;
    const _rate = (e.lungeT > 0) ? 14 : 7.0;
    let _d = normAng(_want - e.angS);
    const _mx = _rate * dt;
    if (_d > _mx) _d = _mx; else if (_d < -_mx) _d = -_mx;
    e.angS = normAng(e.angS + _d);
    e.ang = e.angS;
  }

  for (const e of enemies){
    if (_frz) break;
    if (enemyType(e).kind !== 'drone') continue;
    const T = enemyType(e);
    e.rot = (e.rot || 0) + dt * 7;
    if (e.nadeDodgeThreat) continue;

    /* 目标：追你 / 去看最后位置 / 回巡航 */
    let tx, ty;
    if (e.mode === 1 && e.lastKnown){
      tx = e.lastKnown.x; ty = e.lastKnown.y;
      e.alertT -= dt;
      if (dist(e.x, e.y, tx, ty) < 28 || e.alertT <= 0){
        e.mode = 0; e.lastKnown = null;
        logInfo('calm', '无人机在那一带转了一圈，没找到人 · 回巡航');
      }
    } else {
      if (!e.wp || !e.wp.length) e.wp = [[e.x, e.y]];
      e.i = ((e.i|0) % e.wp.length + e.wp.length) % e.wp.length;
      tx = e.wp[e.i][0]; ty = e.wp[e.i][1];
      if (dist(e.x, e.y, tx, ty) < 22){
        e.wait = (e.wait || 0) - dt;
        if (e.wait <= 0){ e.i = (e.i+1) % e.wp.length; e.wait = 0.6; }
        tx = e.x; ty = e.y;
      }
    }

    const wantA = Math.atan2(ty - e.y, tx - e.x);
    /* 原来只会"匀速硬转"，转弯半径 = 速度/角速度 ≈ 90px：
       航点如果落在转弯半径里面（比如掉头），它就永远绕着那个点转圈，飞不到。
       现在要做大角度转向时先减速、并提高转速，半径缩到 ~50px，才收得住。 */
    const errA = normAng(wantA - e.ang);
    const sharp = Math.min(1, Math.abs(errA) / 1.4);
    const turn = (T.droneTurn || 2.6) * (1 + sharp * 1.5);
    e.ang = e.ang + clamp(errA, -turn*dt, turn*dt);
    const arrive = 22;
    if (dist(e.x, e.y, tx, ty) > arrive){
      const sp = (T.droneSpd || 235) * (e.mode === 1 ? 1.15 : 1) * (1 - 0.62*sharp);
      e.x += Math.cos(e.ang) * sp * dt;
      e.y += Math.sin(e.ang) * sp * dt;
      /* 会飞：不撞墙，只被地图边界挡住 */
      e.x = clamp(e.x, 24, cur().w - 24);
      e.y = clamp(e.y, 24, cur().h - 24);
    }
  }

  /* 谁在看着你：摄像头/无人机只要有一个看见，警报就满 */
  alarm2Want = anyAlarmSees ? 1 : 0;
  /* 死亡地带自己管围剿：4-1 那套"左边源源不断"的警报不进来，否则会抢红边和字幕 */
  if (!_frz){
  if (!ar && !dzLvl) alarmRushUpdate(dt);
  if (dzLvl){
    segBegin('围剿');
    try { dzSiegeUpdate(dt); } finally { segEnd(); }
  }
  }
  /* 音频每帧更新已挪到 frame()：暂停/回主菜单时 update 不跑，声音会卡住不停 */

  /* 无人机的声音：按"最近那架"的距离调音量，没有无人机就静音 */
  {
    let dmin = 1e9;
    for (const e of enemies){
      if (enemyType(e).kind !== 'drone') continue;
      dmin = Math.min(dmin, dist(e.x, e.y, player.x, player.y));
    }
    if (dmin > 2600){ if (droneHum) stopDroneHum(); } else sfxDroneHum(dmin);
  }

  if (!_frz && typeof squadTick === 'function') squadTick(dt);
  /* 声音集中投递、空间桶刷新、仇恨递减都只做一次。 */
  if(typeof factionFrameEnd==='function')factionFrameEnd(dt);
  else if (typeof factionTickGrudge === 'function') factionTickGrudge(dt);
  if (!_frz){
  segBegin('单位分离');
  try { separateEnemies(dt); } finally { segEnd(); }
  /* 交替掩护跃进：两人一组，一个架枪一个跳（m37743）。只在 humanOn 的关生效 */
  if (typeof boundTick === 'function') boundTick(L, dt);
  updateMgNests(dt);
  }

  /* 巡逻点被堵死时跳过，别原地蹭 */
  for (const e of enemies){
    if (e.mode === 0 && (e.stuckT || 0) > 2){
      e.i = (e.i+1) % e.wp.length; e.wait = 1.4; e.stuckT = 0; e.logStuck = 0; e.path = null; e.goal = null;
      logWarn('stuck', '人机#' + (enemies.indexOf(e)+1) + ' 巡逻点走不到，跳过该点');
    }
  }

  if (anySees){
    for (const e of enemies){
      /* “有人看见玩家”的呼喊只通知同样敌对玩家的人。
         多阵营加入后若漏掉这层，B/同阵营单位会先被广播扭向玩家，下一帧感知
         又把玩家排除，两个状态轮流抢朝向，看起来同样像原地转圈。 */
      if (e.mode === 0 && factionWantsFight(e,player) && dist(e.x,e.y,player.x,player.y) < 460){
        /* 同伴喊一声，他只知道"大概在那个方向"；必须自己看见才会精确跟进 */
        e.mode = 1; e.heard = true;
        e.alertT = Math.max(2, CFG.eMemory*0.6);
        e.lastKnown = roughSpot(cur(), player.x, player.y, 110);
        e.ang = Math.atan2(e.lastKnown.y-e.y, e.lastKnown.x-e.x);
      }
    }
  }

  /* 心跳。割草模式里满屏都是人，“被发现”不该当信号，
     所以这里只看自己的伤势：血越少心跳越快越重 */
  if (ar){
    const _hurt = clamp(1 - player.hp / Math.max(1, arenaMaxHp()), 0, 1);
    const _k = clamp((_hurt - 0.45) / 0.55, 0, 1);
    if (_k > 0.02){
      hbT -= dt;
      if (hbT <= 0){
        if (!hbSampleOn) heartbeat(0.10 + 0.30*_k);
        hbPulse = 1;
        hbT = 0.95 - 0.50*_k;
      }
    } else {
      hbT = 0;
    }
    tense = _k;
  } else if (anySees || (anyHunt && nearestHunt < 420)){
    const near = anySees ? clamp(1 - nearestSeer/Math.max(120, seeRange(cur())), 0, 1) : 0.18;
    const low  = player.hp < CFG.hp*0.35 ? 0.22 : 0;
    const k = clamp(near*0.86 + low, 0, 1);
    hbT -= dt;
    if (hbT <= 0){
      if (!hbSampleOn) heartbeat(anySees ? (0.10 + 0.30*k) : 0.05);
      hbPulse = 1;
      hbT = anySees ? (0.94 - 0.54*k) : 1.05;
      if (k > 0.5) camShake = Math.max(camShake, 0.20*k);
    }
  } else {
    hbT = 0;
  }
  /* 紧张度：被追 0.18 秒冲到 0.65，约 0.6 秒到顶；脱战后几秒内慢慢松掉 */
  {
    /* 被看见 = 拉满；只是听见/在附近搜 = 最多到 0.42，且要在 420px 内；
       离得远就当作"没什么事"，心跳跟着松下去。 */
    const target = ar ? tense : (anySees ? 1 : ((anyHunt && nearestHunt < 420) ? 0.42 : 0));
    if (!ar) tense += (target - tense) * Math.min(1, dt * (target > tense ? 5.5 : 0.85));
    if (tense < 0.002) tense = 0;
  }
  hbPulse = Math.max(0, hbPulse - 3.2*dt);

  /* 开走的运兵车从数组里摘掉（在循环外做，别在遍历里 splice） */
  TruckSystem.removeGone();

  ProjectileSystem.update(L,dt,_frz);

  stUpdate(dt);
  player.flash = Math.max(0, player.flash - dt*1.6);
  if (player.hintT > 0) player.hintT = Math.max(0, player.hintT - dt);

  /* 撤离 */
  const E = L.extract;
  /* 判定带上玩家的半个身位：虚线框画出来，玩家站在框边上就该算"到了" */
  const _ez = 8;
  const inZone = player.x > E.x - _ez && player.x < E.x+E.w + _ez &&
                 player.y > E.y - _ez && player.y < E.y+E.h + _ez;
  /* 观战图（斗蛐蛐）没有"撤离"这件事：玩家就是摄像机，站在中心也不该判成功 */
  const _noEx = !!(L.rules && (L.rules.noExtract || L.rules.cricket));
  const canExtract = inZone && state === 'play' && player.hp > 0;
  if (L.boss && canExtract && exitOpen){
    state = 'win'; clearedLv[levelIdx] = true; if (typeof progWin === 'function') progWin(levelIdx, diffName); sfxWin(); stopSiren();
    runTimes[levelIdx] = timeAlive;
    logInfo('win', '跑出去了 · 第四关 · 用时 ' + logGame() + ' · 电闸 3/3');
  }
  if (!_noEx && !L.boss && canExtract && player.loot >= lootTotal && (!dzLvl || L.dzBox)){
    player.holdT += dt;
    if (player.holdT >= (dzLvl ? 9 : 1.6)){
      if (dzLvl){
        /* 死亡地带：撤离成功不写 clearedLv(levelIdx)，那会把某张正式关标成通关 */
        state = 'win'; sfxWin(); stopSiren();
        logInfo('dz', '带着黑匣子撤离 · 用时 ' + logGame());
        if (typeof progDzWin === 'function') progDzWin(dzTier);            /* m33967：撤离成功 → 记一笔，可能解锁下一档难度 */
        if (typeof stashBeginSettle === 'function') stashBeginSettle();   /* 结算：想把什么留下来 */
      } else {
        state = 'clear'; clearedLv[levelIdx] = true; if (typeof progWin === 'function') progWin(levelIdx, diffName); sfxWin(); stopSiren();
        runTimes[levelIdx] = timeAlive;
        logInfo('clear', '撤离成功 · 第 ' + (levelIdx+1) + ' 关 · 用时 ' + logGame() + ' · 剩烟雾 ' + player.grenades);
      }
    }
  } else player.holdT = 0;

  lowHpUpdate(dt);

  recAcc += dt;
  if (recAcc >= 1/REC_HZ){ recAcc -= 1/REC_HZ; recSnapshot(); }

  if (ar) arenaUpdate(dt); else arenaBossTick(dt);

  vrecAcc += activeDt;
  const finalReplayFrame = state !== 'play' || (player.hp <= 0 && dyingT <= 0);
  if (vrecAcc >= 1/VREC_HZ || finalReplayFrame){
    vrecAcc %= 1/VREC_HZ;
    vrecSnapshot();
  }

  if (state === 'play' && player.hp <= 0){
    player.hp = 0;
    if (ar){ arenaGameOver(); return; }
    if (dyingT <= 0){
      dyingT = 1.0;
      player.grace = Math.max(player.grace, 3);   /* 死了就不该再挨子弹 */
      logError('dead', '你被打死了 · 第 ' + (levelIdx+1) + ' 关 · 撑了 ' + logGame() + ' · 物资 ' + player.loot + '/' + lootTotal);
    }
    dyingT -= dt;
    if (dyingT <= 0){ dyingT = 0; enterDead(); }
  } else if (dyingT > 0){
    /* 血回来了（比如药正好打上）：倒地计时清零，不然人会一直"动不了但能开枪" */
    dyingT = 0;
  }

  /* 摄像头扫视：全帧唯一一处写它的 ang，别处不许动，免得"啪"一下把头转过去 */
  for (const e of enemies){
    if (!enemyType(e).static || !(e.sweep > 0)) continue;
    e.swT = (e.swT || 0) + dt;
    e.ang = e.baseAng + Math.sin(e.swT * 0.42) * e.sweep;
  }
}

/* ---------------- 摄像机 ---------------- */
function updateCam(){
  if (!player) return;
  const L = cur();
  /* 死了就不能再被边界卡住：否则倒在地图边上时，尸体会被推到屏幕角落，
     死亡画面看起来就像“镜头跑偏了”。此时干脆把人放回正中间。 */
  if (player && player.hp <= 0 && state !== 'menu'){
    cam.x = player.x - W/2;
    cam.y = player.y - H/2;
    return;
  }
  let tx, ty;
  if (state === 'menu'){ tx = L.w/2 - W/2; ty = L.h/2 - H/2; }
  else { tx = player.x - W/2; ty = player.y - H/2; }
  cam.x = L.w <= W ? (L.w-W)/2 : clamp(tx, 0, L.w-W);
  cam.y = L.h <= H ? (L.h-H)/2 : clamp(ty, 0, L.h-H);
  /* 望远镜：镜头朝玩家看的方向前推（不是单纯拉远）。
     前推之后玩家的屏幕位置会往后退一点，正好把背后的建筑挤出画面。 */
  const _bk = (typeof binoK === 'function') ? binoK() : 0;
  if (_bk > 0.001 && state === 'play' && player && typeof player.aim === 'number'){
    const _pan = (typeof binoPanK === 'function') ? binoPanK() : 0;
    cam.x += Math.cos(player.aim) * _pan;
    cam.y += Math.sin(player.aim) * _pan;
    /* 前推之后还得出界：照原来的规矩再夹一次，地图边上就吃不到前推 */
    if (L.w > W) cam.x = clamp(cam.x, 0, L.w - W); else cam.x = (L.w-W)/2;
    if (L.h > H) cam.y = clamp(cam.y, 0, L.h - H); else cam.y = (L.h-H)/2;
  }
}


/* ============================================================
   第四关 · 猎手
   ============================================================ */

function pounceSec(){
  const v = POUNCE_MS[diffName];
  return (v === undefined ? POUNCE_MS.normal : v) / 1000;
}

/* 猎手看见你了没有：视野锥 + 遮挡 + 烟雾遮蔽（他也要吃烟） */
function hunterSpot(L, minFromPlayer, maxTry){
  maxTry = maxTry || 400;
  for (let i=0;i<maxTry;i++){
    const x = rand(80, L.w-80), y = rand(80, L.h-80);
    if (dist(x, y, player.x, player.y) < (minFromPlayer || 700)) continue;
    let bad = false;
    for (const w of L.walls){
      if (x > w.x - 26 && x < w.x + w.w + 26 && y > w.y - 26 && y < w.y + w.h + 26){ bad = true; break; }
    }
    if (!bad) return {x:x, y:y};
  }
  return safeSpot(L, {x:L.w/2, y:L.h/2}, 40);
}
function spawnHunter(role, at){
  const L = cur();
  let p;
  if (at){
    const q = safeSpot(L, at, 30);
    /* 守卫也不能贴着玩家出生 */
    p = dist(q.x, q.y, player.x, player.y) > 620 ? q : hunterSpot(L, 900);
  } else {
    p = hunterSpot(L, 900);
  }
  const gs = (role === 'guard') ? {x:p.x, y:p.y} : null;
  return {
    type: (role === 'guard') ? 'guard' : 'hunter',
    role: role || 'chase', guardSpot: gs, leash: 0,
    patrolRadius: (role === 'guard' && at && at.patrolRadius) || 150,
    burstOn: true, burstT: 0,
    x: p.x, y: p.y, r:14, ang: rand(0,TAU), state:'patrol',
    wp:[[p.x, p.y]], i:0, wait:0, lastKnown:null, lostT:0,
    path:null, goal:null, navT:0, stuckT:0, netT:0, netX:undefined, netY:undefined,
    forceT:0, forceA:null, chk:null, stepT:0, pounceT:0, recT:0,
    seen:false, hitFlash:0
  };
}
function addHunter(role){
  const L = cur();
  const r = role || 'chase';
  const at = (r === 'guard' && L.guardSpots)
    ? L.guardSpots[Math.floor(arenaRandom()*L.guardSpots.length)] : null;
  hunters.push(spawnHunter(r, at));
  logWarn('boss', '又下来一个猎手（' + (r === 'guard' ? '守点' : '追你') + '）· 场上共 ' + hunters.length + ' 个');
  setMsg(r === 'guard' ? '又来一个，他往出口那边去了' : '又下来一个', 1.9);
}

/* 点到线段的距离：判断"这团烟是不是挡在两人中间" */
function segPointDist(x1, y1, x2, y2, px, py){
  const dx = x2 - x1, dy = y2 - y1;
  const L2 = dx*dx + dy*dy;
  let t = L2 > 0.0001 ? ((px - x1)*dx + (py - y1)*dy) / L2 : 0;
  t = clamp(t, 0, 1);
  const qx = x1 + dx*t, qy = y1 + dy*t;
  return Math.hypot(px - qx, py - qy);
}
/* 烟只挡对面，不挡自己人（用户 m04403 的设计约定）：
     · 玩家扔的烟 → 挡敌人（forEnemy=true 时照常生效），不挡玩家自己（forEnemy 为空/假时跳过）
     · 敌人扔的烟 → 只挡玩家，敌人自己人看得穿
   以前只写了「敌人烟不挡敌人」，玩家扔的烟却连自己都挡，导致扔完烟自己瞎。 */
function smokeBlocks(x1, y1, x2, y2, forEnemy){
  for (const s of smokes){
    if (forEnemy && s.byEnemy) continue;      /* 敌人自己的烟，敌人看得穿 */
    if (!forEnemy && !s.byEnemy) continue;    /* 自己扔的烟，自己不瞎 */
    const R = s.r * (s.age !== undefined && s.life ? Math.min(1, s.age/0.35) : 1) * 0.94;
    if (segPointDist(x1, y1, x2, y2, s.x, s.y) < R) return true;
  }
  return false;
}

/* 这条射线在烟里能走多远：撞进烟面就断，视觉和判定用同一套圆。
   forEnemy 的语义与 smokeBlocks 一致：自己的烟不切自己的光锥。 */
function raySmokeCut(ox, oy, ang, maxLen, forEnemy){
  const dx = Math.cos(ang), dy = Math.sin(ang);
  let best = maxLen;
  for (const s of smokes){
    if (forEnemy && s.byEnemy) continue;
    if (!forEnemy && !s.byEnemy) continue;
    const R = s.r * 0.94;
    const ex = ox - s.x, ey = oy - s.y;
    const b = ex*dx + ey*dy;
    const c = ex*ex + ey*ey - R*R;
    if (c <= 0) return 0;
    const disc = b*b - c;
    if (disc < 0) continue;
    const t = -b - Math.sqrt(disc);
    if (t > 0 && t < best) best = t;
  }
  return best;
}

function bossSeesNow(b){
  if (!b) return false;
  /* 烟永远有效：你在烟里，或者烟挡在中间 —— 就算他"已经暴露了你的位置"也一样 */
  if (concealed) return false;
  if (smokeBlocks(b.x, b.y, player.x, player.y, true)) return false;
  if (bossExposed) return true;
  const d = dist(b.x, b.y, player.x, player.y);
  const rng = enemyVisionRange(b);
  if (d > rng) return false;
  if (losBlocked(b.x, b.y, player.x, player.y)) return false;
  const a = Math.atan2(player.y-b.y, player.x-b.x);
  return Math.cos(normAng(a - b.ang)) >= Math.cos((enemyType(b).fov || 68)*Math.PI/180);
}

/* 一个点是不是踩在墙上（猎手挑目标点时要用） */
function ptInWall(L, x, y, pad){
  return L.walls.some(w => x > w.x-pad && x < w.x+w.w+pad && y > w.y-pad && y < w.y+w.h+pad);
}

const _BOSS_PATROL_PATH_START={x:0,y:0}, _BOSS_PATROL_PATH_GOAL={x:0,y:0};
function bossPickPatrol(b){
  const L = cur();
  _BOSS_PATROL_PATH_START.x=b.x;_BOSS_PATROL_PATH_START.y=b.y;
  const setPatrol = (x,y) => {
    b._patrolPending=null;
    b.wp = [[x,y]]; b.i = 0;
    /* 新巡逻目标不沿用旧路径，也不受旧朝向的绕路锁限制。 */
    b.path = null; b.goal = null; b.navT = 0; b.wpRef = null; b.wpStall = 0;
  };
  if(b._patrolPending){
    const p=b._patrolPending;
    _BOSS_PATROL_PATH_GOAL.x=p.x;_BOSS_PATROL_PATH_GOAL.y=p.y;
    const path=NavQuery.findPath(L,_BOSS_PATROL_PATH_START,_BOSS_PATROL_PATH_GOAL);
    if(navWork.deferred)return;
    b._patrolPending=null;
    if(path){setPatrol(p.x,p.y);return;}
  }
  /* 守卫守在自己那一小片，但要走"一段路"，不能原地小碎步换点——
     以前每次只挑 ±90 内的点、几十像素就换一个，看起来像在墙角抽抽。
     现在要求：离当前位置至少 70px（走到才算一段），范围放宽到 ±150。 */
  if (enemyType(b).leash && b.guardSpot){
    let gx = b.guardSpot.x, gy = b.guardSpot.y;
    /* 顶部驻点被墙围住，允许配置更大的巡逻范围，覆盖周边通道。 */
    const patrolRadius = b.patrolRadius || 150;
    const minLeg = patrolRadius > 150 ? 180 : 70;
    for (let k=0;k<40;k++){
      const cx2 = clamp(b.guardSpot.x + rand(-patrolRadius, patrolRadius), 40, L.w-40);
      const cy2 = clamp(b.guardSpot.y + rand(-patrolRadius, patrolRadius), 40, L.h-40);
      if (ptInWall(L, cx2, cy2, 30)) continue;
      if (dist(cx2, cy2, b.x, b.y) < minLeg) continue;      /* 太近，一步就到，会变成原地踏步 */
      _BOSS_PATROL_PATH_GOAL.x=cx2;_BOSS_PATROL_PATH_GOAL.y=cy2;
      if (!NavQuery.findPath(L,_BOSS_PATROL_PATH_START,_BOSS_PATROL_PATH_GOAL)){
        if(navWork.deferred){b._patrolPending={x:cx2,y:cy2};return;}
        continue;
      }
      gx = cx2; gy = cy2; break;
    }
    setPatrol(gx, gy); return;
  }
  /* 光看"不在墙里"不够：目标要真能走到。走不到的点会让人机一路贴着墙推，
     看起来就是"进去了出不来"。这里用导航网格验证一次连通性。 */
  for (let k=0;k<80;k++){
    const x = rand(80, L.w-80), y = rand(80, L.h-80);
    if (L.walls.some(w => x > w.x-30 && x < w.x+w.w+30 && y > w.y-30 && y < w.y+w.h+30)) continue;
    if (dist(x,y,player.x,player.y) < 260) continue;
    _BOSS_PATROL_PATH_GOAL.x=x;_BOSS_PATROL_PATH_GOAL.y=y;
    if (!NavQuery.findPath(L,_BOSS_PATROL_PATH_START,_BOSS_PATROL_PATH_GOAL)){
      if(navWork.deferred){b._patrolPending={x,y};return;}
      continue;      /* 确实走不到才换一个；预算排队保留同一个候选。 */
    }
    setPatrol(x, y); return;
  }
  /* 一个都挑不出来就原地待命，别给个走不到的目标 */
  setPatrol(b.x, b.y);
}

/* 气动门：一段噪声 + 低频"噗"，开门升调、关门降调 */
/* 门响的距离系数：1 = 就在耳边，0 = 压根不该听见。
   大图上门口一百多扇、两百多号人来回走，离得远的门响不该占着耳朵。 */
function doorSndK(px, py){
  if (px == null || py == null) return 1;
  if (typeof player === 'undefined' || !player) return 1;
  /* m35424：坐标非有限时返回 0（听不见），别把 NaN 传进音频参数 */
  if (!isFinite(px) || !isFinite(py) || !isFinite(player.x) || !isFinite(player.y)) return 0;
  return Math.max(0, 1 - dist(px, py, player.x, player.y) / 1100);
}
/* 同一瞬间几十扇门一起开关会变成"合唱"，这里给个全局节流 */
let _doorSndT = -1e9;
function sfxDoor(opening, px, py){
  if (!actx || !actx.createBuffer) return;
  const _k = doorSndK(px, py);
  /* m35424：玩家/门坐标是 NaN 时 _k 也是 NaN，后面 exponentialRampToValueAtTime(NaN) 会抛，
     一次门响就把整帧更新打断。非法值直接跳过这一次。 */
  if (!isFinite(_k)) return;
  if (_k <= 0.05) return;
  const _nowMs = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  if (_nowMs - _doorSndT < 150) return;
  _doorSndT = _nowMs;
  let _pan = null;
  if (px != null && py != null) _pan = (typeof sfxPan === 'function') ? sfxPan(px, py) : null;
  try {
    const t0 = actx.currentTime + 0.01;
    const n = actx.createBuffer(1, Math.floor(actx.sampleRate * 0.30), actx.sampleRate);
    const ch = n.getChannelData(0);
    for (let i=0;i<ch.length;i++){
      const k = 1 - i/ch.length;
      ch[i] = (Math.random()*2-1) * k * k;
    }
    const src = actx.createBufferSource(); src.buffer = n;
    const lp = actx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(opening ? 1400 : 900, t0);
    lp.frequency.linearRampToValueAtTime(opening ? 2400 : 420, t0 + 0.28);
    const g = actx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(0.30 * _k, t0 + 0.03);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.30);
    src.connect(lp); lp.connect(g);
    if (_pan){ g.connect(_pan); _pan.connect(duckBus()); } else g.connect(duckBus());
    src.start(t0); src.stop(t0 + 0.32);
    /* 机械"咔"的那一下 */
    const o = actx.createOscillator(), og = actx.createGain();
    o.type = 'square';
    o.frequency.setValueAtTime(opening ? 210 : 160, t0);
    og.gain.setValueAtTime(0.0001, t0);
    og.gain.linearRampToValueAtTime(0.10 * _k, t0 + 0.008);
    og.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.09);
    o.connect(og);
    if (_pan) og.connect(_pan); else og.connect(duckBus());
    o.start(t0); o.stop(t0 + 0.11);
  } catch (e){ if (typeof reportErr === 'function') reportErr('42-actors', e); }
}
