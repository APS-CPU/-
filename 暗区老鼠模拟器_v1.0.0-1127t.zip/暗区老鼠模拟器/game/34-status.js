/* ============ 状态与冷却的统一入口 ============
   状态的"是什么"写在 data/status.js 的 ESTATUS_DEF 里，
   这里只有四个动词：挂上、查询、递时间、取移速倍率。
   以前 stun 是直接改 e.spdK（还拿 _spdK0 存旧值再还回去），
   于是"哪条路忘了乘 spdK"就变成 bug（逃跑那次就是这么漏的）。
   现在基础倍率 e.spdK 谁都不许动，状态只是乘上去的一个因子。 */
function eStatusDef(key){
  return (typeof ESTATUS_DEF !== 'undefined' && ESTATUS_DEF[key]) ? ESTATUS_DEF[key] : null;
}
/* 挂上状态（同名字取更长的那个时间，不覆盖） */
function eStatusSet(e, key, t){
  const d = eStatusDef(key);
  if (!d || !e || !(t > 0)) return false;
  e[d.field] = Math.max(e[d.field] || 0, t);
  if (key === 'stun') e.stunMax = Math.max(e.stunMax || 0, e[d.field]);
  if (d.raise) for (const k in d.raise) e[k] = Math.max(e[k] || 0, d.raise[k]);
  if (d.clear) for (const k in d.clear) e[k] = d.clear[k];
  return true;
}
function eStatusHas(e, key){
  const d = eStatusDef(key);
  return !!(d && e && (e[d.field] || 0) > 0);
}
/* 每帧把这个"手上的活全停"的清理压一遍：状态还挂着的时候，
   别的分支也别想偷偷把 hideGoal / peekPhase 写回来。 */
function eStatusHold(e, key){
  const d = eStatusDef(key);
  if (!d || !e || !(e[d.field] > 0) || !d.clear) return false;
  for (const k in d.clear) e[k] = d.clear[k];
  return true;
}
/* 有些状态"到期"不是一个纯粹的减法：恐惧到期要看玩家是不是还端着枪，
   如果还架着，就得续一段继续缩着。数据层只写 tick:'fear' 这个钩子名，
   真正的判断放在本文件下面的 STATUS_TICK_FNS 里 —— 数据是数据，逻辑是逻辑。 */
const STATUS_TICK_FNS = {
  /* 呼叫支援：前摇跑完再广播；中途喊一句，玩家有机会打断 */
  call: function(e, dt, d){
    e.callT = Math.max(0, (e.callT || 0) - dt);
    const D = backupDef();
    const _el = (D.windup || 3) - e.callT;
    if (!e.callBark && _el >= (D.barkAt || 1.5)){
      e.callBark = true;
      setBark(e, '请求支援！', 2.4, 3, false);
      if (!ar) sfxAlarm();
    }
    if (e.callT > 0) return true;
    if (!e.callDone){ e.callDone = true; backupDispatch(e, D); }
    return false;
  },
  suppress: function(e, dt, d){
    e.suppressT = Math.max(0, (e.suppressT || 0) - dt);
    if (e.suppressT > 0) return true;
    /* 打完这一轮给个冷却：不然中一枪就无限压着打 */
    const _sdl2 = Math.max(0, DIFF_ORDER.indexOf(diffName));
    e.suppressCd = Math.max(0.45, rand(1.0, 1.8) - _sdl2 * 0.24);
    return false;
  },
  fear: function(e, dt, d){
    e.fearT = Math.max(0, (e.fearT || 0) - dt);
    if (e.fearT > 0) return true;                    /* 还怕着 */
    const _pd = dist(e.x, e.y, player.x, player.y);
    const _reload = !!(player && player.gun && player.gun.reloading > 0);
    const _corner = _pd < HUMAN.closeR;
    if (e.hideGoal && !_reload && !_corner){
      e.fearT = 1.6;                                 /* 玩家还架着枪：不敢出去，续一段 */
      return true;
    }
    if (_corner && !_reload){
      e.blindCd = HUMAN.blindCd * reactK(e); e.blindShot = true;
      voiceSay(e, 'cornered', 0.7, 3);               /* 退无可退：拼了 */
    }
    return false;                                    /* 真的结束了 */
  }
};
/* 递时间：所有状态一次走完，到期补 onEnd */
function eStatusTick(e, dt){
  if (!e || !(dt > 0)) return;
  for (const key in ESTATUS_DEF){
    const d = ESTATUS_DEF[key];
    if (!d || !(e[d.field] > 0)) continue;
    const fn = (d.tick && typeof STATUS_TICK_FNS[d.tick] === 'function') ? STATUS_TICK_FNS[d.tick] : null;
    if (fn){
      if (fn(e, dt, d)) continue;                    /* 钩子说"还没完" */
      e[d.field] = 0;
      if (d.onEnd) for (const k in d.onEnd) e[k] = d.onEnd[k];
      continue;
    }
    e[d.field] = Math.max(0, e[d.field] - dt);
    if (e[d.field] <= 0){
      e[d.field] = 0;
      if (d.onEnd) for (const k in d.onEnd) e[k] = d.onEnd[k];
    }
  }
}
/* 立刻掐掉一个状态（不跑到期动作）——关卡重置、架枪被打断这类场景用 */
function eStatusClear(e, key){
  const d = eStatusDef(key);
  if (!d || !e) return false;
  if (!(e[d.field] > 0)) return false;
  e[d.field] = 0;
  return true;
}
/* 状态乘出来的移速倍率（1 = 没影响） */
function eStatusSpdK(e){
  let k = 1;
  for (const key in ESTATUS_DEF){
    const d = ESTATUS_DEF[key];
    if (d && (e[d.field] || 0) > 0 && d.eff && typeof d.eff.spdK === 'number') k *= d.eff.spdK;
  }
  return k;
}
/* AI 里所有速度都应该乘这个：基础倍率（体型/行为）× 状态倍率 */
function eMoveK(e){
  /* marchK：观战图里"行军"用的减速（m41535），别的模式恒为 1，不影响手感 */
  const base = ((e && e.spdK) || 1) * ((e && e.marchK) || 1);
  /* 铁丝网：AI 踩在网里一样走不动（和玩家共用 WIRE_DEF.slowK）。
     这里**现场按坐标判**，不用每帧刷的 e.inWire —— eMoveK 会被好几个地方调用，
     用一个可能过期的标记，测试里"恐惧不改移速"就会莫名其妙变 0.42。 */
  let wk = 1;
  if (e && typeof wireAt === 'function' && wires.length &&
      wireAt(e.x, e.y, 2)) wk = ((typeof WIRE_DEF !== 'undefined' && WIRE_DEF.slowK) || 0.45);
  return base * eStatusSpdK(e) * wk;
}
/* 一票否决：眩晕期间不许开火 / 不许做战术动作 */
function eStatusNo(e, what){
  for (const key in ESTATUS_DEF){
    const d = ESTATUS_DEF[key];
    if (d && (e[d.field] || 0) > 0 && d.eff && d.eff[what]) return true;
  }
  return false;
}
function eStatusList(e){
  const out = [];
  for (const key in ESTATUS_DEF){
    const d = ESTATUS_DEF[key];
    if (d && (e[d.field] || 0) > 0) out.push({ key: key, label: d.label, col: d.col, t: e[d.field], max: (key === 'stun' ? (e.stunMax || e[d.field]) : e[d.field]) });
  }
  return out;
}

/* ---- 冷却：读、写、每帧递减，只有这三个动词 ---- */
function eCdDef(key){ return (typeof E_CD_DEF !== 'undefined' && E_CD_DEF[key]) ? E_CD_DEF[key] : null; }
function eCd(e, key){ return (e && e[key] > 0) ? e[key] : 0; }
function eCdSet(e, key, v){
  if (!e) return;
  if (!eCdDef(key) && typeof console !== 'undefined') console.warn('[cd] 未登记的冷却: ' + key + '（去 data/status.js 的 E_CD_DEF 里登记）');
  e[key] = Math.max(e[key] || 0, v);
}
function eCdTick(e, dt){
  if (!e || !(dt > 0)) return;
  for (const k in E_CD_DEF){
    if (E_CD_DEF[k].mode !== 'tick') continue;
    if ((e[k] || 0) > 0) e[k] = Math.max(0, e[k] - dt);
  }
}

/* 眩晕仍然叫 enemyStun（八处调用点不用改），但它现在只是"挂个状态" */
function enemyStun(e, t){
  if (!e || e.dead || !(t > 0)) return;
  const T = (typeof enemyType === 'function') ? enemyType(e) : null;
  if (T && (T.static || T.fly)) return;          /* 摄像头/无人机不吃这套 */
  eStatusSet(e, 'stun', t);
  if (typeof setBark === 'function') setBark(e, pickBark(['呃……', '（被震得耳朵嗡嗡响）', '（站都站不稳）']), 1.6);
}
/* 爆炸和某个点之间有没有"死墙"挡着：死墙后面完全吃不到伤害 */
/* 爆炸点的判定要往里收 2px：
   火箭弹是"撞在墙面上"炸的，爆炸点正好贴在墙的边界上，
   从爆炸点连到近侧玩家的线段会擦到那堵墙的边，被判成"被墙挡死" → 贴脸也没伤害。
   把墙矩形内缩一点，擦边就不算阻挡，真正穿过墙体才算。 */
const BLAST_INSET = 2.0;
function blastRect(w){
  return { x: w.x + BLAST_INSET, y: w.y + BLAST_INSET,
           w: w.w - BLAST_INSET * 2, h: w.h - BLAST_INSET * 2 };
}
function blastBlocked(x1, y1, x2, y2, targetWall){
  const L = cur();
  for (const w of rayWallCandidates(L,x1,y1,x2-x1,y2-y1,1)){
    if (w===targetWall || w.dead || w.glass || w.brk) continue;
    const r = blastRect(w);
    if (r.w <= 0 || r.h <= 0) continue;
    if (CollisionQuery.segmentHitsRect(x1, y1, x2, y2, r)) return true;
  }
  return false;
}
/* 隔着一堵可破坏墙：伤害打个折（玻璃不挡） */
function blastCoverFactor(x1, y1, x2, y2){
  const L = cur();
  for (const w of rayWallCandidates(L,x1,y1,x2-x1,y2-y1,1)){
    if (w.dead || w.glass || !w.brk) continue;
    const r = blastRect(w);
    if (r.w <= 0 || r.h <= 0) continue;
    if (segHitsRect(x1, y1, x2, y2, r)) return 0.75;
  }
  return 1;
}
const _STATUS_AREA_PERMISSION_REQUEST={source:null,target:null};
const _STATUS_AREA_PERMISSION_RESULT={};
function statusAreaPermission(source,target){
  _STATUS_AREA_PERMISSION_REQUEST.source=source;
  _STATUS_AREA_PERMISSION_REQUEST.target=target;
  return CombatQuery.areaPermission(_STATUS_AREA_PERMISSION_REQUEST,_STATUS_AREA_PERMISSION_RESULT).allowed;
}
const ROCKET_R = ROCKET_DEF.blastRadius;
const ROCKET_DMG_CENTER = ROCKET_DEF.damageCenter;
const ROCKET_DMG_EDGE = ROCKET_DEF.damageEdge;
const ROCKET_DMG_FALLOFF_POWER = ROCKET_DEF.damageFalloffPower;
/* 战斗，爽！！专属的爆炸半径倍率（【高爆弹头】每层 +12%，最多三层）。
   伤害衰减曲线也跟着这个半径走：圈放大多少，边缘那一圈的伤害就推到多远，
   不是"圈画大了但边上空着"。故事关没有这张卡，倍率恒 1。 */
const ROCKET_ARENA_BOOM_K = 0.12;
function arenaRocketRadiusK(){
  if (!ar) return 1;
  return 1 + ROCKET_ARENA_BOOM_K * Math.min(3, ar.rwBoom | 0);
}
function rocketK(d){
  return clamp(1 - 0.62 * clamp(d / ROCKET_R, 0, 1), 0, 1);
}
/* 伤害随距离是"平方衰减"而不是线性：
   线性的时候，圈内 200px 就已经 88 点（人 100 血），再近一点点就死了，
   边缘之外又是 0 —— 手感上就是"要么无伤、要么秒死"。
   改成 (1 - d/R)^2.2 之后：贴脸 150 → 半步外 105 → 半圈 72 → 大半圈 35 → 圈边 30，
   一整条都是"疼但死不了"，只有真的贴上去才会被炸死。 */
function rocketDmgAt(d, R){
  const k = Math.pow(clamp(1 - d / (R || ROCKET_R), 0, 1), ROCKET_DMG_FALLOFF_POWER);
  return Math.round(ROCKET_DMG_EDGE + (ROCKET_DMG_CENTER - ROCKET_DMG_EDGE) * k);
}
function rocketBlast(x, y, source){
  if (typeof sfxRocketBoom === 'function') sfxRocketBoom(x, y, source === player);
  const screenFeedback=!(typeof mobaSuppressCombatFeedback==='function' && mobaSuppressCombatFeedback(source));
  if (typeof tripFuseNear === 'function') tripFuseNear(x, y, 140);
  /* 割草里【高爆弹头】会把整圈等比放大；故事关 arenaRocketRadiusK() 恒 1 */
  const _R = ROCKET_R * arenaRocketRadiusK();
  const L = cur();
  /* 拆掩体：范围内的可破坏墙吃一大坨伤害 */
  for (const w of L.walls){
    if (w.dead || w.glass) continue;
    if (w === source) continue;                /* 开炮的炮塔自己不吃这一发 */
    if (!w.brk && !w.decor) continue;          /* 装饰物（桌/椅）也算可破坏 */
    const nx = clamp(x, w.x, w.x + w.w), ny = clamp(y, w.y, w.y + w.h);
    if (dist(x, y, nx, ny) > _R * 0.8) continue;
    damageWall(w, 620, nx, ny, Math.atan2(y - ny, x - nx),source);
  }
  /* 不挡路但有血的装饰物（瓦罐）不在墙表里，爆炸要单独照顾一次 */
  if (typeof decors !== 'undefined' && decors.length){
    for (const _d of decors){
      if (_d.dead || !_d._w || !(_d.hp > 0)) continue;
      const nx = clamp(x, _d.x, _d.x + _d.w), ny = clamp(y, _d.y, _d.y + _d.h);
      if (dist(x, y, nx, ny) > _R * 0.8) continue;
      if (blastBlocked(x, y, nx, ny)) continue;
      damageDecor(_d._w, 620, nx, ny, Math.atan2(ny - y, nx - x));
    }
  }
  /* 玻璃：冲击波范围内的玻璃一并震碎（以前只有弹丸直击才碎，炸旁边它纹丝不动） */
  {
    const _gl = [];
    for (const w of L.walls){
      if (w.dead || !w.glass) continue;
      const nx = clamp(x, w.x, w.x + w.w), ny = clamp(y, w.y, w.y + w.h);
      if (dist(x, y, nx, ny) > _R * 0.8) continue;
      if (blastBlocked(x, y, nx, ny)) continue;      /* 隔着实体墙就别碎了 */
      _gl.push({ w: w, nx: nx, ny: ny });
    }
    for (const _g of _gl) shatterGlass(_g.w, _g.nx, _g.ny, Math.atan2(y - _g.ny, x - _g.nx));
  }
  /* 门：爆炸波也啃门（关着的才算，开着的门板已经转开、炸不着） */
  if (typeof doors !== 'undefined' && doors.length){
    for (const _d of doors){
      if (_d.broken || !doorSolid(_d)) continue;
      const nx = clamp(x, _d.x, _d.x + _d.w), ny = clamp(y, _d.y, _d.y + _d.h);
      if (dist(x, y, nx, ny) > _R * 0.8) continue;
      if (blastBlocked(x, y, nx, ny)) continue;
      damageDoor(_d, Math.round(220 * rocketK(dist(x, y, nx, ny))), nx, ny,
                 Math.atan2(ny - y, nx - x), false);
    }
  }
  /* 铁丝网：子弹打不坏，只有爆炸能撕开（圈内按距离给伤害） */
  if (typeof wires !== 'undefined' && wires.length){
    for (const _w of wires){
      if (_w.dead) continue;
      const nx = clamp(x, _w.x, _w.x + _w.w), ny = clamp(y, _w.y, _w.y + _w.h);
      const _wd = dist(x, y, nx, ny);
      if (_wd > _R * 0.8) continue;
      if (blastBlocked(x, y, nx, ny)) continue;
      damageWire(_w, Math.round(90 + 160 * rocketK(_wd)), nx, ny);
    }
  }
  /* 玩家。战斗，爽！！里自己的炮不炸自己：这个模式是拿来爽的，
     贴脸开炮的惩罚交给"打不死人 + 白瞎一发弹药"，不交给"炸死自己"。
     故事关里照旧，一点都没改。 */
  if (player && player.hp > 0 && !player.god && statusAreaPermission(source,player) &&
      !(ar && source === player)){
    const d = dist(x, y, player.x, player.y);
    if (d <= _R && !blastBlocked(x, y, player.x, player.y)){
      const k = rocketK(d), cov = blastCoverFactor(x, y, player.x, player.y);
      const dmg = Math.max(1, Math.round(rocketDmgAt(d, _R) * cov));
      player.hp -= absorbArmor(dmg, 'blast');
      hurtNum(dmg);
      player.flash = 1; hitFlash = 1; camShake = Math.max(camShake, 0.9);
      /* 火箭筒：半径是手雷的 1.9 倍，按自己的半径归一化，残留更久、震感更强 */
      if (typeof blastFilterStart === 'function') blastFilterStart(x, y, k, { d: d, radius: _R, lenK: 1.35, shakeK: 1.6 });
      /* 眩晕：越靠近中心越久（1.8s → 0.5s） */
      const stun = 0.7 + 1.6 * k;
      player.stunT = Math.max(player.stunT || 0, stun);
      visionBlind = Math.max(visionBlind, 0.55 * k);
      /* 模糊：近距离几乎是满糊，而且"糊住"一段时间再退 */
      visionBlur = Math.max(visionBlur, 0.72 + 0.28 * k);
      visionBlurHold = Math.max(visionBlurHold, 1.2 + 3.6 * k);
      /* 冲击波：把人往外掀（越靠中心推力越大） */
      const _kx = (player.x - x) / Math.max(1, d), _ky = (player.y - y) / Math.max(1, d);
      const _imp = 170 + 620 * k;
      player.kickX = (player.kickX || 0) + _kx * _imp;
      player.kickY = (player.kickY || 0) + _ky * _imp;
      /* 耳鸣：越近响越久 */
      tinStart(k);
      stOnHurt(dmg, 'blast');
      stBleedAdd(2);   /* 火箭弹：直接大出血（II 级流血） */
      if (player.hp <= 0) markDeath('blast', (source && (source.rocketTurret || source.type)) ? source : null, dmg, Math.atan2(player.y - y, player.x - x));
      logWarn('hurt', '吃火箭弹 · -' + dmg + ' HP · 剩 ' + Math.max(0, Math.round(player.hp)));
      sfxHurt();
    }
  }
  /* 运兵车：载具不在 enemies 里，以前这里整段漏掉 —— 火箭弹打在车上只冒火花不掉血 */
  if (typeof trucks !== 'undefined' && trucks){
    for (const t of trucks){
      if (!t || t.tstate === 'gone' || t.wreck) continue;
      const d = dist(x, y, t.x, t.y);
      /* 车身本身有 40 半径：贴着车壳炸也算"贴脸"，所以先扣掉半个车身再算曲线 */
      const _tp = Math.max(0, d - (t.r || 40) * 0.6);
      if (_tp > _R) continue;
      if (blastBlocked(x, y, t.x, t.y)) continue;
      const dmg = Math.max(1, Math.round(
        rocketDmgAt(_tp, _R) * ROCKET_DMG_VEHICLE * blastCoverFactor(x, y, t.x, t.y)));
      damageTruck(t, dmg, Math.atan2(t.y - y, t.x - x));
    }
  }
  const fallen = [];
  /* 敌人（测试区/正式关都用 enemies 这张表） */
  if (typeof enemies !== 'undefined' && enemies){
    for (const e of enemies.slice()){
      if (!e || e.dead) continue;
      if (!statusAreaPermission(source,e)) continue;
      /* 炮塔同阵营免伤；敌对 B 势力仍然会被它的爆炸伤到。 */
      if (source && source.rocketTurret && combatFaction(source)===combatFaction(e)) continue;
      const d = dist(x, y, e.x, e.y);
      if (d > _R) continue;
      if (blastBlocked(x, y, e.x, e.y)) continue;
      /* 冲击波：连人带烟一起往外掀 */
      const _ek = rocketK(d);
      const _ex = (e.x - x) / Math.max(1, d), _ey = (e.y - y) / Math.max(1, d);
      const _ep = 12 + 40 * _ek;
      e.x += _ex * _ep; e.y += _ey * _ep;
      if (L && L.walls) for (const _w of L.walls) pushOutCircle(e, e.r, _w);
      for (const _t of trucks) if (_t.solid) pushOutTruckCircle(e, _t);
      e.x = clamp(e.x, 14, L.w - 14); e.y = clamp(e.y, 14, L.h - 14);
      /* 自己人放的炮，炸到队友要打折：火箭兵的爆炸半径 320，不折就是"一炮清队" */
      const _D2 = rpgDef();
      const _allyK = (source && combatFaction(source) === combatFaction(e) && source.type)
        ? ((_D2 && _D2.allyDmgK !== undefined) ? _D2.allyDmgK : 1) : 1;
      /* 战斗，爽！！：吃「伤害强化」这一条乘法 + 模式专属倍率；不吃暴击（crit 在子弹管线里，碰不到这里） */
      const dmg = Math.max(1, Math.round(rocketDmgAt(d, _R) * blastCoverFactor(x, y, e.x, e.y) * _allyK *
                                            arenaRocketDmgK()));
      e.hp -= dmg;
      e.rocketBlastMuteUntil = timeAlive + ROCKET_HEARING.hitBlastCooldown;
      if(typeof factionNoteDamage==='function')factionNoteDamage(e,source,dmg,'rocketBlast');
      if (e.hp <= 0 && typeof combatFinishNPC === 'function') combatFinishNPC(e,source,Math.atan2(e.y-y,e.x-x),fallen);
      else if (e.hp <= 0 && typeof killTestEnemy === 'function'){ arKillSrc = 'blast'; killTestEnemy(e,fallen); arKillSrc = 'bullet'; }
      else enemyStun(e, 0.9 + 2.3 * rocketK(d));      /* 贴脸 3.2s、圈边 0.9s */
    }
  }
  for (const a of allies.slice()){
    const d=dist(x,y,a.x,a.y);
    if(d>_R||blastBlocked(x,y,a.x,a.y)||!statusAreaPermission(source,a))continue;
    companionDamage(a,Math.max(1,Math.round(rocketDmgAt(d, _R)*blastCoverFactor(x,y,a.x,a.y))),source,'blast',Math.atan2(a.y-y,a.x-x));
    if(!a.dead)enemyStun(a,.9+2.3*rocketK(d));
  }
  queueBlastComradeFalls(fallen,source && combatFaction(source)!=='player' ? source : player);
  /* 先让受伤者进入忽略期，再向其他听众投递炸点。 */
  gunNoise(ROCKET_NOISE_BLAST, x, y, source || player, 'rocketBlast');
  /* 爆炸视觉：白光 + 两道冲击波 + 往上翻的黑烟 */
  bossBlastFx(x, y, _R,screenFeedback);
  if (typeof rocketFxStart === 'function') rocketFxStart(x, y, _R, screenFeedback);
  spawnPart(x, y, 0, 0, 0.30, 'flash', _R * 0.62);
  /* 以前这里还撒两圈 'ring' 粒子，尺寸是 R 的 0.78/1.18 倍、再被粒子绘制放大到 1.95 倍，
     所以画出来的圆根本不代表杀伤范围 —— 和真正的圈混在一起，【高爆弹头】放大了也看不出来。
     现在统一由 drawBlastRings() 那一道实线圈（= 真实半径）负责说明范围。 */
  for (let i = 0; i < 30; i++){
    const _ba = fxRand(0, TAU), _bd = fxRand(0, _R * 0.55);
    spawnPart(x + Math.cos(_ba)*_bd, y + Math.sin(_ba)*_bd, _ba, fxRand(6, 52),
              fxRand(0.9, 2.0), 'bsmoke', fxRand(6, 13));
  }
  scorchMarks.push({ x:x, y:y, r:_R * 0.30, t:0 });
  /* 冲击波圈：半径就是真实杀伤半径，高爆弹叠一层就明显大一圈 */
  blastRings.push({ x:x, y:y, R:_R, t:0, life:1.15 });
  if(screenFeedback){
    fxFlash = Math.max(fxFlash, 0.9);
    camShake = Math.max(camShake, 1.25 + 0.45 * (arenaRocketRadiusK() - 1));
  }
  beep(58, 0.55, 'sawtooth', 0.3, 26);
  noiseBurst(0.62, 420, 1.0, 1.25);
  logWarn('gun', '火箭弹爆炸 · 中心 ' + ROCKET_DMG_CENTER + ' / 外圈 ' + ROCKET_DMG_EDGE + ' · 半径 ' + _R + (fallen.length ? ' · 击倒 ' + fallen.length + ' 名敌人' : ''));
}
function fireRocket(a){
  const g = player.gun; if (!g) return;
  /* 枪口在身前 22px：如果 22px 之内就有墙，把弹丸生成在墙面前 1px，
     否则会出现"弹丸出生在墙体内部、擦着墙飞出去不炸"的情况（贴脸开炮炸不到人） */
  let _muz = 22;
  const _dx = Math.cos(a), _dy = Math.sin(a);
  for (const w of cur().walls){
    if (w.dead || w.glass) continue;
    const _t = rayEnter(player.x, player.y, _dx, _dy, w, _muz);
    if (_t >= 0 && _t < _muz) _muz = Math.max(1, _t - 1);
  }
  const ax = player.x + _dx * _muz, ay = player.y + _dy * _muz;
  const _rocket = spawnBullet(ax, ay, ax - Math.cos(a)*6, ay - Math.sin(a)*6,
              Math.cos(a)*ROCKET_SPD, Math.sin(a)*ROCKET_SPD,
              player, ROCKET_LIFE, g.dmg, true, ROCKET_BODY_R, false);
  /* 玩家这发可以直接"打地面"：落点 = 开火瞬间准星所指的地面。
     弹道中途撞墙/撞门/撞人/撞车仍会按原逻辑提前引爆（那些判定排在落点引信之前），
     只有一路飞过去的，才在准星处空炸 —— 不再必须飞到地图另一头的墙上才有反应。 */
  if (_rocket && typeof mouseWorldX === 'function' && typeof mouseWorldY === 'function'){
    const _lx = mouseWorldX(), _ly = mouseWorldY();
    if (dist(ax, ay, _lx, _ly) > 24){
      _rocket.landFuse = true;
      _rocket.landX = _lx;
      _rocket.landY = _ly;
    }
  }
  /* 尾焰：一小股白烟往后喷 */
  for (let i = 0; i < 7; i++)
    spawnPart(ax, ay, a + Math.PI + fxRand(-0.5, 0.5), fxRand(60, 220), fxRand(0.16, 0.4), 'smoke', fxRand(2.5, 5));
  spawnPart(ax, ay, a, 0, 0.12, 'flash', 9);
  if (typeof sfxRocketFire === 'function') sfxRocketFire();
  else sfxGunShot(g);
  camShake = Math.max(camShake, 0.5);
  /* 火箭筒的后喷比枪声吵：普通枪 2.2，这里 3.4（默认 hearR 340 → 1150px） */
  gunNoise(ROCKET_NOISE_FIRE, ax, ay, player, 'rocketLaunch');
}
