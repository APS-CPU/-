/* ===== BGM =====
   合成的那段删了，改成"你自己导入一首"。
   音频存 IndexedDB —— localStorage 只有 5MB，一首歌放不下。
   淡入淡出由 frame() 驱动（0.8 秒），所以暂停/结算时是慢慢小的，不是硬切。 */
let bgmEl = null, bgmVol = 0, bgmWant = 0, bgmName = '', bgmUrl = '';
/* 三个可调：淡入淡出时长、音量、三选一时要不要继续放 */
const BGM_FADE = 0.8;
let bgmFade = 0.8, bgmVolume = 0.85, bgmHoldFreeze = false;
try {
  const _bc = JSON.parse(localStorage.getItem('after5_bgmcfg') || '{}');
  if (typeof _bc.fade === 'number') bgmFade = Math.min(2, Math.max(0.2, _bc.fade));
  if (typeof _bc.vol === 'number') bgmVolume = Math.min(1, Math.max(0, _bc.vol));
  if (typeof _bc.hold === 'boolean') bgmHoldFreeze = _bc.hold;
} catch(e){}
function saveBgmCfg(){
  try {
    localStorage.setItem('after5_bgmcfg',
      JSON.stringify({fade: bgmFade, vol: bgmVolume, hold: bgmHoldFreeze}));
  } catch(e){}
}

function bgmInit(){
  if (bgmEl) return;
  if (typeof Audio === 'undefined') return;   /* node 桩件里没有 Audio，直接跳过 */
  bgmEl = new Audio();
  bgmEl.loop = true;
  bgmEl.preload = 'auto';
  bgmEl.volume = 0;
  bgmEl.addEventListener('error', ()=>{
    setMsg('这首曲子放不了（浏览器不支持这个格式）', 3);
    bgmSetStatus('读取失败');
  });
}

function bgmSetStatus(txt){
  const el = document.getElementById('bgmName');
  if (el) el.textContent = '背景音乐：' + txt;
}

function bgmWanted(){
  if (!musicOn || !bgmEl || !bgmEl.src) return 0;
  if (state !== 'play') return 0;
  if (paused || mapOpen || ui.inv.open) return 0;
  if (ar && ar.freeze && !bgmHoldFreeze) return 0;
  return 1;
}

function bgmTick(dt){
  if (!bgmEl) return;
  bgmWant = bgmWanted();
  const step = dt / Math.max(0.05, bgmFade);
  if (bgmVol < bgmWant) bgmVol = Math.min(bgmWant, bgmVol + step);
  else if (bgmVol > bgmWant) bgmVol = Math.max(bgmWant, bgmVol - step);
  try { bgmEl.volume = Math.max(0, Math.min(1, bgmVol * bgmVolume)); } catch(e){}
  if (bgmVol > 0.002 && bgmEl.paused){
    const pr = bgmEl.play();
    if (pr && pr.catch) pr.catch(()=>{});
  }
  if (bgmVol <= 0.002 && !bgmEl.paused){
    try { bgmEl.pause(); } catch(e){}
  }
}

/* --- 3.2 IndexedDB 小工具 --- */
function idbOpen(){
  return new Promise((res, rej)=>{
    const r = indexedDB.open('after5_bgm', 1);
    r.onupgradeneeded = ()=>{ r.result.createObjectStore('kv'); };
    r.onsuccess = ()=> res(r.result);
    r.onerror = ()=> rej(r.error);
  });
}
function idbPut(k, v){
  return idbOpen().then(db => new Promise((res, rej)=>{
    const t = db.transaction('kv', 'readwrite');
    t.objectStore('kv').put(v, k);
    t.oncomplete = ()=> res(true);
    t.onerror = ()=> rej(t.error);
  }));
}
function idbGet(k){
  return idbOpen().then(db => new Promise((res, rej)=>{
    const t = db.transaction('kv', 'readonly');
    const q = t.objectStore('kv').get(k);
    q.onsuccess = ()=> res(q.result);
    q.onerror = ()=> rej(q.error);
  }));
}
function idbDel(k){
  return idbOpen().then(db => new Promise((res, rej)=>{
    const t = db.transaction('kv', 'readwrite');
    t.objectStore('kv').delete(k);
    t.oncomplete = ()=> res(true);
    t.onerror = ()=> rej(t.error);
  }));
}

function withTimeout(pr, ms, fallback){
  return Promise.race([
    pr.catch(()=> fallback),
    new Promise(res=> setTimeout(()=> res(fallback), ms))
  ]);
}

/* --- 3.3 换曲子 / 载入 / 清空 --- */
function bgmApply(blob, name){
  bgmInit();
  if (bgmUrl){ try{ URL.revokeObjectURL(bgmUrl); }catch(e){} }
  bgmUrl = URL.createObjectURL(blob);
  bgmEl.src = bgmUrl;
  bgmEl.volume = 0;
  bgmVol = 0;
  bgmName = name || '导入的音乐';
  bgmSetStatus(bgmName);
}

function bgmLoadSaved(){
  bgmInit();
  if (!bgmEl) return;
  withTimeout(idbGet('bgm'), 4000, null).then(rec=>{
    if (rec && rec.blob) bgmApply(rec.blob, rec.name);
    else bgmSetStatus('无（点「导入音乐」选一首）');
  });
}

function syncBgmTune(){
  const fr = document.getElementById('bgmFadeR'), vr = document.getElementById('bgmVolR');
  const fv = document.getElementById('bgmFadeV'), vv = document.getElementById('bgmVolV');
  const fb = document.getElementById('btnBgmFreeze');
  if (fr) fr.value = bgmFade;
  if (fv) fv.textContent = bgmFade.toFixed(1) + 's';
  if (vr) vr.value = Math.round(bgmVolume * 100);
  if (vv) vv.textContent = Math.round(bgmVolume * 100) + '%';
  if (fb) fb.textContent = '选技能时音乐不停顿：' + (bgmHoldFreeze ? '开' : '关');
}

{
  const fr = document.getElementById('bgmFadeR'), vr = document.getElementById('bgmVolR');
  const fb = document.getElementById('btnBgmFreeze');
  if (fr) fr.addEventListener('input', ()=>{
    bgmFade = Math.min(2, Math.max(0.2, Number(fr.value) || 0.8));
    syncBgmTune(); saveBgmCfg();
  });
  if (vr) vr.addEventListener('input', ()=>{
    bgmVolume = Math.min(1, Math.max(0, (Number(vr.value) || 0) / 100));
    syncBgmTune(); saveBgmCfg();
  });
  if (fb) fb.addEventListener('click', ()=>{
    bgmHoldFreeze = !bgmHoldFreeze;
    syncBgmTune(); saveBgmCfg();
  });
}

document.getElementById('btnBgmPick').addEventListener('click', ()=>{
  const f = document.getElementById('bgmFile');
  f.value = '';
  f.click();
});

document.getElementById('bgmFile').addEventListener('change', ()=>{
  const f = document.getElementById('bgmFile').files && document.getElementById('bgmFile').files[0];
  if (!f) return;
  if (f.size > 24 * 1024 * 1024){
    setMsg('这个文件太大（超过 24MB），换小一点的', 3);
    bgmSetStatus('文件太大');
    return;
  }
  bgmInit();
  const url = URL.createObjectURL(f);
  const probe = new Audio();
  let settled = false;
  const done = ok=>{
    if (settled) return;
    settled = true;
    try{ URL.revokeObjectURL(url); }catch(e){}
    if (!ok){
      setMsg('这个文件放不了，换 mp3 / ogg / wav 试试', 3);
      bgmSetStatus('导入失败');
      return;
    }
    bgmApply(f, f.name);
    setMsg('已导入：' + f.name, 2.4);
    withTimeout(idbPut('bgm', {name: f.name, blob: f, at: Date.now()}), 6000, 'timeout')
      .then(ok=>{
        if (ok === 'timeout'){
          setMsg('浏览器不让存这个文件，下次打开要重新导入', 3.4);
        }
      });
  };
  probe.preload = 'metadata';
  probe.addEventListener('loadedmetadata', ()=> done(true));
  probe.addEventListener('error', ()=> done(false));
  setTimeout(()=> done(false), 10000);
  probe.src = url;
});

document.getElementById('btnBgmClear').addEventListener('click', ()=>{
  idbDel('bgm').catch(()=>{});
  bgmInit();
  try{ bgmEl.pause(); }catch(e){}
  bgmEl.removeAttribute('src');
  try{ bgmEl.load(); }catch(e){}
  if (bgmUrl){ try{ URL.revokeObjectURL(bgmUrl); }catch(e){} bgmUrl = ''; }
  bgmVol = 0; bgmWant = 0; bgmName = '';
  bgmSetStatus('无（已恢复默认）');
  setMsg('已恢复默认：没有背景音乐', 2);
});

document.getElementById('btnMusic').addEventListener('click', ()=>{
  musicOn = !musicOn;
  try { localStorage.setItem('after5_music', musicOn ? '1' : '0'); } catch(e){}
  syncMusicBtn();
});

document.getElementById('btnShake').addEventListener('click', ()=>{
  shakeOn = !shakeOn;
  try { localStorage.setItem('after5_shake', shakeOn ? '1' : '0'); } catch(e){}
  if (!shakeOn) camShake = 0;
  syncShakeBtn();
});

bgmInit();
bgmLoadSaved();
syncBgmTune();
syncShakeBtn();

/* m32898：面板上那个主按钮的文字/行为按当前页决定。
   在「开发」页它只是"返回当前界面"——开发页出现的瞬间玩家已经在改开发者参数了，
   再让这个键去"开始游戏"会把 dev 状态、难度、关卡列表搅在一起。 */
function syncPanelPrimaryBtn(){
  const bc = document.getElementById('btnClose');
  if (!bc) return;
  const inPlay = (state === 'play' || state === 'arenaPick' || state === 'arenaOver');
  bc.textContent = (typeof panelTab !== 'undefined' && panelTab === 'dev')
    ? '返回当前界面'
    : (inPlay ? '返回游戏' : '开始游戏');
}
document.getElementById('btnClose').addEventListener('click', ()=>{
  if (typeof panelTab !== 'undefined' && panelTab === 'dev'){ closePanel(); return; }
  /* 局内打开设置时，这个键是"返回"，不该把当前这局重置掉 */
  if (state === 'play' || state === 'arenaPick' || state === 'arenaOver'){
    closePanel();
    return;
  }
  closePanel(); levelIdx = 0; reset(); state='play';
});
btnSettings.addEventListener('click', ()=> togglePanel());

const settingsCard = document.getElementById('settingsCard');
function fitSettingsCard(){
  // The canvas already scales with the viewport. Match its scale on large
  // viewports, including when browser zoom makes CSS pixels smaller.
  settingsCard.style.zoom = Math.max(1, cv.clientWidth / W || 1);
}
if (typeof ResizeObserver === 'function'){
  const settingsResize = new ResizeObserver(()=>{
    if (panelOpen()) fitSettingsCard();
  });
  settingsResize.observe(cv);
}

function openPanel(){
  fitSettingsCard();
  syncXrayBtn();
  syncTimeBtn();
  const bh = document.getElementById('btnHeatInf');
  if (bh){
    bh.textContent = '热成像无限：' + (CFG.heatInf ? '开' : '关');
    bh.style.borderColor = CFG.heatInf ? PAL.P44 : '';
  }
  syncMusicBtn();
  syncDevCheats();
  syncPanelPrimaryBtn();
  panel.classList.add('on');
  btnSettings.style.display = 'none';
  paused = true;
}
function closePanel(){
  if (bindTarget) bindCaptureCancel();
  panel.classList.remove('on');
  paused = false;
  if (state === 'menu') btnSettings.style.display = '';
}
function togglePanel(){
  if (confirmBack) return;
  if (panelOpen()) closePanel();
  else { buildRows(); openPanel(); }
}

/* ---------------- 玩法 ---------------- */
function throwGrenade(){
  if (smokeCount() <= 0) return;
  const tx = mouse.x + cam.x, ty = mouse.y + cam.y;
  const d = dist(player.x, player.y, tx, ty);
  if (d < 12) return;
  const k = Math.min(1, 350/d);
  grenades.push({ x0:player.x, y0:player.y, x:player.x, y:player.y,
                  x1:player.x+(tx-player.x)*k, y1:player.y+(ty-player.y)*k,
                  t:0, dur:0.42 });
  throwTakeOne('smoke');                    /* ver3 从格子里扣，老档扣计数 */
  sfxThrow();
  if (player && player.hand === 'smoke' && smokeCount() <= 0) player.hand = null;
  logInfo('smoke', '扔出烟雾弹 · 剩 ' + smokeCount());
}

function smokesCovering(x, y, forEnemy){
  const out = [];
  for (const s of smokes){
    if (s.life <= 0) continue;
    /* forEnemy：敌人扔的烟不替玩家"藏"——他们自己看得穿自己丢的烟，
       否则扔完烟自己也瞎了，等于自废武功 */
    if (forEnemy && s.byEnemy) continue;
    const rr = s.r * Math.min(1, s.age/0.5);
    if (dist(x,y,s.x,s.y) < rr*0.95) out.push(s);
  }
  return out;
}

function segHitsRect(x1,y1,x2,y2,rc){
  let t0 = 0, t1 = 1;
  const dx = x2-x1, dy = y2-y1;
  const p = [-dx, dx, -dy, dy];
  const q = [x1-rc.x, rc.x+rc.w-x1, y1-rc.y, rc.y+rc.h-y1];
  for (let i=0;i<4;i++){
    if (Math.abs(p[i]) < 1e-9){
      if (q[i] < 0) return false;
    } else {
      const t = q[i]/p[i];
      if (p[i] < 0){ if (t > t1) return false; if (t > t0) t0 = t; }
      else         { if (t < t0) return false; if (t < t1) t1 = t; }
    }
  }
  return true;
}

/* 从 (ox,oy) 沿 a 方向打到墙的距离，没墙就是 maxLen */
function rayEnter(ox,oy,dx,dy,rc,maxLen){
  let t0 = 0, t1 = maxLen;
  const p = [-dx, dx, -dy, dy];
  const q = [ox-rc.x, rc.x+rc.w-ox, oy-rc.y, rc.y+rc.h-oy];
  for (let i=0;i<4;i++){
    if (Math.abs(p[i]) < 1e-9){ if (q[i] < 0) return -1; }
    else {
      const t = q[i]/p[i];
      if (p[i] < 0){ if (t > t1) return -1; if (t > t0) t0 = t; }
      else         { if (t < t0) return -1; if (t < t1) t1 = t; }
    }
  }
  return t0;
}

/* 射线墙体宽相位：大图不能让每根视线都从头扫完整张 walls。
   把固定墙按 256px 方格建索引，射线只取自身包围盒经过的格子；会移动的
   装饰墙单独保留引用、每次查它的实时坐标。这样不改 rayEnter 的精确判定，
   只减少送进去的无关墙。数组、墙数或墙体几何版本一变就惰性重建。 */
const RAY_WALL_CELL = 256, RAY_WALL_INDEX_MIN = 32;
const rayWallCache = new WeakMap();
const doorGeometryCache = new WeakMap();
let wallGeomVer = 0;                    /* 同墙数、同数组下原地改墙坐标时递增 */
function addRectToRayGrid(rows, id, left, top, right, bottom){
  const x0 = Math.floor(left / RAY_WALL_CELL), x1 = Math.floor(right / RAY_WALL_CELL);
  const y0 = Math.floor(top / RAY_WALL_CELL), y1 = Math.floor(bottom / RAY_WALL_CELL);
  for (let cy = y0; cy <= y1; cy++){
    let row = rows.get(cy);
    if (!row) rows.set(cy, row = new Map());
    for (let cx = x0; cx <= x1; cx++){
      let bucket = row.get(cx);
      if (!bucket) row.set(cx, bucket = []);
      bucket.push(id);
    }
  }
}
function rayWallIndex(L){
  const walls = (L && L.walls) || [];
  let c = rayWallCache.get(L);
  if (c && c.walls === walls && c.count === walls.length && c.version === wallGeomVer) return c;
  const rows = new Map(), fixed = [], dynamic = [];
  for (let i = 0; i < walls.length; i++){
    const w = walls[i];
    /* 推动椅子时墙代理会原地改坐标，不能烘进格子；数量通常只有个位数。 */
    if (w && w.decor){ dynamic.push(w); continue; }
    const id = fixed.length;
    fixed.push(w);
    addRectToRayGrid(rows, id, w.x, w.y, w.x + w.w, w.y + w.h);
  }
  c = { walls, count: walls.length, version: wallGeomVer, rows,
        fixed, dynamic, marks: new Uint32Array(fixed.length), stamp: 0, scratch: [] };
  rayWallCache.set(L, c);
  return c;
}
function rayWallCandidates(L, ox, oy, dx, dy, maxLen){
  const ex = ox + dx * maxLen, ey = oy + dy * maxLen;
  return wallBoxCandidates(L, Math.min(ox,ex), Math.min(oy,ey), Math.max(ox,ex), Math.max(oy,ey));
}
function wallBoxCandidates(L, left, top, right, bottom){
  const walls = (L && L.walls) || [];
  if (walls.length < RAY_WALL_INDEX_MIN) return walls;
  return rayGridBoxCandidates(rayWallIndex(L), left, top, right, bottom);
}

/* 每份索引有一组临时结果，查同一份索引前先读完。 */
function rayGridBoxCandidates(c, left, top, right, bottom){
  const out = c.scratch;
  out.length = 0;
  c.stamp = (c.stamp + 1) >>> 0;
  if (!c.stamp){ c.marks.fill(0); c.stamp = 1; }
  const x0 = Math.floor(left / RAY_WALL_CELL), x1 = Math.floor(right / RAY_WALL_CELL);
  const y0 = Math.floor(top / RAY_WALL_CELL), y1 = Math.floor(bottom / RAY_WALL_CELL);
  for (let cy = y0; cy <= y1; cy++){
    const row = c.rows.get(cy);
    if (!row) continue;
    for (let cx = x0; cx <= x1; cx++){
      const bucket = row.get(cx);
      if (!bucket) continue;
      for (let k = 0; k < bucket.length; k++){
        const id = bucket[k];
        if (c.marks[id] === c.stamp) continue;
        c.marks[id] = c.stamp;
        out.push(c.fixed[id]);
      }
    }
  }
  /* 动态墙不多，直接精确扫；读的是对象此刻的坐标，不会因格子缓存而滞后。 */
  for (let i = 0; i < c.dynamic.length; i++) out.push(c.dynamic[i]);
  return out;
}
/* 平开门的两个碰撞位置都覆盖到，开关、锁和破损状态仍读门本身。 */
function doorBoxCandidates(left, top, right, bottom){
  if (doors.length < RAY_WALL_INDEX_MIN) return doors;
  let index = doorGeometryCache.get(doors);
  if (!index || index.count !== doors.length){
    const rows = new Map(), fixed = [], dynamic = [];
    for (const d of doors){
      const ox = d.swing ? d.ox : d.fx, oy = d.swing ? d.oy : d.fy;
      const ow = d.swing ? d.ow : d.fw, oh = d.swing ? d.oh : d.fh;
      const l = Math.min(d.fx, ox), t = Math.min(d.fy, oy);
      const r = Math.max(d.fx + d.fw, ox + ow), b = Math.max(d.fy + d.fh, oy + oh);
      if (!Number.isFinite(l + t + r + b)){ dynamic.push(d); continue; }
      addRectToRayGrid(rows, fixed.length, l, t, r, b);
      fixed.push(d);
    }
    index = { count: doors.length, rows, fixed, dynamic,
              marks: new Uint32Array(fixed.length), stamp: 0, scratch: [] };
    doorGeometryCache.set(doors, index);
  }
  return rayGridBoxCandidates(index, left, top, right, bottom);
}
/* 保留完整扫描作为几何对照和测试基准；正式路径在大关卡走上面的宽相位。 */
function rayToWallBrute(ox,oy,a,maxLen,skipGlass,skipDoors,skipLow){
  const dx = Math.cos(a), dy = Math.sin(a);
  let best = maxLen;
  for (const w of cur().walls){
    if (skipGlass && w.glass) continue;
    if (skipLow && lowSight(w)) continue;
    const t = rayEnter(ox,oy,dx,dy,w,maxLen);
    if (t >= 0.5 && t < best) best = t;
  }
  if (!skipDoors) for (const d of doors){
    if (!doorSolid(d)) continue;
    const t = rayEnter(ox,oy,dx,dy,d,maxLen);
    if (t >= 0.5 && t < best) best = t;
  }
  return best;
}
function rayToWall(ox,oy,a,maxLen,skipGlass,skipDoors,skipLow,ignoreWall){
  const dx = Math.cos(a), dy = Math.sin(a);
  let best = maxLen;
  const L = cur(), candidates = rayWallCandidates(L, ox, oy, dx, dy, maxLen);
  for (let i = 0; i < candidates.length; i++){
    const w = candidates[i];
    if (w === ignoreWall || (skipGlass && w.glass)) continue;      /* 玻璃挡人不挡光 */
    if (skipLow && lowSight(w)) continue;    /* 腰高的东西（木箱/桌子）：挡敌人眼睛，挡不住玩家 */
    const t = rayEnter(ox,oy,dx,dy,w,maxLen);
    if (t >= 0.5 && t < best) best = t;
  }
  /* skipDoors：子弹走这条（门挡人不挡弹，弹道线得画穿过去），视线/视野锥不传 */
  if (!skipDoors){
    const ex = ox + dx * best, ey = oy + dy * best;
    for (const d of doorBoxCandidates(Math.min(ox,ex), Math.min(oy,ey), Math.max(ox,ex), Math.max(oy,ey))){
      if (!doorSolid(d)) continue;
      const t = rayEnter(ox,oy,dx,dy,d,best);
      if (t >= 0.5 && t < best) best = t;
    }
  }
  return best;
}

/* 视线：和画出来的那道视野锥用同一套几何（精确相交，不做 14px 膨胀）。
   clearLine 是给 AI 挑掩体、子弹判定用的，它把每堵墙放大 14px 求稳；
   拿它当视野判定，就会出现“锥子明明照到他了，人却是隐身的”——
   敌人贴着柱子、在 hugCover 里的时候正好卡在这 14px 里。
   玻璃按透明的算：人能看穿玻璃，光锥也从玻璃透过去，两边一致。 */
function sightLine(L, x1, y1, x2, y2){
  const dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy);
  if (len < 0.001) return true;
  const lim = len - 1;
  if (truckOcclSeg(x1, y1, x2, y2)) return false;
  return rayToWall(x1, y1, Math.atan2(dy, dx), lim, true) >= lim;
}

/* 同 rayToWall，但顺手把“撞到的是哪面墙”带回来 —— 跳弹要靠它算法线 */
function rayHitWall(ox, oy, a, maxLen){
  const dx = Math.cos(a), dy = Math.sin(a);
  let best = null, bt = maxLen;
  for (const w of cur().walls){
    const t = rayEnter(ox, oy, dx, dy, w, maxLen);
    if (t >= 0.5 && t < bt){ bt = t; best = w; }
  }
  for (const d of doors){
    if (!doorSolid(d)) continue;
    const t = rayEnter(ox, oy, dx, dy, d, maxLen);
    if (t >= 0.5 && t < bt){ bt = t; best = d; }
  }
  return best ? {t: bt, w: best} : null;
}

/* ---------------- 门 ----------------
   两种：
   · 自动门（老）：敌人有卡，走到门口就开；玩家没卡，只能趁门开着挤进去。
   · 手开关门（第 20 轮）：玩家按 E 开关，无读条；关上挡人挡视线，但子弹穿得过去，
     只是穿过去的同时啃它的血，血空了就碎（碎了等于一直开着）。
   钥匙是预留：isLocked / keyId 已经在数据里，现在关卡默认不锁。 */
let doors = [];
let doorCfg = { range: 64 };
function initDoors(L){
  const DEF = (typeof COVER_DEF !== 'undefined') ? COVER_DEF : {};
  const def = DEF.door || { hp: 220 };
  doorCfg = { range: def.range || 64 };
  doors = (L.doors || []).map(function(d){
    const dt = (d.t && DEF[d.t]) || def;                 /* 写 t:'doorSwing' 就是平开门 */
    const hp = d.hp || dt.hp || 220;
    const sz = dt.sz || [48, 110];
    const fw = d.w != null ? d.w : sz[0];
    const fh = d.h != null ? d.h : sz[1];
    const swing = !!(d.swing || dt.swing);
    const pad = Math.max(4, Math.min(9, Math.min(fw, fh) * 0.16));
    /* 门板：宽度 = 门洞厚 − 10（30 的门洞 → 20，比例约 1:2），长度几乎占满门洞。
       铰链放在门洞**上边缘**，全开时门板贴在门垛外侧，不会横在门洞中间把人堵住
       （30 宽的洞全开后还剩 33 的通行宽度，人是半径 11，能过）。 */
    const th = Math.max(12, Math.min(fw - 10, 40));
    const gp = 5;
    const hx0 = d.x + fw * 0.5, hy0 = d.y + 1, len0 = fh - 2;
    return {
      x:d.x, y:d.y, w:fw, h:fh, open:0, hold:0, snd:false,
      /* 门框（永远不动的那个矩形）；平开门另外记着门板尺寸和转轴 */
      fx:d.x, fy:d.y, fw:fw, fh:fh,
      swing: swing,
      /* 门板厚度 / 门垛厚度 / 转轴 / 门板长度 / 全开时横着的那一条 */
      pad: pad, th: th, gap: gp,
      hx: hx0, hy: hy0, len: len0,
      ox: hx0, oy: hy0 - th * 0.5, ow: len0, oh: th,
      manual: d.manual === true,        /* true = 玩家自己按 E 开关 */
      want: 0,                          /* 手开关门的目标：0 关 / 1 开 */
      maxHp: hp, hp: hp, broken: false, hitT: 0,
      isLocked: !!d.isLocked,           /* 预留：以后接钥匙道具 */
      keyId: d.keyId || null,
      skin: d.skin || dt.skin || 'wall',/* 门板配色（见 data/covers.js 的 DOOR_SKIN） */
      unlocked: false                   /* 用钥匙开过就永久解开（本轮还没有钥匙） */
    };
  });
}
/* 关着 = 走不过去。平开门转过大半才算开（转的过程里还是拦人的） */
function doorSolid(d){ return d.open < (d.swing ? 0.55 : 0.42); }