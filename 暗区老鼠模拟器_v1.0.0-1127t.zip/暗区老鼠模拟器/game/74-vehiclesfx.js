/* ============================ 车辆引擎声 ============================
   每辆车一个常驻声部：两个振荡器（主音 + 低八度）+ 一条噪声。
   按车速调转速、按距离调音量、按左右调声像。四款车音色不同：
     truck        运兵车     柴油直六：低、闷、带点糙
     truck_apc    装甲运兵车 更大排量：更低、更沉，副音更重
     truck_pickup 武装皮卡   汽油 V6：中高、干脆
     truck_civil  民用皮卡   汽油四缸：比武装皮卡更轻、更尖一点
   只有玩家驾驶的车辆播放持续发动机声，下车、报废或换关时淡出。
   ==================================================================== */

/* idle/max 是发动机基频（Hz），filt 是低通截止，sub 是低八度音量，
   growl 是噪声（排气/机械声）音量，vol 是整体音量 */
var VEH_ENGINE = {
  truck:        { idle: 36, max: 92,  filt: 430, sub: 0.55, growl: 0.16, vol: 0.86, name: '柴油直六' },
  truck_apc:    { idle: 29, max: 78,  filt: 330, sub: 0.75, growl: 0.20, vol: 0.98, name: '大排量柴油' },
  truck_pickup: { idle: 48, max: 128, filt: 720, sub: 0.35, growl: 0.10, vol: 0.74, name: '汽油 V6' },
  truck_civil:  { idle: 44, max: 118, filt: 660, sub: 0.32, growl: 0.09, vol: 0.68, name: '汽油四缸' }
};
function vehEngineSpec(kind){
  return VEH_ENGINE[kind] || VEH_ENGINE.truck;
}
const VEH_ENGINE_GAIN = 0.065;

/* 一辆车的声部：懒建 */
function _vehEngMake(t, spec){
  const out = duckBus();
  const pan = (typeof actx.createStereoPanner === 'function') ? actx.createStereoPanner() : null;
  const g = actx.createGain();
  g.gain.value = 0.0001;
  const lp = actx.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.value = spec.filt;
  lp.Q.value = 0.9;

  const o1 = actx.createOscillator();
  o1.type = 'sawtooth';
  o1.frequency.value = spec.idle;
  const g1 = actx.createGain();
  g1.gain.value = 1.0;

  const o2 = actx.createOscillator();
  o2.type = 'square';
  o2.frequency.value = spec.idle * 0.5;
  const g2 = actx.createGain();
  g2.gain.value = spec.sub;

  /* 噪声：排气 / 机械的沙声，带通跟着转速走 */
  const nz = actx.createBufferSource();
  if (typeof ensureNoise === 'function') ensureNoise();
  nz.buffer = (typeof noiseBuf !== 'undefined') ? noiseBuf : null;
  nz.loop = true;
  const bp = actx.createBiquadFilter();
  bp.type = 'bandpass';
  bp.frequency.value = 240;
  bp.Q.value = 0.7;
  const g3 = actx.createGain();
  g3.gain.value = spec.growl;

  o1.connect(g1); g1.connect(lp);
  o2.connect(g2); g2.connect(lp);
  if (nz.buffer){ nz.connect(bp); bp.connect(g3); g3.connect(lp); }
  lp.connect(g);
  if (pan){ g.connect(pan); pan.connect(out); } else g.connect(out);

  try {
    const t0 = actx.currentTime;
    o1.start(t0); o2.start(t0);
    if (nz.buffer) nz.start(t0);
  } catch (e){}
  return { o1, o2, g1, g2, nz, bp, g3, lp, g, pan, spec, alive: true };
}

function _vehEngKill(v){
  if (!v || !v.alive) return;
  v.alive = false;
  const disconnect = () => {
    for (const node of [v.o1, v.o2, v.g1, v.g2, v.nz, v.bp, v.g3, v.lp, v.g, v.pan]){
      if (node) node.disconnect();
    }
  };
  v.o1.onended = disconnect;
  try {
    const t = actx.currentTime;
    v.g.gain.cancelScheduledValues(t);
    v.g.gain.setTargetAtTime(0.0001, t, 0.08);
    v.o1.stop(t + 0.45); v.o2.stop(t + 0.45);
    if (v.nz.buffer) v.nz.stop(t + 0.45);
  } catch (e){ disconnect(); }
}

/* 已经建过声部的车（换关时 trucks 被清空，而车对象本身还挂在别人手里，
   所以必须自己记一份名单，把不在 trucks 里的声部断掉） */
var VEH_ALIVE = [];

/* 每帧：挑最近的几辆活车，建 / 更新声部，多余的淡出 */
/* 起步一声：低音从很低扫到怠速，带一点起动机的干磨声。
   只在"从静止起步"或"刚坐上车"时响一次，用 t._engKickT 防抖。 */
function _vehEngKick(t, spec){
  if (!actx) return;
  const now = actx.currentTime;
  try {
    const g = actx.createGain();
    const pan = (typeof actx.createStereoPanner === 'function') ? actx.createStereoPanner() : null;
    const cx = (typeof cam !== 'undefined' && cam) ? cam.x : 0;
    const _w = (typeof W === 'number') ? W : 1280;
    if (pan){
      pan.pan.value = Math.max(-0.85, Math.min(0.85, ((t.x - cx) / (_w * 0.5)) * 0.85));
      g.connect(pan); pan.connect(duckBus());
    } else g.connect(duckBus());
    const near = Math.max(0.12, 1 - Math.hypot(t.x - player.x, t.y - player.y) / 1700);
    const vol = spec.vol * VEH_ENGINE_GAIN * 0.85 * Math.pow(near, 1.2);
    const o = actx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(spec.idle * 0.42, now);
    o.frequency.exponentialRampToValueAtTime(spec.idle * 1.55, now + 0.22);
    o.frequency.exponentialRampToValueAtTime(spec.idle * 1.06, now + 0.62);
    const lp = actx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = spec.filt * 1.15;
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(vol, now + 0.05);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol * 0.34), now + 0.42);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.72);
    o.connect(lp); lp.connect(g);
    o.start(now); o.stop(now + 0.74);
    /* 起动机干磨：一小段高频噪声 */
    const nz = actx.createBufferSource(); nz.buffer = noiseBuf;
    const bp = actx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1100; bp.Q.value = 0.8;
    const g2 = actx.createGain();
    g2.gain.setValueAtTime(Math.max(0.0001, vol * 0.22), now);
    g2.gain.exponentialRampToValueAtTime(0.0001, now + 0.30);
    nz.connect(bp); bp.connect(g2); g2.connect(g);
    nz.start(now); nz.stop(now + 0.32);
  } catch (e){}
}
function vehEngineTick(dt){
  if (typeof actx === 'undefined' || !actx) return;
  if (typeof trucks === 'undefined' || !trucks) return;
  if (audioIsBackground()) return;
  for (let i = VEH_ALIVE.length - 1; i >= 0; i--){
    const t = VEH_ALIVE[i];
    if (!t || !t._eng || trucks.indexOf(t) < 0){
      if (t && t._eng){ _vehEngKill(t._eng); t._eng = null; }
      VEH_ALIVE.splice(i, 1);
    }
  }
  const playing = !(typeof state === 'string' && state !== 'play') && !(typeof paused !== 'undefined' && paused);
  const cand = [];
  for (const t of trucks){
    if (!t) continue;
    if (t.wreck || t.tstate === 'gone'){
      if (t._eng){ _vehEngKill(t._eng); t._eng = null; }
      continue;
    }
    if (playing && playerTruck === t && t.tstate === 'driven') cand.push(t);
    else if (t._eng){ _vehEngKill(t._eng); t._eng = null; }
  }
  const now = actx.currentTime;
  for (const t of cand){
    const spec = vehEngineSpec(t.type || 'truck');
    if (!t._eng){ t._eng = _vehEngMake(t, spec); VEH_ALIVE.push(t); }
    const v = t._eng;
    if (!v || !v.alive) continue;
    /* 转速：车速 / 该车型极速，叠一点怠速 */
    const T = (typeof vehicleDef === 'function') ? vehicleDef(t.type) : null;
    const maxSpd = Math.max(120, (T && T.drive && T.drive.maxFwd) || 700);
    const k = Math.min(1, Math.abs(t.spd || 0) / maxSpd);
    const base = spec.idle + (spec.max - spec.idle) * Math.pow(k, 0.85);
    /* 玩家自己开：给一点抖动，听着像在踩油门 */
    const driven = (typeof playerTruck !== 'undefined' && playerTruck && playerTruck === t);
    /* 起步判定：静止够久再动，或刚上车，都来一声 */
    const _abs = Math.abs(t.spd || 0);
    if (_abs < 8) t._engRest = (t._engRest || 0) + dt; else t._engRest = 0;
    const _started = (_abs > 22 && (t._engRest || 0) <= 0.0001 && (t._engPrevAbs || 0) < 8);
    const _mounted = driven && !t._engWasDriven;
    t._engWasDriven = driven;
    if ((_started || _mounted) && (now - (t._engKickT || -9)) > 1.2){
      t._engKickT = now;
      _vehEngKick(t, spec);
    }
    t._engPrevAbs = _abs;
    /* 正在加速：转速先冲一点，听着像在给油 */
    const _acc = Math.max(0, _abs - (t._engPrevSpd || 0));
    const _rev = Math.min(1, _acc * 22);
    t._engPrevSpd = _abs;
    const wob = driven ? (Math.sin(now * 7.3) * 1.6 + Math.sin(now * 2.1) * 1.1)
                       : (Math.sin(now * 3.1) * 0.7);
    try {
      v.o1.frequency.setTargetAtTime(base + wob + 10 * _rev, now, 0.06);
      v.o2.frequency.setTargetAtTime((base + wob + 10 * _rev) * 0.5, now, 0.06);
      v.lp.frequency.setTargetAtTime(spec.filt + 260 * k, now, 0.10);
      if (v.bp) v.bp.frequency.setTargetAtTime(180 + 520 * k, now, 0.10);
    } catch (e){}
    /* 音量：距离衰减 + 自己开更响 + 越慢越"怠速轻" */
    const vol = spec.vol * VEH_ENGINE_GAIN * 1.5 * (0.58 + 0.42 * k) * (1 + 0.12 * _rev);
    try { v.g.gain.setTargetAtTime(Math.max(0.0001, vol), now, 0.10); } catch (e){}
    if (v.pan){
      try { v.pan.pan.setTargetAtTime(0, now, 0.08); } catch (e){}
    }
  }
}

/* 换关 / 回菜单 / 结算时静音 */
function vehEngineSilence(){
  for (const t of VEH_ALIVE){
    if (!t) continue;
    _vehEngKill(t._eng);
    t._eng = null;
    t._engWasDriven = false;
  }
  VEH_ALIVE.length = 0;
  if (typeof trucks === 'undefined' || !trucks) return;
  for (const t of trucks){ if (t && t._eng){ _vehEngKill(t._eng); t._eng = null; } }
}

/* m19692：车顶机枪的音色 —— 所有车载机枪共用这一种（用户要求"长得一样，不要多种音色"）。
   一发 = 低频撞击 + 高频噪声爆裂。对照测试期间每发都起音。 */
function sfxTruckMg(px, py, distance){
  if (typeof actx === 'undefined' || !actx) return false;
  audioDiagCount('truck');
  let gain = 1;
  if (distance !== undefined){
    const k = Math.max(0, 1 - distance / 1000);
    const volume = Math.max(0, Math.min(1, (CFG.gunVol ?? 100) / 100));
    gain = 0.5 * volume * k * (0.35 + 0.65 * k);
    if (gain === 0) return true;
  }
  const now = actx.currentTime;
  try {
    const out = duckBus();
    let node = out;
    if (typeof actx.createStereoPanner === 'function' && isFinite(px)){
      const p = actx.createStereoPanner();
      const _w = (typeof W === 'number' ? W : 1280);
      p.pan.value = Math.max(-0.9, Math.min(0.9, ((px - cam.x) / (_w * 0.5)) * 0.85));
      p.connect(out); node = p;
    }
    const g = actx.createGain(); g.connect(node);
    const peak = 0.62 * gain;
    const floor = Math.min(0.0001, peak * 0.01);
    g.gain.setValueAtTime(floor, now);
    g.gain.exponentialRampToValueAtTime(peak, now + 0.004);
    g.gain.exponentialRampToValueAtTime(floor, now + 0.105);
    const o = actx.createOscillator(); o.type = 'triangle';
    o.frequency.setValueAtTime(120, now);
    o.frequency.exponentialRampToValueAtTime(46, now + 0.075);
    const og = actx.createGain(); og.gain.value = 0.95;
    o.connect(og); og.connect(g);
    o.start(now); o.stop(now + 0.12);
    if (typeof noiseBuf !== 'undefined' && noiseBuf){
      const s = actx.createBufferSource(); s.buffer = noiseBuf;
      const bp = actx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 0.9;
      bp.frequency.setValueAtTime(2600, now);
      bp.frequency.exponentialRampToValueAtTime(700, now + 0.07);
      const ng = actx.createGain();
      ng.gain.setValueAtTime(0.9, now);
      ng.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);
      s.connect(bp); bp.connect(ng); ng.connect(g);
      s.start(now); s.stop(now + 0.11);
    }
    return true;
  } catch (e){ if (typeof reportErr === 'function') reportErr('74-vehiclesfx', e); return false; }
}
