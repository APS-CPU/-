/* ============================================================
   52-factions.js —— 阵营感知 + 小队行军
   ------------------------------------------------------------
   A 势力（enemy）打玩家、也打 B 势力（bandit）；
   B 势力打 A，对玩家中立 —— 除非玩家先动手触发动态仇恨。
   ------------------------------------------------------------
   两件事：
   1) 感知：把「看见玩家」升级成「看见当前敌对目标」。玩家仍然走原来的
      enemySees（一字没改），NPC 互看用 npcSeesTarget。e.sees 语义变成
      「看见当前目标」，另存 e.seesPlayer 给 UI / 统计用。
   2) 行军：一个小队排成队形走路（纵队/横队/楔形），任一成员进入交战
      状态就整队散开，之后完全交给原有 AI（包抄/投雷/掩体全都还在）。
   ============================================================ */

/* ---------------- 运行时关系覆盖层 ----------------
   FACTION_DEF 是"出厂设置"，这里放"这一局临时改成什么样"。
   用途：玩家按关卡规则 / 道具加入某个势力时，不需要改表，也不用写死
   "player 打谁" 的分支。键按字母序拼成 'a|b'，值只有 hostile / neutral。 */
var factionRelOverride = {};

function factionRelPair(a, b){
  return (a < b) ? (a + '|' + b) : (b + '|' + a);
}
function factionRelSet(a, b, rel){
  if (!a || !b || a === b) return null;
  const k = factionRelPair(a, b);
  if (rel === 'hostile' || rel === 'neutral') factionRelOverride[k] = rel;
  else delete factionRelOverride[k];
  return factionRelOverride[k] || null;
}
function factionRelGet(a, b){
  if (!a || !b || a === b) return null;
  return factionRelOverride[factionRelPair(a, b)] || null;
}
function factionRelClear(){ factionRelOverride = {}; }

/* 玩家当前阵营：默认 'player'。关卡规则 / 道具 / J 面板可以改。
   注意 combatFaction(player) 仍然返回 'player' —— 那个函数被到处当作
   "是不是玩家本人"的判定用（友伤豁免、统计、UI），不能改它的返回值。 */
function playerFactionId(){
  if (typeof player !== 'undefined' && player && player.faction) return player.faction;
  return 'player';
}
/* 关系判定前先把 'player' 换成"玩家现在实际属于哪个阵营" */
function factionAlias(f){
  return (f === 'player') ? playerFactionId() : f;
}

function factionsHostile(a, b){
  if (!a || !b || a === b) return false;
  const A = factionAlias(a), B = factionAlias(b);
  if (A === B) return false;
  const ov = factionRelGet(A, B);
  if (ov) return ov === 'hostile';
  const DA = FACTION_DEF[A], DB = FACTION_DEF[B];
  if (!DA || !DB) return false;
  return DA.hostiles.indexOf(B) >= 0 || DB.hostiles.indexOf(A) >= 0;
}

function factionThreatKey(target){
  if (!target) return '';
  if (typeof player !== 'undefined' && target === player) return 'player';
  return target.id || target._combatId || '';
}

function factionThreat(observer, target){
  if (!observer || !observer.factionThreats) return null;
  const key = factionThreatKey(target);
  const t = key && observer.factionThreats[key];
  return t && t.left > 0 && t.value >= FACTION_HATE_DEF.threshold ? t : null;
}

function factionRememberThreat(observer, target, value, sec, x, y){
  if (!observer || !target || observer === target) return null;
  const key = factionThreatKey(target);
  if (!key) return null;
  const table = observer.factionThreats || (observer.factionThreats = {});
  const old = table[key] || { value: 0, left: 0, x: 0, y: 0 };
  old.value = Math.min(FACTION_HATE_DEF.max, old.value + Math.max(0, value || 0));
  old.left = Math.max(old.left, sec === undefined ? FACTION_HATE_DEF.duration : sec);
  old.x = Number.isFinite(x) ? x : target.x;
  old.y = Number.isFinite(y) ? y : target.y;
  table[key] = old;
  return old;
}

/* 仇恨值挂在被仇恨的目标身上，便于 UI/调试读取；个体是否知情仍由上面的
   factionThreats 决定。 */
function factionAddHateTag(target, offendedFaction, value, sec){
  if (!target || !offendedFaction) return null;
  const table = target.factionHate || (target.factionHate = {});
  const old = table[offendedFaction] || { value: 0, left: 0 };
  old.value = Math.min(FACTION_HATE_DEF.max, old.value + Math.max(0, value || 0));
  old.left = Math.max(old.left, sec === undefined ? FACTION_HATE_DEF.duration : sec);
  table[offendedFaction] = old;
  return old;
}

function factionHateTag(target, offendedFaction){
  const h = target && target.factionHate && target.factionHate[offendedFaction];
  return h && h.left > 0 && h.value >= FACTION_HATE_DEF.threshold ? h : null;
}

var GRUDGE_T = FACTION_HATE_DEF.duration;  /* 旧测试/调试接口兼容 */

/* 显式的全阵营临时关系，仅保留给剧情/调试。实战玩家误伤走局部 threat，
   不再让地图另一头的整支 B 势力瞬间知道玩家的位置。 */
var factionGrudges = {};

function factionGrudgeLeft(f, other){
  const g = factionGrudges[f];
  if (!g) return 0;
  const t = g[other] || 0;
  return t > 0 ? t : 0;
}

function factionAddGrudge(f, other, sec){
  if (!f || !other || f === other) return 0;
  if (!factionGrudges[f]) factionGrudges[f] = {};
  const cur = factionGrudges[f][other] || 0;
  factionGrudges[f][other] = Math.max(cur, sec === undefined ? GRUDGE_T : sec);
  return factionGrudges[f][other];
}

function factionClearGrudges(){
  factionGrudges = {};
  if (typeof player !== 'undefined' && player) player.factionHate = {};
  if (typeof enemies !== 'undefined' && enemies){
    for (const e of enemies){
      e.factionThreats = {};
      e.heardSource = null;
      if (typeof player !== 'undefined' && (e.tgtRef === player || e.tgtCache === player)){
        e.tgtRef = null; e.tgtCache = null; e.combatTargetId = null;
      }
    }
  }
}

function factionTickGrudge(dt){
  for (const f in factionGrudges){
    const g = factionGrudges[f];
    for (const o in g){
      g[o] = Math.max(0, g[o] - dt);
      if (g[o] <= 0) delete g[o];
    }
  }
  if (typeof player !== 'undefined' && player && player.factionHate){
    for (const f in player.factionHate){
      const h = player.factionHate[f];
      h.left = Math.max(0, h.left - dt);
      if (h.left <= 0 || h.value < FACTION_HATE_DEF.threshold) delete player.factionHate[f];
    }
  }
  if (typeof enemies === 'undefined' || !enemies) return;
  for (const e of enemies){
    const table = e && e.factionThreats;
    if (!table) continue;
    for (const key in table){
      const t = table[key];
      t.left = Math.max(0, t.left - dt);
      if (t.left > 0) continue;
      delete table[key];
      if (key === 'player' && typeof player !== 'undefined' &&
          (e.tgtRef === player || e.tgtCache === player || e.heardSource === player)){
        e.tgtRef = null; e.tgtCache = null; e.heardSource = null; e.combatTargetId = null;
        e.blindShot = false; e.cornerWatch = null;
      }
    }
  }
}

/* 有方向的主动交战判定：a 是否想打 b。基础敌对关系仍是双向的；动态仇恨只
   从知情者指向目标，B 恨玩家不会顺带把玩家队友全部改成敌人。 */
function factionWantsFight(a, b){
  const fa0 = (typeof combatFaction === 'function') ? combatFaction(a) : (a && (a.faction || a.team) || 'enemy');
  const fb0 = (typeof combatFaction === 'function') ? combatFaction(b) : (b && (b.faction || b.team) || 'enemy');
  /* 玩家换阵营后，'player' 要按"他现在属于哪个阵营"来算关系 */
  const fa = factionAlias(fa0), fb = factionAlias(fb0);
  if (!a || !b || !fa || !fb || fa === fb) return false;
  if (fa === 'neutral' || fb === 'neutral') return false;
  /* 队友永远不和玩家打：玩家可以换阵营，队友不跟着换（他们还是 'player'），
     但绝不能出现"玩家加入 A 之后自己的队友开始打自己"。 */
  if ((a === player && b && b.controller === 'companion') ||
      (b === player && a && a.controller === 'companion')) return false;
  if (factionsHostile(fa, fb)) return true;
  if (factionGrudgeLeft(fa, fb) > 0) return true;
  if (factionThreat(a, b)) return true;

  /* 玩家身上有该势力的仇恨标记时，走到附近的同势力成员也会加入；距离外仍
     保持中立，不做全地图广播。真正加入后，视觉/声音入口会给它写个体 threat。 */
  const tag = factionHateTag(b, fa);
  if (tag && Number.isFinite(a.x) && Number.isFinite(a.y) && Number.isFinite(b.x) && Number.isFinite(b.y)){
    if (Math.hypot(a.x - b.x, a.y - b.y) <= FACTION_HATE_DEF.joinR) return true;
  }
  return false;
}

/* ---------------- 空间桶 + 固定容量声音事件 ----------------
   一张 320px 空间桶同时供索敌、声音和弹体候选使用。桶只保存实体引用，不复制
   坐标；每帧重建两次仍是 O(N)，比每个脚步/每颗子弹全扫 enemies 稳定得多。 */
var FACTION_CELL = DataFACTION_PERF.cellSize;
var FACTION_NOISE_CAP = DataFACTION_PERF.noiseCapacity;
var FACTION_TARGET_SCAN_BUDGET = DataFACTION_PERF.targetScansPerFrame;
var factionSpatial = { cells: new Map(), ready: false, count: 0, rawCount: -1, querySeq: 0 };
var factionNoiseEvents = [];
var factionNoiseCount = 0;
var factionFrameOpen = false;
var factionTargetBudget = FACTION_TARGET_SCAN_BUDGET;
var factionPerf = { noiseEvents: 0, noiseCandidates: 0, noiseDropped: 0, targetScans: 0, targetCandidates: 0 };
for (let _fni = 0; _fni < FACTION_NOISE_CAP; _fni++)
  factionNoiseEvents.push({ source:null, x:0, y:0, radius:0, kind:'step' });

function factionCellKey(cx, cy){ return cx * 131071 + cy; }
function factionSpatialRebuild(){
  const cells = factionSpatial.cells;
  cells.clear();
  let n = 0;
  if (typeof enemies !== 'undefined' && enemies){
    for (const e of enemies){
      if (!e || e.dead || e.gone || (e.hp !== undefined && e.hp <= 0)) continue;
      const cx = Math.floor(e.x / FACTION_CELL), cy = Math.floor(e.y / FACTION_CELL);
      const key = factionCellKey(cx, cy);
      e._factionNext = cells.get(key) || null;
      cells.set(key, e);
      n++;
    }
  }
  factionSpatial.count = n;
  factionSpatial.rawCount = (typeof enemies!=='undefined'&&enemies)?enemies.length:0;
  factionSpatial.ready = true;
}
function factionSpatialEnsure(){
  if (!factionSpatial.ready || factionSpatial.rawCount !== ((typeof enemies!=='undefined'&&enemies)?enemies.length:0))
    factionSpatialRebuild();
}
function factionSpatialEach(x, y, radius, fn, limit){
  factionSpatialEnsure();
  const r = Math.max(0, radius || 0), cap = limit === undefined ? 1e9 : limit;
  const x0 = Math.floor((x-r)/FACTION_CELL), x1 = Math.floor((x+r)/FACTION_CELL);
  const y0 = Math.floor((y-r)/FACTION_CELL), y1 = Math.floor((y+r)/FACTION_CELL);
  let seen = 0;
  for (let cy=y0; cy<=y1; cy++) for (let cx=x0; cx<=x1; cx++){
    let e = factionSpatial.cells.get(factionCellKey(cx,cy)) || null;
    while (e){
      const next = e._factionNext;
      if (++seen > cap) return seen-1;
      if (fn(e) === false) return seen;
      e = next;
    }
  }
  return seen;
}
function factionSpatialSegmentCandidates(x0,y0,x1,y1,pad,fn){
  factionSpatialEnsure();
  const p = Math.max(0,pad||0);
  const c0x=Math.floor((Math.min(x0,x1)-p)/FACTION_CELL), c1x=Math.floor((Math.max(x0,x1)+p)/FACTION_CELL);
  const c0y=Math.floor((Math.min(y0,y1)-p)/FACTION_CELL), c1y=Math.floor((Math.max(y0,y1)+p)/FACTION_CELL);
  for(let cy=c0y;cy<=c1y;cy++)for(let cx=c0x;cx<=c1x;cx++){
    let e=factionSpatial.cells.get(factionCellKey(cx,cy))||null;
    while(e){const next=e._factionNext;fn(e);e=next;}
  }
}
function factionFrameBegin(){
  factionFrameOpen=true;
  factionTargetBudget = FACTION_TARGET_SCAN_BUDGET;
  factionPerf.noiseEvents=0; factionPerf.noiseCandidates=0; factionPerf.noiseDropped=0;
  factionPerf.targetScans=0; factionPerf.targetCandidates=0;
  // 分离/推挤在上一帧末尾仍可能改变位置；每帧入口只做一次线性重建，
  // 后续索敌、听觉和弹道全部复用，避免各系统分别全表扫描。
  factionSpatialRebuild();
}
function factionEmitNoise(source, kind, x, y, radius){
  if (!source || !(radius > 0) || (source === player && spectatorViewOn())) return false;
  /* 军团推塔：机枪棱堡/水晶一直在开火，它们的枪炮声不该把人从路上勾走（只在本模式内屏蔽，
     其它模式照旧）。只挡"结构"发出的声，单位互相打还是要靠枪声找人的。 */
  if (source.mgSentry || source.rocketTurret || source.mobaLane !== undefined){
    const _L = (typeof cur === 'function') ? cur() : null;
    if (_L && typeof mobaOn === 'function' && mobaOn(_L)) return false;
  }
  /* 同一射手 0.08 秒内的一串弹丸只投递一次枪声；脚步本身已按步频触发。 */
  if (kind === 'shot'&&factionFrameOpen){
    const now = (typeof uiT === 'number') ? uiT : 0;
    if (source._factionShotAt !== undefined && now-source._factionShotAt < 0.08) return false;
    source._factionShotAt = now;
  }
  if (factionNoiseCount >= FACTION_NOISE_CAP){
    factionPerf.noiseDropped++;
    return false;
  }
  const q=factionNoiseEvents[factionNoiseCount++];
  q.source=source;q.kind=kind||'step';q.x=Number.isFinite(x)?x:source.x;q.y=Number.isFinite(y)?y:source.y;q.radius=radius;
  if(!factionFrameOpen)factionNoiseFlush();
  return true;
}
function factionNoiseApply(listener, q){
  const source=q.source;
  if(!listener||listener===source||listener.dead||enemyType(listener).static)return;
  if(!factionWantsFight(listener,source))return;
  const hm=(listener.HM!==undefined?listener.HM:enemyType(listener).hearMul)||0;
  if(!(hm>0))return;
  const hk=(cur().rules&&cur().rules.hearK!==undefined)?cur().rules.hearK:1;
  if(dist(listener.x,listener.y,q.x,q.y)>q.radius*hm*hk)return;
  if(listener.sees&&listener.tgtRef&&listener.tgtRef!==source)return;
  if(q.kind==='rocketBlast'&&(listener.sees||rocketBlastSoundIgnored(listener)))return;
  if(q.kind==='rocketLaunch'&&listener.sees)return;
  if(q.kind==='blast'&&(listener.lastKnown||(listener.memoT>0&&listener.memo))){
    const matchesThreat=n=>n && n.x===q.x && n.y===q.y && (n.by||player)===source;
    if(matchesThreat(listener.nadeDodgeThreat)||matchesThreat(listener.nadeDodgeEnded))return;
  }

  /* 玩家带着仇恨进入附近时，这一次声音让该成员正式“知情”。 */
  if(source===player&&!factionsHostile(combatFaction(listener),'player'))
    factionRememberThreat(listener,source,FACTION_HATE_DEF.hitGain,FACTION_HATE_DEF.duration,q.x,q.y);
  listener.heardSource=source;
  listener.combatTargetId=(typeof combatId==='function')?combatId(source):null;
  alertBySound(listener,q.x,q.y,source,q.kind);
  if(enemyType(listener).kind==='blade'){
    listener.memo={x:q.x,y:q.y};listener.memoT=Math.max(listener.memoT||0,3.4);listener.huntT=Math.max(listener.huntT||0,1.5);
  }
  if(listener.squad)listener.squad.engaged=true;
}
function factionNoiseDispatch(q){
  factionPerf.noiseEvents++;
  factionPerf.noiseCandidates+=factionSpatialEach(q.x,q.y,q.radius*1.55,e=>factionNoiseApply(e,q));
  q.source=null;q.radius=0;
}
function factionNoiseFlush(){
  // AI 在本帧内已经移动过；刷新一次，供听觉结算和随后的弹道共同复用。
  factionSpatialRebuild();
  let firstRocketBlast = -1;
  for(let i=0;i<factionNoiseCount;i++){
    const q=factionNoiseEvents[i];
    if(q.kind==='rocketBlast'){
      if(firstRocketBlast<0)firstRocketBlast=i;
    }else factionNoiseDispatch(q);
  }
  /* 同一批声音先处理枪口，再判断每个听众是否还会调查炸点。 */
  if(firstRocketBlast>=0){
    for(let i=firstRocketBlast;i<factionNoiseCount;i++){
      const q=factionNoiseEvents[i];
      if(q.kind==='rocketBlast')factionNoiseDispatch(q);
    }
  }
  factionNoiseCount=0;
}
function factionFrameEnd(dt){
  factionNoiseFlush();
  factionTickGrudge(dt);
  factionFrameOpen=false;
}
function factionResetRuntime(){
  factionFrameOpen=false;factionNoiseCount=0;factionSpatial.cells.clear();factionSpatial.ready=false;factionSpatial.count=0;factionSpatial.rawCount=-1;
  factionClearGrudges();
  if(typeof factionRelClear==='function')factionRelClear();   /* 关系覆盖层也跟着关卡一起清 */
  if(typeof squads!=='undefined'){squads.length=0;_squadSeq=0;}
}

/* ---------------- 阵营感知 ---------------- */

/* Cached shapes are shared by world cones and the night mask. No blur pass. */
function companionVisionRay(x,y,a,range){
  let len=Math.min(rayToWall(x,y,a,range,true),raySmokeCut(x,y,a,range));
  for(const t of trucks)if(t.tstate!=='gone'){
    const hit=rayTruckT(t,x,y,a,range);
    if(hit!==null)len=Math.min(len,hit);
  }
  return len;
}
function companionVisionShape(e,followPose=false){
  let v=companionConeCache.get(e);const L=cur(),D=COMPANION_VISION;
  if(v&&v.level===L&&v.nav===navVer&&v.range===D.range&&v.half===D.half&&uiT>=v.at&&uiT-v.at<.1&&
    (!followPose||(v.x===e.x&&v.y===e.y&&v.ang===e.ang)))return v;
  v={x:e.x,y:e.y,ang:e.ang,at:uiT,level:L,nav:navVer,range:D.range,half:D.half,points:[]};
  for(let i=0;i<=D.rays;i++){
    const a=e.ang-D.half+2*D.half*i/D.rays,len=companionVisionRay(e.x,e.y,a,D.range);
    v.points.push({x:e.x+Math.cos(a)*len,y:e.y+Math.sin(a)*len});
  }
  companionConeCache.set(e,v);return v;
}
function companionSharedSees(target){
  if(!allies.length||!target)return false;
  let c=companionSightCache.get(target);
  if(c&&c.level===cur()&&c.nav===navVer&&uiT>=c.at&&uiT-c.at<.1&&
    (!c.observer||allies.includes(c.observer)&&!c.observer.dead&&c.observer.hp>0))return !!c.observer;
  let observer=null;
  for(const e of allies){
    if(e.dead||e.hp<=0)continue;
    const v=companionVisionShape(e),dx=target.x-v.x,dy=target.y-v.y,d=Math.hypot(dx,dy),a=Math.atan2(dy,dx);
    if(d>COMPANION_VISION.range||Math.abs(normAng(a-v.ang))>COMPANION_VISION.half)continue;
    if(companionVisionRay(v.x,v.y,a,d)>=d-.5){observer=e;break;}
  }
  companionSightCache.set(target,{at:uiT,level:cur(),nav:navVer,observer});return !!observer;
}

/* 一只 NPC 能不能看见另一只（或玩家）。和 enemySees 同一套判定，
   只是把 player 换成任意目标，并且不检查 player.grace。 */
function npcSeesTarget(e, t, hidden){
  if (!e || !t || e === t || enemyIsFortification(t)) return false;
  if (hidden) return false;
  /* 和 enemySees 一样尊重出生保护/无敌帧：否则测试和开局保护都会被"看穿" */
  if (t === player && player.grace > 0) return false;
  /* m46193：上帝模式玩家对 NPC 完全不可见（和其它感知入口保持一致） */
  if (t === player && typeof godInvis === 'function' && godInvis()) return false;
  if (t.dead || t.gone || (t.hp !== undefined && t.hp <= 0)) return false;
  const d = dist(e.x, e.y, t.x, t.y);
  if (d > enemyVisionRange(e, t)) return false;
  if (losBlocked(e.x, e.y, t.x, t.y, false, false, e.towerOn)) return false;
  const T = enemyType(e);
  if ((T.static || T.fly) && smokeBlocks(e.x, e.y, t.x, t.y, true)) return false;
  const a = Math.atan2(t.y - e.y, t.x - e.x);
  const half = enemyFovHalf(e, T) * Math.PI / 180;
  return Math.cos(normAng(a - e.ang)) >= Math.cos(half);
}

/* 这一只见过的、当前敌对的所有候选里挑最近的一个 */
function enemyPickTarget(e, concealed){
  let best = null, bd = 1e9;
  const consider = (o) => {
    if (!o || o === e) return;
    factionPerf.targetCandidates++;
    if (!factionWantsFight(e, o)) return;
    if (!npcSeesTarget(e, o, o===player?concealed:false)) return;
    const d = dist(e.x, e.y, o.x, o.y);
    if (d < bd){ bd = d; best = o; }
  };
  consider(player);
  /* 视距外的人连 FOV/LOS 都不算；每次最多看 64 个局部候选，密集 300 怪也有硬上限。 */
  factionSpatialEach(e.x,e.y,Math.max(760,enemyVisionRange(e,player)),consider,64);
  return best;
}

/* 感知入口：替换原来那行 `e.sees = enemySees(e, concealed);`
   dt 只用于错帧扫描（每 0.3 秒扫一次 NPC），单帧开销可以忽略。 */
function enemyPerceive(e, concealed, dt){
  const rawSeeP = enemySees(e, concealed);
  e.seesPlayer = rawSeeP;
  const _dt = (dt === undefined) ? 0.016 : dt;

  /* 先维持仍可见的旧目标，避免玩家/B 同时出现时每帧跳目标。 */
  let tgt = null;
  const old=e.tgtRef;
  if(old&&!old.dead&&(old.hp===undefined||old.hp>0)&&factionWantsFight(e,old)&&
     (old===player?rawSeeP:npcSeesTarget(e,old)))
    tgt=old;
  if (!tgt && rawSeeP && factionWantsFight(e, player)){
    tgt = player;
    if(!factionsHostile(combatFaction(e),'player')&&factionHateTag(player,combatFaction(e)))
      factionRememberThreat(e,player,FACTION_HATE_DEF.hitGain,FACTION_HATE_DEF.duration,player.x,player.y);
  }

  /* 错帧 + 每帧预算：即使正在看玩家，也会低频比较附近其他势力；这样 B 真能
     分走 A 的火力。锁定目标仍有 18% 距离滞回，不会左右横跳。 */
  if(!Number.isFinite(e.tgtScanT)){
    const id=(typeof combatId==='function'?combatId(e):'')||'0';
    let h=0;for(let i=0;i<id.length;i++)h=(h*33+id.charCodeAt(i))>>>0;
    e.tgtScanT=(h%300)/1000;
  }else e.tgtScanT -= _dt;
  if (e.tgtScanT <= 0 && factionTargetBudget > 0){
    factionTargetBudget--;factionPerf.targetScans++;
    e.tgtScanT = 0.30;
    e.tgtCache = enemyPickTarget(e,concealed) || null;
  }
  if(e.tgtCache){
    const c=e.tgtCache;
    if(!c.dead&&(c.hp===undefined||c.hp>0)&&factionWantsFight(e,c)&&(c===player?rawSeeP:npcSeesTarget(e,c))){
      if(!tgt||c===old||dist(e.x,e.y,c.x,c.y)<dist(e.x,e.y,tgt.x,tgt.y)*.82)tgt=c;
    }else e.tgtCache=null;
  }
  if(tgt){
    e.lastKnown={x:tgt.x,y:tgt.y};
    e.lastKnownSource=tgt;
    e.alertT=Math.max(e.alertT||0,(CFG.eMemory||6)+2);
    e.mode=1;
    if(e.squad)e.squad.engaged=true;
  }

  e.tgtRef = tgt;
  e.targetSeen = !!tgt;
  e.sees = e.targetSeen;  /* 单体战术仍沿用旧字段；全局“玩家被发现”只读 seesPlayer */
  if (tgt && tgt !== player){
    e.lastKnown = { x: tgt.x, y: tgt.y };
    if (e.squad) e.squad.engaged = true;
  }
  return e.sees;
}

/* 地图墙体会动态增删。按墙体版本共享建筑候选，避免每个枪手扫描整张地图。 */
function enemyIsFortification(target){
  return !!(target && (target.rocketTurret || target.mgSentry || target.mgNest));
}
const enemyStructureCache = new WeakMap();
const _enemyStructureAim = { x:0, y:0, distance:0, wall:null };
function enemyStructureTarget(L, e){
  let cache = enemyStructureCache.get(L);
  if (!cache || cache.walls !== L.walls || cache.count !== L.walls.length || cache.version !== wallGeomVer){
    cache = { walls:L.walls, count:L.walls.length, version:wallGeomVer,
      targets:L.walls.filter(enemyIsFortification) };
    enemyStructureCache.set(L,cache);
  }
  const result = _enemyStructureAim;
  result.wall = null;
  let bestDistance = ENGAGE.structureRange;
  for (const w of cache.targets){
    if (!w.brk || !(w.hp > 0) || w.dead || w.destroyed || !factionWantsFight(e,w)) continue;
    if (e.mobaLane !== undefined && w.mobaLane !== undefined && e.mobaLane !== w.mobaLane) continue;
    const dx = w.x + w.w / 2 - e.x, dy = w.y + w.h / 2 - e.y;
    const length = Math.hypot(dx,dy);
    if (length === 0 || length - Math.hypot(w.w,w.h)/2 >= bestDistance) continue;
    const entry = rayEnter(e.x,e.y,dx/length,dy/length,w,length);
    if (entry < 0 || entry >= bestDistance) continue;
    const fraction = Math.max(0,entry - 1) / length;
    const x = e.x + dx * fraction, y = e.y + dy * fraction;
    if (losBlocked(e.x,e.y,x,y) || smokeBlocks(e.x,e.y,x,y,true)) continue;
    bestDistance = entry;
    result.x = x; result.y = y; result.distance = entry; result.wall = w;
  }
  return result.wall ? result : null;
}

function enemyTargetEntity(e){
  const t=e&&e.tgtRef;
  if(t&&!t.dead&&!t.gone&&(t.hp===undefined||t.hp>0)&&factionWantsFight(e,t))return t;
  /* 兼容旧 AI/关卡数据：它们只有 sees，没有 tgtRef。真实帧会写 seesPlayer，
     因此这条不会把“正在看 B”的新式目标偷换成玩家。 */
  if(e&&factionWantsFight(e,player)&&
     (e.seesPlayer===true||(e.sees===true&&e.seesPlayer===undefined)))return player;
  /* 老的战术入口默认围绕玩家运作。若没有任何别的声音/记忆目标，继续把静态
     敌对的玩家当作战术对象；B 中立时 factionWantsFight 为 false，不会误用。 */
  const remembered=e&&(e.lastKnownSource||e.heardSource);
  if(e&&factionWantsFight(e,player)&&!e.lastKnown&&
     (!remembered||remembered===player||!factionWantsFight(e,remembered)))return player;
  return null;
}
/* 当前目标 → 记忆点 → 原地。中立 B 没有目标时绝不再偷偷回退到玩家。 */
function enemyTargetPoint(e){
  return enemyTargetPointFromEntity(e,enemyTargetEntity(e));
}
function enemyTargetPointFromEntity(e,target){
  if(target)return target;
  if (e.lastKnown) return e.lastKnown;
  if(e&&factionWantsFight(e,player))return player;
  return e;
}
const EnemyPerception=Object.freeze({
  selectedCover:function(enemy){
    return enemy.hideGoal;
  },
  read:function(enemy,result){
    const entity=enemyTargetEntity(enemy);
    const point=enemyTargetPointFromEntity(enemy,entity);
    result.targetEntity=entity;
    result.targetPoint=point;
    result.targetX=point.x;
    result.targetY=point.y;
    const remembered=enemy.lastKnown;
    result.lastKnownX=remembered?remembered.x:null;
    result.lastKnownY=remembered?remembered.y:null;
    result.heardSource=enemy.heardSource||null;
    return result;
  },
  threat:function(enemy){
    if(!enemy)return null;
    const entity=enemyTargetEntity(enemy);
    if(entity&&entity!==enemy&&!entity.dead&&!entity.gone&&(entity.hp===undefined||entity.hp>0)&&
       (typeof factionWantsFight!=='function'||factionWantsFight(enemy,entity)))return entity;
    for(const source of [enemy.lastKnownSource,enemy.heardSource]){
      if(source&&source!==enemy&&!source.dead&&!source.gone&&(source.hp===undefined||source.hp>0)&&
         (typeof factionWantsFight!=='function'||factionWantsFight(enemy,source)))return source;
    }
    const point=enemyTargetPoint(enemy);
    return point&&point!==enemy?point:null;
  },
  shotTarget:function(enemy,explicitTarget){
    const point=enemyTargetPoint(enemy);
    const tracked=enemy.tgtRef;
    return explicitTarget
      || (tracked&&!tracked.dead&&(tracked.hp===undefined||tracked.hp>0)?tracked:null)
      || (point&&point!==enemy?point:(enemy.lastKnown||player));
  },
  reportContact:function(enemy){
    const point=enemyTargetPoint(enemy);
    return enemy.tgtRef&&!enemy.tgtRef.dead?enemy.tgtRef:(enemy.sees?point:null);
  }
});
function enemyTargetDistance(e){
  const t=enemyTargetPoint(e);return dist(e.x,e.y,t.x,t.y);
}
function enemyTargetReloading(e){
  const t=enemyTargetEntity(e);
  if(t===player)return playerReloading();
  return !!(t&&t.reloading>0);
}
function enemyTargetLookingAt(e,x,y){
  const t=enemyTargetEntity(e);
  if(t===player)return playerLookingAt(x,y);
  if(!t)return false;
  const a=Math.atan2(y-t.y,x-t.x),ta=(t.aim===undefined?t.ang:t.aim);
  return Math.abs(normAng(a-(ta||0)))<0.72;
}

/* 枪声与脚步走同一条固定容量事件管线。 */
function factionHearShot(shooter, x, y){
  if (!shooter) return false;
  const sx = (x === undefined) ? shooter.x : x;
  const sy = (y === undefined) ? shooter.y : y;
  /* 枪声比脚步传得远得多：A、B 两拨人在几十米外打起来，旁边路过的人也该被惊动
     （用户 m41130：只有玩家开枪会引来人，A/B 互射时旁边的 B 慢悠悠走过去）。
     脚步仍是 playerHearR()，枪声按 2.4 倍算，下限 620px。 */
  const r = Math.max(620, (playerHearR() || 320) * 2.4);
  return factionEmitNoise(shooter,'shot',sx,sy,r);
}
function factionHearStep(mover,x,y){
  if(!mover)return false;
  const T=enemyType(mover), loud=(T.stepLoud===undefined?1:T.stepLoud);
  if(!(loud>0))return false;
  return factionEmitNoise(mover,'step',x===undefined?mover.x:x,y===undefined?mover.y:y,
                          maskedHearR(CFG.hearR*Math.max(.25,loud)));
}

/* ---------------- 小队行军 ---------------- */

var SQUAD_DEF = {
  on: true,
  size: [4, 6],          /* 每队人数（用户要求 4~6） */
  gap: 30,               /* 队员之间基础间距 */
  spdK: 0.74,            /* 行军速度（比交战移动慢，看得出"在走"） */
  breakK: 1.0,           /* 散开后速度回到 1 */
  arriveR: 90,           /* 到点后换下一个目标点 */
  engagedR: 520,         /* 这个距离内有敌人看见我们，整队就散开 */
  retryT: 2.4            /* 走不通时重新选点 */
};
var squads = [];
var _squadSeq = 0;

/* 队形：以队长为基准，按朝向旋转的局部坐标（x=前，y=右） */
function squadSlots(n, kind){
  const g = SQUAD_DEF.gap, out = [{ x: 0, y: 0 }];
  if (kind === 'column'){
    /* 纵队：一列跟着走，最像行军 */
    for (let i = 1; i < n; i++) out.push({ x: -Math.ceil(i / 2) * g * (i % 2 ? 1 : 1), y: (i % 2 ? -1 : 1) * g * 0.5 * Math.ceil(i / 2) });
    for (let i = 1; i < n; i++) out[i] = { x: -i * (g * 0.92), y: (i % 2 ? -1 : 1) * (g * 0.34) };
  } else if (kind === 'wide'){
    /* 横队：一排推开 */
    const half = (n - 1) / 2;
    for (let i = 1; i < n; i++){
      const k = Math.ceil(i / 2) * (i % 2 ? 1 : -1);
      out.push({ x: 0, y: k * g });
    }
    out[0] = { x: 0, y: 0 };
    for (let i = 1; i < n; i++){
      const k = Math.ceil(i / 2) * (i % 2 ? 1 : -1);
      out[i] = { x: 0, y: k * g };
    }
    void half;
  } else {
    /* 楔形：队长在前，两边斜着跟 */
    for (let i = 1; i < n; i++){
      const k = Math.ceil(i / 2) * (i % 2 ? 1 : -1);
      out.push({ x: -Math.abs(k) * g * 0.62, y: k * g });
    }
  }
  return out;
}

function squadNew(leader, members, kind){
  const s = {
    id: ++_squadSeq, leader: leader, members: members,
    kind: kind || 'column', slots: squadSlots(members.length, kind || 'column'),
    goal: null, engaged: false, retryT: 0
  };
  for (const e of members){ e.squad = s; }
  squads.push(s);
  return s;
}

/* 给一个小队挑一个"往前走"的点：优先屏幕外/远一点的空地 */
function squadPickGoal(s){
  const L = cur();
  if (!L) return null;
  const lead = s.leader;
  for (let t = 0; t < 24; t++){
    const a = rand(0, TAU);
    const r = rand(280, 760);
    const x = clamp(lead.x + Math.cos(a) * r, 60, L.w - 60);
    const y = clamp(lead.y + Math.sin(a) * r, 60, L.h - 60);
    if (dist(x, y, lead.x, lead.y) < 200) continue;
    const q = safeSpot(L, { x: x, y: y }, 26);
    if (clearWalkLine(L, lead.x, lead.y, q.x, q.y) || freeLen(L, lead.x, lead.y, Math.atan2(q.y - lead.y, q.x - lead.x), 300, 20) > 200){
      return q;
    }
  }
  return null;
}

/* 行军不吃自己的位移：把槽位写成航点，让原有的巡逻 AI 去走 ——
   直接改 e.x/e.y 会和 AI 的寻路每帧互相拉扯（实测 2 秒只挪 8px）。
   marchK 只用来把行军速度压到 0.62，交战前会清掉。 */
function squadSetWaypoint(e, tx, ty){
  const w = e.wp && e.wp[e.i | 0];
  const moved = w ? Math.hypot(w[0] - tx, w[1] - ty) : 1e9;
  if (moved > 26){
    e.wp = [[tx, ty]];
    e.i = 0; e.wait = 0;
    e.path = null; e.goal = null;      /* 让 AI 重新寻路到新槽位 */
  }
  e.marchK = SQUAD_DEF.spdK;
}

function squadTickOne(s, dt){
  if (!SQUAD_DEF.on) return;
  /* 成员掉队/死亡就从队里剔掉 */
  for (let i = s.members.length - 1; i >= 0; i--){
    const e = s.members[i];
    if (!e || e.dead || e.gone || (e.hp !== undefined && e.hp <= 0) || enemies.indexOf(e) < 0){
      e.squad = null;
      s.members.splice(i, 1);
    }
  }
  if (!s.members.length){ s.done = true; return; }
  if (s.leader.dead || s.members.indexOf(s.leader) < 0) s.leader = s.members[0];

  /* 遭遇敌人 → 整队散开，交回原 AI（行军减速也要撤掉，否则打起来慢半拍） */
  if (!s.engaged){
    for (const e of s.members){
      if (e.sees || e.tgtRef || ((e.alertT || 0) > 0 && e.mode === 1)){ s.engaged = true; break; }
    }
    if (s.engaged) squadBreakOne(s);
  }
  if (s.engaged) return;

  const lead = s.leader;
  if (!s.goal || dist(lead.x, lead.y, s.goal.x, s.goal.y) < SQUAD_DEF.arriveR || s.retryT <= 0){
    s.retryT = SQUAD_DEF.retryT;
    const g = squadPickGoal(s);
    if (g) s.goal = g;
  }
  if (!s.goal) return;

  /* 队长走目标点，队员各自走到自己槽位（槽位跟着队长朝向转） */
  squadSetWaypoint(lead, s.goal.x, s.goal.y);
  const ca = Math.cos(lead.ang), sa = Math.sin(lead.ang);
  for (let i = 0; i < s.members.length; i++){
    const e = s.members[i];
    if (e === lead) continue;
    const sl = s.slots[i] || s.slots[0];
    const tx = lead.x + ca * sl.x - sa * sl.y;
    const ty = lead.y + sa * sl.x + ca * sl.y;
    if (dist(e.x, e.y, tx, ty) < 10) continue;
    squadSetWaypoint(e, tx, ty);
  }
}

/* 散开：把行军减速和队形航点都还回去 */
function squadBreakOne(s){
  for (const e of s.members){
    e.marchK = 0;
    e.path = null; e.goal = null;
    e.wp = [[e.x, e.y]]; e.i = 0; e.wait = 0;
  }
}

function squadTick(dt){
  if (!SQUAD_DEF.on || !squads.length) return;
  for (let i = squads.length - 1; i >= 0; i--){
    const s = squads[i];
    squadTickOne(s, dt);
    if (s.done) squads.splice(i, 1);
    else if (!s.engaged) s.retryT = Math.max(0, (s.retryT || 0) - dt);
  }
}

/* ---------------- 投放 ---------------- */

/* B 势力小队：n 个（默认 4~6），同一个 type 池，队形行军 */
function squadSpawnBandit(n, opt){
  const L = cur();
  if (!L) return null;
  const O = opt || {};
  const cnt = Math.max(1, n || (SQUAD_DEF.size[0] + Math.floor(Math.random() * (SQUAD_DEF.size[1] - SQUAD_DEF.size[0] + 1))));
  const spot = O.at || devSpotAt();
  if (!spot) return null;
  const kind = O.type || 'grunt';
  const T = enemyType({ type: kind });
  const members = [];
  for (let i = 0; i < cnt; i++){
    const a = (i / cnt) * TAU;
    const q = safeSpot(L, { x: spot.x + Math.cos(a) * 46, y: spot.y + Math.sin(a) * 46 }, T.r || 14);
    const e = {
      type: kind, faction: 'bandit', factionTint: (O.tint || '#7fbf6a'),
      x: q.x, y: q.y, r: T.r || 12, ang: rand(0, TAU), angS: 0,
      wp: [[q.x, q.y]], i: 0, wait: 0,
      mode: 0, lastKnown: null, alertT: 0, sees: false, heard: false, chk: null,
      ammo: CFG.mag, fireCd: rand(0.5, 1.6), reloading: 0, muzzle: 0,
      hp: Math.max(1, T.hp || 100), maxHp: Math.max(1, T.hp || 100), fleeCd: 0
    };
    if (T.armorKind) e.armor = armorOf(T.armorKind);
    enemies.push(e);
    assignWeapon(e);
    members.push(e);
  }
  const s = squadNew(members[0], members, O.formation || 'column');
  const g = squadPickGoal(s);
  if (g) s.goal = g;
  return s;
}

/* 遇到交战就散开：player 侧不需要写进 AI，交给 squadTickOne 的 engaged 判定 */
function squadBreakAll(){
  for (const s of squads) s.engaged = true;
}

/* 真实落血后的唯一阵营事件入口。基础敌对关系不需要动态仇恨；玩家打中原本
   中立的 B 时，玩家获得数值标签，受击者及 shareR 内同势力成员获得知情 threat。 */
function factionNoteDamage(target, source, damage, kind){
  if(!target||!source||!(damage>0)||source!==player)return false;
  const f=combatFaction(target),sf=combatFaction(source);
  if(!f||f===sf||f==='neutral'||factionsHostile(f,sf))return false;
  const gain=Math.min(FACTION_HATE_DEF.max,
    FACTION_HATE_DEF.hitGain+Math.max(0,damage)*FACTION_HATE_DEF.damageK);
  factionAddHateTag(source,f,gain,FACTION_HATE_DEF.duration);
  // 正常战斗帧已经维护空间索引；受击时不能为每一发子弹再做 O(N) 重建。
  factionSpatialEnsure();
  let shared=0;
  const wake=e=>{
    if(!e||e.dead||combatFaction(e)!==f)return;
    factionRememberThreat(e,source,gain,FACTION_HATE_DEF.duration,source.x,source.y);
    shared++;
    /* 火箭伤害仍建立仇恨。调查位置由听见的枪口或亲眼发现的目标决定。 */
    if (kind === 'rocketBlast') return;
    e.heardSource=source;e.combatTargetId=(typeof combatId==='function')?combatId(source):'player';
    e.lastKnown={x:source.x,y:source.y};e.lastKnownSource=source;
    e.alertT=Math.max(e.alertT||0,(CFG.eMemory||6)+2);
    e.mode=1;e.heard=true;e.hearT=.8;
    if(e.squad)e.squad.engaged=true;
  };
  wake(target);
  factionSpatialEach(target.x,target.y,FACTION_HATE_DEF.shareR,e=>{
    if(e!==target&&dist(e.x,e.y,target.x,target.y)<=FACTION_HATE_DEF.shareR)wake(e);
  });
  target.lastHateKind=kind||'damage';
  target.lastHateShared=shared;
  return true;
}
/* 旧调用名保留；新伤害代码统一传真实伤害值。 */
function notePlayerHurt(e, damage, source, kind){
  return factionNoteDamage(e,source||player,damage===undefined?1:damage,kind);
}


/* ── 武器归属：谁在扣扳机 ──────────────────────────────────────────────
   固定阵地看座位上的人，载具看控制者阵营，都没有就看单位自己。
   以后新增载具/阵地，只要把"能不能打"接到 weaponWantsFight 上，
   就不用再各写一套"要不要打玩家"的判断（B 势力中立时不会开火）。 */
function weaponCrew(unit){
  if (!unit) return null;
  if (unit.seat && !unit.seat.dead) return unit.seat;        /* 重机枪阵地：坐着的人 */
  if (unit.mgSeat && !unit.mgSeat.dead) return unit.mgSeat;
  if (unit.driver && !unit.driver.dead) return unit.driver;  /* 载具：司机 */
  return unit;                                               /* 没人：看单位自身的阵营 */
}
function weaponFaction(unit){
  const c = weaponCrew(unit);
  if (!c) return 'neutral';
  if (typeof combatFaction === 'function') return combatFaction(c);
  return c.faction || c.team || 'enemy';
}
function weaponWantsFight(unit, tgt){
  const c = weaponCrew(unit);
  if (!c || !tgt || c === tgt) return false;
  if (typeof factionWantsFight === 'function') return factionWantsFight(c, tgt);
  return true;
}

/* ── 玩家阵营：切换与结算 ──────────────────────────────────────────────
   玩家默认是 'player'，可以按关卡规则 / 道具 / 调试面板改成
   'enemy'（A 势力）/ 'bandit'（B 势力）/ 'neutral'。
   关系判定走 factionAlias —— 把 'player' 换成
   "玩家现在实际属于哪个阵营"再查表，所以 combatFaction 的返回值不用动。 */
var FACTION_PLAYABLE = ['player', 'enemy', 'bandit', 'neutral'];

/* 换阵营时把"旧账"一次清干净：
   敌人脑子里还记着"玩家在那边"（lastKnown）、还带着 6 秒警戒（alertT）、
   各自身上还有对玩家的仇恨表（factionThreats）—— 不清就会继续追你几秒，
   看起来像"友好没生效"。 */
function playerFactionClearHostility(){
  if (typeof factionClearGrudges === 'function') factionClearGrudges();
  if (typeof enemies !== 'undefined' && enemies){
    for (const e of enemies){
      if (!e || e.dead) continue;
      e.tgtRef = null; e.tgtCache = null; e.combatTargetId = null;
      e.lastKnown = null; e.heardSource = null;
      e.alertT = 0; e.mode = 0; e.heard = false;
      e.sees = false; e.seesPlayer = false;
      e.blindShot = false; e.cornerWatch = null;
      e.factionThreats = {};
      e.chk = { t: 0, best: 1e9 };
      if (e.squad && typeof squadBreakOne === 'function') squadBreakOne(e.squad);
    }
  }
  if (typeof squads !== 'undefined' && squads){
    for (const s of squads){ s.engaged = false; s.engageT = 0; }
  }
  if (typeof player !== 'undefined' && player){
    player.factionHate = {};
    player.tgtRef = null;
  }
  if (typeof factionNoise !== 'undefined' && factionNoise) factionNoise.length = 0;
}

/* 真正切换。返回新阵营 id；参数不认识就原样返回当前阵营。 */
function playerSetFaction(f, opts){
  if (typeof FACTION_DEF === 'undefined' || !FACTION_DEF[f]) return playerFactionId();
  const from = playerFactionId();
  player.faction = f;
  /* 关系覆盖层：玩家加入某势力后，"玩家 vs 该势力"强制中立（否则你自己人打你），
     其余关系仍按 FACTION_DEF 查。这里不动表，只压一条覆盖。 */
  if (typeof factionRelSet === 'function'){
    for (const k in FACTION_DEF){
      if (k === 'player' || k === f) continue;
      factionRelSet('player', k, null);
    }
  }
  playerFactionClearHostility();
  if (!opts || opts.silent !== true){
    const lb = (FACTION_DEF[f] && FACTION_DEF[f].label) || f;
    if (from !== f && typeof setMsg === 'function') setMsg('阵营 → ' + lb + ' · ' + factionStanceText(f), 2.6);
    if (typeof logInfo === 'function') logInfo('faction', '玩家阵营切换 ' + from + ' → ' + f);
  }
  return f;
}

/* 按 FACTION_PLAYABLE 循环，给调试面板用 */
function playerCycleFaction(){
  const curF = playerFactionId();
  let i = FACTION_PLAYABLE.indexOf(curF);
  if (i < 0) i = 0;
  return playerSetFaction(FACTION_PLAYABLE[(i + 1) % FACTION_PLAYABLE.length]);
}

/* "与谁敌对 / 与谁中立"的一句话摘要，给 HUD 与 setMsg 用 */
function factionStanceText(f){
  if (typeof FACTION_DEF === 'undefined') return '';
  const me = f || playerFactionId();
  const hostile = [], neutral = [];
  for (const k in FACTION_DEF){
    if (k === me || k === 'player') continue;
    if (k === 'neutral') continue;      /* "与中立中立"读着别扭，也不提供信息 */
    const lb = FACTION_DEF[k].label || k;
    let h;
    if (me === 'neutral') h = false;
    else {
      const ov = (typeof factionRelGet === 'function') ? factionRelGet(me, k) : null;
      h = ov ? (ov === 'hostile') : ((FACTION_DEF[me].hostiles.indexOf(k) >= 0) || (FACTION_DEF[k].hostiles.indexOf(me) >= 0));
    }
    (h ? hostile : neutral).push(lb);
  }
  const parts = [];
  if (hostile.length) parts.push('与 ' + hostile.join('、') + ' 敌对');
  if (neutral.length) parts.push('与 ' + neutral.join('、') + ' 中立');
  return parts.join(' · ') || '独行';
}

/* ---------------- 阵营外观：底色与势力弧 ----------------
 * 关键区别：「看见目标」不等于「看见玩家」。
 * A/B 两拨人互相开火时，双方 e.sees 都是 true；如果按 e.sees 就刷成红色，
 * 两拨人会在交火的一瞬间变成同一种颜色，看起来像自己人打自己人。
 * 所以"红色（发现你了）"只跟 seesPlayer 走，其余情况一律按阵营色。 */
function enemySeesYou(e){
  if (!e || !e.sees) return false;
  return (e.seesPlayer === undefined) ? true : !!e.seesPlayer;
}
function enemyBodyTint(e){
  const T = (typeof enemyType === 'function') ? (enemyType(e) || {}) : {};
  /* 老关卡（第一、二章等）的敌人根本没有 faction 字段：
     这类单位一律沿用旧的调色板逻辑（P27/P92/P91），不吃新的阵营配色，
     否则它们会因为 factionLook(undefined) 落到 neutral 灰而整体变灰。 */
  if (!e.faction){
    const _t0 = (typeof enemyType === 'function') ? (enemyType(e) || {}) : {};
    let _c0 = e.minionTint ? e.minionTint : (e.sees ? PAL.P91 : (e.mode === 1 ? PAL.P92 : PAL.P27));
    const _ar0 = (e.armor && e.armor.kind) || _t0.armorKind || null;
    if (_ar0 && e.armor && !e.bossKind && typeof _c0 === 'string' && _c0.charAt(0) === '#') _c0 = mixHex(_c0, armorDef(_ar0).pal, 0.30);
    return _c0;
  }
  const look = (typeof factionLook === 'function') ? factionLook(e.faction) : { body: '#5f8fd8', light: '#c8e0ff' };
  /* 底色永远是阵营色。
     以前"看见玩家就整个刷红"，结果 A/B 交火时两边同时变红 —— 用户反馈的根本原因就是这句。
     现在"他盯上你了"改成一圈提示环（见 44-sfxcombat 的敌人绘制），身体颜色不再被吃掉。 */
  let c = e.minionTint ? e.minionTint : mixHex(look.body, '#141a21', 0.30);
  /* 警戒/搜索中：往该阵营的浅色推一档，状态变化看得见，但阵营不会变 */
  if (!e.minionTint && e.mode === 1) c = mixHex(c, look.light, 0.30);
  const arK = (e.armor && e.armor.kind) || T.armorKind || null;
  if (arK && e.armor && !e.bossKind && typeof c === 'string' && c.charAt(0) === '#'){
    c = mixHex(c, armorDef(arK).pal, 0.30);
  }
  return c;
}
function enemyShowsFactionArc(e){
  /* 活着就画，不再因为"看见你了"而消失 —— 混战时正是最需要分清谁是谁的时候 */
  return !!(e && e.faction && !e.dead && !e.dummy);
}
/* 势力弧/头顶标记的"可见度"：只在刚踩出声纹的那一段窗口里显示。
   理由（用户 2026-11-21）：站着不动的敌人身上挂一圈轮廓 = 透视，
   看不到人却能看到它的圈，等于给小地图报点。
   窗口长度与声纹寿命一致（DataSfxFoot.life），并按剩余时间淡出，
   所以观感和室外声纹完全同步：先听到动静，圈才浮出来，然后慢慢散。 */
function enemyStepRevealK(e){
  if (!e) return 0;
  const D = (typeof DataSfxFoot !== 'undefined') ? DataSfxFoot : null;
  if (D && D.on === false) return 0;
  const life = (D && D.life) || 1.55;
  const at = (typeof e._ripAt === 'number') ? e._ripAt : -1e9;
  const now = (typeof uiT === 'number') ? uiT : 0;
  const age = now - at;
  if (age < 0 || age > life) return 0;
  return Math.pow(1 - age / life, (D && D.fadePow) || 0.7);
}
