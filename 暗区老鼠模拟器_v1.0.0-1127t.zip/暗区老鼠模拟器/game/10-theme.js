/* ================= 主题 =================
   第一章是夜里，近黑底 + 冷青；第二章白天，米白底 + 炭黑物件。
   做法不是把颜色硬编码改一遍，而是给 ctx 套一层壳：
   浅色主题下把 fillStyle/strokeStyle/shadowColor 过一遍 themeColor()，
   深色主题原样返回，所以第一章一个像素都不会变。 */
let THEME_LIGHT = false;

const THEME_EXACT = {
  /* 背景 / 网格 / 墙 */
  [PAL.P5]: PAL.P34,
  [PAL.P66]: PAL.P65,
  [PAL.P22]: PAL.P25,
  [PAL.P24]: PAL.P84,
  /* 玩家 */
  [PAL.P2]: PAL.P6,
  [PAL.P3]: PAL.P177,
  [PAL.P8]: PAL.P175,
  [PAL.P15]: PAL.P174,
  /* 视野锥：浅蓝半透 -> 深灰半透（像影子） */
  [PAL.P50]: PAL.P276,
  [PAL.P51]: PAL.P64,
  [PAL.P52]: PAL.P279,
  /* 烟雾：灰 -> 尘土黄 */
  [PAL.P47]: PAL.P187,
  [PAL.P41]: PAL.P173,
  [PAL.P39]: PAL.P165,
  /* 物资：亮黄 -> 深琥珀（白底上亮黄会糊） */
  [PAL.P0]: PAL.P88,
  [PAL.P60]: PAL.P180,
  /* 撤离点 */
  [PAL.P67]: PAL.P203,
  [PAL.P42]: PAL.P301,
  [PAL.P45]: PAL.P189,
  [PAL.P46]: PAL.P295,
  /* HUD 里的浅色文字统一换成墨色 */
  [PAL.P18]: PAL.P268,
  [PAL.P54]: PAL.P267,
  [PAL.P55]: PAL.P269,
  [PAL.P20]: PAL.P265,
  [PAL.P152]: PAL.P282,
  [PAL.P49]: PAL.P283,
  [PAL.P17]: PAL.P263,
  [PAL.P48]: PAL.P284,
  [PAL.P53]: PAL.P191,
  [PAL.P57]: PAL.P262,
  [PAL.P19]: PAL.P256,
  [PAL.P16]: PAL.P289,
  [PAL.P40]: PAL.P294,
  [PAL.P68]: PAL.P290,
  [PAL.P14]: PAL.P288,
  [PAL.P4]: PAL.P77,
  [PAL.P10]: PAL.P74,
  [PAL.P9]: PAL.P75,
  [PAL.P31]: PAL.P23,
  [PAL.P30]: PAL.P23,
  [PAL.P27]: PAL.P82,
  [PAL.P33]: PAL.P6,
  /* 人机视野锥：浅蓝 -> 影灰 */
  [PAL.P129]: PAL.P278,
  [PAL.P43]: PAL.P64,
  [PAL.P69]: PAL.P285,
  /* 蓝/绿强调色在米白底上要压深，否则糊成一片 */
  [PAL.P28]: PAL.P76,
  [PAL.P1]: PAL.P73,
  [PAL.P11]: PAL.P6,
  [PAL.P21]: PAL.P190,
  [PAL.P58]: PAL.P179,
  /* m34759：白天关卡的 HUD 底板原来是 #fbf9f4（近乎纯白纸），一大块白得刺眼、像渲染 bug；
     一起把压在白底上的浅色字压深，否则「热成像电量 空格开机」这种根本看不清 */
  [PAL.P93]:  'rgba(232,236,241,0.62)',   /* 白纸 → 磨砂灰 */
  [PAL.P89]:  'rgba(120,132,146,0.30)',   /* 底板描边 */
  [PAL.P156]: 'rgba(62,96,130,0.95)',     /* 浅蓝说明字 → 深蓝灰 */
  [PAL.P217]: 'rgba(178,96,30,0.95)',     /* 橙色强调字 → 深橙 */
  [PAL.P57]:  'rgba(40,52,64,0.86)',      /* HP 数字 */
  [PAL.P48]:  'rgba(60,74,88,0.72)',      /* 人机/伤害那行 */
  [PAL.P56]:  'rgba(178,64,54,0.92)',     /* 暴露中 */
  [PAL.P3]: PAL.P178
};

/* 没有精确命中时：低饱和的浅色（HUD 灰白字、白圈之类）按"变墨色"处理 */
/* 每帧要换算几百次颜色（每个 fillStyle 赋值一次），字符串解析很贵，
   于是拿个缓存兜住：同一个颜色串只解析一次。 */
const THEME_CACHE = new Map();
function themeColor(v){
  if (!THEME_LIGHT || typeof v !== 'string') return v;
  const hit = THEME_EXACT[v];
  if (hit) return hit;
  let got = THEME_CACHE.get(v);
  if (got !== undefined) return got;
  const m = /^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)$/.exec(v);
  if (!m){ THEME_CACHE.set(v, v); return v; }
  const r = +m[1], g = +m[2], b = +m[3], a = m[4] === undefined ? 1 : +m[4];
  const mx = Math.max(r,g,b), mn = Math.min(r,g,b);
  const l = (mx + mn) / 510;
  const s = mx === mn ? 0 : (mx - mn) / (mx + mn > 255 ? (510 - mx - mn) : (mx + mn));
  if (l <= 0.62 || s > 0.42){ THEME_CACHE.set(v, v); return v; }   /* 深的、或彩色的（红橙绿）一律不动 */
  /* 浅灰蓝 -> 墨色，透明度保留 */
  got = 'rgba(28,38,48,' + a.toFixed(3) + ')';
  THEME_CACHE.set(v, got);
  return got;
}

function TC(v){ return themeColor(v); }

/* 每次取 ctx.fillRect 都 bind 一次 = 每帧造几百个临时函数，这里缓存住 */
const CTX_BOUND = new WeakMap();          /* 每个绘制目标各存一份绑定缓存 */
function makeCtxProxy(target){
  let bound = CTX_BOUND.get(target);
  if (!bound){ bound = new Map(); CTX_BOUND.set(target, bound); }
  return new Proxy(target, {
    get(t, k){
      const v = t[k];
      if (typeof v !== 'function') return v;
      let f = bound.get(k);
      if (!f || f.__src !== v){ f = v.bind(t); f.__src = v; bound.set(k, f); }
      return f;
    },
    set(t, k, v){
      /* 深色主题（默认）下根本不需要换色：别为每次 fillStyle 多走一次函数调用，
         这一条在密集战斗里有十几万次/秒的量。 */
      if (THEME_LIGHT && (k === 'fillStyle' || k === 'strokeStyle' || k === 'shadowColor')) v = themeColor(v);
      t[k] = v;
      return true;
    }
  });
}
let ctx = makeCtxProxy(rawCtx);
/* 临时把绘制目标切到离屏画布，跑完切回来（静态层预渲染用） */
let _ctxCur = ctx;
function withDrawCtx(target, fn){
  const prev = ctx, prevRaw = _ctxCur;
  ctx = makeCtxProxy(target); _ctxCur = target;
  try { return fn(); } finally { ctx = prev; _ctxCur = prevRaw; }
}

const clamp = (v,a,b)=> v<a?a:(v>b?b:v);
const dist  = (x1,y1,x2,y2)=> Math.hypot(x2-x1, y2-y1);
const lerp  = (a,b,t)=> a+(b-a)*t;
/* 搜出来的防弹衣该是"捡到的旧东西"：三成接近全新，其余在区间里随便抽。
   以前只有一个死区间，看起来不是件件满耐久就是件件半耐久。 */
const rollDurPct = (a, b)=>{
  const r = Math.random();
  if (r < 0.30) return 0.92 + Math.random() * 0.08;   /* 近全新 92%~100% */
  if (r < 0.55) return lerp(a, Math.max(a, 0.45), Math.random());  /* 偏旧 */
  return lerp(Math.min(b, 0.60), b, Math.random());   /* 偏新 */
};
const TAU = Math.PI*2;
const normAng = a => { while(a>Math.PI)a-=TAU; while(a<-Math.PI)a+=TAU; return a; };
/* 割草战斗随机流。音效、粒子和屏幕抖动不消耗这一状态；普通关卡沿用原来的随机源。 */
let arenaRng = null;
function arenaSeedRandom(seed){
  if (seed === undefined){
    const words = new Uint32Array(1);
    if (typeof crypto !== 'undefined' && crypto.getRandomValues) crypto.getRandomValues(words);
    else words[0] = (Date.now() ^ Math.floor(Math.random() * 4294967296)) >>> 0;
    seed = words[0];
  }
  seed = seed >>> 0;
  let s = seed;
  const state = [];
  for (let i = 0; i < 4; i++){
    s = (s + 0x9e3779b9) >>> 0;
    let z = s;
    z = Math.imul(z ^ (z >>> 16), 0x21f0aaad);
    z = Math.imul(z ^ (z >>> 15), 0x735a2d97);
    state.push((z ^ (z >>> 15)) >>> 0);
  }
  if (!state.some(Boolean)) state[0] = 1;
  arenaRng = { algorithm:'xoshiro128**', version:1, seed, state };
  return arenaGetRandomState();
}
function arenaValidRandomState(value){
  const uint = n => Number.isInteger(n) && n >= 0 && n <= 0xffffffff;
  return !!(value && value.algorithm === 'xoshiro128**' && value.version === 1 &&
    uint(value.seed) && Array.isArray(value.state) && value.state.length === 4 &&
    value.state.every(uint) && value.state.some(Boolean));
}
function arenaGetRandomState(){
  return arenaRng ? { algorithm:arenaRng.algorithm, version:arenaRng.version,
    seed:arenaRng.seed, state:arenaRng.state.slice() } : null;
}
function arenaSetRandomState(value){
  if (!arenaValidRandomState(value)) return false;
  arenaRng = { algorithm:value.algorithm, version:value.version,
    seed:value.seed, state:value.state.slice() };
  return true;
}
function arenaRandom(){
  /* 地图生成阶段还没有 ar，但只要显式播过种就照样走种子流 —— 不然同一种子生成不出同一张图 */
  if (!ar && !(typeof dzRngActive !== 'undefined' && dzRngActive)) return Math.random();
  if (!arenaRng) arenaSeedRandom();
  const s = arenaRng.state;
  const x = Math.imul(s[1], 5);
  const result = Math.imul((x << 7) | (x >>> 25), 9) >>> 0;
  const t = s[1] << 9;
  s[2] = (s[2] ^ s[0]) >>> 0;
  s[3] = (s[3] ^ s[1]) >>> 0;
  s[1] = (s[1] ^ s[2]) >>> 0;
  s[0] = (s[0] ^ s[3]) >>> 0;
  s[2] = (s[2] ^ t) >>> 0;
  s[3] = ((s[3] << 11) | (s[3] >>> 21)) >>> 0;
  return result / 4294967296;
}
const fxRand = (a,b)=> a+Math.random()*(b-a);

const rand = (a,b)=> a+arenaRandom()*(b-a);

/* ---------------- 参数 ---------------- */
const FIELDS = [
  {k:'enemies',   label:'人机数量',   min:1,  max:10,   step:1,   def:4,   unit:'个'},
  {k:'eDmg',      label:'人机伤害',   min:1,  max:40,   step:1,   def:12,  unit:''},
  {k:'fireRate',  label:'人机射速',   min:0.2,max:3,    step:0.1, def:0.8, unit:'发/秒'},
  {k:'mag',       label:'人机弹匣',   min:1,  max:12,   step:1,   def:6,   unit:'发'},
  {k:'reload',    label:'换弹时间',   min:0.3,max:5,    step:0.1, def:1.5, unit:'秒'},
  {k:'bulletSpd', label:'敌人子弹速度',   min:200,max:2000, step:20,  def:1200, unit:''},
  {k:'spread',    label:'射击散布',   min:0,  max:25,   step:1,   def:6,   unit:'°'},
  {k:'hearR',     label:'脚步可听距', min:60, max:700,  step:10,  def:320, unit:''},
  {k:'eSpeed',    label:'人机移速',   min:30, max:220,  step:5,   def:96,  unit:''},
  {k:'eMemory',   label:'追踪记忆',   min:1,  max:20,   step:1,   def:7,   unit:'秒'},
  {k:'hp',        label:'玩家生命',   min:30, max:500,  step:10,  def:100, unit:''},
  {k:'gunVol',    label:'武器音量',   min:0,  max:100,  step:5,   def:70,  unit:'%'},
  {k:'stepVol',   label:'自己的脚步',     min:0,  max:100,  step:5,   def:75,  unit:'%'},
  {k:'ambVol',    label:'环境声',     min:0,  max:100,  step:5,   def:80,  unit:'%'},
  {k:'pSpeed',    label:'玩家移速',   min:80, max:340,  step:5,   def:172, unit:''},
  {k:'grenades',  label:'烟雾弹数量', min:1,  max:9,    step:1,   def:2,   unit:'颗'},
  {k:'smokeLife', label:'烟雾持续',   min:3,  max:40,   step:1,   def:10,  unit:'秒'},
  {k:'smokeR',    label:'烟雾半径',   min:50, max:280,  step:5,   def:120, unit:''},
  {k:'loot',      label:'物资数量',   min:1,  max:8,    step:1,   def:3,   unit:'件'},
  {k:'pVision',   label:'你的视距',   min:120,max:700,  step:10,  def:360, unit:''},
  {k:'pFov',      label:'你的视角',   min:40, max:300,  step:5,   def:110, unit:'°'}
];

const PRESETS = {
  easy:   {enemies:2, eDmg:4,  fireRate:0.6, mag:5, reload:2.2, bulletSpd:1200, spread:9,
           eVision:210, hearR:250, eSpeed:74, eMemory:4, hp:150, pSpeed:190, grenades:3,
           smokeLife:14, smokeR:150, loot:2, pVision:460, pFov:140},
  normal: {enemies:5, eDmg:9,  fireRate:1.0, mag:8, reload:1.3, bulletSpd:1320, spread:5,
           eVision:360, hearR:340, eSpeed:104, eMemory:9, hp:100, pSpeed:172, grenades:2,
           smokeLife:10, smokeR:120, loot:3, pVision:360, pFov:110},
  hard:   {enemies:7, eDmg:14, fireRate:1.6, mag:10, reload:0.9, bulletSpd:1460, spread:3,
           eVision:430, hearR:430, eSpeed:126, eMemory:13, hp:80, pSpeed:160, grenades:2,
           smokeLife:8, smokeR:100, loot:4, pVision:300, pFov:95},
  /* 噩梦：人比你快、比你准、记得住、血薄得像纸。想过就得靠烟和墙，不是靠枪法 */
  nightmare: {enemies:9, eDmg:19, fireRate:2.0, mag:12, reload:0.7, bulletSpd:1620, spread:2,
           eVision:500, hearR:520, eSpeed:136, eMemory:16, hp:60, pSpeed:152, grenades:1,
           smokeLife:7, smokeR:92, loot:5, pVision:300, pFov:95}
};

const DIFF_ORDER = ['easy', 'normal', 'hard', 'nightmare'];
const DIFF_LABEL = {easy:'简单', normal:'普通', hard:'困难', nightmare:'噩梦', custom:'自定义'};

const DEFAULTS = {}; FIELDS.forEach(f=>DEFAULTS[f.k]=f.def);
/* 画质页也是正式配置。以前这三项在 DEFAULTS 建好以后才临时挂到 CFG 上：
   saveCfg 虽然会写进 localStorage，启动读取却只遍历 DEFAULTS，于是每次重开都被漏掉。 */
DEFAULTS.lodNear = 560;
DEFAULTS.coneAlpha = 1;
/* m32306：玩家自己的脚步声可听范围虚线圈，透明度玩家自己调（0=不画）。 */
DEFAULTS.hearRingA = 1;
/* m33507：纯听觉项，跟开发者无关 */
DEFAULTS.stepVol = 75;
DEFAULTS.ambVol = 80;
DEFAULTS.lodFar = 1010;
let CFG = Object.assign({}, DEFAULTS);
CFG.dev = false;            /* 开发者模式：手动开关（来自开发页那个按钮）*/
CFG.devExplicit = false;    /* true = 这个 dev 是手动点亮的，允许记进存档 */
CFG.heatInf = false;        /* 开发者：热成像无限（第四关也能用） */
CFG.showHurt = true;        /* 玩家挨打时冒出具体伤害数字（默认开，算玩法提示不算作弊） */
CFG.xray = false;           /* 开发者：透视，视野外的敌人也画出来 */
CFG.devDmg = false;        /* 开发者：一枪 999999 伤害（L 开关） */
CFG.devFreeze = false;     /* 开发者暂停：世界静止，只有玩家能动（P） */
CFG.oneShot = false;       /* 面板开关：玩家一枪 999999（不用开开发者模式也能开） */
CFG.walkToggle = false;     /* 静步：false = 按住（默认），true = 按一下切换 */
CFG.aiArc = false;          /* 开发者：AI 弧线走路（DataMOVE），默认关 */
CFG.fogVision = false;      /* 视野外隐身：任何关卡都能开（关掉时按各关 rules.fog / L.blind 走） */
let diffName = 'normal';    /* 当前难度：easy / normal / hard / custom */
/* 2026-11-24：diffName 会被开发者面板改成 'custom'，但"我到底玩的是哪一档"不能因此丢掉 ——
   通关记勋章时要用这个（玩家报过：开着开发者面板打赢困难，章没记上）。 */
let presetName = 'normal';
try {
  const saved = JSON.parse(localStorage.getItem('after5_cfg') || 'null');
  if (saved){
    for (const k in DEFAULTS) if (typeof saved[k] === 'number') CFG[k] = saved[k];
    /* 开发者模式只认"手动开关"：
       - 手动在开发页点亮的 → 记进存档（devExplicit），下次进来还是开；
       - 拖滑块顺带打开的 → 只在本次运行有效，不写档（这就是"不污染正常对局"）。
       以前 dev 无条件写档，导致"只要拖过一次滑块，以后每局都是开发者模式"。 */
    /* m33127：开发者入口没解锁（面板标题没连点过）就绝不允许 dev 是开的。
       以前只看存档里的 dev，于是「上次开着 → 这次开发页被藏起来 → 玩家看着像没开，
       其实已经开了」，选关里就冒出测试区。解锁状态单独存在 after5_devUnlock 里，
       这里直接读，避免和 19-truckdraw.js 的加载顺序打架。 */
    let _devUnlocked = false;
    try { _devUnlocked = (localStorage.getItem('after5_devUnlock') === '1'); } catch(e2){}
    CFG.dev = _devUnlocked && (!!saved.dev || !!saved.devExplicit);
    CFG.devExplicit = CFG.dev;
    CFG.heatInf = !!saved.heatInf;
CFG.showHurt = (saved.showHurt === undefined) ? true : !!saved.showHurt;
    CFG.xray = !!saved.xray;
    CFG.oneShot = !!saved.oneShot;
    CFG.walkToggle = !!saved.walkToggle;
    CFG.aiArc = !!saved.aiArc;
    CFG.fogVision = !!saved.fogVision;
    /* m32656：custom 是"拖过滑块"留下的临时难度，不该跟着存档回到关卡里 */
    if (saved.diff && saved.diff !== 'custom'){ diffName = saved.diff; presetName = saved.diff; }
    if (CFG.dev && diffName === 'normal') diffName = 'custom';
  }
} catch(e){}
/* 视野外隐身：面板开关的值，任何关卡都生效。
   各关自己的 rules.fog / L.blind 照旧，这里是"额外再加一层" —— 只做 OR，不覆盖。 */
function fogVisionOn(){
  return !!(typeof CFG !== 'undefined' && CFG && CFG.fogVision);
}
function saveCfg(){
  try {
    /* m35424：性能测试页（?bench=dz）是临时沙盒，绝不写正式存档 */
    if (typeof window !== 'undefined' && window.__BENCH_ISO) return;
    CFG.diff = diffName;
    /* 只有"手动点开关"过的开发者模式才落盘；拖滑块带出来的只是本次运行有效 */
    const o = Object.assign({}, CFG);
    /* 开着的开发者模式一律记住（拖滑块打开也算），关掉时连记忆一起清；
       m33127：没解锁开发者入口时，一律不写 dev —— 防止"偷偷开着" 传下去 */
    let _devUnlocked2 = false;
    try { _devUnlocked2 = (localStorage.getItem('after5_devUnlock') === '1'); } catch(e3){}
    o.dev = _devUnlocked2 && !!CFG.dev;
    o.devExplicit = o.dev;
    if (!o.dev){ delete o.dev; delete o.devExplicit; }
    localStorage.setItem('after5_cfg', JSON.stringify(o));
  } catch(e){}
}

/* ---------------- 关卡 ---------------- */
