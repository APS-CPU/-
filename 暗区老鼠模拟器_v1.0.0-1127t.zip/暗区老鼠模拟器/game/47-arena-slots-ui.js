function arenaSlotSavedTime(value){
  const d = new Date(value);
  if (!Number.isFinite(d.getTime())) return '—';
  const two = n => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + two(d.getMonth() + 1) + '-' + two(d.getDate()) +
    ' ' + two(d.getHours()) + ':' + two(d.getMinutes()) + ':' + two(d.getSeconds());
}
function arenaSaveButtonVisible(){
  return !arenaSlotUI && !!(ar && !ar.over && player && player.hp > 0 && state === 'play');
}
function arenaSaveButtonRect(){
  const s = DataARENA_SLOT_UI.layout.save;
  return { x: W - s.width - s.right, y: s.top, w: s.width, h: s.height };
}

const _ARENA_SLOT_META_VIEW={};
function arenaSlotMetaView(meta,result){
  result.wave=DataARENA_SLOT_UI.text.waveLead + meta.wave + DataARENA_SLOT_UI.text.waveTail;
  result.difficulty=DataARENA_SLOT_UI.text.difficultyLead + (DIFF_LABEL[meta.difficulty] || meta.difficulty);
  result.score=DataARENA_SLOT_UI.text.scoreLead + meta.score;
  result.savedAt=DataARENA_SLOT_UI.text.savedAtLead + arenaSlotSavedTime(meta.savedAt);
  return result;
}
const _ARENA_SLOT_CONFIRM_VIEW={};
function arenaSlotConfirmView(confirm,index,result){
  result.label=confirm==='load'?DataARENA_SLOT_UI.text.load:confirm==='delete'?DataARENA_SLOT_UI.text.delete:DataARENA_SLOT_UI.text.overwrite;
  result.title=result.label + DataARENA_SLOT_UI.text.slotLead + (index + 1) + DataARENA_SLOT_UI.text.question;
  result.description=confirm==='load'?DataARENA_SLOT_UI.text.loadDetail:
    confirm==='delete'?DataARENA_SLOT_UI.text.deleteDetail:DataARENA_SLOT_UI.text.overwriteDetail;
  return result;
}
const _ARENA_SLOT_SCREEN_VIEW={};
function arenaSlotScreenView(mode,slots,result){
  const entry=mode==='entry';
  result.entry=entry;
  result.title=entry?DataARENA_SLOT_UI.text.entryTitle:DataARENA_SLOT_UI.text.manualTitle;
  result.description=entry?DataARENA_SLOT_UI.text.entryDetail:DataARENA_SLOT_UI.text.manualDetail;
  result.emptyDescription=entry?DataARENA_SLOT_UI.text.emptyEntry:DataARENA_SLOT_UI.text.emptyManual;
  result.emptyAction=entry?DataARENA_SLOT_UI.text.newRun:DataARENA_SLOT_UI.text.saveHere;
  result.backAction=entry?DataARENA_SLOT_UI.text.back:DataARENA_SLOT_UI.text.cancel;
  const text=DataARENA_SLOT_UI.text;
  result.footer=entry&&slots.every(Boolean)?ARENA_SLOT_COUNT+text.fullTail:
    mode==='manual'?text.autosaveLead+ARENA_AUTOSAVE_EVERY+text.autosaveTail:'';
  return result;
}
function drawArenaSlots(){
  const ui = arenaSlotUI;
  const S = DataARENA_SLOT_UI.palette;
  const layout = DataARENA_SLOT_UI.layout;
  if (!ui) return;
  const screen = arenaSlotScreenView(ui.mode,ui.slots,_ARENA_SLOT_SCREEN_VIEW);
  uiButtons = [];
  const light = THEME_LIGHT;
  THEME_LIGHT = false;
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = screen.entry ? S.entry : S.manual;
  ctx.fillRect(0, 0, W, H);
  ctx.textAlign = 'center';
  ctx.font = 'bold 34px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = S.title;
  ctx.fillText(screen.title, W / 2, 126);
  ctx.font = '15px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = S.intro;
  ctx.fillText(screen.description, W / 2, 164);
  const {width, height, gap, top, radius, inset} = layout.card;
  const choice = layout.cardAction;
  const left = (W - width * ARENA_SLOT_COUNT - gap * (ARENA_SLOT_COUNT - 1)) / 2;
  for (let i = 0; i < ARENA_SLOT_COUNT; i++){
    const x = left + i * (width + gap), snap = ui.slots[i];
    const hover = mouse.x >= x && mouse.x <= x + width && mouse.y >= top && mouse.y <= top + height;
    ctx.fillStyle = hover ? S.cardHot : S.card;
    ctx.strokeStyle = hover ? S.edgeHot : S.edge;
    ctx.lineWidth = hover ? 2 : 1;
    roundRect(x, top, width, height, radius); ctx.fill(); ctx.stroke();
    ctx.textAlign = 'left';
    ctx.fillStyle = S.slotTitle;
    ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
    ctx.fillText(DataARENA_SLOT_UI.text.slotLead + (i + 1), x + inset, top + 43);
    if (snap){
      const view = arenaSlotMetaView(snap.meta,_ARENA_SLOT_META_VIEW);
      ctx.font = '18px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = S.wave;
      ctx.fillText(view.wave, x + inset, top + 93);
      ctx.font = '16px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = S.meta;
      ctx.fillText(view.difficulty, x + inset, top + 130);
      ctx.fillText(view.score, x + inset, top + 165);
      ctx.font = '13px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = S.time;
      ctx.fillText(view.savedAt, x + inset, top + 202);
      if (screen.entry){
        btn(x + choice.deleteX, top + choice.top, choice.deleteWidth, choice.height, DataARENA_SLOT_UI.text.delete, () => arenaRunSlotCommand('ask-delete',i), { dark: true });
        btn(x + inset, top + choice.top, choice.loadWidth, choice.height, DataARENA_SLOT_UI.text.load, () => arenaRunSlotCommand('choose',i), { primary: true, dark: true });
      } else btn(x + inset, top + choice.top, width - 2 * inset, choice.height, DataARENA_SLOT_UI.text.saveHere, () => arenaRunSlotCommand('choose',i), { primary: true, dark: true });
    } else {
      ctx.font = '22px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = S.emptyTitle;
      ctx.fillText(DataARENA_SLOT_UI.text.emptySlot, x + inset, top + 120);
      ctx.font = '14px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = S.emptyDetail;
      ctx.fillText(screen.emptyDescription, x + inset, top + 160);
      btn(x + inset, top + choice.top, width - 2 * inset, choice.height, screen.emptyAction, () => arenaRunSlotCommand('choose',i), { primary: true, dark: true });
    }
    /* 删除按钮先注册，整张卡片也可点；命中删除不会误触读档。 */
    btn(x, top, width, height, '', () => arenaRunSlotCommand('choose',i), { invisible: true, dark: true });
  }
  ctx.textAlign = 'center';
  ctx.font = '14px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = S.footer;
  if (screen.footer) ctx.fillText(screen.footer, W / 2, 565);
  const back = layout.back;
  btn(W / 2 - back.width / 2, back.top, back.width, back.height, screen.backAction, () => arenaRunSlotCommand('close'), { dark: true });
  if (ui.error){ ctx.fillStyle = S.error; ctx.fillText(ui.error, W / 2, 700); }
  flushButtons();
  if (ui.confirm){
    uiButtons = [];
    ctx.fillStyle = S.confirmationShade; ctx.fillRect(0, 0, W, H);
    const box = layout.confirm;
    const x = W / 2 - box.width / 2, y = H / 2 - box.height / 2;
    ctx.fillStyle = S.confirmation; ctx.strokeStyle = S.confirmationEdge;
    roundRect(x, y, box.width, box.height, box.radius); ctx.fill(); ctx.stroke();
    ctx.textAlign = 'center';
    ctx.font = 'bold 25px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = S.confirmationTitle;
    const confirmView = arenaSlotConfirmView(ui.confirm,ui.index,_ARENA_SLOT_CONFIRM_VIEW);
    ctx.fillText(confirmView.title, W / 2, y + 55);
    ctx.font = '15px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = S.confirmationDetail;
    ctx.fillText(confirmView.description, W / 2, y + 99);
    if (ui.error){ ctx.font = '13px "Microsoft YaHei",sans-serif'; ctx.fillStyle = S.error; ctx.fillText(ui.error, W / 2, y + 132); }
    const command = ui.confirm === 'load' || ui.confirm === 'delete' ? ui.confirm : 'overwrite';
    const action = () => arenaRunSlotCommand(command,ui.index);
    btn(W / 2 - box.actionGap / 2 - box.actionWidth, y + box.actionTop, box.actionWidth, box.actionHeight, confirmView.label, action, { primary: true, dark: true });
    btn(W / 2 + box.actionGap / 2, y + box.actionTop, box.actionWidth, box.actionHeight, DataARENA_SLOT_UI.text.cancel, () => arenaRunSlotCommand('cancel'), { dark: true });
    flushButtons();
  }
  ctx.restore();
  THEME_LIGHT = light;
}
function drawArenaSaveUI(){
  if (arenaSlotUI){ drawArenaSlots(); return; }
  if (!arenaSaveButtonVisible()) return;
  const r = arenaSaveButtonRect();
  const button = btn(r.x, r.y, r.w, r.h, DataARENA_SLOT_UI.text.manualSave, () => arenaRunSlotCommand('open-manual'), { dark: true, overlay: true });
  const all = uiButtons;
  uiButtons = [button];
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
  flushButtons();
  ctx.restore();
  uiButtons = all;
}
