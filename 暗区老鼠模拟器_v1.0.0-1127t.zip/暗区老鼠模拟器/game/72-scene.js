/* 72-scene.js —— 场景存档（m44040）
   拍一张"当前这一局长什么样"的快照，退出/刷新之后还能原样摆回来：
     关卡索引 + 玩家位置/血/护甲/背包 + 场上敌人 + 车辆。
   F5 存 / F6 读（存盘走 localStorage，读档 = startLevel + 用开发者生成器重建）。

   为什么读档要 CFG.dev：重建靠 devSpawnKind/spawnTruck，前者只在开发者模式放行；
   存档本身随时可存（拍到一半想留个念也行）。 */
const SCENE_KEY = 'dsh_scene_v1';
const SCENE_FMT = 'dsh-scene';
const SCENE_VER = 1;

function sceneHas(){
  try { return !!localStorage.getItem(SCENE_KEY); } catch(e){ return false; }
}

/* 拍快照：只存"能重建"的信息，不存运行时临时量 */
function sceneSnap(){
  const L = cur();
  const p = player || {};
  const ee = [];
  for (const e of (enemies || [])){
    if (e.dead || !e.type) continue;
    ee.push({
      ty: e.type,
      x: Math.round(e.x * 10) / 10,
      y: Math.round(e.y * 10) / 10,
      hp: Math.round(e.hp || 0),
      fac: e.faction || null,
      ang: Math.round((e.ang || 0) * 1000) / 1000,
    });
  }
  const tt = [];
  for (const t of (trucks || [])){
    if (t.gone) continue;
    tt.push({
      k: t.veh || t.type || 'truck',
      x: Math.round(t.x * 10) / 10,
      y: Math.round(t.y * 10) / 10,
      ang: Math.round((t.ang || 0) * 1000) / 1000,
      team: (typeof truckTeam === 'function') ? truckTeam(t) : 'neutral',
      hp: Math.round(t.hp || 0),
    });
  }
  return {
    fmt: SCENE_FMT, ver: SCENE_VER,
    lvl: levelIdx | 0,
    lvlName: (L && L.name) || '',
    p: {
      x: Math.round((p.x || 0) * 10) / 10,
      y: Math.round((p.y || 0) * 10) / 10,
      hp: Math.round(p.hp || 0),
      armor: (p.armor && p.armor.kind) || null,
      bag: (p.bag && p.bag.kind) || null,
    },
    e: ee, t: tt,
    at: Date.now(),
  };
}

function sceneSave(){
  let snap;
  try { snap = sceneSnap(); } catch(e){ setMsg('存档失败：' + e.message, 2); return false; }
  if (!snap.e.length && !snap.t.length && !snap.p.hp){ /* 空格子也允许存，只是没意义 */ }
  try { localStorage.setItem(SCENE_KEY, JSON.stringify(snap)); }
  catch(e){ setMsg('存档失败：浏览器不让写 localStorage', 2.4); return false; }
  setMsg('已存档 · ' + (snap.lvlName || ('第 ' + (snap.lvl + 1) + ' 关')) +
         ' · 敌人 ' + snap.e.length + ' · 车 ' + snap.t.length + '（F6 读档）', 2.6);
  logInfo('scene', '存档 ' + snap.e.length + ' 敌 / ' + snap.t.length + ' 车 · 关卡 ' + snap.lvl);
  return true;
}

/* 把一份快照写进当前局（不负责 startLevel，方便测试单独用） */
function sceneApply(snap){
  if (!snap || snap.fmt !== SCENE_FMT) return false;
  const L = cur();
  if (!L) return false;
  const p = player;
  if (p && snap.p){
    if (isFinite(snap.p.x)) p.x = clamp(snap.p.x, 20, L.w - 20);
    if (isFinite(snap.p.y)) p.y = clamp(snap.p.y, 20, L.h - 20);
    if (isFinite(snap.p.hp)) p.hp = Math.max(1, Math.min(snap.p.hp, (CFG && CFG.hp) || 100));
    if (snap.p.armor && typeof ARMOR_DEF !== 'undefined' && ARMOR_DEF[snap.p.armor]){
      const a = ARMOR_DEF[snap.p.armor];
      p.armor = { kind: a.id, label: a.label, reduce: a.reduce, hp: a.dur, maxHp: a.dur };
    } else p.armor = null;
    if (snap.p.bag && typeof BAG_DEF !== 'undefined' && BAG_DEF[snap.p.bag]){
      const b = BAG_DEF[snap.p.bag];
      p.bag = { kind: b.id, label: b.label, slots: b.slots, ammoK: b.ammoK };
    }
  }
  let ne = 0, nt = 0;
  for (const it of (snap.e || [])){
    if (!it || !it.ty) continue;
    const ok = (typeof devSpawnKind === 'function') &&
               devSpawnKind(it.ty, { x: it.x, y: it.y }, it.fac || undefined);
    if (!ok) continue;
    const e = enemies[enemies.length - 1];
    if (!e) continue;
    e.x = it.x; e.y = it.y;
    if (isFinite(it.hp)) e.hp = Math.max(1, it.hp);
    if (isFinite(it.ang)){ e.ang = it.ang; if ('angS' in e) e.angS = it.ang; }
    ne++;
  }
  for (const it of (snap.t || [])){
    if (!it || !it.k) continue;
    if (typeof spawnTruck !== 'function') continue;
    if (spawnTruck(it.k, { x: it.x, y: it.y }, it.team || 'neutral') === false) continue;
    const t = trucks[trucks.length - 1];
    if (!t) continue;
    t.x = it.x; t.y = it.y;
    if (isFinite(it.ang)){ t.ang = it.ang; t.head = it.ang; }
    if (isFinite(it.hp)) t.hp = Math.max(1, it.hp);
    if (typeof navPatchTruck === 'function') navPatchTruck(t);
    nt++;
  }
  logInfo('scene', '读档 ' + ne + ' 敌 / ' + nt + ' 车');
  return { enemies: ne, trucks: nt };
}

function sceneLoad(){
  let snap = null;
  try { snap = JSON.parse(localStorage.getItem(SCENE_KEY) || 'null'); } catch(e){ snap = null; }
  if (!snap || snap.fmt !== SCENE_FMT){ setMsg('没有存档（先按 F5 存一次）', 2.2); return false; }
  if (!CFG.dev){ setMsg('读档要用开发者模式重建单位（当前没开）', 2.6); return false; }
  const idx = clamp(snap.lvl | 0, 0, LEVELS.length - 1);
  startLevel(idx, 0);
  if (state === 'intro'){ intro = null; state = 'play'; }
  const r = sceneApply(snap);
  if (!r){ setMsg('读档失败：格式不对', 2.4); return false; }
  setMsg('已读档 · ' + (snap.lvlName || ('第 ' + (idx + 1) + ' 关')) +
         ' · 敌人 ' + r.enemies + ' · 车 ' + r.trucks, 2.6);
  return true;
}

window.addEventListener('keydown', function(ev){
  if (!ev || !CFG || !CFG.dev) return;
  if (state !== 'play') return;
  if (ev.code === 'F5'){ ev.preventDefault(); sceneSave(); return; }
  if (ev.code === 'F6'){ ev.preventDefault(); sceneLoad(); return; }
}, false);
