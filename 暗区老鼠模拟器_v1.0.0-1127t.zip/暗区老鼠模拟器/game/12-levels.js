/* ===== 关卡数据 =====
   加一关 = 往下面这个数组里加一条，不用改逻辑。
   字段说明：
     name      关卡名（选关界面显示）
     chapter   属于第几章（选关按章分页，章节名见表 buildChapters 里的 meta）
     w,h       地图尺寸（像素）
     theme     'dark' | 'light'（浅色主题会自动换色，见 THEME_EXACT）
     rules.mode  'stealth' 潜行 | 'blind' 视野外隐身 | 'boss' 猎场
                 （blind 关卡自动带"视野外隐身"，boss 关卡自动带"强制静步 + 电闸"）
     start     出生点 {x,y}
     extract   撤离点 {x,y,w,h}
     walls     墙 [{x,y,w,h}]
     loot      物资点 [{x,y}]
     slots     普通敌人巡逻线 [{x,y,wp:[[x,y],...]}]
     guardSpots 猎手驻点 [{x,y}]（boss 关用）
     switchSpots / exitSpots  电闸与出口候选点（boss 关用）
   规则字段在 reset() 里统一归一化成 L.rules，代码只看 L.rules + 下面两个派生别名。 */
/* 关卡数据已移到 data/levels.js */



/* 章节表按 LEVELS 里的 chapter 字段自动归并 */

/* ---- 第四关边界补丁 ----
   原来外圈 160px 几乎全是空的（上边挡 1%、下边 4%、右边 4%），
   贴着边界走等于免费高速路。这里沿四边各插几段伸进来的墙，
   把外圈切成几段：边界仍然能走，但每走一段就得往中间钻。
   顺带把三处守卫驻点挪到边界环上，让外圈变成有主的地盘。 */
(function sealBossPerimeter(){
  const L4 = LEVELS[3];
  if (!L4 || !L4.boss) return;
  const segs = [
    /* 竖着的插在上/下边，横着的插在左/右边；间距 640 / 500，把外圈切成小格 */
    [ 640,    0,  28, 200], [1280,    0,  28, 200],
    [1920,    0,  28, 200], [2560,    0,  28, 200],
    [ 640, 1800,  28, 200], [1280, 1800,  28, 200],
    [1920, 1800,  28, 200], [2560, 1800,  28, 200],
    [   0,  500, 200,  28], [   0, 1000, 200,  28], [   0, 1500, 200,  28],
    [3000,  500, 200,  28], [3000, 1000, 200,  28], [3000, 1500, 200,  28]
  ];
  for (const g of segs) L4.walls.push({x:g[0], y:g[1], w:g[2], h:g[3]});
  L4.guardSpots = [
    {x:1400, y:120, patrolRadius:420}, {x:1200, y:1880}, {x:3080, y:1000}
  ].concat(L4.guardSpots.slice(3));
})();

let levelIdx = 0;
let arenaLvl = null;                     /* 战斗，爽！！的关卡对象（不在 LEVELS 里，不污染正式关卡） */
let dzLvl = null;                        /* 死亡地带：6000×6000 的大图（不在 LEVELS 里） */
/* 死亡地带难度三档，全部锚在关卡原版那套数值上：
   hard      = 关卡「困难」 → 伤害 14 × 枪的 npc 系数（和故事关一模一样）
   nightmare = 关卡「噩梦」 → 伤害 19 × 枪的 npc 系数（和故事关一模一样）
   core      = 硬核         → 直接用手上这把枪的原值（手枪 46 / AR 36 …），不吃难度系数 */
let dzTier = 'hard';   /* m33967：默认困难，噩梦/硬核要靠成功撤离逐级解锁 */
const DZ_TIERS = ['hard', 'nightmare', 'core'];
const DZ_TIER_LABEL = { hard: '困难', nightmare: '噩梦', core: '硬核' };
let dzSavedCfg = null, dzSavedDiff = '';  /* 进模式前存一份难度参数，退出时还原，别把噩梦漏到别的关 */
const cur = () => ((typeof mobaLvl !== 'undefined' && mobaLvl) || dzLvl || customLvl || arenaLvl || LEVELS[levelIdx]);
let cam = {x:0, y:0};

/* ---------------- 大地图底座（m27522） ----------------
   分块（chunk）+ 视锥裁剪（cull）+ 静态层预渲染（static）。
   现在关卡还是原来那几个尺寸，但下面这套按"几千米 × 几千米"写：
   · 所有世界绘制前先过 cullPt / cullRect，屏幕外的绝对不画；
   · chunk 只回答"该醒哪些格子"，数据架子留着（spawns / props / triggers）；
   · 地面和墙烘焙到离屏画布，每帧只贴一张图，墙变了 / 走远了才重画。 */

const CHUNK_SIZE = 512;          /* 一格多少世界像素 */
const CHUNK_RADIUS = 2;          /* 以玩家所在格为中心，左右各 2 格 → 5×5 = 2560px */
const chunks = new Map();        /* 'cx,cy' → { cx, cy, x, y, active, data } */
const CHUNK_HOOKS = { activate: null, deactivate: null };
const chunkStats = { active: 0, created: 0, px: -999999, py: -999999 };

function chunkKey(cx, cy){ return cx + ',' + cy; }
function chunkOf(x, y){ return { cx: Math.floor(x / CHUNK_SIZE), cy: Math.floor(y / CHUNK_SIZE) }; }
function chunkGet(cx, cy, create){
  const k = chunkKey(cx, cy);
  let c = chunks.get(k);
  if (!c && create){
    c = { cx: cx, cy: cy, x: cx * CHUNK_SIZE, y: cy * CHUNK_SIZE, active: false,
          data: { spawns: [], props: [], triggers: [] } };
    chunks.set(k, c);
    chunkStats.created++;
  }
  return c || null;
}
function chunkInMap(c, L){
  L = L || cur();
  return c.x + CHUNK_SIZE > 0 && c.y + CHUNK_SIZE > 0 && c.x < L.w && c.y < L.h;
}
/* 只在玩家跨格子时重算，平时一帧就是一个整数比较 */
function updateChunks(x, y, L){
  L = L || cur();
  const q = chunkOf(x, y);
  if (chunkStats.px === q.cx && chunkStats.py === q.cy) return;
  chunkStats.px = q.cx; chunkStats.py = q.cy;
  const want = new Set();
  for (let dy = -CHUNK_RADIUS; dy <= CHUNK_RADIUS; dy++){
    for (let dx = -CHUNK_RADIUS; dx <= CHUNK_RADIUS; dx++){
      const c = chunkGet(q.cx + dx, q.cy + dy, true);
      if (!chunkInMap(c, L)) continue;
      want.add(chunkKey(c.cx, c.cy));
      if (!c.active){
        c.active = true;
        if (CHUNK_HOOKS.activate) { try { CHUNK_HOOKS.activate(c, L); } catch (err){ if (typeof reportErr === 'function') reportErr('12-levels', err); } }
      }
    }
  }
  let n = 0;
  for (const c of chunks.values()){
    if (c.active && !want.has(chunkKey(c.cx, c.cy))){
      c.active = false;
      if (CHUNK_HOOKS.deactivate) { try { CHUNK_HOOKS.deactivate(c, L); } catch (err){ if (typeof reportErr === 'function') reportErr('12-levels', err); } }
    }
    if (c.active) n++;
  }
  chunkStats.active = n;
}
function chunksActive(){
  const a = [];
  for (const c of chunks.values()) if (c.active) a.push(c);
  return a;
}
function chunksReset(){
  chunks.clear();
  chunkStats.active = 0; chunkStats.created = 0;
  chunkStats.px = -999999; chunkStats.py = -999999;
}

/* --- 视锥裁剪 --- */
/* 包围盒跟着当前变换矩阵走：镜头有震动 / 特写缩放，只看 cam 会算错 */
const CULL = { x0: 0, y0: 0, x1: 0, y1: 0, scale: 1, ok: false };
const cullStats = { tested: 0, culled: 0 };
const CULL_PAD = 40;

function cullBegin(){
  cullStats.tested = 0; cullStats.culled = 0;
  let m = null;
  try { if (ctx && typeof ctx.getTransform === 'function') m = ctx.getTransform(); } catch (err) { m = null; }
  if (m && typeof m.inverse === 'function' && isFinite(m.a) && isFinite(m.d) && (m.a || m.d)){
    const inv = m.inverse();
    CULL.scale = Math.hypot(m.a, m.b);
    const pts = [[0,0],[W,0],[0,H],[W,H]];
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (let i = 0; i < 4; i++){
      const wx = inv.a * pts[i][0] + inv.c * pts[i][1] + inv.e;
      const wy = inv.b * pts[i][0] + inv.d * pts[i][1] + inv.f;
      if (wx < x0) x0 = wx;
      if (wx > x1) x1 = wx;
      if (wy < y0) y0 = wy;
      if (wy > y1) y1 = wy;
    }
    CULL.x0 = x0 - CULL_PAD; CULL.y0 = y0 - CULL_PAD;
    CULL.x1 = x1 + CULL_PAD; CULL.y1 = y1 + CULL_PAD;
    CULL.ok = true;
  } else {
    const zoom = (typeof crkZoomK === 'function') ? crkZoomK() : 1;
    const halfW = W/2, halfH = H/2;
    CULL.scale = zoom;
    CULL.x0 = cam.x + halfW - halfW/zoom - CULL_PAD;
    CULL.y0 = cam.y + halfH - halfH/zoom - CULL_PAD;
    CULL.x1 = cam.x + halfW + halfW/zoom + CULL_PAD;
    CULL.y1 = cam.y + halfH + halfH/zoom + CULL_PAD;
    CULL.ok = true;
  }
}
function cullPt(x, y, pad){
  if (!CULL.ok) return true;
  cullStats.tested++;
  const p = pad || 0;
  if (x < CULL.x0 - p || x > CULL.x1 + p || y < CULL.y0 - p || y > CULL.y1 + p){ cullStats.culled++; return false; }
  return true;
}
function cullRect(x, y, w, h, pad){
  if (!CULL.ok) return true;
  cullStats.tested++;
  const p = pad || 0;
  if (x + w < CULL.x0 - p || x > CULL.x1 + p || y + h < CULL.y0 - p || y > CULL.y1 + p){ cullStats.culled++; return false; }
  return true;
}

/* --- 静态层：地面 + 墙烘焙到离屏画布 --- */
const ST_MARGIN = 320;
/* 地面和墙合成一张：这两层之间没有任何动态绘制，分两张只会每帧多一次整屏合成
   （1920×1440 的 drawImage 白贴一遍），离屏内存也从 22MB 降到 11MB。 */
const stLayers = { base: null };
let _stDirty = true, _stTh = null, _stLight = null;

function stNewCanvas(w, h){
  if (typeof OffscreenCanvas !== 'undefined'){ try { return new OffscreenCanvas(w, h); } catch (err){ if (typeof reportErr === 'function') reportErr('12-levels', err); } }
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}
function stMake(){ return { cv: null, ctx: null, x: 0, y: 0, cx: -1e9, cy: -1e9, w: 0, h: 0, dirty: true }; }
function staticInvalidate(){
  _stDirty = true;
  if (stLayers.base) stLayers.base.dirty = true;
}
function stSync(layer, drawFn){
  const camX = Math.round(cam.x), camY = Math.round(cam.y);
  /* 望远镜把画面拉远时，屏幕里装得下更多的世界：静态层得按同一倍率烘焙，
     否则画面边上会露出没烘到的空白，相机一动就闪一下 —— 看起来像在抽。
     倍率按 0.1 一档量化，免得举镜那 0.7 秒里每帧重建一次画布。 */
  const zk = (typeof binoZoomK === 'function' && player) ? Math.min(3, Math.ceil(Math.max(1, 1 / binoZoomK()) * 10) / 10) : 1;
  /* 什么时候重烘：图层是按「烘焙那一刻的相机」居中铺的，左右各多出 ST_MARGIN。
     只要相机相对烘焙点移动没超过 ST_MARGIN，屏幕就一直被这张图完整盖住。
     原来卡在半个 ST_MARGIN（160px）就重烘，等于白跑；现在放到 0.75 倍（240px），
     留 80px 余量，重烘频率降一半。相机移动本身不会让图层内容过期（内容过期走 _stDirty）。 */
  const needNew = !layer.cv || _stDirty || layer.dirty || layer.zk !== zk ||
                  Math.abs(camX - layer.cx) > ST_MARGIN * 0.75 ||
                  Math.abs(camY - layer.cy) > ST_MARGIN * 0.75;
  if (!needNew) return false;
  layer.zk = zk;
  const w = Math.ceil(W * zk) + ST_MARGIN * 2, h = Math.ceil(H * zk) + ST_MARGIN * 2;
  if (!layer.cv || layer.w !== w || layer.h !== h){ layer.cv = stNewCanvas(w, h); layer.w = w; layer.h = h; }
  layer.x = camX - ST_MARGIN - (w - W - ST_MARGIN * 2) / 2;
  layer.y = camY - ST_MARGIN - (h - H - ST_MARGIN * 2) / 2;
  layer.cx = camX; layer.cy = camY;   /* 记住上次烘焙时的相机位置，而不是画布原点 */
  const target = layer.cv.getContext('2d');
  target.setTransform(1, 0, 0, 1, 0, 0);
  /* 每次烘焙前把会"粘在画布上"的状态复位。setTransform 不管裁切区，
     而裁切区一旦在上一轮烘焙里被漏掉一次 restore，就会一直留在这张画布上，
     之后每次重烘都被那块矩形裁掉 —— 表现就是"某些墙/掩体突然画不出来"。
     真正兜底的是下面的 try/catch：烘焙中途抛异常就直接作废这张画布。 */
  target.globalAlpha = 1;
  target.globalCompositeOperation = 'source-over';
  target.clearRect(0, 0, w, h);
  try {
    withDrawCtx(target, function(){
      ctx.translate(-layer.x, -layer.y);
      drawFn(layer);
    });
    target.globalAlpha = 1;
    target.globalCompositeOperation = 'source-over';
  } catch (err){ /* 烘焙失败多半是某个绘制分支在 ctx.save() 之后抛了异常，裁切区没恢复。
       这张画布已经不可信（残留裁切区/残留 canvas 状态），直接扔掉重做，
       免得后面每帧重烘都被同一个裁切区裁，看着像"整片区域的东西不见了"。 */
    if (typeof console !== 'undefined' && console.warn){
      if (!stSync._warned){ stSync._warned = true; console.warn('[静态层] 烘焙异常，已作废该画布：', err); }
    }
    layer.cv = null;
    layer.w = 0; layer.h = 0;
    layer.dirty = true;
    return false;
  }
  layer.dirty = false;
  _stDirty = false;
  return true;
}
function stBlit(layer){
  if (!layer || !layer.cv) return;
  ctx.drawImage(layer.cv, 0, 0, layer.w, layer.h, layer.x, layer.y, layer.w, layer.h);
}

/* 暗角：全屏径向渐变，只随画布尺寸和主题变。原来每帧 createRadialGradient + 全屏填，
   现在烘一次、之后每帧只贴图（贴图在哪个后端都不比逐像素算渐变贵）。 */
let _vigCv = null, _vigKey = '';
function drawVignette(){
  const c0 = TC(PAL.P7), c1 = TC(THEME_LIGHT ? PAL.P275 : PAL.P112);
  const key = W + 'x' + H + '|' + c0 + '|' + c1;
  if (!_vigCv || _vigKey !== key){
    _vigCv = stNewCanvas(W, H);
    const g = _vigCv.getContext('2d');
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.clearRect(0, 0, W, H);
    const vg = g.createRadialGradient(W/2, H/2, H*0.35, W/2, H/2, H*0.95);
    vg.addColorStop(0, c0);
    vg.addColorStop(1, c1);
    g.fillStyle = vg; g.fillRect(0, 0, W, H);
    _vigKey = key;
  }
  ctx.drawImage(_vigCv, 0, 0);
}

/* ---------------- 状态 ---------------- */
let state = 'menu';
let paused = false;
/* 高频短命对象池：活动数组仍保持原来的密集数组接口，旧逻辑和测试可以照常
   使用 length / map / push；游戏自己的生成入口只从固定池取对象。 */
const BULLET_POOL_CAPACITY = 500;
const SPARK_POOL_CAPACITY = 500;
const DAMAGE_NUMBER_POOL_CAPACITY = 256;
const POOL_TAG = Symbol('effectPool');
function pooledView(capacity){ const a = new Array(capacity); a.length = 0; return a; }
function fixedPool(capacity, factory){
  const p = { capacity:capacity, cursor:0, serial:0, items:new Array(capacity) };
  for (let i=0;i<capacity;i++){
    const o = factory();
    o.active = false;
    Object.defineProperty(o, POOL_TAG, { value:p });
    p.items[i] = o;
  }
  return p;
}
function poolTake(pool, view, otherView){
  if (view.length + (otherView ? otherView.length : 0) >= pool.capacity) return null;
  /* 正常路径只扫固定容量的槽，不创建对象，也不会让池扩容。 */
  for (let n=0;n<pool.capacity;n++){
    const i = (pool.cursor + n) % pool.capacity, o = pool.items[i];
    if (o.active) continue;
    pool.cursor = (i + 1) % pool.capacity;
    o.active = true; o.poolSerial = ++pool.serial;
    view.push(o);
    return o;
  }
  /* 兼容老测试直接写 view.length=0 / view=[]：只在池满时回收已经不在活动视图里的孤儿槽。 */
  for (let n=0;n<pool.capacity;n++){
    const i = (pool.cursor + n) % pool.capacity, o = pool.items[i];
    if (view.indexOf(o) >= 0 || (otherView && otherView.indexOf(o) >= 0)) continue;
    pool.cursor = (i + 1) % pool.capacity;
    o.active = true; o.poolSerial = ++pool.serial;
    view.push(o);
    return o;
  }
  return null;                         /* 安全上限：池满就放弃这次生成 */ if (typeof reportErr === 'function') reportErr('12-levels', err); }
function poolReleaseAt(view, index){
  const o = view[index];
  if (o && o[POOL_TAG]) o.active = false;
  const last = view.pop();
  if (index < view.length) view[index] = last;  /* swap-pop：不 splice、不搬整段数组 */
}
function poolClearView(view){
  if (!view) return;
  for (let i=0;i<view.length;i++) if (view[i] && view[i][POOL_TAG]) view[i].active = false;
  view.length = 0;
}
const BULLET_POOL = fixedPool(BULLET_POOL_CAPACITY, () => ({
  active:false, poolSerial:0, x:0, y:0, px:0, py:0, vx:0, vy:0, by:null,
  life:0, dmg:0, rocket:false, turretRocket:false, r:0, trD:0, trNext:0, trHot:0,
  landFuse:false, landX:0, landY:0, smartFuse:false, fuseOptimized:false,
  fuseTargetX:0, fuseTargetY:0, fuseTargetRef:null, fuseLookAhead:0, fuseStep:0, fuseGain:0
}));
const SPARK_POOL = fixedPool(SPARK_POOL_CAPACITY, () => ({
  active:false, poolSerial:0, x:0, y:0, ang:0, spd:0, t:0, dur:0, kind:'', size:0
}));
const DAMAGE_NUMBER_POOL = fixedPool(DAMAGE_NUMBER_POOL_CAPACITY, () => ({
  active:false, poolSerial:0, x:0, y:0, t:0, val:0, kill:false, crit:false, pop:0, txt:''
}));
/* 残骸火焰 / 黑烟 / 火星 / 屏幕灰烬：各有自己的固定池，不和战斗火花抢槽位 */
const WRECKFX_POOL_CAPACITY = 520;
const ASH_POOL_CAPACITY = 380;
const WRECKFX_POOL = fixedPool(WRECKFX_POOL_CAPACITY, () => ({
  active:false, poolSerial:0, kind:'', x:0, y:0, vx:0, vy:0, t:0, dur:0, size:0, seed:0
}));
const ASH_POOL = fixedPool(ASH_POOL_CAPACITY, () => ({
  active:false, poolSerial:0, x:0, y:0, vx:0, vy:0, t:0, dur:0, size:0, rot:0, spin:0, a:0
}));
const wreckFxs = pooledView(WRECKFX_POOL_CAPACITY);
const ashes = pooledView(ASH_POOL_CAPACITY);
let ashT = 0, ashAcc = 0;
function spawnBullet(x,y,px,py,vx,vy,by,life,dmg,rocket,r,turretRocket){
  const b = poolTake(BULLET_POOL, bullets);
  if (!b) return null;
  b.x=x; b.y=y; b.px=px; b.py=py; b.vx=vx; b.vy=vy; b.by=by;
  b.life=life; b.dmg=dmg; b.rocket=!!rocket; b.turretRocket=!!turretRocket; b.r=r||0;
  b.trD=0; b.trNext=0; b.trHot=0;
  /* 池对象会复用：普通子弹和玩家直射火箭不能继承上一发敌军火箭的落点引信。 */
  b.landFuse=false; b.landX=0; b.landY=0;
  b.smartFuse=false; b.fuseOptimized=false;
  b.fuseTargetX=0; b.fuseTargetY=0; b.fuseTargetRef=null;
  b.fuseLookAhead=0; b.fuseStep=0; b.fuseGain=0;
  return b;
}
function rocketFuseTargetPoint(b){
  if(!b)return null;
  const ref=b.fuseTargetRef;
  if(ref&&!ref.dead&&(ref.hp===undefined||ref.hp>0)&&Number.isFinite(ref.x)&&Number.isFinite(ref.y))
    return {x:ref.x,y:ref.y};
  if(Number.isFinite(b.fuseTargetX)&&Number.isFinite(b.fuseTargetY))
    return {x:b.fuseTargetX,y:b.fuseTargetY};
  return null;
}
/* 智能空炸只在火箭第一次进入“爆炸能擦到目标”的那一帧运行一次。
   从擦边点沿当前飞行方向向前看一小段，用真实伤害衰减和墙体传播挑最高伤害点；
   选完立即锁住，后续帧只等火箭飞到该点，不追着移动目标反复重算。 */
function rocketSmartFusePlan(b){
  if(!b||!b.smartFuse||b.fuseOptimized)return null;
  const target=rocketFuseTargetPoint(b);
  if(!target)return null;
  const dx=b.x-b.px,dy=b.y-b.py,segLen=Math.hypot(dx,dy);
  if(segLen<1e-6)return null;
  const ux=dx/segLen,uy=dy/segLen;
  const radius=(typeof ROCKET_R==='number'?ROCKET_R:320)*
    (typeof arenaRocketRadiusK==='function'?arenaRocketRadiusK():1);
  const tx=target.x-b.px,ty=target.y-b.py;
  const along=tx*ux+ty*uy;
  const perp2=Math.max(0,tx*tx+ty*ty-along*along);
  if(perp2>radius*radius)return null;
  const half=Math.sqrt(Math.max(0,radius*radius-perp2));
  let entryD=along-half;
  if(along+half<0||entryD>segLen+1e-6)return null;
  entryD=clamp(entryD,0,segLen);
  const ex=b.px+ux*entryD,ey=b.py+uy*entryD;
  const speed=Math.hypot(b.vx,b.vy);
  const maxAhead=Math.max(0,Math.min(
    Number(b.fuseLookAhead)||radius,
    Math.max(segLen-entryD,Math.max(0,b.life||0)*speed)
  ));
  const step=Math.max(8,Number(b.fuseStep)||24);
  const scoreAt=(x,y)=>{
    const d=dist(x,y,target.x,target.y);
    if(d>radius+1e-6)return -1;
    if(typeof blastBlocked==='function'&&blastBlocked(x,y,target.x,target.y))return -1;
    const dmg=typeof rocketDmgAt==='function'?rocketDmgAt(d,radius):(1-d/radius)*100;
    const cover=typeof blastCoverFactor==='function'?blastCoverFactor(x,y,target.x,target.y):1;
    return dmg*cover;
  };
  let best={x:ex,y:ey,ahead:0,score:scoreAt(ex,ey)};
  const test=(ahead)=>{
    ahead=clamp(ahead,0,maxAhead);
    const x=ex+ux*ahead,y=ey+uy*ahead;
    /* 未来弹道中间已有实体墙时不能把墙后的理论高分当成有效空炸点。 */
    if(ahead>1&&typeof losBlocked==='function'&&losBlocked(ex,ey,x,y))return false;
    const score=scoreAt(x,y);
    if(score>best.score+1e-6)best={x:x,y:y,ahead:ahead,score:score};
    return true;
  };
  for(let a=step;a<=maxAhead+1e-6;a+=step)if(!test(a))break;
  /* 把几何最近点也单独测一次，避免采样步长恰好跨过真正峰值。 */
  test(along-entryD);
  if(best.score<0)return null;
  return {entryX:ex,entryY:ey,entryD:entryD,entryScore:scoreAt(ex,ey),
          bestX:best.x,bestY:best.y,bestAhead:best.ahead,bestScore:best.score,segLen:segLen};
}
/* 计算这一帧的弹道线段是否跨过预先解算的爆炸落点。
   返回精确落点和它在本帧线段上的距离，供人体命中与最终引爆共用。 */
function rocketLandingFusePoint(b){
  if(!b||!b.rocket||!b.landFuse||!Number.isFinite(b.landX)||!Number.isFinite(b.landY))return null;
  if(b.smartFuse&&!b.fuseOptimized){
    const plan=rocketSmartFusePlan(b);
    if(plan){
      b.fuseOptimized=true;
      const gain=Math.max(0,Number(b.fuseGain)||0);
      if(plan.bestAhead>2&&plan.bestScore>plan.entryScore+gain){
        b.landX=plan.bestX;b.landY=plan.bestY;
        /* 峰值已经位于本帧扫过的线段里，直接在精确点引爆；否则让弹体继续飞。 */
        if(plan.entryD+plan.bestAhead<=plan.segLen+1e-6)
          return {x:plan.bestX,y:plan.bestY,t:clamp((plan.entryD+plan.bestAhead)/plan.segLen,0,1),
                  d:plan.entryD+plan.bestAhead};
        return null;
      }
      return {x:plan.entryX,y:plan.entryY,t:clamp(plan.entryD/plan.segLen,0,1),d:plan.entryD};
    }
  }
  const dx=b.x-b.px,dy=b.y-b.py,n=dx*dx+dy*dy;
  if(n<1e-8)return null;
  const t=((b.landX-b.px)*dx+(b.landY-b.py)*dy)/n;
  if(t<-1e-6||t>1.000001)return null;
  const hx=b.px+dx*t,hy=b.py+dy*t;
  /* 浮点误差或极低帧率都不能让火箭从落点旁边穿过去。 */
  if(dist(hx,hy,b.landX,b.landY)>Math.max(2,b.r||0))return null;
  return {x:b.landX,y:b.landY,t:clamp(t,0,1),d:Math.sqrt(n)*clamp(t,0,1)};
}
let player, grenades, smokes, nades = [], nadeShards = [], enemies, loots, bullets = pooledView(BULLET_POOL_CAPACITY), camShake, timeAlive, msg, msgT, hitFlash;
/* 全队投雷节奏：距离上一次"有人开始掏雷"还要等多少秒。避免四个人同一帧一起掏雷 */
let nadeSquadCd = 0;
/* 信号枪：天上飞的信号弹 / 等着倒计时的落点 / 正在下降的空投 */
let flares = [], airDrops = [], signalSpots = [];
let concealed = false, concealLeft = 0;
let mouse = {x: W/2, y: H/2, down:false};
/* 望远镜放大时，画面绕【自己的屏幕位置】放大 binoZoomK() 倍（见 44-sfxcombat 里的世界变换）：
   鼠标的屏幕坐标必须按同一倍率、同一个锚点反算回世界，否则准星、枪口、光锥会各指一个方向。 */
function binoAnchorX(){ return player ? (player.x - cam.x) : W/2; }
function binoAnchorY(){ return player ? (player.y - cam.y) : H/2; }
function mouseWorldX(){ const z = binoZoomK(); const a = binoAnchorX(); return (Math.abs(z - 1) > 0.001 ? (mouse.x - a)/z + a : mouse.x) + cam.x; }
function mouseWorldY(){ const z = binoZoomK(); const a = binoAnchorY(); return (Math.abs(z - 1) > 0.001 ? (mouse.y - a)/z + a : mouse.y) + cam.y; }
let hbT = 0;
let hbPulse = 0;
let uiT = 0;          /* 界面动画时钟：不受暂停/结算冻结影响 */
let runTimes = [];    /* 每关各自的用时，结算的"总用时"用这个加 */
let mapOpen = false;
let mapView = null;      /* drawMap 算出来的屏幕→世界映射，点地图瞬移要用 */
let uiButtons = [];
let confirmBack = false;
/* 关卡扩开的视野（只影响 rules 里写了值的关） */
/* 瞭望塔（第 65 轮）：人站在塔上时视距 ×T.visionK、视角 ×T.fovK（见 game/31-watchtower.js）。
   乘在这里而不是改 CFG —— CFG 是全局设置，改了会连 HUD、别的角色一起变。 */
function seeRange(L){
  const base = Math.max(pVisionNow(), (L && L.rules && L.rules.playerVision) || 0);
  /* m21653：大雾雷暴会大幅缩短视距（weatherSeeK 由 game/16-frag.js 提供） */
  const _wsk = (typeof weatherSeeK === 'function') ? weatherSeeK() : 1;
  return base * ((typeof towerVisionK === 'function') ? towerVisionK() : 1) * _wsk;
}
/* 敌人的视野半角（度）：先看关卡规则，没有就按兵种 fov，再乘关卡缩放。
   enemyFovK 是"整体收窄"用的：死亡地带这种大地图，116° 的半角等于背后也能看见你一半。 */
function enemyFovHalf(e, T){
  const L = cur();
  const R = (L && L.rules) || {};
  const base=R.enemyFov || (T.fov || 58) * (R.enemyFovK || 1);
  return e?.towerOn ? base*TOWER_AI.fovK : base;
}
function enemyVisionRange(e,target=player){
  /* 敌人的视距走 CFG.eVision（难度表里的那一列），不是玩家的 pVision。
     以前这里用 seeRange(cur()) = 玩家视距：简单给到 460、噩梦只有 300，
     于是"简单难度敌人看得比噩梦还远"（m35918）。eVision 那一列之前完全没人读。 */
  const T = enemyType(e) || {};
  const L = cur();
  const lvl = (L && L.rules && L.rules.enemyVision) || 0;
  const ev = isFinite(CFG.eVision) ? CFG.eVision : seeRange(L);   /* 没设过就用旧行为兜底 */
  const base = Math.max(ev * (T.visionMul || 1), lvl);
  /* 敌人站上瞭望塔：视距加成（玩家那套在 seeRange 里乘 towerVisionK，AI 走这里） */
  const towerK = (e && e.towerOn && typeof TOWER_AI !== 'undefined' && TOWER_AI.boostK) ? TOWER_AI.boostK : 1;
  /* m46193：上帝模式下玩家只是"观察者"，不该影响敌人 —— 蹲下不再缩短敌人的视距，
     画出来的视野锥也保持原长（否则玩家一蹲就看见锥体缩一截，像在干预 AI）。 */
  /* 观察者身份一律不算"蹲"：上帝模式 / 开发者无敌 / 斗蛐蛐观战图（玩家只是摄像机）。
     否则在观战里按 Shift 挪镜头，敌人的视野锥会跟着缩，看着像玩家在干预 AI。 */
  const _god = (target === player) && (
    (typeof godOn === 'function' && godOn()) || player.god === true ||
    (typeof spectatorViewOn === 'function' && spectatorViewOn()));
  /* m21653：雾里敌人也看不见那么远 —— 和玩家用同一个倍率 */
  const _wsk2 = (typeof weatherSeeK === 'function') ? weatherSeeK() : 1;
  return base * towerK * _wsk2 * ((target && target.crouch && !T.crouchBlind && !_god) ? CROUCH_SEE : 1);
}
function seeFov(L){
  const base = Math.max(CFG.pFov, (L && L.rules && L.rules.playerFov) || 0);
  return base * ((typeof towerFovK === 'function') ? towerFovK() : 1);   /* 上瞭望塔：视角收窄，见 game/31-watchtower.js */
}
/* 霰弹枪拉枪膀要多久（听感上对得上 pump 音效） */
const SHELL_PUMP_T = 0.85;

const CROUCH_SEE = 0.78;   /* 蹲下时被看见的距离倍率：只缩两成，不是隐身 */      /* Esc 回大厅的二次确认 */
let stepRipples = [];
let enemySteps = [];   /* 第三关：敌人的脚步「声纹」 */
let hoverBtn = null;

/* ---------------- 第四关：猎手 ---------------- */
let boss = null;
let hunters = [];
let caughtT = 0, caughtZoom = 1, caughtFx = 0, caughtFocus = {x:0,y:0}, caughtHunter = null;
/* 死亡定格：所有敌人显形，看清自己是怎么死的，按任意键才进结算 */
let revealAll = false, deadT = 0, dyingT = 0;
/* 死亡回放：每帧记一份快照，只留最后 5 秒 */
const REC_HZ = 20, REC_SECS = 5, REC_KEEP = REC_HZ*REC_SECS + 1;
let recBuf = [], recAcc = 0, replayT = 0;
/* 胜利回放：整局录制（10Hz），上帝视角看全程 */
const VREC_HZ = 10, VREC_MAX = VREC_HZ * 900;
let vrecBuf = [], vrecAcc = 0;
let gT = 0, gPlaying = true, gZoom = 0.5, gCam = {x:0, y:0}, gXray = true, gAutoCam = true, gDrag = null, gBack = 'win';

function recSnapshot(){
  recBuf.push({
    px:player.x, py:player.y, aim:player.aim||0, hp:player.hp,
    en: enemies.map(e=>({x:e.x, y:e.y, a:e.ang||0, m:e.mode, s:!!e.sees})),
    hu: hunters.map(h=>({x:h.x, y:h.y, a:h.ang||0, m:h.state, s:!!h.sees})),
    bu: bullets.map(b=>({x:b.x, y:b.y})),
    sm: smokes.map(k=>({x:k.x, y:k.y, r:k.r*Math.min(1, k.age/0.5)})),
    lk: loots.map(l=>({x:l.x, y:l.y, t:!!l.taken}))
  });
  if (recBuf.length > REC_KEEP) recBuf.shift();
}
let switches = [], swDone = 0, exitOpen = false, bossExposed = false;
let hbProx = 0, exitArrowT = 0, runBannerT = 0, intro = null;
let runT = 0, sirenSrc = null, sirenSynth = [];
/* 离线冲刺：你看不见他的时候，他才会跑起来抄近路 */
let bossBoostLeft = 12, bossBoostWho = null;
let bossPVX = 0, bossPVY = 0, bossPrevX = null, bossPrevY = null;
const introSeen = {};
const POUNCE_MS = {easy:500, normal:350, hard:250, nightmare:190};
/* 扑击：起跳距离 / 扑出去多远 / 判定命中的半径（三个数一起调手感） */
const POUNCE_RANGE = 185, POUNCE_REACH = 135, POUNCE_GRAB = 70;
const LUNGE_DUR = 0.16;   /* 扑出去那一下用多少秒，太快就变成瞬移 */
const wasteland = () => !!(LEVELS[levelIdx] && LEVELS[levelIdx].boss);
const clearedLv = {};

/* 把一个点推到墙外（地图改过后防止出生/物资点正好压在墙上） */
/* 同伴只喊了个大概方位时用的模糊点：必须在玩家能直着走到的范围里，
   否则会把点甩到墙那边（人机会绕到房子外面去，永远进不了门）。 */
function roughSpot(L, x, y, r){
  for (let i = 0; i < 10; i++){
    const a = rand(0, Math.PI * 2), d = rand(r * 0.35, r);
    const px = x + Math.cos(a) * d, py = y + Math.sin(a) * d;
    if (px < 30 || py < 30 || px > L.w - 30 || py > L.h - 30) continue;
    if (!clearWalkLine(L, x, y, px, py)) continue;
    return { x: px, y: py };
  }
  return { x: x, y: y };
}

function safeSpot(L, p, pad){
  pad = pad || 24;
  const inW = (x,y)=> collisionWalls(L,x,y,pad).some(w=> x > w.x-pad && x < w.x+w.w+pad && y > w.y-pad && y < w.y+w.h+pad);
  if (!inW(p.x,p.y)) return p;
  /* 原来是 260px 的环搜，第一个不压墙的点就收工：在屋里听见脚步时，
     这个点经常被穿过墙挪到房子外面去（人机于是去绕房子，永远不进门）。
     现在只找 96px 以内，并且优先挑一条视线能走到的点（不穿墙）。 */
  let fallback = null;
  for (let r=12; r<=96; r+=12){
    for (let a=0; a<16; a++){
      const ang = a*Math.PI/8;
      const x = p.x + Math.cos(ang)*r, y = p.y + Math.sin(ang)*r;
      if (x < 30 || y < 30 || x > L.w-30 || y > L.h-30) continue;
      if (inW(x,y)) continue;
      const cand = {x:Math.round(x), y:Math.round(y), wp:p.wp};
      if (!fallback) fallback = cand;
      if (clearWalkLine(L, p.x, p.y, x, y)) return cand;
    }
  }
  return fallback || p;
}

/* ============================================================
   房间登记（关卡侧）：谁盖房子谁登记
   ------------------------------------------------------------
   L.rooms 的语义是"屋内空间"，被这些地方用着：
     levelRoomAt（AI 判断是否同屋）、nadeRoomOK（跨房手雷）、
     roomSearchTick（进屋搜查）、屋顶淡出与室内压暗。
   所以"登记"必须发生在**知道这是一间房**的地方，而不是在最底层给每堵墙登记
   —— 矮墙、走廊、院墙都不是房间。

   · 坐标一律取「内空区」（墙内侧），贴墙的站位才不会被判成在屋外；
   · 现场盖房的人（房间模板 placeRooms、手写大屋）调 roomAdd 登记；
   · 去重靠 _roomKeys，重复登记（生成器重入、改建）不会长出两份；
   · 200px 网格索引 L.roomGrid：大图上"每帧每敌一次"的查询只扫桶+邻桶，
     线性遍历在 40 间房 × 88 个敌人时是每帧几千次矩形判断；
   · 房间边界变了（拆墙改建、重新生成）就 roomsInvalidate(L)，别指望索引永久有效。
   ============================================================ */
const ROOM_GRID = 200;

function roomsInit(L){
  if (!L) return null;
  if (!L.rooms) L.rooms = [];
  /* 编辑器、读档和测试都会整份替换 rooms。去重表若仍指向旧数组，
     autoRoomsFor 会“检测成功但添加为 0”，室内搜索随后完全不启动。 */
  if (!L._roomKeys || L._roomKeysRef !== L.rooms){
    L._roomKeys = new Set(L.rooms.filter(Boolean).map(roomKeyOf));
    L._roomKeysRef = L.rooms;
  }
  return L.rooms;
}

function roomKeyOf(r){
  return (r.x | 0) + ',' + (r.y | 0) + ',' + (r.w | 0) + ',' + (r.h | 0) + ',' + (r.name || '');
}

/* 登记一间房：w/h 至少 8px，坐标取整；同名同位置的重复登记直接忽略 */
function roomAdd(L, r){
  if (!L || !r) return null;
  if (![r.x, r.y, r.w, r.h].every(Number.isFinite)) return null;
  roomsInit(L);
  const one = {
    x: Math.round(r.x), y: Math.round(r.y),
    w: Math.max(8, Math.round(r.w)), h: Math.max(8, Math.round(r.h)),
    name: r.name || '房间'
  };
  if (r.building !== undefined) one.building = r.building;
  if (r.fallback) one.fallback = true;
  if (r.template) one.template = r.template;
  if (r.locked) one.locked = true;
  const k = roomKeyOf(one);
  if (L._roomKeys.has(k)) return one;
  L._roomKeys.add(k);
  L.rooms.push(one);
  L.roomGrid = null;                 /* 索引失效，下次查询时重建 */
  return one;
}

/* 房间边界变了（拆墙、改建、重新生成）就喊一声 */
function roomsInvalidate(L){
  if (L){ L.roomGrid = null; L._roomGridRef = null; }
}

function roomGridBuild(L){
  const g = new Map();
  const rooms = (L && L.rooms) || [];
  for (let i = 0; i < rooms.length; i++){
    const r = rooms[i];
    if (!r) continue;
    const x0 = Math.floor(r.x / ROOM_GRID), x1 = Math.floor((r.x + r.w) / ROOM_GRID);
    const y0 = Math.floor(r.y / ROOM_GRID), y1 = Math.floor((r.y + r.h) / ROOM_GRID);
    for (let gx = x0; gx <= x1; gx++){
      for (let gy = y0; gy <= y1; gy++){
        const k = gx + ',' + gy;
        let b = g.get(k);
        if (!b){ b = []; g.set(k, b); }
        b.push(r);
      }
    }
  }
  L.roomGrid = g;
  L._roomGridRef = L.rooms;      /* 记下这份索引对应哪个数组：有人直接换掉 L.rooms 时自动重建 */
  return g;
}

/* 跟 levelRoomAt 同语义：命中就返回；多间重叠时优先非 fallback 的 */
function roomAtFast(L, x, y){
  if (!L || !L.rooms || !L.rooms.length) return null;
  /* 懒建 + 自检：登记/平移/失效之后第一次查询才真正扫一遍；
     L.rooms 被整个换掉（测试/编辑器改图）也认得出，避免拿到过期索引 */
  if (!L.roomGrid || L._roomGridRef !== L.rooms) roomGridBuild(L);
  const list = L.roomGrid.get(Math.floor(x / ROOM_GRID) + ',' + Math.floor(y / ROOM_GRID)) || null;
  /* 桶里有哪几间房就只判那几间：房间登记时会写进它覆盖的每一个桶，
     所以"这个桶里没有房间"就等于"这个点不在任何房间里"，可以直接返回。
     （早先这里在桶为空时退回全量线性扫，结果大图上大部分采样点都是空地，
     反而比线性还慢一倍。） */
  let fallback = null;
  for (const r of (list || [])){
    if (!r || !roomHasPoint(r, x, y)) continue;
    if (!r.fallback) return r;
    fallback = r;
  }
  return fallback;
}
