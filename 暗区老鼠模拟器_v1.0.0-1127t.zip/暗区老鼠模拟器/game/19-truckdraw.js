function drawRocketTurret(w){
  const D=ROCKET_TURRET_DEF, h=D.baseHalf;
  const x=w.x+h,y=w.y+h,dead=!!w.wreck,low=w.hp/w.maxHp<D.lowHealthRatio;
  /* 八边形底座：和地图里铁皮同色系（PAL 冷灰蓝），不再用偏绿的灰 */
  const oct=(r)=>{ctx.beginPath();for(let i=0;i<8;i++){const a=Math.PI/8+i*Math.PI/4,px=Math.cos(a)*r,py=Math.sin(a)*r;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.closePath();};
  /* m45600：红外指示线 —— 炮塔真的看得见你时，才从炮口射出一条细红线。
     它的意义不是伤害，而是"我知道了"：线扫到你身上 = 你暴露了。 */
  if(!dead && (w.irK||0)>0.02 && (w.irLen||0)>40){
    const _mz=h*0.92;
    const _bx=x+Math.cos(w.ang)*_mz, _by=y+Math.sin(w.ang)*_mz;
    const _ex=_bx+Math.cos(w.ang)*w.irLen, _ey=_by+Math.sin(w.ang)*w.irLen;
    const _a=0.55*(w.irK||0);
    const _lg=ctx.createLinearGradient(_bx,_by,_ex,_ey);
    _lg.addColorStop(0,'rgba(255,60,60,0)');
    _lg.addColorStop(0.25,'rgba(255,72,72,'+(_a*0.55).toFixed(3)+')');
    _lg.addColorStop(1,'rgba(255,86,86,'+_a.toFixed(3)+')');
    ctx.save();
    /* 压迫感三件套：外层光晕（粗、暗、呼吸）+ 芯线（细、亮）+ 端点大点 */
    const _pulse = 0.72 + 0.28*Math.sin((typeof uiT==='number'?uiT:0)*9);
    const _fl = (w.irFlash||0) > 0 ? (w.irFlash/0.34) : 0;
    ctx.strokeStyle='rgba(255,40,40,'+(_a*0.30*_pulse+_fl*0.25).toFixed(3)+')';
    ctx.lineWidth=5.2+_fl*3.0;
    ctx.beginPath();ctx.moveTo(_bx,_by);ctx.lineTo(_ex,_ey);ctx.stroke();
    ctx.strokeStyle=_lg;ctx.lineWidth=1.4+_fl*0.8;
    ctx.beginPath();ctx.moveTo(_bx,_by);ctx.lineTo(_ex,_ey);ctx.stroke();
    ctx.fillStyle='rgba(255,96,96,'+(_a*0.95).toFixed(3)+')';
    ctx.beginPath();ctx.arc(_ex,_ey,3.0+_fl*2.4,0,TAU);ctx.fill();
    if(_fl>0){ctx.strokeStyle='rgba(255,90,90,'+(_fl*0.85).toFixed(3)+')';ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(_ex,_ey,9+22*(1-_fl),0,TAU);ctx.stroke();}
    ctx.restore();
  }
  ctx.save();ctx.translate(x,y);
  ctx.fillStyle='rgba(0,0,0,.42)';ctx.beginPath();ctx.ellipse(4,9,32,24,0,0,TAU);ctx.fill();

  /* ---- 底座 ---- */
  oct(34);
  const bg=ctx.createLinearGradient(-28,-30,26,30);
  bg.addColorStop(0,   dead?'#272e33':'#3b4856');
  bg.addColorStop(.55, dead?'#1d2327':'#2a3540');
  bg.addColorStop(1,   dead?'#141a1d':'#1b242e');
  ctx.fillStyle=bg;ctx.fill();
  /* 本体阵营染色：光靠底座那圈线太细，远看还是两坨一样的铁灰色。
     确认过是「炮塔/棱堡」这类建筑，就按势力把底座和转塔都往阵营色里带一点。 */
  if (!dead && w.factionTint && typeof mixHex === 'function'){
    ctx.save();
    ctx.globalAlpha = 0.30;
    ctx.fillStyle = mixHex(w.factionTint, '#2a3540', 0.45);
    oct(34); ctx.fill();
    ctx.restore();
  }
  /* 活着的时候轮廓直接用阵营色：这是整个炮塔最容易一眼认出的边，
     比底座里面那层淡色 overlay 有效得多（远看/夜里都成立） */
  if (!dead && w.factionTint && typeof factionLook === 'function'){
    const _lk0 = factionLook(w.faction);
    ctx.strokeStyle = (_lk0 && _lk0.arc) || w.factionTint;
    ctx.lineWidth = 2.6;
    ctx.setLineDash(_lk0 && _lk0.mark === 'ring' ? [7.0, 4.4] : []);
  } else {
    ctx.strokeStyle=PAL.P6;ctx.lineWidth=2;
  }
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.strokeStyle='rgba(150,175,195,'+(dead?.10:.18)+')';ctx.lineWidth=1.2;oct(27.5);ctx.stroke();
  for(let i=0;i<4;i++){
    const a=Math.PI/4+i*Math.PI/2,bx=Math.cos(a)*29.5,by=Math.sin(a)*29.5;
    ctx.fillStyle='#0c1114';ctx.beginPath();ctx.arc(bx,by,3.1,0,TAU);ctx.fill();
    ctx.fillStyle='rgba(168,192,210,'+(dead?.16:.38)+')';ctx.beginPath();ctx.arc(bx-1,by-1,1.2,0,TAU);ctx.fill();
  }

  /* ---- 阵营圈：A 势力实线 / B 势力虚线（数据见 data/factionlook.js）----
     以前两家的炮塔都是同一套冷灰蓝，同为"铁疙瘩"根本分不出谁是谁 */
  if (!dead && w.factionTint){
    const _lk = (typeof factionLook === 'function') ? factionLook(w.faction) : null;
    ctx.save();
    ctx.globalAlpha = 0.85;
    ctx.strokeStyle = (_lk && _lk.arc) || w.factionTint;
    ctx.lineWidth = 2.6;
    if (_lk && _lk.mark === 'ring') ctx.setLineDash([6.5, 4.2]);
    oct(31.5); ctx.stroke();
    ctx.restore();
  }

  /* ---- 转塔（活着时朝玩家，废了以后歪着） ---- */
  ctx.save();ctx.rotate(w.ang+(dead?.24:0));ctx.translate(-turretRecoil(w),0);
  ctx.fillStyle=dead?'#1a2126':PAL.P23;ctx.beginPath();ctx.arc(0,0,21,0,TAU);ctx.fill();
  ctx.strokeStyle=dead?'rgba(120,140,150,.14)':'rgba(150,175,195,.42)';ctx.lineWidth=1.6;ctx.stroke();
  ctx.strokeStyle='rgba(190,214,232,'+(dead?.05:.10)+')';ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,15,0,TAU);ctx.stroke();

  /* 机匣 */
  roundRect(-27,-13,18,26,4);ctx.fillStyle=dead?'#171d21':PAL.P22;ctx.fill();
  ctx.strokeStyle=PAL.P6;ctx.lineWidth=1.4;ctx.stroke();

  /* 一根粗炮管：上亮下暗的圆柱明暗 + 椭圆炮口 + 底部投影，做出「有厚度」的伪 3D
     不用真 3D，靠三件事骗眼睛：① 靠上的面比靠下的面亮 ② 炮口是个椭圆不是圆 ③ 管子底下有一条自己的影子 */
  const barGrad=ctx.createLinearGradient(0,-11,0,11);
  barGrad.addColorStop(0,   dead?'#4a555d':'#9fb2c0');
  barGrad.addColorStop(.30, dead?'#3a444b':'#7b8e9c');
  barGrad.addColorStop(.58, dead?'#252d33':'#3b4a57');
  barGrad.addColorStop(1,   dead?'#151b20':'#1b242e');
  if(!dead){
    /* 炮盾：和塔座连着的那段，短而粗 */
    roundRect(-24,-15,26,30,6);ctx.fillStyle=barGrad;ctx.fill();
    ctx.strokeStyle=PAL.P6;ctx.lineWidth=1.5;ctx.stroke();
    ctx.fillStyle='rgba(10,14,18,.5)';roundRect(-21,-5.5,12,11,2);ctx.fill();
    ctx.strokeStyle='rgba(150,175,195,.14)';ctx.lineWidth=1;ctx.stroke();

    /* 炮管本体：越往前越细一点，像真的有个锥度 */
    ctx.beginPath();
    ctx.moveTo(-2,-12.0); ctx.lineTo(46,-7.6); ctx.lineTo(54,-6.0);
    ctx.lineTo(54,6.0);  ctx.lineTo(46,7.6);  ctx.lineTo(-2,12.0);
    ctx.closePath();
    ctx.fillStyle=barGrad;ctx.fill();
    ctx.strokeStyle=PAL.P6;ctx.lineWidth=1.4;ctx.stroke();

    /* 顶面高光：这条亮边就是「圆柱的上面」 */
    ctx.strokeStyle='rgba(208,232,250,.34)';ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(-1,-9.6);ctx.lineTo(45,-5.9);ctx.stroke();
    /* 底面暗边 + 管子自己的影子 */
    ctx.strokeStyle='rgba(6,10,14,.6)';ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(-1,10.4);ctx.lineTo(45,6.5);ctx.stroke();
    ctx.strokeStyle='rgba(0,0,0,.32)';ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(0,14.0);ctx.lineTo(48,9.4);ctx.stroke();

    /* 炮口：椭圆的环 + 黑洞（椭圆是关键，圆的就像纸片） */
    ctx.save();ctx.translate(53,0);
    const mz=ctx.createLinearGradient(-5,-8,5,8);
    mz.addColorStop(0,'#bcccd9');mz.addColorStop(.45,'#66798a');mz.addColorStop(1,'#1d272f');
    ctx.fillStyle=mz;ctx.beginPath();ctx.ellipse(0,0,6.2,10.4,0,0,TAU);ctx.fill();
    ctx.strokeStyle=PAL.P6;ctx.lineWidth=1.2;ctx.stroke();
    ctx.fillStyle='#05090c';ctx.beginPath();ctx.ellipse(1.4,0,3.7,6.8,0,0,TAU);ctx.fill();
    ctx.strokeStyle='rgba(196,222,242,.42)';ctx.lineWidth=1.2;
    ctx.beginPath();ctx.ellipse(0,0,6.2,10.4,0,Math.PI*0.60,Math.PI*1.40);ctx.stroke();
    ctx.restore();

    /* 制退器两道槽 + 一节套箍 */
    ctx.strokeStyle='rgba(8,12,16,.78)';ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(36,-7.2);ctx.lineTo(36,7.2);ctx.stroke();
    ctx.beginPath();ctx.moveTo(44,-6.2);ctx.lineTo(44,6.2);ctx.stroke();
    roundRect(10,-9.5,12,19,2);ctx.fillStyle='rgba(126,150,172,.16)';ctx.fill();
    ctx.strokeStyle='rgba(8,12,16,.6)';ctx.lineWidth=1;ctx.stroke();
  } else {
    /* 废了：炮盾还在，炮管从中间炸断，前面那截垂下去 */
    roundRect(-22,-13,24,26,5);ctx.fillStyle=barGrad;ctx.fill();
    ctx.strokeStyle=PAL.P6;ctx.lineWidth=1.5;ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-2,-9.5);ctx.lineTo(21,-7.4);ctx.lineTo(26,-5.6);
    ctx.lineTo(26,5.6);ctx.lineTo(21,7.4);ctx.lineTo(-2,9.5);
    ctx.closePath();
    ctx.fillStyle=barGrad;ctx.fill();ctx.strokeStyle=PAL.P6;ctx.lineWidth=1.4;ctx.stroke();
    /* 断口：锯齿边 + 一点烧红的金属 */
    ctx.fillStyle='#0a0f13';
    ctx.beginPath();ctx.moveTo(26,-5.6);ctx.lineTo(22,-2.2);ctx.lineTo(27,0.4);ctx.lineTo(22,3.4);ctx.lineTo(26,5.6);ctx.lineTo(31,0);ctx.closePath();ctx.fill();
    ctx.fillStyle='rgba(150,44,34,.45)';ctx.beginPath();ctx.arc(24.5,0.8,2.1,0,TAU);ctx.fill();
    /* 垂下去的那一截 */
    ctx.save();ctx.translate(29,1);ctx.rotate(.74);
    ctx.beginPath();
    ctx.moveTo(0,-6);ctx.lineTo(24,-4.6);ctx.lineTo(29,-3.4);
    ctx.lineTo(29,3.4);ctx.lineTo(24,4.6);ctx.lineTo(0,6);
    ctx.closePath();
    ctx.fillStyle=barGrad;ctx.fill();ctx.strokeStyle=PAL.P6;ctx.lineWidth=1.3;ctx.stroke();
    ctx.strokeStyle='rgba(208,232,250,.20)';ctx.lineWidth=1.6;
    ctx.beginPath();ctx.moveTo(1,-4.6);ctx.lineTo(23,-3.6);ctx.stroke();
    ctx.fillStyle='#05090c';ctx.beginPath();ctx.ellipse(29,0,3.6,5.2,0,0,TAU);ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  /* ---- 状态灯 / 血条 / 焦痕 ---- */
  if(dead){
    /* 断口一直在烧：两层闪的暖光（慢闪管"火还在晃"、快闪管"火苗在舔"），
       再加三颗往上飘的余烬 —— 静态截图里也能一眼看出这坨在着火 */
    const _s1=0.62+0.38*Math.sin(uiT*7.3), _s2=0.55+0.45*Math.sin(uiT*17.1+1.7);
    const _fa=0.42*_s1+0.22*_s2;
    const fg2=ctx.createRadialGradient(25,1,0,25,1,20+7*_s1);
    fg2.addColorStop(0,   'rgba(255,226,150,'+(_fa).toFixed(3)+')');
    fg2.addColorStop(0.45,'rgba(255,132,36,'+(_fa*0.55).toFixed(3)+')');
    fg2.addColorStop(1,   'rgba(120,30,8,0)');
    ctx.fillStyle=fg2;ctx.beginPath();ctx.arc(25,1,20+7*_s1,0,TAU);ctx.fill();
    for(let i=0;i<3;i++){
      const ph=(uiT*1.7+i*0.37)%1;
      const ex=25+Math.sin(uiT*3.1+i*2.0)*5*(1-ph*0.4), ey=1-ph*15-2;
      ctx.fillStyle='rgba(255,'+(190-60*ph|0)+',90,'+(0.85*(1-ph)).toFixed(3)+')';
      ctx.beginPath();ctx.arc(ex,ey,1.7*(1-ph*0.5),0,TAU);ctx.fill();
    }
    /* 焦痕只压在中间一小块，别把整个炮座糊掉 */
    ctx.fillStyle='rgba(6,9,11,.30)';ctx.beginPath();ctx.ellipse(-6,4,15,10,.4,0,TAU);ctx.fill();
    ctx.strokeStyle='rgba(10,14,17,.7)';ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(-18,-12);ctx.lineTo(-3,5);ctx.lineTo(11,11);ctx.stroke();
    /* 崩下来的两片装甲 */
    /* 崩下来的一小块装甲，压在底座边上 */
    ctx.fillStyle='#1b2328';
    ctx.beginPath();ctx.moveTo(-33,20);ctx.lineTo(-23,30);ctx.lineTo(-35,31);ctx.closePath();ctx.fill();
    ctx.strokeStyle='rgba(120,140,150,.16)';ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(-33,20);ctx.lineTo(-23,30);ctx.stroke();
  } else {
    const lamp=low?(Math.sin(uiT*11)>0?PAL.P12:'#5d1d17'):PAL.P1;
    ctx.fillStyle=lamp;ctx.fillRect(-30,18,7,5);
    ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(-30,18,7,1);
    if(w.hitT>0){ctx.fillStyle='rgba(255,214,150,.26)';oct(34);ctx.fill();}
    if(w.hp<w.maxHp){
      ctx.fillStyle='rgba(8,12,16,.9)';ctx.fillRect(-32,-49,64,5);
      ctx.fillStyle=low?PAL.P12:'#7ea88f';ctx.fillRect(-32,-49,64*w.hp/w.maxHp,5);
      ctx.strokeStyle='rgba(0,0,0,.6)';ctx.lineWidth=1;ctx.strokeRect(-32.5,-49.5,65,6);
    }
  }
  ctx.restore();
}

/* 投放面板：分组 + 组内条目。
   27 项挤成一屏会变成一堵墙，所以按组折叠：←/→ 或点标签切组，组内最多 7 项，数字键选。 */
const DEV_SPAWN_GROUPS = [
  { key: 'veh', name: '车辆', items: [
    { k: 'truck',      fac: 'enemy',  name: '[A] 运兵车（放兵 · 会开走）' },
    { k: 'truckApc',   fac: 'enemy',  name: '[A] 装甲运兵车（厚 · 放 3 职业兵）' },
    { k: 'truckPickup',fac: 'enemy',  name: '[A] 武装皮卡（快 · 脆 · 放 2 人）' },
    { k: 'truckBandit',fac: 'bandit', name: '[B] 运兵车（下来的是 B 势力）' },
    { k: 'truckPark',  fac: 'neutral',name: '停着的运兵车（中立 · 不动 · 不放兵）' },
    { k: 'truckApcPark',   fac: 'neutral', name: '停着的装甲车（只看外观）' },
    { k: 'truckPickupPark',fac: 'neutral', name: '停着的皮卡（只看外观）' },
    { k: 'truckCivilPark', fac: 'neutral', name: '绿色民用皮卡（无机枪 · 可开走）' },
    { k: 'truckCivil',     fac: 'neutral', name: '绿色民用皮卡（开进场 · 不会放兵）' }
  ]},
  { key: 'man', name: '人形', items: [
    { k: 'grunt',     name: '普通人机（跟随你的阵营）' },
    { k: 'sentinel',  name: '哨兵（站桩）' },
    { k: 'hunter',    name: '猎手' },
    { k: 'guard',     name: '守卫' },
    { k: 'grenadier', name: '掷弹兵（会扔雷）' },
    { k: 'spec',      name: '职业兵（三级甲 · 扔烟）' },
    { k: 'rocketman', name: '火箭筒兵' }
  ]},
  { key: 'search', name: '搜索', items: [
    { k: 'searchCareless', name: '普通兵 · 粗心搜索' },
    { k: 'searchCareful',  name: '职业兵 · 仔细搜索' }
  ]},
  { key: 'melee', name: '近战', items: [
    { k: 'bladeKnife', name: '刀手 · 小刀' },
    { k: 'bladeDao',   name: '刀手 · 弯刀' }
  ]},
  { key: 'boss', name: 'BOSS', items: [
    { k: 'bossCharger', name: '疯狗（自爆）' },
    { k: 'bossWarlord', name: '督军（冲锋）' },
    { k: 'bossShield',  name: '盾卫（举盾）' },
    { k: 'bossSpawner', name: '巢母（召唤）' }
  ]},
  { key: 'gear', name: '阵地', items: [
    { k: 'mgnest',      name: '重机枪阵地（可占领）' },
    { k: 'rocketTurret',name: '火箭炮塔' },
  { k: 'mgSentry',name: '机枪棱堡' },
    { k: 'dummy',       name: '假人（不动 · 打不死）' },
    { k: 'dummyArmor',  name: '假人 · 穿三级甲' }
  ]},
  { key: 'misc', name: '功能', items: [
    { k: 'flankPair',     name: '协同精英小队（2 人）' },
    { k: 'banditSquad', fac: 'bandit', name: '[B] 行军小队（5 人 · 固定 B 势力）' },
    { k: 'companion',     name: '派一个职业兵队友' },
    { k: 'playerFaction', name: '切换玩家阵营（玩家 → A → B → 中立）' },
    { k: 'devFreeze',     name: '开发者暂停（世界静止 · 只你能动）' }
  ]}
];
/* 扁平表：老代码/测试还按这个找条目，顺序就是面板顺序 */
const DEV_SPAWN_LIST = DEV_SPAWN_GROUPS.reduce((a, g) => a.concat(g.items), []);
let devGroupIx = 0;
let devPlaceKind = null;        /* 非空 = 放置模式：点地图放一个 */
let devPlaceFac = null;         /* 放置模式下这次投放的势力（null = 跟随玩家） */
let devPlaceAng = 0;            /* 放置模式下这次投放的朝向（弧度）；m43322：[ ] 可转 */

/* 投放的兵跟随玩家当前阵营：加入 A → A；加入 B → B；中立 → 中立；
   玩家自己（没加入任何势力）→ 老规矩，投的是 A 势力。 */
function devFactionTint(f){
  if (f === 'bandit') return '#7fbf6a';
  if (f === 'neutral') return '#9aa4ae';
  return '#6d8fb8';
}
function devSpawnFaction(){
  if (typeof playerFactionId !== 'function') return 'enemy';
  const f = playerFactionId();
  if (f === 'bandit') return 'bandit';
  if (f === 'neutral') return 'neutral';
  return 'enemy';
}
/* 开发者暂停：世界静止，只有玩家和玩家自己的子弹照常走 */
function devFrozen(){ return !!(CFG.dev && CFG.devFreeze && state === 'play'); }
/* 暂停档位：1 = 世界静止（别人不动、玩家能走、音效全停）
   2 = 再加一条：玩家自己打出去的子弹也冻住
   按 P 循环 0 → 1 → 2 → 0（用户要的"按两下连子弹也停，按第三下全恢复"） */
function devFreezeLv(){ return devFrozen() ? (CFG.devFreeze | 0) : 0; }
function devToggleFreeze(){
  if (!CFG.dev || state !== 'play') return;
  const _lv = (CFG.devFreeze | 0);
  const _next = _lv >= 2 ? 0 : _lv + 1;
  CFG.devFreeze = _next;
  saveCfg();
  if (_next === 0) setMsg('继续（一切恢复）', 1.8);
  else if (_next === 1) setMsg('暂停 Lv1 · 世界静止 + 声音全停（再按 P：连你的子弹也冻住）', 2.4);
  else setMsg('暂停 Lv2 · 世界静止 + 声音全停 + 你的子弹也冻住（再按 P 全恢复）', 2.4);
  logWarn('dev', '开发者暂停 ' + (_next ? ('Lv' + _next) : '关闭'));
  /* 立刻生效，不等下一帧：长循环音（车引擎/漂移/雨）当场静音，背景音乐当场停 */
  if (typeof audioPauseTick === 'function') audioPauseTick();
  if (typeof lvlMusicEl !== 'undefined' && lvlMusicEl){
    if (_next === 0){ if (typeof levelMusicTick === 'function') levelMusicTick(0); }
    else { try { lvlMusicEl.pause(); } catch(e){} }
  }
}
/* 面板里点一下/按一下数字就会进入放置模式，这几种是"立刻执行"的功能项 */
const DEV_INSTANT = { playerFaction: 1, devFreeze: 1, companion: 1, flankPair: 1, banditSquad: 1 };
/* 退出放置模式：只清"这次放什么"，**不清朝向** ——
   m43911：以前这里把 devPlaceAng 归零，导致"摆好角度 → 按 J 换个兵种 → 角度没了",
   换一次兵就要重摆一次。朝向记住到下一次换关/重开（reset() 里清）。 */
function devPlaceCancel(){ devPlaceKind = null; devPlaceFac = null; }
/* 放置朝向：默认 0（朝右），[ / ] 每次 15°，按住 Shift 每次 5° */
function devPlaceRotate(d){
  devPlaceAng = (typeof normAng === 'function') ? normAng(devPlaceAng + d) : (devPlaceAng + d);
  const deg = Math.round(devPlaceAng * 180 / Math.PI);
  setMsg('投放朝向 ' + (deg > 180 ? deg - 360 : deg) + '°', 0.9);
  return deg;
}
/* m43955：放置时按住 Shift 吸附到 20px 网格 —— 一排车/一排兵要对齐就靠它 */
const DEV_PLACE_GRID = 20;
function devPlaceSnap(x, y){
  const S = DEV_PLACE_GRID;
  return { x: Math.round(x / S) * S, y: Math.round(y / S) * S };
}
/* 刚放下的那个东西转成 devPlaceAng：按坐标找最近的新实体（敌人/车/炮塔都算） */function devPlaceApplyAng(x, y){
  if (!devPlaceAng) return false;
  let best = null, bd = 46;
  for (const e of enemies){
    if (!e || e.dead) continue;
    const d = Math.hypot(e.x - x, e.y - y);
    if (d < bd){ bd = d; best = e; }
  }
  for (const t of trucks){
    if (!t || t.gone) continue;
    const d = Math.hypot(t.x - x, t.y - y);
    if (d < bd){ bd = d; best = t; }
  }
  if (!best) return false;
  best.ang = devPlaceAng;
  if ('angS' in best || best.type) best.angS = devPlaceAng;
  if (best.head !== undefined) best.head = devPlaceAng;
  if (best.mgAng !== undefined) best.mgAng = devPlaceAng;
  if (best.moveAng !== undefined) best.moveAng = devPlaceAng;
  return true;
}
function devMouseWorld(){
  if (typeof screenToWorld === 'function') return screenToWorld(mouse.x, mouse.y);
  return { x: mouse.x + cam.x, y: mouse.y + cam.y };
}
function devPlaceOK(kind, x, y, pad){
  const L = cur();
  if (!L) return false;
  const p = pad === undefined ? 20 : pad;
  if (x < p || y < p || x > L.w - p || y > L.h - p) return false;
  const T = enemyType({ type: kind });
  const rr = ((T && T.r) || 12) + 6;
  for (const w of L.walls){
    if (x > w.x - rr && x < w.x + w.w + rr && y > w.y - rr && y < w.y + w.h + rr) return false;
  }
  return true;
}
let devSpawnOpen = false;

/* 刷物资（V）：把现在有的几类物资在脚边撒一圈。
   新加物资只要往下面这个表里加一行，不用改投放面板。
   注意：只在测试区这类开发关用，正式关的物资点走 levels.js 的 loot 表 */
function devDropLoot(){
  if (!CFG.dev || state !== 'play' || !player) return false;
  const L = cur();
  const base = [];
  /* 药：小药 / 绿药包 */
  base.push({kind:'med', rarity:'small'}, {kind:'med', rarity:'big'}, {kind:'nade'});
  /* 弹药：三种口径各一盒 */
  if (typeof AMMO_ORDER !== 'undefined') for (const a of AMMO_ORDER) base.push({kind:'ammo', ammo:a});
  /* 枪：现在有的全给（信号枪 / 两把近战也摆上，方便试手感） */
  base.push({kind:'gun', wid:'pistol'}, {kind:'gun', wid:'flare'}, {kind:'gun', wid:'bino'}, {kind:'gun', wid:'shotgun'},
            {kind:'gun', wid:'rifle'}, {kind:'gun', wid:'ar'}, {kind:'gun', wid:'rpg'},
            {kind:'gun', wid:'knife'}, {kind:'gun', wid:'dao'});
  /* 枪口配件（收束器）：三个款各给一个，方便一次比完 */
  if (typeof ATTACH_DEF !== 'undefined') for (const id in ATTACH_DEF) base.push({kind:'attach', aid:id});
  /* 防弹衣：三档全给，方便一次比完 */
  if (typeof ARMOR_ORDER !== 'undefined') for (const k of ARMOR_ORDER) base.push({kind:'armor', armor:k});
  /* 背包：三档全给（只差大小） */
  if (typeof BAG_ORDER !== 'undefined') for (const k of BAG_ORDER) base.push({kind:'bag', bag:k});
  /* 万能钥匙：测试锁门用 */
  base.push({kind:'key'});
  /* 装备类：热成像 / 热成像电池 / 防弹盾牌（gear:true 的那几样，一次摆齐） */
  base.push({kind:'thermal'}, {kind:'heatcell', n:2}, {kind:'shield'});
  let n = 0;
  for (let i = 0; i < base.length; i++){
    const ang = TAU * (i / base.length);
    const rad = 54 + (i % 3) * 16;
    const p = safeSpot(L, {x: clamp(player.x + Math.cos(ang) * rad, 30, L.w - 30),
                           y: clamp(player.y + Math.sin(ang) * rad, 30, L.h - 30)}, 16);
    const d = base[i];
    loots.push({ x:p.x, y:p.y, taken:false, kind:d.kind, n:d.n,
                 rarity:d.rarity, ammo:d.ammo, wid:d.wid, armor:d.armor, bag:d.bag, aid:d.aid });
    n++;
  }
  sfxPick();
  setMsg('刷物资：' + n + ' 件撒在脚边', 1.8);
  logWarn('dev', '刷物资 ' + n + ' 件');
  return true;
}

function devSpawnEnemy(){
  if (!CFG.dev || state !== 'play') return;
  const L = cur();
  let spot = null, seen = null;
  for (let k = 0; k < 400; k++){
    const x = rand(60, L.w-60), y = rand(60, L.h-60);
    if (dist(x, y, player.x, player.y) < 240) continue;          /* 别糊到脸上 */
    if (L.walls.some(w => x > w.x-26 && x < w.x+w.w+26 && y > w.y-26 && y < w.y+w.h+26)) continue;
    if (!spot) spot = {x, y};
    /* 开了视野遮挡的图里：优先扔在你视线能到的地方，否则按下 J 等于没人出现 */
    if (!seen && playerCanSeePoint(x, y)){ seen = {x, y}; break; }
  }
  spot = seen || spot;
  if (!spot){ setMsg('这张图没找到空地', 1.6); return; }
  /* 新东西（刀手）也要能被 J 投出来 */
  if (arenaRandom() < 0.34){
    const _b = makeBladeEnemy(L);
    _b.x = spot.x; _b.y = spot.y; _b.ang = rand(0, TAU);
    _b.wp = [[spot.x, spot.y], [spot.x + rand(-220,220), spot.y + rand(-220,220)]];
    enemies.push(_b);
    setMsg('再投一个刀手 · 场上 ' + enemies.length + ' 个', 2.0);
    logWarn('dev', '投放 刀手（' + _b.wid + '）· 场上 ' + enemies.length + ' 个');
    return;
  }
  const t = safeSpot(L, {x: clamp(spot.x + rand(-220,220), 40, L.w-40),
                         y: clamp(spot.y + rand(-220,220), 40, L.h-40)}, 24);
  enemies.push({
    x:spot.x, y:spot.y, r:12, ang:rand(0,TAU),
    wp:[[t.x, t.y]], i:0, wait:0,
    mode:0, lastKnown:null, alertT:0, sees:false, heard:false, chk:null,
    ammo: CFG.mag, fireCd: rand(0.4,1.4), reloading:0, muzzle:0,
    /* 血量必须自己带上：不然打它 e.hp 变成 NaN，头顶血条也不画，等于测不了 */
    hp:100, maxHp:100, fleeCd:0
  });
  const _ne = enemies[enemies.length-1];
  assignWeapon(_ne);
  setMsg('空投一个' + enemyType(_ne).label + ' · ' + gunDef({wid:_ne.wid}).name +
         ' · 场上 ' + enemies.length + ' 个', 2.0);
  logWarn('dev', '开发者 · 随机投放' + enemyType(_ne).label + '（' + gunDef({wid:_ne.wid}).name +
          '）· 场上 ' + enemies.length + ' 个 · 位置 ' + Math.round(spot.x) + ',' + Math.round(spot.y));
}

/* 找一个"离玩家不太近、又不在墙里"的空地 */
function devSpotAt(){
  const L = cur();
  let spot = null, seen = null;
  for (let k = 0; k < 400; k++){
    const x = rand(60, L.w-60), y = rand(60, L.h-60);
    if (dist(x, y, player.x, player.y) < 240) continue;
    if (L.walls.some(w => x > w.x-26 && x < w.x+w.w+26 && y > w.y-26 && y < w.y+w.h+26)) continue;
    if (!spot) spot = {x, y};
    if (!seen && playerCanSeePoint(x, y)){ seen = {x, y}; break; }
  }
  return seen || spot;
}

/* 按种类投一个：人机种类不再随机，J 打开面板自己挑 */
/* ---------------- 训练假人 ----------------
   怎么做到"无限血 + 不动 + 不打"：不改敌人 AI 本体，只在每帧把它按住 ——
   刷满眩晕（眩晕这条链已经实现了"禁用一切机制 + 原地懵"），再把血补回满。
   伤害仍然真的走 absorbEnemyArmor → 所以面板报的是"实伤"，穿不穿甲一眼看出来。 */
let _dummySeq = 0;
function updateDummies(dt){
  if (!enemies.length) return;
  for (const e of enemies){
    if (!e.dummy || e.dead) continue;
    e.stunT = 1e9;              /* 永久眩晕：不动、不打、不找掩体、不喊话 */
    e.stunSpin = 0;             /* 也别转圈，假人得站定 */
    e.stunWob = 0;
    e.spdK = 0;
    e.sees = false;
    e.fireCd = 99;
    e.hp = e.maxHp;             /* 打不死：每帧补满，飘字照样是真实伤害 */
  }
}
function dummyRecord(e, dmg, crit){
  if (!e || !e.dummy) return;
  e.dHits = (e.dHits || 0) + 1;
  e.dTotal = (e.dTotal || 0) + dmg;
  e.dMax = Math.max(e.dMax || 0, dmg);
  e.dLast = dmg;
  if (crit) e.dCrit = (e.dCrit || 0) + 1;
  e.dLog = e.dLog || [];
  e.dLog.push({ t: uiT, v: dmg });
  if (e.dLog.length > 60) e.dLog.shift();
}
function dummyDps(e){
  const log = e.dLog || [];
  let sum = 0;
  for (const r of log) if (uiT - r.t <= 3.0) sum += r.v;
  return sum / 3.0;
}
/* 画出每个假人头顶的统计板（屏幕坐标，画在所有东西之上） */
function drawDummyPanels(){
  if (!enemies.length) return;
  ctx.save();
  ctx.textAlign = 'center';
  ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
  for (const e of enemies){
    if (!e.dummy || e.dead) continue;
    const p = deathScreenPos(e.x, e.y);
    if (p.x < -80 || p.x > W + 80 || p.y < -80 || p.y > H + 80) continue;
    const hits = e.dHits || 0;
    const avg = hits ? (e.dTotal / hits) : 0;
    const dps = dummyDps(e);
    const lines = [
      (enemyType(e).label || '假人') + ' #' + (e.dummyIdx || 0) + '　命中 ' + hits,
      '上一击 ' + Math.round(e.dLast || 0) + '　均伤 ' + avg.toFixed(1) + '　最高 ' + Math.round(e.dMax || 0),
      '暴击 ' + (e.dCrit || 0) + (hits ? '（' + Math.round((e.dCrit || 0) / hits * 100) + '%）' : '') +
        '　三秒 DPS ' + dps.toFixed(0)
    ];
    const w = 210, lh = 16, h = lines.length * lh + 10;
    const bx = p.x - w / 2, by = p.y - 92 - h;
    ctx.fillStyle = 'rgba(8,12,16,0.72)';
    ctx.fillRect(bx, by, w, h);
    ctx.strokeStyle = 'rgba(150,190,220,0.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(bx + 0.5, by + 0.5, w - 1, h - 1);
    ctx.fillStyle = 'rgba(196,226,248,0.95)';
    for (let i = 0; i < lines.length; i++)
      ctx.fillText(lines[i], p.x, by + 15 + i * lh);
    /* 一根短连线，别让板子飘在别人头上 */
    ctx.strokeStyle = 'rgba(150,190,220,0.22)';
    ctx.beginPath(); ctx.moveTo(p.x, by + h); ctx.lineTo(p.x, p.y - 22); ctx.stroke();
  }
  ctx.restore();
}
/* 按 K 清掉所有假人；没有假人就返回 false，交回原来的"处决"逻辑 */
function devClearDummies(){
  if (!CFG.dev || state !== 'play') return false;
  const list = enemies.filter(e => e.dummy);
  if (!list.length) return false;
  let tot = 0, hit = 0;
  for (const e of list){ tot += (e.dTotal || 0); hit += (e.dHits || 0); }
  enemies = enemies.filter(e => !e.dummy);
  setMsg(hit
    ? ('假人清掉了 · 一共打了 ' + hit + ' 下，总伤害 ' + Math.round(tot))
    : '假人清掉了', 2.2);
  logWarn('dev', '清除假人 ×' + list.length + ' · 命中 ' + hit + ' · 总伤 ' + Math.round(tot));
  return true;
}
function devSpawnKind(kind, pos, fac){
  /* fac：这次投放的势力（'enemy' | 'bandit' | 'neutral'）。不传就跟随玩家。 */
  const _fac = fac || devSpawnFaction();
  const _ft = devFactionTint(_fac);
  if (!CFG.dev || state !== 'play') return false;
  if (kind === 'devFreeze'){ devToggleFreeze(); return true; }
  if (kind === 'playerFaction'){ playerCycleFaction(); return true; }
  if (kind === 'companion') return !!companionSpawn();
  if (kind === 'banditSquad'){
    const s = squadSpawnBandit(5, { type: 'grunt', formation: 'column' });
    if (s){
      setMsg('摆了一支 B 势力小队（' + s.members.length + ' 人）· 他们在打 A 势力，对你中立', 2.4);
      logWarn('dev', '投放 B 势力小队 · ' + s.members.length + ' 人');
    }
    return !!s;
  }
  if (kind === 'flankPair') return devSpawnFlankPair();
  if (kind === 'flankElite' && !cur().rules?.devTest) return false;
  if (kind === 'rocketTurret') return spawnRocketTurret(pos);
  if (kind === 'mgSentry' && typeof spawnMgSentry === 'function') return spawnMgSentry(pos);
  if (kind === 'mgnest'){
    if (!pos) return spawnMgNest();
    if (!devPlaceOK(kind, pos.x, pos.y, 46)){ setMsg('这儿放不下机枪阵地', 1.6); return false; }
    return spawnMgNest(pos.x, pos.y, Math.atan2(player.y - pos.y, player.x - pos.x));
  }
  if (kind === 'truck') return spawnTruck(null, pos, _fac);
  if (kind === 'truckApc') return spawnTruck('truck_apc', pos, _fac);
  if (kind === 'truckPickup') return spawnTruck('truck_pickup', pos, _fac);
  if (kind === 'truckBandit') return spawnTruck(null, pos, 'bandit');
  if (kind === 'truckPark') return spawnParkedTruck(null, pos, _fac);
  if (kind === 'truckApcPark') return spawnParkedTruck('truck_apc', pos, _fac);
  if (kind === 'truckPickupPark') return spawnParkedTruck('truck_pickup', pos, _fac);
  if (kind === 'truckCivil') return spawnTruck('truck_civil', pos, 'neutral');
  if (kind === 'truckCivilPark') return spawnParkedTruck('truck_civil', pos, 'neutral');
  if (kind && kind.indexOf('boss') === 0) return devSpawnBoss(kind.slice(4).toLowerCase(), pos, _fac);
  const L = cur();
  const spot = pos || devSpotAt();
  if (!spot){ setMsg('这张图没找到空地', 1.6); return false; }
  if (pos && !devPlaceOK(kind, spot.x, spot.y)){ setMsg('这儿放不下', 1.6); return false; }
  if (kind === 'dummy' || kind === 'dummyArmor'){
    const DT = enemyType({type: kind});
    const e = {
      type: kind,
      x: spot.x, y: spot.y, r: DT.r || 14, ang: 0,
      wp: [], i: 0, wait: 0, mode: 0, lastKnown: null, alertT: 0,
      sees: false, heard: false, chk: null, ammo: 0, fireCd: 99, reloading: 0, muzzle: 0,
      hp: DT.hp, maxHp: DT.maxHp, fleeCd: 0,
      dummy: true, dummyIdx: (++_dummySeq),
      stunT: 1e9, spdK: 0, tucked: false, peekPhase: 'tuck',
      dHits: 0, dTotal: 0, dMax: 0, dCrit: 0, dLast: 0, dLog: []
    };
    if (DT.armorKind) e.armor = armorOf(DT.armorKind);
    enemies.push(e);
    setMsg('摆了一个' + DT.label + ' · 按 K 清掉所有假人', 2.2);
    logWarn('dev', '投放 ' + DT.label + ' #' + e.dummyIdx);
    return true;
  }
  if (kind === 'bladeKnife' || kind === 'bladeDao'){
    const b = makeBladeEnemy(L);
    b.x = spot.x; b.y = spot.y; b.ang = rand(0, TAU);
    b.wid = (kind === 'bladeDao') ? 'dao' : 'knife';
    b.wp = [[spot.x, spot.y], [spot.x + rand(-220,220), spot.y + rand(-220,220)]];
    b.faction = _fac; b.factionTint = devFactionTint(_fac);
    enemies.push(b);
    setMsg('投了一个' + (kind === 'bladeDao' ? '弯刀' : '小刀') + '刀手 · 场上 ' + enemies.length + ' 个', 2.0);
    logWarn('dev', '投放 刀手（' + b.wid + '）· 场上 ' + enemies.length + ' 个');
    return true;
  }
  const t = safeSpot(L, {x: clamp(spot.x + rand(-220,220), 40, L.w-40),
                         y: clamp(spot.y + rand(-220,220), 40, L.h-40)}, 24);
  const searchProfile = kind === "searchCareful" ? true : kind === "searchCareless" ? false : undefined;
  if (searchProfile !== undefined) kind = searchProfile ? "spec" : "grunt";
  const _dT = enemyType({type: kind});
  const _hp = Math.max(1, enemyBaseHp(_dT, L));
  enemies.push({
    type: kind,
    x:spot.x, y:spot.y, r:_dT.r || 12, ang:rand(0,TAU),
    wp:[[t.x, t.y]], i:0, wait:0,
    mode:0, lastKnown:null, alertT:0, sees:false, heard:false, chk:null,
    ammo: CFG.mag, fireCd: rand(0.4,1.4), reloading:0, muzzle:0,
    hp:_hp, maxHp:_hp, fleeCd:0, faction: _fac, factionTint: _ft
  });
  const ne = enemies[enemies.length-1];
  if (searchProfile !== undefined) ne.searchCareful = searchProfile;
  if (enemyType(ne).armorKind) ne.armor = armorOf(enemyType(ne).armorKind);
  assignWeapon(ne);
  setMsg('投了一个' + enemyType(ne).label + ' · 场上 ' + enemies.length + ' 个', 2.0);
  logWarn('dev', '投放 ' + enemyType(ne).label + ' · 场上 ' + enemies.length + ' 个');
  return true;
}

/* 开发者：按种类投一只 BOSS（普通关卡也能用，能力由 arenaBossTick 驱动） */
function devSpawnBoss(kind, pos, fac){
  const L = cur();
  const bd = (typeof ARENA_BOSSES !== 'undefined' && ARENA_BOSSES[kind]) || null;
  if (!bd) return false;
  const spot = pos || devSpotAt();
  if (!spot) { setMsg('这张图没找到空地', 1.6); return false; }
  if (pos && !devPlaceOK(kind, spot.x, spot.y)){ setMsg('这儿放不下', 1.6); return false; }
  const wave = (typeof ar !== 'undefined' && ar) ? ar.wave : 5;
  const hp = bossHpFor(wave, 0, bd.hpK);
  const b = { type:'grunt', x:spot.x, y:spot.y, r:21, ang: rand(0, TAU),
              wp:[[spot.x, spot.y]], i:0, wait:0, mode:1,
              lastKnown:{x:player.x, y:player.y}, alertT:99,
              sees:false, heard:false, chk:null,
              ammo: kind === 'charger' ? 0 : 60, fireCd: 0.6, reloading:0, muzzle:0,
              hp: hp, maxHp: hp, dmgK: bossPowerK(wave, 0),
              spdK: bd.spdK, wid: bd.wid,
              boss:true, bossName: bd.name, bossKind: kind,
              bossTint: bd.tint, bossTip: bd.tip,
              shieldAng: rand(0, TAU), burstLeft: 0, spawnCd: 3.5,
              dashT: 0, dashWind: 0, dashCd: 2.6, dashDir: 0, faction: _fac, factionTint: _ft };
  enemies.push(b);
  setMsg('投放 ' + bd.name + ' · ' + bd.tip, 2.4);
  logWarn('dev', '开发者 · 投放 BOSS ' + bd.name + '（' + kind + '）· HP ' + hp);
  return true;
}

/* 两名测试精英成组投放在附近可见空地，确保玩家能观察到完整协同。 */
function devSpawnFlankPair(){
  if (!CFG.dev || state !== 'play' || !cur().rules?.devTest) return false;
  const L=cur(),T=ENEMY_TYPES.flankElite;
  let spots=null;
  const vision=enemyVisionRange({type:'flankElite'});
  for (const radius of [Math.min(350,vision*0.75),Math.min(440,vision*0.85)]){
    for (let i=0;i<16;i++){
      const a=(player.aim||0)+i*TAU/16;
      const x=player.x+Math.cos(a)*radius,y=player.y+Math.sin(a)*radius;
      const x2=x-Math.sin(a)*80,y2=y+Math.cos(a)*80;
      if (!flankWalk(L,T.r,x,y,x,y) || !flankWalk(L,T.r,x2,y2,x2,y2) ||
          losBlocked(x,y,player.x,player.y) || losBlocked(x2,y2,player.x,player.y)) continue;
      if (enemies.some(e=>!e.dead && (dist(e.x,e.y,x,y)<45 || dist(e.x,e.y,x2,y2)<45))) continue;
      spots=[[x,y],[x2,y2]];break;
    }
    if(spots)break;
  }
  if(!spots){setMsg('附近没有能观察协同的空地，请移到开阔处再投放',2.5);return false;}
  for(const [x,y] of spots){
    const e={type:'flankElite',x,y,r:T.r,ang:Math.atan2(player.y-y,player.x-x),
      wp:[[x,y]],i:0,wait:0,mode:0,lastKnown:null,alertT:0,sees:false,heard:false,chk:null,
      ammo:CFG.mag,fireCd:0.5,reloading:0,muzzle:0,hp:enemyBaseHp(T,cur()),maxHp:enemyBaseHp(T,cur()),fleeCd:0};
    e.armor=armorOf(T.armorKind);assignWeapon(e);enemies.push(e);
  }
  setMsg('协同精英 ×2 · 观察“架枪 / 包抄 / 侧翼就位”提示',3);
  return true;
}

function devSpawnPanel(v){
  devSpawnOpen = (v === undefined) ? !devSpawnOpen : !!v;
}

/* 投放面板的几何：绘制和点击共用这一份。
   条目会越加越多（现在 21 项），窗口一矮最后几行就被切到画面外 —— 行高按可用高度自适应。 */
/* 投放面板的几何：绘制和点击共用这一份（分组后一屏最多 7 行）。 */
function devSpawnPanelGeom(){
  const g = DEV_SPAWN_GROUPS[devGroupIx] || DEV_SPAWN_GROUPS[0];
  const n = Math.max(1, g.items.length);
  const pw = 408;
  const rowH = Math.max(19, Math.min(30, Math.floor((H - 250) / n)));
  const ph = 94 + n * rowH + 28;
  const x = (W - pw) / 2;
  const y = clamp(72, 42, Math.max(42, H - ph - 54));
  return { x: x, y: y, w: pw, h: ph, rowH: rowH, n: n, group: g, tabsY: y + 44, itemsY: y + 80 };
}
function devTabRects(G){
  const out = [], pad = 16, n = DEV_SPAWN_GROUPS.length;
  const w = (G.w - pad * 2) / n;
  for (let i = 0; i < n; i++) out.push({ x: G.x + pad + i * w, y: G.tabsY, w: w - 4, h: 22, i: i });
  return out;
}
function devTabHit(mx, my){
  if (!CFG.dev || !devSpawnOpen) return -1;
  for (const r of devTabRects(devSpawnPanelGeom()))
    if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) return r.i;
  return -1;
}
function devRowHit(mx, my){
  if (!CFG.dev || !devSpawnOpen) return -1;
  const G = devSpawnPanelGeom();
  if (mx < G.x || mx > G.x + G.w || my < G.itemsY) return -1;
  for (let i = 0; i < G.n; i++){
    const ry = G.itemsY + i * G.rowH;
    if (my >= ry && my < ry + G.rowH - 3) return i;
  }
  return -1;
}
/* 面板里点一下：切组 / 选中兵种。**不在这里投放** —— 投放只走两条路：
   数字键（立刻放一个）和放置模式里点地图。返回 'tab' | 'pick' | 'blank' */
function devPanelPickAt(mx, my){
  const ti = devTabHit(mx, my);
  if (ti >= 0){ devGroupIx = ti; return 'tab'; }
  const ri = devRowHit(mx, my);
  if (ri < 0) return 'blank';
  const g = DEV_SPAWN_GROUPS[devGroupIx] || DEV_SPAWN_GROUPS[0];
  const it = g.items[ri];
  if (!it) return 'blank';
  if (DEV_INSTANT[it.k]){
    devSpawnKind(it.k, devMouseWorld(), it.fac || null);
    devPlaceKind = null;
    setMsg('已执行', 1.2);
  } else {
    devPlaceKind = it.k;
    devPlaceFac = it.fac || null;
    setMsg('点地图放一个 · 右键/Esc 退出', 1.6);
  }
  /* 切阵营是个"开关"，切完还想接着放兵，所以面板不要自己关掉 */
  if (it.k !== 'playerFaction') devSpawnOpen = false;
  return 'pick';
}
function devGroupStep(d){
  const n = DEV_SPAWN_GROUPS.length;
  devGroupIx = (devGroupIx + d + n) % n;
}
function drawDevSpawnPanel(){
  if (!CFG.dev || !devSpawnOpen) return;
  const G = devSpawnPanelGeom();
  const pw = G.w, rowH = G.rowH, ph = G.h, x = G.x, y = G.y;
  ctx.save();
  ctx.fillStyle = 'rgba(10,14,20,0.95)';
  ctx.strokeStyle = 'rgba(255,196,120,0.55)';
  ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.roundRect(x, y, pw, ph, 12); ctx.fill(); ctx.stroke();
  ctx.textAlign = 'left';
  ctx.fillStyle = '#ffcf8a';
  ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
  ctx.fillText('投放人机', x + 18, y + 26);
  ctx.textAlign = 'right';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#8fa0b4';
  ctx.fillText('J / Esc 关闭', x + pw - 18, y + 26);
  for (const r of devTabRects(G)){
    const on = r.i === devGroupIx;
    const hov = mouse.x >= r.x && mouse.x <= r.x + r.w && mouse.y >= r.y && mouse.y <= r.y + r.h;
    ctx.fillStyle = on ? 'rgba(255,196,120,0.22)' : (hov ? 'rgba(255,196,120,0.10)' : 'rgba(255,255,255,0.045)');
    ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 6); ctx.fill();
    ctx.textAlign = 'center';
    ctx.font = (on ? 'bold ' : '') + '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = on ? '#ffd9a6' : '#93a3b6';
    ctx.fillText(DEV_SPAWN_GROUPS[r.i].name, r.x + r.w / 2, r.y + 15);
  }
  ctx.textAlign = 'left';
  for (let i = 0; i < G.n; i++){
    const it = G.group.items[i];
    const ry = G.itemsY + i * rowH;
    const hov = mouse.x > x + 10 && mouse.x < x + pw - 10 && mouse.y > ry && mouse.y < ry + rowH - 3;
    if (hov){ ctx.fillStyle = 'rgba(255,196,120,0.14)'; ctx.fillRect(x + 10, ry, pw - 20, rowH - 3); }
    ctx.font = Math.max(10, Math.min(13, rowH * 0.46)) + 'px "Microsoft YaHei",sans-serif';
    const _on = (it.k === 'devFreeze' && devFrozen());
    ctx.fillStyle = _on ? '#8fd6a8' : '#d9e3ef';
    ctx.fillText('[' + (i === 9 ? 0 : i + 1) + ']  ' + it.name, x + 20, ry + rowH * 0.66);
  }
  ctx.textAlign = 'center';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#7f8fa3';
  ctx.fillText('←/→ 或点标签切组 · 数字键立刻投放 · 之后点地图连放 · 右键/Esc 退出', x + pw / 2, y + ph - 10);
  ctx.restore();
}
/* 暂停时屏幕上方挂一条，别让人以为是卡死了 */
function drawDevFreezeTag(){
  ctx.save();
  ctx.textAlign = 'center';
  ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  const _lv = (CFG.devFreeze | 0);
  const t = _lv >= 2 ? '开发者暂停 Lv2 · 世界与你的子弹都静止（P 再按一次全恢复）'
                     : '开发者暂停 Lv1 · 世界静止 · 声音已停（再按 P：子弹也停）';
  const w = ctx.measureText(t).width + 26;
  ctx.fillStyle = 'rgba(8,12,16,0.72)';
  ctx.beginPath(); ctx.roundRect((W - w) / 2, 12, w, 26, 8); ctx.fill();
  ctx.strokeStyle = 'rgba(140,226,170,0.55)'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.fillStyle = '#9fe3b8';
  ctx.fillText(t, W / 2, 30);
  ctx.restore();
}
/* 放置模式：鼠标下画一个"落点圈"，红=放不下 */
function drawDevPlaceGhost(){
  /* 拍照模式下连落点圈和这行提示字一起藏掉 */
  if (typeof uiHideAll !== 'undefined' && uiHideAll) return;
  if (!CFG.dev || !devPlaceKind || state !== 'play') return;
  const w = devMouseWorld();
  const T = enemyType({ type: devPlaceKind });
  const r = (T && T.r) || 14;
  const ok = devPlaceOK(devPlaceKind, w.x, w.y);
  ctx.save();
  ctx.lineWidth = 1.6;
  ctx.strokeStyle = ok ? 'rgba(140,226,170,0.92)' : 'rgba(240,110,110,0.92)';
  ctx.fillStyle = ok ? 'rgba(140,226,170,0.10)' : 'rgba(240,110,110,0.10)';
  ctx.beginPath(); ctx.arc(mouse.x, mouse.y, r + 6, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(mouse.x - r - 12, mouse.y); ctx.lineTo(mouse.x - r - 4, mouse.y);
  ctx.moveTo(mouse.x + r + 4, mouse.y);  ctx.lineTo(mouse.x + r + 12, mouse.y);
  ctx.moveTo(mouse.x, mouse.y - r - 12); ctx.lineTo(mouse.x, mouse.y - r - 4);
  ctx.moveTo(mouse.x, mouse.y + r + 4);  ctx.lineTo(mouse.x, mouse.y + r + 12);
  ctx.stroke();
  ctx.textAlign = 'center';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = ok ? 'rgba(180,240,200,0.95)' : 'rgba(250,160,160,0.95)';
  ctx.fillText(ok ? '左键放一个 · [ ] 转向 · 右键退出' : '这儿放不下', mouse.x, mouse.y - r - 20);
  /* 朝向箭头：一眼看出这个兵/车会朝哪边站（m43322） */
  if (ok){
    const _len = r + 16;
    const _cx = Math.cos(devPlaceAng), _cy = Math.sin(devPlaceAng);
    ctx.strokeStyle = 'rgba(150,235,180,0.95)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(mouse.x + _cx * (r + 2), mouse.y + _cy * (r + 2));
    ctx.lineTo(mouse.x + _cx * _len, mouse.y + _cy * _len);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(mouse.x + _cx * _len, mouse.y + _cy * _len);
    ctx.lineTo(mouse.x + _cx * (_len - 7) - _cy * 5, mouse.y + _cy * (_len - 7) + _cx * 5);
    ctx.lineTo(mouse.x + _cx * (_len - 7) + _cy * 5, mouse.y + _cy * (_len - 7) - _cx * 5);
    ctx.closePath();
    ctx.fillStyle = 'rgba(150,235,180,0.95)';
    ctx.fill();
    const _deg = Math.round(devPlaceAng * 180 / Math.PI);
    ctx.fillStyle = 'rgba(180,240,200,0.85)';
    ctx.font = '10px "Microsoft YaHei",sans-serif';
    ctx.fillText((_deg > 180 ? _deg - 360 : _deg) + '°', mouse.x, mouse.y + r + 20);
  }
  ctx.restore();
}
function devToggleXray(){
  if (!CFG.dev) return;
  CFG.xray = !CFG.xray;
  saveCfg();
  setMsg(CFG.xray ? '透视：开（视野外也看得见）' : '透视：关', 1.6);
  logWarn('dev', '开发者 · 透视 ' + (CFG.xray ? '开启' : '关闭'));
  syncXrayBtn();
}

function devToggleHeat(){
  if (!CFG.dev) return;
  CFG.heatInf = !CFG.heatInf;
  saveCfg();
  setMsg(CFG.heatInf ? '热成像：无限' : '热成像：正常', 1.6);
  logWarn('dev', '开发者 · 热成像无限 ' + (CFG.heatInf ? '开启' : '关闭'));
}

/* 一枪 999999：面板里的「一击必杀」开关，或者开发者模式的 L 键，两者任一开着都生效 */
function oneShotOn(){ return !!(CFG.oneShot || (CFG.dev && CFG.devDmg)); }
function devToggleDmg(){
  if (!CFG.dev || state !== 'play') return;
  CFG.oneShot = !oneShotOn();
  CFG.devDmg = CFG.oneShot;
  syncDevCheats();
  setMsg(CFG.oneShot ? '一击必杀：开' : '一击必杀：关', 1.4);
  logWarn('dev', '一击必杀 ' + (CFG.oneShot ? '开' : '关'));
}
function devToggleGod(){
  if (!CFG.dev || state !== 'play') return;
  player.god = !player.god;
  setMsg(player.god ? '无敌：开' : '无敌：关', 1.4);
  logWarn('dev', '开发者 · 无敌 ' + (player.god ? '开启' : '关闭'));
}

/* 沙盒全开（I）：无敌 + 无限子弹 + 无限药品 + 打药秒好 + 热成像无限 + 一击必杀。
   以前这几个各自一个键（I/T/H/N/Z/Shift+N），测试时要按一串，现在一个键管全部。 */
function devApplySandbox(on){
  CFG.devSandbox = !!on;
  CFG.devInfAmmo = !!on;
  CFG.devInfMed = !!on;
  CFG.devNoHealCd = !!on;
  CFG.devDmg = !!on;
  /* 热成像是单独一个开关（面板里 / T 键），沙盒不替玩家做决定 */
  if (!on){
    /* 关沙盒 = 回到真实状态：电量清零，得自己充 */
    player.battery = 0;
    if (typeof player.batLock !== 'undefined'){ player.batLock = false; player.batRelease = false; }
  }
  player.god = !!on;
  if (typeof syncDevCheats === 'function') syncDevCheats();
}
function devToggleSandbox(){
  if (state !== 'play') return;
  if (!CFG.dev){ setMsg('先按 O 打开自定义参数', 1.6); return; }
  const on = !CFG.devSandbox;
  devApplySandbox(on);
  setMsg(on ? '沙盒全开 · 无敌 / 无限弹 / 无限药 / 秒好 / 热成像无限 / 一击必杀'
            : '沙盒全关', 2.6);
  logWarn('dev', '沙盒 ' + (on ? '全开' : '全关'));
}

function goSelect(){ mapOpen = false; state = 'select'; logInfo('ui', '打开选关界面'); }

/* ---------------- 运行日志 ---------------- */
let LOG_ON = true, LOG = [], LOG_MAX = 4000, logOpen = false, logDirty = false;
let codexOpen = false, codexPage = 0;
let logEl = null, logListEl = null, logNoteEl = null, logTick = 0;
let logBtnEl = null, lastCrash = '';

function pad2(n){ return (n < 10 ? '0' : '') + n; }
function logWall(){ const d = new Date(); return pad2(d.getHours())+':'+pad2(d.getMinutes())+':'+pad2(d.getSeconds()); }
function logGame(){
  const t = Math.max(0, timeAlive || 0);
  return pad2(Math.floor(t/60))+':'+pad2(Math.floor(t%60));
}
function logAdd(lv, tag, m){
  if (!LOG_ON) return;
  LOG.push({ w: logWall(), g: logGame(), lv: lv, tag: tag, m: m });
  if (lv !== 'info') crashNote(lv, tag, m);   /* 警告/错误同时落盘，刷新也不丢 */
  if (LOG.length > LOG_MAX) LOG.splice(0, LOG.length - LOG_MAX);
  logDirty = true;
}
/* ---------- 异常持久化：刷新不丢，玩家能把日志发出来 ---------- */
const CRASH_KEY = 'after5_crash_v1', CRASH_MAX = 120;
function crashLoad(){
  try{ const s = localStorage.getItem(CRASH_KEY); const a = s ? JSON.parse(s) : []; return Array.isArray(a) ? a : []; }catch(e){ return []; }
}
/* m22515：测试 bundle 里没有 URLSearchParams / location 也可能缺失，全都要守卫，
   否则一行顶层代码就把整个 bundle 加载炸掉（之前 7 套测试全红就是这个）。 */
const deathZoneBenchmarkPage = (typeof location !== 'undefined') &&
  (typeof URLSearchParams !== 'undefined') &&
  new URLSearchParams(location.search).get('bench') === 'dz';
function crashSave(list){
  if (deathZoneBenchmarkPage) return;
  try{ localStorage.setItem(CRASH_KEY, JSON.stringify(list.slice(-CRASH_MAX))); }catch(e){}
}
function crashNote(lv, tag, m){
  if (lv === 'info') return;
  const list = crashLoad();
  list.push({ w: logWall(), g: logGame(), lv: lv, tag: tag, m: String(m).slice(0, 400) });
  crashSave(list);
}
function crashCount(){ return crashLoad().length; }
function crashText(){ return crashLoad().map(e => '[' + e.w + '] ' + e.g + ' ' + e.lv.toUpperCase() + ' ' + e.tag + '  ' + e.m).join('\n'); }
function crashClear(){ crashSave([]); }
function downloadText(name, txt){
  try{
    const blob = new Blob([txt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => { try{ URL.revokeObjectURL(url); }catch(e2){} }, 1500);
    return true;
  }catch(e){ return false; }
}
const logInfo  = (tag, m)=>logAdd('info',  tag, m);
const logWarn  = (tag, m)=>logAdd('warn',  tag, m);
const logError = (tag, m)=>logAdd('error', tag, m);
function logCrash(where, err){
  const msg = where + ': ' + (err && err.message ? err.message : String(err));
  if (msg === lastCrash) return;          /* 同一个错误只记一次，别刷屏 */
  lastCrash = msg; logError('crash', msg);
  if (typeof showCrash === 'function') showCrash(msg);   /* 同一帧的横幅：让卡死时截图能直接看出是哪个函数炸的 */
}

const LOG_STYLE = {
  info:  { lv:PAL.P87, m:PAL.P31 },
  warn:  { lv:PAL.P101, m:PAL.P106 },
  error: { lv:PAL.P37, m:PAL.P99 }
};
const LOG_BTN = 'background:rgba(20,30,38,.95);border:1px solid #2b3d4a;color:#bcd4e2;border-radius:6px;'
  + 'padding:5px 11px;font:12px "Microsoft YaHei",sans-serif;cursor:pointer;';

function esc(s){ return String(s).replace(/[&<>]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }

function ensureLogUI(){
  if (logEl || !document.body) return;
  const d = document.createElement('div');
  d.style.cssText = 'position:absolute;inset:0;z-index:40;display:none;background:#050a0f;'
    + 'color:#cfe3ef;padding:14px 18px;box-sizing:border-box;font-family:Consolas,"Microsoft YaHei",monospace;';
  d.innerHTML = '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">'
    + '<b style="font-size:15px;color:#bde6ff;">运行日志</b>'
    + '<span id="logNote" style="font-size:12px;color:#6f8a9c;"></span>'
    + '<span style="flex:1"></span>'
    + '<button id="logToggle" style="' + LOG_BTN + '">记录中</button>'
    + '<button id="logCopy" style="' + LOG_BTN + '">复制全部</button>'
    + '<button id="logSave" style="' + LOG_BTN + '">下载 日志+性能</button>'
    + '<button id="logClear" style="' + LOG_BTN + '">清空</button>'
    + '<button id="logClose" style="' + LOG_BTN + '">关闭 (L)</button>'
    + '<span style="font-size:11px;color:#4a6675;">Esc 也能关 · 打开时游戏暂停</span>'
    + '</div>'
    + '<div id="logList" style="overflow:auto;height:calc(100% - 46px);font-size:12px;line-height:1.6;"></div>';
  document.body.appendChild(d);
  logEl = d; logListEl = d.querySelector('#logList'); logNoteEl = d.querySelector('#logNote');
  d.querySelector('#logCopy').addEventListener('click', copyLog);
  d.querySelector('#logSave').addEventListener('click', ()=>{
    const head = '暗区老鼠模拟器 运行日志\n时间 ' + new Date().toLocaleString()
      + '\n版本 ' + (typeof BUILD_TAG !== 'undefined' ? BUILD_TAG : '?') + '\n\n';
    const tail = '\n\n===== 历史留存异常（含以前几局） =====\n' + (crashText() || '(无)') + '\n';
    const stamp = Date.now();
    const okA = downloadText('暗区日志_' + stamp + '.txt', head + logText() + tail);
    /* m32656：性能（F3 卡顿帧）单独一份，玩家直接能看出"卡在哪一段" */
    const okB = (typeof perfSpikeText === 'function')
      ? downloadText('暗区性能_' + stamp + '.txt', perfSpikeText()) : false;
    if (logNoteEl) logNoteEl.textContent = (okA || okB)
      ? ('已保存两份（同一时间戳）：日志' + (okA ? '✓' : '✗') + ' · 性能' + (okB ? '✓' : '✗'))
      : '保存失败，改用「复制全部」';
  });
  d.querySelector('#logClear').addEventListener('click', ()=>{ LOG.length = 0; crashClear(); renderLog(); });
  d.querySelector('#logClear').title = '同时清掉历史留存的异常';
  d.querySelector('#logClose').addEventListener('click', ()=>toggleLog(false));
  logBtnEl = d.querySelector('#logToggle');
  logBtnEl.addEventListener('click', ()=>{
    LOG_ON = !LOG_ON;
    logBtnEl.textContent = LOG_ON ? '记录中' : '已暂停';
    logBtnEl.style.color = LOG_ON ? PAL.P4 : PAL.P96;
  });
  logBtnEl.style.color = PAL.P4;
}

function renderLog(){
  if (!logListEl) return;
  const tail = LOG.slice(-500);
  let h = '';
  for (const e of tail){
    const st = LOG_STYLE[e.lv] || LOG_STYLE.info;
    h += '<div style="display:flex;gap:8px;white-space:pre-wrap;">'
       + '<span style="color:#55707f;">' + e.w + '</span>'
       + '<span style="color:#3d5a68;">' + e.g + '</span>'
       + '<span style="color:' + st.lv + ';min-width:46px;">' + e.lv.toUpperCase() + '</span>'
       + '<span style="color:#7fa6bd;min-width:70px;">' + esc(e.tag) + '</span>'
       + '<span style="color:' + st.m + ';">' + esc(e.m) + '</span>'
       + '</div>';
  }
  logListEl.innerHTML = h || '<div style="color:#5f7a8c;">还没有记录</div>';
  logListEl.scrollTop = logListEl.scrollHeight;
  let nw = 0, ne = 0;
  for (const e of LOG){ if (e.lv === 'warn') nw++; else if (e.lv === 'error') ne++; }
  if (logNoteEl) logNoteEl.textContent = '共 ' + LOG.length + ' 条 · 警告 ' + nw + ' · 错误 ' + ne
    + (LOG_ON ? '' : ' · 记录已暂停');
}

function logText(){
  const _h = '暗区老鼠模拟器 · 版本 ' + (typeof BUILD_TAG !== 'undefined' ? BUILD_TAG : '?') + '\n';
  return _h + LOG.map(e => '[' + e.w + '] ' + e.g + ' ' + e.lv.toUpperCase() + ' ' + e.tag + '  ' + e.m).join('\n');
}
function copyLog(){
  const txt = logText();
  const done = (ok)=>{ if (logNoteEl) logNoteEl.textContent = ok ? ('已复制 ' + LOG.length + ' 条，直接粘给我') : '复制失败，请手动 Ctrl+A / Ctrl+C'; };
  try{
    if (navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(txt).then(()=>done(true), ()=>done(fallbackCopy(txt)));
      return;
    }
  }catch(e){}
  done(fallbackCopy(txt));
}
function fallbackCopy(txt){
  try{
    const ta = document.createElement('textarea');
    ta.value = txt;
    ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
    document.body.appendChild(ta); ta.focus(); ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return !!ok;
  }catch(e){ return false; }
}

function toggleLog(force){
  ensureLogUI();
  if (!logEl) return;
  logOpen = (force === undefined) ? !logOpen : !!force;
  logEl.style.display = logOpen ? 'block' : 'none';
  if (logOpen){ logDirty = false; renderLog(); }
}

/* ---------------- 设置面板 ---------------- */
const panel  = document.getElementById('panel');
const rowsEl = document.getElementById('rows');
/* 数值型参数其实是"改关卡"，属于开发者选项：只有音量这种纯体验项留在「参数」页。
   这条线（CHEAT_FIELD_KEYS）就是整理的分界，加新字段时按性质放。 */
const devRowsEl = document.getElementById('devRows');
const CHEAT_FIELD_KEYS = new Set(['enemies','eDmg','fireRate','mag','reload','bulletSpd','spread',
  'hearR','eSpeed','eMemory','hp','pSpeed','grenades','smokeLife','smokeR','loot','pVision','pFov']);
const tagEl  = document.getElementById('presetTag');
const btnSettings = document.getElementById('btnSettings');
const panelOpen = ()=> panel.classList.contains('on');

function fmt(v, f){
  if (f.step >= 1) return String(Math.round(v));
  return v.toFixed(1);
}

let hpRowEl = null;
function buildRows(){
  rowsEl.innerHTML = '';
  if (devRowsEl) devRowsEl.innerHTML = '';
  for (const f of FIELDS){
    const row = document.createElement('div'); row.className = 'row';
    const lab = document.createElement('label'); lab.textContent = f.label;
    const inp = document.createElement('input');
    inp.type = 'range'; inp.min = f.min; inp.max = f.max; inp.step = f.step;
    inp.value = CFG[f.k];
    const val = document.createElement('span'); val.className = 'val';
    val.textContent = fmt(CFG[f.k], f) + (f.unit ? ' ' + f.unit : '');
    inp.addEventListener('input', ()=>{
      /* m33507：只有「改关卡数值」这类才是开发者选项；音量这种纯手感项不该顺手开开发者模式 */
      if (CHEAT_FIELD_KEYS.has(f.k)){ CFG.dev = true; diffName = 'custom'; }
      CFG[f.k] = parseFloat(inp.value);
      /* 这一关有血量下限就不让往下拖了：拖到哪儿都弹回下限 */
      if (f.k === 'hp'){
        const _fl = hpFloorOf(cur());
        if (CFG.hp < _fl) CFG.hp = _fl;
        if (parseFloat(inp.value) < _fl) inp.value = String(_fl);
      }
      val.textContent = fmt(CFG[f.k], f) + (f.unit ? ' ' + f.unit : '');
      tagEl.textContent = '自定义';
      saveCfg();
    });
    row.appendChild(lab); row.appendChild(inp); row.appendChild(val);
    (CHEAT_FIELD_KEYS.has(f.k) && devRowsEl ? devRowsEl : rowsEl).appendChild(row);
    if (f.k === 'hp') hpRowEl = { inp: inp, val: val, f: f };
  }
  syncHpRow();
  if (typeof buildProgUnlock === 'function') buildProgUnlock();   /* m37700：解锁按钮跟着 devRows 重建 */
}
/* 开发工具：手动试天气，沿用 2 秒过渡。 */
function buildWeatherPicker(){
  if (!wxRowsEl || wxRowsEl.childElementCount || typeof WEATHER_ORDER === 'undefined') return;
  const box = document.createElement('div');
  box.className = 'row';
  box.style.flexWrap = 'wrap';
  box.style.gap = '6px';
  const lab = document.createElement('label');
  lab.textContent = '天气';
  lab.style.minWidth = '72px';
  box.appendChild(lab);
  for (const k of WEATHER_ORDER){
    const d = WEATHER_DEF[k];
    if (!d) continue;
    const btn = document.createElement('button');
    btn.textContent = d.label + (d.pin ? '（测试）' : '');
    btn.style.cssText = 'padding:4px 10px;border-radius:6px;border:1px solid #3a4552;' +
                        'background:#1b232c;color:#cfe2f2;font-size:12px;cursor:pointer';
    btn.addEventListener('click', function(){
      weatherTransition(k, 2.0);
      btn.blur();
    });
    box.appendChild(btn);
  }
  wxRowsEl.appendChild(box);
}

/* m37700：开发者工具 —— 一键解锁全部关卡与难度（只加通关记录，不删东西） */
function buildProgUnlock(){
  if (!devRowsEl || document.getElementById('progUnlockRow')) return;
  const box = document.createElement('div');
  box.className = 'row';
  box.style.flexWrap = 'wrap';
  box.style.gap = '6px';
  const lab = document.createElement('label');
  lab.textContent = '解锁';
  lab.style.minWidth = '72px';
  box.appendChild(lab);
  const btn = document.createElement('button');
  btn.textContent = '一键解锁全部关卡与难度';
  btn.style.cssText = 'padding:5px 12px;border-radius:6px;border:1px solid rgba(255,196,110,0.75);' +
                      'background:#231a08;color:#ffd79a;font-size:12px;font-weight:bold;cursor:pointer';
  const note = document.createElement('div');
  note.style.cssText = 'padding:2px 0 8px 0;font-size:12px;line-height:1.7;color:rgba(150,200,170,0.62)';
  note.textContent = '只往存档里补「已通关」记录：关卡解锁链、每关的普通 / 困难 / 噩梦、死亡地带的噩梦与硬核、全难度章都会一起开。不会删掉你已有的记录，想恢复原样只能清空全部数据。';
  btn.addEventListener('click', function(){
    if (typeof progUnlockAll !== 'function'){ setMsg('还没加载进度模块', 2); btn.blur(); return; }
    const r = progUnlockAll();
    btn.textContent = '✓ 已全部解锁（关卡 ' + r.levels + ' 张 / 死亡地带 ' + r.dz + ' 档）';
    btn.style.borderColor = 'rgba(120,220,150,0.85)';
    btn.style.background = '#0f2417';
    btn.style.color = '#a6f0bf';
    if (typeof setMsg === 'function') setMsg('开发者：所有关卡与难度已解锁', 2.6);
    if (typeof logInfo === 'function') logInfo('dev', '一键解锁：关卡 ' + r.levels + ' 张、死亡地带 ' + r.dz + ' 档');
    if (typeof refreshKeyRows === 'function') refreshKeyRows();
    btn.blur();
  });
  box.appendChild(btn);
  box.id = 'progUnlockRow';
  devRowsEl.insertBefore(note, devRowsEl.firstChild);
  devRowsEl.insertBefore(box, devRowsEl.firstChild);
}

/* 把行头那个"玩家生命"滑条拉到当前真实值（换了血量下限也能同步回去） */
function syncHpRow(){
  if (!hpRowEl || !hpRowEl.inp) return;
  const _fl = hpFloorOf(cur());
  hpRowEl.inp.min = String(Math.max(hpRowEl.f.min || 0, _fl));
  hpRowEl.inp.value = String(CFG.hp);
  hpRowEl.val.textContent = fmt(CFG.hp, hpRowEl.f) + (hpRowEl.f.unit ? ' ' + hpRowEl.f.unit : '');
}

/* m34234：开发者模式会把 diffName 改成 custom，但玩家可能一个滑块都没动。
   这里拿当前 CFG 跟四套预设逐项比，全等就认出"其实还是困难"，让通关记录落在正确档上。 */
function presetMatch(){
  /* 只用不会随局内状态漂移的字段：hp 会跟着存档/受伤变，pSpeed 会被加成改，不能拿来认档 */
  const keys = ['eDmg', 'fireRate', 'mag', 'bulletSpd', 'spread', 'eVision',
                'hearR', 'eSpeed', 'eMemory', 'pVision', 'pFov'];
  for (const name of ['nightmare', 'hard', 'normal', 'easy']){
    const p = PRESETS[name]; if (!p) continue;
    let same = true;
    for (const k of keys){
      if (typeof p[k] !== 'number') continue;
      if (Math.abs((CFG[k] || 0) - p[k]) > 0.001){ same = false; break; }
    }
    if (same) return name;
  }
  return '';
}
function applyPreset(name, inGame, persist = true){
  /* 只有在关卡里切换时才校验 —— 选关页点的那一下不该被"上一局用的关卡"挡掉，
     真正的降档发生在 reset() 里（进关那一刻按这一关的版本判断）。 */
  if (inGame && !diffAllowed(name, cur())) name = 'hard';   /* 这一关没有这一档 */
  const p = PRESETS[name]; if (!p) return;
  const oldHpMax = CFG.hp || 100;
  Object.assign(CFG, p);
  diffName = name;
  if (typeof presetName !== 'undefined') presetName = name;   /* 记住"真正的档位"，开发者模式改 diffName 时不受影响 */
  /* 局内切难度：能立刻生效的都立刻生效（子弹速度、射速、伤害、视野……都是每帧现读 CFG）。
     敌人数量这种要重开关卡才变的，只提示、不偷偷改。 */
  if (!inGame){
    CFG.dev = false; CFG.heatInf = false; CFG.xray = false;
  }
  applyHpFloor(inGame ? cur() : null);
  /* 下限把上限抬高了就重按新上限算一遍比例（别让人从 60 切到困难反而只剩 22）
     而且不管当时在不在关卡里都算：血量上限变了，当前血就得跟着调 */
  if (player && player.hp !== undefined && CFG.hp !== oldHpMax){
    const ratio2 = Math.min(1, player.hp / Math.max(1, oldHpMax));
    player.hp = Math.max(1, Math.round(CFG.hp * ratio2));
  }
  if (persist) saveCfg();
  buildRows();
  tagEl.textContent = (DIFF_LABEL)[name] || '自定义';
}

document.querySelectorAll('[data-preset]').forEach(b=>{
  b.addEventListener('click', ()=> applyPreset(b.getAttribute('data-preset'),
    state === 'play' || state === 'intro' || state === 'caught'));
});

/* ---- 设置面板里的"按键"页 ---- */
const keyRowsEl = document.getElementById('keyRows');
const tabCfgEl  = document.getElementById('tabCfg');
const tabKeyEl  = document.getElementById('tabKey');
const tabPerfEl = document.getElementById('tabPerf');
const wxRowsEl  = document.getElementById('wxRows');
const tabDevEl  = document.getElementById('tabDev');
const perfRowsEl= document.getElementById('perfRows');
const perfBoxEl = document.getElementById('perfBox');
const devBoxEl  = document.getElementById('devBox');
const hintEl    = document.getElementById('hint');
const titleEl   = document.getElementById('panelTitle');
/* 难度按钮按 DIFF_ORDER 生成：以后加一档只加一行数据 */
(function buildDiffButtons(){
  const box = document.getElementById('diffBtns');
  if (!box) return;
  box.innerHTML = DIFF_ORDER.map(k =>
    '<button data-preset="' + k + '">' + (DIFF_LABEL[k] || k) + '</button>').join(' ');
})();

const btnKeyReset = document.getElementById('btnKeyReset');
let panelTab = 'cfg';

function refreshKeyRows(){
  if (!keyRowsEl) return;
  const scroll = keyRowsEl.scrollTop;
  keyRowsEl.innerHTML = '';
  let currentSection = null;
  for (const act of BIND_ORDER){
    const section = BIND_ROWS[act].bindSection;
    if (section && section !== currentSection){
      const heading = document.createElement('h3'); heading.className = 'keySection';
      heading.textContent = section; keyRowsEl.appendChild(heading);
      const help = document.createElement('div'); help.className = 'keyHelp';
      help.textContent = '按住第一键再按第二键（可用鼠标）。组合键优先，Esc 取消。';
      keyRowsEl.appendChild(help);
    }
    currentSection = section;
    const row = document.createElement('div'); row.className = 'row';
    const lab = document.createElement('label'); lab.textContent = BIND_NAME[act];
    const b = document.createElement('button');
    b.className = 'kbtn' + (bindTarget === act ? ' arming' : '');
    b.dataset.bindAction = act;
    b.textContent = bindCaptureLabel(act);
    b.addEventListener('click', (e)=>{
      e.preventDefault();
      bindCaptureStart(act);
      refreshKeyRows();
      /* 点完按钮焦点会留在按钮上，空格/回车会重复触发它，直接放开 */
      b.blur();
    });
    const def = document.createElement('span'); def.className = 'kdef';
    def.textContent = '默认 ' + keyLabel(BIND_DEF[act]);
    row.appendChild(lab); row.appendChild(b); row.appendChild(def);
    /* m37450 / m37520：3（投掷物 / 枪 切换）和 Q（换手上这一类里的下一个）分工不同，
       Q 拿着枪时是换枪、拿着投掷物时才是手雷⇄烟雾弹，最容易被当成 bug。 */
    if (act === 'throwToggle' || act === 'throwSwap') row.classList.add('keyHot');
    keyRowsEl.appendChild(row);
    if (act === 'throwSwap'){
      const _k3 = keyLabel(BIND_DEF.throwToggle || BINDS.throwToggle);
      const _kq = keyLabel(BIND_DEF.throwSwap || BINDS.throwSwap);
      const _kf = keyLabel(BINDS.swap);
      const note = document.createElement('div');
      note.className = 'keyNote';
      note.innerHTML = '<b>' + _k3 + ' 和 ' + _kq + ' 分工不一样，别当成坏了</b>'
        + '<br>· <b>' + _k3 + '</b>：在手里的「枪」和「投掷物」之间来回切，解锁枪械之后才有意义。'
        + '<br>· <b>' + _kq + '</b>：换「手上这一类」里的下一个——'
        + '手里是<b>枪</b>就<b>换枪</b>（两把枪来回换，和 <b>' + _kf + '</b> 一个效果）；'
        + '手里是<b>投掷物</b>就<b>手雷 ⇄ 烟雾弹</b>；举着盾时是<b>收盾</b>。'
        + '<br>· 所以想换手雷 / 烟雾弹，得先按 <b>' + _k3 + '</b> 把投掷物拿出来，再按 <b>' + _kq + '</b>。';
      keyRowsEl.appendChild(note);
    }
  }
  keyRowsEl.scrollTop = scroll;
  if (btnKeyReset) btnKeyReset.style.display = 'inline-block';
}

/* 画质页：两个滑块直接决定敌人分档的距离，调完立刻生效（每帧现读 CFG） */
/* 画质页的距离示意图：圆心=玩家，内圈=完整细节，外圈=简化，圈外=圆点。
   世界px 直接按比例缩到画布上，西边放一把"人"的图标，让人一眼看出这两条滑块管多远。 */
function drawLodPreview(){
  const cv = document.getElementById('lodPrev');
  if (!cv || !cv.getContext) return;
  const g = cv.getContext('2d');
  const W = cv.width, H = cv.height;
  g.clearRect(0, 0, W, H);
  const near = Math.max(120, CFG.lodNear || 560);
  const far  = Math.max(near + 120, CFG.lodFar || 1010);
  const cy = H / 2, cx = W * 0.40;
  const k = Math.min(cx - 12, W - cx - 190) / far;   /* 内圈外圈都完整落在画布里，右边留字 */
  const ry = 0.77;                                /* 纵向阈值是横向的 0.77 倍 */

  /* 三层底色 */
  const ring = (r, fill, stroke) => {
    g.beginPath();
    g.ellipse(cx, cy, r * k, r * k * ry, 0, 0, Math.PI * 2);
    if (fill){ g.fillStyle = fill; g.fill(); }
    if (stroke){ g.strokeStyle = stroke; g.lineWidth = 1.5; g.stroke(); }
  };
  ring(far, 'rgba(70,90,120,0.18)', 'rgba(150,200,170,0.35)');
  ring(near, 'rgba(126,224,126,0.13)', 'rgba(126,224,126,0.55)');

  /* 中心：你 */
  g.beginPath(); g.arc(cx, cy, 4.5, 0, Math.PI * 2);
  g.fillStyle = '#8ef0c8'; g.fill();
  g.font = '12px "Microsoft YaHei",sans-serif';
  g.fillStyle = 'rgba(190,235,215,0.9)'; g.textAlign = 'center';
  g.fillText('你', cx, cy - 10);

  /* 三个距离上的小敌人示意：完整 / 简化 / 圆点 */
  const drawE = (dxWorld, mode) => {
    const x = cx + dxWorld * k;
    if (x > W - 8) return;
    g.save();
    if (mode === 0){          /* 完整 */
      g.fillStyle = '#c8b48c'; g.beginPath(); g.arc(x, cy, 7, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#6b5a3c'; g.fillRect(x + 2, cy - 2, 11, 3);
      g.fillStyle = '#2d3644'; g.beginPath(); g.arc(x, cy - 2, 3.2, 0, Math.PI * 2); g.fill();
    } else if (mode === 1){   /* 简化 */
      g.fillStyle = '#b9a884'; g.beginPath(); g.arc(x, cy, 6, 0, Math.PI * 2); g.fill();
      g.strokeStyle = '#2d3644'; g.lineWidth = 2;
      g.beginPath(); g.arc(x, cy, 4, -0.9, 0.9); g.stroke();
      g.strokeStyle = '#d8cba8'; g.lineWidth = 2.6;
      g.beginPath(); g.moveTo(x + 3, cy); g.lineTo(x + 12, cy); g.stroke();
    } else {                  /* 圆点 */
      g.fillStyle = '#a9b6c6'; g.beginPath(); g.arc(x, cy, 3, 0, Math.PI * 2); g.fill();
      g.strokeStyle = 'rgba(169,182,198,0.7)'; g.lineWidth = 1.4;
      g.beginPath(); g.moveTo(x + 2, cy); g.lineTo(x + 7, cy); g.stroke();
    }
    g.restore();
  };
  drawE(near * 0.55, 0);
  drawE((near + far) * 0.5, 1);
  drawE(far * 0.92, 2);

  /* 右侧文字：把两个数字翻译成人话 */
  g.textAlign = 'left';
  g.font = 'bold 13px "Microsoft YaHei",sans-serif';
  g.fillStyle = '#8ef0c8';
  const tx = W - 186;
  g.fillText('完整细节 ' + Math.round(near) + ' px', tx, cy - 30);
  g.fillStyle = 'rgba(170,190,210,0.92)';
  g.fillText('简化 ' + Math.round(far) + ' px', tx, cy - 2);
  g.fillStyle = 'rgba(150,165,185,0.85)';
  g.font = '12px "Microsoft YaHei",sans-serif';
  g.fillText('再远只剩一个点', tx, cy + 26);
  g.fillStyle = 'rgba(150,200,170,0.55)';
  g.fillText('内圈直径 ≈ 画面宽度的 ' + Math.round(near * 2 / 1280 * 100) + '%（按 1280 宽的窗口算）', 12, H - 10);
}

function buildPerfRows(){
  if (!perfRowsEl) return;
  perfRowsEl.innerHTML = '';
  /* m23255：显示尺寸 —— 改的是画布在页面上的实际像素面积。
     1920 屏上"铺满"会把 1280*800 放大到 1728*1080，每帧多合成 80% 的像素，
     核显上这一步能吃掉 20ms（用户死亡界面 update=0 时渲染仍 24.8ms）。 */
  if (typeof displayMode === 'function' && typeof displayModeSet === 'function'){
    const row = document.createElement('div'); row.className = 'row';
    const lab = document.createElement('label'); lab.textContent = '显示尺寸';
    const box = document.createElement('div'); box.style.display = 'flex'; box.style.gap = '8px';
    [['铺满窗口','fit'], ['原始 1:1','native']].forEach(([name, mode])=>{
      const b = document.createElement('button');
      const on = (displayMode() === mode);
      b.textContent = name;
      b.className = 'btn' + (on ? ' on' : '');
      b.style.cssText = 'padding:4px 14px;border-radius:7px;border:1px solid #2b4a3c;background:' +
        (on ? '#3f7f52' : '#1b2620') + ';color:#cfefd8;font-size:12px;cursor:pointer;';
      b.addEventListener('click', ()=>{ displayModeSet(mode); b.blur(); });
      box.appendChild(b);
    });
    row.appendChild(lab); row.appendChild(box);
    perfRowsEl.appendChild(row);
  }
  /* m23103 A：渲染分辨率（真降分辨率）。
     只改"每帧要填多少像素"，逻辑坐标/命中/视野/声音全都不变。 */
  (()=>{
    const row = document.createElement('div'); row.className = 'row';
    const lab = document.createElement('label'); lab.textContent = '渲染分辨率';
    const box = document.createElement('div'); box.style.display = 'flex'; box.style.gap = '8px';
    [[1, '100%'], [0.85, '85%'], [0.7, '70%']].forEach(([k, name])=>{
      const b = document.createElement('button');
      b.textContent = name;
      b.className = 'btn' + (renderScale() === k ? ' on' : '');
      b.style.cssText = 'padding:4px 14px;border-radius:7px;border:1px solid #2b4a3c;background:' +
        (renderScale() === k ? '#3f7f52' : '#1b2620') + ';color:#cfefd8;font-size:12px;cursor:pointer;';
      b.addEventListener('click', ()=>{ renderScaleSet(k); b.blur(); });
      box.appendChild(b);
    });
    row.appendChild(lab); row.appendChild(box);
    perfRowsEl.appendChild(row);
  })();
  /* m22515 A：画质档位（高 / 低 / 极低）。低配机器点「极低」能显著提帧：
     关掉雨幕虚影、雾团、光晕、镜头雨丝，雨丝数量也砍一半。 */
  (()=>{
    const row = document.createElement('div'); row.className = 'row';
    const lab = document.createElement('label'); lab.textContent = '雨雾特效';
    const box = document.createElement('div');
    box.style.cssText = 'display:flex;gap:6px;flex:1;justify-content:flex-end';
    const cur = (typeof perfLv === 'function') ? perfLv() : 0;
    ['全开', '精简', '关闭'].forEach((name, i)=>{
      const b = document.createElement('button');
      b.textContent = name;
      b.style.cssText = 'padding:3px 10px;border-radius:6px;cursor:pointer;font:12px Microsoft YaHei;' +
        (i === cur ? 'background:#3f7f52;color:#eafbf0;border:1px solid #58a06b'
                   : 'background:#1a2430;color:#a8bccb;border:1px solid #2d3d4c');
      b.addEventListener('click', ()=>{
        if (typeof perfSetLv === 'function') perfSetLv(i);
        b.blur();
        buildPerfRows();
      });
      box.appendChild(b);
    });
    row.appendChild(lab); row.appendChild(box);
    perfRowsEl.appendChild(row);
  })();
  const mk = (label, k, min, max, step, unit)=>{
    const row = document.createElement('div'); row.className = 'row';
    const lab = document.createElement('label'); lab.textContent = label;
    const inp = document.createElement('input');
    inp.type = 'range'; inp.min = min; inp.max = max; inp.step = step; inp.value = CFG[k];
    const val = document.createElement('span'); val.className = 'val';
    val.textContent = Math.round(CFG[k]) + ' ' + unit;
    inp.addEventListener('input', ()=>{
      CFG[k] = parseFloat(inp.value);
      if (CFG.lodFar < CFG.lodNear + 120) CFG.lodFar = CFG.lodNear + 120;   /* 远近档别贴在一起 */
      val.textContent = Math.round(CFG[k]) + ' ' + unit;
      if (k === 'lodNear' && window.__perfFarSync) window.__perfFarSync();
      saveCfg();
    });
    row.appendChild(lab); row.appendChild(inp); row.appendChild(val);
    perfRowsEl.appendChild(row);
    return { inp, val, unit };
  };
  /* 视野锥不透明度：单独一条，单位是 % */
  (()=>{
    const row = document.createElement('div'); row.className = 'row';
    const lab = document.createElement('label'); lab.textContent = '视野锥不透明度';
    const inp = document.createElement('input');
    const cur = coneAlphaK();
    inp.type = 'range'; inp.min = 0; inp.max = 100; inp.step = 5; inp.value = Math.round(cur * 100);
    const val = document.createElement('span'); val.className = 'val';
    val.textContent = Math.round(cur * 100) + ' %';
    inp.addEventListener('input', ()=>{
      CFG.coneAlpha = parseFloat(inp.value) / 100;
      val.textContent = Math.round(CFG.coneAlpha * 100) + ' %';
      saveCfg();
    });
    row.appendChild(lab); row.appendChild(inp); row.appendChild(val);
    perfRowsEl.appendChild(row);
  })();
  /* m32306 玩家声纹透明度：太清楚碍眼、太淡又看不清，交给玩家自己拖 */
  (()=>{
    const row = document.createElement('div'); row.className = 'row';
    const lab = document.createElement('label'); lab.textContent = '玩家声纹透明度';
    const inp = document.createElement('input');
    const cur = hearRingAlphaK();
    inp.type = 'range'; inp.min = 0; inp.max = 100; inp.step = 5; inp.value = Math.round(cur * 100);
    const val = document.createElement('span'); val.className = 'val';
    val.textContent = Math.round(cur * 100) + ' %';
    inp.addEventListener('input', ()=>{
      CFG.hearRingA = parseFloat(inp.value) / 100;
      val.textContent = Math.round(CFG.hearRingA * 100) + ' %';
      saveCfg();
    });
    row.appendChild(lab); row.appendChild(inp); row.appendChild(val);
    perfRowsEl.appendChild(row);
  })();
  mk('近处细节距离', 'lodNear', 240, 1200, 20, 'px');
  const far = mk('远处细节距离', 'lodFar', 480, 2200, 20, 'px');
  window.__perfFarSync = ()=>{ if (far) { far.inp.value = String(CFG.lodFar); far.val.textContent = Math.round(CFG.lodFar) + ' px'; } };
  const tip = document.createElement('div'); tip.className = 'hint'; tip.style.display = 'block';
  tip.textContent = '上面两条决定"多远之内画完整敌人"，数字越大越清楚、也越吃帧。视野锥那条是敌人视野的浓淡：人多的时候调到 40% 左右，屏幕就不会糊成一片白。玩家声纹是脚下那圈虚线（脚步能传多远），嫌碍眼就调低、看不清就调高，0% 整圈不画。';
  perfRowsEl.appendChild(tip);
}

function setPanelTab(t){
  panelTab = t;
  if (typeof wipeReset === 'function') wipeReset();   /* 换页就别留着「清空数据」的确认进度 */
  const cfg  = (t === 'cfg');
  const perf = (t === 'perf');
  const dev  = (t === 'dev');
  const key  = (t === 'key');
  if (!key && bindTarget) bindCaptureCancel();
  /* m23640：画质页要能看见屏幕右下那个 LOD 圈，遮罩调淡一点 */
  /* m23715：画质页把卡片靠右停靠，左边留出来给"玩家身上的 LOD 圈"看 */
  const _cardEl = document.querySelector('#panel .card');
  if (_cardEl){
    if (t === 'perf'){ _cardEl.style.width = 'min(560px,46%)'; _cardEl.style.marginRight = '1.6%'; }
    else { _cardEl.style.width = ''; _cardEl.style.marginRight = ''; }
  }
  panel.style.justifyContent = (t === 'perf') ? 'flex-end' : '';
  panel.style.background = (t === 'perf') ? 'rgba(2,5,8,.62)' : '';
  rowsEl.style.display     = cfg  ? '' : 'none';
  if (devRowsEl) devRowsEl.style.display = dev ? '' : 'none';
  if (perfRowsEl) perfRowsEl.style.display = perf ? '' : 'none';
  keyRowsEl.style.display  = key  ? '' : 'none';
  if (typeof syncPanelPrimaryBtn === 'function') syncPanelPrimaryBtn();   /* m32898：开发页的主按钮=返回当前界面 */
  if (wxRowsEl) wxRowsEl.style.display = dev ? '' : 'none';
  if (dev){ buildWeatherPicker(); buildProgUnlock(); }
  /* 开发页每次重建滑块都会清空 devRows，所以 buildRows 末尾也要补回解锁按钮 */
  if (perfBoxEl) perfBoxEl.style.display = perf ? '' : 'none';
  /* 画质页的内容与按钮文字都要等 perfOn/musicOn 这些后面脚本里的变量就位后再碰 */
  const _lp = document.getElementById('lodPrevBox');
  if (_lp) _lp.style.display = perf ? '' : 'none';
  if (perf){
    if (typeof buildPerfRows === 'function') buildPerfRows();
    if (typeof drawLodPreview === 'function') drawLodPreview();
    if (typeof syncFpsBtn === 'function') setTimeout(syncFpsBtn, 0);   /* perfOn 的 let 声明在 58-replay.js，晚于本文件加载，顶层直接调会踩 TDZ */
  }
  if (devBoxEl)  devBoxEl.style.display  = dev  ? '' : 'none';
  /* 上帝模式那一排也只在开发页露出（它是开发者工具，不该出现在普通玩家眼前） */
  if (typeof godSyncBoxVisible === 'function') godSyncBoxVisible();
  tabCfgEl.classList.toggle('on', cfg);
  if (tabPerfEl) tabPerfEl.classList.toggle('on', perf);
  if (tabDevEl)  tabDevEl.classList.toggle('on', dev);
  tabKeyEl.classList.toggle('on', key);
  titleEl.textContent = cfg ? '自定义参数' : perf ? '画质与性能' : dev ? '开发者选项' : '按键设置';
  if (hintEl) hintEl.style.display = dev ? '' : 'none';
  /* 难度按钮只在"参数"页；开发页把它们也藏掉，别混在一起 */
  document.querySelectorAll('[data-preset]').forEach(b=>{
    const _k = b.getAttribute('data-preset');
    const _ok = (state === 'play') ? diffAllowed(_k, cur()) : true;
    b.style.display = (cfg && _ok) ? '' : 'none';
  });
  document.getElementById('btnReset').style.display = cfg ? '' : 'none';
  /* 背景音乐那一坨（导入/淡入/音量）属于"参数"页，别跑到画质/开发页上 */
  ['bgmRow','bgmTune'].forEach(function(id){
    const el = document.getElementById(id); if (el) el.style.display = cfg ? '' : 'none';
  });
  ['btnWalk','btnMusic','btnShake','btnAudioRateLimit','btnAudioMasterLimit'].forEach(function(id){
    const b = document.getElementById(id); if (b) b.style.display = cfg ? '' : 'none';
  });
  if (key){
    if (btnKeyReset) btnKeyReset.style.display = 'inline-block';
    refreshKeyRows();
  } else if (btnKeyReset){
    btnKeyReset.style.display = 'none';
  }
}
if (tabCfgEl) tabCfgEl.addEventListener('click', ()=> setPanelTab('cfg'));

for (const [id, label, read, toggle] of [
  ['btnAudioRateLimit', '音效限流', () => audioRateLimit, () => { audioRateLimit = !audioRateLimit; }],
  ['btnAudioMasterLimit', '总线压限', () => audioMasterLimit, () => {
    audioMasterLimit = !audioMasterLimit;
    audioSyncMasterLimiter();
  }]
]){
  const button = document.getElementById(id);
  if (!button) continue;
  const sync = () => {
    const on = read();
    button.textContent = label + '：' + (on ? '开' : '关');
    button.setAttribute('aria-pressed', String(on));
    button.style.borderColor = on ? PAL.P44 : '';
  };
  button.addEventListener('click', () => { toggle(); saveAudioOptions(); sync(); });
  sync();
}
if (tabPerfEl) tabPerfEl.addEventListener('click', ()=> setPanelTab('perf'));
if (tabDevEl) tabDevEl.addEventListener('click', ()=> setPanelTab('dev'));
if (tabKeyEl) tabKeyEl.addEventListener('click', ()=> setPanelTab('key'));

/* ---- 画质页的三个预设 + 帧时间开关 ---- */
function applyQuality(near, far, name){
  CFG.lodNear = near; CFG.lodFar = far;
  saveCfg(); buildPerfRows();
  setMsg('画质：' + name + '（近处 ' + near + ' / 远处 ' + far + '）', 1.8);
}
[['btnQlow', 300, 700, '低'], ['btnQmid', 560, 1010, '中'], ['btnQhigh', 900, 1600, '高']].forEach(function(t){
  const el = document.getElementById(t[0]);
  if (el) el.addEventListener('click', ()=> applyQuality(t[1], t[2], t[3]));
});
const benchButton = document.getElementById('btnPerfBenchmark');
if (benchButton) benchButton.addEventListener('click', ()=>{
  window.open('?bench=dz', '_blank', 'noopener');
});
const btnFpsEl = document.getElementById('btnFps');
function syncFpsBtn(){
  if (!btnFpsEl) return;
  /* perfOn 在 58-replay.js 才声明；加载期被调到就容错成"关" */
  let _on = false;
  try { _on = perfOn; } catch (e) { _on = false; }
  btnFpsEl.textContent = '帧时间显示：' + (_on ? '开' : '关');
  btnFpsEl.style.borderColor = _on ? PAL.P213 : '';
}
if (btnFpsEl) btnFpsEl.addEventListener('click', ()=>{ perfOn = !perfOn; if (perfOn && typeof perfLongInstall === 'function') perfLongInstall(); syncFpsBtn(); });

if (btnKeyReset) btnKeyReset.addEventListener('click', ()=>{
    /* 先把"按任意键…"那个待绑定状态取消掉，否则点完恢复默认，
       下一次按键还会被吃进绑定流程，看起来像没生效 */
    bindCaptureCancel();
    resetBinds();
    refreshKeyRows();
    setMsg('按键已恢复默认', 1.6);
  });

/* m32556：所有可调参数回默认（面板上那个「恢复默认」按钮用） */
function resetAllCfg(){
  Object.assign(CFG, DEFAULTS);
  CFG.dev = false; CFG.devExplicit = false;
  CFG.heatInf = false; CFG.xray = false; CFG.oneShot = false;
  CFG.aiArc = false; CFG.fogVision = false;
  CFG.devDmg = false; CFG.devFreeze = false; CFG.showHurt = true;
  diffName = 'normal';
  saveCfg();
  if (typeof buildRows === 'function') buildRows();
  if (typeof syncDevCheats === 'function') syncDevCheats();
  if (typeof applyAiArc === 'function') applyAiArc();
  if (typeof syncAiArcBtn === 'function') syncAiArcBtn();
  if (typeof syncDevBtn === 'function') syncDevBtn();
  if (tagEl) tagEl.textContent = '普通';
}
document.getElementById('btnReset').addEventListener('click', ()=>{
  resetAllCfg();
});

/* m32656：关开发者模式不该动玩家自己的音量/画质偏好。只把"开发者调出来的"东西退回去：
   难度参数（人机数量/伤害/射速…）+ 各种开发者开关 + 难度名回普通。
   音量（gunVol）和画质（lodNear/lodFar/coneAlpha/hearRingA）原样保留。 */
const DEV_KEEP_KEYS = ['gunVol', 'stepVol', 'ambVol', 'lodNear', 'lodFar', 'coneAlpha', 'hearRingA'];
function resetDevCfg(){
  const keep = {};
  for (const k of DEV_KEEP_KEYS) keep[k] = CFG[k];
  Object.assign(CFG, DEFAULTS);
  for (const k of DEV_KEEP_KEYS) if (keep[k] !== undefined) CFG[k] = keep[k];
  CFG.dev = false; CFG.devExplicit = false;
  CFG.heatInf = false; CFG.xray = false; CFG.oneShot = false;
  CFG.aiArc = false; CFG.fogVision = false;
  CFG.devDmg = false; CFG.devFreeze = false;
  CFG.showHurt = true;
  diffName = 'normal';
  saveCfg();
  if (typeof buildRows === 'function') buildRows();
  if (typeof syncDevCheats === 'function') syncDevCheats();
  if (typeof applyAiArc === 'function') applyAiArc();
  if (typeof syncAiArcBtn === 'function') syncAiArcBtn();
  if (typeof syncDevBtn === 'function') syncDevBtn();
  if (tagEl) tagEl.textContent = (typeof DIFF_LABEL !== 'undefined' && DIFF_LABEL[diffName]) || '普通';
}
function syncXrayBtn(){
  const bx = document.getElementById('btnXray');
  if (!bx) return;
  bx.textContent = '敌人透视：' + (CFG.xray ? '开' : '关');
  bx.style.borderColor = CFG.xray ? PAL.P213 : '';
}
const btnXr = document.getElementById('btnXray');
if (btnXr){
  btnXr.addEventListener('click', ()=>{
    CFG.dev = true; diffName = 'custom';
    devToggleXray();
  });
}
const btnTm = document.getElementById('btnTime');
if (btnTm){
  btnTm.addEventListener('click', ()=>{
    CFG.dev = true; diffName = 'custom';
    devCycleTime();
  });
}
/* 静步模式：默认长按，改成"点击切换"后就不用一直按着了 */
const btnWalk = document.getElementById('btnWalk');
function syncWalkBtn(){
  if (!btnWalk) return;
  btnWalk.textContent = '静步：' + (CFG.walkToggle ? '点击切换' : '长按');
  btnWalk.style.borderColor = CFG.walkToggle ? PAL.P44 : '';
}
if (btnWalk){
  btnWalk.addEventListener('click', ()=>{
    CFG.walkToggle = !CFG.walkToggle;
    if (player){ player.walkToggleOn = false; player.walkKeyPrev = false; }
    syncWalkBtn(); saveCfg();
    setMsg(CFG.walkToggle ? '静步改成点击切换了' : '静步改回长按了', 2.0);
  });
  syncWalkBtn();
}

/* 视野外隐身：像"天气"一样随时切。任何关卡都能用，各关自己的雾不受影响（是 OR，不是覆盖） */
const btnFog = document.getElementById('btnFog');
function syncFogBtn(){
  if (!btnFog) return;
  btnFog.textContent = '视野：' + (CFG.fogVision ? '锥子外不可见' : '正常');
  btnFog.style.borderColor = CFG.fogVision ? PAL.P44 : '';
}
if (btnFog){
  btnFog.addEventListener('click', ()=>{
    CFG.fogVision = !CFG.fogVision;
    setMsg(CFG.fogVision
      ? '视野外隐身：敌人不在视野锥里就不显示（热成像 / 透视照旧有效）'
      : '视野恢复：敌人照常可见', 2.2);
    syncFogBtn(); saveCfg();
  });
  syncFogBtn();
}

/* 视野锥画风：柔和（默认，像一束光）/ 经典（多边形硬边，信息最清楚）。随时可切 */
const btnCone = document.getElementById('btnCone');
function coneSoftOn(){ return CFG.coneStyle !== 'classic'; }
/* 视野锥整体不透明度：0（完全看不见）~1（原样）。人一多几十个锥子叠起来就是一片白雾，
   玩家自己在「画质」里调；0.35~0.6 在二十人以上的场面里最舒服。 */
function coneAlphaK(){ const v = (typeof CFG !== 'undefined' && typeof CFG.coneAlpha === 'number') ? CFG.coneAlpha : 1; return Math.max(0, Math.min(1, v)); }
/* m32306：玩家声纹圈的透明度。0 时整圈不画。 */
/* m33507：脚步声 / 环境声音量系数（0~1，缺省 1）。都是纯听觉项，不改任何机制。 */
function stepVolK(){
  const v = (typeof CFG !== 'undefined' && typeof CFG.stepVol === 'number') ? CFG.stepVol : 75;
  return Math.max(0, Math.min(1, v / 100));
}
function ambVolK(){
  const v = (typeof CFG !== 'undefined' && typeof CFG.ambVol === 'number') ? CFG.ambVol : 80;
  return Math.max(0, Math.min(1, v / 100));
}

function hearRingAlphaK(){ const v = (typeof CFG !== 'undefined' && typeof CFG.hearRingA === 'number') ? CFG.hearRingA : 1; return Math.max(0, Math.min(1, v)); }
function syncConeBtn(){
  if (!btnCone) return;
  btnCone.textContent = '视野锥：' + (coneSoftOn() ? '柔和' : '经典');
  btnCone.style.borderColor = coneSoftOn() ? PAL.P44 : '';
}
if (btnCone){
  btnCone.addEventListener('click', ()=>{
    CFG.coneStyle = coneSoftOn() ? 'classic' : 'soft';
    setMsg(coneSoftOn()
      ? '视野锥：柔光（边缘发光，看不出锯齿）'
      : '视野锥：经典（多边形硬边，射程/角度最清楚）', 2.2);
    syncConeBtn(); saveCfg();
  });
  syncConeBtn();
}

/* m32556：开发者入口默认隐藏，玩家与开发功能彻底隔离。
   解锁方式：面板标题「自定义参数」3 秒内连点 10 次（**不给任何视觉反馈**）。
   解锁状态存 localStorage，关掉浏览器再进也还在；
   只有把「开发者模式」按成关，才会重新上锁 + 参数全回默认 + 「开发」标签瞬间消失。 */
const DEV_UNLOCK_KEY = 'after5_devUnlock';
let devUnlocked = false;
try { devUnlocked = (localStorage.getItem(DEV_UNLOCK_KEY) === '1'); } catch(e){}
function devUnlockSave(){
  try { localStorage.setItem(DEV_UNLOCK_KEY, devUnlocked ? '1' : '0'); } catch(e){}
}
function devUnlockSync(){
  if (tabDevEl) tabDevEl.style.display = devUnlocked ? '' : 'none';
  if (!devUnlocked && panelTab === 'dev') setPanelTab('cfg');
}
{ /* 标题十连点：3 秒内点够 10 下就解锁，没有任何画面/提示反馈 */
  const _tp = document.getElementById('panelTitle');
  let _t0 = 0, _n = 0;
  if (_tp) _tp.addEventListener('click', ()=>{
    const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    if (!_t0 || (now - _t0) > 3000){ _t0 = now; _n = 1; }
    else { _n++; }
    if (_n >= 10){
      _n = 0; _t0 = 0;
      if (!devUnlocked){ devUnlocked = true; devUnlockSave(); devUnlockSync(); }
    }
  });
}

/* 开发者模式总开关：显式打开/关闭（拖动任何滑块仍然会自动打开） */
const btnDevOn = document.getElementById('btnDevOn');
/* m32812：面板上的开关文字必须永远跟着 CFG.dev 走。
   以前只有点这个按钮时才刷新，于是局内自动放行 / 进出死亡地带改了 CFG.dev 之后
   面板还显示旧文字（玩家看到"关"但开发者模式其实是开的，关卡列表里还挂着测试区）。 */
const _DEV_HINT_HTML = (function(){ const h = document.getElementById('hint'); return h ? h.innerHTML : ''; })();
function syncDevBtn(){
  if (!btnDevOn) return;
  btnDevOn.textContent = '开发者模式：' + (CFG.dev ? '开' : '关');
  btnDevOn.style.borderColor = CFG.dev ? PAL.P44 : '';
  if (typeof godSyncBoxVisible === 'function') godSyncBoxVisible();
  const h = document.getElementById('hint');
  if (h && _DEV_HINT_HTML){
    h.innerHTML = CFG.dev
      ? '<b style="color:#8ce8a8">开发者模式：已开启</b><br>' + _DEV_HINT_HTML
      : '<b style="color:#ffb066">开发者模式：未开启</b> —— 解锁只是把「开发」页露出来，要生效请点「开发者模式：开」<br>' + _DEV_HINT_HTML;
  }
}
if (btnDevOn){
  btnDevOn.addEventListener('click', (ev)=>{
    if (ev && ev.__devToggled) return;   /* 防重复触发：两个监听器各处理一次会"点了开立刻又关" */
    if (ev) ev.__devToggled = true;
    const wasOn = !!CFG.dev;
    CFG.dev = !CFG.dev;
    CFG.devExplicit = CFG.dev;      /* 手动点亮 = 允许记住；手动关掉 = 连记忆一起清 */
    if (wasOn && !CFG.dev){
      devDisable();
    }
    syncDevBtn();
    saveCfg();
  });
  syncDevBtn();
}
devUnlockSync();   /* 开局按存档决定「开发」标签露不露 */

/* ================= 清空全部数据（三次确认，点完刷新 = 闪退重进） ================= */
/* 用户 m33834：开发页要一个"回到刚下载这个安装包"的按钮。
   本地所有东西都在 localStorage 里（仓库 / 三个存档位 / 设置 / 画面 / 按键 / 开发者解锁标记），
   所以清空 localStorage + 刷新就是"新装的软件"。三次确认是防手滑 —— 这个没法撤销。 */
let _wipeStep = 0, _wipeT = 0;
const btnWipeAll = document.getElementById('btnWipeAll');
function wipeLabelSync(){
  if (!btnWipeAll) return;
  btnWipeAll.textContent = _wipeStep <= 0 ? '清空全部数据'
    : _wipeStep === 1 ? '再点一次确认（1/3）'
    : _wipeStep === 2 ? '真的要清空？（2/3）' : '最后确认，点完就刷新（3/3）';
  btnWipeAll.style.borderColor = _wipeStep <= 0 ? 'rgba(255,120,110,0.7)' : 'rgba(255,90,80,1)';
  btnWipeAll.style.color = _wipeStep <= 0 ? '#ff9a8a' : '#ffd0c8';
  btnWipeAll.style.background = _wipeStep >= 2 ? 'rgba(120,20,16,0.55)' : '';
}
function wipeReset(){ _wipeStep = 0; _wipeT = 0; wipeLabelSync(); }
function wipeAllData(){
  try{ localStorage.clear(); }catch(e){}
  try{ sessionStorage.clear(); }catch(e){}
  /* 内存里的东西也清一遍，免得刷新前的那一帧还带着旧数据（刷新本来就会重来，这里是保险） */
  try{
    if (typeof CFG === 'object' && CFG) for (const k of Object.keys(CFG)) delete CFG[k];
  }catch(e){}
  try{ location.reload(); }catch(e){}
}
if (btnWipeAll){
  btnWipeAll.addEventListener('click', ()=>{
    const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    if (_wipeStep > 0 && (now - _wipeT) > 6000) _wipeStep = 0;   /* 6 秒没接着点就当没点过 */
    _wipeT = now;
    _wipeStep++;
    if (_wipeStep < 4){ wipeLabelSync(); return; }
    _wipeStep = 0;
    wipeAllData();
  });
  wipeLabelSync();
}

const btnHeat = document.getElementById('btnHeatInf');if (btnHeat){
  btnHeat.addEventListener('click', ()=>{
    CFG.heatInf = !CFG.heatInf; CFG.dev = true;
    btnHeat.textContent = '热成像无限：' + (CFG.heatInf ? '开' : '关');
    btnHeat.style.borderColor = CFG.heatInf ? PAL.P44 : '';
    saveCfg();
  });
}
/* AI 弧线走路：把 DataMOVE.on 跟 CFG.aiArc 对齐。数据层缺这个表时静默跳过 */
function applyAiArc(){
  if (typeof DataMOVE === 'object' && DataMOVE) DataMOVE.on = !!CFG.aiArc;
  return !!(typeof DataMOVE === 'object' && DataMOVE && DataMOVE.on);
}
function syncAiArcBtn(){
  const b = document.getElementById('btnAiArc');
  if (!b) return;
  const on = applyAiArc();
  b.textContent = 'AI 弧线走路：' + (on ? '开' : '关');
  b.style.borderColor = on ? PAL.P44 : '';
}
{
  const _bArc = document.getElementById('btnAiArc');
  if (_bArc) _bArc.addEventListener('click', ()=>{
    CFG.aiArc = !CFG.aiArc;
    applyAiArc(); syncAiArcBtn(); saveCfg();
    setMsg(CFG.aiArc ? 'AI 弧线走路：开（拐角会走弧线、急转会减速）' : 'AI 弧线走路：关（沿寻路方向硬切）', 2.0);
  });
}
syncAiArcBtn();   /* 开局按存档把开关的字刷对 */

/* 开发者的三个开关：无限子弹 / 无限药品 / 打药秒好。全走 CFG.dev*，不开自定义参数时一律关 */
/* m33225："开发者功能对玩家可见"的统一判定 —— 必须有解锁，且开发者模式真的开着。
   以前选关只判 CFG.dev，于是只要 dev 因为任何一条路径被置 true（存档还原、出局还原、
   局内切换……）测试图就会漏出来，哪怕玩家从没解锁过开发页。 */
function devUiOn(){
  const unlocked = (typeof devUnlocked !== 'undefined') && !!devUnlocked;
  return unlocked && !!(typeof CFG !== 'undefined' && CFG && CFG.dev);
}

function syncDevCheats(){
  const map = [['btnInfAmmo','devInfAmmo','无限子弹'],
               ['btnInfMed','devInfMed','无限药品'],
               ['btnNoHealCd','devNoHealCd','打药秒好'],
               ['btnHurtNum','showHurt','受伤数字']];
  /* 一击必杀单独一档：**不需要**开开发者模式 */
  {
    const b1 = document.getElementById('btnOneShot');
    if (b1){
      const on1 = oneShotOn();
      b1.textContent = '一击必杀：' + (on1 ? '开' : '关');
      b1.style.borderColor = on1 ? PAL.P44 : '';
    }
  }
  for (const it of map){
    const b = document.getElementById(it[0]);
    if (!b) continue;
    const on = !!(CFG.dev && CFG[it[1]]);
    b.textContent = it[2] + '：' + (on ? '开' : '关');
    b.style.borderColor = on ? PAL.P44 : '';
  }
  if (typeof syncDevBtn === 'function') syncDevBtn();
}
function devToggleCheat(key, label){
  CFG.dev = true;
  CFG[key] = !CFG[key];
  syncDevCheats();
  setMsg('开发者 · ' + label + ' ' + (CFG[key] ? '开' : '关'), 1.6);
  logWarn('dev', '开发者 · ' + label + ' ' + (CFG[key] ? '开启' : '关闭'));
}
function devToggleInfAmmo(){ devToggleCheat('devInfAmmo', '无限子弹'); }
function devToggleInfMed(){ devToggleCheat('devInfMed', '无限药品'); }
function devToggleNoHealCd(){ devToggleCheat('devNoHealCd', '打药秒好'); }
[['btnOneShot', ()=>{
    /* 必须按"当前实际是否生效"来翻，而且两个来源一起关：
       沙盒全开（I）会把 CFG.devDmg 也点亮，只翻 CFG.oneShot 的话按钮永远关不掉。 */
    const on = oneShotOn();
    CFG.oneShot = !on; CFG.devDmg = !on;
    syncDevCheats(); saveCfg();
    setMsg(on ? '一击必杀：关（沙盒里的那一份也关了）' : '一击必杀：开', 1.6); }],
   ['btnInfAmmo', devToggleInfAmmo], ['btnInfMed', devToggleInfMed], ['btnNoHealCd', devToggleNoHealCd],
   ['btnHurtNum', ()=>{ CFG.showHurt = !CFG.showHurt; syncDevCheats(); saveCfg();
                        setMsg(CFG.showHurt ? '受伤数字：开' : '受伤数字：关', 1.4); }]]
  .forEach(function(pair){ const b = document.getElementById(pair[0]); if (b) b.addEventListener('click', pair[1]); });
syncDevCheats();   /* 开局按存档把「一击必杀」这些按钮的字刷对 */

/* ---------- 战斗 BGM（战斗，爽！！专用，程序生成的鼓点 + 低音） ---------- */
let musicOn = true;
try { musicOn = localStorage.getItem('after5_music') !== '0'; } catch(e){}

/* 震屏开关：默认开，玩家可以关。一直连杀的时候震得太多会烦 */
let shakeOn = true;
try { shakeOn = localStorage.getItem('after5_shake') !== '0'; } catch(e){}

function syncShakeBtn(){
  const b = document.getElementById('btnShake');
  if (b){
    b.textContent = '震屏：' + (shakeOn ? '开' : '关');
    b.style.borderColor = shakeOn ? PAL.P44 : '';
  }
}
let musT = 0, musBeat = 0;

function syncMusicBtn(){
  const b = document.getElementById('btnMusic');
  if (b){
    b.textContent = '音乐：' + (musicOn ? '开' : '关');
    b.style.borderColor = musicOn ? PAL.P44 : '';
  }
}

/* ================= 死亡地带 · 开发者模式二次确认 =================
   规则（用户 m15467）：在对局里打开开发者模式 → 先弹一次警告；
   玩家坚持打开，就把"当前难度的仓库"标记成作弊存档（面板上会写明，并给一键清空）。
   不在死亡地带里就不弹（故事关/割草不涉及仓库）。 */
let devGateAsk = false, devGatePassed = false;

function devGateReset(){ devGateAsk = false; devGatePassed = false; }

/* 仓库标记只记录历史。进局只读取当前开关，出局还原局外设置。 */
let devGlobalBeforeDz = null;
function devDisable(){
  devGateAsk = false;
  if (devGlobalBeforeDz !== null) devGlobalBeforeDz = false;
  devUnlocked = false;
  devUnlockSave();
  if (typeof godSetOn === 'function') godSetOn(false);
  if (player) player.god = false;
  CFG.devSandbox = CFG.devInfAmmo = CFG.devInfMed = CFG.devNoHealCd = false;
  devTimeScale = 1;
  devSpawnOpen = false;
  if (typeof devItemOpen !== 'undefined') devItemOpen = false;
  devPlaceCancel();
  resetDevCfg();
  if (dzSavedCfg){
    Object.assign(dzSavedCfg, CFG);
    dzSavedDiff = diffName;
    applyPreset(dzTier === 'core' ? 'hard' : dzTier, true, false);
  }
  devUnlockSync();
}
function devEnterDzTier(tier, benchmark = false){
  const on = !benchmark && devUiOn();
  if (devGlobalBeforeDz === null) devGlobalBeforeDz = devUiOn();
  devGateReset();
  if (on) devGateApprove(tier);
}
/* 入场的难度预设会清掉 CFG.dev，只有已打标的对局才能恢复。 */
function devApplyDzTier(){
  CFG.dev = devGatePassed && devUnlocked;
  syncDevCheats();
}
function devLeaveDz(){
  if (devGlobalBeforeDz === null) return;
  CFG.dev = devGlobalBeforeDz && devUnlocked;
  CFG.devExplicit = CFG.dev;
  devGlobalBeforeDz = null;
  devGateReset();
  if (typeof syncDevCheats === "function") syncDevCheats();
  if (typeof syncDevBtn === 'function') syncDevBtn();
}

function devGateTick(){
  if (devGatePassed || devGateAsk) return;
  if (typeof dzLvl === 'undefined' || !dzLvl) return;
  if (state !== 'play') return;
  if (!(typeof CFG !== 'undefined' && CFG && CFG.dev)) return;
  devGateAsk = true;
  uiButtons = [];
  mouse.down = false; mouse.fire = false;
  for (const k in keys) keys[k] = false;   /* 弹窗时先把按住的键松开，别让玩家一边走一边点 */
}

function devGateApprove(tier){
  stashMarkDirty(tier);
  devGatePassed = true;
}

/* 确认/取消的唯一入口：按钮和键盘（Y/Enter 开，N/Esc 关）都走这里 */
function devGateAnswer(ok){
  if (!devGateAsk) return;
  devGateAsk = false;
  if (ok){
    devGateApprove(dzTier);
    setMsg('开发者模式已开启 · 「' + (typeof DZ_TIER_LABEL !== 'undefined' ? (DZ_TIER_LABEL[dzTier] || dzTier) : dzTier) + '」仓库已标记', 2.6);
  } else {
    devDisable();
    if (typeof setMsg === 'function') setMsg('开发者模式已关闭', 1.8);
  }
}

function drawDevGate(){
  if (!devGateAsk) return;
  uiButtons = [];
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,0.62)';
  ctx.fillRect(0, 0, W, H);
  const bw = Math.min(660, W - 120), bh = 260;
  const bx = (W - bw) / 2, by = (H - bh) / 2;
  ctx.fillStyle = 'rgba(16,20,26,0.97)';
  roundRect(bx, by, bw, bh, 12); ctx.fill();
  ctx.strokeStyle = 'rgba(255,170,90,0.75)'; ctx.lineWidth = 2;
  roundRect(bx, by, bw, bh, 12); ctx.stroke();

  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(255,190,120,0.98)';
  ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
  ctx.fillText('你正在死亡地带对局里打开开发者模式', W / 2, by + 52);

  ctx.fillStyle = 'rgba(226,232,240,0.92)';
  ctx.font = '14px "Microsoft YaHei",sans-serif';
  ctx.fillText('确认之后，' + (typeof DZ_TIER_LABEL !== 'undefined' ? ('「' + (DZ_TIER_LABEL[dzTier] || dzTier) + '」') : '当前难度') +
    '的仓库会被打上「开过开发者模式」的标记，', W / 2, by + 92);
  ctx.fillText('表示里面的东西不是你自己打出来的。面板里会给一个"清空这个仓库"的按钮，随时能重来。', W / 2, by + 116);
  ctx.fillStyle = 'rgba(255,140,120,0.9)';
  ctx.fillText('取消会立刻关掉开发者模式（包括暂停、作弊开关）。', W / 2, by + 148);

  btn(W / 2 - 200, by + bh - 76, 180, 42, '开启（会打标记）', function(){ devGateAnswer(true); }, { primary: true });
  btn(W / 2 + 20, by + bh - 76, 180, 42, '取消（关掉开发者模式）', function(){ devGateAnswer(false); });
  flushButtons();
  ctx.restore();
  ctx.textAlign = 'left';
}

/* 车壳：纯代码画一辆带轮子的重型装甲车 */
/* 皮卡车身：引擎盖 → 前挡风 → 双排驾驶室 → 后挡风 → 敞篷车斗 → 尾门。
   从上往下看的角度画，所以"窗户"是侧面两条暗带，"挡风玻璃"是前后的梯形。 */
function drawPickupBody(ctx, e, o){
  const hw = o.hw, hh = o.hh;
  const body = o.body, plate = o.plate, edge = o.edge;
  const wr = !!e.wreck;
  const dark = wr ? '#2a2620' : '#15181c';
  const glass = wr ? '#2f3338' : 'rgba(96,132,158,0.92)';
  const L = hw;                 /* 车头是 +x */

  /* 车斗地板（后段） */
  const bedX0 = -L + 3, bedX1 = -6;
  ctx.fillStyle = wr ? '#242019' : '#2f3a2c';
  ctx.fillRect(bedX0, -hh + 2, bedX1 - bedX0, hh * 2 - 4);
  /* 车斗侧板 + 尾门 */
  ctx.strokeStyle = wr ? '#3a352b' : o.edge;
  ctx.lineWidth = 2;
  ctx.strokeRect(bedX0 + 0.5, -hh + 1.5, (bedX1 - bedX0) - 1, hh * 2 - 3);
  ctx.fillStyle = wr ? '#332f26' : '#5b4a33';
  ctx.fillRect(bedX0, -hh, 3, hh * 2);                       /* 尾门 */
  /* 车斗里横着的加强筋 */
  ctx.strokeStyle = wr ? 'rgba(30,26,20,0.6)' : 'rgba(18,26,18,0.45)';
  ctx.lineWidth = 1.1;
  for (let i = 1; i <= 4; i++){
    const bx = bedX0 + 6 + i * 6;
    ctx.beginPath(); ctx.moveTo(bx, -hh + 3); ctx.lineTo(bx, hh - 3); ctx.stroke();
  }
  /* 车斗里扔的两个木箱 */
  if (!wr){
    ctx.fillStyle = '#6b5738';
    ctx.fillRect(-L + 10, -hh + 5, 11, 8);
    ctx.fillRect(-L + 10, hh - 13, 11, 8);
    ctx.strokeStyle = 'rgba(24,20,14,0.8)'; ctx.lineWidth = 1;
    ctx.strokeRect(-L + 10.5, -hh + 5.5, 10, 7);
    ctx.strokeRect(-L + 10.5, hh - 12.5, 10, 7);
  }

  /* 后挡风（驾驶室与车斗之间的斜玻璃） */
  ctx.fillStyle = glass;
  ctx.beginPath();
  ctx.moveTo(-6, -hh + 3); ctx.lineTo(-1, -hh + 1.5);
  ctx.lineTo(-1, hh - 1.5); ctx.lineTo(-6, hh - 3);
  ctx.closePath(); ctx.fill();

  /* 驾驶室车顶 */
  ctx.fillStyle = wr ? '#33302a' : mixHex(plate, '#0c110c', 0.18);
  ctx.fillRect(-2, -hh + 1, 17, hh * 2 - 2);
  ctx.strokeStyle = edge; ctx.lineWidth = 2.2;
  ctx.strokeRect(-2, -hh + 1, 17, hh * 2 - 2);
  /* 两侧车窗（两条暗带） */
  ctx.fillStyle = glass;
  ctx.fillRect(0, -hh + 1.2, 13, 3.4);
  ctx.fillRect(0, hh - 4.6, 13, 3.4);
  /* 车顶加强筋 / 行李架 */
  ctx.strokeStyle = wr ? 'rgba(140,120,90,0.35)' : 'rgba(20,30,20,0.35)';
  ctx.lineWidth = 1.2;
  for (const rx of [3, 8, 13]){
    ctx.beginPath(); ctx.moveTo(rx, -hh + 2); ctx.lineTo(rx, hh - 2); ctx.stroke();
  }

  /* 前挡风：驾驶室到引擎盖之间的梯形 */
  ctx.fillStyle = glass;
  ctx.beginPath();
  ctx.moveTo(15, -hh + 1.5); ctx.lineTo(21, -hh + 4);
  ctx.lineTo(21, hh - 4); ctx.lineTo(15, hh - 1.5);
  ctx.closePath(); ctx.fill();

  /* 引擎盖 */
  ctx.fillStyle = body;
  ctx.fillRect(20, -hh + 3, L - 23, hh * 2 - 6);
  ctx.strokeStyle = edge; ctx.lineWidth = 1.8;
  ctx.strokeRect(20, -hh + 3, L - 23, hh * 2 - 6);
  /* 盖上的两道折线 */
  ctx.strokeStyle = wr ? 'rgba(120,110,90,0.35)' : 'rgba(20,34,20,0.4)';
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(22, -hh * 0.45); ctx.lineTo(L - 4, -hh * 0.45); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(22, hh * 0.45); ctx.lineTo(L - 4, hh * 0.45); ctx.stroke();

  /* 前格栅 + 保险杠 */
  ctx.fillStyle = '#20242a';
  ctx.fillRect(L - 3, -hh + 4, 3, hh * 2 - 8);
  ctx.fillStyle = wr ? '#4a4a44' : '#8a939c';
  ctx.fillRect(L - 1.5, -hh + 5, 2, hh * 2 - 10);

  /* 两盏大灯 + 照出去的一点光 */
  if (!wr){
    ctx.fillStyle = 'rgba(255,238,190,0.95)';
    ctx.fillRect(L - 4, -hh + 4.5, 3, 3.4);
    ctx.fillRect(L - 4, hh - 7.9, 3, 3.4);
    const _fl = e.paralyzed ? (0.3 + 0.7 * Math.max(0, Math.sin(uiT * 13.7) * Math.sin(uiT * 5.3))) : 1;
    const gr = ctx.createRadialGradient(L + 6, 0, 2, L + 6, 0, 72);
    gr.addColorStop(0, 'rgba(255,236,180,' + (0.18 * _fl).toFixed(3) + ')');
    gr.addColorStop(1, 'rgba(255,236,180,0)');
    ctx.fillStyle = gr;
    ctx.beginPath(); ctx.arc(L + 6, 0, 72, 0, TAU); ctx.fill();
    /* 尾灯 */
    ctx.fillStyle = 'rgba(255,92,72,0.85)';
    ctx.fillRect(-L + 0.5, -hh + 3, 2.5, 5);
    ctx.fillRect(-L + 0.5, hh - 8, 2.5, 5);
  }

  /* 驾驶室后面的防滚架（参考图里那两道横杆） */
  ctx.strokeStyle = wr ? '#4a453c' : '#39423a';
  ctx.lineWidth = 2.4;
  ctx.beginPath(); ctx.moveTo(-3, -hh - 1.5); ctx.lineTo(-3, hh + 1.5); ctx.stroke();
  ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(-5, -hh - 1); ctx.lineTo(-5, hh + 1); ctx.stroke();

  /* 后视镜 */
  if (!wr){
    ctx.fillStyle = '#2a3038';
    ctx.fillRect(17, -hh - 4, 4, 2.6);
    ctx.fillRect(17, hh + 1.4, 4, 2.6);
  }

  /* 环境光：整车上压一层暗色，让亮度跟地面/墙对齐（不然像贴图贴上去的） */
  ctx.fillStyle = 'rgba(10,16,12,0.22)';
  ctx.fillRect(-L, -hh - 1, L * 2, hh * 2 + 2);
  /* 泥点/划痕：固定几个位置，看起来是"用过的工具车" */
  if (!wr){
    ctx.fillStyle = 'rgba(24,20,14,0.35)';
    ctx.fillRect(-L + 5, -hh + 2.5, 9, 3);
    ctx.fillRect(-L + 16, hh - 6, 7, 2.6);
    ctx.fillRect(23, -hh * 0.55, 10, 2.4);
    ctx.fillStyle = 'rgba(150,150,130,0.10)';
    ctx.fillRect(-2, -hh + 1, 17, hh * 2 - 2);
  }
}

/* 驾驶室：两种厢式车共用（斜挡风 + 两盏大灯 + 灯光锥） */
function drawTruckCab(ctx, e, hw, hh){
  ctx.fillStyle = e.wreck ? '#22252a' : '#12161b';
  ctx.beginPath();
  ctx.moveTo(hw - 13, -hh + 5); ctx.lineTo(hw, -hh + 12);
  ctx.lineTo(hw, hh - 12); ctx.lineTo(hw - 13, hh - 5);
  ctx.closePath(); ctx.fill();
  if (e.wreck) return;
  ctx.fillStyle = 'rgba(255,236,180,0.95)';
  ctx.beginPath(); ctx.arc(hw - 2, -hh + 9, 2.8, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.arc(hw - 2, hh - 9, 2.8, 0, TAU); ctx.fill();
  if (e.tstate === 'wreck') return;
  /* 瘫痪的车电路坏了：大灯忽明忽暗，闪得没规律才像坏了 */
  const _fl = e.paralyzed ? (0.30 + 0.70 * Math.max(0, Math.sin(uiT * 13.7 + e.x * 0.11) * Math.sin(uiT * 5.3 + 1.1))) : 1;
  const gr = ctx.createRadialGradient(hw + 6, 0, 2, hw + 6, 0, 78);
  gr.addColorStop(0, 'rgba(255,236,180,' + (0.20 * _fl).toFixed(3) + ')');
  gr.addColorStop(1, 'rgba(255,236,180,0)');
  ctx.fillStyle = gr;
  ctx.beginPath(); ctx.arc(hw + 6, 0, 78, 0, TAU); ctx.fill();
}

/* 运兵车：**帆布篷 + 后门** —— 轮廓要跟装甲运兵车一眼分开。
   装甲车是硬壳斜面+侧裙板，运兵车是"卡车拉了一车人"：车顶是软篷、有横向褶皱、
   车尾两扇对开门，两侧还有长凳扶手。 */
function drawTruckBody(ctx, e, o){
  const hw = o.hw, hh = o.hh, body = o.body, plate = o.plate, edge = o.edge;
  const wr = !!e.wreck;
  ctx.fillStyle = body;
  ctx.fillRect(-hw, -hh, hw * 2, hh * 2);
  ctx.strokeStyle = edge; ctx.lineWidth = 2.6;
  ctx.strokeRect(-hw, -hh, hw * 2, hh * 2);

  /* 车厢底板（前半截是驾驶室，后半截装人） */
  const _c0 = -hw + 5, _c1 = hw - 15;
  ctx.fillStyle = wr ? '#2a2723' : '#3a3830';
  ctx.fillRect(_c0, -hh + 5, _c1 - _c0, hh * 2 - 10);

  /* 帆布篷：是一块绷在车斗上的布，不是几块木板并排放。
     所以要：② 横向（车宽方向）做柱状明暗 —— 中间鼓、两侧收，布才有"鼓起来"的体感；
     ③ seam 只留两道很淡的横向折痕，不再画成等分的格子；④ 两侧篷边打一圈绳扣。
     用户 m42531：原来的三分缝 + 平板色看起来像"车顶搭了两块木板"。 */
  const _tarp  = wr ? '#2a2924' : '#4b4a3c';
  const _tarpL = wr ? '#34332c' : '#5a5947';
  const _tarpD = wr ? '#1d1c18' : '#3a3a2f';
  ctx.beginPath();
  ctx.moveTo(_c0, -hh + 4);
  ctx.lineTo(_c1, -hh + 4);
  ctx.quadraticCurveTo(_c1 + 5, 0, _c1, hh - 4);
  ctx.lineTo(_c0, hh - 4);
  ctx.quadraticCurveTo(_c0 - 4, 0, _c0, -hh + 4);
  ctx.closePath();
  /* 柱面渐变：光从左上，布面从边到边先亮后暗 */
  const _tg = ctx.createLinearGradient(0, -hh + 4, 0, hh - 4);
  _tg.addColorStop(0.00, _tarpD);
  _tg.addColorStop(0.18, _tarp);
  _tg.addColorStop(0.46, _tarpL);
  _tg.addColorStop(0.72, _tarp);
  _tg.addColorStop(1.00, _tarpD);
  ctx.fillStyle = _tg;
  ctx.fill();
  ctx.strokeStyle = _tarpD; ctx.lineWidth = 1.1; ctx.stroke();

  /* 两道很淡的横向折痕（布被绳子勒出来的褶），位置不等分 */
  ctx.lineCap = 'round';
  for (const _fx of [0.30, 0.66]){
    const _x = _c0 + (_c1 - _c0) * _fx;
    ctx.strokeStyle = wr ? 'rgba(14,14,11,0.30)' : 'rgba(26,26,21,0.26)';
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(_x - 1.5, -hh + 5);
    ctx.quadraticCurveTo(_x + 3.5, 0, _x - 0.5, hh - 5);
    ctx.stroke();
    ctx.strokeStyle = wr ? 'rgba(70,68,58,0.16)' : 'rgba(150,148,120,0.16)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(_x + 1.4, -hh + 5);
    ctx.quadraticCurveTo(_x + 6.0, 0, _x + 2.4, hh - 5);
    ctx.stroke();
  }
  /* 中脊：布被撑起来的那道高点，只留一条很短的亮线 */
  ctx.strokeStyle = wr ? 'rgba(90,88,74,0.35)' : 'rgba(168,166,134,0.34)';
  ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(_c0 + (_c1 - _c0) * 0.36, 0.6); ctx.lineTo(_c0 + (_c1 - _c0) * 0.62, 0.6); ctx.stroke();
  ctx.lineCap = 'butt';

  /* 篷边绳扣：沿着两条长边一排小孔，这是"布绑在车斗上"最省事的证据 */
  {
    const _n = 7;
    for (let i = 0; i < _n; i++){
      const _x = _c0 + 6 + (_c1 - _c0 - 12) * i / (_n - 1);
      for (const _sy of [-hh + 5.2, hh - 5.2]){
        ctx.fillStyle = wr ? 'rgba(12,12,10,0.55)' : 'rgba(18,18,14,0.50)';
        ctx.beginPath(); ctx.arc(_x, _sy, 1.25, 0, TAU); ctx.fill();
        ctx.fillStyle = wr ? 'rgba(120,112,88,0.30)' : 'rgba(196,188,150,0.32)';
        ctx.beginPath(); ctx.arc(_x - 0.5, _sy - 0.5, 0.55, 0, TAU); ctx.fill();
      }
    }
  }
  /* 车厢两侧的金属压条：把"篷布"和"车身"分开，轮廓才不像一块整板 */
  ctx.strokeStyle = wr ? '#3b3931' : '#6f6d5c';
  ctx.lineWidth = 1.8;
  ctx.beginPath(); ctx.moveTo(_c0 + 1, -hh + 4.5); ctx.lineTo(_c1 - 1, -hh + 4.5); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(_c0 + 1, hh - 4.5); ctx.lineTo(_c1 - 1, hh - 4.5); ctx.stroke();

  /* 车尾两扇对开门（合页 + 把手） */
  const _dw = 7;
  ctx.fillStyle = plate;
  ctx.fillRect(-hw + 2, -hh + 6, _dw, hh * 2 - 12);
  ctx.strokeStyle = edge; ctx.lineWidth = 1.2;
  ctx.strokeRect(-hw + 2, -hh + 6, _dw, hh * 2 - 12);
  ctx.beginPath(); ctx.moveTo(-hw + 2 + _dw * 0.5, -hh + 6); ctx.lineTo(-hw + 2 + _dw * 0.5, hh - 6); ctx.stroke();
  if (!wr){
    ctx.fillStyle = 'rgba(210,214,220,0.65)';
    ctx.fillRect(-hw + 5.4, -3.2, 2.2, 6.4);
  }

  /* 前装甲板（驾驶室后面那道隔板） */
  ctx.fillStyle = plate;
  ctx.fillRect(hw - 16, -hh + 6, 7, hh * 2 - 12);

  drawTruckCab(ctx, e, hw, hh);
}

/* 装甲运兵车：**硬壳斜面 + 侧裙板 + 尾部跳板** —— 轮廓方正、轮子被裙板盖掉一半，
   跟"帆布篷卡车"完全是两种东西。舱盖/观察窗仍由 drawTruck 后面那段画。 */
function drawApcBody(ctx, e, o){
  const hw = o.hw, hh = o.hh, body = o.body, plate = o.plate, edge = o.edge;
  const wr = !!e.wreck;
  /* 首上装甲：前脸切一刀，形成斜面（俯视角下就是两个斜角） */
  ctx.beginPath();
  ctx.moveTo(-hw, -hh); ctx.lineTo(hw - 12, -hh);
  ctx.lineTo(hw, -hh + 8); ctx.lineTo(hw, hh - 8);
  ctx.lineTo(hw - 12, hh); ctx.lineTo(-hw, hh);
  ctx.closePath();
  ctx.fillStyle = body; ctx.fill();
  ctx.strokeStyle = edge; ctx.lineWidth = 2.8; ctx.stroke();

  /* 侧裙板：盖住半个轮子 —— 装甲车最直观的特征 */
  ctx.fillStyle = plate;
  ctx.fillRect(-hw + 3, -hh - 5, hw * 2 - 10, 7);
  ctx.fillRect(-hw + 3, hh - 2, hw * 2 - 10, 7);
  ctx.strokeStyle = edge; ctx.lineWidth = 1.2;
  ctx.strokeRect(-hw + 3, -hh - 5, hw * 2 - 10, 7);
  ctx.strokeRect(-hw + 3, hh - 2, hw * 2 - 10, 7);

  /* 车顶装甲板：比车身压深一档、四周留一圈壳边，让人看出"这是顶盖"而不是一整块平板。
     m42531：原来车顶就是 body 那一整片，和侧裙/车头的明度差得突兀；现在顶盖由 body 混色得到，
     同色系压深，并加中脊、两道横筋、四角铆钉与一根潜望镜，俯视像装甲车的顶盖。 */
  const roof = wr ? 'rgba(24,27,31,0.92)' : mixHex(mixHex(body, '#0d1218', 0.23), plate, 0.12);
  const roofHi = wr ? 'rgba(70,74,80,0.25)' : mixHex(roof, '#c9d6e2', 0.16);
  const roofLo = 'rgba(8,11,15,0.42)';
  const rx0 = -hw + 13, rx1 = hw - 15, ry0 = -hh + 6.5, ry1 = hh - 6.5;
  ctx.fillStyle = roof;
  ctx.beginPath();
  ctx.moveTo(rx0, ry0); ctx.lineTo(rx1 - 5, ry0);
  ctx.lineTo(rx1, ry0 + 5); ctx.lineTo(rx1, ry1 - 5);
  ctx.lineTo(rx1 - 5, ry1); ctx.lineTo(rx0, ry1);
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = wr ? 'rgba(90,94,100,0.35)' : 'rgba(12,16,21,0.55)';
  ctx.lineWidth = 1.2; ctx.stroke();
  /* 顶盖内侧的一圈高光，制造"压边"的厚度感 */
  ctx.strokeStyle = roofHi; ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(rx0 + 2.5, ry0 + 2.5); ctx.lineTo(rx1 - 7, ry0 + 2.5);
  ctx.lineTo(rx1 - 2.5, ry0 + 7); ctx.lineTo(rx1 - 2.5, ry1 - 7);
  ctx.lineTo(rx1 - 7, ry1 - 2.5); ctx.lineTo(rx0 + 2.5, ry1 - 2.5);
  ctx.closePath(); ctx.stroke();

  /* 中脊 + 两道横筋 */
  ctx.fillStyle = wr ? 'rgba(20,22,25,0.55)' : 'rgba(12,16,21,0.34)';
  ctx.fillRect(rx0 + 4, -2.6, (rx1 - rx0) - 8, 5.2);
  ctx.fillStyle = roofHi;
  ctx.fillRect(rx0 + 4, -3.4, (rx1 - rx0) - 8, 1);
  for (const _bx of [-14, 6]){
    ctx.fillStyle = roofLo; ctx.fillRect(_bx, ry0 + 3, 3, (ry1 - ry0) - 6);
    ctx.fillStyle = roofHi; ctx.fillRect(_bx + 3, ry0 + 3, 0.9, (ry1 - ry0) - 6);
  }
  /* 四角 + 中部铆钉 */
  if (!wr){
    ctx.fillStyle = 'rgba(150,162,176,0.5)';
    for (const _bx of [rx0 + 3.5, rx1 - 4.5]){
      for (const _by of [ry0 + 3.5, 0, ry1 - 3.5]){
        ctx.beginPath(); ctx.arc(_bx, _by, 1.05, 0, TAU); ctx.fill();
      }
    }
  }

  /* 车长潜望镜：顶盖前部一个斜切小方块，装甲车的"眼" */
  if (!wr){
    ctx.save();
    ctx.translate(hw - 26, -hh + 11);
    ctx.rotate(-0.18);
    ctx.fillStyle = '#2c333b'; ctx.fillRect(-4, -3, 8, 6);
    ctx.strokeStyle = 'rgba(140,152,166,0.5)'; ctx.lineWidth = 0.9; ctx.strokeRect(-4, -3, 8, 6);
    ctx.fillStyle = 'rgba(12,16,20,0.9)'; ctx.fillRect(1.2, -2, 2.2, 4);
    ctx.restore();
  }

  /* 车顶中央装甲脊：一条压暗的长条，把顶面分成两块 */
  ctx.fillStyle = wr ? 'rgba(20,22,25,0.55)' : 'rgba(14,17,21,0.42)';
  ctx.fillRect(-hw + 10, -3.2, hw * 2 - 26, 6.4);

  /* 尾部跳板：两片合页 + 一道缝 */
  ctx.fillStyle = plate;
  ctx.fillRect(-hw + 1, -hh + 9, 9, hh * 2 - 18);
  ctx.strokeStyle = edge; ctx.lineWidth = 1.1;
  ctx.strokeRect(-hw + 1, -hh + 9, 9, hh * 2 - 18);
  ctx.beginPath(); ctx.moveTo(-hw + 5.5, -hh + 9); ctx.lineTo(-hw + 5.5, hh - 9); ctx.stroke();

  /* 侧工具箱（只有装甲车有：硬壳外挂件） */
  if (!wr){
    ctx.fillStyle = 'rgba(30,36,42,0.92)';
    ctx.fillRect(-hw + 22, -hh + 1.5, 12, 6);
    ctx.fillRect(-hw + 22, hh - 7.5, 12, 6);
    ctx.strokeStyle = 'rgba(130,142,155,0.45)'; ctx.lineWidth = 0.9;
    ctx.strokeRect(-hw + 22, -hh + 1.5, 12, 6);
    ctx.strokeRect(-hw + 22, hh - 7.5, 12, 6);
  }

  drawTruckCab(ctx, e, hw, hh);
}

function drawTruck(e){
  const T = vehicleDef(e && e.type) || enemyType(e);  /* 未知旧输入仍走原回退 */
  const a = e.visA === undefined ? 1 : e.visA;

  /* 车身尺寸/轮位/配色都从车型数据来（data/vehicles.js）：
     不写就还是基准运兵车那套 52/27 + 三个轮位 + 灰蓝配色。
     注意：这**只是外观**，碰撞盒始终是 TRUCK_BODY {HL:46, HW:20}。 */
  const hw = (T.bw || 52), hh = (T.bh || 27);
  const _wx = (T.wheelX && T.wheelX.length) ? T.wheelX : [-30, 0, 30];
  const _SK = T.skin || {};
  ctx.save();
  ctx.globalAlpha = a;

  /* 地上的影子 */
  ctx.fillStyle = 'rgba(8,10,12,0.34)';
  ctx.beginPath();
  ctx.ellipse(e.x + 5, e.y + 7, hw * 1.02, hh * 1.14, e.ang, 0, TAU);
  ctx.fill();

  ctx.translate(e.x + (e.ramOX || 0), e.y + (e.ramOY || 0));
  ctx.rotate(e.ang + (e.ramYaw || 0));

  /* 六个轮子：每侧三个，刹车时会锁死（不转） */
  const roll = (e.wheelRot || 0) + (e.tstate === 'drift_in' ? uiT * 34 : 0);
  const _wl = hw * 0.42, _wh = Math.max(7, hh * 0.33);
  ctx.fillStyle = '#15171b';
  for (const sx of _wx){
    for (const sy of [-hh - 3, hh + 3]){
      ctx.save();
      ctx.translate(sx, sy);
      ctx.fillRect(-_wl / 2, -_wh / 2, _wl, _wh);
      /* 轮子本体就一块黑胎，不画浅色花纹（俯视角下会像一圈梳齿）；
         "在转"交给开快车时的后轮扬尘去表现，见 truckDrive 里的 dustT */
      ctx.fillStyle = '#15171b';
      ctx.restore();
    }
  }

  /* 车身：底板上再盖一层装甲板
     归属染色：谁的车一眼要能看出来（A 蓝 / B 绿 / 中立灰 / 你的亮蓝），
     废铁不染，保持烧黑的样子 */  const _own = (typeof truckFaction === 'function') ? truckFaction(e) : 'enemy';
  const _ownTint = e.factionTint || ((typeof _ftint === 'function') ? _ftint(_own) : '#6d8fb8');
  const body = e.wreck ? (_SK.wreckBody || '#3a3f46')
             : mixHex((_SK.body || '#4a535f'), _ownTint, 0.42);
  const plate = e.wreck ? (_SK.wreckPlate || '#474c53')
              : mixHex((_SK.plate || '#5d6874'), _ownTint, 0.30);
  const edge = e.wreck ? (_SK.wreckEdge || '#22262b') : (_SK.edge || '#8b98a6');
  if (e.veh === 'pickup'){
    drawPickupBody(ctx, e, { hw, hh, body, plate, edge });
  } else if (e.veh === 'apc'){
    drawApcBody(ctx, e, { hw, hh, body, plate, edge });
  } else {
    drawTruckBody(ctx, e, { hw, hh, body, plate, edge });
  }

  /* 装甲运兵车（apc）：车顶一个圆舱盖 + 两侧三个观察窗，壳厚就显得"重" */
  /* m42690：装了车顶机枪的 APC 不画这个舱盖 —— 枪座那圈（下面 3088 起的 `if (_mg)`）
     会盖在同一个位置，两个圆叠着会像"洞上打了补丁"。 */
  if (e.veh === 'apc' && !e.wreck && !truckMgDef(e)){
    ctx.fillStyle = '#252b32';
    ctx.beginPath(); ctx.arc(-6, 0, 9.5, 0, TAU); ctx.fill();
    /* 舱盖：外圈钢环 + 铆钉 + 内圈偏心阴影（和运兵车转塔座同一套画法） */
    const _hg = ctx.createRadialGradient(-8.6, -2.6, 1, -6, 0, 10.5);
    _hg.addColorStop(0, 'rgba(170,182,196,0.30)');
    _hg.addColorStop(0.6, 'rgba(0,0,0,0)');
    _hg.addColorStop(1, 'rgba(0,0,0,0.30)');
    ctx.fillStyle = _hg;
    ctx.beginPath(); ctx.arc(-6, 0, 9.5, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(152,168,184,0.60)'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(-6, 0, 9.5, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(158,170,184,0.55)';
    for (let i = 0; i < 6; i++){
      const _a3 = i / 6 * TAU + 0.35;
      ctx.beginPath(); ctx.arc(-6 + Math.cos(_a3) * 7.3, Math.sin(_a3) * 7.3, 0.9, 0, TAU); ctx.fill();
    }
    ctx.fillStyle = '#171c22';
    ctx.beginPath(); ctx.arc(-6, 0, 3.4, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(8,11,15,0.55)';
    ctx.beginPath(); ctx.arc(-6.7, -0.7, 2.5, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(10,14,18,0.85)';
    for (const _sy of [-hh + 9, 0, hh - 9]){
      ctx.fillRect(hw - 30, _sy - 2.2, 9, 4.4);
    }
  }

  /* 车头保险杠的黄黑警示条 + 车尾两盏红尾灯，让轮廓在暗图里认得出来 */
  if (!e.wreck && e.veh !== 'pickup'){
    ctx.fillStyle = '#c9a227';
    ctx.fillRect(hw - 5, -hh + 2, 4, hh * 2 - 4);
    ctx.fillStyle = 'rgba(20,22,26,0.85)';
    for (let i = -hh + 3; i < hh - 4; i += 7) ctx.fillRect(hw - 5, i, 4, 3);
    ctx.fillStyle = 'rgba(255,92,72,0.85)';
    ctx.fillRect(-hw + 1, -hh + 6, 3, 7);
    ctx.fillRect(-hw + 1, hh - 13, 3, 7);
  }

  /* 车顶机枪：会真的转过来打你（逻辑见 truckMgTick）。没配 mg 的关卡/载具这里就只剩舱盖。 */
  {
    const _mg = truckMgDef(e);
    const _ma = (e.mgAng === undefined ? e.ang - Math.PI/2 : e.mgAng) - e.ang;
    if (_mg && !e.wreck){
      ctx.save();
      ctx.translate(-6, 0);
      ctx.rotate(_ma);
      /* 炮管：两根套管，看起来是"机枪"不是"铁棍" */
      ctx.fillStyle = '#1b1f25';
      ctx.fillRect(6, -3.6, 26, 7.2);
      ctx.fillStyle = '#39414b';
      ctx.fillRect(8, -2.2, 22, 2.4);
      /* 消焰器 */
      ctx.fillStyle = '#0f1216';
      ctx.fillRect(30, -4.6, 5, 9.2);
      /* 枪口焰 */
      if ((e.mgFlash || 0) > 0){
        const k = (e.mgFlash / 0.05);
        ctx.fillStyle = 'rgba(255,226,150,' + (0.85 * k).toFixed(2) + ')';
        ctx.beginPath(); ctx.moveTo(35, 0);
        ctx.lineTo(35 + 13 * k, -6 * k); ctx.lineTo(35 + 18 * k, 0);
        ctx.lineTo(35 + 13 * k, 6 * k); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    }
    /* 转塔座：一圈带铆钉的座圈，盖在炮管根部（没机枪的车不画）。
       m42531：原来是一个纯黑圆 + 一根黑棍，俯视像一个洞里插了根管子 —— 这里补座圈高光和铆钉。 */
    if (_mg){
    ctx.fillStyle = e.wreck ? '#26292e' : '#2c3037';
    ctx.beginPath(); ctx.arc(-6, 0, 11, 0, TAU); ctx.fill();
    const _rg = ctx.createRadialGradient(-9, -3, 1, -6, 0, 12);
    _rg.addColorStop(0, e.wreck ? 'rgba(120,124,130,0.20)' : 'rgba(168,178,190,0.26)');
    _rg.addColorStop(0.62, 'rgba(0,0,0,0)');
    _rg.addColorStop(1, 'rgba(0,0,0,0.25)');
    ctx.fillStyle = _rg;
    ctx.beginPath(); ctx.arc(-6, 0, 11, 0, TAU); ctx.fill();
    ctx.strokeStyle = _mg && e.mgRage > 0 ? '#c9a227' : edge;
    ctx.lineWidth = 1.6; ctx.stroke();
    /* 座圈铆钉 */
    ctx.fillStyle = e.wreck ? 'rgba(90,94,100,0.55)' : 'rgba(150,160,172,0.55)';
    for (let i = 0; i < 6; i++){
      const _a2 = i / 6 * TAU + 0.4;
      ctx.beginPath(); ctx.arc(-6 + Math.cos(_a2) * 8.6, Math.sin(_a2) * 8.6, 0.95, 0, TAU); ctx.fill();
    }
    ctx.fillStyle = '#20232a';
    ctx.beginPath(); ctx.arc(-6, 0, 4.2, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.30)';
    ctx.beginPath(); ctx.arc(-6.8, -0.8, 3.1, 0, TAU); ctx.fill();
    }
  }

  /* 侧门：往车尾滑开（皮卡是普通车门，不画这道滑门） */
  if (e.veh !== 'pickup'){
  const doorW = 26, doorShift = (e.door || 0) * doorW;
  ctx.fillStyle = e.wreck ? '#2a2d33' : '#464c56';
  ctx.fillRect(-14 - doorShift, hh - 2, doorW, 5);
  if ((e.door || 0) > 0.05 && !e.wreck){
    /* 门里那点亮 —— 让你知道"人就是从这里下来的" */
    ctx.fillStyle = 'rgba(255,214,140,' + (0.35 * e.door).toFixed(2) + ')';
    ctx.fillRect(-14, hh - 1, doorW, 4);
  }
  }

  /* 刚挨了枪：壳上闪一下白，配火花（不流血） */
  if (e.hitT > 0){
    ctx.globalAlpha = a * Math.min(1, e.hitT / 0.18) * 0.55;
    ctx.fillStyle = 'rgba(255,246,214,0.9)';
    ctx.fillRect(-hw, -hh, hw * 2, hh * 2);
    ctx.globalAlpha = a;
  }
  ctx.restore();

  /* F3 调试：红虚线 = 以前用的 AABB 判定盒（车一斜就比车身大一圈）；
     青实线 = 真正挡人的车身。开着它就能一眼看出"看到的"和"挡住的"差多少。
     注意：ctx 是代理对象，没有 setLineDash，虚线得自己一段段画。 */
  if (CFG.dbgHull){
    const rc = truckRect(e);
    ctx.save();
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = 'rgba(232,86,74,0.85)';
    ctx.beginPath();
    const _dash = 7, _gap = 5;
    const _edge = (x0, y0, x1, y1) => {
      const len = Math.hypot(x1 - x0, y1 - y0);
      const ux = (x1 - x0) / (len || 1), uy = (y1 - y0) / (len || 1);
      for (let d = 0; d < len; d += _dash + _gap){
        const e2 = Math.min(len, d + _dash);
        ctx.moveTo(x0 + ux * d, y0 + uy * d);
        ctx.lineTo(x0 + ux * e2, y0 + uy * e2);
      }
    };
    _edge(rc.x, rc.y, rc.x + rc.w, rc.y);
    _edge(rc.x + rc.w, rc.y, rc.x + rc.w, rc.y + rc.h);
    _edge(rc.x + rc.w, rc.y + rc.h, rc.x, rc.y + rc.h);
    _edge(rc.x, rc.y + rc.h, rc.x, rc.y);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(90,214,224,0.95)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    const _cs = truckCorners(e);
    ctx.moveTo(_cs[0].x, _cs[0].y);
    for (let _i = 1; _i < 4; _i++) ctx.lineTo(_cs[_i].x, _cs[_i].y);
    ctx.closePath();
    ctx.stroke();
    ctx.restore();
  }
  /* 过载哑火：车顶一条红条，让你看得出它"哑了" */
  if (e.mgOverheat){
    const H2 = mgHeatDef(truckMgDef(e) || {});
    const hw2 = 34, hx2 = e.x - hw2 / 2, hy2 = e.y - (e.r || 20) - 30;
    ctx.globalAlpha = a;
    ctx.fillStyle = 'rgba(8,10,14,0.78)';
    ctx.fillRect(hx2 - 1, hy2 - 1, hw2 + 2, 5);
    ctx.fillStyle = 'rgba(238,96,72,0.95)';
    ctx.fillRect(hx2, hy2, Math.max(2, hw2 * clamp((e.mgHeat || 0) / H2.max, 0, 1)), 3);
  }
  /* 血条：只要车还没被打烂就一直挂着（满血也挂）。
     以前是「被打过才画」，结果满血的车从外面看就是个没有血量的铁盒子，
     玩家根本不知道这东西能不能打穿、还要打几枪。废铁不挂条。 */
  if (!e.wreck && e.tstate !== 'gone'){
    const _hp = Math.max(0, Math.round(e.hp)), _mx = Math.max(1, Math.round(e.maxHp));
    const _k = clamp(e.hp / e.maxHp, 0, 1);
    const bw = 92, bh = 5, bx = e.x - bw / 2, by = e.y - e.r - 20;
    ctx.globalAlpha = a;
    ctx.fillStyle = 'rgba(10,12,16,0.72)';
    ctx.fillRect(bx - 1, by - 1, bw + 2, bh + 2);
    /* 满血是暗金、见血之后转亮金，快爆的时候偏红 */
    ctx.fillStyle = _k > 0.6 ? 'rgba(176,140,66,0.95)'
                  : (_k > 0.28 ? 'rgba(196,150,60,0.95)' : 'rgba(206,86,52,0.96)');
    ctx.fillRect(bx, by, bw * _k, bh);
    ctx.fillStyle = 'rgba(255,225,170,0.85)';
    ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(((T.label) || '运兵车') + ' ' + _hp + ' / ' + _mx, e.x, by - 5);
    /* 归属牌：血条左边一块小色牌，写「你 / A / B / 中」——
       以前只是血条右边一个 3.8px 的小点，还中立不画，等于看不出来是谁的车 */
    {
      const _fac = truckFaction(e);
      const _col = e.factionTint || ((typeof _ftint === 'function') ? _ftint(_fac) : '#6d8fb8');
      const _tag = (_fac === 'player') ? '你'
                 : (_fac === 'bandit') ? 'B'
                 : (_fac === 'neutral') ? '中' : 'A';
      const cw = 15, ch = 12, cx = bx - cw - 4, cy = by - (ch - bh) / 2;
      ctx.globalAlpha = a;
      ctx.beginPath(); ctx.roundRect(cx, cy, cw, ch, 3);
      ctx.fillStyle = 'rgba(10,14,19,0.82)'; ctx.fill();
      ctx.strokeStyle = _col; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.fillStyle = _col;
      ctx.font = 'bold 9px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(_tag, cx + cw / 2, cy + ch / 2 + 0.5);
      ctx.textBaseline = 'alphabetic';
    }
    if (e === playerTruck){
      ctx.fillStyle = 'rgba(150,214,255,0.95)';
      ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      const _cargo = (typeof truckIsCargo === 'function' && truckIsCargo(e));
      ctx.fillText('驾驶中 · ' + Math.round(Math.abs(e.spd)) + ' km/h'
        + (_cargo ? ('　货斗 ' + truckCargoOf(e).length + '/40 · Tab') : ''), e.x, by - 19);
      ctx.fillStyle = 'rgba(180,220,255,0.78)';
      ctx.fillText('WASD 开 · 左键 机枪 · T 下车', e.x, by + 30);
    } else if (playerTruck === null && truckCanDrive(e) &&
               dist(player.x, player.y, e.x, e.y) <= e.r + 104){
      ctx.fillStyle = 'rgba(150,214,255,0.90)';
      ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      if (!window.uiHideAll){
        const _cg = (typeof truckIsCargo === 'function' && truckIsCargo(e));
        ctx.fillText(_cg ? ('T 上车　Tab 货斗 ' + truckCargoOf(e).length + '/40') : 'T 上车', e.x, by + 18);
        ctx.fillStyle = 'rgba(150,214,255,0.62)';
        ctx.font = 'bold 9px "Microsoft YaHei",sans-serif';
      }
    }
    /* 瘫了：血条上面挂一条红底黑框的标签，一眼看得出"它动不了了" */
    if (e.paralyzed){
      const _pl = 0.55 + 0.45 * Math.sin(uiT * 6.5);
      const tw = 58, tx = e.x - tw / 2, ty = by - 30;
      ctx.fillStyle = 'rgba(10,12,16,0.82)';
      ctx.fillRect(tx, ty, tw, 14);
      ctx.fillStyle = 'rgba(196,52,40,0.92)';
      ctx.fillRect(tx, ty, tw, 14);
      ctx.fillStyle = 'rgba(255,236,226,' + (0.78 + 0.22 * _pl).toFixed(2) + ')';
      ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('瘫  痪', e.x, ty + 11);
    }
    ctx.globalAlpha = 1;
  }
}

/* ——— 画 ——— */
function drawMgNest(n){
  const D = mgNestDef();
  const hot = clamp((n.mgHeat || 0), 0, 1);
  const legA = n.ang;
  ctx.save();
  ctx.translate(n.x, n.y);

  /* ---- 地面：两层影子，脚下一坨实的、外面一圈虚的 ---- */
  ctx.fillStyle = 'rgba(6,8,11,0.32)';
  ctx.beginPath(); ctx.ellipse(5, 8, 34, 26, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(6,8,11,0.20)';
  ctx.beginPath(); ctx.ellipse(2, 4, 25, 18, 0, 0, TAU); ctx.fill();

  /* ---- 三脚架：三条腿（两条朝前、一条朝后），腿有粗细变化 + 脚盘 ---- */
  for (const off of [-0.72, 0.72, Math.PI]){
    const ax = Math.cos(legA + off), ay = Math.sin(legA + off);
    const bx = Math.cos(legA + off + 0.10), by = Math.sin(legA + off + 0.10);
    const kx = (ax + bx) * 0.5, ky = (ay + by) * 0.5;
    /* 腿的影子 */
    ctx.strokeStyle = 'rgba(0,0,0,0.42)'; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(ax * 6 + 1.5, ay * 6 + 2.5); ctx.lineTo(bx * 23 + 1.5, by * 23 + 2.5); ctx.stroke();
    /* 腿身：深色外皮 + 内芯，短而粗，别画成藤蔓 */
    ctx.strokeStyle = '#1c2126'; ctx.lineWidth = 6.2;
    ctx.beginPath(); ctx.moveTo(ax * 5, ay * 5); ctx.lineTo(bx * 23, by * 23); ctx.stroke();
    ctx.strokeStyle = '#333b43'; ctx.lineWidth = 3.6;
    ctx.beginPath(); ctx.moveTo(ax * 6, ay * 6); ctx.lineTo(bx * 22, by * 22); ctx.stroke();
    /* 膝盖处的接箍（让它看起来是机械腿，不是树枝） */
    ctx.fillStyle = '#454e58';
    ctx.beginPath(); ctx.arc(kx * 17, ky * 17, 3.1, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#14181c'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(kx * 17, ky * 17, 3.1, 0, TAU); ctx.stroke();
    /* 脚盘 */
    ctx.fillStyle = '#22282e';
    ctx.beginPath(); ctx.arc(bx * 24.5, by * 24.5, 4.8, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#525c66'; ctx.lineWidth = 1.1;
    ctx.beginPath(); ctx.arc(bx * 24.5, by * 24.5, 4.8, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#5b6672';
    ctx.beginPath(); ctx.arc(bx * 24.5, by * 24.5, 1.6, 0, TAU); ctx.fill();
  }

  /* ---- 中心座：带螺栓的圆盘 + 高低机 ---- */
  const hub = ctx.createRadialGradient(-2.5, -3, 1.5, 0, 0, 12);
  hub.addColorStop(0, '#5d6772'); hub.addColorStop(0.65, '#3a424b'); hub.addColorStop(1, '#272d33');
  ctx.fillStyle = hub;
  ctx.beginPath(); ctx.arc(0, 0, 11.5, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#171b1f'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.arc(0, 0, 11.5, 0, TAU); ctx.stroke();
  ctx.fillStyle = '#4a535d';
  for (let i = 0; i < 6; i++){
    const a2 = i * TAU / 6 + 0.4;
    ctx.beginPath(); ctx.arc(Math.cos(a2) * 8.4, Math.sin(a2) * 8.4, 1.4, 0, TAU); ctx.fill();
  }

  /* ---- 防盾：先画（在枪下面），朝向枪口的一块弧形钢板 ---- */
  ctx.save();
  ctx.rotate(n.ang);
  /* 板身：上下都比机匣高出两截，才看得出"这是一块盾" */
  ctx.fillStyle = 'rgba(52,61,71,0.97)';
  ctx.beginPath(); ctx.roundRect(8, -22, 7.5, 44, 3); ctx.fill();
  /* 上缘迎光 */
  ctx.fillStyle = 'rgba(160,176,192,0.38)';
  ctx.beginPath(); ctx.roundRect(8, -22, 2.4, 44, 1.4); ctx.fill();
  /* 下缘阴影 */
  ctx.fillStyle = 'rgba(0,0,0,0.38)';
  ctx.beginPath(); ctx.roundRect(13.6, -22, 1.9, 44, 1); ctx.fill();
  ctx.strokeStyle = 'rgba(132,146,162,0.90)'; ctx.lineWidth = 1.1;
  ctx.beginPath(); ctx.roundRect(8, -22, 7.5, 44, 3); ctx.stroke();
  /* 上下各一道加强筋 */
  ctx.strokeStyle = 'rgba(20,26,32,0.55)'; ctx.lineWidth = 1.4;
  for (const gy of [-14, 14]){
    ctx.beginPath(); ctx.moveTo(8.6, gy); ctx.lineTo(14.6, gy); ctx.stroke();
  }
  /* 铆钉（两列六颗） */
  ctx.fillStyle = '#737e8a';
  for (const ry of [-18, -6.5, 6.5, 18]){
    ctx.beginPath(); ctx.arc(10.6, ry, 1.25, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(13.2, ry, 1.25, 0, TAU); ctx.fill();
  }
  ctx.restore();

  /* ---- 枪身：跟着 mgAng 转 ---- */
  ctx.save();
  ctx.rotate(n.mgAng);

  /* 弹药箱（挂在机匣左边，盖子 + 一道提手） */
  ctx.fillStyle = '#2a2f25';
  ctx.beginPath(); ctx.roundRect(-31, -9, 17, 18, 2); ctx.fill();
  ctx.fillStyle = '#454b38';
  ctx.beginPath(); ctx.roundRect(-30, -8, 15, 16, 2); ctx.fill();
  ctx.strokeStyle = '#22261d'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.roundRect(-30, -8, 15, 16, 2); ctx.stroke();
  ctx.strokeStyle = 'rgba(210,224,180,0.22)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(-28.5, -8); ctx.lineTo(-28.5, 8); ctx.stroke();

  /* 弹链：从箱口垂到进弹口，一节一节的黄铜 */
  ctx.strokeStyle = 'rgba(28,26,20,0.85)'; ctx.lineWidth = 3.4;
  ctx.beginPath();
  ctx.moveTo(-14, 6.5);
  ctx.quadraticCurveTo(-18, 12, -24, 11);
  ctx.stroke();
  ctx.fillStyle = 'rgba(196,158,74,0.95)';
  for (let i = 0; i < 5; i++){
    const t = i / 4;
    const px = -14 + (-24 + 14) * t + Math.sin(t * Math.PI) * 1.2;
    const py = 6.5 + (11 - 6.5) * t + Math.sin(t * Math.PI) * 2.6;
    ctx.beginPath(); ctx.roundRect(px - 1.3, py - 1.1, 2.6, 2.2, 0.6); ctx.fill();
  }

  /* 机匣：上下渐变，做出圆筒感 */
  const rg = ctx.createLinearGradient(0, -6.5, 0, 6.5);
  rg.addColorStop(0, '#5a646f'); rg.addColorStop(0.35, '#414a54');
  rg.addColorStop(0.75, '#333a42'); rg.addColorStop(1, '#22282e');
  ctx.fillStyle = rg;
  ctx.beginPath(); ctx.roundRect(-15, -6.5, 26, 13, 2.2); ctx.fill();
  ctx.strokeStyle = '#181d22'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.roundRect(-15, -6.5, 26, 13, 2.2); ctx.stroke();
  /* 顶盖（进弹机盖）+ 两个卡笋 */
  ctx.fillStyle = 'rgba(150,166,182,0.30)';
  ctx.beginPath(); ctx.roundRect(-13, -6.2, 22, 3.4, 1.4); ctx.fill();
  ctx.fillStyle = '#59636e';
  ctx.beginPath(); ctx.arc(-8, -4.4, 1.1, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.arc(4, -4.4, 1.1, 0, TAU); ctx.fill();
  /* 拉机柄（右侧一根短杆） */
  ctx.fillStyle = '#2c333a';
  ctx.beginPath(); ctx.roundRect(-16.5, 1.2, 5, 2.6, 1.2); ctx.fill();
  /* 照门 */
  ctx.fillStyle = '#59636e';
  ctx.fillRect(-11, -9.2, 1.6, 3);

  /* 枪管：越热越红；先画外皮再画高光 */
  const bcol0 = hot > 0.80 ? '#8a3f28' : (hot > 0.55 ? '#6d4a30' : '#39414a');
  const bcol1 = hot > 0.80 ? '#d2714a' : (hot > 0.55 ? '#a3764a' : '#4d5762');
  const bg = ctx.createLinearGradient(0, -3.4, 0, 3.4);
  bg.addColorStop(0, bcol1); bg.addColorStop(0.45, bcol0); bg.addColorStop(1, '#1e242a');
  ctx.fillStyle = bg;
  ctx.beginPath(); ctx.roundRect(10, -3.4, 24, 6.8, 1.6); ctx.fill();
  ctx.strokeStyle = '#161a1f'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.roundRect(10, -3.4, 24, 6.8, 1.6); ctx.stroke();
  /* 枪管上的散热环 ×2 */
  ctx.strokeStyle = 'rgba(190,204,218,0.22)'; ctx.lineWidth = 1.2;
  for (const bx of [15, 25]){
    ctx.beginPath(); ctx.moveTo(bx, -3.2); ctx.lineTo(bx, 3.2); ctx.stroke();
  }
  /* 消焰器：粗一圈，带三道开槽 */
  ctx.fillStyle = '#2b3238';
  ctx.beginPath(); ctx.roundRect(33, -4.2, 7, 8.4, 1.8); ctx.fill();
  ctx.strokeStyle = '#151a1f'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.roundRect(33, -4.2, 7, 8.4, 1.8); ctx.stroke();
  ctx.strokeStyle = 'rgba(190,204,218,0.25)';
  for (const gx of [35.2, 37.2]){ ctx.beginPath(); ctx.moveTo(gx, -4); ctx.lineTo(gx, 4); ctx.stroke(); }

  /* 枪口焰：三层，外圈散、内芯白 */
  if ((n.mgFlash || 0) > 0){
    const f = clamp(n.mgFlash / 0.12, 0, 1);
    /* 三层焰：都从 MG_MUZZLE 这同一个点往外长，跟弹道起点严格同源 */
    ctx.fillStyle = 'rgba(255,170,80,' + (0.30 * f) + ')';
    ctx.beginPath(); ctx.ellipse(MG_MUZZLE + 6, 0, 12, 7, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,205,120,' + (0.55 * f) + ')';
    ctx.beginPath(); ctx.ellipse(MG_MUZZLE + 2, 0, 9, 5.2, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,246,220,' + (0.95 * f) + ')';
    ctx.beginPath(); ctx.ellipse(MG_MUZZLE - 1, 0, 5, 3.4, 0, 0, TAU); ctx.fill();
  }
  ctx.restore();

  /* ---- 地上的空弹壳：一直有人在这打枪，脚边得有点痕迹（固定偏移，不闪） ---- */
  const shellSeed = ((n.x * 7 + n.y * 13) % 17) / 17;
  ctx.fillStyle = 'rgba(184,150,86,0.75)';
  for (let si = 0; si < 5; si++){
    const sa = shellSeed * TAU + si * 1.27;
    const sr = 13 + ((si * 5 + Math.floor(shellSeed * 9)) % 9);
    const px2 = Math.cos(sa) * sr, py2 = Math.sin(sa) * sr;
    ctx.save();
    ctx.translate(px2, py2);
    ctx.rotate(sa + 0.6);
    ctx.beginPath(); ctx.roundRect(-1.5, -0.85, 3.0, 1.7, 0.8); ctx.fill();
    ctx.restore();
  }

  /* ---- 状态灯：有人用是暖黄，空着是冷灰 ---- */
  const live = !!(n.seat || n.playerSeat);
  ctx.fillStyle = live ? 'rgba(244,204,96,0.95)' : 'rgba(118,130,144,0.45)';
  ctx.beginPath(); ctx.arc(-16, -11, 2.4, 0, TAU); ctx.fill();
  if (live){
    ctx.fillStyle = 'rgba(244,204,96,0.18)';
    ctx.beginPath(); ctx.arc(-16, -11, 6, 0, TAU); ctx.fill();
  }
  ctx.restore();

  /* 过热：枪管冒热气 */
  if ((n.mgHeat || 0) > 0.8 && Math.random() < 0.20){
    spawnPart(n.x + Math.cos(n.mgAng) * 28, n.y + Math.sin(n.mgAng) * 28, -Math.PI / 2 + rand(-0.4, 0.4),
              rand(10, 24), rand(0.4, 0.8), 'smoke', rand(3, 6));
  }
}
function drawMgNests(){
  if (!mgNests.length) return;
  for (const n of mgNests){
    if (!cullRect(n.x - 40, n.y - 40, 80, 80, 60)) continue;
    drawMgNest(n);
  }
}
/* 接管时的准星 + 热条（跟车顶机枪同一套画法，数值取 DataMGNEST） */
function drawMgNestHud(){
  const n = player && player.mgNest;
  if (!n) return;
  const D = mgNestDef();
  n.overPulse = (n.overPulse || 0) + 0.016;
  const cx = mouse.x, cy = mouse.y;
  ctx.save();
  ctx.strokeStyle = 'rgba(255,214,150,0.92)';
  ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.arc(cx, cy, 17, 0, TAU); ctx.stroke();
  ctx.strokeStyle = 'rgba(255,214,150,0.55)';
  ctx.beginPath(); ctx.arc(cx, cy, 26, -0.55, 0.55); ctx.stroke();
  ctx.beginPath(); ctx.arc(cx, cy, 26, Math.PI - 0.55, Math.PI + 0.55); ctx.stroke();
  ctx.strokeStyle = 'rgba(255,236,200,0.85)';
  for (let k = 0; k < 4; k++){
    const ang = k * Math.PI / 2;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(ang) * 11, cy + Math.sin(ang) * 11);
    ctx.lineTo(cx + Math.cos(ang) * 17, cy + Math.sin(ang) * 17);
    ctx.stroke();
  }
  ctx.fillStyle = 'rgba(255,238,208,0.95)';
  ctx.beginPath(); ctx.arc(cx, cy, 1.7, 0, TAU); ctx.fill();
  const H = mgHeatDef(D);
  const hot = clamp((n.mgHeat || 0) / H.max, 0, 1);
  const over = !!n.mgOverheat;
  const bw = 148, bx = cx - bw / 2, by = cy + 34, hh = 7;
  ctx.fillStyle = 'rgba(10,14,18,0.74)';
  roundRect(bx - 1, by - 1, bw + 2, hh + 2, 4); ctx.fill();
  const hcol = over ? (Math.sin((n.overPulse || 0) * 9) > 0 ? 'rgba(236,84,64,0.96)' : 'rgba(255,140,90,0.96)')
             : (hot > 0.72 ? 'rgba(240,120,80,0.95)'
             : (hot > 0.40 ? 'rgba(240,190,90,0.95)' : 'rgba(150,205,255,0.92)'));
  ctx.fillStyle = hcol;
  roundRect(bx, by, Math.max(2, bw * hot), hh, 3.5); ctx.fill();
  ctx.strokeStyle = 'rgba(10,14,18,0.55)';
  ctx.lineWidth = 1;
  for (let k = 1; k < 4; k++){
    const gx = bx + bw * (k / 4);
    ctx.beginPath(); ctx.moveTo(gx, by + 1); ctx.lineTo(gx, by + hh - 1); ctx.stroke();
  }
  ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = over ? 'rgba(255,150,120,0.98)' : 'rgba(220,232,244,0.88)';
  ctx.fillText(over ? ('过载 · ' + mgHeatLeft(n, D).toFixed(1) + 's 才能再打')
                    : ('枪管 ' + Math.round(hot * 100) + '% · 弹链 250 发'), cx, by + 21);
  if (over){
    ctx.strokeStyle = 'rgba(240,110,90,0.95)';
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(cx, cy, 21, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, 29, 0, TAU); ctx.stroke();
  }
  ctx.restore();
  setCursorStyle('none');
}

function drawTruckMgHud(){
  const t = playerTruck;
  if (!t) return;
  t.overPulse = (t.overPulse || 0) + 0.016;
  const M = truckMgDef(t) || {};
  const cx = mouse.x, cy = mouse.y;
  ctx.save();
  ctx.strokeStyle = 'rgba(255,214,150,0.92)';
  ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.arc(cx, cy, 17, 0, TAU); ctx.stroke();
  ctx.strokeStyle = 'rgba(255,214,150,0.55)';
  ctx.beginPath(); ctx.arc(cx, cy, 26, -0.55, 0.55); ctx.stroke();
  ctx.beginPath(); ctx.arc(cx, cy, 26, Math.PI - 0.55, Math.PI + 0.55); ctx.stroke();
  ctx.strokeStyle = 'rgba(255,236,200,0.85)';
  for (let k = 0; k < 4; k++){
    const ang = k * Math.PI / 2;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(ang) * 11, cy + Math.sin(ang) * 11);
    ctx.lineTo(cx + Math.cos(ang) * 17, cy + Math.sin(ang) * 17);
    ctx.stroke();
  }
  ctx.fillStyle = 'rgba(255,238,208,0.95)';
  ctx.beginPath(); ctx.arc(cx, cy, 1.7, 0, TAU); ctx.fill();
  const _H = mgHeatDef(M);
  const _hot = clamp((t.mgHeat || 0) / _H.max, 0, 1);
  const _over = !!t.mgOverheat;
  /* ——— 只有一条热条：无限弹链，唯一要盯的就是它 ——— */
  const bw = 148, bx = cx - bw / 2, by = cy + 34, hh = 7;
  ctx.fillStyle = 'rgba(10,14,18,0.74)';
  roundRect(bx - 1, by - 1, bw + 2, hh + 2, 4); ctx.fill();
  const _hcol = _over ? (Math.sin((t.overPulse || 0) * 9) > 0 ? 'rgba(236,84,64,0.96)' : 'rgba(255,140,90,0.96)')
             : (_hot > 0.72 ? 'rgba(240,120,80,0.95)'
             : (_hot > 0.40 ? 'rgba(240,190,90,0.95)' : 'rgba(150,205,255,0.92)'));
  ctx.fillStyle = _hcol;
  roundRect(bx, by, Math.max(2, bw * _hot), hh, 3.5); ctx.fill();
  /* 满值前那一段画刻度：让人有"快红了"的预感 */
  ctx.strokeStyle = 'rgba(10,14,18,0.55)';
  ctx.lineWidth = 1;
  for (let k = 1; k < 4; k++){
    const gx = bx + bw * (k / 4);
    ctx.beginPath(); ctx.moveTo(gx, by + 1); ctx.lineTo(gx, by + hh - 1); ctx.stroke();
  }
  ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = _over ? 'rgba(255,150,120,0.98)' : 'rgba(220,232,244,0.88)';
  ctx.fillText(_over ? ('过载 · ' + mgHeatLeft(t, M).toFixed(1) + 's 才能再打')
                     : ('枪管 ' + Math.round(_hot * 100) + '% · 无限弹链'), cx, by + 21);
  /* 过载时准星也变色，别让人以为是没打中 */
  if (_over){
    ctx.strokeStyle = 'rgba(240,110,90,0.95)';
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(cx, cy, 21, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, 29, 0, TAU); ctx.stroke();
  }
  ctx.restore();
  setCursorStyle('none');
}

/* m45698：机枪棱堡的绘制（沙袋圈 + 通用机枪 + 血条 + 换弹提示） */
function drawMgSentry(w){
  const D = (typeof MG_SENTRY_DEF === 'object' && MG_SENTRY_DEF) ? MG_SENTRY_DEF : {};
  const cx = w.x + w.w / 2, cy = w.y + w.h / 2;
  const dead = (w.hp || 0) <= 0;
  const h = (D.baseHalf || 30);
  const rec = Math.max(0, Math.min(1, w.recoil || 0));   /* 0..1：开火瞬间的枪管后坐 */
  /* m45862：受击反馈 —— 白闪 + 抖动 + 沙粒飞溅（都不依赖全局状态，纯由 hitT 驱动） */
  const _hit = Math.max(0, Math.min(1, (w.hitT || 0) / 0.16));
  const _shake = _hit > 0 ? Math.sin((typeof uiT === 'number' ? uiT : 0) * 78) * _hit * 1.8 : 0;
  ctx.save();
  ctx.translate(cx + _shake, cy);
  /* 地基阴影 */
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.beginPath(); ctx.ellipse(0, 4, h * 1.06, h * 0.92, 0, 0, TAU); ctx.fill();
  /* 阵营圈：和火箭炮塔同一套约定（A 实线 / B 虚线），否则两家棱堡看着是同一个东西 */
  if (!dead && w.factionTint){
    const _lk2 = (typeof factionLook === 'function') ? factionLook(w.faction) : null;
    ctx.save();
    ctx.globalAlpha = 0.8;
    ctx.strokeStyle = (_lk2 && _lk2.arc) || w.factionTint;
    ctx.lineWidth = 2.4;
    if (_lk2 && _lk2.mark === 'ring') ctx.setLineDash([6.5, 4.2]);
    ctx.beginPath(); ctx.ellipse(0, 2, h * 1.18, h * 1.04, 0, 0, TAU); ctx.stroke();
    ctx.restore();
  }
  /* 阵营轮廓：整圈沙袋的最外缘描一道（B 虚线），比只染沙袋更远可辨 */
  if (!dead && w.factionTint && typeof factionLook === 'function'){
    const _lk3 = factionLook(w.faction);
    ctx.save();
    ctx.globalAlpha = 0.95;
    ctx.strokeStyle = (_lk3 && _lk3.arc) || w.factionTint;
    ctx.lineWidth = 2.8;
    if (_lk3 && _lk3.mark === 'ring') ctx.setLineDash([7.0, 4.4]);
    ctx.beginPath(); ctx.ellipse(0, 1, h * 1.26, h * 1.12, 0, 0, TAU); ctx.stroke();
    ctx.restore();
  }
  /* 沙袋墙：朝射击方向开口的"马蹄"，两排错缝。
     正面（w.ang 方向）留出一个射击口，不是均匀一圈 —— 均匀一圈看着像花瓣。 */
  const gapA = (typeof w.baseAng === 'number') ? w.baseAng : w.ang, gapW = 0;   /* m45955：沙袋直接围一圈，不留射击口（枪管画在沙袋之上） */
  /* m45899：血量分层 —— 5000 血是一条线，但外观得让人看出"打穿了几层"。
     0.66 以上：沙袋完整；0.33~0.66：外排开始缺口、整体塌一点；0.33 以下：外排只剩零星、内排也破。 */
  const _k = dead ? 0 : Math.max(0, Math.min(1, (w.hp || 0) / (w.maxHp || D.hp || 5000)));
  const _stage = (_k > 0.66) ? 0 : (_k > 0.33 ? 1 : 2);
  const rows = [ { r: h * 0.96, n: 9, sc: 1.00, lift: 3.0 },
                 { r: h * 0.66, n: 7, sc: 0.86, lift: 1.2 } ];
  for (let ri = 0; ri < rows.length; ri++){
    const R = rows[ri];
    for (let i = 0; i < R.n; i++){
      const a = (i / R.n) * TAU + (ri ? 0.55 : 0.0);     /* 第二排错开半格 = 错缝 */
      let d = Math.abs(normAng(a - gapA));
      if (d < gapW) continue;                            /* 让出射击口 */
      /* 打穿的缺口：外排先碎，内排后碎（确定性取模，每次重画一致，不会闪） */
      if (ri === 0 && _stage >= 1 && (i % 3 === 1)) continue;
      if (ri === 0 && _stage >= 2 && (i % 3 !== 0)) continue;
      if (ri === 1 && _stage >= 2 && (i % 2 === 0)) continue;
      const _sag = (_stage === 1 ? 1.5 : _stage === 2 ? 3.2 : 0) * (ri === 0 ? 1 : 0.6);
      const bx = Math.cos(a) * R.r, by = Math.sin(a) * R.r;
      ctx.save();
      ctx.translate(bx, by - R.lift + _sag);
      ctx.rotate(a + Math.PI / 2);                       /* 沙袋长边沿切线 */
      const ww = 15 * R.sc, hh = 9.5 * R.sc;
      const shade = (i + ri) % 3;
      /* 沙袋也带一点阵营色：否则两边棱堡都是一圈黄沙包，形状完全一样 */
      {
        const _sb = shade === 0 ? '#7b6b50' : (shade === 1 ? '#6e6047' : '#83725a');
        ctx.fillStyle = (!dead && w.factionTint && typeof mixHex === 'function')
          ? mixHex(_sb, w.factionTint, 0.42) : _sb;
      }
      ctx.strokeStyle = 'rgba(34,29,21,0.95)'; ctx.lineWidth = 1.1;
      ctx.beginPath(); ctx.roundRect(-ww / 2, -hh / 2, ww, hh, hh * 0.52); ctx.fill(); ctx.stroke();
      /* 顶部受光 */
      ctx.fillStyle = 'rgba(255,238,196,0.13)';
      ctx.beginPath(); ctx.roundRect(-ww / 2 + 1.2, -hh / 2 + 1.1, ww - 2.4, hh * 0.42, hh * 0.28); ctx.fill();
      /* 缝线 + 两粒沙点 */
      ctx.strokeStyle = 'rgba(28,23,16,0.55)'; ctx.lineWidth = 0.9;
      ctx.beginPath(); ctx.moveTo(-ww / 2 + 1.5, 0.2); ctx.lineTo(ww / 2 - 1.5, 0.2); ctx.stroke();
      ctx.fillStyle = 'rgba(36,30,22,0.45)';
      ctx.beginPath(); ctx.arc(-ww * 0.22, -hh * 0.14, 0.9, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.arc(ww * 0.18, hh * 0.16, 0.8, 0, TAU); ctx.fill();
      ctx.restore();
    }
  }
  /* 枪架 + 枪身：绕 ang 转；开火时整根往后缩 rec*3.2px */
  ctx.save();
  ctx.rotate(w.ang);
  ctx.translate(-rec * 3.2, 0);
  /* 三脚架（死掉就不画，地上只剩沙袋） */
  ctx.strokeStyle = 'rgba(28,33,38,0.9)'; ctx.lineWidth = 2.2;
  if (!dead){
    ctx.beginPath(); ctx.moveTo(-3, 0); ctx.lineTo(-13, 9); ctx.moveTo(-3, 0); ctx.lineTo(-13, -9); ctx.stroke();
  }
  /* m45899：枪手 —— 半个身子坐在机匣后面；换弹时蹲下补弹、开火时顶肩，死了就没这个人 */
  if (!dead){
    const _rl = (w.reloadT || 0) > 0;
    const _crouch = _rl ? 3.4 : 0;
    const _lean = _rl ? 0 : rec * 1.6;
    const _arm = (typeof mixHex === 'function' && w.factionTint) ? mixHex(w.factionTint, '#0e1318', 0.30) : '#8d6a3a';
    ctx.save();
    ctx.translate(-12.5 - _lean, _crouch);
    /* 躯干 */
    ctx.fillStyle = '#3f4a3a';
    ctx.beginPath(); ctx.roundRect(-9.5, -6.6, 11.5, 13.2, 4); ctx.fill();
    ctx.strokeStyle = 'rgba(18,22,16,0.9)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(-9.5, -6.6, 11.5, 13.2, 4); ctx.stroke();
    /* 势力色袖标（谁家的机枪一眼看出来） */
    ctx.fillStyle = _arm;
    ctx.beginPath(); ctx.roundRect(-1.6, -6.0, 3.4, 12.0, 1.4); ctx.fill();
    /* 头盔 */
    ctx.fillStyle = '#4c5a44';
    ctx.beginPath(); ctx.arc(-7.2, 0, 4.5, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(16,20,14,0.95)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(-7.2, 0, 4.5, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.10)';
    ctx.beginPath(); ctx.arc(-8.4, -1.4, 2.0, 0, TAU); ctx.fill();
    /* 两条手臂搭到握把上 */
    ctx.strokeStyle = '#45503c'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-2.2, -3.2); ctx.lineTo(4.6, -2.0); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-2.2, 3.2); ctx.lineTo(4.6, 2.0); ctx.stroke();
    ctx.restore();
  }
  ctx.fillStyle = '#2b3239';
  ctx.beginPath(); ctx.roundRect(-14, -4, 12, 8, 2); ctx.fill();   /* 机匣 */
  ctx.beginPath(); ctx.roundRect(2, -3, 26, 6, 2); ctx.fill();     /* 枪管 */
  ctx.fillStyle = '#39434c';
  ctx.beginPath(); ctx.roundRect(28, -4.5, 5, 9, 2); ctx.fill();   /* 消焰器 */
  /* m45899：换弹提示 —— 枪管烧红 + 散热白烟（头顶那根蓝条太远看不清） */
  if (!dead && (w.reloadT || 0) > 0){
    const _hot = 0.35 + 0.35 * Math.sin((typeof uiT === 'number' ? uiT : 0) * 5);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const _gr = ctx.createLinearGradient(2, 0, 28, 0);
    _gr.addColorStop(0, 'rgba(255,90,40,' + (0.10 + 0.16 * _hot).toFixed(2) + ')');
    _gr.addColorStop(1, 'rgba(255,170,90,' + (0.30 + 0.30 * _hot).toFixed(2) + ')');
    ctx.fillStyle = _gr;
    ctx.beginPath(); ctx.roundRect(2, -3, 26, 6, 2); ctx.fill();
    ctx.restore();
    /* 散热白烟：两缕往上飘 */
    for (let i = 0; i < 2; i++){
      const _p = ((typeof uiT === 'number' ? uiT : 0) * 0.7 + i * 0.5) % 1;
      ctx.fillStyle = 'rgba(226,232,236,' + (0.20 * (1 - _p)).toFixed(2) + ')';
      ctx.beginPath();
      ctx.arc(12 + i * 9, -4 - _p * 13, 2.6 + _p * 3.4, 0, TAU); ctx.fill();
    }
  }
  if (!dead){
    ctx.fillStyle = 'rgba(255,214,120,0.9)';
    ctx.beginPath(); ctx.arc(-18, 0, 5, 0, TAU); ctx.fill();       /* 弹箱 */
    /* 弹链：从弹箱引到机匣，几颗铜色弹尖 */
    ctx.fillStyle = 'rgba(206,166,86,0.85)';
    for (let i = 0; i < 4; i++){
      const t = i / 3;
      ctx.beginPath(); ctx.arc(-13 + t * 12, -3.2 + t * 2.0, 1.15, 0, TAU); ctx.fill();
    }
  }
  /* 枪口焰：开火那几帧三层 + 横向拉长，像真的在喷 */
  if ((w.flash || 0) > 0){
    const f = Math.min(1, w.flash * 9);
    ctx.save();
    ctx.translate(35, 0);
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = 'rgba(255,150,60,' + (f * 0.55).toFixed(2) + ')';
    ctx.beginPath(); ctx.ellipse(6, 0, 13 * f + 4, 5.0 * f + 1.6, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,238,170,' + (f * 0.95).toFixed(2) + ')';
    ctx.beginPath(); ctx.ellipse(3, 0, 7.5 * f + 2, 2.9 * f + 1.1, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,240,' + f.toFixed(2) + ')';
    ctx.beginPath(); ctx.arc(1.2, 0, 2.0 * f + 1.0, 0, TAU); ctx.fill();
    ctx.restore();
    /* 枪口烟：两团往上飘的灰白（跟着 flash 衰减） */
    ctx.fillStyle = 'rgba(190,190,185,' + (f * 0.22).toFixed(2) + ')';
    ctx.beginPath(); ctx.arc(41 + 3 * (1 - f), -4 - 7 * (1 - f), 5.5 * (1.2 - f * 0.4), 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(47 + 5 * (1 - f), -9 - 10 * (1 - f), 4.2 * (1.2 - f * 0.4), 0, TAU); ctx.fill();
    /* 抛壳：右侧甩出一枚黄铜，位置随 flash 走一帧 */
    ctx.fillStyle = 'rgba(214,170,72,0.95)';
    ctx.save();
    ctx.translate(-4 + 10 * (1 - f), -6 - 6 * (1 - f));
    ctx.rotate(1.2 * (1 - f));
    ctx.beginPath(); ctx.roundRect(-1.7, -0.9, 3.4, 1.8, 0.8); ctx.fill();
    ctx.restore();
  }
  ctx.restore();  /* 血条：只在受损时出现，免得满血也挂一条 */
  if (!dead && w.maxHp && w.hp < w.maxHp){
    const bw = h * 1.7;
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(-bw / 2, -h - 12, bw, 4);
    ctx.fillStyle = (w.hp / w.maxHp > 0.5) ? '#79c46b' : '#d9694f';
    ctx.fillRect(-bw / 2, -h - 12, bw * Math.max(0, w.hp / w.maxHp), 4);
  }
  /* 换弹：枪口上抬的蓝条 */
  if (!dead && (w.reloadT || 0) > 0){
    const k = 1 - w.reloadT / (D.reloadT || 3.5);
    const bw = h * 1.5;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(-bw / 2, -h - 20, bw, 3);
    ctx.fillStyle = '#6fa8d8'; ctx.fillRect(-bw / 2, -h - 20, bw * Math.max(0, Math.min(1, k)), 3);
  }
  /* m45899：受击 = 定向火花 + 尘土，不再画整圈白球（那东西像"治疗光环"，反而没打击感） */
  if (!dead && _hit > 0){
    const _from = (typeof w.hitAng === 'number') ? w.hitAng : (w.ang + Math.PI);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let k = 0; k < 5; k++){
      const a2 = _from + (k - 2) * 0.26;
      const d2 = h * (0.55 + 0.45 * (1 - _hit));
      const len = 6 + 10 * _hit;
      ctx.strokeStyle = 'rgba(255,' + (200 - k * 14) + ',120,' + (0.65 * _hit).toFixed(2) + ')';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a2) * d2, Math.sin(a2) * d2);
      ctx.lineTo(Math.cos(a2) * (d2 + len), Math.sin(a2) * (d2 + len));
      ctx.stroke();
    }
    ctx.restore();
    /* 尘土：被打中的那一侧扬起两团 */
    ctx.fillStyle = 'rgba(198,180,142,' + (0.55 * _hit).toFixed(2) + ')';
    for (let k = 0; k < 2; k++){
      const a3 = _from + (k ? 0.34 : -0.30), d3 = h * (0.95 + 0.35 * (1 - _hit));
      ctx.beginPath(); ctx.arc(Math.cos(a3) * d3, Math.sin(a3) * d3 - 2 * (1 - _hit), 4.2 + 2.6 * _hit, 0, TAU); ctx.fill();
    }
  }
  if (dead){
    ctx.fillStyle = 'rgba(30,26,22,0.45)';
    ctx.beginPath(); ctx.arc(0, 0, h * 0.62, 0, TAU); ctx.fill();
  }
  ctx.restore();
}
