/* 室内搜查性格和巡查点生成；走路、开门与扫视由 roomSearchTick 处理。 */
var SEARCH_DEF = {
  on: true,
  /* 各档"仔细"的概率：普通 / 老兵 / 精英。
     2026-11-25 反馈「进房间有一半概率不丢雷」：原来 0.12/0.55/0.92 ——
     老兵那档正好 5 成，玩家看到的"一半不扔"就是这里掷出来的。
     现在抬到 0.85/0.97/1.00：进可疑房间基本都会先排点，只有极少数普通兵才会直接推门。
     想回到以前那种"偶尔才扔"，把这三个数改小即可。 */
  p: { normal: 0.85, veteran: 0.97, elite: 1.00 },
  cell: 58,        /* 采样格子边长（屋里一格约等于一个身位） */
  inset: 26,       /* 离墙留一点，别贴脸修边 */
  maxCells: 16    /* 最多补几格，防止大仓库走成马拉松 */
};

/* 这个敌人够不够仔细（惰性决定一次，之后固定） */
function searchCarefulRoll(e){
  if (!SEARCH_DEF.on) return false;
  if (e.searchCareful !== undefined) return !!e.searchCareful;
  let tier = 0;
  try { tier = (typeof tacticsTier === 'function') ? tacticsTier(e) : 0; } catch (err){ tier = 0; }
  const key = tier >= 2 ? 'elite' : (tier >= 1 ? 'veteran' : 'normal');
  const p = SEARCH_DEF.p[key] === undefined ? 0 : SEARCH_DEF.p[key];
  e.searchCareful = (typeof arenaRandom === 'function' ? arenaRandom() : Math.random()) < p;
  e.searchCarefulTier = key;
  return !!e.searchCareful;
}

/* 房间在哪：给一个点，找包含它的房间（优先快索引） */
function searchRoomOf(L, x, y){
  if (typeof levelRoomAt !== 'function') return null;
  try { return levelRoomAt(L, x, y) || null; } catch (err){ return null; }
}

/* 在目标房内建立巡查点表，优先安排墙角和容器的可站立侧面。 */
function searchSweepAppend(L, e, s){
  if (!SEARCH_DEF.on || !s) return false;
  if (!searchCarefulRoll(e)) return false;
  if (s.swept) return false;                    /* 这一轮已经补过了 */
  const room = s.roomObj || searchRoomOf(L, s.target.x, s.target.y) || searchRoomOf(L, e.x, e.y);
  if (!room || searchRoomOf(L,e.x,e.y)!==room) return false;
  const x0 = room.x + SEARCH_DEF.inset, y0 = room.y + SEARCH_DEF.inset;
  const x1 = room.x + room.w - SEARCH_DEF.inset, y1 = room.y + room.h - SEARCH_DEF.inset;
  if (x1 <= x0 || y1 <= y0) return false;

  const cells = [];
  function add(x,y,lx,ly){
    if(x<x0||x>x1||y<y0||y>y1||navBlockedAt(L,x,y)||cells.some(p=>dist(p.x,p.y,x,y)<18))return;
    cells.push({x,y,lx,ly,priority:1});
  }
  for(const x of [x0,x1])for(const y of [y0,y1])
    add(x,y,x===x0?room.x+8:room.x+room.w-8,y===y0?room.y+8:room.y+room.h-8);
  for(const w of (L.brk||[])){
    if(!COVER_DEF[w.t]?.loot)continue;
    const x=w.x+w.w/2,y=w.y+w.h/2,p=SEARCH_DEF.inset;
    if(searchRoomOf(L,x,y)!==room)continue;
    add(w.x-p,y,w.x,y);add(w.x+w.w+p,y,w.x+w.w,y);
    add(x,w.y-p,x,w.y);add(x,w.y+w.h+p,x,w.y+w.h);
  }
  const step=Math.max(SEARCH_DEF.cell,(x1-x0)/12,(y1-y0)/12);
  for (let y = y0; y <= y1; y += step){
    for (let x = x0; x <= x1; x += step){
      if (typeof navBlockedAt === 'function' && navBlockedAt(L, x, y)) continue;
      if(!cells.some(p=>dist(p.x,p.y,x,y)<18))cells.push({x,y,lx:x+(x<(x0+x1)/2?-20:20),ly:y});
    }
  }
  if (!cells.length){ s.swept = true; return false; }

  /* 就近排序：贪心，从当前位置一格一格跳，避免在屋里来回横穿 */
  const out = [];
  let cx = e.x, cy = e.y, last=NaN;
  while (cells.length && out.length < SEARCH_DEF.maxCells){
    let bi = 0, bd = Infinity;
    for (let i = 0; i < cells.length; i++){
      const p=cells[i], a=Math.atan2(p.y-cy,p.x-cx);
      const turn=Number.isFinite(last)?Math.abs(normAng(a-last))*14:0;
      const base=dist(cx,cy,p.x,p.y)+turn-(p.priority?32:0);
      if(base>=bd)continue;
      const d=base+(roomSearchWalk(L,e,cx,cy,p.x,p.y)?0:125);
      if (d < bd){ bd = d; bi = i; }
    }
    const pick = cells.splice(bi, 1)[0];
    out.push(pick);
    last=Math.atan2(pick.y-cy,pick.x-cx);cx = pick.x; cy = pick.y;
  }
  s.sweep=out;s.sweepIndex=0;s.sweepVisited=0;s.limit=Math.max(s.limit,90);
  s.swept = true;
  s.sweepCount = out.length;
  if (typeof tacBump === 'function') tacBump('sweep');
  return true;
}

/* 搜房只负责选谁、哪扇门、以及情报变化时是否中断。 */
function searchEntryFragStillValid(L,e,order){
  const s=order.search;
  return e.roomSearch===s && s.points?.[s.index]?.door===order.door &&
    !e.sees && e.mode===1 && e.lastKnown &&
    levelRoomAt(L,e.lastKnown.x,e.lastKnown.y)===(order.clueRoom || order.room);
}
/* 门口"能不能过/能不能扔"的统一门状态判定（1126e）：
   以前 16-frag 的起手判据是 60%、nadeRoundTick 的取消判据是 95%，
   门开到 72% 时就会出现「刚起手就被判门没开、直接放弃」的自相矛盾。
   现在两处共用这一个函数，阈值放数据里（roomEntry.doorOpen，默认 0.60）。 */
function doorGateOpen(door){
  if (!door) return false;
  if (door.broken) return true;
  if (door.isLocked && !door.unlocked) return false;
  const cfg = (typeof DataTHROW !== 'undefined' && DataTHROW && DataTHROW.roomEntry) ? DataTHROW.roomEntry : null;
  const need = (cfg && isFinite(cfg.doorOpen)) ? cfg.doorOpen : 0.60;
  return (door.open === undefined ? 0 : door.open) >= need;
}
/* 门中心：统一走 roomDoorFrame（door.cx/cy 在模板房里根本没初始化） */
function doorGateCenter(door){
  if (!door) return null;
  if (typeof roomDoorFrame === 'function'){
    const f = roomDoorFrame(door);
    if (f) return { x: f.cx, y: f.cy };
  }
  return (isFinite(door.cx) && isFinite(door.cy)) ? { x: door.cx, y: door.cy } : null;
}
/* 线索隔着第二扇门时，先排查外门通向的房间，搜房仍追原来的线索。 */
function searchEntryFragTarget(L,s,p){
  const clueRoom=s.roomObj;
  if(!clueRoom || clueRoom.building==null)return {room:clueRoom,via:false};
  const innerDoor=s.points.some((q,i)=>i>s.index && q.phase==='cross' && q.door && q.door!==p.door);
  if(!innerDoor)return {room:clueRoom,via:true};
  const f=roomDoorFrame(p.door);
  const offset=(f.vertical?f.w:f.h)/2+4;
  const dx=f.vertical?offset*p.exitSide:0, dy=f.vertical?0:offset*p.exitSide;
  const outside=levelRoomAt(L,f.cx-dx,f.cy-dy);
  const entrance=levelRoomAt(L,f.cx+dx,f.cy+dy);
  return {room:!outside && entrance?.building===clueRoom.building ? entrance : clueRoom,via:false};
}
/* 门口破门（投雷/等队友）兜底计时：在门口折腾太久还没进屋就放弃这套，
   直接走进去。2026-11-23 反馈：玩家把门开着躲屋里，人机在门外站着不动很久
   （投雷前摇 → 退开 → 等爆炸 → 再投一颗），观感就是「卡在门口」。 */
function searchEntryFragBudgetUsed(s, e, p){
  if (s.fragAt === undefined) { s.fragAt = uiT; return false; }
  if (s.fragGiveUp) return true;
  /* 只要还在"往门口靠近"，这 6 秒就重新计时 —— 否则从远处走过来的人经常还没抬手就被判超时，
     表现就是"进可疑房子有时不扔雷"。只有真的在门口站着不动才算干耗。 */
  const _c = (p && p.door) ? doorGateCenter(p.door) : null;
  const _d = (_c && e) ? Math.hypot(e.x - _c.x, e.y - _c.y) : null;
  if (_d !== null && isFinite(_d)){
    if (s.fragDist === undefined || _d < s.fragDist - 4){ s.fragAt = uiT; }
    s.fragDist = _d;
  }
  if (uiT - s.fragAt > 6.0) { s.fragGiveUp = true; return true; }
  return false;
}
/* 队友接手补第二颗的可用性：同一个门侧、第一颗已经在飞、原投掷者还没开始补第二颗。
   同一轮只允许一个队友接手（原订单的 follow 会被消费掉），门上的 _fragCoopAt 兜住同帧多人。 */
function searchEntryFragCoopMate(L,e,p){
  const mate=enemyDoorFragReservation(L,e,p.door,p.exitSide,false);
  const owner=mate && mate.owner;
  if(!(mate && owner && owner!==e && !mate._coopUsed))return null;
  /* 首投者还在前摇（已经抬手但还没撒手）时也允许接手：
     这样两个人是"同时抬手"，而不是等第一个人扔完再轮到他。 */
  const winding = (owner.throwT||0)>0 && owner.roomEntryThrow && owner.roomEntryThrow.order===mate;
  if(!(mate.nade ? mate.follow : winding))return null;
  if(uiT-((p.door && p.door._fragCoopAt)||-999)<=8)return null;
  return mate;
}
function searchEntryFragCoopStart(L,e,s,p,mate){
  /* 不新开订单：直接挂到首颗那份订单上，两个人各投各的（e.roomEntryThrow 是每个敌人自己的）。
     这样两颗同时上膛、同时在空，而不是等前一颗炸完。
     失败时什么都不改，下一帧换个采样点再试（不要把订单判死）。 */
  const cfg=DataTHROW.roomEntry;
  const via=s.roomObj.building!=null && !s.points.some(
    (q,i)=>i>s.index && q.phase==='cross' && q.door && q.door!==p.door);
  const f=enemyDoorFragFrame(L,e,s.roomObj,p.door,p.exitSide,via,cfg.windupDrift,true);
  if(!f)return false;
  const _ok=enemyDoorFragStart(L,e,mate,f,enemyThrowDef(),true);
  if(!_ok)return false;
  mate._coopUsed=true;
  mate.follow=false;
  if(p.door)p.door._fragCoopAt=uiT;
  s.entryFrag=mate;
  s.fragAt=uiT;
  return true;
}
/* 只在"有搭档一起攻同一个门"时才走轮次路径；单人（含单人补投）仍走原有实现，
   这样既有玩法一条不改，双人则拿到同一时间轴与各自的落点。 */
function nadeRoundWanted(L,e,p){
  if(!p || !p.door) return false;
  if(nadeRoundGet(p.door,p.exitSide,e)) return true;   /* 已经在轮次里 */
  const f=nadeRoundFaction(e);
  for(const o of enemies){
    if(o===e || o.dead || o.dummy) continue;
    if(nadeRoundFaction(o)!==f) continue;
    /* 搭档只要"也在搜同一栋房、也在警戒"就够 —— 能不能包抄(canFlank)是另一套战术，和门口排点无关 */
    if(!o.roomSearch) continue;
    if(typeof dist==='function' && dist(o.x,o.y,e.x,e.y)>110) continue;
    if(typeof levelRoomAt==='function' && levelRoomAt(L,o.x,o.y)) continue;  /* 已经在屋里的人不算 */
    if(!((o.throwT||0)>0) && !(o.alertT>0)) continue;                        /* 没在警戒的不算搭档 */
    return true;
  }
  return false;
}
/* 轮次路径下"门前投雷"的唯一入口：负责要名额、要落点、起前摇，失败就把控制权交还搜房。 */
function nadeRoundMine(e){
  for (const r of NADE_ROUND.rounds.values()){
    const sl = r.slots.find(s => s.owner === e);
    if (sl) return Object.assign({}, sl, { thrown: r.thrown || 0, lastRelease: r.lastRelease });
  }
  return null;
}
/* 通用"门口冻住"看门狗：站在门口 5 秒没挪窝、前摇没在走、也没有雷在空中
   → 直接放弃破门、清干净状态，让搜房逻辑带他进屋（2026-11-25：会丢雷的敌人进门时冻住）。 */
function searchEntryFragStuck(e,s){
  if(!s || !e) return false;
  if((e.throwT||0) > 0 || (typeof nadeLiveEnemy==='function' && nadeLiveEnemy() > 0)){
    s._stkX=e.x; s._stkY=e.y; s._stkAt=uiT; return false;
  }
  if(s._stkAt===undefined || s._stkX===undefined ||
     Math.abs(e.x-s._stkX)>3 || Math.abs(e.y-s._stkY)>3){
    s._stkX=e.x; s._stkY=e.y; s._stkAt=uiT; return false;
  }
  if(uiT - s._stkAt > 5.0){
    s.entryFrag=null; s.entryFragSupport=null; s.fragGiveUp=true; s.fragAt=uiT;
    e.roomEntryThrow=null; e.throwT=0;
    if(typeof nadeRoundReleaseSlot==='function')nadeRoundReleaseSlot(e);
    return true;
  }
  return false;
}
function nadeRoundSearchTick(L,e,s,p,dt){
  const _dbg=NADE_ROUND.dbg||(NADE_ROUND.dbg={});
  const why0=(k)=>{_dbg[k]=(_dbg[k]||0)+1;return k;};
  if(!p || !p.door || !s.roomObj)return why0('no-ctx')&&false;
  if(typeof searchEntryFragStuck==='function' && searchEntryFragStuck(e,s))return why0('stuck')&&false;
  /* 这扇门刚刚打满一轮：附近的人先按兵不动一小会儿，别换个人立刻凑出第三颗 */
  if(e.fragHoldUntil && uiT < e.fragHoldUntil)return why0('hold')&&false;
  /* 兜底预算/放弃标记优先：被打断过一次就别再原地重来（会被同一次眩晕反复打断） */
  if(typeof searchEntryFragBudgetUsed==='function' && searchEntryFragBudgetUsed(s, e, p))return why0('budget')&&false;
  if(!searchCarefulRoll(e))return why0('not-careful')&&false;
  /* 全队节奏：刚有人扔过就等（队友"同时抬手"的情况由下面的 pending 分支放行） */
  const _r0=nadeRoundGet(p.door,p.exitSide,e);
  const _pending0=_r0?nadeRoundPendingCount(_r0):0;
  const _mine0=_r0?(_r0.slots.find(sl=>sl.owner===e)||null):null;
  const _nbBlocked=(k,limit)=>{
    /* 卡住看门狗：同一个阻塞原因连续超过 limit 秒，就认为状态没被推进（前摇被别处清掉、
       雷已经不在场上但 slot 还挂在 air 等），把这一条作废、交还移动权，别让人站在门口像冻住。 */
    if(s._nbKey!==k){s._nbKey=k;s._nbAt=uiT;return false;}
    return (uiT-(s._nbAt===undefined?uiT:s._nbAt)) > (limit||2.5);
  };
  if(_mine0 && (_mine0.state==='windup'||_mine0.state==='air')){
    const liveNade=_mine0.state==='air' && nades.includes(_mine0.nade);
    if(!liveNade && _nbBlocked('wait-'+_mine0.state,3.0)){
      if(e.roomEntryThrow)e.roomEntryThrow=null;
      e.throwT=0;
      if(typeof nadeRoundReleaseSlot==='function')nadeRoundReleaseSlot(e);
      _mine0.state='cancel'; _mine0.cancelReason='stuck';
      return why0('stuck')&&false;
    }
    return true;  /* 前摇/等爆炸：继续占住 */
  }
  /* 这一轮还欠一颗（follow 名额没用完）时，先别往屋里走 —— 站在门外等节奏，扔完再进。
     但门已经被炸开的，就没必要等第二颗了：那不是"戒备"，是发呆。 */
  if(_mine0 && _mine0.state==='done' && !(p.door && p.door.broken)){
    const _cfg4=nadeRoundEntryCfg()||{};
    const _cap4=(_cfg4.maxPerRound===undefined?2:_cfg4.maxPerRound);
    const _TH4=(typeof enemyThrowDef==='function')?enemyThrowDef():null;
    const _gap4=(_TH4&&_TH4.gap!==undefined)?_TH4.gap:3.5;
    if(((_r0.thrown)||0)<_cap4 && (uiT-(_r0.lastRelease===undefined?-1e9:_r0.lastRelease))<_gap4)return true;
  }
  // 冷却限制新一轮。首颗已经离手时，尚在空中的同轮手雷仍允许队友接手第二颗。
  const activeSupport=_r0 && !_r0.closed && _r0.slots.some(sl=>
    sl.owner!==e && sl.state==='air' && nades.includes(sl.nade));
  if(!activeSupport && _pending0===0 && !(_mine0 && _mine0.state==='done') &&
     typeof nadeSquadCd!=='undefined' && nadeSquadCd>0)return why0('squad-cd')&&false;
  const failed=s.fragSpotRetry;
  if(failed?.door===p.door && failed.side===p.exitSide &&
     dist(failed.x,failed.y,e.x,e.y)<8 && uiT<failed.until)return false;
  const ent=e.roomEntryThrow;
  if(ent && ent.round){
    /* 有订单但前摇没在走（throwT 已归零、也没真的扔出去）→ 说明这条被别处掐断了，
       不能再拿它占住移动权，否则人就在门口冻住。 */
    if(!((e.throwT||0) > 0) && !ent.nade){
      e.roomEntryThrow=null;
      if(typeof nadeRoundReleaseSlot==='function')nadeRoundReleaseSlot(e);
      return why0('ent-stale')&&false;
    }
    return true;               /* 前摇/等雷期间占住移动权（由 enemyThrowTick 推进） */
  }
  /* 2026-11-25：一旦这颗已经起手（前摇/已在空中），看见你也不许取消 ——
     不然「抬到一半突然收回手」，观感像抽筋，也浪费了已经占住的名额。
     只有「还没起手」时才按 A 方案处理：看得见就改用枪。 */
  const _mineS = (typeof nadeRoundMine==='function') ? nadeRoundMine(e) : null;
  const _committed = ((e.throwT||0) > 0) || !!(_mineS && (_mineS.state==='windup' || _mineS.state==='air'));
  if(e.sees && !_committed){
    if(typeof nadeRoundCancel==='function')nadeRoundCancel(e,'sees');
    /* 2026-11-25 修 bug（用户视频：门口站 8 秒，既不扔雷也不进屋）：
       门外能直接看见屋里的人 → 每帧都在这里"取消→重排→再取消"，而重排又总是先排投雷，
       于是这个人被永久钉在门外。取消的同时把这一间房的投雷计划标记成"放弃"，
       他才会走普通搜房流程进屋开打。 */
    if (s){ s.fragGiveUp = true; s.fragAt = uiT; }
    return false;
  }
  const {room,via}=searchEntryFragTarget(L,s,p);
  const slot=nadeRoundJoin(L,e,p.door,p.exitSide,room,s);
  if(!slot){
    /* 这一轮还欠一颗、只是没到节奏：站在门外等，别趁机溜进屋 */
    /* 这一轮还欠一颗、只是没到节奏：站在门外等，别趁机溜进屋 */
    if(_r0 && !(p.door && p.door.broken)){
      const _cap5=(nadeRoundEntryCfg()||{}).maxPerRound;
      const _capV=(_cap5===undefined?2:_cap5);
      const _TH5=(typeof enemyThrowDef==='function')?enemyThrowDef():null;
      const _gapV=(_TH5&&_TH5.gap!==undefined)?_TH5.gap:3.5;
      if(((_r0.thrown)||0)<_capV && (uiT-(_r0.lastRelease===undefined?-1e9:_r0.lastRelease))<_gapV)return true;
    }
    return why0('no-slot')&&false;        /* 名额满/轮次关闭：交还搜房 */
  }
  if(slot.state==='cancel')return why0('stale')&&false; /* 这一条已经废了：等轮次清理，别原地打转 */
  if(slot.state==='air')return true;
  /* 概率门槛（沿用旧契约）：一轮的第一颗走 firstChance，补投走 followChance。
     掷不中就作废这一条、直接进屋搜 —— 别让人机在门口反复试。 */
  {
    const _cfg3 = nadeRoundEntryCfg() || {};
    const _r3 = slot.order;
    const _first3 = !((_r3.thrown || 0) > 0 ||
      _r3.slots.some(o => o !== slot && (o.state === 'windup' || o.state === 'air')));
    const _p3 = _first3 ? _cfg3.firstChance : _cfg3.followChance;
    if (_p3 !== undefined && _p3 !== null && Math.random() > _p3){
      slot.state = 'cancel'; slot.cancelReason = 'chance';
      if (s) { s.fragGiveUp = true; s.fragAt = uiT; }
      return why0('chance') && false;
    }
  }
  const targetRoom=slot.order.room;
  slot.order.viaConnectedRoom ??= targetRoom===room && via;
  /* 起手这一刻位置要严格（不能站在门里就开始拉环）；前摇之后的复核才带 windupDrift 容差 */
  if (slot.since === undefined) slot.since = uiT;
  const _held = uiT - slot.since;
  let f=enemyDoorFragFrame(L,e,targetRoom,p.door,p.exitSide,via,0,slot.state==='windup');
  if(!f)f=enemyDoorFragFrame(L,e,targetRoom,p.door,p.exitSide,via,0,
    nadeRoundPendingCount(slot.order)>0 || (slot.order.thrown||0)>0);
  /* 被顶到门槛上（2026-11-25 用户反馈「准备扔的那一刹那被队友挤了一下就不扔了」）：
     只要人就贴在门口那一圈里（门中心距离 ≤ 半宽 + 半径 + 12），就允许带 allowInside
     直接起手 —— 他本来就已经在门槛上了，再要求严格的外侧站位只会让这一颗永远扔不出去。 */
  if(!f && typeof roomDoorFrame === 'function'){
    const _fr = roomDoorFrame(p.door);
    if(_fr){
      const _halfF = Math.min(_fr.w, _fr.h) / 2;
      if(Math.hypot(e.x - _fr.cx, e.y - _fr.cy) <= _halfF + ((e.r||13)) + 12)
        f = enemyDoorFragFrame(L,e,targetRoom,p.door,p.exitSide,via,0,true);
    }
  }
  /* 保底（2026-11-25 用户反馈「有时候一颗都不扔，还会进屋又出去又进来」）：
     占着名额却一直被挤出合法框（被同伴顶、被路过的人挡住），超过 1.2 秒就
     允许"站在门口/门里那一侧"直接扔 —— 宁可炸在门槛上，也别让人在门口反复进进出出。 */
  if(!f && _held > 1.2 && !((e.throwT||0) > 0)) f=enemyDoorFragFrame(L,e,targetRoom,p.door,p.exitSide,via,0,true);
  if(!f){ nadeRoundReleaseSlot(e); return why0('no-frame')&&false; } /* 只是还没走到门口，不取消轮次 */
  const why=nadeRoundBegin(L,e,slot.order,f);
  if(why==='no-spot' && nadeRoundPendingCount(slot.order)+(slot.order.thrown||0)>0){
    // 队友刚到门边时，当前角度可能没有第二个安全落点。释放临时占位，让他沿路线继续走。
    s.fragSpotRetry={door:p.door,side:p.exitSide,x:e.x,y:e.y,until:uiT+.2};
    nadeRoundReleaseSlot(e);
    return why0('support-reposition')&&false;
  }
  if(why!=='windup'){ nadeRoundCancel(e,why); return why0('begin-'+why)&&false; }
  s.fragSpotRetry=null;
  /* 让"谁占着这扇门"对旧接口可见：搜房等待逻辑与测试都靠 enemyDoorFragReservation 判断 */
  if(typeof enemyDoorFragReserve==='function')enemyDoorFragReserve(e,slot.order);
  if(s)s.entryFragSupport=slot.order;
  return true;
}
function searchEntryFragWaitForAlly(L,e,s,p){
  const cfg=DataTHROW.roomEntry;
  if(!cfg || !p.exitSide)return false;
  if(typeof searchEntryFragStuck==='function' && searchEntryFragStuck(e,s))return false;
  if(typeof nadeRoundOn==='function' && nadeRoundOn() && (typeof nadeRoundWanted!=='function' || nadeRoundWanted(L,e,p))){
    /* 这一轮还欠一颗时，人一直钉在门口等（哪怕当前路点已经不是那扇门）：
       否则它扔完第一颗就进门了，第二颗永远没机会出手。 */
    const _mine=nadeRoundMine(e);
    if(_mine){
      const _cap=(cfg.maxPerRound===undefined?2:cfg.maxPerRound);
      const _TH=(typeof enemyThrowDef==='function')?enemyThrowDef():null;
      const _gap=(_TH&&_TH.gap!==undefined)?_TH.gap:3.5;
      if(_mine.state==='windup'||_mine.state==='air')return true;
      if((_mine.thrown||0)<_cap && (uiT-(_mine.lastRelease===undefined?-1e9:_mine.lastRelease))<_gap)return true;
    }
    return nadeRoundSearchTick(L,e,s,p,1/60);
  }
  /* 已经接手了那颗补投：之后每帧都推进它（不管当前是 approach 还是 cross） */
  if(s.entryFrag && s.entryFrag.coop){ s.fragAt=uiT; return enemyDoorFragTick(L,e,s.entryFrag,1/60); }
  /* 队友接手补第二颗：不用等自己走到门口，站在门外就能直接把这一颗补上。
     这条要排在「兜底计时」之前 —— 接手是进展，不是卡在门口干耗。 */
  const mate=searchEntryFragCoopMate(L,e,p);
  if(mate && !s.entryFrag)searchEntryFragCoopStart(L,e,s,p,mate);
  if(mate && s.entryFrag){
    s.fragAt=uiT;
    return enemyDoorFragTick(L,e,s.entryFrag,1/60);
  }
  if(searchEntryFragBudgetUsed(s, e, p))return false;
  const order=enemyDoorFragReservation(L,e,p.door,p.exitSide,false);
  if(!order || order.owner===e)return false;
  const f=roomDoorFrame(p.door);
  const depth=(f.vertical?e.x-f.cx:e.y-f.cy)*p.exitSide;
  if(depth>=0 || dist(e.x,e.y,f.cx,f.cy)>cfg.waitDistance)return false;
  s.entryFragSupport=order;
  return true;
}
function searchEntryFragTick(L,e,s,p,dt){
  if(typeof nadeRoundOn==='function' && nadeRoundOn() && (typeof nadeRoundWanted!=='function' || nadeRoundWanted(L,e,p)))return nadeRoundSearchTick(L,e,s,p,dt);
  /* 这一轮刚打满：附近的人别再补（含走旧实现的那种），直接进屋搜 */
  if(e && e.fragHoldUntil && uiT < e.fragHoldUntil)return false;
  const {room,via:viaConnectedRoom}=searchEntryFragTarget(L,s,p), support=s.entryFragSupport;
  if(!room)return false;
  if(e.sees && !((e.throwT||0) > 0))return false;   /* 已起手的这颗不许因为看见而中断 */
  /* 队友接手补第二颗优先于兜底计时（接手是进展） */
  if(!s.entryFrag){
    const mate=searchEntryFragCoopMate(L,e,p);
    if(mate && searchEntryFragCoopStart(L,e,s,p,mate)){
      s.fragAt=uiT;
      return enemyDoorFragTick(L,e,s.entryFrag,dt);
    }
  }
  if(searchEntryFragBudgetUsed(s, e, p))return false;
  if(support?.door===p.door && support.side===p.exitSide && support.nade)return false;
  const saved=s.entryFrag;
  /* 每真的投出一颗雷就把兜底计时清零：投第二颗、等这颗爆炸都算正常进度，
     只有「一直没进展」才触发放弃。 */
  if(saved && saved.nade !== s._fragNade){ s._fragNade = saved.nade; s.fragAt = uiT; }
  if(saved?.room===room)return saved.door===p.door && enemyDoorFragTick(L,e,saved,dt);
  if(!DataTHROW.roomEntry)return false;
  /* 2026-11-25 反馈：整队排队等同一个人把两颗都扔完太拖。
     第一颗已经在飞、而投掷者还没开始补第二颗时，同门同侧、同样站在屋外的队友直接接手补这一颗。
     同一轮只允许一个队友接手：接手时把原订单的 follow 消费掉，并给门记一个时间戳兜住同帧多人。
     点数位置由 enemyDoorFragSpot 的 previous（首颗落点）做 minSeparation 分离，不会两颗砸同一个坑。 */
  if(!saved){
    const mate=enemyDoorFragReservation(L,e,p.door,p.exitSide,false);
    const owner=mate && mate.owner;
    const coopOK = mate && owner && owner!==e && mate.nade && mate.follow &&
      !(owner.roomEntryThrow && owner.roomEntryThrow.order===mate) && !((owner.throwT||0)>0) &&
      uiT - ((p.door && p.door._fragCoopAt) || -999) > 8;
    if(coopOK){
      mate.follow=false;
      if(p.door)p.door._fragCoopAt=uiT;
      const coop={room,clueRoom:s.roomObj,door:p.door,side:p.exitSide,viaConnectedRoom:false,search:s,
        isActive:searchEntryFragStillValid,nade:mate.nade,coop:true,
        stand:{x:e.x,y:e.y},follow:true,followBy:uiT+8};
      s.entryFrag=coop;
      return enemyDoorFragTick(L,e,coop,dt);
    }
  }
  if(!enemyDoorFragFrame(L,e,room,p.door,p.exitSide,viaConnectedRoom) || !searchCarefulRoll(e))return false;
  const order={room,clueRoom:s.roomObj,door:p.door,side:p.exitSide,viaConnectedRoom,search:s,isActive:searchEntryFragStillValid};
  s.entryFrag=order;
  return enemyDoorFragTick(L,e,order,dt);
}

function searchSweepCount(L, e){
  if (!SEARCH_DEF.on || !e) return 0;
  if (!searchCarefulRoll(e)) return 0;
  const room = searchRoomOf(L, e.x, e.y) || (e.lastKnown ? searchRoomOf(L, e.lastKnown.x, e.lastKnown.y) : null);
  if (!room) return 0;
  let n = 0;
  const x0 = room.x + SEARCH_DEF.inset, y0 = room.y + SEARCH_DEF.inset;
  const x1 = room.x + room.w - SEARCH_DEF.inset, y1 = room.y + room.h - SEARCH_DEF.inset;
  for (let y = y0; y <= y1; y += SEARCH_DEF.cell){
    for (let x = x0; x <= x1; x += SEARCH_DEF.cell){
      if (typeof navBlockedAt === 'function' && navBlockedAt(L, x, y)) continue;
      n++;
    }
  }
  return n;
}

/* ================= 门前投雷"轮次"状态（2026-11-25 局部重构） =================
   把"谁在投、投到哪、占着哪个名额、什么时候必须交还"从隐式的 e.throwT /
   order.follow / order._coopUsed / door._fragCoopAt / e.roomEntryForce 里拿出来，
   集中到一份显式的轮次记录上。

   - 轮次身份：门 + 门侧 + 阵营；发起时记下来源搜查任务，用来判断情报是否失效。
   - 轮次只负责：成员、名额（最多 2 颗）、截止时间、完成条件。
   - 每位成员一条 slot：执行人、计划落点、状态（idle/windup/air/cancel）、自己那颗雷。
   - 容量口径：场上敌雷 + 已预约未出手，两项各计一次。
   - 出手/取消都只有一个入口，重复调用得同一个结果。

   生产路径由 DataTHROW.roomEntry.useRound 控制；关掉即回到旧实现（便于 A/B 与回退）。 */
var NADE_ROUND = { on: true, rounds: new Map(), seq: 0, doorIds: new WeakMap() };

function nadeRoundEntryCfg(){
  return (typeof DataTHROW === 'object' && DataTHROW && DataTHROW.roomEntry) ? DataTHROW.roomEntry : null;
}
function nadeRoundOn(){
  const cfg = nadeRoundEntryCfg();
  return !!(NADE_ROUND.on && cfg && cfg.useRound !== false);
}
function nadeRoundDoorId(door){
  if (!door) return 'none';
  let id = NADE_ROUND.doorIds.get(door);
  if (!id){ id = ++NADE_ROUND.seq; NADE_ROUND.doorIds.set(door, id); }
  return id;
}
function nadeRoundFaction(e){
  try { return (typeof combatFaction === 'function') ? combatFaction(e) : 'enemy'; } catch (err){ return 'enemy'; }
}
function nadeRoundKey(door, side, e){
  return nadeRoundDoorId(door) + '|' + side + '|' + nadeRoundFaction(e);
}
function nadeRoundGet(door, side, e){
  return NADE_ROUND.rounds.get(nadeRoundKey(door, side, e)) || null;
}
function nadeRoundPendingCount(round){
  if (!round) return 0;
  let n = 0;
  for (const sl of round.slots) if (sl.state === 'windup') n++;
  return n;
}
/* 容量读口：场上敌雷（已出手、物理系统还没移除）+ 已预约未出手。两项各计一次。 */
function nadeRoundCapacity(){
  const live = (typeof nadeLiveEnemy === 'function') ? nadeLiveEnemy() : 0;
  let reserved = 0;
  for (const r of NADE_ROUND.rounds.values()) reserved += nadeRoundPendingCount(r);
  return { live: live, reserved: reserved, total: live + reserved };
}
function nadeRoundCapacityMax(){
  const TH = (typeof enemyThrowDef === 'function') ? enemyThrowDef() : null;
  return (TH && TH.maxLive !== undefined) ? TH.maxLive : 2;
}
/* 诊断/验收用：把轮次摊平成可读结构（出口只读，不参与判定） */
function nadeRoundDiag(door){
  const out = [];
  for (const r of NADE_ROUND.rounds.values()){
    if (door && r.door !== door) continue;
    out.push({
      side: r.side, faction: r.faction, room: r.room && r.room.name,
      closed: r.closed, left: +((r.deadline || 0) - uiT).toFixed(2),
      slots: r.slots.map(sl => ({
        owner: sl.owner ? (sl.owner.type || '?') : null,
        state: sl.state,
        spot: sl.spot ? { x: +sl.spot.x.toFixed(1), y: +sl.spot.y.toFixed(1) } : null,
        hasNade: !!sl.nade, age: sl.at === undefined ? null : +(uiT - sl.at).toFixed(2)
      }))
    });
  }
  return out;
}
function nadeRoundSlots(door, side, e){
  const r = nadeRoundGet(door, side, e);
  return r ? r.slots.slice() : [];
}

/* 选点：先试确定性候选，再做有上限的采样；每个候选都要躲开同轮已计划的落点。 */
/* 确定性候选：目标房间内的一张静态网格（不吃随机数）。
   先按"离投掷者近 → 远"排，再按间距筛 —— 同样的局面永远给出同样的首选落点，
   联机和回放里不会出现"同一颗雷每次落点都不一样"。 */
/* ==== 落点记忆（2026-11-25）=========================================
   以前"分开落点"只在**同一轮**里生效（avoid.spots）。两个敌人先后各成一枚
   （一个先到、一个后到，或者上一轮已经关掉），就各自挑最近的合法点，
   于是两颗雷叠在同一块地方。这里维护一份跨轮次的落点记忆，
   连同"当前空中/地上还没爆的雷"一起，作为软性避让。 */
var NADE_SPOT_MEM = [];
function nadeSpotRemember(x, y){
  if (!isFinite(x) || !isFinite(y)) return;
  NADE_SPOT_MEM.push({ x: x, y: y, t: uiT });
  if (NADE_SPOT_MEM.length > 24) NADE_SPOT_MEM.shift();
}
function nadeSpotBusy(x, y, sep){
  const ttl = 8;
  for (let i = NADE_SPOT_MEM.length - 1; i >= 0; i--){
    if (uiT - NADE_SPOT_MEM[i].t > ttl) NADE_SPOT_MEM.splice(i, 1);
  }
  for (const m of NADE_SPOT_MEM) if (Math.hypot(x - m.x, y - m.y) < sep) return true;
  const list = (typeof nades !== 'undefined' && nades) ? nades : [];
  for (const n of list){
    if (!n) continue;
    const nx = (n.tx === undefined ? n.x : n.tx), ny = (n.ty === undefined ? n.y : n.ty);
    if (Math.hypot(x - nx, y - ny) < sep) return true;
  }
  return false;
}
function nadeRoundDetCandidates(L, e, f, avoid, TH){
  const cfg = nadeRoundEntryCfg() || {};
  const room = (avoid && avoid.room) || null;
  if (!room || !isFinite(room.x) || !isFinite(room.w)) return [];
  const step = Math.max(24, Math.min(64, cfg.gridStep || 32));
  const inset = Math.min(40, cfg.inset === undefined ? 12 : cfg.inset);
  const tx = (f && isFinite(f.cx)) ? f.cx : (room.x + room.w / 2);
  const ty = (f && isFinite(f.cy)) ? f.cy : (room.y + room.h / 2);
  const out = [];
  for (let y = room.y + inset; y <= room.y + room.h - inset; y += step){
    for (let x = room.x + inset; x <= room.x + room.w - inset; x += step){
      if (typeof navBlockedAt === 'function' && navBlockedAt(L, x, y)) continue;
      /* 注意：门内投雷本来就是"屋外 → 屋内"，这里**不能**套 nadeRoomOK（那是路边互斥用的） */
      if (typeof clearWalkLine === 'function' && !clearWalkLine(L, x, y, tx, ty)) continue;
      /* 预选与出手复核共用同一套几何：这里过不了的落点，撒手时也一定会被否掉 */
      if (typeof enemyDoorFragLanding === 'function' && !enemyDoorFragLanding(L, e, room, f, x, y, TH)) continue;
      /* 1126e：队友本人也算占位。以前只避开队友的落点，队友站在那儿，
         撒手那一刻才被 enemyNadeCrowded 拒掉（白抬手一秒）。这里提前过滤。 */
      if (avoid && avoid.people){
        let _crowded = false;
        for (const p of avoid.people){
          if (!p || p === e) continue;
          if (Math.hypot(x - p.x, y - p.y) < ((e.r || 13) + (p.r || 13) + 6)){ _crowded = true; break; }
        }
        if (_crowded) continue;
      }
      const d = Math.hypot(x - e.x, y - e.y);
      /* 太近会把自己炸进去 —— 但小屋进深不足时要跟着放宽，否则一个候选都不剩 */
      const _roomDepth = Math.min(room.w, room.h);
      const _dMin = _roomDepth < 260 ? Math.max(46, _roomDepth * 0.35) : 90;
      if (d < _dMin) continue;
      out.push({ x: x, y: y, d: d });
    }
  }
  out.sort((a, b) => a.d - b.d);
  /* 跨轮次避让：已有雷/刚炸过的坑附近不放新落点 */
  const _sepBase = (cfg.sepGuard === undefined ? 42 : cfg.sepGuard);
  const _roomDepth2 = Math.min(room.w, room.h);
  const _sep2 = _roomDepth2 < 260 ? Math.max(44, _sepBase * 1.1) : Math.max(64, _sepBase * 1.7);
  const _free = out.filter((c) => !nadeSpotBusy(c.x, c.y, _sep2));
  return _free.length ? _free : out;
}
function nadeRoundSpotAvoid(round,e){
  const avoid={room:round.room,side:round.side,spots:[],people:[]};
  if(round.lastSpot)avoid.spots.push(round.lastSpot);
  for(const sl of round.slots){
    if(sl.owner===e || sl.state==='cancel')continue;
    if(sl.owner)avoid.people.push(sl.owner);
    if(sl.nade)avoid.spots.push({x:sl.nade.tx,y:sl.nade.ty});
    else if(sl.spot)avoid.spots.push(sl.spot);
  }
  return avoid;
}
function nadeRoundSpotClear(spot,avoid){
  const cfg=nadeRoundEntryCfg() || {};
  const sep=cfg.sepGuard ?? cfg.minSeparation ?? 42;
  const depth=Math.min(avoid.room?.w ?? Infinity,avoid.room?.h ?? Infinity);
  const min=depth<260 ? Math.max(22,Math.min(sep,depth*.42)) : sep;
  return avoid.spots.every(p=>Math.hypot(spot.x-p.x,spot.y-p.y)>=min);
}
/* 优先覆盖门轴两侧和不同深度，窄房仍使用可行的分离落点。 */
function nadeRoundCoverageScore(point,avoid,frame){
  if(!avoid.spots.length)return 0;
  let score=Infinity;
  for(const other of avoid.spots){
    const dx=Math.abs(point.x-other.x),dy=Math.abs(point.y-other.y);
    const lateral=frame.vertical ? dy : dx;
    const depth=frame.vertical ? dx : dy;
    score=Math.min(score,Math.hypot(dx,dy)+Math.min(lateral,depth)*2);
  }
  return score;
}
function nadeRoundPickSpot(L,e,f,avoid,TH,accept){
  const cfg=nadeRoundEntryCfg() || {};
  const tries=Math.max(1,Math.min(24,cfg.spotTries||8));
  const sep=cfg.sepGuard ?? cfg.minSeparation ?? 42;
  const depth=Math.min(avoid.room?.w ?? Infinity,avoid.room?.h ?? Infinity);
  const sampleSep=depth<260 ? Math.max(44,sep*1.1) : Math.max(64,sep*1.7);
  const usable=spot=>nadeRoundSpotClear(spot,avoid) && (!accept || accept(spot));
  /* ① 确定性候选优先 */
  const det = nadeRoundDetCandidates(L, e, f, avoid, TH);
  const score=spot=>nadeRoundCoverageScore(spot,avoid,f);
  let best=null,bestScore=-Infinity;
  for(const spot of det){
    if(!usable(spot))continue;
    if(!avoid.spots.length)return {x:spot.x,y:spot.y};
    const value=score(spot);
    if(value>bestScore){best=spot;bestScore=value;}
  }
  if(best)return {x:best.x,y:best.y};
  /* ② 兜底：旧的有上限采样 */
  for (let i = 0; i < tries; i++){
    const spot = (typeof enemyDoorFragSpot === 'function')
      ? enemyDoorFragSpot(L, e, { room: (avoid && avoid.room) || null, side: (avoid && avoid.side) || 0,
          nade: null }, f, TH)
      : null;
    if (!spot) continue;
    if (!usable(spot)) continue;
    if (nadeSpotBusy(spot.x, spot.y, sampleSep)) continue;
    if(!avoid.spots.length)return spot;
    const value=score(spot);
    if(value>bestScore){best=spot;bestScore=value;}
  }
  return best;
}

/* 找/建轮次，返回该执行人的 slot。名额满返回 null（调用方应把控制权交还搜房）。 */
/* ==== 1126e 门口站位（stance）========================================
   每扇门 × 每侧 × 每阵营只放两个站位：首投位、补投位。
   理由：以前两个人（甚至三个）会挤在同一点，谁也没法稳定抬手 —— 前摇被推挤顶出
   合法框就会自己取消；而"冻结推挤"又会让没站位的人堆成一团互相顶死。
   所以先把站位定下来（原子占位），后面才允许冻结"已占到站位"的人。 */
var NADE_STANCE = { doors: new WeakMap(), seq: 0 };
function nadeStanceKey(door, side, faction){
  const id = nadeRoundDoorId(door);
  return id + '|' + side + '|' + faction;
}
/* 站位点是否真的能站：直接拿门框判据验收（忽略门开合，占位时门可能还没推开）。
   以前这里只算一个"几何上差不多"的点，站上去不一定满足深度/距离判据，
   于是抬手前一秒被自检否掉 —— 这也是推挤豁免一直没法打开的根子。 */
function nadeStanceLegal(L, e, room, door, side, x, y){
  if (typeof enemyDoorFragFrame !== 'function') return true;
  const probe = { x: x, y: y, r: (e && e.r) || 13 };
  try {
    return !!enemyDoorFragFrame(L, probe, room, door, side, false, 0, false, true);
  } catch (err){ return true; }
}
/* 两个站位的世界坐标：沿门轴左右各一个点，退到门外"半厚 + 半径 + 10"处。
   2026-11-25：改成"取点即验收" —— 沿门轴 × 往外两个方向搜一圈，
   先找到能通过门框判据的点；都找不到才退回原来的名义点（保持老行为）。 */
function nadeStanceSpots(door, side, e, L, room){
  const f = (typeof roomDoorFrame === 'function') ? roomDoorFrame(door) : null;
  if (!f) return null;
  const r = (e && e.r) || 13;
  const out0 = (f.vertical ? f.w : f.h) / 2 + r + 10;
  const along = f.vertical ? f.h : f.w;
  const span = Math.min(Math.max(along / 2 - r - 4, 0) * 0.6, 22);
  const nx = f.vertical ? side : 0, ny = f.vertical ? 0 : side;
  const ax = f.vertical ? 0 : 1, ay = f.vertical ? 1 : 0;
  const at = (sx, out) => ({ x: f.cx + nx * out + ax * sx, y: f.cy + ny * out + ay * sx });
  const nominal = [at(span, out0), at(-span, out0)];
  if (!L || !room || typeof enemyDoorFragFrame !== 'function') return nominal;

  const _ok = (p) => nadeStanceLegal(L, e, room, door, side, p.x, p.y);
  const _sep = Math.max(2.2 * r, 26);
  const spots = [];
  const alongs = [span, span * 0.66, span * 0.33, 0, -span * 0.33, -span * 0.66, -span];
  const outs = [0, 8, 16, 26, 38, -8];
  for (const sgn of [1, -1]){
    let best = null;
    for (const dOut of outs){
      for (let i = 0; i < alongs.length; i++){
        const sx = sgn * Math.abs(alongs[i]) * (i === 0 ? 1 : 1);
        const p = at(sx, out0 + dOut);
        if (!_ok(p)) continue;
        if (spots.length && Math.hypot(p.x - spots[0].x, p.y - spots[0].y) < _sep) continue;
        best = p; break;
      }
      if (best) break;
    }
    spots.push(best || nominal[sgn > 0 ? 0 : 1]);
  }
  return spots;
}
function nadeStanceTable(door){
  let t = NADE_STANCE.doors.get(door);
  if (!t){ t = new Map(); NADE_STANCE.doors.set(door, t); }
  return t;
}
/* 原子占位：返回 0/1；两个都被占（或都被别人名字占着）返回 -1 */
function nadeStanceClaim(door, side, e, L, room){
  if (!door || !e) return -1;
  const tab = nadeStanceTable(door);
  const key = nadeStanceKey(door, side, combatFaction(e));
  let row = tab.get(key);
  if (!row){ row = [null, null]; tab.set(key, row); }
  for (let i = 0; i < 2; i++){
    if (row[i] && row[i] !== e && !row[i].dead && !row[i].gone) continue;
    row[i] = e;
    /* 记在自己身上（WeakMap 不可枚举）：寻路/等待时要知道"该站哪一格" */
    const sp = nadeStanceSpots(door, side, e, L, room);
    e._stanceSpot = sp ? { door: door, side: side, idx: i, x: sp[i].x, y: sp[i].y } : null;
    return i;
  }
  return -1;
}
function nadeStanceSpotOf(e){ return (e && e._stanceSpot) ? e._stanceSpot : null; }
function nadeStanceRelease(door, side, e){
  if (!door || !e) return;
  if (e._stanceSpot && e._stanceSpot.door === door) e._stanceSpot = null;
  const tab = NADE_STANCE.doors.get(door);
  if (!tab) return;
  const row = tab.get(nadeStanceKey(door, side, combatFaction(e)));
  if (!row) return;
  for (let i = 0; i < 2; i++) if (row[i] === e) row[i] = null;
}
function nadeStanceFreeSpots(door, side, e, L, room){
  const spots = nadeStanceSpots(door, side, e, L, room);
  if (!spots) return 0;
  const tab = NADE_STANCE.doors.get(door);
  const row = tab && tab.get(nadeStanceKey(door, side, combatFaction(e)));
  if (!row) return 2;
  let n = 0;
  for (let i = 0; i < 2; i++) if (!row[i] || row[i] === e || row[i].dead || row[i].gone) n++;
  return n;
}
function nadeRoundJoin(L, e, door, side, room, search){
  if (!door || side === undefined || side === null) return null;
  const cfg = nadeRoundEntryCfg() || {};
  const key = nadeRoundKey(door, side, e);
  let r = NADE_ROUND.rounds.get(key);
  if (!r){
    r = { key: key, door: door, side: side, faction: nadeRoundFaction(e), room: room || null,
      search: search || null, slots: [], closed: false,
      created: uiT, deadline: uiT + (cfg.roundTtl || 12) };
    NADE_ROUND.rounds.set(key, r);
  }
  if (r.closed) return null;
  const mine = r.slots.find(sl => sl.owner === e);
  const _cap = cfg.maxPerRound === undefined ? 2 : cfg.maxPerRound;
  const _spent = (r.thrown || 0) + r.slots.filter(sl => sl.state === 'windup' || sl.state === 'idle').length;
  if (mine && (mine.state === 'done' || mine.state === 'cancel')){
    /* 这一轮总共只发 maxPerRound 颗（双人各一颗 / 单人补第二颗）；发完就交还搜房 */
    if (mine.state === 'done' && _spent < _cap){
      /* 同一个人补第二颗：必须等上一颗按"全队节奏"过去（gap 秒）。
         两个人各扔一颗才是同时撒手；一个人连扔两颗同时飞等于无敌连发。 */
      const _TH2 = (typeof enemyThrowDef === 'function') ? enemyThrowDef() : null;
      const _gap2 = (_TH2 && _TH2.gap !== undefined) ? _TH2.gap : 3.5;
      if ((uiT - (r.lastRelease === undefined ? -1e9 : r.lastRelease)) < _gap2) return null;
      r.slots = r.slots.filter(sl => sl !== mine);
    }
    else return null;
  } else if (mine) return mine;
  if (_spent >= _cap) return null;
  const cap = cfg.maxPerRound === undefined ? 2 : cfg.maxPerRound;
  /* 硬上限：一轮里"没作废"的 slot 数量不得超过配额（不管它现在是 idle/windup/air/done） */
  if (r.slots.filter(sl => sl.state !== 'cancel').length >= cap) return null;
  /* 站位：两个都有人就交还移动权去外面等（别挤在门口互相顶） */
  const _st = (typeof nadeStanceClaim === 'function') ? nadeStanceClaim(door, r.side, e, L, room) : 0;
  if (_st < 0) return null;
  const sl = { owner: e, state: 'idle', spot: null, nade: null, at: uiT, order: r, stance: _st };
  r.slots.push(sl);
  return sl;
}
/* 只是"还没走到门口"这类无害失败：把 idle 的 slot 摘掉，轮次留给之后/别人用 */
function nadeRoundReleaseSlot(e){
  for (const [key, r] of Array.from(NADE_ROUND.rounds.entries())){
    const i = r.slots.findIndex(sl => sl.owner === e && sl.state === 'idle');
    if (i >= 0){
      r.slots.splice(i,1);
      nadeStanceRelease(r.door,r.side,e);
    }
    if (!r.slots.length) NADE_ROUND.rounds.delete(key);
  }
}
/* 明确取消：同一 slot 重复取消只留第一条原因 */
function nadeRoundCancel(e, reason){
  for (const r of NADE_ROUND.rounds.values()){
    const sl = r.slots.find(s => s.owner === e);
    if (!sl) continue;
    if (sl.state === 'cancel') return sl.cancelReason;
    const _why = reason || 'cancel';
    /* 补投者在前摇前失败时，已经抬手的队友继续投，保留他的计时和推挤豁免。 */
    const peerWinding = sl.state === 'idle' && r.slots.some(other =>
      other.state === 'windup' && other.owner?.throwT > 0 && other.owner.roomEntryThrow?.round === r);
    const whole = (r.thrown || 0) === 0 && !peerWinding;
    if (whole){
      for (const s2 of r.slots){
        if (s2.state !== 'windup' && s2.state !== 'idle') continue;
        s2.state = 'cancel';
        s2.cancelReason = _why;
        const o2 = s2.owner;
        if (o2){
          if (typeof nadeStanceRelease === 'function') nadeStanceRelease(r.door, r.side, o2);
          if (o2.roomEntryThrow) o2.roomEntryThrow = null;
          o2.roomEntryForce = false;
          o2.throwT = 0;
          if (o2.roomSearch) o2.roomSearch.fragGiveUp = true;
        }
      }
      r.closed = true;
      r.closeReason = _why;
    } else {
      sl.state = 'cancel';
      sl.cancelReason = _why;
      if (typeof nadeStanceRelease === 'function') nadeStanceRelease(r.door, r.side, sl.owner);
      if (e && e.roomEntryThrow) e.roomEntryThrow = null;
      if (e){ e.roomEntryForce = false; e.throwT = 0; }
    }
    if (typeof logInfo === 'function') logInfo('nade', '取消门前投雷 · ' + _why + (whole ? '（整轮）' : '（仅补投）'));
    return _why;
  }
  return null;
}
/* 起手：占一个名额 + 预约落点 + 进入前摇。失败时释放临时预约并返回原因。 */
function nadeRoundBegin(L, e, round, f){
  const TH = (typeof enemyThrowDef === 'function') ? enemyThrowDef() : null;
  if (!TH || !f) return 'no-frame';
  const cap = nadeRoundCapacity();
  if (cap.total >= nadeRoundCapacityMax()) return 'capacity';
  const spot = nadeRoundPickSpot(L,e,f,nadeRoundSpotAvoid(round,e),TH);
  if (!spot) return 'no-spot';
  const mySlot = round.slots.find(sl => sl.owner === e);
  if (!mySlot) return 'no-slot';
  mySlot.spot = spot;
  mySlot.state = 'windup';
  mySlot.at = uiT;
  e.roomEntryThrow = { round: round, order: round, x: mySlot.spot.x, y: mySlot.spot.y, at: uiT };
  e.roomEntryForce = true;
  if (typeof startEnemyThrow === 'function') startEnemyThrow(e, TH, true);
  /* 同轮补投跟随首投节奏，保留同帧出手的机会。 */
  const lead=round.slots.find(sl=>sl!==mySlot&&sl.state==='windup'&&sl.owner?.throwT>0);
  if(lead){
    const roll=Math.random();
    const delay=roll<.2 ? 0 : .7*(roll-.2)/.8;
    e.throwT=lead.owner.throwT+delay;
  }
  return 'windup';
}
/* 出手：预约转实体（只有一处入口，重复调用返回同一颗） */
function nadeRoundReleased(e, nade){
  for (const r of NADE_ROUND.rounds.values()){
    const sl = r.slots.find(s => s.owner === e);
    if (!sl) continue;
    if (sl.state === 'air') return sl.nade;
    /* 兜底硬闸：这一轮已经发满配额就不许再出手（哪怕 slot 被谁偷偷复活） */
    {
      const _capHard = (nadeRoundEntryCfg() || {}).maxPerRound;
      if ((r.thrown || 0) >= (_capHard === undefined ? 2 : _capHard)){
        sl.state = 'cancel';
        sl.cancelReason = 'cap';
        if (e && e.roomEntryThrow) e.roomEntryThrow = null;
        if (e){ e.roomEntryForce = false; e.throwT = 0; }
        return null;
      }
    }
    sl.state = 'air';
    sl.nade = nade;
    sl.at = uiT;
    if (nade){
      const previous=r.lastNade;
      if(previous && previous.by!==e && previous.fuse>0 && nades.includes(previous)){
        // 出手与引信分开对齐，以先出手那颗的剩余时间为准。
        nade.fuse=previous.fuse+0.5+Math.random()*0.5;
      }
      r.lastNade=nade;
      r.lastSpot = {x:nade.tx,y:nade.ty};
      nade.__round = r.key;
    }
    r.thrown = (r.thrown || 0) + 1;
    /* 出手后按"全队下一个"的既有节奏占用一次全局间隔（队友同时扔走 pending 分支，不受影响） */
    const _TH = (typeof enemyThrowDef === 'function') ? enemyThrowDef() : null;
    if (typeof nadeSquadCd !== 'undefined') nadeSquadCd = (_TH && _TH.gap !== undefined) ? _TH.gap : 3.5;
    /* 单人补第二颗要按"全队节奏"隔开（两个人各一颗才允许同时撒手） */
    r.lastRelease = uiT;
    /* 这一轮的配额用完了：所有参与者都不许再开新轮（否则扔完立刻又组一轮，变成连发）。
       想再扔得等下一次搜房重新进入（新的 roomSearch），或者别的门。 */
    const _capNow = (nadeRoundEntryCfg() || {}).maxPerRound;
    if ((r.thrown || 0) >= (_capNow === undefined ? 2 : _capNow)){
      r.closed = true;
      /* 同一扇门这一侧打满了：**所有**在搜这栋房的同伙都别再补，直接进去。
         只给参与者置标记是不够的 —— 第三个没挤进轮次的人会立刻再开一轮，变成连发。 */
      for (const _o of (typeof enemies !== 'undefined' ? enemies : [])){
        if (!_o || _o.dead || _o.gone) continue;
        if (typeof nadeRoundFaction === 'function' && nadeRoundFaction(_o) !== r.faction) continue;
        if (_o.roomSearch) _o.roomSearch.fragGiveUp = true;
        /* 就守在门附近的那几位也压住：换个人立刻又凑一轮 = 连发第三颗 */
        const _dc = r.door ? doorGateCenter(r.door) : null;
        if (_dc && Math.hypot(_o.x - _dc.x, _o.y - _dc.y) < 420) _o.fragHoldUntil = uiT + 6;
      }
    }
    return nade;
  }
  return null;
}
/* 每个模拟步推进一次：到期清理、情报失效清理、空轮次删除 */
function nadeRoundTick(dt){
  if (!NADE_ROUND.rounds.size) return;
  for (const [key, r] of Array.from(NADE_ROUND.rounds.entries())){
    /* ① 绝对时限：到点就把还举着手的人全部作废（名额立刻释放），
         已经出手的雷不追（它归物理系统管），但轮次本身不再接新成员。 */
    const _expired = (r.deadline !== undefined) && uiT > r.deadline;
    if (_expired) r.closed = true;
    for (const sl of r.slots){
      const e = sl.owner;
      const dead = !e || e.dead || e.gone;
      if (sl.state === 'windup' && dead){
        sl.state = 'cancel'; sl.cancelReason = 'dead';
      }
      if (sl.state === 'windup' && _expired){
        sl.state = 'cancel'; sl.cancelReason = 'ttl';
        if (e){ e.roomEntryThrow = null; e.throwT = 0; e.roomEntryForce = false;
          if (e.roomSearch){ e.roomSearch.fragGiveUp = true; } }
      }
      if (sl.state === 'windup' && !dead && e.alertT !== undefined && (e.alertT || 0) <= 0){
        sl.state = 'cancel'; sl.cancelReason = 'intel';
        e.roomEntryThrow = null; e.throwT = 0; e.roomEntryForce = false;
      }
      /* ② 门在拉环期间被关上/锁上 → 这一颗别再扔了（前摇白费），名额释放。
            1126e：这里以前用 95% 门槛，而起手用的是 60% —— 门 72% 时刚起手就被自己取消。
            现在统一走 doorGateOpen()，只有"真的关了/锁了"才取消。 */
      if (sl.state === 'windup' && !dead && e.roomEntryThrow && e.roomEntryThrow.order){
        const _d = e.roomEntryThrow.order.door || (r.door);
        const _bad = _d && !doorGateOpen(_d);
        if (_bad){
          sl.state = 'cancel'; sl.cancelReason = 'door';
          e.roomEntryThrow = null; e.throwT = 0; e.roomEntryForce = false;
          if (e.roomSearch){ e.roomSearch.fragGiveUp = true; }
        }
      }
      /* ③ 已经被别人带进屋（站在目标房间里）→ 本来想取消。
            2026-11-25：用户反馈「敌人会被另一个人挤进屋内，扔雷就中断了」——
            只要已经抬手（`throwT>0`）就是把这一颗扔完，不再因为位置变了而收手。
            没抬手的那种（还在 idle 阶段）照旧交给上面的选点逻辑处理。 */
      if (sl.state === 'windup' && !dead && typeof levelRoomAt === 'function' && r.room
          && !((e.throwT || 0) > 0)){
        const _L = (typeof cur === 'function') ? cur() : null;
        const _here = _L ? levelRoomAt(_L, e.x, e.y) : null;
        if (_here && _here === r.room){
          sl.state = 'cancel'; sl.cancelReason = 'inside';
          e.roomEntryThrow = null; e.throwT = 0; e.roomEntryForce = false;
          if (e.roomSearch){ e.roomSearch.fragGiveUp = true; }
        }
      }
      /* 已出手的雷被物理系统移除（炸了/落地消失）→ 这一条结束，控制权还给搜房 */
      if (sl.state === 'air' && (!sl.nade || (typeof nades !== 'undefined' && nades.indexOf(sl.nade) < 0))){
        sl.state = 'done';
      }
    }
    /* 给已到门口的队友一点起手时间。等待超时就按各自的倒计时出手。 */
    const _al=(nadeRoundEntryCfg()||{}).alignHold;
    const _hold=Math.max(0,_al===undefined?0.7:_al);
    for (const sl of r.slots){
      if (sl.state!=='windup') continue;
      const e2=sl.owner;
      if(!e2 || !(e2.throwT>0)) continue;
      const waiting=r.slots.some(o=>o!==sl && o.state==='idle');
      if(waiting && (uiT-(sl.at||0))<_hold && e2.throwT<0.06){ e2.throwT=0.06; }
    }
    const live = r.slots.some(sl => sl.state === 'windup' || sl.state === 'air');
    if (r.closed && !live){ NADE_ROUND.rounds.delete(key); continue; }
    if (uiT > r.deadline && !live){ r.closed = true; NADE_ROUND.rounds.delete(key); continue; }
    if (!live && r.slots.length && r.slots.every(sl => sl.state === 'cancel' || sl.state === 'done')) NADE_ROUND.rounds.delete(key);
  }
}
