/* ============================================================================
   瞭望塔（第 65 轮）
   ----------------------------------------------------------------------------
   用户 m10607：「新增建筑物，瞭望塔，上去之后，视野会变得非常远，但是视野的宽距
   会变小，当发现敌人时会向自己的队友实时播报敌人的位置」。

   三件事分开做，别混在一起：
     1. 能不能上去 —— 走到塔旁边按 E 爬，人在平台中心，按 E 下来；
     2. 视野怎么变 —— 只动两个乘数（data/covers.js 的 TOWER_TUNE），
        见 game/12-levels.js 的 seeRange() / seeFov()，别的地方一概不改；
     3. 播报 —— 塔上看到谁，就给谁盖一个 spotT 标记（自己屏幕上看得到），
        同时把位置塞进队友的 lastKnown（复用第 40 轮的 fleeCallBackup 那套字段）。

   铁律（和掩体那边一样）：
     · 塔是**建筑**不是掩体：st:'solid'、没有 hp，打不烂也不会碎；
     · 塔身照常挡视线挡子弹（sight 默认 'high'），所以人上塔以后不是"透视"，
       还是得靠视线；上塔只是看得更远更窄；
     · 播报**不是自动索敌**：只把位置告诉队友，打不打、怎么走还是 AI 自己决定。
   ============================================================================ */

/* 玩家正站在哪座塔上（null = 在地上）。存墙对象本身，不存坐标。 */
let towerSeat = null;
/* 已经被播报出去的敌人：`敌人 -> 剩余秒数`，画标记和给队友续时都用它 */
const towerSpots = new Map();
let towerPingT = 0;          /* 距离上次刷新队友情报过了多久 */

function towerTune(){
  return (typeof TOWER_TUNE !== 'undefined') ? TOWER_TUNE
       : { visionK: 2.3, fovK: 0.5, climbR: 74, spotT: 1.6, pingT: 2.6, pingR: 1400, maxSpot: 12,
           markT: 4.5, goR: 90, guardR: 260 };
}
/* 人上塔时，队友该围着哪儿待命（塔脚），供 companionFollow 的 anchor 用。
   视野窄了，塔底就是盲区，队友自然被拉回来守这一圈。 */
function towerAnchor(){
  if (!towerSeat) return (typeof player !== 'undefined') ? player : null;
  return towerFootPos(towerSeat);
}
/* 塔上报出去的情报，队友这边记多久（到期自己清） */
function towerMarkTick(dt){
  if (typeof allies === 'undefined' || !allies || !allies.length) return;
  for (const a of allies){
    if (!a || !a.towerMark) continue;
    a.towerMark.t -= dt;
    if (a.towerMark.t <= 0 || a.dead) a.towerMark = null;
  }
}
/* 塔上的平台中心（人站这儿） */
function towerFootPos(d){
  return { x: d.x + d.w * 0.5, y: d.y + d.h * 0.5 };
}
/* 人"站"的位置：抬起来的平台中心。平顶款没有 hi，就退回地基中心。
   注意：视线不能从这个点算（它在塔身碰撞箱上方，往下的射线会穿过自己的塔），
   算遮挡用 towerFootPos + towerRayStart，见 towerSees()。 */
function towerPlatPos(d){
  if (d.cov !== 'watchtower') return towerFootPos(d);
  const r = towerDeckRect(d, d.hi);
  /* 人是"脚踩在这个点上"画的（身体往上长），所以脚要落在板子的下三分之一，
     不然上半身会顶到板子上沿，看着像站在边缘上、还和栏杆穿模。 */
  return { x: r.x + r.w * 0.5, y: r.y + r.h * 0.74 };
}
/* 离得最近的一座塔（range 从塔的边缘算，跟门/箱子一个习惯） */
function towerNear(range){
  if (!player) return null;
  const R = (range === undefined) ? towerTune().climbR : range;
  const L = (typeof cur === 'function') ? cur() : null;
  if (!L || !L.walls) return null;
  let best = null, bd = R;
  for (const w of L.walls){
    if (!w || (w.cov !== 'watchtower' && w.cov !== 'watchtowerOld') || w.dead) continue;
    /* 到矩形边缘的距离：站在塔脚下也能按到，不用挤进碰撞箱 */
    const dx = Math.max(w.x - player.x, 0, player.x - (w.x + w.w));
    const dy = Math.max(w.y - player.y, 0, player.y - (w.y + w.h));
    const d = Math.hypot(dx, dy);
    if (d < bd){ bd = d; best = w; }
  }
  return best;
}
/* 爬上去：人放到平台中心，视角、速度全交给原来的那套（只是位置被钉住） */
function climbTower(d){
  if (!d || !player || player.hp <= 0) return false;
  if (player.mgNest && typeof dismountMgNest === 'function') dismountMgNest();
  if (player.seat && typeof standUp === 'function') standUp();
  towerSeat = d;
  const p = towerPlatPos(d);
  player.x = p.x; player.y = p.y;
  player.moving = false; player.mvX = 0; player.mvY = 0;
  if (typeof setMsg === 'function'){
    const T = towerTune();
    setMsg('爬上瞭望塔 · 视野 ×' + T.visionK + ' · 视角收窄 · 按 E 下来', 2.6);
  }
  return true;
}
function leaveTower(){
  if (!towerSeat) return false;
  const d = towerSeat;
  towerSeat = null;
  /* 下来的时候往南边挪一点，别正好卡在塔的碰撞箱里 */
  if (player){
    player.y = Math.min(d.y + d.h + player.r + 6, (cur() ? cur().h - player.r - 4 : d.y + d.h + 20));
    player.x = d.x + d.w * 0.5;
  }
  if (typeof setMsg === 'function') setMsg('下塔了', 1.1);
  return true;
}
/* 视野倍率：给 seeRange / seeFov 乘的。没上塔就是 1。 */
function towerVisionK(){ return towerSeat ? towerTune().visionK : 1; }
function towerFovK(){ return towerSeat ? towerTune().fovK : 1; }

/* 塔上的人站在平台中心，而平台中心**在塔自己的碰撞箱里**：
   直接拿这个点去算 losBlocked 会被自己的塔身挡死（每一条视线都"被遮住"）。
   所以先沿视线方向走到塔边、出了塔身再开始算遮挡 —— 等于把人抬到塔顶往外看。 */
function towerRayStart(p, tx, ty){
  const d = towerSeat;
  if (!d) return p;
  const dx = tx - p.x, dy = ty - p.y;
  const len = Math.hypot(dx, dy) || 1;
  const ux = dx / len, uy = dy / len;
  const x0 = d.x, x1 = d.x + d.w, y0 = d.y, y1 = d.y + d.h;
  let t = 1e9;
  if (ux > 1e-6) t = Math.min(t, (x1 - p.x) / ux);
  else if (ux < -1e-6) t = Math.min(t, (x0 - p.x) / ux);
  if (uy > 1e-6) t = Math.min(t, (y1 - p.y) / uy);
  else if (uy < -1e-6) t = Math.min(t, (y0 - p.y) / uy);
  if (!isFinite(t) || t < 0) t = 0;
  return { x: p.x + ux * (t + 2), y: p.y + uy * (t + 2) };
}

/* 塔上"我现在能看见谁"：用收窄后的锥 + 塔顶的视线。
   注意这里**不复用 litByCone**（它读的是玩家自己的视距/视角），否则一上塔
   播报半径也跟着变，两个乘数就打架了。 */
function towerSees(u){
  if (!towerSeat || !player || !u || u.dead) return false;
  const p = towerFootPos(towerSeat);
  /* seeRange / seeFov 已经乘过塔的倍率了（人在塔上才乘），这里直接用，
     别再自己乘一遍 —— 两个乘数打架会让播报半径和屏幕上的光锥对不上。 */
  if (dist(p.x, p.y, u.x, u.y) > seeRange(cur())) return false;
  const aim = (typeof player.aim === 'number') ? player.aim : 0;
  const a = Math.atan2(u.y - p.y, u.x - p.x);
  const half = seeFov(cur()) * Math.PI / 360;      /* seeFov 是全角，半角要 /2 */
  const da = Math.atan2(Math.sin(a - aim), Math.cos(a - aim));
  if (Math.abs(da) > half) return false;
  /* 视线：从塔边开始算（别被自己的塔身挡住）；矮掩体挡不住塔上的视线 —— skipLow = true */
  const s = towerRayStart(p, u.x, u.y);
  return !losBlocked(s.x, s.y, u.x, u.y, false, true);
}

/* 把"看到的位置"告诉队友。
   字段沿用第 40 轮 fleeCallBackup 那一套（mode / lastKnown / alertT / heardSource），
   这样队友的追击、绕路、警戒全都不用改，只多了一条信息来源。 */
function towerBroadcast(u){
  const list = (typeof allies !== 'undefined' && allies) ? allies : null;
  if (!list || !list.length) return 0;
  const T = towerTune();
  let n = 0;
  for (const a of list){
    if (!a || a.dead || a.hp <= 0) continue;
    if (dist(a.x, a.y, u.x, u.y) > T.pingR) continue;
    a.mode = 1;
    a.alertT = Math.max(a.alertT || 0, (typeof CFG !== 'undefined' ? CFG.eMemory : 6) + 4);
    a.lastKnown = { x: u.x, y: u.y };
    a.lastKnownSource = u;
    a.tgtCache = u;
    a.ang = Math.atan2(u.y - a.y, u.x - a.x);
    a.towerIntelT = 2.2;         /* 给 AI 那边看的：这条情报是塔上报的 */
    /* 队友自己那套是"玩家下命令"，不读 lastKnown —— 所以另存一份报点，
       由 companionTowerGo() 消费：跟着报点压过去，不抢玩家的 move/hold 命令。 */
    a.towerMark = { x: u.x, y: u.y, t: T.markT || 4.5,
                    id: (typeof combatId === 'function') ? combatId(u) : null };
    n++;
  }
  return n;
}

function updateWatchTower(dt){
  const T = towerTune();
  if (typeof towerEnemyTick === "function") towerEnemyTick(dt);
  towerMarkTick(dt);
  /* 标记倒计时 */
  if (towerSpots.size){
    for (const [u, t] of towerSpots){
      const nt = t - dt;
      if (nt <= 0 || !u || u.dead) towerSpots.delete(u); else towerSpots.set(u, nt);
    }
  }
  if (!towerSeat) return;
  if (!player || player.hp <= 0){ towerSeat = null; return; }
  /* 人在塔上：位置钉在平台中心，视角随便转 */
  const p = towerPlatPos(towerSeat);
  player.x = p.x; player.y = p.y;
  player.mvX = 0; player.mvY = 0; player.moving = false;

  towerPingT = Math.max(0, towerPingT - dt);
  const list = enemies.concat((typeof hunters !== 'undefined') ? hunters : []);
  let n = 0;
  for (const u of list){
    if (!u || u.dead || n >= T.maxSpot) continue;
    if (!towerSees(u)) continue;
    towerSpots.set(u, T.spotT);
    n++;
    /* 同一批情报按 pingT 节流：每帧刷会让队友的 lastKnown 一直抖，
       而且 alertT 被无限续命，整个地图的敌人永远处于警戒 */
    if (towerPingT <= 0) towerBroadcast(u);
  }
  if (n > 0 && towerPingT <= 0) towerPingT = T.pingT;
}

/* 敌人头顶的播报标记：一个方括号 + 一条拉向队友的细线。
   只在塔上画（下塔就没了），它是"你现在这门炮的瞄准信息"，不是常驻 UI。 */

function drawTowerMarks(){
  if (!towerSeat || !towerSpots.size || !player) return;
  const T = towerTune();
  for (const [u, t] of towerSpots){
    if (!u || u.dead) continue;
    if (typeof cullPt === 'function' && !cullPt(u.x, u.y, 80)) continue;
    const a = Math.min(1, t / Math.min(1, T.spotT));
    const r = (u.r || 12) + 9;
    ctx.save();
    ctx.globalAlpha = 0.35 + 0.5 * a;
    ctx.strokeStyle = '#e8c579'; ctx.lineWidth = 1.6;
    /* 四个角括号，比整圈更像"锁定" */
    const c = 4.5;
    ctx.beginPath();
    for (const s of [[-1, -1], [1, -1], [-1, 1], [1, 1]]){
      const cx = u.x + s[0] * r, cy = u.y + s[1] * r;
      ctx.moveTo(cx, cy - s[1] * c); ctx.lineTo(cx, cy); ctx.lineTo(cx - s[0] * c, cy);
    }
    ctx.stroke();
    ctx.restore();
  }
}

/* 走在塔背后的人应该被平台挡住 —— 所以平台在"人之后"再画一遍。
   人在塔上时这一座不画（否则把自己盖住了，那种情况 drawCover 里已经画过）。 */
function drawTowerTops(){
  if (typeof cur !== 'function') return;
  const L = cur();
  if (!L || !L.walls) return;
  for (const w2 of L.walls){
    if (!w2 || w2.dead || w2.cov !== 'watchtower') continue;
    /* 人在塔上时平台由 drawCover 那层画（否则平台会盖住人）。这里按坐标认，
       只比引用的话，别处重新构造过同一个塔对象就会漏过去 → 平台盖住玩家的腿。 */
    if ((towerSeat && towerSeat.x === w2.x && towerSeat.y === w2.y) || towerEnemyOf(w2)) continue;
    if (typeof cullRect === 'function' && !cullRect(w2.x, w2.y - (w2.hi || 64), w2.w, w2.h + (w2.hi || 64))) continue;
    drawTowerTop(w2, w2.hi);
  }
}
/* 塔上的一行状态：这一炮打出去，谁收到了。没有它，玩家不知道"播报"到底有没有生效。 */
/* 现在有多少个队友手里握着塔上的报点（HUD 和测试都用它） */
function towerSyncCount(){
  let got = 0;
  if (typeof allies !== 'undefined' && allies){
    for (const a of allies) if (a && !a.dead && a.towerMark && a.towerMark.t > 0) got++;
  }
  return got;
}

function drawTowerHud(){
  if (!towerSeat || !player || player.hp <= 0) return;
  const got = towerSyncCount();
  const seen = towerSpots.size;
  const label = '瞭望塔 · 情报同步 ' + got + ' 人 · 标记 ' + seen + ' 个 · 按 E 下来';
  ctx.save();
  ctx.font = 'bold 13px system-ui,-apple-system,"Segoe UI",sans-serif';
  ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  const tw = ctx.measureText(label).width;
  const x = 18, y = H - 96;
  ctx.fillStyle = 'rgba(8,12,10,0.72)';
  ctx.fillRect(x - 6, y - 11, tw + 14, 22);
  ctx.strokeStyle = 'rgba(232,197,121,0.55)'; ctx.lineWidth = 1;
  ctx.strokeRect(x - 6, y - 11, tw + 14, 22);
  ctx.fillStyle = seen > 0 ? '#e8c579' : '#8fa3b0';
  ctx.fillText(label, x, y);
  ctx.restore();
}

/* 站到塔边上给一行提示（跟门、椅子那套一个样式）：[E] 上塔 */
function drawTowerHint(){
  if (towerSeat || !player || player.hp <= 0) return;
  const d = towerNear();
  if (!d) return;
  if (typeof cullPt === 'function' && !cullPt(d.x + d.w * 0.5, d.y, 160)) return;
  const tx = d.x + d.w * 0.5;
  const ty = (d.cov === 'watchtower') ? (d.y - (d.hi || 64) - 18) : (d.y - 12);
  ctx.save();
  ctx.font = 'bold 13px system-ui,-apple-system,"Segoe UI",sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  const label = '[E] 上塔';
  const tw = ctx.measureText(label).width;
  ctx.fillStyle = 'rgba(8,12,10,0.72)';
  ctx.fillRect(tx - tw / 2 - 7, ty - 10, tw + 14, 20);
  ctx.strokeStyle = 'rgba(120,200,150,0.55)'; ctx.lineWidth = 1;
  ctx.strokeRect(tx - tw / 2 - 7, ty - 10, tw + 14, 20);
  ctx.fillStyle = '#8fe0a8';
  ctx.fillText(label, tx, ty);
  ctx.restore();
}



/* ===== 敌人也能上塔：塔是"观察位"，不是玩家专属 =====
   设计原则和玩家侧一致 —— 塔是眼睛不是手：
   上塔的敌人自己**不开火**（它只负责看和报），收到报点的同伴才会朝那个方向压。
   这样玩家看到的是"塔上有人 → 下面的人开始朝我这边扫"，而不是"塔上有个人隔着 600px 点我"。 */
var TOWER_AI = {
  on: true,
  claimR: 78,        /* 走到离塔脚多近会决定上去 */
  minTier: 1,        /* 只有老兵/精英会上塔；普通兵保持"粗心"，符合之前的分层 */
  pingT: 2.4,        /* 播报间隔（秒） */
  pingR: 640,        /* 报给多远内的同伴 */
  fovK: 0.49,        /* 收窄后的扇形由四周扫视补足覆盖 */
  sweepRate: 0.70,   /* 弧度 / 秒 */
  boostK: 1.85,      /* 塔上敌人的视距倍率（玩家是 2.3，AI 略低） */
  holdMax: 40,       /* 最多待多久就下来，避免一座塔被永久占住 */
  hurtLeave: 0.35,   /* 血掉到这个比例以下就下塔跑路 */
  suppressT: 5.0,    /* 同伴收到报点后朝那个方向压制多久（塔上有人一直在报，压制要压得住） */
  suppressN: 8,      /* 压制打几发 */
  suppressJit: 0.055,/* 扇面半角（弧度）≈3.2°：有人报了大概位置，就不该撒成弹幕 */
  nestR: 300,        /* 塔附近这个范围里有空的重机枪阵地，就顺手派个人去坐 */
  coolT: 8,          /* 刚下塔的人/刚空出来的塔，多少秒内不再互相招募 */
};
function towerAiOn(L){
  if (!TOWER_AI.on) return false;
  if (typeof humanOn === 'function' && !humanOn(L || cur())) return false;
  return true;
}
function towerEnemyOf(w){
  const e = w && w.occ;
  if (!e || e.dead || !(e.hp > 0)) return null;
  return e;
}
function towerEnemyMount(e, w){
  if (!e || !w || towerEnemyOf(w) || e.towerOn) return false;
  /* 塔上的位置钉在平台中心，跟玩家上塔同一套坐标 */
  const p = towerPlatPos(w);
  w.occ = e;
  e.towerOn = w;
  e.towerLookStart = Number.isFinite(e.ang) ? e.ang : 0;
  e.angS = e.coneA = e.towerLookStart;
  e.towerT = 0;
  e.towerPingT = 0.35;
  e.path = null; e.goal = null; e.wp = null; e.i = 0;
  e.hideGoal = null; e.chk = null;
  e.x = p.x; e.y = p.y;
  e.mvX = 0; e.mvY = 0; e.moving = false;
  e.spd = 0;
  if (typeof setBark === 'function') setBark(e, '上塔观察', 1.0, 1);
  return true;
}
function towerEnemyLeave(e){
  const w = e && e.towerOn;
  if (!w) return false;
  if (w.occ === e) w.occ = null;
  e.towerOn = null;
  e.towerT = 0;
  /* 刚下来的人别马上又被派上去（也别让这塔立刻再招人） */
  e.towerCool = (typeof TOWER_AI !== 'undefined' && TOWER_AI.coolT) ? TOWER_AI.coolT : 8;
  w.claimCool = e.towerCool;
  /* 下来的时候往南边挪一点，别卡在塔的碰撞箱里（和玩家下塔一致） */
  e.y = Math.min(w.y + w.h + e.r + 6, (cur() ? cur().h - e.r - 4 : w.y + w.h + 20));
  e.x = w.x + w.w * 0.5;
  e.path = null; e.goal = null;
  return true;
}
/* 让一个敌人朝 (x,y) 方向"压制扫射"：复用受击压制那套状态机
   （eStatusSet('suppress') + suppressAng + suppressN），不另写一套开枪逻辑 */
function enemySuppressToward(e, x, y, dur, n){
  if (!e || e.dead || !(e.hp > 0)) return false;
  if (!enemyType(e).canShoot) return false;
  if ((e.ammo || 0) <= 0 || e.reloading > 0) return false;
  if (typeof eStatusSet !== 'function') return false;
  if (eStatusHas(e, 'suppress')) return false;
  const a = Math.atan2(y - e.y, x - e.x);
  eStatusSet(e, 'suppress', dur || TOWER_AI.suppressT);
  e.suppressAng = a;
  e.suppressN = Math.max(2, n || TOWER_AI.suppressN);
  /* 塔上报的点比"听见枪声"准得多：间隔拉开（一串点射），扇面收到 ~3°
     —— 有人报了大概位置还撒成弹幕，就演得过分了 */
  e.suppressGap = 0.42;
  e.suppressJit = (typeof TOWER_AI.suppressJit === 'number') ? TOWER_AI.suppressJit : (3.2 * Math.PI / 180);
  e.suppressI = 0;
  e.suppressStep = (e.suppressJit * 2) / Math.max(1, e.suppressN - 1);
  e.suppressPoints = null;
  e.fireCd = Math.min(e.fireCd || 99, 0.08);
  if (typeof tacBump === 'function') tacBump('suppress');
  return true;
}
/* 塔上这位向外报点：只报给同阵营、看得见塔打不了的那种"看不见你"的同伴 */
function towerEnemyPing(e, w){
  const A = TOWER_AI;
  const seen = EnemyPerception.reportContact(e);
  if (!seen || seen === e) return 0;
  const fx = towerFootPos(w);
  let n = 0;
  for (const a of enemies){
    if (!a || a === e || a.dead || !(a.hp > 0)) continue;
    if (a.controller === 'companion') continue;
    if (typeof combatFaction === 'function' && combatFaction(a) !== combatFaction(e)) continue;
    if (dist(a.x, a.y, fx.x, fx.y) > A.pingR) continue;
    if (a.towerOn || a.mgSeat) continue;
    a.mode = 1;
    a.alertT = Math.max(a.alertT || 0, (typeof CFG !== 'undefined' ? CFG.eMemory : 6) + 4);
    a.lastKnown = { x: seen.x, y: seen.y };
    a.lastKnownSource = seen;
    a.tgtCache = seen;
    a.coneA = a.ang = Math.atan2(seen.y - a.y, seen.x - a.x);
    a.towerIntelT = 2.2;
    /* 关键：看不见也朝那个方向扫 —— 这就是玩家要的"报点压制" */
    if (!a.sees) enemySuppressToward(a, seen.x, seen.y, A.suppressT, A.suppressN);
    n++;
  }
  return n;
}
function towerEnemyTick(dt){
  const L = (typeof cur === 'function') ? cur() : null;
  if (!L || !L.walls || state !== 'play') return;
  if (!towerAiOn(L)) return;
  const A = TOWER_AI;
  /* 冷却：刚下塔的人 / 刚空出来的塔，短时间内不再互相招募 */
  for (const e of enemies){ if (e && (e.towerCool || 0) > 0) e.towerCool = Math.max(0, e.towerCool - dt); }
  for (const w of L.walls){ if (w && (w.claimCool || 0) > 0) w.claimCool = Math.max(0, w.claimCool - dt); }
  /* 1. 已经在塔上的：钉位置、慢慢扫、定期报点 */
  for (const w of L.walls){
    if (!w || (w.cov !== 'watchtower' && w.cov !== 'watchtowerOld') || w.dead) continue;
    const e = towerEnemyOf(w);
    if (!e){ if (w.occ) w.occ = null; continue; }
    const p = towerPlatPos(w);
    e.x = p.x; e.y = p.y;
    e.mvX = 0; e.mvY = 0; e.moving = false; e.spd = 0;
    /* 塔上的人只负责看：扳机锁死在 enemyShoot 里判 e.towerOn（塔是眼睛不是手） */
    e.towerT = (e.towerT || 0) + dt;
    /* 塔上视野更远（视距在 enemyVisionRange 里乘倍率），角度慢慢扫 */
    const t=e.towerT;
    e.ang=e.angS=e.coneA=normAng(e.towerLookStart+t*A.sweepRate+.27*Math.sin(t*1.5));
    e.towerPingT = (e.towerPingT || 0) - dt;
    if (e.towerPingT <= 0){
      e.towerPingT = A.pingT;
      towerEnemyPing(e, w);
    }
    const hurt = (e.maxHp || 100) > 0 && e.hp / (e.maxHp || 100) < A.hurtLeave;
    if (hurt || (e.towerT > A.holdMax) || eStatusHas(e, 'stun')) towerEnemyLeave(e);
  }
  /* 2. 没人占的塔：让靠得最近的老兵/精英上去（普通兵不占，保持"粗心"） */
  for (const w of L.walls){
    if (!w || (w.cov !== 'watchtower' && w.cov !== 'watchtowerOld') || w.dead) continue;
    if (towerEnemyOf(w)) continue;
    if ((w.claimCool || 0) > 0) continue;
    let best = null, bd = A.claimR;
    for (const e of enemies){
      if (!e || e.dead || !(e.hp > 0)) continue;
      if (e.controller === 'companion' || e.mgSeat || e.towerOn) continue;
      if ((e.towerCool || 0) > 0) continue;
      if (typeof tacticsPlus === 'function' && !tacticsPlus(e, L)) continue;
      if (typeof enemyType === 'function' && !enemyType(e).canShoot) continue;
      if (eStatusHas(e, 'stun')) continue;
      if (e.hideGoal || e.tacticPhase || e.bound || (e.throwT || 0) > 0) continue;
      if ((e.alertT || 0) <= 0 && !e.sees) continue;
      const d = dist(e.x, e.y, w.x + w.w * 0.5, w.y + w.h * 0.5);
      if (d < bd){ bd = d; best = e; }
    }
    if (best) towerEnemyMount(best, w);
  }
  /* 3. 塔 + 重机枪阵地的配合：塔附近有空枪位，就派一个没上塔的同伴去坐
        （他走过去以后 updateMgNests 那套 aiClaimR=130 会自动让他坐下） */
  if (typeof mgNests !== 'undefined' && mgNests && mgNests.length){
    for (const w of L.walls){
      if (!w || (w.cov !== 'watchtower' && w.cov !== 'watchtowerOld') || w.dead) continue;
      const guard = towerEnemyOf(w);
      if (!guard) continue;
      const fx = towerFootPos(w);
      for (const n of mgNests){
        if (!n || n.seat || n.playerSeat) continue;
        if (typeof combatFaction === 'function' && combatFaction(n) !== combatFaction(guard)) continue;
        if (dist(n.x, n.y, fx.x, fx.y) > A.nestR) continue;
        let runner = null, rd = 460;
        for (const e of enemies){
          if (!e || e === guard || e.dead || !(e.hp > 0)) continue;
          if (e.controller === 'companion' || e.mgSeat || e.towerOn || e.nestRoute) continue;
          if (typeof combatFaction === 'function' && combatFaction(e) !== combatFaction(guard)) continue;
          if (e.hideGoal || e.tacticPhase || e.bound) continue;
          const d = dist(e.x, e.y, n.x, n.y);
          if (d < rd){ rd = d; runner = e; }
        }
        if (runner){
          runner.nestRoute = n;
          runner.wp = [[n.x, n.y]];
          runner.i = 0;
          runner.path = null;
          runner.goal = { x: n.x, y: n.y };
        }
      }
    }
  }
}
