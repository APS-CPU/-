/* 自动登记房间：谁造的墙，程序自己认房间 —— 不用手写 rooms[]
 *
 * 为什么需要：`roomSearchTick` 只有在 `L.rooms` 非空时才会"进屋找人"。
 * 全项目原先只有测试区那栋房子手写了 rooms[]，所以正式关里玩家一进屋，
 * 敌人走到墙外就不知道往里搜了（追到门口也不拐进去）。
 *
 * 做法（不是洪水填充，不做全图扫描）：
 *   屋子在关卡里永远是"四面轴对齐的墙围成一个矩形"，门洞会让某一面断成两截。
 *   所以先把同一高度（y 相近）的横墙合并成"一段连续横墙"（允许门洞的缺口），
 *   再找上下两层横墙 + 左右两根竖墙围成的矩形，凑成就 roomAdd 一间。
 *   墙的数量级是几十到一两百，复杂度 O(n²) 但常数极小，
 *   手摆关卡和以后随机生成的矩形房间都适用。
 *
 * 约束：
 *   - 只用 roomAdd 登记（去重 + 索引失效都由它负责）
 *   - 已经有 rooms[] 的关卡（测试区）被完全覆盖时不重复登记
 *   - 结果按面积从大到小，避免小箱子围出的"假房间"顶掉真正的屋子
 */
(function(){
  const TOL = 9;            /* 墙厚/对齐容差 */
  const GAP = 76;           /* 同一面墙上允许的门洞缺口（门宽 ~70） */
  const MIN_SIDE = 64;      /* 小于这个边长的围合当储物格，不登记为房间 */
  const MAX_ROOMS = 24;

  function isSolidWall(w){
    /* m35424：死亡地带的四边框（_dzEdge）跟 mapBoundary 一样不是「屋子的墙」，
       否则 6000×5960 的边框会被识别成一间「屋内 0,0」的假房间，
       AI 听到脚步后会反复规划错误的室内目标，表现就是亮问号却站着不动。 */
    if (!w || w.glass || w.door || w.mapBoundary || w._dzEdge) return false;
    if (w.hidden) return false;
    const ww = w.w || 0, hh = w.h || 0;
    return ww >= 12 && hh >= 12;
  }

  function split(walls){
    const hs = [], vs = [];
    for (const w of walls){
      if (!isSolidWall(w)) continue;
      if (w.w >= w.h) hs.push(w);
      else vs.push(w);
    }
    return { hs, vs };
  }

  /* 同一高度上的横墙合并成若干"连续段"：[x0, x1] */
  function mergeRow(segs){
    const arr = segs.slice().sort((a, b) => a.x - b.x);
    const out = [];
    for (const s of arr){
      const x0 = s.x, x1 = s.x + s.w;
      const last = out[out.length - 1];
      if (last && x0 <= last.x1 + GAP){
        if (x1 > last.x1) last.x1 = x1;
      } else out.push({ x0, x1 });
    }
    return out;
  }

  function coversY(v, y0, y1){
    return v.y <= y0 + TOL && (v.y + v.h) >= y1 - TOL;
  }

  function detectBoxes(L){
    const walls = (L && L.walls) || [];
    const { hs, vs } = split(walls);
    const out = [];
    if (hs.length < 2 || vs.length < 2) return out;

    /* 按 y 分组成"横墙层" */
    const levels = [];
    for (const h of hs){
      let lv = null;
      for (const it of levels){ if (Math.abs(it.y - h.y) <= TOL){ lv = it; break; } }
      if (!lv){ lv = { y: h.y, segs: [] }; levels.push(lv); }
      lv.segs.push(h);
    }
    for (const lv of levels) lv.spans = mergeRow(lv.segs);
    levels.sort((a, b) => a.y - b.y);

    for (let a = 0; a < levels.length; a++){
      for (let b = a + 1; b < levels.length; b++){
        const y0 = levels[a].y, y1 = levels[b].y;
        if (y1 - y0 < MIN_SIDE) continue;
        for (const sa of levels[a].spans){
          for (const sb of levels[b].spans){
            const x0 = Math.max(sa.x0, sb.x0), x1 = Math.min(sa.x1, sb.x1);
            if (x1 - x0 < MIN_SIDE) continue;
            let left = false, right = false;
            for (const v of vs){
              if (!coversY(v, y0, y1)) continue;
              if (Math.abs((v.x + v.w) - x0) <= TOL || Math.abs(v.x - x0) <= TOL) left = true;
              if (Math.abs((v.x + v.w) - x1) <= TOL || Math.abs(v.x - x1) <= TOL) right = true;
              if (left && right) break;
            }
            if (!left || !right) continue;
            out.push({ x: x0, y: y0, w: x1 - x0, h: y1 - y0 });
          }
        }
      }
    }
    return out;
  }

  function autoRoomsFor(L){
    if (!L || typeof roomAdd !== 'function') return 0;
    roomsInit(L);
    let added = 0;
    const boxes = detectBoxes(L).sort((a, b) => (b.w * b.h) - (a.w * a.h));
    for (const b of boxes){
      if (added >= MAX_ROOMS) break;
      let covered = false;
      for (const r of L.rooms){
        if (b.x >= r.x - TOL && b.y >= r.y - TOL &&
            b.x + b.w <= r.x + r.w + TOL && b.y + b.h <= r.y + r.h + TOL){ covered = true; break; }
      }
      if (covered) continue;
      const one = roomAdd(L, { x: b.x, y: b.y, w: b.w, h: b.h, name: '屋内 ' + Math.round(b.x) + ',' + Math.round(b.y) });
      if (one) added++;
    }
    return added;
  }

  window.autoRoomsFor = autoRoomsFor;
  window.autoRoomsDetect = detectBoxes;
})();
