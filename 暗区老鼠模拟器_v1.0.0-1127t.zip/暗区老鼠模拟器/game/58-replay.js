/* ================= 上帝视角（整局回放） ================= */
/* 回放要录哪些"特殊东西"：
     运兵车 trucks、火箭炮塔（L.walls 里 rocketTurret 的那些）、
     以及不是普通子弹的弹种 —— 火箭弹（玩家 RPG / 炮塔）、手雷、烟雾弹、信号弹、破片。
   普通子弹照旧走 bu（不然一帧上百个点，录像就肥了）。 */
function vrecTurrets(L){
  const out = [];
  for (const w of L.walls){
    if (!w.rocketTurret) continue;
    out.push({ x: w.x + w.w / 2, y: w.y + w.h / 2, a: w.ang || 0,
               hp: w.hp | 0, mh: w.maxHp || 1, w: !!w.wreck,
               f: (w.recoilT || 0) > 0 ? 1 : 0 });
  }
  return out;
}
function vrecProjectiles(){
  const out = [];
  /* k: 1 = 火箭弹，2 = 炮塔火箭弹，3 = 手雷，4 = 烟雾弹，5 = 信号弹，6 = 破片 */
  for (const b of bullets){
    if (!b.rocket) continue;
    /* 不是玩家打的（炮塔 / 别的来源）→ 算"打向你的"，回放里套红环标记 */
    const hostile = !!b.turretRocket || (b.by && b.by !== player);
    out.push({ k: hostile ? 2 : 1, x: b.x, y: b.y, vx: b.vx || 0, vy: b.vy || 0 });
  }
  for (const n of nades) out.push({ k: 3, x: n.x, y: n.y, f: n.fuse || 0 });
  for (const g of grenades) out.push({ k: 4, x: g.x, y: g.y });
  for (const f of flares) out.push({ k: 5, x: f.x, y: f.y });
  for (const s of nadeShards) out.push({ k: 6, x: s.x, y: s.y });
  return out;
}
function vrecSnapshot(){
  const _L = cur();
  if (vrecBuf.at(-1)?.t === timeAlive) vrecBuf.pop();
  vrecBuf.push({
    t: timeAlive, px: player.x, py: player.y, aim: player.aim||0, hp: player.hp,
    en: enemies.map(e=>({x:e.x, y:e.y, a:e.ang||0, m:e.mode, s:!!e.sees})),
    hu: hunters.map(h=>({x:h.x, y:h.y, a:h.ang||0, m:h.state, s:!!h.sees})),
    bu: bullets.map(b=>({x:b.x, y:b.y})),
    sm: smokes.map(k=>({x:k.x, y:k.y, r:k.r*Math.min(1, k.age/0.5)})),
    /* 玩家攻击轨迹：枪是 hitscan，子弹只在 tracers 里留一条线，不记下来回放就什么都没有 */
    tr: tracers.map(t=>({x0:t.x0, y0:t.y0, x1:t.x1, y1:t.y1,
                         p:Math.min(1, (t.t||0) / Math.max(0.001, t.dur||1))})),
    lk: loots.map(l=>({x:l.x, y:l.y, t:!!l.taken})),
    tk: trucks.map(t=>({x:t.x, y:t.y, a:t.ang||0, hp:t.hp|0, mh:t.maxHp||1, d:!!t.dead})),
    tu: _L ? vrecTurrets(_L) : [],
    pr: vrecProjectiles(),
    sw: switches.map(w=>!!w.on), ex: exitOpen
  });
  if (vrecBuf.length > VREC_MAX) vrecBuf.shift();
}
function vrecStart(){ return vrecBuf[0]?.t ?? 0; }
function vrecDur(){ return vrecBuf.at(-1)?.t ?? 0; }
function vrecIndexAt(t){
  /* 长局会丢弃最早的帧。按录像时间戳查找，也能处理不等间隔的终局帧。 */
  let lo = 0, hi = vrecBuf.length - 1;
  while (lo < hi){
    const mid = Math.ceil((lo + hi) / 2);
    if (vrecBuf[mid].t <= t) lo = mid;
    else hi = mid - 1;
  }
  return lo;
}
function vrecAt(t){ return vrecBuf[vrecIndexAt(t)] ?? null; }

function startGreplay(back){
  if (vrecBuf.length < 20){ setMsg('这一局太短，没录到回放', 1.8); return; }
  gBack = back || (state === 'clear' ? 'clear' : (state === 'lose' ? 'lose' : 'win'));
  gT = vrecStart(); gPlaying = true; gAutoCam = true; gDrag = null;
  const s = vrecAt(gT);
  gZoom = clamp(Math.min(W / cur().w, H / cur().h) * 3.2, 0.12, 1.6);
  gCam = {x: s ? s.px : cur().w/2, y: s ? s.py : cur().h/2};
  state = 'greplay';
  logInfo('ui', '全局回放 · 共 ' + vrecDur().toFixed(1) + ' 秒');
}
function exitGreplay(){
  gDrag = null;
  if (gBack === 'dead'){ toDeadFrame(true); return; }   /* 从死亡页进来的，看完回死亡页 */
  state = gBack === 'clear' ? 'clear' : (gBack === 'lose' ? 'lose' : 'win');
}

function updateGReplay(dt){
  const dur = vrecDur();
  if (gPlaying){
    gT += dt;
    if (gT >= dur){ gT = dur; gPlaying = false; }
  }
  const s = vrecAt(gT);
  let mx = 0, my = 0;
  if (keys['KeyA']) mx -= 1;
  if (keys['KeyD']) mx += 1;
  if (keys['KeyW']) my -= 1;
  if (keys['KeyS']) my += 1;
  if (mx || my){
    gAutoCam = false;
    const v = 520 / gZoom;
    gCam.x += mx * v * dt; gCam.y += my * v * dt;
  } else if (gAutoCam && s){
    gCam.x += (s.px - gCam.x) * Math.min(1, dt*6);
    gCam.y += (s.py - gCam.y) * Math.min(1, dt*6);
  }
  const L = cur();
  gCam.x = clamp(gCam.x, 0, L.w);
  gCam.y = clamp(gCam.y, 0, L.h);
}

function drawGReplay(){
  uiButtons = [];
  const L = cur(), start = vrecStart(), dur = vrecDur();
  const idx = vrecIndexAt(gT), s = vrecBuf[idx];

  ctx.save();
  ctx.fillStyle = PAL.P70; ctx.fillRect(0, 0, W, H);

  /* ---- 世界 ---- */
  ctx.save();
  ctx.translate(W/2 - gCam.x*gZoom, H/2 - gCam.y*gZoom);
  ctx.scale(gZoom, gZoom);

  ctx.strokeStyle = PAL.P118;
  ctx.lineWidth = 3/gZoom;
  ctx.strokeRect(0, 0, L.w, L.h);

  if (gZoom > 0.2){
    ctx.strokeStyle = PAL.P304; ctx.lineWidth = 1/gZoom;
    for (let x = 0; x <= L.w; x += 200){ ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, L.h); ctx.stroke(); }
    for (let y = 0; y <= L.h; y += 200){ ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(L.w, y); ctx.stroke(); }
  }

  ctx.fillStyle = PAL.P293;
  for (const w of L.walls) ctx.fillRect(w.x, w.y, w.w, w.h);

  if (s && (s.ex || !L.boss)){
    const E = L.extract;
    ctx.fillStyle = PAL.P307;
    ctx.fillRect(E.x, E.y, E.w, E.h);
    ctx.strokeStyle = PAL.P131; ctx.lineWidth = 2.5/gZoom;
    ctx.strokeRect(E.x, E.y, E.w, E.h);
  }

  if (s){
    switches.forEach((w, i)=>{
      ctx.fillStyle = s.sw[i] ? PAL.P26 : PAL.P226;
      ctx.beginPath(); ctx.arc(w.x, w.y, 8/gZoom, 0, TAU); ctx.fill();
      if (!s.sw[i]){
        ctx.strokeStyle = PAL.P225; ctx.lineWidth = 2/gZoom;
        ctx.beginPath(); ctx.arc(w.x, w.y, 20/gZoom, 0, TAU); ctx.stroke();
      }
    });

    for (const k of s.sm){
      const g = ctx.createRadialGradient(k.x, k.y, 2, k.x, k.y, k.r);
      g.addColorStop(0, TC(PAL.P147));
      g.addColorStop(1, TC(PAL.P121));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(k.x, k.y, k.r, 0, TAU); ctx.fill();
    }

    /* 玩家的攻击轨迹：最近 0.7 秒开过的枪，从枪口到命中点一条淡黄线 */
    {
      const seen = {};
      for (let q2 = idx; q2 >= 0; q2--){
        const sn = vrecBuf[q2];
        const a = 1 - (gT - sn.t) / 0.7;
        if (a <= 0.03) break;
        if (!sn.tr?.length) continue;
        for (const t of sn.tr){
          const key = Math.round(t.x0) + ',' + Math.round(t.y0) + ',' + Math.round(t.x1) + ',' + Math.round(t.y1);
          if (seen[key]) continue;
          seen[key] = 1;
          ctx.strokeStyle = 'rgba(255,226,150,' + (a * 0.85).toFixed(3) + ')';
          ctx.lineWidth = 2.2 / gZoom;
          ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(t.x0, t.y0); ctx.lineTo(t.x1, t.y1); ctx.stroke();
        }
      }
      ctx.lineCap = 'butt';
    }

    /* 玩家走过的路 */
    const from = vrecIndexAt(gT - 12);
    for (let t = from; t <= idx; t += 2){
      const q = vrecBuf[t]; if (!q) continue;
      const a = 0.05 + 0.32 * ((t - from) / Math.max(1, idx - from));
      ctx.fillStyle = 'rgba(150,205,235,' + a.toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(q.px, q.py, 3/gZoom, 0, TAU); ctx.fill();
    }

    /* 人机 */
    s.en.forEach((e)=>{
      if (!gXray && !e.s) return;
      const c = e.s ? PAL.P36 : (e.m === 1 ? PAL.P100 : PAL.P17);
      ctx.fillStyle = c;
      ctx.beginPath(); ctx.arc(e.x, e.y, 7/gZoom, 0, TAU); ctx.fill();
      if (e.s){
        ctx.strokeStyle = PAL.P255; ctx.lineWidth = 2/gZoom;
        ctx.beginPath(); ctx.arc(e.x, e.y, 16/gZoom, 0, TAU); ctx.stroke();
      }
    });

    /* 猎手 */
    s.hu.forEach((h, i)=>{
      if (!gXray && !h.s && h.m !== 'chase' && h.m !== 'pounce' && h.m !== 'lunge') return;
      ctx.fillStyle = PAL.P38;
      ctx.beginPath(); ctx.arc(h.x, h.y, 9/gZoom, 0, TAU); ctx.fill();
      ctx.strokeStyle = PAL.P214; ctx.lineWidth = 2/gZoom;
      ctx.beginPath(); ctx.arc(h.x, h.y, 20/gZoom, 0, TAU); ctx.stroke();
      /* 朝向 */
      ctx.strokeStyle = PAL.P102; ctx.lineWidth = 2.5/gZoom;
      ctx.beginPath(); ctx.moveTo(h.x, h.y);
      ctx.lineTo(h.x + Math.cos(h.a)*26/gZoom, h.y + Math.sin(h.a)*26/gZoom);
      ctx.stroke();
      if (gZoom > 0.4){
        ctx.fillStyle = PAL.P218;
        ctx.font = Math.round(12/gZoom) + 'px "Microsoft YaHei",sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('猎手' + (i+1), h.x, h.y - 26/gZoom);
      }
    });

    /* 运兵车（会动的障碍物，车上带炮塔） */
    for (const t of (s.tk || [])){
      const dead = t.d, hpK = t.mh ? Math.max(0, Math.min(1, t.hp / t.mh)) : 0;
      ctx.save();
      ctx.translate(t.x, t.y); ctx.rotate(t.a || 0);
      ctx.fillStyle = dead ? 'rgba(96,100,106,0.85)' : 'rgba(78,86,74,0.95)';
      ctx.strokeStyle = dead ? 'rgba(150,154,160,0.8)' : 'rgba(150,160,140,0.9)';
      ctx.lineWidth = 2 / gZoom;
      const bw = 92, bh = 40;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(-bw/2, -bh/2, bw, bh, 7); else ctx.rect(-bw/2, -bh/2, bw, bh);
      ctx.fill(); ctx.stroke();
      /* 炮塔 */
      ctx.fillStyle = dead ? 'rgba(70,74,80,0.9)' : 'rgba(58,64,56,0.95)';
      ctx.beginPath(); ctx.arc(6, 0, 11, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = dead ? 'rgba(140,144,150,0.9)' : 'rgba(196,206,180,0.95)';
      ctx.lineWidth = 4 / gZoom;
      ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(6 + 30, 0); ctx.stroke();
      ctx.restore();
      /* 血条（只在这辆车还活着的时候画） */
      if (!dead && hpK < 0.999){
        const w2 = 60, h2 = 4 / gZoom;
        ctx.fillStyle = 'rgba(0,0,0,0.55)';
        ctx.fillRect(t.x - w2/2, t.y - 34/gZoom, w2, h2);
        ctx.fillStyle = 'rgba(226,196,96,0.95)';
        ctx.fillRect(t.x - w2/2, t.y - 34/gZoom, w2 * hpK, h2);
      }
    }

    /* 火箭炮塔（住在 L.walls 里，会转、会开炮） */
    for (const u of (s.tu || [])){
      const hpK = u.mh ? Math.max(0, Math.min(1, u.hp / u.mh)) : 0;
      ctx.save();
      ctx.translate(u.x, u.y);
      ctx.fillStyle = u.w ? 'rgba(84,88,94,0.9)' : 'rgba(64,70,60,0.95)';
      ctx.strokeStyle = u.w ? 'rgba(150,154,160,0.85)' : 'rgba(190,200,170,0.95)';
      ctx.lineWidth = 2.5 / gZoom;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(-40, -40, 80, 80, 6); else ctx.rect(-40, -40, 80, 80);
      ctx.fill(); ctx.stroke();
      ctx.rotate(u.a || 0);
      /* 炮管 */
      ctx.strokeStyle = u.w ? 'rgba(140,144,150,0.9)' : 'rgba(214,222,190,0.98)';
      ctx.lineWidth = 9 / gZoom;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(34, 0); ctx.stroke();
      /* 炮口火光：这一格刚开过炮 */
      if (u.f && !u.w){
        const g = ctx.createRadialGradient(38, 0, 1, 38, 0, 26);
        g.addColorStop(0, 'rgba(255,232,170,0.95)');
        g.addColorStop(0.5, 'rgba(255,150,60,0.55)');
        g.addColorStop(1, 'rgba(255,120,40,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(38, 0, 26, 0, TAU); ctx.fill();
      }
      ctx.restore();
      /* 报废打叉 */
      if (u.w){
        ctx.strokeStyle = 'rgba(226,86,80,0.85)'; ctx.lineWidth = 3 / gZoom;
        ctx.beginPath();
        ctx.moveTo(u.x - 22, u.y - 22); ctx.lineTo(u.x + 22, u.y + 22);
        ctx.moveTo(u.x + 22, u.y - 22); ctx.lineTo(u.x - 22, u.y + 22);
        ctx.stroke();
      } else if (hpK < 0.999){
        const w2 = 64, h2 = 4 / gZoom;
        ctx.fillStyle = 'rgba(0,0,0,0.55)';
        ctx.fillRect(u.x - w2/2, u.y - 52/gZoom, w2, h2);
        ctx.fillStyle = 'rgba(226,196,96,0.95)';
        ctx.fillRect(u.x - w2/2, u.y - 52/gZoom, w2 * hpK, h2);
      }
    }

    /* 子弹 */
    for (const b of s.bu){
      ctx.fillStyle = PAL.P105;
      ctx.beginPath(); ctx.arc(b.x, b.y, 3/gZoom, 0, TAU); ctx.fill();
    }

    /* 特殊弹种：火箭弹 / 手雷 / 烟雾弹 / 信号弹 / 破片。
       画在最上面一层 —— 混战里最想知道的就是"这一发是从哪飞过来的"。
       炮塔火箭弹（k=2）额外套一圈红环 + 朝向箭头，一眼能看出"正在打你"。 */
    for (const p of (s.pr || [])){
      if (p.k === 6){                      /* 破片：太密，只在小视野里点缀 */
        if (gZoom < 0.3) continue;
        ctx.fillStyle = 'rgba(226,178,96,0.75)';
        ctx.fillRect(p.x - 1/gZoom, p.y - 1/gZoom, 2/gZoom, 2/gZoom);
        continue;
      }
      if (p.k === 1 || p.k === 2){
        const ang = Math.atan2(p.vy || 0, p.vx || 0);
        const tail = 46 / Math.max(0.25, gZoom);
        const hostile = p.k === 2;
        /* 尾迹 */
        ctx.strokeStyle = hostile ? 'rgba(255,96,80,0.55)' : 'rgba(255,206,120,0.55)';
        ctx.lineWidth = 4 / gZoom;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(p.x - Math.cos(ang) * tail, p.y - Math.sin(ang) * tail);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
        /* 弹头 */
        ctx.fillStyle = hostile ? 'rgba(255,120,96,1)' : 'rgba(255,226,150,1)';
        ctx.beginPath(); ctx.arc(p.x, p.y, 5 / gZoom, 0, TAU); ctx.fill();
        if (hostile){
          /* 正在朝你飞的标记：红环 + 前方双箭头 */
          const pr = 13 / gZoom;
          ctx.strokeStyle = 'rgba(255,70,60,0.95)'; ctx.lineWidth = 2.5 / gZoom;
          ctx.beginPath(); ctx.arc(p.x, p.y, pr, 0, TAU); ctx.stroke();
          ctx.beginPath();
          for (let i = 0; i < 2; i++){
            const d = pr + i * 7 / gZoom;
            ctx.moveTo(p.x + Math.cos(ang) * d + Math.cos(ang + 2.5) * 6/gZoom,
                       p.y + Math.sin(ang) * d + Math.sin(ang + 2.5) * 6/gZoom);
            ctx.lineTo(p.x + Math.cos(ang) * d, p.y + Math.sin(ang) * d);
            ctx.lineTo(p.x + Math.cos(ang) * d + Math.cos(ang - 2.5) * 6/gZoom,
                       p.y + Math.sin(ang) * d + Math.sin(ang - 2.5) * 6/gZoom);
          }
          ctx.stroke();
        }
      } else if (p.k === 3){               /* 手雷：用引信剩余画个倒计时光弧 */
        const f = Math.max(0, Math.min(1, (p.f || 0) / 3));
        ctx.fillStyle = 'rgba(150,170,96,0.95)';
        ctx.beginPath(); ctx.arc(p.x, p.y, 6 / gZoom, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(255,214,120,0.95)'; ctx.lineWidth = 2 / gZoom;
        ctx.beginPath(); ctx.arc(p.x, p.y, 9 / gZoom, -Math.PI/2, -Math.PI/2 + TAU * f); ctx.stroke();
      } else if (p.k === 4){               /* 烟雾弹 */
        ctx.fillStyle = 'rgba(196,204,212,0.9)';
        ctx.beginPath(); ctx.arc(p.x, p.y, 5 / gZoom, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(160,170,180,0.9)'; ctx.lineWidth = 1.5 / gZoom;
        ctx.beginPath(); ctx.arc(p.x, p.y, 9 / gZoom, 0, TAU); ctx.stroke();
      } else if (p.k === 5){               /* 信号弹 */
        const g = ctx.createRadialGradient(p.x, p.y, 1, p.x, p.y, 22 / gZoom);
        g.addColorStop(0, 'rgba(255,120,110,0.95)');
        g.addColorStop(1, 'rgba(255,90,80,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(p.x, p.y, 22 / gZoom, 0, TAU); ctx.fill();
      }
    }

    /* 玩家 */
    ctx.fillStyle = PAL.P2;
    ctx.beginPath(); ctx.arc(s.px, s.py, 9/gZoom, 0, TAU); ctx.fill();
    ctx.strokeStyle = PAL.P3; ctx.lineWidth = 2.5/gZoom;
    ctx.beginPath(); ctx.arc(s.px, s.py, 16/gZoom, 0, TAU); ctx.stroke();
    ctx.strokeStyle = PAL.P62; ctx.lineWidth = 2/gZoom;
    ctx.beginPath(); ctx.moveTo(s.px, s.py);
    ctx.lineTo(s.px + Math.cos(s.aim)*30/gZoom, s.py + Math.sin(s.aim)*30/gZoom);
    ctx.stroke();
  }
  ctx.restore();

  /* ---- 顶栏 ---- */
  ctx.fillStyle = PAL.P271;
  ctx.fillRect(0, 0, W, 52);
  ctx.textAlign = 'left';
  ctx.fillStyle = PAL.P29;
  ctx.font = 'bold 20px "Microsoft YaHei",sans-serif';
  ctx.fillText('上帝视角', 24, 33);
  ctx.fillStyle = PAL.P184;
  ctx.font = '15px "Microsoft YaHei",sans-serif';
  ctx.fillText(L.name + ' · 地图 ' + L.w + '×' + L.h, 236, 33);

  ctx.textAlign = 'right';
  ctx.fillStyle = PAL.P104;
  ctx.font = 'bold 17px "Microsoft YaHei",sans-serif';
  ctx.fillText(gT.toFixed(1) + ' / ' + dur.toFixed(1) + ' 秒   ×' + gZoom.toFixed(2), W - 24, 33);

  /* ---- 底部面板 ---- */
  const bgGrad = ctx.createLinearGradient(0, H - 196, 0, H);
  bgGrad.addColorStop(0, TC(PAL.P270));
  bgGrad.addColorStop(0.45, TC(PAL.P272));
  bgGrad.addColorStop(1, TC(PAL.P273));
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, H - 196, W, 196);

  /* 图例 */
  ctx.textAlign = 'left';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  const lg = [[PAL.P2, '你'], [PAL.P38, '猎手'], [PAL.P36, '已经发现你的人机'],
              [PAL.P17, '没发现你的人机'], [PAL.P26, '已拉的电闸'],
              ['rgba(78,86,74,0.95)', '运兵车'], ['rgba(64,70,60,0.95)', '炮塔'],
              ['rgba(255,226,150,1)', '你的火箭弹'], ['rgba(255,120,96,1)', '打向你的火箭弹'],
              ['rgba(150,170,96,0.95)', '手雷']];
  let lx = 140;
  for (const item of lg){
    ctx.fillStyle = item[0];
    ctx.beginPath(); ctx.arc(lx, H - 168, 5, 0, TAU); ctx.fill();
    ctx.fillStyle = PAL.P183;
    ctx.fillText(item[1], lx + 12, H - 163);
    lx += 26 + ctx.measureText(item[1]).width + 22;
  }

  /* ---- 时间轴 ---- */
  const x0 = 140, x1 = W - 140, ty = H - 56;
  ctx.fillStyle = PAL.P61;
  ctx.fillRect(x0, ty - 4, x1 - x0, 8);
  ctx.fillStyle = PAL.P8;
  const progress = dur > start ? clamp((gT - start) / (dur - start), 0, 1) : 0;
  ctx.fillRect(x0, ty - 4, (x1 - x0) * progress, 8);
  const hx = x0 + (x1 - x0) * progress;
  ctx.fillStyle = PAL.P2;
  ctx.beginPath(); ctx.arc(hx, ty, 7, 0, TAU); ctx.fill();
  ctx.textAlign = 'center';
  ctx.fillStyle = PAL.P167;
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText(start.toFixed(1) + 's', x0, ty + 22);
  ctx.fillText(dur.toFixed(1) + 's', x1, ty + 22);
  const kept = start > 1/VREC_HZ + 0.05 ? '保留末段录像 · ' : '';
  ctx.fillText(kept + '点时间轴跳转 · 拖拽画面平移 · 滚轮缩放', W/2, ty + 22);

  /* ---- 按钮 ---- */
  const by = H - 122;
  btn(140, by, 150, 44, gPlaying ? '暂停 (空格)' : '播放 (空格)', ()=>{ gPlaying = !gPlaying; if (gT >= vrecDur()) gT = vrecStart(); }, {primary: true});
  btn(302, by, 170, 44, '透视：' + (gXray ? '开' : '关') + ' (U)', ()=>{ gXray = !gXray; });
  btn(484, by, 120, 44, '缩小 (−)', ()=>{ gZoom = clamp(gZoom/1.3, 0.12, 3.2); });
  btn(616, by, 120, 44, '放大 (+)', ()=>{ gZoom = clamp(gZoom*1.3, 0.12, 3.2); });
  btn(748, by, 140, 44, '跟随玩家 (F)', ()=>{ gAutoCam = true; });
  btn(W-260, by, 120, 44, '关闭 (Esc)', ()=>exitGreplay());
  ctx.textAlign = 'left';
  ctx.fillStyle = PAL.P49;
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('WASD 平移 · ←→ 前后 1 秒 · R 回到开头 · U 透视 · 空格播放/暂停 · F 跟随玩家', 140, H - 132);

  flushButtons();
  ctx.restore();
}

/* ---- 帧内分段计时：F3 里点名「这一帧的 57ms 花在哪一段」 ----
   只有 F3 打开时才值得看（但这些打点本身几乎零成本，就一直在跑）。
   同一个名字一帧内累加（静态层分地面/墙两次烘焙）。
   父子嵌套时按「自身耗时」归因：渲染 45ms 里有 40ms 是静态层烘焙，
   要指出的是静态层，不能被「渲染」这种大段盖住。 */
let perfSegs = Object.create(null);        /* 名字 → 本帧累计毫秒 */
let perfSegKids = Object.create(null);     /* 名字 → 它的子段累计毫秒 */
let perfSegTop = [];                       /* 本帧最慢的几段（按自身耗时排序） */
let perfSpike = { ms: 0, top: [] };        /* 最近一次卡顿帧的明细，留着慢慢看 */
const PERF_SPIKE_MS = 25;                  /* 超过这个就当卡顿帧记一笔 */
let _segStack = [];
/* 浏览器级长任务（>80ms）：这类卡顿常常压根不在 JS 里 —— 视频卡一下、GPU/合成线程被占，
   F3 的分段账只会显示"这一帧 JS 才 4ms"，看不出谁在拖。挂个 PerformanceObserver 记下来。 */
let perfLong = { ms: 0, at: 0, n: 0 };
let _perfLongObs = null;
function perfLongInstall(){
  if (_perfLongObs || typeof PerformanceObserver !== 'function') return;
  try{
    _perfLongObs = new PerformanceObserver(function(list){
      for (const e of list.getEntries()){
        if (e.duration < 80) continue;
        perfLong.ms = e.duration;
        perfLong.at = e.startTime + e.duration;
        perfLong.n++;
      }
    });
    _perfLongObs.observe({ entryTypes: ['longtask'] });
  } catch(err){ _perfLongObs = null; }
}
function segBegin(name){
  if (!perfOn) return;                      /* F3 关着就只剩这一次判断，别为看数字付出帧时间 */
  const p = _segStack.length ? _segStack[_segStack.length-1] : null;
  _segStack.push({ name: name, t0: performance.now(), parent: p ? p.name : null });
}
function segEnd(){
  if (!perfOn){ _segStack.length = 0; return; }   /* 中途按 F3 关掉：栈直接丢掉，别错配父子 */
  const s = _segStack.pop();
  if (!s) return;
  const d = performance.now() - s.t0;
  perfSegs[s.name] = (perfSegs[s.name] || 0) + d;
  if (s.parent) perfSegKids[s.parent] = (perfSegKids[s.parent] || 0) + d;
}
function segSelfTop(n){
  const arr = [];
  for (const k in perfSegs){
    /* 夹掉负数：子段计时里套了别的段、或者手工构造 kids > total 时会出现 -1.0ms；
       0.05ms 以下的也丢掉，不然卡顿帧点名会列出一排「更新 0.0」的噪声 */
    const ms = Math.max(0, perfSegs[k] - (perfSegKids[k] || 0));
    if (ms >= 0.05) arr.push({ name: k, ms: ms });
  }
  arr.sort(function(a, b){ return b.ms - a.ms; });
  return arr.slice(0, n);
}
function segReset(){
  perfSegs = Object.create(null); perfSegKids = Object.create(null); _segStack.length = 0;
  perfLod = null;
}
/* 分段是靠在调用点上写 segBegin/segEnd 手工标出来的：
   本工程会在 node 里把整段脚本当模块跑测试，函数声明不是 window 的属性，
   所以「替换全局函数来打点」那套在测试里根本不生效 —— 别用。 */

let last = performance.now();
/* ---- 帧时间自检（F3）：不做无根据的优化，先让它自己报数 ---- */
let perfOn = false;
let perfAudioLines = [], perfAudioNext = 0;
let perfGapMs = 0;   /* 上一帧的实际间隔（rAF 口径），卡顿帧靠它和 CPU 耗时取大的那个 */
let perfFps = 60, perfWorst = 0, perfAcc = 0, perfCnt = 0;
let perfLastNow = null, perfFrameMs = 16.7, perfLod = null;
/* m32656：卡顿帧要能自动进 L 日志 —— 玩家忘了开 F3、忘了截图也能事后看。
   滑块阈值 PERF_SPIKE_MS 与 F3 面板共用；1.2 秒冷却，避免连卡时把日志刷爆。 */
let PERF_SPIKES = [];
const PERF_SPIKE_MAX = 80;
let perfSpikeNextLog = 0;
/* m32943：玩家说这条日志比 F3 少了太多信息 —— 一行里把 F3 的关键口径都带上
   （更新/渲染拆分、更新自身与子段、最慢段 top3、敌人 LOD 分档、画质三件套）。 */
const _PFX_LV = ['全开', '精简', '关闭'];
function perfSpikeBrief(r){
  let t = '';
  for (let i = 0; i < r.top.length; i++){ if (i) t += '/'; t += r.top[i].name + ' ' + r.top[i].ms.toFixed(1); }
  const lod = r.lod ? (' · 敌 ' + r.enemies + '（全速' + r.lod.near + ' 降频' + (r.lod.mid + r.lod.far) + ' 休眠' + r.lod.sleep + '）') : (' · 敌 ' + r.enemies);
  return '卡顿 ' + r.ms.toFixed(0) + 'ms（帧 ' + r.frame.toFixed(0) + ' · ' + r.fps.toFixed(0) + 'fps'
    + ' · CPU ' + r.cpu.toFixed(1) + (r.updSkipped
        ? ' · 更新 —（本帧没跑：' + (r.state || '') + '）'
        : ' = 更新 ' + r.upd.toFixed(1) + '（自身 ' + (r.updSelf || 0).toFixed(1) + ' 子段 ' + (r.updSub || 0).toFixed(1) + '）')
    + ' + 渲染 ' + r.draw.toFixed(1) + '）'
    + (t ? ' · 最慢 ' + t : '')
    + lod + ' · 特效 ' + r.fx
    + ' · 画质 ' + (_PFX_LV[r.fxLv || 0] || r.fxLv) + '/' + Math.round((r.rs || 1) * 100) + '%/' + (r.disp || 'fit')
    + (r.weather ? ' · 天气 ' + r.weather : '')
    + ' · ' + r.state + (r.diff ? '/' + r.diff : '');
}
function perfSpikeRecord(ms, cost){
  const nowMs = performance.now();
  const _lod = (typeof perfLod === 'object' && perfLod)
    ? { near: perfLod.near || 0, mid: perfLod.mid || 0, far: perfLod.far || 0, sleep: perfLod.sleep || 0 } : null;
  const _updAll = perfSegs['更新'] || 0;
  const r = {
    w: (typeof logWall === 'function') ? logWall() : new Date().toLocaleTimeString(),
    ms: ms, cpu: cost, frame: perfFrameMs, fps: perfFps,
    enemies: (typeof enemies !== 'undefined' ? enemies.length : 0),
    fx: (typeof fxParts !== 'undefined' ? fxParts.length + (typeof tracers !== 'undefined' ? tracers.length : 0) : 0),
    upd: _updAll,
    /* 与 F3 面板同一口径：自身 = 总 - 子段（perfSegKids 记的是 update 里切出去的块） */
    updSelf: Math.max(0, _updAll - clamp((perfSegKids['更新'] || 0), 0, _updAll)),
    updSub: clamp((perfSegKids['更新'] || 0), 0, _updAll),
    draw: perfSegs['渲染'] || 0,
    lod: _lod,
    fxLv: (typeof perfLv === 'function') ? perfLv() : 0,
    rs: (typeof renderScale === 'function') ? renderScale() : 1,
    disp: (typeof displayMode === 'function') ? displayMode() : 'fit',
    weather: (typeof weatherLabel === 'function') ? weatherLabel() : '',
    updSkipped: (typeof perfUpdSkipped !== 'undefined') ? !!perfUpdSkipped : false,
    state: (typeof state !== 'undefined' ? state : '?'),
    diff: (typeof diffName !== 'undefined' ? diffName : ''),
    top: (typeof segSelfTop === 'function' ? segSelfTop(3) : []).map(t => ({ name: t.name, ms: t.ms })),
  };
  PERF_SPIKES.push(r);
  if (PERF_SPIKES.length > PERF_SPIKE_MAX) PERF_SPIKES.shift();
  if (nowMs >= perfSpikeNextLog){
    perfSpikeNextLog = nowMs + 1200;
    if (typeof logWarn === 'function') logWarn('perf', perfSpikeBrief(r));
  }
}
function perfSpikeText(){
  if (!PERF_SPIKES.length) return '(这一局没有记录到卡顿帧)';
  const NL = String.fromCharCode(10);
  const head = '暗区老鼠模拟器 · 卡顿帧记录（F3 口径）' + NL
    + '时间 ' + new Date().toLocaleString() + NL
    + '版本 ' + (typeof BUILD_TAG !== 'undefined' ? BUILD_TAG : '?') + NL
    + '阈值 ' + PERF_SPIKE_MS + 'ms · 共 ' + PERF_SPIKES.length + ' 条' + NL
    + '判定口径：ms=这一帧实际间隔（rAF 或 CPU 取大），cpu=本帧 JS 提交耗时，frame=平滑帧时长' + NL + NL;
  const lines2 = PERF_SPIKES.map((r, i) => (i + 1) + '. [' + r.w + '] ' + perfSpikeBrief(r) + NL
    + '     更新 ' + r.upd.toFixed(1) + 'ms（自身 ' + (r.updSelf || 0).toFixed(1) + ' / 子段 ' + (r.updSub || 0).toFixed(1) + '）'
    + ' · 渲染 ' + r.draw.toFixed(1) + 'ms · CPU 合计 ' + r.cpu.toFixed(1) + 'ms'
    + (r.lod ? ' · LOD 全速' + r.lod.near + '/降频' + (r.lod.mid + r.lod.far) + '/休眠' + r.lod.sleep : ''));
  return head + lines2.join(NL);
}
/* 「CPU 更新」以前只显示预渲染总时长，碰上暂停/死亡/地图这类"update 根本没跑"的帧，
   就显示 0.00ms，看着像计时坏了。这里把"跑没跑"和"自身/子段"分开记，面板才说真话。 */
let perfUpdSkipped = false;
let lastDt = 1/60;   /* 渲染层要用它做淡入淡出 */
function perfTick(now, t0){
  const cost = performance.now() - t0;
  /* m32656：面板没开也照记卡顿帧 —— 玩家看不到 F3 时也该留下证据（1.2 秒冷却，见 perfSpikeRecord） */
  { const _spk = Math.max(cost, perfGapMs || 0);
    if (_spk >= PERF_SPIKE_MS) perfSpikeRecord(_spk, cost); }
  // FPS 使用 rAF 帧间隔；CPU 提交耗时不能代替屏幕实际帧率。
  if (perfLastNow !== null && now > perfLastNow){
    const elapsed = now - perfLastNow;
    perfGapMs = elapsed;
    perfFrameMs = perfFrameMs*0.9 + elapsed*0.1;
    perfAcc += elapsed; perfCnt++;
  }
  perfLastNow = now;
  if (cost > perfWorst) perfWorst = cost;
  if (perfCnt >= 30){
    perfFps = 1000 / Math.max(0.01, perfAcc / perfCnt);
    perfWorst = 0; perfAcc = 0; perfCnt = 0;
  }
  if (!perfOn){
    if (audioDiagWeb) audioDiagWatch(false);
    perfAudioNext = 0;
    return;
  }
  audioDiagWatch(true);
  if (now >= perfAudioNext){
    perfAudioLines = audioDiagLines();
    perfAudioNext = now + 250;
  }
  /* 本帧最慢项：按自身耗时排，卡顿帧（CPU 或 rAF 间隔超线）就把这一帧的账存下来，
     57ms 再次出现时不用猜是哪一段 */
  perfSegTop = segSelfTop(3);
  const _spikeMs = Math.max(cost, perfGapMs || 0);
  if (_spikeMs >= PERF_SPIKE_MS) perfSpike = { ms: _spikeMs, cpu: cost, top: perfSegTop.slice() };
  ctx.save();
  ctxScreen();          /* m23103 */
  const bad = perfFrameMs > 20;
  if (dzLvl && state === 'play') ctx.translate(W - 470, 168);
  const barY = perfLod ? 200 : 182;
  ctx.fillStyle = 'rgba(0,0,0,0.72)'; ctx.fillRect(8, 8, 452, barY + 10 + 16 * perfAudioLines.length);
  ctx.font = 'bold 12px monospace'; ctx.textAlign = 'left';
  ctx.fillStyle = bad ? '#ff9a6a' : '#9cf59c';
  ctx.fillText(Math.round(perfFps) + ' fps   ' + perfFrameMs.toFixed(1) + ' ms/帧', 16, 26);
  ctx.fillStyle = 'rgba(255,255,255,0.62)';
  ctx.fillText('最差 ' + perfWorst.toFixed(1) + 'ms · 敌人 ' + enemies.length +
               ' · 特效 ' + (fxParts.length + tracers.length), 16, 44);
  /* 自身 = 总 - 子段（子段是 update 里又切出去的块），区分开才知道钱花在"框架"还是"AI" */
  const updMs = perfSegs['更新'] || 0;
  const updKids = clamp(perfSegKids['更新'] || 0, 0, updMs);
  const updSelf = updMs - updKids;
  let _updWhy = state;
  if (paused) _updWhy += ' · 暂停';
  if (mapOpen) _updWhy += ' · 地图';
  if (logOpen) _updWhy += ' · 日志';
  if (confirmBack) _updWhy += ' · 确认';
  if (arenaSlotUI) _updWhy += ' · 选卡';
  const _updTxt = perfUpdSkipped
    ? 'CPU 更新 —（本帧没跑：' + _updWhy + '）'
    : 'CPU 更新 ' + updMs.toFixed(2) + 'ms（自身 ' + updSelf.toFixed(2) + ' · 子段 ' + updKids.toFixed(2) + '）';
  ctx.fillText(_updTxt + ' · 渲染 ' + (perfSegs['渲染'] || 0).toFixed(2) + 'ms', 16, 62, 436);
  ctx.fillText('本帧 CPU ' + cost.toFixed(2) + 'ms · 不含 GPU 完成时间', 16, 80);
  ctx.fillStyle = 'rgba(150,220,255,0.80)';
  ctx.fillText('分块 ' + chunkStats.active + ' 格 · 裁剪 ' + cullStats.culled + '/' + cullStats.tested, 176, 26);
  /* 本帧最慢的那一段：超过 6ms 标黄，一眼看得出这一帧是谁在花钱 */
  const _topSeg = perfSegTop[0];
  ctx.fillStyle = (_topSeg && _topSeg.ms >= 6) ? '#ffd27a' : 'rgba(255,255,255,0.78)';
  ctx.fillText('本帧最慢 ' + (_topSeg ? _topSeg.name + ' ' + _topSeg.ms.toFixed(1) + 'ms' : '—'), 16, 98);
  /* 最近一次卡顿帧的明细：留着不刷，直到下一次卡顿把它顶掉 */
  if (perfSpike.ms > 0 && perfSpike.top.length){
    let _s = '最近卡顿 ' + perfSpike.ms.toFixed(0) + 'ms（CPU ' + perfSpike.cpu.toFixed(0) + '）· ';
    for (let i = 0; i < perfSpike.top.length; i++){
      if (i) _s += ' · ';
      _s += perfSpike.top[i].name + ' ' + perfSpike.top[i].ms.toFixed(0);
    }
    ctx.fillStyle = '#ff9a6a';
    ctx.fillText(_s, 16, 134, 436);
  }
  /* 战术计数：F3 里能数出"闪身枪/压制/包抄"这一局到底触发过没有。
     m37586：局内感受不出来 → 先把次数摆出来。 */
  if (typeof tacStatLine === 'function'){
    ctx.fillStyle = '#9ad6ff';
    ctx.fillText(tacStatLine(), 16, 152, 436);
    const _rec = (typeof tacStatRecent === 'function') ? tacStatRecent(5) : '';
    ctx.fillStyle = 'rgba(255,255,255,0.52)';
    ctx.fillText(_rec ? ('最近 ' + _rec) : '还没有任何战术事件', 16, 168, 436);
  }
  /* 最近一次浏览器级长任务：JS 账很小但帧很长，就说明卡在 JS 之外（合成/GC/显卡） */
  if (perfLong.ms > 0){
    const _age = (performance.now() - perfLong.at) / 1000;
    ctx.fillStyle = (_age < 8) ? '#ff6a4a' : 'rgba(255,140,100,0.55)';
    ctx.fillText('浏览器长任务 ' + perfLong.ms.toFixed(0) + 'ms · ' + _age.toFixed(1) + 's 前 · 共 ' + perfLong.n + ' 次', 16, 116);
  }
  if (perfLod){
    const {near, mid, far, sleep} = perfLod;
    ctx.fillStyle = '#9ad6ff';
    ctx.fillText('AI 全速 '+near+' · 降频 '+mid+' · 远处简化 '+far+' · 休眠 '+sleep, 16, 184);
  }
  /* 一条 16.7ms 的标尺，超过就是掉帧 */
  ctx.fillStyle = 'rgba(255,255,255,0.16)'; ctx.fillRect(16, barY, 270, 3);
  const w = Math.min(1, perfFrameMs / 16.7) * 270;
  ctx.fillStyle = bad ? '#ff7a4a' : '#7ee07e'; ctx.fillRect(16, barY, w, 3);
  for (let i = 0; i < perfAudioLines.length; i++){
    ctx.fillStyle = i === 0 ? '#9ad6ff' : (i === 5 && audioDiagLastLimit ? '#ffd27a' : 'rgba(255,255,255,0.8)');
    ctx.fillText(perfAudioLines[i], 16, barY + 19 + i * 16, 436);
  }
  ctx.restore();
}

/* 画布状态泄漏自查：save/restore 一旦不配对，后面的绘制会带着错误的变换/裁切，
   屏幕上就是"巨大色块、世界不见了"这种诡异画面。这里记账，丢多少层就补回来。 */
let ctxDepth = 0, ctxRawSave = null, ctxRawRestore = null, ctxWrapWarned = false;
function ctxWrap(){
  if (ctxRawRestore || !ctx || !ctx.restore) return;
  ctxRawSave = ctx.save.bind(ctx);
  ctxRawRestore = ctx.restore.bind(ctx);
  ctx.save = function(){ ctxDepth++; return ctxRawSave(); };
  ctx.restore = function(){
    if (ctxDepth <= 0){
      if (!ctxWrapWarned){ ctxWrapWarned = true; logCrash('canvas', new Error('restore 多于 save（画布状态被提前弹出）')); }
      return ctxRawRestore();
    }
    ctxDepth--;
    return ctxRawRestore();
  };
}
function ctxCheckBalance(where){
  if (ctxDepth <= 0) return;
  logCrash('canvas', new Error(where + ' 结束时还留着 ' + ctxDepth + ' 层 save'));
  while (ctxDepth > 0 && ctxRawRestore){ ctxDepth--; try { ctxRawRestore(); } catch (err){ if (typeof reportErr === 'function') reportErr('58-replay', err); } }
}

/* 高刷屏只需要多画，不必把整套世界模拟也重复到 200~300 次/秒。
   连续确认刷新率高于约 150Hz 后，世界以固定 120Hz 前进；渲染、鼠标事件、
   UI 和音频仍逐个 rAF 执行。144Hz 及以下继续走旧路径，避免改变原有手感。 */
const HIGH_HZ_ENTER_DT = 1 / 150;
const HIGH_HZ_EXIT_DT = 1 / 144;
const HIGH_HZ_CONFIRM_FRAMES = 8;
const HIGH_HZ_SIM_STEP = 1 / 120;
let highHzProbeFrames = 0, highHzSimActive = false, highHzSimAcc = 0;
const highHzSimPlanOut = { steps: 1, dt: 0, active: false };
function highHzSimReset(){
  highHzProbeFrames = 0;
  highHzSimActive = false;
  highHzSimAcc = 0;
}
function highHzSimPlan(dt){
  const out = highHzSimPlanOut;
  out.steps = 0; out.dt = 0; out.active = highHzSimActive;
  if (!(dt > 0)) return out;

  if (!highHzSimActive){
    if (dt < HIGH_HZ_ENTER_DT) highHzProbeFrames++;
    else highHzProbeFrames = 0;
    if (highHzProbeFrames < HIGH_HZ_CONFIRM_FRAMES){
      out.steps = 1; out.dt = dt;
      return out;
    }
    highHzSimActive = true;
    highHzSimAcc = 0;
  } else if (dt >= HIGH_HZ_EXIT_DT){
    /* 刷新率掉回 144Hz 时立刻回旧逻辑，并把不足一步的余量补进本帧。 */
    const carry = highHzSimAcc;
    highHzSimReset();
    out.steps = 1; out.dt = Math.min(0.05, dt + carry); out.active = false;
    return out;
  }

  highHzSimAcc += dt;
  if (highHzSimAcc + 1e-9 >= HIGH_HZ_SIM_STEP){
    highHzSimAcc -= HIGH_HZ_SIM_STEP;
    if (highHzSimAcc < 0) highHzSimAcc = 0;
    out.steps = 1; out.dt = HIGH_HZ_SIM_STEP;
  }
  out.active = true;
  return out;
}
function highHzVisualInputSync(){
  /* 世界可以 120Hz，但枪口/望远镜方向必须继续吃每个显示帧的最新鼠标位置。 */
  if (!highHzSimActive || state !== 'play' || !player || player.hp <= 0 || dyingT > 0) return;
  player.aim = Math.atan2(mouseWorldY() - player.y, mouseWorldX() - player.x);
}

function frame(now){
  /* 兜底：主循环本体包一层，异常只记账不死循环（rAF 在 finally 里续上）。
     以前没有这层，某次绘制抛异常会让 requestAnimationFrame 断掉，
     画面停在上一次成功的那帧 —— 看着就是"卡着动不了、UI 少一半"。 */
  try { frameBody(now); }
  catch (err){ logCrash('frame', err); showCrash(String(err && err.message || err)); }
  finally { requestAnimationFrame(frame); }
}
function frameBody(now){
  if (typeof inventoryInputSync === 'function') inventoryInputSync();
  ctxWrap();          /* 第一次画之前把 save/restore 包上，方便发现状态泄漏 */
  segReset();          /* 上一帧的账已经画在 F3 上了，这里清空重新记 */
  const _deadish = (state === 'dead' || state === 'lose' || state === 'arenaOver');
  if (_deadish) deathK = Math.min(1, deathK + 0.016 / 1.1);
  else deathK = 0;
  if (deathView) deathViewT += 0.016;
  const __t0 = performance.now();
  let dt = (now-last)/1000; last = now;
  dt = clamp(dt, 0, 0.05);   /* 负数 dt（时钟源不一致/系统时间回拨）会让 update 里的计时循环跑爆 */
  uiT += dt;
  /* 退出到菜单/选关/死亡/回放时风噪必须停 —— 主界面还在呼啦呼啦吹是 bug */
  if (typeof windAudioLevel === 'function' && (typeof windActive !== 'function' || !windActive())) windAudioLevel(0);
  if (state !== 'play' && typeof vehEngineSilence === 'function') vehEngineSilence();
  /* m24812：撤离/死亡/回菜单之后雨声不能继续响（结算仓库界面还在下雨）。rainTick 只在 play 里排队，离开后没人收尾 */
  if (state !== 'play' && typeof rainOn !== 'undefined' && rainOn && typeof rainStop === 'function') rainStop();
  /* 音乐走真实帧时间：命中定格/慢放会让 update 提前返回，
     如果音乐挂在 update 上，每次击杀都会漏掉一拍 —— 听着就是"顿一下"。 */
  segBegin('音频'); bgmTick(dt); segEnd();
  segBegin('更新');
  devGateTick();
  const playUpdates = state === 'play' && !devGateAsk && !paused && !mapOpen && !logOpen && !confirmBack && !arenaSlotUI;
  perfUpdSkipped = !playUpdates && state !== 'caught' && state !== 'replay' && state !== 'dead' && state !== 'intro' && state !== 'greplay';
  if (playUpdates){
    resetNavigationWork(true,true);
    const sim = highHzSimPlan(dt);
    for (let s = 0; s < sim.steps && state === 'play'; s++){
      /* 时间加速：同一模拟步里多跑几次，每步还是固定 dt，物理和寻路不会穿墙 */
      const tSteps = clamp(Math.round(devTimeScale) || 1, 1, 8);
      for (let i = 0; i < tSteps && state === 'play'; i++){
        try { update(sim.dt,true); } catch(err){ logCrash('update', err); break; }
      }
      if (state === 'play' && CFG.dev && typeof devOrderTick === 'function') devOrderTick(sim.dt);
    }
  } else {
    highHzSimReset();
    if (state === 'caught'){
    updateCaught(dt);
    } else if (state === 'replay'){
      updateReplay(dt);
    } else if (state === 'dead'){
      deadT += dt;
    } else if (state === 'intro'){
      updateIntro(dt);
    } else if (state === 'greplay'){
      updateGReplay(dt);
    } else if (hpFx.k1 || hpFx.k2 || hpFx.k3) lowHpStop();   /* 离开战斗就把心跳收掉 */
  }
  segEnd();
  /* 音频每帧都要走：update 在暂停/回主菜单时不执行，若把 tick 留在 update 里，
     退出游戏后 levelMusicEl 会一直 loop 响下去（alarm 也会停在最后音量） */
  segBegin('音频'); try { alarm2Update(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('58-replay', err); } segEnd();
  segBegin('音频'); try { levelMusicTick(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('58-replay', err); } segEnd();
  segBegin('战斗音频');
  if (typeof audioHealthTick === 'function') audioHealthTick();
  tinUpdate();
  /* 致死的一发也要播。旧版或未加载的音效脚本不应打断渲染。 */
  if (typeof rocketAudioTick === 'function') rocketAudioTick();
  segEnd();
  if (state === 'arenaOver' && ar && !deathView) arenaCommitBestScore(ar);
  highHzVisualInputSync();
  segBegin('渲染');
  if (state === 'replay'){ try { drawReplay(); } catch(err){ logCrash('render', err); } }
  else if (state === 'greplay'){ try { drawGReplay(); } catch(err){ logCrash('render', err); } }
  else {
    try {
      /* 常规画面前维护暂停静音和选图页淡出；独立回放沿用各自的音轨。 */
      if (typeof audioPauseTick === 'function') audioPauseTick();
      if (typeof dzAudioFrame === 'function') dzAudioFrame();
      render();
      drawDevGate();
    } catch(err){ logCrash('render', err); }
  }
  segEnd();
  segBegin('界面');
  if (state === 'play'){ try { drawDummyPanels(); } catch (err){ if (typeof reportErr === 'function') reportErr('58-replay', err); } }
  if (confirmBack){
    try { drawConfirm(); } catch(err){ logCrash('render', err); }
    flushButtons();
  }
  try { drawArenaSaveUI(); } catch(err){ logCrash('render', err); }
  if (logOpen && logDirty && now - logTick > 200){ logDirty = false; logTick = now; renderLog(); }
  segEnd();
  try { perfTick(now, __t0); } catch(err){ logCrash('perf', err); }
  try { drawCrashBanner(); } catch (err){ if (typeof reportErr === 'function') reportErr('58-replay', err); }
  try { if (window.__CLICKDBG) drawClickDbg(); } catch (err){ if (typeof reportErr === 'function') reportErr('58-replay', err); }
  try { drawStuckHint(dt); } catch (err){ if (typeof reportErr === 'function') reportErr('58-replay', err); }
  try { ctxCheckBalance('本帧'); } catch (err){ if (typeof reportErr === 'function') reportErr('58-replay', err); }
}

/* 卡死自查：freeze 挂着超过 3 秒就把"到底是谁拦住了"写到屏幕左下角。
   正常情况下永远看不到；一旦又出现半边黑、动不了，截图就能直接定位。 */
let stuckT = 0;
function drawStuckHint(dt){
  const on = !!(ar && ar.freeze && state === 'play');
  if (!on){ if (stuckT){ stuckT = 0; } return; }
  stuckT += (dt || 0);
  if (stuckT < 3) return;
  const bits = [];
  if (ar.er) bits.push('er=' + (ar.er.stage || '空转'));
  if (ar.shuf) bits.push('shuf');
  if (ar.choices) bits.push('choices=' + (ar.choices.length | 0));
  if (ar.drawShow && !ar.drawShow.closed) bits.push('drawShow');
  if (ar.banAnim) bits.push('banAnim t=' + (ar.banAnim.t || 0).toFixed(2) + '/' + (ar.banAnim.dur || 0));
  if (ar.cinePending) bits.push('cinePending');
  if (ar.armIdx >= 0) bits.push('arm=' + ar.armIdx);
  if (!bits.length) bits.push('无来源（只挂了 freeze 标志）');
  ctx.save();
  ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(0, H - 44, Math.min(W, 520), 20);
  ctx.fillStyle = '#ffb08a';
  ctx.fillText('冻结 ' + stuckT.toFixed(1) + 's · ' + bits.join(' · '), 8, H - 30);
  ctx.restore();
}

/* ---------------- 开发期错误横幅 ----------------
 * 约定（用户 m01862 第 2 条）：任何 try/catch 都不要空着吞异常，
 * 把错误交给 reportErr(位置, err) —— 屏幕顶部立刻亮一条红条。
 * 同一句错误连续出现只累加次数（显示 "3×"），最多同时留 4 条，8 秒后自动淡出。
 * 这样"某处悄悄报错、画面只是有点怪"的情况能立刻看见，而不用靠截图猜。 */
const ERR_TTL = 8000, ERR_MAX = 4;
let errRows = [], errLastKey = '', errLastAt = -1e9;
function errText(err){
  if (err === null || err === undefined) return '未知错误';
  if (typeof err === 'string') return err;
  const m = (err && err.message) ? err.message : String(err);
  let at = '';
  if (err && err.stack){
    const line = String(err.stack).split('\n')[1] || '';
    at = line.trim().replace(/^at\s+/, '');
  }
  return at ? (m + ' @ ' + at) : m;
}
function reportErr(where, err){
  const now = performance.now();
  const raw = errText(err);
  const text = (where ? '[' + where + '] ' : '') + raw;
  const key = (where || '') + '|' + raw.slice(0, 120);
  /* 同一帧里同一个错被反复抛（比如每帧都炸一次）不能刷屏，只累加计数 */
  if (key === errLastKey && now - errLastAt < 1500){
    const last = errRows[errRows.length - 1];
    if (last){ last.n++; last.t = now; }
    errLastAt = now;
    return;
  }
  errLastKey = key; errLastAt = now;
  const dup = errRows.find(r => r.key === key);
  if (dup){ dup.n++; dup.t = now; return; }
  errRows.push({ key, text, n: 1, t: now });
  while (errRows.length > ERR_MAX) errRows.shift();
  /* 控制台也留一份完整堆栈，方便直接复制 */
  try { console.error('[游戏错误]', where || '未知位置', err); } catch (_){ if (typeof reportErr === 'function') reportErr('58-replay', _); }
}
/* 老接口：单条崩溃提示走同一个通道 */
function showCrash(m){ reportErr('', m); }

/* 点击自查叠层（?dbgclick=1）：把最后一次 mousedown 的坐标/命中的按钮/当前状态写在左上角，
   排查"点了没反应"时让玩家截一张图就能定位到底是没收到点击、还是点错了按钮、还是进了 play 又被弹回来 */
function drawClickDbg(){
  const d = window.__CLICKDBG;
  ctx.save();
  ctx.textAlign = 'left';
  ctx.font = '13px Consolas,monospace';
  const lines = [
    'clickDBG  cv=' + cv.width + 'x' + cv.height + ' css=' + Math.round(cv.getBoundingClientRect().width) + 'x' + Math.round(cv.getBoundingClientRect().height),
    'mouse=(' + Math.round(mouse.x) + ',' + Math.round(mouse.y) + ')  state=' + state + '  dzMap=' + dzMapMode,
    'last=(' + (d.last ? d.last.cx + ',' + d.last.cy : '-') + ')  hit=' + (d.hit || '-'),
    'err=' + (d.err || '-') + '  uiButtons=' + (uiButtons ? uiButtons.length : 0)
  ];
  let y = 22;
  for (const ln of lines){
    ctx.fillStyle = 'rgba(0,0,0,0.72)';
    const wdt = ctx.measureText(ln).width + 10;
    ctx.fillRect(14, y - 14, wdt, 18);
    ctx.fillStyle = '#7ef0a0';
    ctx.fillText(ln, 19, y);
    y += 20;
  }
  /* 十字标：这就是游戏"以为"鼠标在的坐标。跟真实指针差多远，一眼就看出来坐标映射有没有问题 */
  ctx.strokeStyle = '#ff4d4d';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(mouse.x - 18, mouse.y); ctx.lineTo(mouse.x + 18, mouse.y);
  ctx.moveTo(mouse.x, mouse.y - 18); ctx.lineTo(mouse.x, mouse.y + 18);
  ctx.stroke();
  ctx.restore();
}

/* 挂监听：只记住"最后一次点击落在哪、命中了哪个按钮" */
function clickDbgInstall(){
  if (window.__CLICKDBG) return;
  window.__CLICKDBG = { last: null, hit: null, err: null };
  addEventListener('mousedown', ev=>{
    try {
      const r = cv.getBoundingClientRect();
      window.__CLICKDBG.last = { cx: Math.round(ev.clientX - r.left), cy: Math.round(ev.clientY - r.top) };
      const b = (typeof uiHit === 'function') ? uiHit(mouse.x, mouse.y) : null;
      window.__CLICKDBG.hit = b ? String(b.label) : '(未命中任何按钮)';
      setTimeout(()=>{ window.__CLICKDBG.hit += ' → state=' + state; }, 0);
    } catch (e){ window.__CLICKDBG.err = e.message; }
  }, true);
}

function drawCrashBanner(){
  if (!errRows.length) return;
  const now = performance.now();
  errRows = errRows.filter(r => now - r.t < ERR_TTL);
  if (!errRows.length) return;
  ctx.save();
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  let y = 0;
  for (const r of errRows){
    const age = now - r.t;
    const a = age > ERR_TTL - 1200 ? (ERR_TTL - age) / 1200 : 1;
    ctx.globalAlpha = Math.max(0, Math.min(1, a));
    const label = (r.n > 1) ? ('  ' + r.n + '×') : '';
    const text = r.text.slice(0, 150);
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    const w = Math.min(W, ctx.measureText(text + label).width + 24);
    ctx.fillStyle = 'rgba(64,8,8,0.92)';
    ctx.fillRect(0, y, w, 22);
    ctx.fillStyle = '#ff8f80';
    ctx.fillText(text + label, 10, y + 16);
    y += 23;
  }
  ctx.restore();
}

buildRows();
reset();
state = 'menu';
/* 压力测试跑帧器：连着跑 300 帧，记录真实帧间隔与分段自身耗时 */
function stressRun(n){
  const ts = [], segSum = Object.create(null), segName = Object.create(null);
  let frames = 0;
  window.__STRESS = null;
  const t0 = performance.now();
  function tick(){
    frames++;
    ts.push(performance.now());
    for (const it of (perfSegTop || [])){
      const key = it.name;
      segName[key] = key;
      segSum[key] = (segSum[key] || 0) + it.ms;
    }
    if (frames < 302) { requestAnimationFrame(tick); return; }
    const dt = [];
    for (let i = 1; i < ts.length; i++) dt.push(ts[i] - ts[i-1]);
    dt.sort((a,b) => a-b);
    const avg = dt.reduce((a,b) => a+b, 0) / Math.max(1, dt.length);
    const segs = Object.keys(segSum).map(k => [k, +(segSum[k] / Math.max(1, dt.length)).toFixed(2)])
      .sort((a,b) => b[1] - a[1]).slice(0, 6);
    window.__STRESS = {
      n: n, frames: dt.length,
      fps: +(1000 / Math.max(0.01, avg)).toFixed(1),
      avg: +avg.toFixed(2),
      p50: +(dt[Math.floor(dt.length * 0.5)] || 0).toFixed(2),
      p95: +(dt[Math.floor(dt.length * 0.95)] || 0).toFixed(2),
      max: +(dt[dt.length - 1] || 0).toFixed(2),
      enemies: enemies.length,
      segs: segs,
      wall: Math.round(performance.now() - t0)
    };
  }
  requestAnimationFrame(tick);
}

/* 单独页中以真实 rAF 间隔测固定种子的死亡地带；主循环照常跑 AI 和渲染。 */
function openDeathZoneBenchmark(){
  const panel = document.createElement('div');
  panel.style.cssText = 'position:absolute;z-index:30;inset:0;padding:18px;text-align:center;' +
    'font:14px Microsoft YaHei,sans-serif;color:#def1f5';
  const card = document.createElement('div');
  card.style.cssText = 'display:inline-block;padding:12px 16px;border:1px solid #386171;' +
    'border-radius:8px;background:#101820';
  const report = document.createElement('div');
  report.setAttribute('aria-live', 'polite');
  report.style.marginBottom = '8px';
  report.textContent = '死亡地带性能测试 · 硬核随机图 · 低画质 · 1280×800 · 预热 2 秒，测量 12 秒';
  const start = document.createElement('button');
  start.textContent = '开始测试';
  /* m23220：性能测试面板原来只有「开始测试」，点了就出不去（要么测完、要么关页面）。
     这里补一个「关闭」+ Esc + 点空白处，三条路都能退。 */
  const closeBtn = document.createElement('button');
  closeBtn.textContent = '关闭 (Esc)';
  closeBtn.style.marginLeft = '10px';
  closeBtn.style.opacity = '0.9';
  card.append(report, start, closeBtn);
  panel.append(card);
  cv.parentElement.append(panel);
  /* m35424：性能测试页是临时沙盒 —— 参数/难度/种子全部快照，退出原样还原，
     期间一律不写正式存档（saveCfg 看 window.__BENCH_ISO）。 */
  window.__BENCH_ISO = true;
  const _benchSnap = {
    cfg: JSON.parse(JSON.stringify(CFG)),
    dzTier: (typeof dzTier !== 'undefined' ? dzTier : null),
    dzMapMode: (typeof dzMapMode !== 'undefined' ? dzMapMode : null),
    dzSeed: (typeof dzSeed !== 'undefined' ? dzSeed : null),
    dzSeedFixed: (typeof dzSeedFixed !== 'undefined' ? dzSeedFixed : false),
    dzSavedCfg: (typeof dzSavedCfg !== 'undefined' && dzSavedCfg) ? JSON.parse(JSON.stringify(dzSavedCfg)) : null,
    dzSavedDiff: (typeof dzSavedDiff !== 'undefined' ? dzSavedDiff : ''),
    diffName: (typeof diffName !== 'undefined' ? diffName : 'normal')
  };
  /* m35424：cancelled/closed 要先声明 —— 下面 onKeyDown 与帧循环都会用到 */
  let cancelled = false, closed = false;
  let rafId = 0;
  /* m23220：Esc 必须在这里处理 —— 这句 stopImmediatePropagation() 会吃掉之后注册的所有监听器。
     m35424：这也是"按键全失灵"的元凶 —— 面板一移除，panel.contains() 恒为 false，
     于是它继续吞掉全部按键。现在存句柄，退出时自摘。 */
  function onKeyDown(e){
    if (closed) return;
    if (e.code === 'Escape' || e.key === 'Escape'){
      e.preventDefault(); e.stopImmediatePropagation();
      closePanel();
      return;
    }
    if (!panel.contains(e.target)) e.stopImmediatePropagation();
  }
  window.addEventListener('keydown', onKeyDown, true);

  /* 统一清理路径：关闭按钮 / Esc / 点空白 / 测试失败 / 页面卸载 都走这里 */
  function closePanel(){
    if (closed) return;
    closed = true; cancelled = true;
    try { window.removeEventListener('keydown', onKeyDown, true); } catch (err){}
    try { document.removeEventListener('visibilitychange', onVis); } catch (err){}
    if (rafId){ try { cancelAnimationFrame(rafId); } catch (err){} rafId = 0; }
    try { panel.remove(); } catch (err){}
    /* 还原正式参数：测试里改的 CFG / 难度 / 种子全部扔掉 */
    try {
      if (typeof CFG !== 'undefined' && _benchSnap.cfg){
        for (const k of Object.keys(CFG)) delete CFG[k];
        Object.assign(CFG, _benchSnap.cfg);
      }
      if (_benchSnap.dzTier !== null && typeof dzTier !== 'undefined') dzTier = _benchSnap.dzTier;
      if (_benchSnap.dzMapMode !== null && typeof dzMapMode !== 'undefined') dzMapMode = _benchSnap.dzMapMode;
      if (_benchSnap.dzSeed !== null && typeof dzSeed !== 'undefined') dzSeed = _benchSnap.dzSeed;
      if (typeof dzSeedFixed !== 'undefined') dzSeedFixed = _benchSnap.dzSeedFixed;
      if (typeof dzSavedCfg !== 'undefined') dzSavedCfg = _benchSnap.dzSavedCfg;
      if (typeof dzSavedDiff !== 'undefined') dzSavedDiff = _benchSnap.dzSavedDiff;
      if (typeof diffName !== 'undefined') diffName = _benchSnap.diffName;
    } catch (err){}
    window.__BENCH_ISO = false;
    try { paused = false; } catch (err){}
    /* 回大厅：测试场景是把玩家丢进死亡地带的，直接留在局里不合适 */
    try { if (typeof goMenu === 'function') goMenu(); } catch (err){}
    /* 去掉 ?bench 参数：刷新后就是正常大厅，不再是测试页 */
    try {
      if (typeof history !== 'undefined' && history.replaceState && String(location.search).indexOf('bench') >= 0){
        history.replaceState(null, '', location.pathname + location.hash);
      }
    } catch (err){}
  }
  closeBtn.addEventListener('click', closePanel);
  panel.addEventListener('mousedown', (e)=>{ if (e.target === panel) closePanel(); });
  function onVis(){
    if (document.hidden && start.disabled) cancelled = true;
  }
  document.addEventListener('visibilitychange', onVis);
  window.addEventListener('pagehide', function(){ window.__BENCH_ISO = false; });
  start.addEventListener('click', ()=>{
    start.disabled = true;
    window.__DZ_BENCH = null;
    report.textContent = '正在预热…';
    requestAnimationFrame(()=>{
      CFG = {...DEFAULTS, lodNear:300, lodFar:700};
      dzTier = 'core'; dzMapMode = 'random'; dzSeed = 20261122; dzSeedFixed = true;
      try { startDeathZone({benchmark:true}); }
      catch (err){
        report.textContent = '测试场景加载失败 · ' + (err.message || err);
        start.disabled = false;
        window.__BENCH_ISO = false;
        return;
      }
      const spot = safeSpot(cur(), {x:4515,y:4870}, player.r + 2);
      player.x = spot.x; player.y = spot.y; player.hp = 1e9; player.grace = 0;
      paused = false; msgT = 0;
      const frames = [];
      const warmUntil = performance.now() + 2000;
      let prev = null, begin = null, nextReport = 0;
      function finish(text){
        paused = true;
        report.textContent = text;
        start.disabled = false;
        start.textContent = '重新测试';
      }
      function sample(now){
        if (closed) return;
        if (cancelled || document.hidden || state !== 'play' || paused){
          cancelled = false;
          finish('本次测试已中断 · 请保持测试页在前台并重新测试');
          return;
        }
        const angle = (now - warmUntil) * .0014;
        mouse.x = W / 2 + Math.cos(angle) * 250;
        mouse.y = H / 2 + Math.sin(angle) * 250;
        if (now >= warmUntil){
          if (prev === null) begin = now;
          else frames.push(now - prev);
          prev = now;
          const elapsed = now - begin;
          if (elapsed >= 12000){
            const fps = frames.length * 1000 / elapsed;
            frames.sort((a,b)=>a-b);
            const p95 = frames[Math.ceil(frames.length * .95) - 1];
            const slow = frames.filter(dt=>dt>1000/30+0.5).length;
            const over50 = frames.filter(dt=>dt>50).length;
            window.__DZ_BENCH = { fps, p95, slow, over50, frames: frames.length, enemies: enemies.length };
            finish('平均 ' + fps.toFixed(1) + ' FPS · P95 ' + p95.toFixed(1) +
                   ' ms · 超过 33.8 ms 的帧 ' + (slow * 100 / frames.length).toFixed(1) +
                   '% · 超过 50 ms 的帧 ' + over50 + ' / ' + frames.length + ' · 人机 ' + enemies.length);
            return;
          }
          if (now >= nextReport){
            report.textContent = '测量中 · 剩 ' + Math.ceil((12000 - elapsed) / 1000) + ' 秒';
            nextReport = now + 1000;
          }
        }
        if (closed) return;
        rafId = requestAnimationFrame(sample);
      }
      rafId = requestAnimationFrame(sample);
    });
  });
}

/* 开发用：?shot=<关卡序号>&px=&py=&aim= —— 直接进关并站到指定位置，
   方便用无头浏览器截图检查屋顶/灰暗/提示这些"只有画出来才看得出来"的东西 */
(function(){
  try {
    if (typeof location === 'undefined' || !location.search) return;
    const q = new URLSearchParams(location.search);
    if (deathZoneBenchmarkPage){
      openDeathZoneBenchmark();
      return;
    }
    if (q.has('stress')){
      /* 压力测试：?stress=<人数> —— 在死亡地带的空地上摆 N 个敌人，测真实帧时间。
         跑完把结果写进 window.__STRESS，由 _work/_stress.cjs 通过 CDP 读取。 */
      const _n = Math.max(1, Math.min(1200, +q.get('stress') || 0));
      if (q.has('sz')){ const _s = (+q.get('sz') | 0) || 6000; dzForceSide = Math.max(3000, Math.min(20000, _s)); }
      if (q.has('seed')){ dzSeed = (+q.get('seed') | 0) >>> 0; dzSeedFixed = true; }
      startDeathZone();
      player.god = true; player.grace = 0;
      /* 摆在空地中央：6000² 时正好是老图的中间空地，12000² 时落在内容区之外的空白 */
      player.x = DZ_W * 0.5; player.y = DZ_H * 0.55;
      enemies.length = 0;
      for (let i = 0; i < _n; i++){
        const a = i / _n * TAU + Math.PI, r = 150 + (i % 9) * 62;
        const e = dzAddEnemy(player.x + Math.cos(a) * r, player.y + Math.sin(a) * r, 'grunt');
        if (e) e.ang = a + Math.PI;
      }
      state = 'play';
      perfOn = true;
      stressRun(_n);
      return;
    }

    if (q.has('perf')){ perfOn = true; if (typeof perfLongInstall === 'function') perfLongInstall(); }   /* 自查：直接开 F3 叠层，配合截图看帧时间 */
    if (q.has('dbgclick')) clickDbgInstall();
    if (q.get('click') === 'dz'){    /* 自查用：像真人一样在菜单上点一下"死亡地带"（等循环跑起来再点） */
      state = 'arcade';
      if (q.has('rnd')) dzMapMode = 'random';
      setTimeout(()=>{
        try {
          drawArcade();
          const _b = (uiButtons || []).find(x => x.label === '死亡地带');
          if (!_b){ setMsg('CLICKERR: 没找到按钮', 30); return; }
          _b.fn();
          logInfo('dbg', 'clicked dz → state=' + state);
        } catch (e){ setMsg('CLICKERR: ' + e.message, 30); }
      }, 400);
      return;
    }
    if (q.has('arcade')){ state = 'arcade'; return; }   /* 自查用：直接看娱乐模式菜单 */
    if (q.has('dzpick')){ state = 'dzpick'; return; }    /* 自查用：直接看死亡地带选图 */
    if (q.has('dz')){
      /* 自查：带 seed/sz 或 map=random 就走随机图，否则默认经典图 */
      if (q.has('seed') || q.has('sz') || q.get('map') === 'random') dzMapMode = 'random';
      if (q.has('sz')){ const _s = (+q.get('sz') | 0) || 6000; dzForceSide = Math.max(3000, Math.min(20000, _s)); }   /* 自查用：临时换边长，量四倍面积 */
      if (q.has('seed')){ dzSeed = (+q.get('seed') | 0) >>> 0; dzSeedFixed = true; }
      startDeathZone();
      if (q.has('mask')) thunderMaskT = (+q.get('mask') || 3);   /* 自查用：直接把"雷声掩盖"开到 N 秒，看 HUD（必须放在 startDeathZone 之后，它会把计时清零） */
      if (q.has('lock')){        /* 自查用：站到第一扇锁着的门前面，看开锁提示 */
        const _d = doors.filter(function(d){ return d.isLocked && !d.unlocked; })[0];
        if (_d){ player.x = _d.x + _d.w / 2; player.y = _d.y + _d.h + 34; }
      }
      if (q.has('px')) player.x = +q.get('px');
      if (q.has('py')) player.y = +q.get('py');
      if (q.has('aim')) player.aim = +q.get('aim');
      if (q.has('tier')){ const _t = String(q.get('tier') || ''); if (['hard','nightmare','core'].indexOf(_t) >= 0) dzTier = _t; }   /* 自查：切换死亡地带难度 */
      if (q.has('intel')) player.hasIntel = true;
      if (q.has('ex')){       /* 自查：直接站到撤离点上，用来看读条 */
        try {
          dzRevealExtract(cur());
          player.x = cur().extract.x + cur().extract.w / 2;
          player.y = cur().extract.y + cur().extract.h / 2;
          cur().dzBox = true;
          player.holdT = 3.2;
        } catch (e){ if (typeof reportErr === 'function') reportErr('58-replay', e); }
      }
      if (q.has('stash')){     /* 自查：直接开仓库面板（pre=出发前整理 / settle=撤离结算） */
        setTimeout(function(){
          try {
            stashLoad();
            const _c = stashCells(); let _n = 0;
            while (_n < 5){ const _it = bagAddCell(_n % 2 ? 'ammo' : 'med', _n % 2 ? { t:'rifle', n:30 } : { rarity:'small' }); if (!_it) break; _n++; }
            if (_n < 5) bagAddCell('med', { rarity:'big' });
            stashOpenPanel(q.get('stash') === 'settle' ? 'settle' : 'pre');
          } catch (e){ if (typeof reportErr === 'function') reportErr('58-replay', e); }
        }, 1000);
      }   /* 自查：假装已经换到情报（必须放在 startDeathZone 之后，它会清零） */
      if (q.has('box')){      /* 自查用：直接把黑匣子塞进包里，看撤离点 */
        const _b = loots.find(l => l.kind === 'blackbox');
        if (_b){ _b.x = player.x; _b.y = player.y; pickLoot(_b); }
      }
      state = 'play';
      if (q.has('gacha')){ setTimeout(function(){ try { gachaOpen(); } catch (e){ if (typeof reportErr === 'function') reportErr('58-replay', e); } }, 1200); }   /* 自查：等开局流程走完再开面板 */
      if (q.has('xray')){ CFG.dev = true; CFG.xray = true; }   /* 自查用：地图上把所有人都画出来 */
      if (q.has('map')) mapOpen = true;   /* 自查用：直接开地图看整张 6000×6000 */
      if (q.has('boom')){      /* 自查用：当场炸一发，看【高爆弹头】的冲击波圈有多大（boom=N 就是叠几层） */
        const _lv = Math.max(0, Math.min(3, +q.get('boom') || 0));
        if (ar){ ar.rwBoom = _lv; }
        player.god = true;
        enemies.length = 0;              /* 别让附近的火箭兵一起炸，截图只留这一圈 */
        if (typeof trucks !== 'undefined') trucks.length = 0;
        rocketBlast(player.x + 430, player.y + 40, player);
      }
      return;
    }
    if (q.has('er')){      /* 自查用：直接开战斗爽并拿上「老实抽卡」，er=pick|roll|res 停在对应界面 */
      startArena(0, true);
      if (q.get('er') === 'list'){      /* 自查用：停在加成一览，看那张卡名字周围的红光 */
        ar.picks.push('老实抽卡，很枯燥吧？'); ar.picks.push('致命一击'); ar.picks.push('扳机改造');
        ar.honestSeen = true; ar.honestAt = sndNow() - (+q.get('t') || 1.4);
        arenaRebuildStats();
        ar.er = null;
        confirmBack = true;
        return;
      }
      if (q.get('er') === 'arm'){       /* 自查用：停在"第一次举起这张卡"，看红光 */
        ar.choices = [UPGRADES.find(u => u.id === 'honest'), UPGRADES.find(u => u.id === 'crit'), UPGRADES.find(u => u.id === 'rof')];
        ar.armIdx = 0; ar.freeze = true; ar.drawShow = null; ar.choices0 = null;
        ar.honestSeen = true; ar.honestAt = sndNow() - (+q.get('t') || 1.0);
        return;
      }
      ar.picks.push('致命一击'); ar.picks.push('致命一击');
      ar.picks.push('扳机改造');
      ar.picks.push('老实抽卡，很枯燥吧？');
      arenaRebuildStats();
      ar.wave = 3;
      erStart(); ar.freeze = false; ar.er.pend = true;
      const m = q.get('er');
      if (m === 'tag'){ ar.er.pend = false; ar.er.target = '致命一击'; ar.er.waves = 1; ar.freeze = false; return; }
      erTick(0.016);
      if (m !== 'pick'){
        ar.er.pend = false; ar.er.target = '致命一击'; erFire();
        if (m === 'roll'){} else { erTick(ER_ROLL_T + 0.01); }
      }
      ar.freeze = true;
      return;
    }
    if (!q.has('shot')) return;
    const i = Math.max(0, Math.min(LEVELS.length - 1, +q.get('shot') || 0));
    startLevel(i);
    if (q.has('px')) player.x = +q.get('px');
    if (q.has('py')) player.y = +q.get('py');
    if (q.has('aim')) player.aim = +q.get('aim');
    if (q.has('noroof')) roofs.length = 0;   /* 自查用：把屋顶去掉，看地面本身有没有那道暗边 */
    state = 'play';
  } catch (e){ if (typeof reportErr === 'function') reportErr('58-replay', e); }
})();
/* 兜住所有没被自己 try 住的异常：照样进横幅，不让它只活在 DevTools 里 */
addEventListener('error', function(ev){
  try { reportErr('window', (ev && (ev.error || ev.message)) || '未知错误'); } catch (_){}
});
addEventListener('unhandledrejection', function(ev){
  try { reportErr('promise', (ev && ev.reason) || '未处理的 Promise 拒绝'); } catch (_){}
});
requestAnimationFrame(frame);
/* F11 已经被 KEY_NO_DEFAULT 挡住浏览器默认行为，这里改成"整页全屏"：
   比浏览器 F11 好在——不显示标签栏/地址栏，画面能真正吃满屏幕。
   Esc 由浏览器自己退出全屏，不用我们处理。 */
function toggleFullscreen(){
  const el = document.documentElement;
  try {
    if (document.fullscreenElement || document.webkitFullscreenElement){
      (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    } else {
      const req = el.requestFullscreen || el.webkitRequestFullscreen;
      if (req) req.call(el, { navigationUI: 'hide' });
      else setMsg('这个浏览器不让网页全屏，用 F11 走浏览器自己的全屏', 3.0);
    }
  } catch(e){
    setMsg('全屏被浏览器拦了：' + (e && e.message ? e.message : e), 3.0);
  }
}
if (typeof document !== 'undefined'){
  const bf = document.getElementById('btnFull');
  if (bf) bf.addEventListener('click', ()=> toggleFullscreen());
  /* 注意：不要给 canvas 挂 dblclick 切全屏 —— 双击就是连开两枪，一开枪画面就被放大。全屏只留按钮和浏览器自己的 F11 */
}
