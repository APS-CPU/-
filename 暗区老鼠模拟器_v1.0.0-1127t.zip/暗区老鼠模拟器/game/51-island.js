/* ======================= 死亡地带 · 不规则岛 =======================
   用户要的：地图不是一块方方正正的矩形，而是一座四周是水的岛；边界就是水（进不去），
   尺寸不再随机，一次到位。

   设计约束（为什么这么做）：
     · 引擎的碰撞全是 AABB，斜边只能拿台阶拼 —— 一圈台阶要几百条墙，导航栅格化、
       视线射线、静态层烘焙全跟着变慢。所以**岛边不是墙，是"不可走区域"**：
       导航栅格里把多边形外的格子全标死，玩家/敌人越界就被推回最近的内点。
       这样"水"和"墙"在物理上等价，但一条墙都不用加。
     · 岛是"超椭圆 + 几个海湾"而不是随机噪声：随机顶点很容易切到核心块里的地标
       （庄园/军营/城区），超椭圆的**对角线半径**能保证 6000² 的核心块四角都在陆地上。
     · 陆地面积按几何算，撒点密度用「陆地面积」，不再用包围盒面积 —— 否则海湾一深，
       同一个人数铺到剩下的小陆地上，密度就翻倍了。
   ------------------------------------------------------------------ */

const ISLAND_BOX = 11500;      /* 包围盒边长：核心块 6000 居中，四周留出海岸与海面 */
const ISLAND_A = 4700;        /* 超椭圆半径（到边中点）；对角线半径 = A * 2^(-1/8) ≈ 0.917A */
const ISLAND_N = 3.2;           /* 超椭圆指数：越大越接近正方形；8 时对角线 0.917A > 核心块角 4243 */
let dzIsland = null;          /* { poly:[{x,y}], cx, cy, bbox, area, landK } */

function dzPolyInPoly(px, py, poly){
  if (!poly || poly.length < 3) return true;
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++){
    const xi = poly[i].x, yi = poly[i].y, xj = poly[j].x, yj = poly[j].y;
    if (((yi > py) !== (yj > py)) && (px < (xj - xi) * (py - yi) / (yj - yi) + xi)) inside = !inside;
  }
  return inside;
}
/* 到多边形边界的最短距离（点在内部时为正） */
function dzPolyEdgeDist(px, py, poly){
  let best = 1e9;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++){
    const ax = poly[j].x, ay = poly[j].y, bx = poly[i].x, by = poly[i].y;
    const vx = bx - ax, vy = by - ay;
    const L2 = vx * vx + vy * vy || 1;
    let t = ((px - ax) * vx + (py - ay) * vy) / L2;
    t = t < 0 ? 0 : (t > 1 ? 1 : t);
    const dx = px - (ax + vx * t), dy = py - (ay + vy * t);
    const d = Math.sqrt(dx * dx + dy * dy);
    if (d < best) best = d;
  }
  return best;
}
/* 把越界的点拉回陆地（沿最近边界点往里退 12px）。返回 {x,y,moved} */
function dzPolyClamp(px, py, poly, pad){
  poly = poly || (dzIsland && dzIsland.poly);
  if (!poly || dzPolyInPoly(px, py, poly)) return { x: px, y: py, moved: false };
  pad = (pad === undefined) ? 12 : pad;
  let bx = px, by = py, best = 1e18;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++){
    const ax = poly[j].x, ay = poly[j].y, bx2 = poly[i].x, by2 = poly[i].y;
    const vx = bx2 - ax, vy = by2 - ay;
    const L2 = vx * vx + vy * vy || 1;
    let t = ((px - ax) * vx + (py - ay) * vy) / L2;
    t = t < 0 ? 0 : (t > 1 ? 1 : t);
    const cx = ax + vx * t, cy = ay + vy * t;
    const d = (px - cx) * (px - cx) + (py - cy) * (py - cy);
    if (d < best){ best = d; bx = cx; by = cy; }
  }
  /* 从边界点朝中心退 pad */
  const c = dzIsland;
  let dx = c.cx - bx, dy = c.cy - by;
  const dl = Math.sqrt(dx * dx + dy * dy) || 1;
  return { x: bx + dx / dl * pad, y: by + dy / dl * pad, moved: true };
}
function dzPolyArea(poly){
  let a = 0;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++){
    a += (poly[j].x + poly[i].x) * (poly[j].y - poly[i].y);
  }
  return Math.abs(a / 2);
}
/* 生成岛：超椭圆 + 三个海湾（海湾只出现在四条边的中点方向，避开核心块的四个角） */
/* 用户 m12734：岛看着还是"矩形里套多边形"，要回退成矩形 + 边缘柔化。
   把 ISLAND_ENABLED 改成 true 就能把岛图开回来。 */
const ISLAND_ENABLED = false;

function dzIslandMake(seed){
  if (!ISLAND_ENABLED) return null;
  const cx = ISLAND_BOX / 2, cy = ISLAND_BOX / 2, A = ISLAND_A;
  const rnd = (typeof arenaRandom === 'function') ? arenaRandom : Math.random;
  /* 海湾：随机的方向（只在 4 个基本方向附近）+ 深度 */
  const bays = [];
  const bayDirs = [0, Math.PI / 2, Math.PI, -Math.PI / 2];
  const nBay = 2 + ((rnd() < 0.45) ? 1 : 0);
  const used = [];
  for (let i = 0; i < nBay; i++){
    let k = Math.floor(rnd() * 4) % 4;
    let guard = 0;
    while (used.indexOf(k) >= 0 && guard++ < 8) k = (k + 1) % 4;
    used.push(k);
    bays.push({ a: bayDirs[k] + (rnd() - 0.5) * 0.7, w: 0.34 + rnd() * 0.20, depth: 900 + rnd() * 520 });
  }
  const ph1 = rnd() * Math.PI * 2, ph2 = rnd() * Math.PI * 2, ph3 = rnd() * Math.PI * 2;
  /* 半岛：1~2 块，方向随机、半径 280~520 */
  const pens = [];
  const nPen = 1 + (rnd() < 0.5 ? 1 : 0);
  for (let i = 0; i < nPen; i++){
    pens.push({ a: rnd() * Math.PI * 2, w: 0.28 + rnd() * 0.16, h: 280 + rnd() * 260 });
  }
  const poly = [];
  const N = 96;
  for (let i = 0; i < N; i++){
    const th = i / N * Math.PI * 2;
    /* 超椭圆半径：r = A / (|cos|^n + |sin|^n)^(1/n) */
    const c = Math.abs(Math.cos(th)), s = Math.abs(Math.sin(th));
    let r = A / Math.pow(Math.pow(c, ISLAND_N) + Math.pow(s, ISLAND_N), 1 / ISLAND_N);
    /* 两组低频噪声：大尺度让轮廓"坨"起来，小尺度加碎边 —— 光靠超椭圆还是太规整 */
    r *= 1 + 0.10 * Math.sin(2 * th + ph1) + 0.07 * Math.sin(3 * th + ph2) + 0.04 * Math.sin(6 * th + ph3);
    /* 半岛：某方向鼓出去一块，海岸线才不是同心圆 */
    for (const pen of pens){
      const d2 = Math.atan2(Math.sin(th - pen.a), Math.cos(th - pen.a));
      r += pen.h * Math.exp(-(d2 * d2) / (pen.w * pen.w));
    }
    /* 海湾：在方向 a 附近按高斯型凹进去 */
    for (const b of bays){
      let d = Math.atan2(Math.sin(th - b.a), Math.cos(th - b.a));
      const k = Math.exp(-(d * d) / (b.w * b.w));
      r -= b.depth * k;
    }
    /* 一点碎边，避免完美光滑（海岸线不该是数学曲线） */
    /* 下限：核心块里的内容最远约 3400，低于它就会把房子切下海 */
    if (r < 3500) r = 3500 + (r - 3500) * 0.15;
    r *= 1 + (rnd() - 0.5) * 0.05;
    poly.push({ x: Math.round(cx + Math.cos(th) * r), y: Math.round(cy + Math.sin(th) * r) });
  }
  const area = dzPolyArea(poly);
  dzIsland = { poly: poly, cx: cx, cy: cy, box: ISLAND_BOX, area: area,
               landK: area / (ISLAND_BOX * ISLAND_BOX) };
  return dzIsland;
}
/* 陆地面积系数：撒点/铺人密度都用它归一（1 = 满包围盒） */
function dzLandK(){ return (dzIsland && dzIsland.landK) ? dzIsland.landK : 1; }
/* 这个点能不能放东西（陆地内、离岸留点余量） */
function dzOnLand(x, y, pad){
  if (!dzIsland) return true;
  if (!dzPolyInPoly(x, y, dzIsland.poly)) return false;
  if (pad && dzPolyEdgeDist(x, y, dzIsland.poly) < pad) return false;
  return true;
}
/* 画岛的路径（供静态层/地图共用）：直接描多边形 */
function dzIslandPath(g){
  if (!dzIsland) return false;
  g.beginPath();
  const p = dzIsland.poly;
  g.moveTo(p[0].x, p[0].y);
  for (let i = 1; i < p.length; i++) g.lineTo(p[i].x, p[i].y);
  g.closePath();
  return true;
}

/* 海：把包围盒里、多边形之外的部分涂成水，再描一圈岸线。
   opt: { water, deep, shore, foam, w, h, thin } —— 地图界面用不同配色、细一点 */
function dzDrawSea(g, opt){
  if (!dzIsland) return false;
  const L = (typeof cur === 'function') ? cur() : null;
  const W = (opt && opt.w) || (L ? L.w : ISLAND_BOX);
  const H = (opt && opt.h) || (L ? L.h : ISLAND_BOX);
  const X0 = (opt && typeof opt.x0 === 'number') ? opt.x0 : 0;
  const Y0 = (opt && typeof opt.y0 === 'number') ? opt.y0 : 0;
  const o = opt || {};
  g.save();
  /* 水面：外框 + 岛，用 evenodd 一次填出"岛外全是水" */
  g.beginPath();
  g.rect(X0, Y0, W, H);
  const p = dzIsland.poly;
  g.moveTo(p[0].x, p[0].y);
  for (let i = 1; i < p.length; i++) g.lineTo(p[i].x, p[i].y);
  g.closePath();
  g.fillStyle = o.water || '#0c1b26';
  g.fill('evenodd');
  /* 近岸浅水：沿多边形往里描几圈越来越淡的线，做出"水深渐变"的错觉 */
  g.lineJoin = 'round';
  for (let k = 3; k >= 1; k--){
    g.beginPath();
    g.moveTo(p[0].x, p[0].y);
    for (let i = 1; i < p.length; i++) g.lineTo(p[i].x, p[i].y);
    g.closePath();
    g.strokeStyle = o.deep || 'rgba(30,66,88,0.45)';
    g.lineWidth = (o.thin ? 3 : 16) * k;
    g.stroke();
  }
  /* 岸线：一条沙色细边 */
  g.beginPath();
  g.moveTo(p[0].x, p[0].y);
  for (let i = 1; i < p.length; i++) g.lineTo(p[i].x, p[i].y);
  g.closePath();
  g.strokeStyle = o.shore || 'rgba(214,196,150,0.55)';
  g.lineWidth = o.thin ? 2 : 3.5;
  g.stroke();
  g.restore();
  return true;
}

/* 找一个"确定在陆地上"的点：先夹回边界内，再沿指向岛心的方向往里走，直到离岸够远。
   出生点、撤离点这类必须保证能站人的地方用它（单纯 clamp 在凹海湾里可能还会落在水上）。 */
function dzLandSpot(x, y, pad){
  pad = pad || 80;
  if (!dzIsland) return { x: x, y: y };
  let px = x, py = y;
  if (!dzPolyInPoly(px, py, dzIsland.poly)){
    const c = dzPolyClamp(px, py, dzIsland.poly, 40);
    px = c.x; py = c.y;
  }
  for (let i = 0; i < 60; i++){
    if (dzOnLand(px, py, pad)) return { x: px, y: py };
    const dx = dzIsland.cx - px, dy = dzIsland.cy - py;
    const dl = Math.sqrt(dx * dx + dy * dy) || 1;
    px += dx / dl * 90; py += dy / dl * 90;
  }
  return { x: dzIsland.cx, y: dzIsland.cy };   /* 兜底：岛心一定在陆地 */
}
