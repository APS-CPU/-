/* 62-devitem.js —— 开发者「刷物资」面板（V）
   以前 V 是一口气把 27 件撒在脚边，乱得没法挑、也选不了数量。
   现在改成和 J（投放人机）一样的分组面板：分组切页、上下选、Z/X 调数量、Enter 投放。
   Shift+V 仍然保留"一次全撒"的老行为。
   加新物资只要往 DEV_ITEM_GROUPS 里加一行。 */

const DEV_ITEM_GROUPS = [
  { key: 'gun', name: '枪械', items: [
    { c: { k:'gun', wid:'pistol' },  name: '手枪' },
    { c: { k:'gun', wid:'shotgun' }, name: '霰弹枪' },
    { c: { k:'gun', wid:'rifle' },   name: 'Uzi 冲锋枪' },
    { c: { k:'gun', wid:'ar' },      name: 'AR15' },
    { c: { k:'gun', wid:'rpg' },     name: '火箭筒' },
    { c: { k:'gun', wid:'flare' },   name: '信号枪' },
    { c: { k:'gun', wid:'bino' },    name: '望远镜' },
    { c: { k:'gun', wid:'knife' },   name: '战术刀' },
    { c: { k:'gun', wid:'dao' },     name: '弯刀' }
  ]},
  { key: 'ammo', name: '弹药', items: [
    { c: { k:'ammo', t:'pistol',  n:24 }, name: '手枪弹 ×24' },
    { c: { k:'ammo', t:'shotgun', n:18 }, name: '霰弹 ×18' },
    { c: { k:'ammo', t:'rifle',   n:60 }, name: '冲锋枪弹 ×60' },
    { c: { k:'ammo', t:'ar',      n:60 }, name: '步枪弹 ×60' },
    { c: { k:'ammo', t:'rocket',  n:1 },  name: '火箭弹 ×1（占 2×1）' },
    { c: { k:'ammo', t:'flare',   n:1 },  name: '信号弹 ×1' }
  ]},
  { key: 'use', name: '消耗', items: [
    { c: { k:'med', r:'small', q:0 }, name: '小药（回复 30）' },
    { c: { k:'med', r:'big',   q:0 }, name: '绿药包（回复 70）' },
    { c: { k:'nade' },  name: '手榴弹' },
    { c: { k:'smoke' }, name: '烟雾弹' },
    { c: { k:'heatcell' }, name: '热成像电池' },
    { c: { k:'key' },   name: '万能钥匙' },
    { c: { k:'rope' },      name: '绳子（拖到手雷上 = 绊雷）' },
    { c: { k:'tripwire' },  name: '绊雷（左键点 = 布设）' },
    { c: { k:'blackbox' },  name: '黑匣子（死亡地带目标）' },
    { c: { k:'intel' },     name: '情报（标出黑匣子区域）' }
  ]},
  { key: 'gear', name: '护甲背包', items: [
    { c: { k:'armor', ak:'light' }, name: '轻甲' },
    { c: { k:'armor', ak:'heavy' }, name: '重甲' },
    { c: { k:'armor', ak:'elite' }, name: '精锐甲' },
    { c: { k:'bag', bk:'small' },   name: '小背包' },
    { c: { k:'bag', bk:'mid' },     name: '中背包' },
    { c: { k:'bag', bk:'big' },     name: '大背包' },
    { c: { k:'shield' },    name: '防弹盾牌' },
    { c: { k:'thermal' },   name: '热成像' }
  ]},
  { key: 'clean', name: '清理', items: [
    { act: 'clearLoot',    name: '清空地上所有道具' },
    { act: 'clearCorpse',  name: '清空地上的尸体' },
    { act: 'clearFx',      name: '清空所有特效（子弹/弹道/血渣/伤害数字）' },
    { act: 'clearAll',     name: '清空道具 + 尸体 + 特效' }
  ]},
  { key: 'att', name: '配件', items: [
    { c: { k:'attach', aid:'choke_std' },   name: '标准收束器' },
    { c: { k:'attach', aid:'choke_tight' }, name: '紧束收束器' },
    { c: { k:'attach', aid:'choke_long' },  name: '长管收束器' },
    { c: { k:'attach', aid:'mag_ext1' },   name: '扩容弹匣 I' },
    { c: { k:'attach', aid:'mag_ext2' },   name: '扩容弹匣 II' },
    { c: { k:'attach', aid:'mag_ext3' },   name: '扩容弹匣 III' },
    { c: { k:'attach', aid:'mag_fast1' },  name: '快速弹匣 I' },
    { c: { k:'attach', aid:'mag_fast2' },  name: '快速弹匣 II' },
    { c: { k:'attach', aid:'mag_fast3' },  name: '快速弹匣 III' }
  ]}
];

let devItemOpen = false;
let devItemGroup = 0;
let devItemSel = 0;
let devItemQty = 1;

function devItemGroupDef(){ return DEV_ITEM_GROUPS[devItemGroup] || DEV_ITEM_GROUPS[0]; }
function devItemDef(){
  const g = devItemGroupDef();
  return g && g.items[devItemSel] || null;
}
function devItemStep(d){
  const g = devItemGroupDef();
  const n = (g && g.items.length) || 1;
  devItemSel = (devItemSel + d + n) % n;
}
function devItemGroupStep(d){
  devItemGroup = (devItemGroup + d + DEV_ITEM_GROUPS.length) % DEV_ITEM_GROUPS.length;
  devItemSel = 0;
}
function devItemQtyStep(d){
  devItemQty = Math.max(1, Math.min(20, (devItemQty | 0) + d));
}
function devItemPanelGeom(){
  const g = devItemGroupDef();
  const n = Math.max(1, g.items.length);
  const pw = 420;
  const rowH = 24;
  const ph = 96 + n * rowH + 34;
  const x = (W - pw) / 2;
  const y = clamp(72, 42, Math.max(42, H - ph - 54));
  return { x: x, y: y, w: pw, h: ph, rowH: rowH, n: n, tabsY: y + 44, itemsY: y + 80 };
}
function devItemTabRects(G){
  const out = [], pad = 16, n = DEV_ITEM_GROUPS.length;
  const w = (G.w - pad * 2) / n;
  for (let i = 0; i < n; i++) out.push({ x: G.x + pad + i * w, y: G.tabsY, w: w - 4, h: 22, i: i });
  return out;
}
function devItemRowRects(G){
  const out = [];
  for (let i = 0; i < G.n; i++)
    out.push({ x: G.x + 14, y: G.itemsY + i * G.rowH, w: G.w - 28, h: G.rowH - 2, i: i });
  return out;
}
function devItemQtyRects(G){
  const baseY = G.itemsY + G.n * G.rowH + 8;
  return {
    minus: { x: G.x + 14,          y: baseY, w: 26, h: 20 },
    value: { x: G.x + 44,          y: baseY, w: 46, h: 20 },
    plus:  { x: G.x + 94,          y: baseY, w: 26, h: 20 },
    fire:  { x: G.x + G.w - 148,   y: baseY, w: 134, h: 20 },
    baseY: baseY
  };
}
/* 把一件东西撒在脚边：走抽奖那套 gachaLoot（内部 lootSpot 自动摊开） */
function devItemDrop(c, n){
  if (!CFG.dev || state !== 'play' || !player) return 0;
  if (typeof gachaLoot !== 'function') return 0;
  const k = Math.max(1, n | 0);
  const before = loots.length;
  for (let i = 0; i < k; i++){ try { gachaLoot(Object.assign({}, c)); } catch (e){} }
  const got = loots.length - before;
  if (got){
    setMsg('刷物资：' + (devItemDef() ? devItemDef().name : '物资') + ' ×' + got, 1.6);
    if (typeof logInfo === 'function') logInfo('dev', '刷物资 · ' + (devItemDef() ? devItemDef().name : '?') + ' ×' + got);
  } else setMsg('刷不出来（先站在空地上）', 1.6);
  return got;
}
/* ---------------- 清理 ---------------- */
function devItemClearLoot(){
  const n = loots.length;
  loots.length = 0;
  return n;
}
function devItemClearCorpses(){
  /* 真正躺在地上的是 corpses（enemies 里的死者倒下时就被移走了），
     所以两个都要清：先清 corpses，再兜底清一遍"还在 enemies 里但已经死了的"。 */
  let n = 0;
  if (typeof corpses !== 'undefined' && corpses && corpses.length){ n += corpses.length; corpses.length = 0; }
  if (typeof enemies !== 'undefined' && enemies){
    for (let i = enemies.length - 1; i >= 0; i--){
      const e = enemies[i];
      if (e && (e.dead || (typeof e.hp === 'number' && e.hp <= 0))){ enemies.splice(i, 1); n++; }
    }
  }
  return n;
}
/* 清特效：把"画在场上但已经没人管"的东西一次扫干净。
   分四类，各自是不同数组，光清尸体是清不掉的：
     bullets     —— 在飞的子弹（敌人和玩家都在这个池里）
     tracers     —— 玩家打出去的弹道线
     fxParts     —— 血渣 / 火星 / 冲击环 / 白闪
     dmgNums     —— 鼠标落点上的伤害数字
     hitMarks    —— 准星上的命中标记
     blastRings  —— 火箭/手雷炸开的气浪圈 */
function devItemClearFx(){
  const cnt = { bullets:0, tracers:0, fx:0, dmg:0, marks:0, rings:0 };
  if (typeof bullets !== 'undefined' && bullets){ cnt.bullets = bullets.length; bullets.length = 0; }
  if (typeof tracers !== 'undefined' && tracers){ cnt.tracers = tracers.length; tracers.length = 0; }
  if (typeof fxParts !== 'undefined' && fxParts){ cnt.fx = fxParts.length; fxParts.length = 0; }
  if (typeof dmgNums !== 'undefined' && dmgNums){ cnt.dmg = dmgNums.length; dmgNums.length = 0; }
  if (typeof hitMarks !== 'undefined' && hitMarks){ cnt.marks = hitMarks.length; hitMarks.length = 0; }
  if (typeof blastRings !== 'undefined' && blastRings){ cnt.rings = blastRings.length; blastRings.length = 0; }
  /* 画面上的"打中了"反馈也一起清：残影、震屏、白闪，否则清完还在抖一下 */
  if (typeof camShake !== 'undefined' && camShake) camShake.t = 0;
  if (typeof hitFlash !== 'undefined') hitFlash = 0;
  if (typeof hitStopT !== 'undefined') hitStopT = 0;
  if (typeof slowT !== 'undefined') slowT = 0;
  return cnt;
}

function devItemRunAct(act){
  if (act === 'clearLoot'){
    const n = devItemClearLoot();
    setMsg('清掉了地上 ' + n + ' 件道具', 1.6);
    if (typeof logInfo === 'function') logInfo('dev', '清空地上道具 · ' + n + ' 件');
    return n;
  }
  if (act === 'clearCorpse'){
    const n = devItemClearCorpses();
    setMsg('清掉了 ' + n + ' 具尸体', 1.6);
    if (typeof logInfo === 'function') logInfo('dev', '清空尸体 · ' + n + ' 具');
    return n;
  }
  if (act === 'clearFx'){
    const c = devItemClearFx();
    const n = c.bullets + c.tracers + c.fx + c.dmg + c.marks + c.rings;
    setMsg('清掉了 ' + n + ' 个特效（子弹 ' + c.bullets + ' · 弹道 ' + c.tracers + ' · 粒子 ' + c.fx + ' · 数字 ' + c.dmg + '）', 2.2);
    if (typeof logInfo === 'function') logInfo('dev', '清空特效 · ' + JSON.stringify(c));
    return n;
  }
  if (act === 'clearAll'){
    const a1 = devItemClearLoot(), a2 = devItemClearCorpses(), a3 = devItemClearFx();
    const n3 = a3.bullets + a3.tracers + a3.fx + a3.dmg + a3.marks + a3.rings;
    setMsg('清掉了 ' + a1 + ' 件道具、' + a2 + ' 具尸体、' + n3 + ' 个特效', 2.2);
    if (typeof logInfo === 'function') logInfo('dev', '清空道具+尸体+特效 · ' + a1 + ' / ' + a2 + ' / ' + n3);
    return a1 + a2 + n3;
  }
  return 0;
}
function devItemFire(){
  const it = devItemDef();
  if (!it) return 0;
  if (it.act) return devItemRunAct(it.act);
  return devItemDrop(it.c, devItemQty);
}
function devItemClick(mx, my){
  if (!CFG.dev || !devItemOpen) return false;
  const G = devItemPanelGeom();
  const inPanel = mx > G.x && mx < G.x + G.w && my > G.y && my < G.y + G.h;
  if (!inPanel){ devItemOpen = false; return false; }
  for (const t of devItemTabRects(G))
    if (mx >= t.x && mx <= t.x + t.w && my >= t.y && my <= t.y + t.h){
      devItemGroup = t.i; devItemSel = 0; return true;
    }
  for (const r of devItemRowRects(G))
    if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h){
      devItemSel = r.i; devItemFire(); return true;
    }
  const Q = devItemQtyRects(G);
  const _actIt = devItemDef();
  const _isActClick = !!(_actIt && _actIt.act);
  if (!_isActClick && mx >= Q.minus.x && mx <= Q.minus.x + Q.minus.w && my >= Q.minus.y && my <= Q.minus.y + Q.minus.h){ devItemQtyStep(-1); return true; }
  if (!_isActClick && mx >= Q.plus.x  && mx <= Q.plus.x  + Q.plus.w  && my >= Q.plus.y  && my <= Q.plus.y  + Q.plus.h){  devItemQtyStep(1);  return true; }
  if (mx >= Q.fire.x  && mx <= Q.fire.x  + Q.fire.w  && my >= Q.fire.y  && my <= Q.fire.y  + Q.fire.h){  devItemFire();      return true; }
  return true;
}
function drawDevItemPanel(){
  if (!CFG.dev || !devItemOpen) return;
  const G = devItemPanelGeom();
  const g = devItemGroupDef();
  const Q = devItemQtyRects(G);
  ctx.save();
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(10,14,20,0.95)';
  ctx.strokeStyle = 'rgba(255,196,120,0.55)';
  ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.roundRect(G.x, G.y, G.w, G.h, 12); ctx.fill(); ctx.stroke();

  ctx.fillStyle = '#ffcf8a';
  ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
  ctx.fillText('刷物资', G.x + 18, G.y + 26);
  ctx.textAlign = 'right';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#8fa0b4';
  ctx.fillText('V / Esc 关闭', G.x + G.w - 18, G.y + 26);

  /* 分组标签 */
  ctx.textAlign = 'center';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  for (const t of devItemTabRects(G)){
    const on = t.i === devItemGroup;
    ctx.fillStyle = on ? 'rgba(255,196,120,0.22)' : 'rgba(255,255,255,0.05)';
    ctx.beginPath(); ctx.roundRect(t.x, t.y, t.w, t.h, 6); ctx.fill();
    ctx.fillStyle = on ? '#ffcf8a' : '#93a3b4';
    ctx.fillText(DEV_ITEM_GROUPS[t.i].name, t.x + t.w / 2, t.y + 15);
  }

  /* 条目 */
  ctx.textAlign = 'left';
  for (const r of devItemRowRects(G)){
    const on = r.i === devItemSel;
    if (on){
      ctx.fillStyle = 'rgba(255,196,120,0.14)';
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 5); ctx.fill();
      ctx.strokeStyle = 'rgba(255,196,120,0.55)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 5); ctx.stroke();
    }
    const it = g.items[r.i];
    if (!it) continue;
    ctx.fillStyle = on ? '#ffe6c0' : '#c8d3de';
    ctx.font = (on ? 'bold ' : '') + '12px "Microsoft YaHei",sans-serif';
    ctx.fillText((r.i + 1) + '. ' + it.name, r.x + 10, r.y + 16);
  }

  /* 数量 + 投放 */
  ctx.fillStyle = 'rgba(255,255,255,0.05)';
  ctx.beginPath(); ctx.roundRect(Q.minus.x, Q.minus.y, Q.minus.w, Q.minus.h, 5); ctx.fill();
  ctx.beginPath(); ctx.roundRect(Q.plus.x,  Q.plus.y,  Q.plus.w,  Q.plus.h, 5); ctx.fill();
  ctx.textAlign = 'center';
  ctx.fillStyle = '#c8d3de'; ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('−', Q.minus.x + Q.minus.w / 2, Q.minus.y + 15);
  ctx.fillText('+', Q.plus.x + Q.plus.w / 2, Q.plus.y + 15);
  const _isAct = !!(devItemDef() && devItemDef().act);
  ctx.fillStyle = _isAct ? '#7f8a96' : '#ffe6c0';
  ctx.fillText(_isAct ? '一次清空' : ('×' + devItemQty), Q.value.x + Q.value.w / 2, Q.value.y + 15);

  ctx.fillStyle = 'rgba(255,196,120,0.24)';
  ctx.beginPath(); ctx.roundRect(Q.fire.x, Q.fire.y, Q.fire.w, Q.fire.h, 6); ctx.fill();
  ctx.fillStyle = '#ffcf8a';
  ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
  ctx.fillText('投放（Enter）', Q.fire.x + Q.fire.w / 2, Q.fire.y + 15);

  ctx.textAlign = 'left';
  ctx.fillStyle = '#8fa0b4';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillText('A/D 换分组 · W/S 选条目 · Z/X 数量 · Shift+V 一次全撒', G.x + 18, G.y + G.h - 10);
  ctx.restore();
}
