/* 战术计数器：进游戏里"感觉得到但不明显"的东西，先变成能数的数字。
   用法：F3 面板里看"本关累计"，或者控制台 tacStatLine() / tacStatRecent()。
   m37586：局内感受不出来 → 至少先确认它到底发生了没有。 */
var TAC_STAT = {
  snapPeek: 0,   /* 闪身枪：缩在掩体后太久了 / 你在换弹 / 没看你 → 立刻探出去打一枪 */
  peek: 0,       /* 普通探头（含看不见时每隔 0.9 秒的扫视探头） */
  feint: 0,      /* 假动作：先探一下再缩回去 */
  suppress: 0,   /* 火力压制：不靠"看见"照着印象里的位置扫一串 */
  blindFire: 0,  /* 盲射：躲太久、看不见也打 */
  flank: 0,      /* 双人包抄：一次 plan = 一个架枪 + 一个侧翼 */
  corner: 0,     /* 架转角（丢视野后用最后已知位置压枪口） */
  bound: 0,      /* 交替掩护跃进：每交换一次角色算一次（m37743） */
  sweep: 0,      /* 细致搜查：搜完线索点后又补了几格"没看过的角"（m38314） */
  t0: 0,
  log: []
};
function tacStatReset(){
  if (typeof TAC_STAT === 'undefined' || !TAC_STAT) return;   /* 脚本顺序没轮到（或测试先跑了 reset）就别炸 */
  TAC_STAT.snapPeek = 0; TAC_STAT.peek = 0; TAC_STAT.feint = 0;
  TAC_STAT.suppress = 0; TAC_STAT.blindFire = 0; TAC_STAT.flank = 0; TAC_STAT.corner = 0;
  TAC_STAT.bound = 0; TAC_STAT.sweep = 0;
  TAC_STAT.t0 = (typeof uiT === 'number') ? uiT : 0;
  TAC_STAT.log.length = 0;
}
function tacBump(k){
  if (typeof TAC_STAT === 'undefined' || !TAC_STAT) return;
  if (TAC_STAT[k] === undefined) return;
  TAC_STAT[k]++;
  if (TAC_STAT.log.length > 47) TAC_STAT.log.shift();
  TAC_STAT.log.push({ k: k, t: (typeof uiT === 'number') ? uiT : 0 });
}
function tacStatLine(){
  const S = TAC_STAT;
  if (!S) return '';
  return '闪身 ' + S.snapPeek + ' · 探头 ' + S.peek + ' · 假动作 ' + S.feint +
         ' · 压制 ' + S.suppress + ' · 盲射 ' + S.blindFire +
         ' · 包抄 ' + S.flank + ' · 架角 ' + S.corner + ' · 跃进 ' + S.bound +
         ' · 翻角 ' + S.sweep;
}
function tacStatRecent(n){
  n = n || 6;
  if (typeof TAC_STAT === 'undefined' || !TAC_STAT) return '';
  const seg = TAC_STAT.log.slice(-n);
  const now = (typeof uiT === 'number') ? uiT : 0;
  return seg.map(function(x){ return x.k + '(' + (now - x.t).toFixed(1) + 's前)'; }).join(' · ');
}
