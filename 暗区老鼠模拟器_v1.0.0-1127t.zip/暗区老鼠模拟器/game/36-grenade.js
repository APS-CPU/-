/* ================= 手雷（m07148）=================
   按 3 拿在手里 → 按住左键掐引信 → 松手扔出去。
   扔出去是个有速度的实体：撞墙反弹（每次保留 55% 能量，2~3 次就停），
   引信走完就炸；手里掐到 0 就在自己脚下炸，伤害一点不打折。
   ================================================== */
/* 兼容旧消费者的只读别名；权威实体/爆炸数值统一在 data/items.js。 */
const NADE_FUSE       = FRAG_GRENADE_DEF.fuse;              /* 引信时长 */
const NADE_R          = FRAG_GRENADE_DEF.blastRadius;       /* 爆炸半径 */
const NADE_DMG_C      = FRAG_GRENADE_DEF.damageCenter;      /* 中心伤害 */
const NADE_DMG_E      = FRAG_GRENADE_DEF.damageEdge;        /* 边缘伤害 */
const NADE_DMG_POWER  = FRAG_GRENADE_DEF.damageFalloffPower;
const NADE_V0         = FRAG_GRENADE_DEF.throwSpeed;        /* 玩家投掷初速 */
const NADE_RAD        = FRAG_GRENADE_DEF.projectileRadius;  /* 弹体半径 */
const NADE_REST       = FRAG_GRENADE_DEF.bounceRetention;   /* 撞墙后速度保留比例 */
const NADE_FRIC       = FRAG_GRENADE_DEF.tangentFriction;   /* 反弹切向摩擦 */
const NADE_STOP       = FRAG_GRENADE_DEF.stopSpeed;         /* 静止阈值 */
const NADE_RECOVER    = 0.55;   /* 扔完的后摇（不能开枪） */
const NADE_RECOVER_K  = 0.70;   /* 后摇期间移速 */
const NADE_SUB        = FRAG_GRENADE_DEF.physicsSubstep;     /* 物理子步上限 */
const NADE_NOISE_BLAST = FRAG_GRENADE_DEF.noiseBlast;       /* 爆炸声纹倍率 */
const NADE_SHARD_N    = 42;     /* 一次爆炸飞出去多少块铁皮 */
const NADE_SHARD_CAP  = 220;    /* 场上最多留多少块（长时间连扔也不会堆爆） */

const sfxPin = ()=> beep(760, 0.05, 'square', 0.05, 1180);

function nadeCount(){
  if (!player) return 0;
  if (bagGridOn()) return bagCountOf('nade');
  return player.nades | 0;
}
function nadeTakeOne(){
  if (bagGridOn()){
    const it = bagOfKind('nade')[0];
    if (!it) return false;
    bagRemoveItem(it); bagRebuild();
    return true;
  }
  if ((player.nades | 0) <= 0) return false;
  player.nades = (player.nades | 0) - 1;
  return true;
}
function nadeDmgAt(d){
  /* 指数从 2.2 压到 1.7：以前 75px 外就只剩 40 点，现在还有 120 —— 碎片弹本来就不该"越远越挠痒" */
  const k = Math.pow(clamp(1 - d / NADE_R, 0, 1), NADE_DMG_POWER);
  return Math.round(NADE_DMG_E + (NADE_DMG_C - NADE_DMG_E) * k);
}

/* ================= 投掷物：手雷 / 烟雾弹 =================
   3 = 投掷物栏 和 枪 来回切（记着上次用哪种）
   Q = 手雷 ↔ 烟雾弹（只在投掷物栏里切）
   手上拿的是哪种看 player.hand：null / 'nade' / 'smoke' */
function smokeCount(){
  if (!player) return 0;
  if (bagGridOn()) return bagCountOf('smoke');
  return player.grenades | 0;
}
function throwNameOf(kind){ return kind === 'smoke' ? '烟雾弹' : '手雷'; }
function throwCountOf(kind){ return kind === 'smoke' ? smokeCount() : nadeCount(); }
function throwTakeOne(kind){
  if (kind === 'smoke'){
    if (bagGridOn()) return bagTakeSmoke();
    if ((player.grenades | 0) <= 0) return false;
    player.grenades = (player.grenades | 0) - 1;
    return true;
  }
  return nadeTakeOne();
}

/* 把某种投掷物拿到手上 */
function handHoldKind(kind){
  if (player) player.qPhase = 'throw';
  if (state !== 'play' || !player || player.hp <= 0) return false;
  kind = kind === 'smoke' ? 'smoke' : 'nade';
  const n = throwCountOf(kind);
  if (n <= 0){ setMsg('没有' + throwNameOf(kind), 1.1); return false; }
  player.hand = kind;
  player.handKind = kind;                 /* 下次按 3 还拿这一种 */
  player.heal = null;
  player.nadeCooking = false;
  player.nadeQueue = false;
  setMsg(throwNameOf(kind) + ' ×' + n + (kind === 'smoke'
      ? '　左键扔出去'
      : '　按住左键掐引信 · 松手扔出去'), 2.4);
  sfxClickGun(true);
  return true;
}

/* 收回袋子 / 换回枪 */
function handLower(){
  if (player) player.qPhase = 'gun';
  if (!player || !player.hand) return false;
  const was = player.hand;
  player.hand = null;
  player.nadeQueue = false;
  if (player.nadeCooking){
    player.nadeCooking = false;
    setMsg('引信掐了 · ' + throwNameOf(was) + '收回袋子', 1.4);
  } else setMsg(throwNameOf(was) + '放回袋子 · 换回枪', 1.2);
  sfxClickGun(true);
  return false;
}

/* 3：投掷物 / 枪 来回切 */
function nadeHoldToggle(){
  if (state !== 'play' || !player || player.hp <= 0) return false;
  if (player.hand) return handLower();
  const want = player.handKind === 'smoke' ? 'smoke' : 'nade';
  if (throwCountOf(want) > 0) return handHoldKind(want);
  /* 想要的那种没货，身上还有另一种就顺手换成另一种，别让 3 白按 */
  const other = want === 'nade' ? 'smoke' : 'nade';
  if (throwCountOf(other) > 0) return handHoldKind(other);
  setMsg('没有手雷，也没有烟雾弹', 1.2);
  return false;
}

/* Q：手上是投掷物 → 手雷 ↔ 烟雾弹；手上是枪 → 切到下一把枪（兼任换枪） */
function handSwapKind(){
  if (state !== 'play' || !player || player.hp <= 0) return false;
  if (!player.hand){
    /* 举着盾：Q 先把盾收了，然后回到"上一次的环节"——上次在投掷物环节就拿出投掷物，
       上次在枪的环节就换枪。不然盾会把 Q 吃掉一次，投掷物互换永远轮不到。 */
    if (typeof playerShieldUp === 'function' && playerShieldUp()){
      player.shieldRaised = false; mouse.fire = false; mouse.down = false;
      if (player.qPhase === 'throw'){
        const _k = throwCountOf('nade') > 0 ? 'nade' : (throwCountOf('smoke') > 0 ? 'smoke' : null);
        if (_k){ handHoldKind(_k); setMsg('收盾 · 拿出' + throwNameOf(_k), 1.2); return true; }
      }
      if (typeof switchWeapon === 'function'){ switchWeapon(1); return true; }
    }
    /* 拿着枪：Q 当换枪用（和 F 一个效果，方向朝前） */
    if (typeof switchWeapon === 'function'){ switchWeapon(1); return true; }
    setMsg('先按 ' + keyLabel(BINDS.throwToggle) + ' 拿出投掷物，再按 ' + keyLabel(BINDS.throwSwap) + ' 换手雷 / 烟雾弹', 1.4);
    return false;
  }
  const want = player.hand === 'smoke' ? 'nade' : 'smoke';
  if (throwCountOf(want) <= 0){
    setMsg('没有' + throwNameOf(want) + '　按 ' + keyLabel(BINDS.throwToggle) + ' 收回枪', 1.2);
    return false;
  }
  return handHoldKind(want);
}

/* 手上是烟雾弹时按左键：扔出去（烟雾弹不掐引信，落地就冒烟） */
function handThrowSmoke(){
  if (!player || player.hand !== 'smoke') return false;
  if (smokeCount() <= 0){ player.hand = null; setMsg('没有烟雾弹', 1.0); return false; }
  throwGrenade();
  if (smokeCount() <= 0){ player.hand = null; player.nadeQueue = false; }
  else setMsg('烟雾弹 ×' + smokeCount(), 0.8);
  return true;
}
/* 按住：开始烧引信 */
function nadeCookStart(){
  if (!player || player.hand !== 'nade') return false;
  if (player.nadeCooking) return false;
  if ((player.throwCd || 0) > 0){
    /* 后摇还没走完：这一下不白按 —— 记一笔，后摇一结束立刻把下一颗扔出去。
       频繁丢雷时就不用等那 0.55 秒再补一下鼠标，更不用重新按 3。 */
    player.nadeQueue = true;
    setMsg('下一个马上扔', 0.5);
    return false;
  }
  if (nadeCount() <= 0){ setMsg('没有手雷', 1.0); player.hand = null; return false; }
  player.nadeCooking = true;
  player.nadeFuseLeft = NADE_FUSE;
  player.heal = null;
  if (!(typeof sfxNadePin === 'function' && sfxNadePin())) sfxPin();
  logInfo('nade', '开始掐引信');
  return true;
}
/* 松手：按剩余引信扔出去 */
/* 真的把一颗扔出去（松手 / 排队连投都走这里）。
   扔完如果袋子里还有，手上自动补下一颗（player.hand 保持 'nade'）——
   这样频繁丢雷不用反复按 3。 */
function nadeThrowAt(fuse){
  const tx = mouse.x + cam.x, ty = mouse.y + cam.y;
  let a = Math.atan2(ty - player.y, tx - player.x);
  if (!isFinite(a)) a = player.aim || 0;
  const raw = { x: player.x + Math.cos(a) * (player.r + 6),
                y: player.y + Math.sin(a) * (player.r + 6) };
  const L = cur();
  const sp = safeSpot(L, raw, NADE_RAD + 2);
  /* 贴窗投掷时从窗前开始飞，交给物理碰撞处理。 */
  const touchesGlass = L.walls.some(w=>w.glass && !w.dead &&
    navSweptCircleHitsRect(player.x,player.y,sp.x,sp.y,NADE_RAD,w));
  const start = touchesGlass ? player : sp;
  nades.push({ x: start.x, y: start.y,
               vx: Math.cos(a) * NADE_V0, vy: Math.sin(a) * NADE_V0,
               fuse: fuse, age: 0, spin: 0, rest: false, by: player, sndT: 0 });
  nadeTakeOne();
  player.throwCd = NADE_RECOVER;
  player.aim = a;
  /* 还有雷就继续握在手上，一颗不剩才放下 */
  if (nadeCount() <= 0){ player.hand = null; player.nadeQueue = false; }
  sfxThrow();
  return fuse;
}
function nadeCookRelease(){
  if (!player || !player.nadeCooking) return false;
  if (player.hand !== 'nade'){ player.nadeCooking = false; return false; }
  player.nadeCooking = false;
  const fuse = nadeThrowAt(Math.max(0.12, player.nadeFuseLeft || NADE_FUSE));
  setMsg('手雷扔出去了 · 引信 ' + fuse.toFixed(1) + ' 秒', 1.5);
  logInfo('nade', '扔出手雷 · 引信 ' + fuse.toFixed(1) + 's · 剩 ' + nadeCount());
  return true;
}

/* ---------- 躲雷：场上有雷在自己脚边，就往反方向退 ----------
   以前没有任何"看到雷要躲"的逻辑：谁扔的雷落在哪，旁边的人就站在那看它炸，
   于是自己队友的雷一落地，一排人站着等爆炸 —— 表现就是"AI 在排队自杀"。
   这里只做位置修正（不走寻路，避免和战术状态机抢控制权）：
   离得越近退得越快，被墙挡住就沿切线找一条能退的方向。 */
function nadeNearestDanger(x, y, extra){
  let best = null, bestD = Infinity;
  if (typeof nades === 'undefined' || !nades) return null;
  for (const n of nades){
    if (!n || n.gone) continue;
    const rr = NADE_R + (extra || 0);
    const d = dist(x, y, n.x, n.y);
    if (d > rr + 30) continue;
    if (d < bestD){ best = n; bestD = d; }
  }
  return best ? { n: best, d: bestD } : null;
}
function nadeDodgeTick(dt){
  const L = cur();
  for (const e of enemies){
    if (!e || e.dead || e.gone) continue;
    if ((e.nadeDeafT || 0) > 0) e.nadeDeafT = Math.max(0, e.nadeDeafT - dt);
    if ((e.nadeBarkT || 0) > 0) e.nadeBarkT = Math.max(0, e.nadeBarkT - dt);
    const previous = e.nadeDodgeThreat;
    if (!nades.length && !previous && !e.nadeDodgeEnded) continue;
    if (enemyType(e).static || e.towerOn || e._dying){
      e.nadeDodgeThreat = e.nadeDodgeEnded = null;
      continue;
    }
    const radius = e.r || 13;
    const near = nades.length ? nadeNearestDanger(e.x, e.y, radius) : null;
    const previousDistance = previous ? dist(e.x, e.y, previous.x, previous.y) : Infinity;
    const holdingClear = !near && previousDistance <= NADE_R + radius + 60 && nades.includes(previous);
    e.nadeDodgeThreat = near?.n || (holdingClear ? previous : null);
    // 爆炸声在帧末投递，保留本帧刚结束躲避的雷以识别声源。
    e.nadeDodgeEnded = previous !== e.nadeDodgeThreat ? previous : null;
    if (!e.nadeDodgeThreat && previous && e.lookT > 0 && e.lastKnown){
      const clue = e.lastKnown;
      if (dist(e.x, e.y, clue.x, clue.y) >= 26 || !clearWalkLine(L, e.x, e.y, clue.x, clue.y)) e.lookT = 0;
    }
    if (!near) continue;
    const n = near.n;
    const d = Math.max(1, near.d);
    const k = 1 - clamp(d / (NADE_R + (e.r || 13)), 0, 1);
    const spd = 70 + 170 * k;                 /* 离得越近跑得越快 */
    const step = spd * dt;
    let ux = (e.x - n.x) / d, uy = (e.y - n.y) / d;
    if (!isFinite(ux) || (Math.abs(ux) < 1e-6 && Math.abs(uy) < 1e-6)){
      ux = Math.cos(e.ang || 0); uy = Math.sin(e.ang || 0);
    }
    /* 正后方被墙挡住时，沿 ±45° / ±90° 试一个能退的方向 */
    let moved = false;
    for (const rot of [0, 0.7, -0.7, 1.35, -1.35]){
      const cs = Math.cos(rot), sn = Math.sin(rot);
      const vx = ux * cs - uy * sn, vy = ux * sn + uy * cs;
      const nx = e.x + vx * step, ny = e.y + vy * step;
      if (nx < 14 || ny < 14 || nx > L.w - 14 || ny > L.h - 14) continue;
      if (navBlockedAt(L, nx, ny)) continue;
      e.x = nx; e.y = ny; moved = true; break;
    }
    if (!moved) continue;
    // 撤出去的位移不计作调查路线卡住。
    if (!previous){ e.chk = null; e.chaseRef = null; e.stuckT = 0; }
    if (d < NADE_R * 0.55 && (e.nadeBarkT || 0) <= 0){
      e.nadeBarkT = 3.2;
      if (typeof setBark === 'function') setBark(e, '雷！散开！', 1.2, 2);
    }
  }
}

const _GRENADE_AREA_PERMISSION_REQUEST={source:null,target:null};
const _GRENADE_AREA_PERMISSION_RESULT={};
function grenadeAreaPermission(source,target){
  _GRENADE_AREA_PERMISSION_REQUEST.source=source;
  _GRENADE_AREA_PERMISSION_REQUEST.target=target;
  return CombatQuery.areaPermission(_GRENADE_AREA_PERMISSION_REQUEST,_GRENADE_AREA_PERMISSION_RESULT).allowed;
}

/* 爆炸：半径 150 / 中心 120 / 边缘 20；自己踩上去吃满伤害 */
function nadeBlast(x, y, source){
  const screenFeedback=!(typeof mobaSuppressCombatFeedback==='function' && mobaSuppressCombatFeedback(source));
  const L = cur();
  /* 手雷炸响也会招人：以炸点为中心，比普通枪声远一点、比火箭筒近（3.0×hearR ≈ 960px） */
  gunNoise(NADE_NOISE_BLAST, x, y, source || player, 'blast');
  /* 手雷专属爆炸声（用户给的素材，只走这一条路径） */
  if (!(typeof sfxNadeBoom2 === 'function' && sfxNadeBoom2(x, y)) && typeof sfxBoom === 'function') sfxBoom(x, y);
  /* 炸到绊雷上的那颗手雷 = 直接引爆它（0.5 秒倒计时） */
  if (typeof tripFuseNear === 'function') tripFuseNear(x, y, 120);
  /* 拆墙：标准墙 340 血，这里给 0.55 倍 —— 两颗拆一面 */
  for (const w of L.walls){
    if (w.dead || !w.brk || w.glass) continue;
    const nx = clamp(x, w.x, w.x + w.w), ny = clamp(y, w.y, w.y + w.h);
    if (dist(x, y, nx, ny) > NADE_R * 0.85) continue;
    const hp0 = w.maxHp || 340;
    damageWall(w, Math.max(120, Math.round(hp0 * 0.55)), nx, ny,
               Math.atan2(y - ny, x - nx),source);
  }
  /* 玻璃：一圈全碎（先收集再碎，边遍历边删会漏） */
  {
    const gl = [];
    for (const w of L.walls){
      if (w.dead || !w.glass) continue;
      const nx = clamp(x, w.x, w.x + w.w), ny = clamp(y, w.y, w.y + w.h);
      if (dist(x, y, nx, ny) > NADE_R * 0.8) continue;
      if (blastBlocked(x, y, nx, ny)) continue;
      gl.push({ w: w, nx: nx, ny: ny });
    }
    for (const g of gl) shatterGlass(g.w, g.nx, g.ny, Math.atan2(y - g.ny, x - g.nx));
  }
  /* 门：木门/铁门一颗就烂 */
  if (typeof doors !== 'undefined' && doors.length){
    for (const d of doors){
      if (d.broken || !doorSolid(d)) continue;
      const nx = clamp(x, d.x, d.x + d.w), ny = clamp(y, d.y, d.y + d.h);
      if (dist(x, y, nx, ny) > NADE_R * 0.8) continue;
      if (blastBlocked(x, y, nx, ny)) continue;
      damageDoor(d, Math.max(160, Math.round((d.maxHp || 220) * 1.25)), nx, ny,
                 Math.atan2(ny - y, nx - x), false);
    }
  }
  /* 铁丝网 */
  if (typeof wires !== 'undefined' && wires.length){
    for (const w of wires){
      if (w.dead) continue;
      const nx = clamp(x, w.x, w.x + w.w), ny = clamp(y, w.y, w.y + w.h);
      if (dist(x, y, nx, ny) > NADE_R * 0.8) continue;
      if (blastBlocked(x, y, nx, ny)) continue;
      damageWire(w, 260, nx, ny);
    }
  }
  /* 玩家：自己扔的也不打折 */
  if (player && player.hp > 0 && !player.god && grenadeAreaPermission(source,player)){
    const d = dist(x, y, player.x, player.y);
    if (d <= NADE_R && !blastBlocked(x, y, player.x, player.y)){
      const k = Math.pow(clamp(1 - d / NADE_R, 0, 1), 1.6);
      const dmg = Math.max(1, Math.round(nadeDmgAt(d) * blastCoverFactor(x, y, player.x, player.y)));
      player.hp -= absorbArmor(dmg, 'blast');
      hurtNum(dmg);
      player.flash = 1; hitFlash = 1; camShake = Math.max(camShake, 0.9);
      /* 爆炸滤镜：会浮动、会散开的那层暖色 */
      if (typeof blastFilterStart === 'function') blastFilterStart(x, y, k);
      player.stunT = Math.max(player.stunT || 0, 0.6 + 1.4 * k);
      visionBlind = Math.max(visionBlind, 0.5 * k);
      visionBlur = Math.max(visionBlur, 0.7 + 0.3 * k);
      visionBlurHold = Math.max(visionBlurHold, 1.2 + 3.4 * k);
      const kx = (player.x - x) / Math.max(1, d), ky = (player.y - y) / Math.max(1, d);
      const imp = 150 + 540 * k;
      player.kickX = (player.kickX || 0) + kx * imp;
      player.kickY = (player.kickY || 0) + ky * imp;
      tinStart(k);
      stOnHurt(dmg, 'blast');
      stBleedAdd(1);
      if (player.hp <= 0) markDeath('blast', (source && (source.rocketTurret || source.type)) ? source : null,
                                    dmg, Math.atan2(player.y - y, player.x - x));
      logWarn('hurt', '吃手雷 · -' + dmg + ' HP · 剩 ' + Math.max(0, Math.round(player.hp)));
      sfxHurt();
    }
  }
  /* 运兵车 */
  if (typeof trucks !== 'undefined' && trucks){
    for (const t of trucks){
      if (!t || t.tstate === 'gone' || t.wreck) continue;
      const d = dist(x, y, t.x, t.y);
      const tp = Math.max(0, d - (t.r || 40) * 0.6);
      if (tp > NADE_R) continue;
      if (blastBlocked(x, y, t.x, t.y)) continue;
      const dmg = Math.max(1, Math.round(nadeDmgAt(tp) * 3.0 * blastCoverFactor(x, y, t.x, t.y)));
      damageTruck(t, dmg, Math.atan2(t.y - y, t.x - x));
    }
  }
  /* 敌人 */
  if (typeof enemies !== 'undefined' && enemies){
    for (const e of enemies.slice()){
      if (!e || e.dead) continue;
      /* 自己扔的雷不炸自己：落点虽然已经推到 selfR 外，但爆炸半径之外还有溅射判定 */
      if (e === source) continue;
      /* 同阵营的雷不炸自己人：以前 A 的雷会把 A 的队友一排炸死，
         再加上他们不会躲队友的雷，看着就是"排队自杀"。跨阵营照旧全额。 */
      if (typeof combatFaction === 'function' && source &&
          combatFaction(e) === combatFaction(source)) continue;
      if (!grenadeAreaPermission(source,e)) continue;
      const d = dist(x, y, e.x, e.y);
      if (d > NADE_R) continue;
      if (blastBlocked(x, y, e.x, e.y)) continue;
      const ek = Math.pow(clamp(1 - d / NADE_R, 0, 1), 1.6);
      const ex = (e.x - x) / Math.max(1, d), ey = (e.y - y) / Math.max(1, d);
      const ep = 10 + 34 * ek;
      e.x += ex * ep; e.y += ey * ep;
      if (L && L.walls) for (const w of collisionWalls(L,e.x,e.y,e.r)) pushOutCircle(e, e.r, w);
      if (typeof trucks !== 'undefined') for (const t of trucks) if (t.solid) pushOutTruckCircle(e, t);
      e.x = clamp(e.x, 14, L.w - 14); e.y = clamp(e.y, 14, L.h - 14);
      const dmg = Math.max(1, Math.round(nadeDmgAt(d) * blastCoverFactor(x, y, e.x, e.y)));
      e.hp -= dmg;
      if(typeof factionNoteDamage==='function')factionNoteDamage(e,source,dmg,'blast');
      if (e.hp <= 0 && typeof combatFinishNPC === 'function') combatFinishNPC(e,source,Math.atan2(e.y-y,e.x-x));
      else if (e.hp <= 0 && typeof killTestEnemy === 'function'){ arKillSrc = 'blast'; killTestEnemy(e); arKillSrc = 'bullet'; }
      else enemyStun(e, 0.6 + 1.9 * ek);
    }
  }
  /* 队友 */
  if (typeof allies !== 'undefined' && allies){
    for (const a of allies.slice()){
      const d = dist(x, y, a.x, a.y);
      if (d > NADE_R || blastBlocked(x, y, a.x, a.y) || !grenadeAreaPermission(source,a)) continue;
      companionDamage(a, Math.max(1, Math.round(nadeDmgAt(d) * blastCoverFactor(x, y, a.x, a.y))),
                      source, 'blast', Math.atan2(a.y - y, a.x - x));
      if (!a.dead) enemyStun(a, 0.6 + 1.9 * Math.pow(clamp(1 - d / NADE_R, 0, 1), 1.6));
    }
  }
  // 桌子和不在墙表里的瓶罐都走装饰物伤害。先判遮挡，再统一结算。
  const decorHits=[];
  for(const d of decors){
    const w=d._w;
    if(d.dead||!w||w.dead||!(w.maxHp>0))continue;
    const nx=clamp(x,w.x,w.x+w.w),ny=clamp(y,w.y,w.y+w.h);
    const distance=dist(x,y,nx,ny);
    if(distance>NADE_R||blastBlocked(x,y,nx,ny,w))continue;
    decorHits.push({w,nx,ny,damage:Math.max(1,Math.round(nadeDmgAt(distance)*blastCoverFactor(x,y,nx,ny)))});
  }
  for(const {w,nx,ny,damage} of decorHits)
    damageDecor(w,damage,nx,ny,Math.atan2(ny-y,nx-x));
  /* 视觉 / 声音 */
  if (typeof bossBlastFx === 'function') bossBlastFx(x, y, NADE_R,screenFeedback);
  for (let i = 0; i < 20; i++){
    const ba = fxRand(0, TAU), bd = fxRand(0, NADE_R * 0.5);
    spawnPart(x + Math.cos(ba) * bd, y + Math.sin(ba) * bd, ba, fxRand(5, 44),
              fxRand(0.8, 1.8), 'bsmoke', fxRand(5, 11));
  }
  /* 铁皮碎片 + 一圈火星：这才是"碎片手雷"该有的样子 */
  nadeSpawnShards(x, y);
  for (let i = 0; i < 18; i++){
    spawnPart(x, y, fxRand(0, TAU), fxRand(420, 980), fxRand(0.18, 0.42), 'mspark', fxRand(1.1, 2.0));
  }
  scorchMarks.push({ x: x, y: y, r: NADE_R * 0.26, t: 0 });
  if(screenFeedback){
    fxFlash = Math.max(fxFlash, 0.7);
    camShake = Math.max(camShake, 1.0);
  }
  beep(62, 0.42, 'sawtooth', 0.24, 28);
  noiseBurst(0.5, 380, 1.0, 1.05);
  logWarn('nade', '手雷爆炸 · 半径 ' + NADE_R + ' · 中心 ' + NADE_DMG_C + ' / 外圈 ' + NADE_DMG_E);
}
