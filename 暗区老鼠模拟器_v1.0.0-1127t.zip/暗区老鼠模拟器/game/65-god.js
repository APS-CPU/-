/* ================= 上帝模式（任何关卡都能随手开） =================
   四个开关：隐身 / 穿墙 / 无敌（不可被选中 + 不出声纹）/ 缩放。
   设计原则：
     · 不改任何关卡数据（不写进 LEVELS、不动 CFG），全部是"读的时候多问一句"；
     · 关掉之后一行都不多跑（每个钩子都是 `if (godXxx())` 短路）；
     · 只在 play 状态生效，回放/菜单/选卡界面不受影响。
   打开方式：**只**在开发者模式（O 面板 → 开发页）里点按钮，
   或者开发者模式下按 ` 键。没开开发者模式时，按键直接不响应、按钮也不显示，
   普通玩家正常游玩碰不到它。 */
const GOD = {
  on: false,
  invis: true,      /* 敌人看不见你（视野 + 追踪都不认你） */
  noclip: true,     /* 穿墙、穿门、穿车 */
  safe: true,       /* 无敌：不掉血、不流血 */
  silent: true,     /* 不出声纹：脚步、开枪、爆炸都不传 */
  zoomK: 1,         /* 缩放（0.5 = 拉远一倍看得更广，2 = 拉近） */
  zoomOn: false
};
const GOD_ZOOM_MIN = 0.35, GOD_ZOOM_MAX = 2.5;

/* 总闸：没开开发者模式，一切视为关 —— 就算误触 ` 也不会进上帝模式 */
function godAvailable(){
  return !!(typeof CFG !== 'undefined' && CFG && CFG.dev);
}
/* 老天爷：老代码里到处是 player.god（开发者无敌），载具撞击/破片/近战都查它。
   新模式的"无敌"必须同时点亮它，否则就是"局部上帝"——子弹打不动，车一撞照样掉血。 */
let _legacyGodPrev = null;
function godSyncLegacy(){
  if (typeof player === 'undefined' || !player) return;
  if (godSafe()){
    if (_legacyGodPrev === null) _legacyGodPrev = !!player.god;
    player.god = true;
  } else if (_legacyGodPrev !== null){
    player.god = _legacyGodPrev;
    _legacyGodPrev = null;
  }
}

function godOn(){ return godAvailable() && !!GOD.on; }
function godInvis(){ return godOn() && GOD.invis; }
function godNoclip(){ return godOn() && GOD.noclip; }
function godSafe(){ return godOn() && GOD.safe; }
function godSilent(){ return godOn() && GOD.silent; }
function godZoomK(){ return godOn() ? GOD.zoomK : 1; }

/* 整组开/关 */
function godSetOn(v){
  if (v && !godAvailable()){
    if (typeof setMsg === 'function') setMsg('上帝模式只在开发者模式里可用（O → 开发）', 2.0);
    return;
  }
  GOD.on = !!v;
  if (typeof syncGodBtns === 'function') syncGodBtns();
  godSyncLegacy();   /* 无敌开关同步到老的 player.god，载具/破片/近战才认 */
  if (typeof setMsg === 'function') setMsg(GOD.on ? '上帝模式：开（按 ` 关）' : '上帝模式：关', 1.8);
}

function godToggle(key){
  if (!GOD.on) godSetOn(true);
  if (key === 'on'){ godSetOn(false); return; }
  if (key === 'zoom'){ GOD.zoomOn = !GOD.zoomOn; if (!GOD.zoomOn) GOD.zoomK = 1; }
  else GOD[key] = !GOD[key];
  godSyncLegacy();
  if (typeof syncGodBtns === 'function') syncGodBtns();
  if (typeof setMsg === 'function'){
    const names = { invis:'隐身', noclip:'穿墙', safe:'无敌', silent:'不出声纹', zoom:'缩放' };
    setMsg((names[key] || key) + '：' + ((key === 'zoom' ? GOD.zoomOn : GOD[key]) ? '开' : '关'), 1.6);
  }
}

/* 直接设定倍率（数字输入框用）：超出范围就夹住，而不是报错 */
function godSetZoom(v){
  const n = Number(v);
  if (!isFinite(n) || n <= 0) return GOD.zoomK;
  if (!godOn()) godSetOn(true);
  GOD.zoomOn = true;
  GOD.zoomK = clamp(n, GOD_ZOOM_MIN, GOD_ZOOM_MAX);
  if (typeof syncGodBtns === 'function') syncGodBtns();
  return GOD.zoomK;
}

function godZoomStep(dir){
  if (!godOn()) godSetOn(true);
  GOD.zoomOn = true;
  GOD.zoomK = clamp(GOD.zoomK * (dir > 0 ? 1.18 : 1 / 1.18), GOD_ZOOM_MIN, GOD_ZOOM_MAX);
  if (typeof syncGodBtns === 'function') syncGodBtns();
  return GOD.zoomK;
}

/* 无敌的实现：每帧把血补回去 + 清流血/眩晕类掉血源。
   比在十几个 `player.hp -=` 的地方各加一句判断可靠得多（那些点分散在 6 个文件里）。 */
function godKeepAlive(){
  if (!godSafe() || typeof player === 'undefined' || !player) return;
  const maxHp = (typeof playerMaxHp === 'function') ? playerMaxHp()
              : ((typeof arenaMaxHp === 'function' && typeof ar !== 'undefined' && ar) ? arenaMaxHp() : (player.maxHp || 100));
  if (player.hp < maxHp) player.hp = maxHp;
  if (player.bleed) player.bleed = 0;
  if (player.burning) player.burning = 0;
}

/* O 面板开发页的按钮状态同步（按钮在 html 的 #godBox 里） */
function syncGodBtns(){
  const on = godOn();
  const set = (id, txt, active) => {
    const b = document.getElementById(id);
    if (!b) return;
    b.textContent = txt;
    b.style.borderColor = active ? 'rgba(140,240,190,0.9)' : '';
    b.style.color = active ? '#b9f5d4' : '';
    b.style.opacity = on ? '' : '0.45';
  };
  set('btnGodOn', '上帝模式：' + (on ? '开' : '关'), on);
  set('btnGodInvis', '隐身：' + (GOD.invis ? '开' : '关'), on && GOD.invis);
  set('btnGodNoclip', '穿墙：' + (GOD.noclip ? '开' : '关'), on && GOD.noclip);
  set('btnGodSafe', '无敌：' + (GOD.safe ? '开' : '关'), on && GOD.safe);
  set('btnGodSilent', '不出声纹：' + (GOD.silent ? '开' : '关'), on && GOD.silent);
  const num = document.getElementById('godZoomNum');
  if (num && document.activeElement !== num) num.value = GOD.zoomK.toFixed(2);
  set('btnGodZoomOut', '缩小 ×' + GOD.zoomK.toFixed(2), on && GOD.zoomOn);
  set('btnGodZoomIn', '放大', on && GOD.zoomOn);
}

function godSyncBoxVisible(){
  const box = document.getElementById('godBox');
  /* 只有"开发者模式已开 且 面板正停在开发页"才露出来，参数页不显示这一排 */
  const onDev = (typeof panelTab !== 'undefined') && panelTab === 'dev';
  if (box) box.style.display = (godAvailable() && onDev) ? '' : 'none';
}

/* 按钮接线（脚本最后加载，DOM 已经在） */
function godWire(){
  const bind = (id, fn) => { const b = document.getElementById(id); if (b) b.addEventListener('click', fn); };
  bind('btnGodOn', () => godSetOn(!GOD.on));
  bind('btnGodInvis', () => godToggle('invis'));
  bind('btnGodNoclip', () => godToggle('noclip'));
  bind('btnGodSafe', () => godToggle('safe'));
  bind('btnGodSilent', () => godToggle('silent'));
  bind('btnGodZoomOut', () => godZoomStep(-1));
  bind('btnGodZoomIn', () => godZoomStep(1));
  godSyncBoxVisible();
  if (typeof syncGodBtns === 'function') syncGodBtns();
  const num = document.getElementById('godZoomNum');
  if (num){
    const apply = () => { godSetZoom(num.value); num.value = GOD.zoomK.toFixed(2); };
    num.addEventListener('change', apply);
    num.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter'){ apply(); num.blur(); }
      ev.stopPropagation();          /* 别让数字键被局内按键吃掉 */
    });
  }
  syncGodBtns();
}
godWire();

/* 开关用 `（Backquote）：F8 早被"输入审计面板"占了，F1/F3/F7/F9 也都有主。
   开着的时候 -/= 调远近。 */
window.addEventListener('keydown', (ev) => {
  if (!godAvailable()) return;            /* 没开开发者模式：这个键当不存在 */
  if (ev.code === 'Backquote'){
    if (typeof state !== 'undefined' && state !== 'play') return;
    ev.preventDefault();
    godSetOn(!GOD.on);
    return;
  }
  if (!godOn()) return;
  if (typeof state !== 'undefined' && state !== 'play') return;
  if (ev.code === 'Minus' || ev.code === 'NumpadSubtract'){ ev.preventDefault(); godZoomStep(-1); }
  else if (ev.code === 'Equal' || ev.code === 'NumpadAdd'){ ev.preventDefault(); godZoomStep(1); }
}, true);

/* 角标：开着的时候右上角挂一行，免得忘了自己还开着 */
function drawGodTag(){
  if (!godOn()) return;
  const on = [];
  if (GOD.invis) on.push('隐身');
  if (GOD.noclip) on.push('穿墙');
  if (GOD.safe) on.push('无敌');
  if (GOD.silent) on.push('静默');
  if (GOD.zoomOn) on.push('×' + GOD.zoomK.toFixed(2));
  ctx.save();
  ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'right';
  ctx.fillStyle = 'rgba(150,240,200,0.9)';
  ctx.fillText('上帝模式 · ' + (on.join(' / ') || '无'), W - 18, 54);
  ctx.restore();
}
