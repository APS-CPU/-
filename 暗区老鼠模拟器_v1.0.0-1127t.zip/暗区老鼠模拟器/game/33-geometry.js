/* 腰高的东西（木箱、桌子）挡不挡视线，取决于"谁在看"：
   玩家站着能看过去（skipLow=true）；敌人照样被挡（默认）。 */
function lowSight(w){ return !!(w && (w.decor || w.sight === 'low')); }
function losBlocked(x1,y1,x2,y2,skipDoors,skipLow,ignoreWall){
  /* 玻璃透明：挡不住视线，但子弹会把它打碎（rayToWall 照旧算它）。
     skipDoors：子弹的命中判定要传 true（门挡视线、挡人，但挡不住子弹） */
  /* 矮家具（桌/柜这类 decor 代理墙）挡人、挡子弹，但挡不住视线：
     一个桌子的高度，站着的人一眼就看过去了。 */
  /* 宽相位：视线也走 256px 的墙格索引（和射线同一套），
     否则大图上每只敌人每次视线判定都要扫完整张 walls —— 四倍面积下这是最贵的一项。 */
  const _L = cur();
  const _dx = x2 - x1, _dy = y2 - y1;
  const _len = Math.hypot(_dx, _dy);
  const _cands = _len < 0.01 ? _L.walls : rayWallCandidates(_L, x1, y1, _dx / _len, _dy / _len, _len);
  for (let i = 0; i < _cands.length; i++){
    const w = _cands[i];
    if (w === ignoreWall || w.glass) continue;
    if (skipLow && lowSight(w)) continue;
    if (segHitsRect(x1,y1,x2,y2,w)) return true;
  }
  if (truckOcclSeg(x1, y1, x2, y2)) return true;   /* 车壳也是实体：残骸能挡视线 */
  if (!skipDoors) for (const d of doors) if (doorSolid(d) && segHitsRect(x1,y1,x2,y2,d)) return true;
  return false;
}

function pushOutCircle(p, r, rect){
  const cx = clamp(p.x, rect.x, rect.x+rect.w);
  const cy = clamp(p.y, rect.y, rect.y+rect.h);
  let dx = p.x-cx, dy = p.y-cy;
  const d2 = dx*dx+dy*dy;
  if (d2 >= r*r) return false;
  if (d2 > 1e-6){
    const d = Math.sqrt(d2), k = (r-d)/d;
    p.x += dx*k; p.y += dy*k;
  } else {
    const l = p.x-rect.x, rr = rect.x+rect.w-p.x;
    const t = p.y-rect.y, b = rect.y+rect.h-p.y;
    const m = Math.min(l,rr,t,b);
    if (m===l) p.x = rect.x-r;
    else if (m===rr) p.x = rect.x+rect.w+r;
    else if (m===t) p.y = rect.y-r;
    else p.y = rect.y+rect.h+r;
  }
  return true;
}

/* M2.1 几何查询门面。
   契约：
   - 坐标和尺寸均为世界像素；矩形为 {x,y,w,h}。
   - 所有查询均为纯读取，不修改、缓存或保留传入对象。
   - segmentHitsRect 返回 bool；rayEnterRect 返回进入距离，未命中返回 -1。
   - 当前只委托旧算法，保留原 epsilon、边界和退化线段语义。 */
var CollisionQuery = Object.freeze({
  version: 1,
  segmentHitsRect: function(x1, y1, x2, y2, rect){
    return segHitsRect(x1, y1, x2, y2, rect);
  },
  rayEnterRect: function(ox, oy, dx, dy, rect, maxLen){
    return rayEnter(ox, oy, dx, dy, rect, maxLen);
  }
});

