/* ---------- 街区图：把外圈从"均匀撒点"改成"几个村子 + 连接路" ----------
   用户 m12356 说的"模板感"，根因不是矩形边界，而是外圈房子按统一网格/均匀随机铺，
   没有"这里是一村、那里是一片林子"的区别。这一版把岛划成 5~7 个地块：
     · 每块有自己的中心、半径、类型（郊野/住宅/工业/公共）；
     · 类型决定房子的种类配比与密度；
     · 地块之间自然留出缓冲（房子只长在自己半径内，半径之间有空隙）；
     · 每个地块用一条 L 形土路接到核心城区的边上（路只是画在地上，不进寻路）。
   ------------------------------------------------------------------ */

const DZ_DISTRICTS_ON = false;   /* 用户 m12734：房子改回均匀撒，地块这条路先留着 */

const DZ_DIST_TYPES = [
  { key: 'rural',      name: '郊野', w: 3, density: 0.55,
    mix: ['small_house', 'small_house', 'two_room', 'kitchen_house', 'storage', 'workshop'] },
  { key: 'residential', name: '住宅区', w: 3, density: 1.0,
    mix: ['small_house', 'small_house', 'two_room', 'safehouse', 'bathroom_house', 'shop'] },
  { key: 'industrial', name: '工业区', w: 2, density: 0.85,
    mix: ['warehouse', 'workshop', 'depot', 'storage', 'big_house', 'big_house'] },
  { key: 'civic',      name: '公共区', w: 1, density: 0.8,
    mix: ['office', 'clinic', 'grand_hall', 'manor', 'safehouse'] }
];

function dzDistrictPickType(){
  let total = 0;
  for (const t of DZ_DIST_TYPES) total += t.w;
  let r = arenaRandom() * total;
  for (const t of DZ_DIST_TYPES){ r -= t.w; if (r <= 0) return t; }
  return DZ_DIST_TYPES[0];
}

/* 在岛上规划地块：核心城区的四角外找空地，彼此至少隔 MIN_SEP */
function dzDistrictsPlan(L, coreRect){
  const ccx = coreRect.x + coreRect.w / 2, ccy = coreRect.y + coreRect.h / 2;
  const coreR = Math.max(coreRect.w, coreRect.h) / 2;
  const out = [];
  const MIN_SEP = 1150;
  const want = 5 + (arenaRandom() < 0.5 ? 1 : 0) + (arenaRandom() < 0.35 ? 1 : 0);
  let tries = 0;
  while (out.length < want && tries < want * 60){
    tries++;
    const px = rand(420, L.w - 420), py = rand(420, L.h - 420);
    if (typeof dzIsland !== 'undefined' && dzIsland && !dzOnLand(px, py, 460)) continue;
    /* 必须在核心城区之外：地块是"城外的村镇"，不是把老城区包进来 */
    if (Math.hypot(px - ccx, py - ccy) < coreR + 520) continue;
    let bad = false;
    for (const d of out){
      if (Math.hypot(px - d.x, py - d.y) < MIN_SEP){ bad = true; break; }
    }
    if (bad) continue;
    const t = dzDistrictPickType();
    out.push({ x: Math.round(px), y: Math.round(py), r: 340 + Math.round(arenaRandom() * 300),
               type: t.key, name: t.name, mix: t.mix, density: t.density });
  }
  return out;
}

/* L 形土路：从地块中心接到核心城区最近的边上（两段矩形，纯视觉） */
function dzDistrictsRoads(L, districts, coreRect){
  if (!L.roads) L.roads = [];
  const ROADW = 96;
  for (const d of districts){
    /* 目标点：核心矩形上离地块最近的那条边上的点 */
    const tx = Math.max(coreRect.x, Math.min(coreRect.x + coreRect.w, d.x));
    const ty = Math.max(coreRect.y, Math.min(coreRect.y + coreRect.h, d.y));
    /* 先横后竖（或反过来，看哪条更长），两段都贴着陆地 */
    const horizFirst = Math.abs(d.x - tx) >= Math.abs(d.y - ty);
    const segs = [];
    if (horizFirst){
      segs.push({ x: Math.min(d.x, tx), y: d.y - ROADW / 2, w: Math.abs(d.x - tx), h: ROADW });
      segs.push({ x: tx - ROADW / 2, y: Math.min(d.y, ty), w: ROADW, h: Math.abs(d.y - ty) });
    } else {
      segs.push({ x: d.x - ROADW / 2, y: Math.min(d.y, ty), w: ROADW, h: Math.abs(d.y - ty) });
      segs.push({ x: Math.min(d.x, tx), y: ty - ROADW / 2, w: Math.abs(d.x - tx), h: ROADW });
    }
    for (const sg of segs){
      if (sg.w < 40 || sg.h < 40) continue;
      /* 只保留整段都在陆地上的（跨海的那段就不要了） */
      let ok = true;
      for (let t = 0; t <= 1.0001 && ok; t += 0.2){
        const qx = sg.x + sg.w * t, qy = sg.y + sg.h * t;
        if (typeof dzOnLand === 'function' && !dzOnLand(qx, qy, 30)) ok = false;
      }
      if (ok) L.roads.push({ x: Math.round(sg.x), y: Math.round(sg.y), w: Math.round(sg.w), h: Math.round(sg.h), _dzDistrict: 1 });
    }
  }
}


/* ---------- 蛛网路：从主城区中心辐射出去、带弯曲、末端分叉 ----------
   用户 m12734：删掉横平竖直的长条，改成"从主城区向边缘辐射、随机弯曲、末端分叉"的蛛网。
   路只是画在地上（L.roadPaths，不进寻路、不当墙），所以弯曲不需要走 A*。 */
function dzRoadWeb(L, cx, cy){
  /* 关卡对象跨局复用：每次重来都要重新生成，不能沿用上一把的路 */
  L.roadPaths = [];
  if (!L.roads) L.roads = [];
  /* 把折线打成小方块塞进 L.roads：巡逻/哨位/沿路掩体都靠它找"路" */
  const stamp = (pts, w) => {
    for (let i = 0; i < pts.length - 1; i++){
      const x0 = pts[i].x, y0 = pts[i].y, x1 = pts[i + 1].x, y1 = pts[i + 1].y;
      const seg = Math.hypot(x1 - x0, y1 - y0);
      const steps = Math.max(1, Math.round(seg / 900));
      for (let k = 0; k < steps; k++){
        const t = k / steps;
        const px = x0 + (x1 - x0) * t, py = y0 + (y1 - y0) * t;
        L.roads.push({ x: Math.round(px - w / 2), y: Math.round(py - w / 2),
                       w: Math.round(w), h: Math.round(w), _noDraw: 1 });
      }
    }
  };
  const spokes = 7 + Math.floor(arenaRandom() * 4);       /* 7~10 条主辐射 */
  const maxLen = Math.max(L.w, L.h) * 0.62;
  for (let i = 0; i < spokes; i++){
    /* 起始角度均匀打散，再加抖动，避免"钟面"太正 */
    let ang = (i / spokes) * Math.PI * 2 + (arenaRandom() - 0.5) * 0.55;
    let x = cx + Math.cos(ang) * (260 + arenaRandom() * 240);
    let y = cy + Math.sin(ang) * (260 + arenaRandom() * 240);
    const pts = [{ x: x, y: y }];
    const len = maxLen * (0.45 + arenaRandom() * 0.55);
    let travelled = 0;
    let w = 86 + arenaRandom() * 18;
    while (travelled < len){
      const step = 190 + arenaRandom() * 170;
      /* 每段偏转 ±0.42 弧度 —— 弯，但不会打转 */
      ang += (arenaRandom() - 0.5) * 0.84;
      x += Math.cos(ang) * step; y += Math.sin(ang) * step;
      if (x < 80 || y < 80 || x > L.w - 80 || y > L.h - 80) break;
      pts.push({ x: x, y: y });
      travelled += step;
      w = Math.max(56, w - step * 0.02);                  /* 越往外越窄 */
      /* 中段有机会分叉出一条岔路 */
      if (pts.length === 3 && arenaRandom() < 0.75){
        const bang = ang + (arenaRandom() < 0.5 ? -1 : 1) * (0.7 + arenaRandom() * 0.5);
        let bx = x, by = y, ba = bang;
        const bpts = [{ x: bx, y: by }];
        const blen = len * (0.35 + arenaRandom() * 0.35);
        let bt = 0;
        while (bt < blen){
          const bs = 170 + arenaRandom() * 150;
          ba += (arenaRandom() - 0.5) * 0.7;
          bx += Math.cos(ba) * bs; by += Math.sin(ba) * bs;
          if (bx < 80 || by < 80 || bx > L.w - 80 || by > L.h - 80) break;
          bpts.push({ x: bx, y: by });
          bt += bs;
        }
        if (bpts.length > 1){
          const bw = Math.max(46, w - 10);
          L.roadPaths.push({ pts: bpts, w: bw });
          stamp(bpts, bw);
        }
      }
    }
    if (pts.length > 1){ L.roadPaths.push({ pts: pts, w: w }); stamp(pts, w); }
  }
}
