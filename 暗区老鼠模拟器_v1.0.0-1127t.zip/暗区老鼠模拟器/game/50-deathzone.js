/* ================= 死亡地带（6000×6000 围剿模式）=================
   和割草一样不写进 LEVELS，免得污染正式关卡列表。
   地形全部按"区域块"生成：打野 / 城区 / 军事重区 / 中心庄园。
   敌人不全是一次性刷满的，reset 之后由 dzPopulate 按区铺。 */
/* 边长可调：自查用 ?dz=1&sz=12000 会把它临时放大（四倍面积 = 边长 ×2），
   平时永远是 6000。改成 let 就是为了这个开关。 */
let DZ_W = 6000, DZ_H = 6000;
/* 随机图的种子与尺寸：dzSeed 一局一个（?seed= 可指定），dzRngActive 让生成阶段也走种子流。
   dzForceSide 是自查开关（?sz=），设了就不随机尺寸。 */
let dzSeed = 0, dzSeedUsed = 0, dzSideUsed = 6000, dzAreaUsed = 1;
let dzBoxPos = null;        /* 这一把黑匣子所在的保险箱中心（地图提示圈用它，而不是掉落物） */
let dzBoxTag = '';          /* 这一把黑匣子落在哪个区（只报区域，不报点），开场字幕与地图用 */
const DZ_BOX_HINT_R = 900;  /* 地图上提示圈的半径下限：给一片，不给一个点 */
let dzBoxHintR = 900;       /* 实际用的半径，按地图大小放大（大图不能只圈一小块） */
let dzRngActive = false, dzForceSide = 0, dzForceRandom = false;
let dzSeedFixed = false;   /* 种子是外部指定的（?seed= / 单测）才钉住，否则每局重新掷 */
/* 两张图：classic = 原来那张 6000² 手工图（默认，和以前逐像素一致）；
   random = 尺寸/位置/内容随种子变的新图。入口在娱乐模式里二选一。 */
let dzMapMode = 'classic';
const DZ_DESIGN = 6000;      /* 现有全部手工坐标都是按这个边长写的 */
const DZ_SIDE_MIN = 6000, DZ_SIDE_MAX = 14000, DZ_SIDE_STEP = 200;
let dzBoxPrev = -1;   /* 上一把黑匣子的保险箱下标（日志用） */
let dzBoxPrevKey = '';   /* 上一把黑匣子所在保险箱的坐标键：真正用来防连刷 */
let dzBoxSeq = 0;        /* 打过几把死亡地带：挑箱子时掺进来，避免同尺寸下永远同一只 */
const DZ_T = 40;
const DZ_ZONES = [
  { key:'manor',  name:'庄园',     x:2300, y:2450, w:1400, h:1100, danger:4 },
  { key:'mil',    name:'军事重区', x:2100, y:600,  w:1800, h:1600, danger:4 },
  { key:'citySW', name:'西南城区', x:700,  y:4100, w:1200, h:1200, danger:3 },
  { key:'citySE', name:'东南城区', x:4300, y:4200, w:1200, h:1200, danger:3 },
  { key:'cityNW', name:'西北城区', x:700,  y:900,  w:1200, h:1200, danger:3 }
];

/* 沿一条线铺墙，gaps 是"从起点算的偏移区间"，区间里是门洞（不铺墙） */
function dzSeg(L, x, y, len, dir, t, gaps){
  const gs = (gaps || []).slice().sort((a, b) => a[0] - b[0]);
  let at = 0;
  const put = (a, b) => {
    if (b - a < 24) return;
    if (dir === 'h') L.walls.push({ x:x + a, y:y, w:b - a, h:t });
    else             L.walls.push({ x:x, y:y + a, w:t, h:b - a });
  };
  for (const g of gs){
    const a = clamp(g[0], 0, len), b = clamp(g[1], 0, len);
    put(at, a); at = Math.max(at, b);
  }
  put(at, len);
}

/* 模板摆位：以前是写死坐标直接 push，两栋楼撞在一起就成了"嵌在一块、门被墙堵死"。
   现在先量出这栋楼的占地，跟已经摆下的房子和手写墙（庄园隔断、军区围墙）比一遍，
   撞了就沿着同一圈往外挪，一圈一圈撑到能塞下为止；实在塞不下就干脆不摆。 */
function dzTplSize(t, rot){
  const T = (typeof ROOM_TEMPLATES !== 'undefined') ? ROOM_TEMPLATES[t] : null;
  if (!T) return { w: 320, h: 240 };
  const swap = (rot === 90 || rot === 270);
  return { w: swap ? T.h : T.w, h: swap ? T.w : T.h };
}
function dzHitsBox(x0, y0, x1, y1, b){
  return x0 < b.x + b.w && x1 > b.x && y0 < b.y + b.h && y1 > b.y;
}
function dzPlace(L, t, x, y, rot){
  rot = rot || 0;
  const sz = dzTplSize(t, rot);
  /* 岛图：整栋房子要落在陆地上（留 40px 岸线余量），否则就换位置/放弃 */
  if (typeof dzIsland !== 'undefined' && dzIsland){
    const _c = dzPolyClamp(x + sz.w / 2, y + sz.h / 2, dzIsland.poly, 60);
    if (_c.moved){ x = Math.round(_c.x - sz.w / 2); y = Math.round(_c.y - sz.h / 2); }
    if (!dzOnLand(x + sz.w / 2, y + sz.h / 2, 40)) return false;
  }
  if (!L._dzFoot) L._dzFoot = [];
  const PAD = 44;
  for (let ring = 0; ring < 16; ring++){
    const step = ring * 70;
    const cands = [];
    if (ring === 0) cands.push([x, y]);
    else {
      for (let i = 0; i < 8; i++){
        const a = i * Math.PI / 4;
        cands.push([x + Math.cos(a) * step, y + Math.sin(a) * step]);
      }
    }
    for (const c of cands){
      const cx = Math.round(c[0]), cy = Math.round(c[1]);
      if (cx < 90 || cy < 90 || cx + sz.w > DZ_W - 90 || cy + sz.h > DZ_H - 90) continue;
      /* 岛图：这个候选位置落海就直接跳过（别再做一堆墙体相交测试） */
      if (typeof dzIsland !== 'undefined' && dzIsland && !dzOnLand(cx + sz.w / 2, cy + sz.h / 2, 34)) continue;
      const x0 = cx - PAD, y0 = cy - PAD, x1 = cx + sz.w + PAD, y1 = cy + sz.h + PAD;
      let bad = false;
      for (const f of L._dzFoot){ if (dzHitsBox(x0, y0, x1, y1, f)){ bad = true; break; } }
      if (!bad){
        for (const w of L.walls){
          if (w.rocketTurret) continue;                 /* 炮塔自己那一格不算 */
          if (dzHitsBox(x0, y0, x1, y1, w)){ bad = true; break; }
        }
      }
      if (bad) continue;
      L.placed.push({ t: t, x: cx, y: cy, rot: rot });
      L._dzFoot.push({ x: cx, y: cy, w: sz.w, h: sz.h });
      return true;
    }
  }
  return false;
}

/* 中心庄园：手写外墙 + 隔断，房间功能靠摆进去的模板和箱子体现 */
function dzBuildManor(L, x0, y0){
  const W = 1400, H = 1100, t = 26;
  dzSeg(L, x0, y0, W, 'h', t, [[600, 780]]);            /* 北墙 · 侧门 */
  dzSeg(L, x0, y0 + H - t, W, 'h', t, [[620, 800]]);    /* 南墙 · 正门 */
  /* 东西外墙各留一个 148px 的窗洞：玻璃就嵌在这里，打碎多一条枪线。
     以前玻璃是直接压在整面墙上的，墙没断开 —— 等于根本没这个入口。 */
  dzSeg(L, x0, y0, H, 'v', t, [[450, 598]]);
  dzSeg(L, x0 + W - t, y0, H, 'v', t, [[450, 598]]);
  /* 竖向隔断：三列（左列两间、中列三间、右列两间） */
  dzSeg(L, x0 + 470, y0, H, 'v', 18, [[150, 230], [520, 610], [880, 960]]);
  dzSeg(L, x0 + 930, y0, H, 'v', 18, [[80, 170], [520, 600], [900, 980]]);
  /* 横向隔断 */
  dzSeg(L, x0, y0 + 380, 470, 'h', 18, [[180, 280]]);
  dzSeg(L, x0 + 470, y0 + 380, W - 470, 'h', 18, [[160, 260]]);
  dzSeg(L, x0, y0 + 740, 470, 'h', 18, [[260, 350]]);
  /* 房间登记：这栋楼是手写隔断，没有人能"顺手"登记，只能在这儿按隔断算格子。
     竖向隔断在 x0+470 / x0+930（厚 18），横向隔断在 y0+380（左列还有 y0+740），
     外墙厚 26 —— 坐标全部取「内空区」，贴墙站位才不会被判成在屋外。
     以前这里只登记了一块「屋顶平台」，等于整栋庄园对人机是"没有房间"：
     进屋搜查、同屋判断、跨房手雷在那儿全都是退化成"屋里屋外没区别"。 */
  {
    const t = 26, w2 = 18;
    const lx0 = x0 + t, lx1 = x0 + 470, mx0 = x0 + 470 + w2, mx1 = x0 + 930, rx0 = x0 + 930 + w2, rx1 = x0 + W - t;
    const ty0 = y0 + t, ty1 = y0 + 380, my0 = y0 + 380 + w2, my1 = y0 + 740, by0 = y0 + 740 + w2, by1 = y0 + H - t;
    roomAdd(L, { x:lx0, y:ty0, w:lx1 - lx0, h:ty1 - ty0, building:0, name:'庄园 · 左前厅' });
    roomAdd(L, { x:lx0, y:my0, w:lx1 - lx0, h:my1 - my0, building:0, name:'庄园 · 左中厅' });
    roomAdd(L, { x:lx0, y:by0, w:lx1 - lx0, h:by1 - by0, building:0, name:'庄园 · 左后厅' });
    roomAdd(L, { x:mx0, y:ty0, w:mx1 - mx0, h:ty1 - ty0, building:0, name:'庄园 · 中前厅' });
    roomAdd(L, { x:mx0, y:my0, w:mx1 - mx0, h:by1 - my0, building:0, name:'庄园 · 中厅' });
    roomAdd(L, { x:rx0, y:ty0, w:rx1 - rx0, h:ty1 - ty0, building:0, name:'庄园 · 右前厅' });
    roomAdd(L, { x:rx0, y:my0, w:rx1 - rx0, h:by1 - my0, building:0, name:'庄园 · 右厅' });
    /* 屋顶平台（火箭炮塔位）叠在中前厅上：标 fallback 让真实房间优先命中 */
    roomAdd(L, { x:x0 + 620, y:y0 + 40, w:300, h:300, building:0, name:'屋顶平台', fallback:true });
  }
}

/* 打野的散装小房子：位置用固定种子，每次进图长一样，但不会重叠 */
/* 可破坏掩体：路边、门口、院子里塞箱子/挡板/矮墙。
   全部走 L.brk（initBreakables 会给它们配 hp、裂纹、分段），打了就碎，碎完变掩体残骸。 */
function dzCover(L){
  const dsz = (t) => {
    const d = (typeof COVER_DEF !== 'undefined' && COVER_DEF[t]) ? COVER_DEF[t] : null;
    return (d && d.sz) ? d.sz : [56, 56];
  };
  const hit = (x, y, w, h) => {
    for (const q of L.walls){
      if (q.dead) continue;
      if (x + w > q.x - 8 && x < q.x + q.w + 8 && y + h > q.y - 8 && y < q.y + q.h + 8) return true;
    }
    for (const q of L.brk){
      if (x + w > q.x - 8 && x < q.x + q.w + 8 && y + h > q.y - 8 && y < q.y + q.h + 8) return true;
    }
    return false;
  };
  const put = (t, x, y, rot) => {
    const sz = dsz(t);
    const w = rot ? sz[1] : sz[0], h = rot ? sz[0] : sz[1];
    x = Math.round(x); y = Math.round(y);
    if (x < 60 || y < 60 || x + w > L.w - 60 || y + h > L.h - 60) return false;
    if (hit(x, y, w, h)) return false;
    L.brk.push({ t: t, x: x, y: y, w: w, h: h });
    return true;
  };
  /* 1. 沿路：每 420~520px 一处"两箱一板"，拆开就是一条通道 */
  for (const r of (L.roads || [])){
    const horiz = r.w >= r.h;
    const len = horiz ? r.w : r.h;
    for (let d = 260; d < len - 260; d += 460){
      if (arenaRandom() < 0.22) continue;
      const jx = (arenaRandom() - 0.5) * 90, jy = (arenaRandom() - 0.5) * 70;
      if (horiz){
        const x = r.x + d + jx, y = r.y + r.h + 30 + jy;
        put('crate', x, y, 0);
        put('crate2', x + 84, y + 10, 0);
        put('panel', x - 16, y + 78, 0);
      } else {
        const x = r.x + r.w + 30 + jx, y = r.y + d + jy;
        put('crate', x, y, 0);
        put('crate2', x + 10, y + 84, 0);
        put('panel', x + 78, y - 16, 0);
      }
    }
  }
  /* 2. 三个城区：街心两组、每栋楼门口一组（能砸开当掩体，也能挡视线） */
  const camp = [
    [1000, 4600], [1500, 4300], [900, 1300], [1450, 1750], [4800, 4550], [5100, 4850]
  ];
  for (const c of camp){
    put('crate', c[0], c[1], 0);
    put('crate2', c[0] + 86, c[1] + 6, 0);
    put('crateAmmo', c[0] + 40, c[1] + 86, 0);
    put('panel', c[0] - 20, c[1] + 84, 0);
  }
  /* 长条武器箱：全图只放两处，都压在最凶的地方 —— 军械库门口、庄园车库。
     少是故意的：它是'这把枪终于能换了'的奖励，不是路边补给。放不下就往外挪几圈再试。 */
  {
    const spots = [
      [3140, 1010], [2560, 1520], [3560, 760],        /* 军事区：军械库门口、兵营2号前、仓库区 */
      [3560, 3320], [2760, 2620],                     /* 庄园：车库、书房侧 */
      [1180, 4780], [1380, 4220],                      /* 西南城区 */
      [4720, 4520],                                    /* 东南城区 */
      [920, 1320], [1520, 1780]                        /* 西北城区 */
    ];
    for (const sp of spots){
      let done = false;
      const OFF = [[0,0],[70,0],[-70,0],[0,70],[0,-70],[90,60],[-90,60],[90,-60],[-90,-60],
                   [150,0],[-150,0],[0,150],[0,-150],[190,120],[-190,120],[190,-120],[-190,-120],[250,0],[0,250]];
      for (let k = 0; k < OFF.length && !done; k++){
        done = put('crateWeap', sp[0] + OFF[k][0], sp[1] + OFF[k][1], 0);
      }
    }
  }

  /* 3. 庄园院里与军事区门口：木箱做临时工事 */
  const yards = [
    [2500, 2760], [2620, 2760], [3380, 2760], [3500, 2760],
    [2500, 3320], [2620, 3320], [3380, 3320],
    [2200, 2000], [2300, 2000], [3760, 2000], [3860, 2000],
    [2900, 2120], [3080, 2120]
  ];
  for (let i = 0; i < yards.length; i++){
    const y = yards[i];
    put(i % 3 === 0 ? 'crateAmmo' : 'crate', y[0], y[1], 0);
    if (i % 3 === 0) put('crateGear', y[0] + 60, y[1] + 4, 0);
  }
  /* 3.5 军事区西墙的"被木板钉死侧门"：两块木板正好塞住 1040~1160 的缺口。
      `hit()` 有 8px 外扩，所以从 1046 起、每块 52，最后一块到 1150，缺口还剩 10px 走不过人。 */
  put('crate2', 2098, 1049, 0);
  put('crate2', 2098, 1111, 0);
  put('crate2', 2098, 1173, 0);

  /* 4. 玻璃：几个院墙缺口，打一枪就碎，碎了多一条穿墙的枪线 */
  const gl = [
    [2300, 2908, 26, 132], [3748, 2908, 26, 132],   /* 庄园东西外墙的窗 */
    [2100, 1516, 26, 148], [3874, 1516, 26, 148]    /* 军事区东西围墙的窗 */
  ];
  for (const g of gl){
    if (hit(g[0], g[1], g[2], g[3])) continue;
    L.glass.push({ x: g[0], y: g[1], w: g[2], h: g[3] });
  }
  dzScenery(L);
}

/* ============================================================
   死亡地带的布景（第 63 轮：把 data/decor.js 与 data/covers.js 的新东西挑几样用上）
   ------------------------------------------------------------
   只拿三样：
     · 报废汽车 wreckcar / wreckcarHalf —— 横在东西向主干道上当路障，
       打不烂（st:'solid'），逼人从边上绕，路中间终于不是一条空跑道
     · 地面杂物 trash / soda / flask / plank —— 纯氛围，子弹能穿过去，
       只有爆炸才炸得碎；不挡路、不进寻路网格
     · 花坛 {t:'bed'} —— 庄园前院一丛玫瑰百合，城区街心几丛小雏菊，郊外路边野花。
       下雨的黑夜里，唯一还像样子的就是这几丛花
   数量都卡着：花 9 丛（约 65 株）、杂物 ~60 件、车最多 10 辆 + 4 个水泥墩。
   ============================================================ */
function dzScenery(L){
  if (!L.decors) L.decors = [];
  const free = (x, y, r) => {
    /* 岛图：花坛/杂物/水泥墩都不许长在水里 */
    if (typeof dzIsland !== 'undefined' && dzIsland && !dzOnLand(x, y, 40)) return false;
    for (const q of L.walls){
      if (q.dead) continue;
      if (x + r > q.x && x - r < q.x + q.w && y + r > q.y && y - r < q.y + q.h) return false;
    }
    for (const q of L.brk){
      if (x + r > q.x && x - r < q.x + q.w && y + r > q.y && y - r < q.y + q.h) return false;
    }
    return x > 80 && y > 80 && x < L.w - 80 && y < L.h - 80;
  };
  /* ---- 1. 报废车：横在三条东西向主干道上 ---- */
  const carSkin = ['rust', 'blue', 'white', 'olive', 'wine', 'burnt', 'nohead', 'half'];
  let ci = 0;
  for (const r of (L.roads || [])){
    if (r.w < r.h) continue;                       /* 只摆东西向的路：车的画法是横的 */
    for (let d = 700; d < r.w - 500; d += 1180){
      if (arenaRandom() < 0.45) continue;
      const t = (ci % 5 === 3) ? 'wreckcarHalf' : 'wreckcar';
      const sz = (t === 'wreckcarHalf') ? [72, 78] : [132, 78];
      const x = r.x + d + Math.round((arenaRandom() - 0.5) * 220);
      const y = r.y + Math.round((arenaRandom() - 0.5) * 26) - (r.h - sz[1]) / 2;
      const w = sz[0], h = sz[1];
      if (x < 120 || x + w > L.w - 120) continue;
      let blocked = false;
      for (const q of L.walls){
        if (q.dead) continue;
        if (x + w > q.x - 30 && x < q.x + q.w + 30 && y + h > q.y - 30 && y < q.y + q.h + 30){ blocked = true; break; }
      }
      if (blocked) continue;
      L.walls.push({ t: t, x: Math.round(x), y: Math.round(y), w: w, h: h, skin: carSkin[ci % carSkin.length] });
      ci++;
      if (ci >= 10) break;
    }
    if (ci >= 10) break;
  }
  /* ---- 2. 南北向的路上放水泥墩（车横着不好看，墩子什么方向都行） ---- */
  let pi = 0;
  for (const r of (L.roads || [])){
    if (r.w >= r.h) continue;
    for (let d = 900; d < r.h - 700 && pi < 4; d += 1500){
      const x = r.x + Math.round((arenaRandom() - 0.5) * 30) - 45;
      const y = r.y + d;
      if (!free(x, y, 45)) continue;
      L.walls.push({ t: 'pillar', x: Math.round(x), y: Math.round(y), w: 90, h: 90 });
      pi++;
    }
  }
  /* ---- 3. 花坛：庄园两丛、城区街心三丛、郊外路边四丛 ---- */
  const beds = [
    { t: 'bed', kind: 'roseLily', x: 2960, y: 2760 },   /* 庄园前院：还活着的那片花 */
    { t: 'bed', kind: 'bouquet',  x: 3260, y: 2760 },
    { t: 'bed', kind: 'daisy',    x: 1250, y: 4620 },   /* 西南城区街心 */
    { t: 'bed', kind: 'mixed',    x: 4820, y: 4560 },   /* 东南城区 */
    { t: 'bed', kind: 'daisy',    x: 1080, y: 1450 },   /* 西北城区 */
    { t: 'bed', kind: 'wild',     x: 1500, y: 5260 },   /* 郊外路边 */
    { t: 'bed', kind: 'wild',     x: 3900, y: 3480 },
    { t: 'bed', kind: 'wild',     x: 2350, y: 4550 },
    { t: 'bed', kind: 'wild',     x: 5150, y: 2320 }
  ];
  for (const b of beds){
    /* 花坛别插进墙里：撞了就往四周挪几圈，八方向找得到空地才种 */
    const OFF = [[0,0],[70,0],[-70,0],[0,70],[0,-70],[90,70],[-90,70],[90,-70],[-90,-70]];
    for (let k = 0; k < OFF.length; k++){
      if (free(b.x + OFF[k][0], b.y + OFF[k][1], 24)){
        L.decors.push({ t: b.t, kind: b.kind, x: b.x + OFF[k][0], y: b.y + OFF[k][1] });
        break;
      }
    }
  }
  /* ---- 4. 地面杂物：城区垃圾堆、路边酒瓶、工事旁的木板 ---- */
  const junk = [
    [1180, 4560], [1420, 4380], [980, 1280], [1360, 1720], [4760, 4480], [5060, 4820],
    [1050, 4740], [1520, 4640], [1240, 4120], [880, 1360], [1560, 1520], [4680, 4620],
    [5140, 4720], [1010, 1180], [1630, 1880], [4920, 4360], [1120, 4460], [1420, 4780]
  ];
  for (const j of junk){
    if (!free(j[0], j[1], 22)) continue;
    L.decors.push({ t: 'trash', x: j[0], y: j[1] });
  }
  /* 酒瓶零散撒在城区与庄园外的地面：纯氛围，打一枪就碎 */
  const bottleSpots = [
    [1220, 4680], [1310, 4620], [1450, 4720], [1080, 4520], [1520, 4460],
    [980, 1420], [1120, 1620], [1420, 1820], [1560, 1620], [900, 1750],
    [4700, 4520], [4820, 4680], [4980, 4580], [5120, 4780], [5060, 4620],
    [2980, 3060], [3100, 3140], [3420, 3060], [2540, 2900], [2620, 3100],
    [2260, 1960], [2380, 2040], [3700, 1960], [3820, 2040], [2960, 3160]
  ];
  const bottleKind = ['soda', 'flask', 'bottle'];
  for (let i = 0; i < bottleSpots.length; i++){
    const b = bottleSpots[i];
    if (!free(b[0], b[1], 14)) continue;
    L.decors.push({ t: bottleKind[i % bottleKind.length], x: b[0], y: b[1] });
  }
  /* 木板：庄园院墙、军事区门口这些地方，地上总得有碎木头 */
  const planks = [
    [2460, 2810], [2740, 2810], [3320, 2810], [3600, 2810],
    [2500, 3380], [2680, 3380], [3300, 3380], [3560, 3380],
    [2160, 2010], [2340, 2010], [3720, 2010], [3900, 2010],
    [2860, 2090], [3120, 2090]
  ];
  for (let i = 0; i < planks.length; i++){
    const b = planks[i];
    if (!free(b[0], b[1], 20)) continue;
    L.decors.push({ t: (i % 3 === 2) ? 'plankBroken' : 'plank', x: b[0], y: b[1] });
  }
}

function dzWildHouses(L){
  const specs = [
    ['small_house', 300, 700], ['small_house', 1750, 300], ['storage', 3400, 260],
    ['two_room', 4850, 800],    ['small_house', 5450, 1900], ['warehouse', 4600, 3000],
    ['small_house', 900, 2500], ['studio', 1500, 3500],     ['small_house', 4600, 5300],
    ['storage', 3000, 5450],    ['two_room', 5300, 4700],   ['small_house', 3900, 4300],
    ['studio', 2500, 1400],     ['small_house', 3500, 3000],
    /* 填空白区：右上、右中、中下、左中、北侧边缘 —— 6000² 上空着太大的话，走路就是纯走路 */
    ['two_room', 5050, 1500],   ['small_house', 5500, 2450], ['clinic', 4750, 2150],
    ['two_room', 2600, 4750],   ['small_house', 3350, 5050], ['workshop', 2350, 4250],
    ['small_house', 1150, 3250],['studio', 5250, 3900],      ['storage', 2500, 300],
    ['small_house', 4250, 320], ['barracks', 5650, 3300],    ['small_house', 1750, 4750],
    /* 出生点旁边留三间：小刀开局第一分钟得有东西可搜，不然就是空跑一公里 */
    ['small_house', 1150, 5100],['studio', 900, 5200],       ['two_room', 1780, 5480]
  ];
  L.dzWild = L.dzWild || [];
  for (const s of specs){
    if (dzPlace(L, s[0], s[1], s[2], 0)) L.dzWild.push({ x: s[0] + 130, y: s[1] + 130 });
  }
}

/* 死亡地带的火箭炮塔：直接往 L.walls 里塞一个"炮塔墙"，
   后面的 updateRocketTurrets / initBreakables 会把它们当普通墙处理（能打烂、残骸仍是掩体） */
function dzAddTurret(L, x, y){
  const D = ROCKET_TURRET_DEF, h = D.baseHalf;
  const _box = { x:x - h, y:y - h, w:2*h, h:2*h };
  /* 先把压在炮塔格子上的矮墙/护墙挪走：射口旁边偶尔会有一条 4px 的压边，
     炮塔就会"砌在墙里"（热成像里看得见，子弹也会先打到那面墙）。 */
  const _over = (o) => Math.min(_box.x + _box.w, o.x + o.w) - Math.max(_box.x, o.x) > 0 &&
                       Math.min(_box.y + _box.h, o.y + o.h) - Math.max(_box.y, o.y) > 0;
  L.walls = L.walls.filter(function(o){ return o.rocketTurret || !_over(o); });
  if (L.brk) L.brk = L.brk.filter(function(o){ return !_over(o); });
  const w = { x:_box.x, y:_box.y, w:_box.w, h:_box.h, rocketTurret:true, type:'rocketTurret',
              brk:true, mat:'metal', hp:D.hp, maxHp:D.hp,
              ang:Math.PI / 2, turnV:0, fireCd:D.initialCooldown, recoilT:0, smokeT:0, wreck:false };
  L.walls.push(w);
  wallGeomVer++;
  /* 炮塔要在 initBreakables 之后才塞：那里面 L.allWalls 会把 brk 的墙剔除再缓存，
     在 build 阶段塞进去会被当成"被拆掉的墙"直接丢掉（试过，进关就没了）。 */
  if (typeof navPatchRect === 'function') navPatchRect(L, w.x, w.y, w.w, w.h);
  return w;
}
/* 摆一辆"敌方控制、停着不动"的机枪车：开不走（truckCanDrive 对 enemy 返回 false）、
   会一直在原地扫射（rules.truckMg.always），能被打爆。 */
function dzSpawnTruck(t, kind){
  const _k = (typeof kind === 'string' && ENEMY_TYPES[kind]) ? kind : 'truck';
  const T = enemyType({ type:_k });
  const e = {
    type:_k, veh: T.veh || 'truck', tstate:'parked', tt:0, team: (_k === 'truck_civil' ? 'neutral' : 'enemy'),
    x:t.x, y:t.y, r:T.r, ang:t.ang, head:t.ang,
    sx:t.x, sy:t.y, tx:t.x, ty:t.y,
    hp:T.hp, maxHp:T.hp, armor:T.armor || 0,
    spd:0, solid:true, door:0, spawned:0, cargoTotal:0, deployT:0,
    smokeT:0, visA:1, hitT:0, wreck:false, gone:false, invul:false, parked:true,
    mgAng:t.ang - Math.PI / 2
  };
  trucks.push(e);
  if (typeof navPatchTruck === 'function') navPatchTruck(e);
  return e;
}

/* ---- 围剿：开局平静 90 秒，之后每 150 秒一次、持续 70 秒；三波 12/18/24，间隔 20 秒 ----
   出来的兵从 1200~1700 外的一圈往里压，不刷在屏幕里；第二次围剿起有概率来一辆运兵车。 */
let dzSiege = null;
function dzSiegeReset(){
  dzSiege = null;
  dzBounty.t = 0;
  dzBounty.dur = 0;
  dzBounty.round = 0;
}
const DZ_SIEGE_SPAWN_STEP = 0.09;  /* 8 人约 0.7 秒落完，避开同一帧的初始化尖峰 */
function dzWaveSpawn(n){
  const L = dzLvl;
  if (!L) return 0;
  let put = 0;
  for (let i = 0; i < n; i++){
    let q = null;
    for (let k = 0; k < 12 && !q; k++){
      const a = rand(0, TAU), r = rand(1200, 1700);
      const x = clamp(player.x + Math.cos(a) * r, 90, L.w - 90);
      const y = clamp(player.y + Math.sin(a) * r, 90, L.h - 90);
      const s = safeSpot(L, { x: x, y: y }, 20);
      if (dist(s.x, s.y, player.x, player.y) > 900) q = s;
    }
    if (!q) continue;
    const rw = arenaRandom();
    /* 围剿分三档（用户 m16203）：Lv1 普通兵 + 少数一/二级甲；Lv2 全员二级甲；Lv3 全员职业兵 */
    const lv = (dzSiege && dzSiege.level) || 1;
    let kind, arm = null;
    if (lv >= 3){
      kind = rw < 0.72 ? 'spec' : 'specFlank';
    } else if (lv === 2){
      kind = 'grunt'; arm = 'heavy';
    } else {
      kind = rw < 0.88 ? 'grunt' : 'grenadier';
      const r = arenaRandom();
      arm = r < 0.20 ? 'light' : (r < 0.29 ? 'heavy' : null);   /* 约三成有甲，够「少数」 */
    }
    dzAddEnemy(q.x, q.y, kind);
    const e = enemies[enemies.length - 1];
    if (e){
      if (arm){ e.armorKind = arm; e.armor = undefined; }   /* 留给 ensureEnemyArmor 穿 */
      e._siegeLv = lv;
      e._rush = true; e.mode = 1; e.alertT = 9e9; e.boostT = 2;
      e._spawnD = Math.round(dist(e.x, e.y, player.x, player.y));   /* 出生时离玩家多远（测试/调参用，之后他们会跑过来） */
      e.lastKnown = { x: player.x, y: player.y };
    }
    put++;
  }
  return put;
}
/* 围剿投放器：一次最多创建一名敌人。
   出生点搜索、实体初始化、导航登记和首次 AI 更新因此分散到不同帧，
   即使警觉满时已有几百名敌人，也不会再把整波 8 人压进同一个长任务。 */
function dzSiegeSpawnTick(S, dt){
  if (!S || !(S.spawnLeft > 0)) return 0;
  S.spawnT = (S.spawnT || 0) - Math.max(0, dt || 0);
  if (S.spawnT > 0) return 0;
  const made = dzWaveSpawn(1);
  if (made > 0){
    S.spawnLeft -= made;
    S.spawned = (S.spawned || 0) + made;
    S.spawnFail = 0;
  } else {
    /* 极端地图一时找不到安全出生点时稍后重试；连续失败也要收口，不能永久挂队列。 */
    S.spawnFail = (S.spawnFail || 0) + 1;
    if (S.spawnFail >= 16){ S.spawnLeft--; S.spawnFail = 0; }
  }
  S.spawnT = DZ_SIEGE_SPAWN_STEP;
  return made;
}
/* m37250：围剿开场横幅 —— 警觉攒满、当地人开始悬赏你。
   只是单纯的提示层，不参与任何判定：一条 6 秒的压迫感标语，顶部居中。 */
var dzBounty = { t: 0, dur: 0, round: 0 };
function dzBountyShow(round){
  dzBounty.t = 0; dzBounty.dur = 6.2; dzBounty.round = round || 1;
  if (typeof sfxSiren === 'function') sfxSiren(0.62);
  camShake = Math.max(camShake || 0, 0.9);
}
function dzBountyTick(dt){
  if (dzBounty.dur <= 0) return;
  dzBounty.t += dt;
  if (dzBounty.t >= dzBounty.dur) dzBounty.dur = 0;
}
/* 逐字画，字间距给小一点 —— 中文拉太开像广告，收在一起才有「压过来」的感觉 */
function _dzBountyLine(txt, y, font, color, glow, gap){
  ctx.font = font;
  ctx.textAlign = 'left';
  const chars = Array.from(txt);
  let total = 0;
  for (const ch of chars) total += ctx.measureText(ch).width + gap;
  total -= gap;
  let x = W/2 - total/2;
  ctx.shadowColor = glow || 'transparent';
  ctx.shadowBlur = glow ? 14 : 0;
  ctx.fillStyle = color;
  for (const ch of chars){
    ctx.fillText(ch, x, y);
    x += ctx.measureText(ch).width + gap;
  }
  ctx.shadowBlur = 0;
}
function drawDzBounty(){
  if (dzBounty.dur <= 0 || !dzLvl || state !== 'play') return;
  const t = dzBounty.t, dur = dzBounty.dur;
  /* 0~0.35 淡入、之后保持、最后 15% 淡出 */
  const fadeIn = Math.min(1, t / 0.35);
  const fadeOut = Math.min(1, (dur - t) / (dur * 0.16));
  const a = Math.max(0, Math.min(fadeIn, fadeOut));
  if (a <= 0.01) return;
  const pulse = 0.88 + 0.12 * Math.sin(t * 5.2);
  const bandH = 112;
  const y0 = 104;
  ctx.save();
  ctx.textAlign = 'center';
  /* 底带：中间最浓、两头散开，不切一条硬边 */
  const g = ctx.createLinearGradient(W/2 - 450, 0, W/2 + 450, 0);
  g.addColorStop(0,    'rgba(30,4,4,0)');
  g.addColorStop(0.16, 'rgba(38,5,5,' + (0.80 * a * pulse).toFixed(3) + ')');
  g.addColorStop(0.5,  'rgba(52,6,6,' + (0.88 * a * pulse).toFixed(3) + ')');
  g.addColorStop(0.84, 'rgba(38,5,5,' + (0.80 * a * pulse).toFixed(3) + ')');
  g.addColorStop(1,    'rgba(30,4,4,0)');
  ctx.fillStyle = g;
  ctx.fillRect(W/2 - 450, y0, 900, bandH);
  /* 上下两条红线，带一点呼吸 */
  ctx.strokeStyle = 'rgba(214,58,44,' + (0.72 * a * pulse).toFixed(3) + ')';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(W/2 - 412, y0 + 8); ctx.lineTo(W/2 + 412, y0 + 8);
  ctx.moveTo(W/2 - 412, y0 + bandH - 8); ctx.lineTo(W/2 + 412, y0 + bandH - 8);
  ctx.stroke();
  ctx.globalAlpha = a;
  _dzBountyLine('通 缉 · 第 ' + dzBounty.round + ' 轮', y0 + 30, 'bold 12px "Microsoft YaHei",sans-serif',
                'rgba(255,138,106,' + (0.95 * pulse).toFixed(3) + ')', 'rgba(190,40,30,0.9)', 2.6);
  _dzBountyLine('你的行为引起当地人恐慌', y0 + 60, 'bold 17px "Microsoft YaHei",sans-serif',
                'rgba(255,196,168,' + (0.96 * pulse).toFixed(3) + ')', 'rgba(120,20,14,0.85)', 1.2);
  _dzBountyLine('他们已经发出针对你的悬赏通缉', y0 + 92, 'bold 26px "Microsoft YaHei",sans-serif',
                'rgba(255,236,228,1)', 'rgba(214,58,44,0.95)', 1.6);
  ctx.globalAlpha = 1;
  ctx.restore();
}
function dzSiegeUpdate(dt){
  const L = dzLvl;
  if (!L || state !== 'play') return;
  dzBountyTick(dt);
  if (!dzSiege){
    dzSiege = { on: false, alert: 0, quietT: 0, coolT: 0, endT: 0, waveT: 0, waveN: 0, round: 0, warned: 0,
                spawnLeft: 0, spawnT: 0, spawnFail: 0, spawned: 0 };
  }
  const S = dzSiege;
  S.coolT = Math.max(0, S.coolT - dt);

  /* 自愈：围剿一旦卡在 on 上（endT 丢了 / 时间被暂停），警觉会永远不涨。5 秒宽限后强行收尾。 */
  if (S.on && (!(S.endT > 0) || timeAlive > S.endT + 5)){
    S.on = false; S.alert = 0; S.spawnLeft = 0; S.waveN = 0; S.coolT = Math.max(S.coolT || 0, 20);
    logWarn('dz', '围剿状态自愈（结束条件丢了）');
  }

  /* 围剿进行中：只推进波次 */
  if (S.on){
    if (timeAlive >= S.endT){
      S.on = false;
      S.alert = 0;
      S.spawnLeft = 0;
      setMsg('这一波压过去了 · 抓紧搜', 2.6);
      logWarn('dz', '围剿结束');
      return;
    }
    if (timeAlive >= S.waveT){
      S.waveT = timeAlive + 20;
      S.spawnLeft = (S.spawnLeft || 0) + (S.waveSize || 8); /* 6/8/10 随等级；由投放器逐帧创建 */
      S.spawnT = 0;
      S.waveN++;
    }
    dzSiegeSpawnTick(S, dt);
    /* 第二辆运兵车：上一轮是同一帧连开两辆（round>=4 的 50%），两辆车从同一条边冲进来、
       还抢同一片空地，看上去就像「车里又开出来一辆车」。改成延时到场，观感才对得上「又来一车援兵」。 */
    if (S.truck2T > 0 && timeAlive >= S.truck2T){
      S.truck2T = 0;
      spawnTruck();
      setMsg('又来一辆运兵车', 2.2);
    }
    return;
  }

  /* 冷却期：警觉值不涨，安静自然回落 */
  if (S.coolT > 0){
    S.alert = Math.max(0, S.alert - 6 * dt);
    return;
  }

  /* 安静就慢慢降温：连着 5 秒没动静才开始掉，掉得不快 —— 想躲必须真的闭嘴一阵 */
  S.quietT += dt;
  if (S.quietT > 5) S.alert = Math.max(0, S.alert - 2.2 * dt);

  /* 快到阈值的时候给前兆，别让玩家莫名其妙被围 */
  if (S.alert >= 60 && S.warned < 1){
    S.warned = 1;
    setMsg('无线电里有人在报你的位置', 2.4);
    logWarn('dz', '警觉 ' + Math.round(S.alert));
  }
  if (S.alert >= 85 && S.warned < 2){
    S.warned = 2;
    setMsg('他们朝这边来了 · 找掩体', 2.4);
    logWarn('dz', '警觉 ' + Math.round(S.alert));
  }
  if (S.alert < 100) return;

  /* 满 100：围剿开始 */
  S.on = true; S.alert = 100; S.warned = 0; S.coolT = 90;
  S.waveN = 0; S.waveT = timeAlive;      /* 第一波立刻出，后两波各隔 20 秒 */
  S.spawnLeft = 0; S.spawnT = 0; S.spawnFail = 0; S.spawned = 0;
  S.endT = timeAlive + 60;
  S.truck2T = 0;
  S.round++;
  S.level = Math.min(3, S.round);          /* 第 1 轮 Lv1、第 2 轮 Lv2、第 3 轮起 Lv3 */
  S.waveN = 0; S.waveT = timeAlive;
  /* 每波人数：按难度给基数，再随轮次往上加（用户 m16563：前期别一上来就一堆）。
     困难 4/6/8、噩梦 5/7/9、硬核 6/8/10 —— 一轮三波，所以是 12~30 只。 */
  const _szBase = (typeof dzTier === 'string' && dzTier === 'core') ? 6
                : (typeof dzTier === 'string' && dzTier === 'nightmare') ? 5 : 4;
  S.waveSize = _szBase + (S.level - 1) * 2;
  const _lvTxt = ['普通搜捕队 · 有人穿着轻甲', '重装搜捕队 · 全员二级甲', '职业兵上门 · 还有车'][S.level - 1]
              + ' · 每波 ' + S.waveSize + ' 只';
  setMsg('围剿 Lv' + S.level + ' · ' + _lvTxt, 3.8);
  dzBountyShow(S.round);   /* m37250：顶部悬赏通缉横幅 */
  camShake = Math.max(camShake, S.level >= 3 ? 1.0 : 0.8);
  logWarn('dz', '围剿 #' + S.round + ' Lv' + S.level + '（第 ' + Math.round(timeAlive) + ' 秒 · 警觉满）');
  /* 车只在 Lv3 来（用户 m16203：三级才会触发车辆事件） */
  if (S.level >= 3){
    spawnTruck();
    /* 第 4 轮起还会再来一辆，但延后 13 秒到场（不再同帧双车），避免两辆车叠在一起开出来 */
    if (S.round >= 4 && arenaRandom() < 0.5) S.truck2T = timeAlive + 13;
  }
}

/* 制造动静就往这儿记一笔：开枪、开枪械、爆炸、砍人。
   潜行玩家一辈子攒不满，爱刚枪的二十来发就招来一整波 —— 这才是"你自己招来的"。
   不同地方"回声"不一样：军事区到处是报话机和巡逻队，同样的枪声更容易把人叫来；
   打野空旷，声音散得快。按区域表给权重，别再写死一个判断框。 */
const DZ_ALERT_ZONE_K = { mil: 1.6, manor: 1.25, citySW: 1.0, citySE: 1.0, cityNW: 1.0 };
const DZ_ALERT_WILD_K = 0.75;
function dzZoneAt(x, y){
  const zones = (typeof dzLvl !== 'undefined' && dzLvl && dzLvl.dzZones && dzLvl.dzZones.length) ? dzLvl.dzZones : DZ_ZONES;
  for (const z of zones){
    if (x >= z.x && x <= z.x + z.w && y >= z.y && y <= z.y + z.h) return z;
  }
  return null;
}
function dzAlertZoneK(x, y){
  const z = dzZoneAt(x, y);
  return z ? (DZ_ALERT_ZONE_K[z.key] || 1.0) : DZ_ALERT_WILD_K;
}
function dzAlertGain(mul){
  if (!dzLvl || !dzSiege || dzSiege.on || dzSiege.coolT > 0) return;
  const k = (mul || 1) * 1.35 * dzAlertZoneK(player.x, player.y);
  dzSiege.alert = Math.min(100, dzSiege.alert + k);
  dzSiege.quietT = 0;
}

/* 大图的天气：默认雷暴，按种子三成多概率换成「风雷」（m19577）。
   同一张图每次进来的天气是固定的，不会读档前后不一样。 */
/* 留给"按种子定开局天气"用（现在开局固定晴天，见 m20510） */
function dzPickWeather(){
  /* 没种子时（手工经典图）不要落到 0 上——0 会恒等于第一档，等于把老图钉死成一种天气 */
  const s = ((typeof dzSeedUsed === 'number' && dzSeedUsed) ? dzSeedUsed
           : ((typeof dzSeed === 'number' ? dzSeed : 0) >>> 0)) >>> 0;
  if (!s) return 'storm';
  const h = ((s * 2654435761) >>> 0) % 100;
  /* 三档：0-24 狂风暴雨、25-54 风雷、55-99 雷暴 */
  if (h < 25) return 'squall';
  if (h < 55) return 'gale';
  return 'storm';
}

function buildDeathZoneCore(){
  const L = {
    name: '死亡地带', w: DZ_W, h: DZ_H, theme: 'dark', chapter: 0, ver: 3, devOnly: true,
    start: { x: 620, y: 5420 },
    extract: { x:-9000, y:-9000, w:10, h:10 },
    walls: [], brk: [], glass: [], doors: [], cameras: [], drones: [],
    loot: [], slots: [], placed: [],
    weapons: ['knife'], startMeds: 1, startSmokes: 2, startAmmo: { pistol: 24 },
    enemyHp: 100, dropGuns: true,
    rules: {
      /* 大图三件套：视距外休眠 + 视野外隐身 + 雨夜 */
      /* nightR 拉到比半屏对角线还远（1280×800 的半对角线 ≈ 755），屏幕里就不再出现那圈"黑框"；
         夜的感觉交给 nightA 的整屏压暗。视野距离两边都放到 800，视角不变（95°）。 */
      /* 开局固定晴天（m20510）：天气交给轮换一点点变坏，别一进来就是雷暴 */
      lod: true, mode: 'blind', weather: 'clear', thermalGear: false, nightR: 1400, nightA: 0.72, nightBlind: false, enemyFovK: 0.72, thunderK: 0.45,
      /* 天气轮换（m20292）：开局天气只当起点，之后每隔一分多钟沿"天气阶梯"挪一格，带 9~13 秒过渡 */
      weatherRotate: true,
      playerVision: 800, playerFov: 95, fog: false, noTalk: true,
      human: true, // 死亡地带复用持枪战术；难度只调参数，远处开销由 LOD 控制。
      hearK: 1.1, walkDelay: 0.12, spawnNearFirst: true,
      /* 围剿：开局 90 秒之后每 150 秒一次，持续 70 秒 */
      alarmAt: 90, alarmRush: 150, alarmCap: 18, alarmMax: 60,
      /* 敌人伤害不走 CFG.eDmg，直接按「手里那把枪的原伤害」算：硬核 ×1，噩梦 ×1.5。
         老关卡没有这两个字段，照旧走 CFG.eDmg 那一套。 */
      dmgMode: dzTier === 'core' ? 'gun' : 'story', dmgMul: 1,
      /* 军事区那几辆车的顶置机枪：常驻值守、射程更远、扫射更久、转得更慢（好让玩家有烟有侧门） */
      truckMg: { always: true, range: 540, dmg: 5, rof: 0.06, spread: 0.10,
                 turnSpd: 4.2, burst: 1.1, pause: 0.55, rage: 9999 },
      dz: true, breach: true, thermalV2: true    /* 一部分薄外墙转成可拆墙；热成像走 v2 规则 */
    }
  };
  /* 边框 */
  L.walls.push({ x:0, y:0, w:DZ_W, h:DZ_T, _dzEdge:1 });
  L.walls.push({ x:0, y:DZ_H - DZ_T, w:DZ_W, h:DZ_T, _dzEdge:1 });
  L.walls.push({ x:0, y:0, w:DZ_T, h:DZ_H, _dzEdge:1 });
  L.walls.push({ x:DZ_W - DZ_T, y:0, w:DZ_T, h:DZ_H, _dzEdge:1 });

  /* 路：只画在地上（不进寻路、不当墙），给玩家一个"往哪走"的参照。
     三条横路 + 两条竖路，横的串起出生点/南环/北环/军事区南门，竖的绕开庄园走两侧。 */
  /* 直路全部删掉（用户 m12734：中间那几条横平竖直的灰色长条太"正交"了）。
     改成蛛网状：从主城区中心辐射出去的弯曲土路，末端分叉 —— 在 dzRoadWeb() 里生成。 */
  L.roads = [];

  /* 中心庄园 */
  dzBuildManor(L, 2300, 2450);
  dzPlace(L, 'storage', 2380, 2580, 0);
  dzPlace(L, 'office',  2900, 2580, 0);
  dzPlace(L, 'storage', 3300, 3000, 90);
  dzPlace(L, 'workshop', 2900, 3050, 0);

  /* 军事重区：军营该有的样子 —— 两列营房对齐、中间一条直通路、南门里侧一个停机坪。
     围墙：北 600、南 2174（门洞 780~1020）、东西 2100 / 3874。 */
  dzSeg(L, 2100, 600, 1800, 'h', 26, []);
  /* 东西围墙各开破口：南门不是唯一入口。
     西墙 1040~1160 是木板钉死的侧门（两块木板，打碎能进）；1500~1680 是玻璃窗。
     东墙只留玻璃那一个。以前玻璃是直接压在整面墙上的 —— 墙没断开，等于没入口。 */
  dzSeg(L, 2100, 600, 1600, 'v', 26, [[440, 640], [900, 1080]]);
  dzSeg(L, 3874, 600, 1600, 'v', 26, [[900, 1080]]);
  /* 南墙：中间是门洞，门洞两侧各开一个炮塔射口（炮塔坐进射口里，朝南没有墙挡着） */
  dzSeg(L, 2100, 2174, 1800, 'h', 26, [[666, 786], [780, 1020], [1086, 1206]]);
  /* 西列营房：三栋同一个 x、同一个朝向，门都朝东（对着中间那条路） */
  dzPlace(L, 'barracks', 2180, 680, 0);
  dzPlace(L, 'barracks', 2180, 1130, 0);
  dzPlace(L, 'barracks', 2180, 1580, 0);
  /* 东列：仓库 / 指挥楼 / 库房，同样对齐 */
  dzPlace(L, 'warehouse', 3340, 680, 0);
  dzPlace(L, 'office',    3340, 1130, 0);
  dzPlace(L, 'storage',   3340, 1580, 0);

  /* 停机坪：南门里侧一块水泥地，四个车位，车整整齐齐停成一排、车头朝北。
     车是"敌人控制的固定资产"：开不走、会扫射、能被打爆，打爆掉一个箱子。 */
  L.dzApron = { x:2540, y:1830, w:800, h:230 };
  L.dzTrucks = [
    { x: 2620, y: 1945, ang: -Math.PI / 2 },
    { x: 2810, y: 1945, ang: -Math.PI / 2 },
    { x: 3000, y: 1945, ang: -Math.PI / 2 },
    { x: 3190, y: 1945, ang: -Math.PI / 2 }
  ];
  /* 炮塔守南门：坐进南墙上的两个射口（缺口 2766~2886 / 3186~3306），
     炮口对着墙外，前面没有墙挡着，也不会一开炮就炸崩自己那面墙 */
  L.dzTurrets = [{ x:2826, y:2128 }, { x:3246, y:2128 }];
  /* 这一片是停机坪 + 炮塔 + 门内通道：先把地皮占住，
     后面的 dzPlace 就不会有哪栋楼被"往外挤"挤到门口来把炮塔埋了。 */
  L._dzFoot = L._dzFoot || [];
  L._dzFoot.push({ x: 2500, y: 1800, w: 800, h: 330, keep: 1 });
  L._dzFoot.push({ x: 2740, y: 2130, w: 560, h: 210, keep: 1 });
  /* 三块城区 */
  const citySets = [
    ['apartment', 'clinic', 'shop', 'office', 'two_room'],
    ['apartment', 'shop', 'storage', 'two_room', 'small_house'],
    ['clinic', 'office', 'apartment', 'workshop', 'small_house']
  ];
  const cities = DZ_ZONES.filter(z => z.key.indexOf('city') === 0);
  for (let i = 0; i < cities.length; i++){
    const z = cities[i], set = citySets[i % citySets.length];
    dzPlace(L, set[0], z.x + 80,  z.y + 80,  0);
    dzPlace(L, set[1], z.x + 80,  z.y + 420, 0);
    dzPlace(L, set[2], z.x + 640, z.y + 80,  0);
    dzPlace(L, set[3], z.x + 640, z.y + 420, 0);
    dzPlace(L, set[4], z.x + 320, z.y + 800, 0);
  }

  dzWildHouses(L);

  /* ---- 核心块里的几栋"大东西"：第 73 轮的新模板 ----
     放三栋，位置挑在原来空旷的地块上（庄园北侧、军事区西侧空地、城区之间的大街边）。
     大礼堂放在城区之间当"地标"，玩家跑图时能靠它定位；庄园主楼贴着既有庄园放；
     大型库房扔到军事区西南角的空地，配一排皮卡（后面 dzVehicles）。 */
  dzPlace(L, 'grand_hall', 3050, 4150, 0);     /* 城区之间的地标 */
  dzPlace(L, 'manor',      2150, 3300, 0);     /* 庄园西侧空地 */
  dzPlace(L, 'depot',      1000, 2600, 0);     /* 军事区西南空地 */
  dzPlace(L, 'big_house',  4400, 3400, 0);     /* 东南斜街上一栋 */
  dzPlace(L, 'big_house',  1900, 5150, 0);     /* 南侧靠撤离点一栋 */

  /* 可破坏掩体：路障、箱子、院里工事、碎得开的外墙 —— 这个模式的核心爽点之一 */
  dzCover(L);

  /* ---- 车：皮卡与装甲皮卡，数量有限 ----
     民用皮卡（truck_civil）是"谁都能开走"的，当成玩家在危难时的逃生/代步工具：
     三辆，停在庄园门口、城区街边、撤离点附近。装甲皮卡（truck_pickup）是敌人的快速反应车：
     两辆，一辆守庄园、一辆守军事区门口，玩家打爆它们能拿到箱子。 */
  L.dzTrucks = L.dzTrucks || [];
  const _pickParked = (t, x, y, ang, kind) => {
    let ok = false;
    for (let k = 0; k < 12 && !ok; k++){
      const a2 = (k / 12) * TAU, d2 = k === 0 ? 0 : 90 + k * 40;
      const px = Math.round(x + Math.cos(a2) * d2), py = Math.round(y + Math.sin(a2) * d2);
      if (px < 120 || py < 120 || px > L.w - 120 || py > L.h - 120) continue;
      let hit = false;
      for (const q of L.walls){
        if (q.dead) continue;
        if (px + 70 > q.x - 20 && px - 70 < q.x + q.w + 20 && py + 44 > q.y - 20 && py - 44 < q.y + q.h + 20){ hit = true; break; }
      }
      if (hit) continue;
      L.dzTrucks.push({ x: px, y: py, ang: ang, kind: kind });
      ok = true;
    }
    return ok;
  };
  _pickParked('civil', 2326, 2340, -Math.PI / 2, 'truck_civil');   /* 庄园门口 */
  _pickParked('civil', 4720, 4520, 0,           'truck_civil');    /* 东南城区街边 */
  _pickParked('civil', 2700, 5450, -Math.PI / 2, 'truck_civil');   /* 南侧撤离点附近 */
  _pickParked('enemy', 3560, 3400, Math.PI / 2, 'truck_pickup');   /* 庄园东侧快速反应车 */
  _pickParked('enemy', 1500, 2350, Math.PI,     'truck_pickup');   /* 军事区门口 */

  /* 野外的物资堆：这是打野区的主要物资来源（箱子都在屋子里） */
  L.pileSpawn = { count: [55, 75], margin: 220 };
  L.dzZones = DZ_ZONES.map(z => ({ key:z.key, name:z.name, x:z.x, y:z.y, w:z.w, h:z.h, danger:z.danger }));
  /* 三个撤离候选：南 / 东 / 北 各一个，拿到黑匣子才随机亮一个 */
  L.dzExtracts = [
    { x: 2900, y: 5700, w: 160, h: 120 },
    { x: 5600, y: 2900, w: 160, h: 120 },
    { x: 2950, y: 180,  w: 160, h: 120 }
  ];
  L.dzBox = false;
  /* normalizeRules() 只扫 LEVELS；这个关是现场建的，派生别名得自己补，
     否则 rules.mode:'blind' 只是数据、L.blind 是 undefined ——
     视野光锥、视野外隐身的敌人、墙上的脚印统统不生效。 */
  L.boss = false;
  L.blind = (L.rules.mode === 'blind');
  return L;
}

/* 按种子掷一个边长：尺寸决定内容规模（面积越大，人/物资/散房越多） */
function dzPickSide(){
  /* 单测里把尺寸钉死在 6000²：布局类断言都是按设计空间写的，随机尺寸会让它们漂移。
     浏览器里没有 module，所以线上仍然每局随机（想复现就 ?seed= / ?sz=）。
     注意别去改 dzForceSide —— 那是"外部指定"的开关，测试自己会显式设/清。 */
  if (dzForceSide < 0) dzForceSide = 0;            /* -1 = 显式要求随机（单测用），用完就清 */
  if (!dzForceRandom){
    const pinned = dzForceSide || ((typeof module !== 'undefined' && module.exports) ? DZ_DESIGN : 0);
    if (pinned) return Math.max(3000, Math.min(20000, pinned));
  }
  const steps = Math.round((DZ_SIDE_MAX - DZ_SIDE_MIN) / DZ_SIDE_STEP);
  const k = Math.floor(arenaRandom() * (steps + 1));
  return DZ_SIDE_MIN + k * DZ_SIDE_STEP;
}
function dzAreaK(W, H){ return (W * H) / (DZ_DESIGN * DZ_DESIGN); }

/* 把设计空间（6000²）里生成好的核心块整体平移 */
function dzShiftCore(L, dx, dy){
  const sh = (o) => {
    if (!o || typeof o !== 'object') return;
    if (typeof o.x === 'number') o.x += dx;
    if (typeof o.y === 'number') o.y += dy;
  };
  for (const key of ['walls','brk','glass','doors','cameras','drones','loot','slots','placed',
                     'dzZones','dzExtracts','dzTrucks','dzTurrets','dzWild','roads','_dzFoot',
                     'dzStoreSpots','dzCameras','rooms']){
    const arr = L[key];
    if (Array.isArray(arr)) for (const o of arr) sh(o);
  }
  /* 房间跟着平移了：去重集合和 200px 网格索引都得按新坐标重建，
     否则新坐标会被当成"新房间"重复登记、索引还会指回老位置 */
  if (L.rooms && L.rooms.length){
    L._roomKeys = new Set(L.rooms.map(roomKeyOf));
    L.roomGrid = null;
  }
  sh(L.start); sh(L.extract); sh(L.dzApron); sh(L.dzBoxSite);
  return L;
}

/* 核心块之外的那一大圈：补散房和几组长条武器箱，让大地图不空 */
function dzExtend(L, areaK, coreRect){
  /* 小房子占多数；大屋/大礼堂/主楼/大库房按低权重掺进来 —— 外圈不能全是同一种小盒子。
     （第 73 轮新加的 big_house / grand_hall / manor / depot 与 safehouse） */
  const TYPES = ['small_house','two_room','storage','studio','clinic','warehouse','shop','office',
                 'safehouse','kitchen_house','bathroom_house','workshop',
                 'big_house','big_house',
                 'grand_hall','manor','depot'];
  const inside = (x, y) => (x > coreRect.x - 40 && x < coreRect.x + coreRect.w + 40 &&
                            y > coreRect.y - 40 && y < coreRect.y + coreRect.h + 40);
  /* 街区图：先把岛划成几个地块（村/住宅/工业/公共），房子只长在地块里，
     地块之间自然留出缓冲 —— 这样看着才是"几个村子"，不是"均匀撒了一层房子" */
  /* 蛛网路：从主城区中心辐射出去 */
  if (typeof dzRoadWeb === 'function'){
    const ccx = coreRect.x + coreRect.w / 2, ccy = coreRect.y + coreRect.h / 2;
    dzRoadWeb(L, ccx, ccy);
  }
  const dists = (typeof dzDistrictsPlan === 'function' && typeof DZ_DISTRICTS_ON !== 'undefined' && DZ_DISTRICTS_ON)
    ? dzDistrictsPlan(L, coreRect) : [];
  L.dzDistricts = dists;
  let houses = 0;
  if (dists.length){
    for (const dst of dists){
      /* 数量按地块面积 × 密度给，上限 26 栋免得一坨 */
      const n = Math.max(4, Math.min(26, Math.round(Math.PI * dst.r * dst.r * dst.density / 45000)));
      let placed = 0, tries = 0;
      while (placed < n && tries < n * 16){
        tries++;
        const ang = arenaRandom() * Math.PI * 2;
        const rad = Math.sqrt(arenaRandom()) * dst.r * 0.92;
        const px = dst.x + Math.cos(ang) * rad, py = dst.y + Math.sin(ang) * rad;
        if (px < 300 || py < 300 || px > L.w - 300 || py > L.h - 300) continue;
        if (inside(px, py)) continue;                        /* 核心城区由手工布局负责 */
        if (typeof dzIsland !== 'undefined' && dzIsland && !dzOnLand(px, py, 220)) continue;
        const t = dst.mix[Math.floor(arenaRandom() * dst.mix.length) % dst.mix.length];
        if (dzPlace(L, t, px, py, 0)){ L.dzWild.push({ x: px + 130, y: py + 130 }); placed++; houses++; }
      }
    }
    /* 地块之间的连接路（纯视觉，不进寻路） */
    if (typeof dzDistrictsRoads === 'function') dzDistrictsRoads(L, dists, coreRect);
  }
  if (!houses){
    /* 兜底：万一地块一个都没成，退回均匀撒点 */
    const landPx = (typeof dzIsland !== 'undefined' && dzIsland) ? dzIsland.area : L.w * L.h;
    const want = Math.max(28, Math.min(120, Math.round(landPx / 1100000)));
    let tries = 0;
    while (houses < want && tries < want * 14){
      tries++;
      const px = rand(360, L.w - 360), py = rand(360, L.h - 360);
      if (inside(px, py)) continue;
      if (typeof dzIsland !== 'undefined' && dzIsland && !dzOnLand(px, py, 300)) continue;
      const t = TYPES[Math.floor(arenaRandom() * TYPES.length) % TYPES.length];
      if (dzPlace(L, t, px, py, 0)){ L.dzWild.push({ x: px + 130, y: py + 130 }); houses++; }
    }
  }
  /* 外圈的长条武器箱：按面积给 3~8 个 */
  const nCr = Math.max(3, Math.min(8, Math.round(3 * areaK)));
  const OFF = [[0,0],[80,0],[-80,0],[0,80],[0,-80],[120,90],[-120,90],[120,-90],[-120,-90]];
  for (let i = 0; i < nCr; i++){
    const px = rand(420, L.w - 420), py = rand(420, L.h - 420);
    if (inside(px, py)) continue;
    const sz = (typeof COVER_DEF !== 'undefined' && COVER_DEF.crateWeap && COVER_DEF.crateWeap.sz) || [96, 30];
    let ok = false;
    for (let k = 0; k < OFF.length && !ok; k++){
      const x = Math.round(px + OFF[k][0]), y = Math.round(py + OFF[k][1]);
      if (x < 60 || y < 60 || x + sz[0] > L.w - 60 || y + sz[1] > L.h - 60) continue;
      let hit = false;
      for (const q of L.walls){ if (!q.dead && x + sz[0] > q.x - 8 && x < q.x + q.w + 8 && y + sz[1] > q.y - 8 && y < q.y + q.h + 8){ hit = true; break; } }
      if (hit) continue;
      L.brk.push({ t:'crateWeap', x:x, y:y, w:sz[0], h:sz[1] });
      ok = true;
    }
  }
  return houses;
}

/* 新入口：先掷尺寸 → 在 6000² 设计空间里造核心块 → 平移到目标地图 → 外圈补内容 */
function buildDeathZone(){
  /* 每次建图先把上一张岛作废：经典图不该有海，随机图也不该拿上一局的岛去挡摆放 */
  if (typeof dzIsland !== 'undefined') dzIsland = null;
  /* 经典图：完全走老路径，尺寸固定 6000²、不平移、不补外圈 —— 和以前一模一样 */
  if (dzMapMode !== 'random'){
    dzSideUsed = DZ_DESIGN; dzAreaUsed = 1;
    DZ_W = DZ_DESIGN; DZ_H = DZ_DESIGN;
    return buildDeathZoneCore();
  }
  /* 种子图：固定尺寸的**不规则岛**（用户 m12363：边界是水、尺寸不再随机）。
     做法见 game/51-island.js 顶部注释：岛边不是墙，是"不可走区域"。 */
  const W = 9000, H = 9000;   /* 矩形种子图的边长（岛已停用，这个尺寸只决定"图多大"） */
  dzSideUsed = W;
  DZ_W = DZ_DESIGN; DZ_H = DZ_DESIGN;
  const L = buildDeathZoneCore();
  DZ_W = W; DZ_H = H;
  /* 6000² 的核心块居中摆进 9500² 的包围盒 */
  const ox = Math.round((W - DZ_DESIGN) / 2), oy = Math.round((H - DZ_DESIGN) / 2);
  dzShiftCore(L, ox, oy);
  L.w = W; L.h = H;
  /* 生成岛：超椭圆 + 海湾，核心块四角保证在陆地上 */
  dzIslandMake();
  /* 面积系数按**陆地**算，不按包围盒（否则海湾一深，同样人数挤在小陆地上） */
  dzAreaUsed = Math.min(1.45, Math.max(1, dzAreaK(W, H) * dzLandK()));   /* 封顶：大图也不能刷出 800 人 */
  /* 边框（包围盒最外圈）留着当兜底，视觉上被海水盖住 */
  L.walls = L.walls.filter(w => !w._dzEdge);
  L.walls.push({ x:0, y:0, w:W, h:DZ_T, _dzEdge:1 });
  L.walls.push({ x:0, y:H - DZ_T, w:W, h:DZ_T, _dzEdge:1 });
  L.walls.push({ x:0, y:0, w:DZ_T, h:H, _dzEdge:1 });
  L.walls.push({ x:W - DZ_T, y:0, w:DZ_T, h:H, _dzEdge:1 });
  /* 撤离点：三个方向各一个。岛图往岸里收 200px；矩形图直接按比例摆在南/东/北三条边上 */
  if (typeof dzIsland !== 'undefined' && dzIsland){
    const cx0 = dzIsland.cx, cy0 = dzIsland.cy, R = ISLAND_A * 1.25;
    const dirs = [[0, 1], [1, 0], [0, -1]];
    L.dzExtracts = dirs.map(function(d){
      const pt = dzPolyClamp(cx0 + d[0] * R, cy0 + d[1] * R, dzIsland.poly, 200);
      return { x: Math.round(pt.x - 80), y: Math.round(pt.y - 60), w: 160, h: 120 };
    });
  } else {
    L.dzExtracts = [
      { x: Math.round(W / 2 - 80), y: Math.round(H - 620), w: 160, h: 120 },
      { x: Math.round(W - 620),    y: Math.round(H / 2 - 60), w: 160, h: 120 },
      { x: Math.round(W / 2 - 80), y: Math.round(500), w: 160, h: 120 }
    ];
  }
  L.extract = { x:-9000, y:-9000, w:10, h:10 };
  /* 物资堆按陆地面积放大 */
  L.pileSpawn = { count: [Math.max(55, Math.round(55 * dzAreaUsed)),
                          Math.max(75, Math.round(75 * dzAreaUsed))], margin: 220 };
  /* 外圈补房子（dzPlace 已经会拒绝落海的房子） */
  dzExtend(L, dzAreaUsed, { x: ox, y: oy, w: DZ_DESIGN, h: DZ_DESIGN });
  /* 兜底：核心块里贴着岸线的那几件（墙/门/家具/房间）如果中心已经落水，直接摘掉 */
  const _onLandC = function(o, pad){
    const cxp = (o.x !== undefined ? o.x : 0) + (o.w !== undefined ? o.w / 2 : 0);
    const cyp = (o.y !== undefined ? o.y : 0) + (o.h !== undefined ? o.h / 2 : 0);
    return dzOnLand(cxp, cyp, pad || 0);
  };
  L.walls = L.walls.filter(function(o){ return o._dzEdge || _onLandC(o, -10); });
  L.doors = L.doors.filter(function(o){ return _onLandC(o, -10); });
  L.rooms = (L.rooms || []).filter(function(o){ return _onLandC(o, -20); });
  L.brk = (L.brk || []).filter(function(o){ return _onLandC(o, -10); });
  L.glass = (L.glass || []).filter(function(o){ return _onLandC(o, -10); });
  L.loot = (L.loot || []).filter(function(o){ return dzOnLand(o.x, o.y, -10); });
  L.decors = (L.decors || []).filter(function(o){ return dzOnLand(o.x, o.y, 0); });
  L.cameras = (L.cameras || []).filter(function(o){ return dzOnLand(o.x, o.y, 0); });
  L.dzZones = (L.dzZones || []).filter(function(o){ return _onLandC(o, -40); });
  L.roads = (L.roads || []).filter(function(o){ return _onLandC(o, -60); });
  /* 出生点可能正好在岸边（用户要的是"固定尺寸的岛"），挪进陆地 */
  if (!dzOnLand(L.start.x, L.start.y, 120)){
    const s0 = dzLandSpot(L.start.x, L.start.y, 140);
    L.start = dzFixSpawnPt(L, { x: Math.round(s0.x), y: Math.round(s0.y) });
  }
  return L;
}

/* 按区铺驻军：军事区和庄园最凶，城区次之，打野最软 */
function dzPopulate(L){
  /* 出生点周围留一圈空的：小刀开局，出生就被一群人围着是没法玩的 */
  const S = L.start || { x: 620, y: 5420 };
  const SAFE_R = 720 * Math.sqrt(Math.max(1, (dzAreaUsed || 1)));
  const far = (x, y) => dist(x, y, S.x, S.y) > SAFE_R;
  /* 尺寸决定内容规模：面积翻倍人就更多，但按 0.65 次方放缓（不然 14000² 会到 660 只，掉帧） */
  const ek = Math.max(1, Math.min(3.2, Math.pow(dzAreaUsed || 1, 0.65)));
  const N = (v) => Math.max(1, Math.round(v * ek));
  const plan = [
    { zone:'mil',    n:N(30), mix:['spec','spec','specFlank','rocketman','grunt'] },
    { zone:'manor',  n:N(16), mix:['spec','specFlank','grunt','rocketman'] },
    { zone:'citySW', n:N(9),  mix:['grunt','grunt','spec','grunt'] },
    { zone:'citySE', n:N(9),  mix:['grunt','spec','grunt','grunt'] },
    { zone:'cityNW', n:N(9),  mix:['grunt','grunt','spec','grunt'] }
  ];
  const byKey = {};
  for (const z of L.dzZones) byKey[z.key] = z;
  for (const p of plan){
    const z = byKey[p.zone];
    if (!z) continue;
    for (let i = 0; i < p.n; i++){
      const spot = safeSpot(L, { x: z.x + 60 + arenaRandom() * (z.w - 120),
                                 y: z.y + 60 + arenaRandom() * (z.h - 120) }, 18);
      if (!far(spot.x, spot.y)) continue;
      const kind = p.mix[i % p.mix.length];
      dzAddEnemy(spot.x, spot.y, kind);
    }
  }

  /* 打野：32 → 14。而且不再撒在空地上 —— 人贴着散房站（房子旁边、屋后），
     空地上遇到一堆散兵只会变成"边跑边挨枪"，人堆在建筑里才有攻楼的味道。 */
  /* 打野第一层：把整张图按 5×5 切成格子，每格中间（带抖动）放一个人。
     这样"出了五块区域就没人"的问题从根上没了 —— 不管往哪个方向走，走一千米必然撞上人。
     落在城区/军事区/庄园格子里的人跳过（那边已经有驻军，别叠成一堆）。 */
  const G = Math.max(5, Math.min(8, Math.round(5 * Math.sqrt(ek)))), cw = DZ_W / G, ch = DZ_H / G;
  const inAnyZone = (x, y) => {
    for (const z of L.dzZones){
      if (x > z.x - 40 && x < z.x + z.w + 40 && y > z.y - 40 && y < z.y + z.h + 40) return true;
    }
    return false;
  };
  let wild = 0;
  for (let gy = 0; gy < G; gy++){
    for (let gx = 0; gx < G; gx++){
      const ax = (gx + 0.5) * cw + rand(-170, 170);
      const ay = (gy + 0.5) * ch + rand(-170, 170);
      if (inAnyZone(ax, ay)) continue;
      const spot = safeSpot(L, { x: ax, y: ay }, 18);
      if (!far(spot.x, spot.y)) continue;
      dzAddEnemy(spot.x, spot.y, arenaRandom() < 0.8 ? 'grunt' : 'spec');
      wild++;
    }
  }

  /* 四边哨：格子在正中间，所以最外圈会漏掉一圈边。
     沿四条边每隔 ~1000px 站一个，保证走到地图边缘也不是无人区。 */
  const SIDE_N = Math.max(4, Math.min(8, Math.round(6 * Math.sqrt(ek))));
  for (let side = 0; side < 4; side++){
    for (let i = 0; i < SIDE_N; i++){
      const t = (i + 0.5) / SIDE_N;
      const inset = rand(200, 320);
      let px, py;
      if (side === 0){ px = t * DZ_W; py = inset; }
      else if (side === 1){ px = t * DZ_W; py = DZ_H - inset; }
      else if (side === 2){ px = inset; py = t * DZ_H; }
      else { px = DZ_W - inset; py = t * DZ_H; }
      px += rand(-90, 90); py += rand(-90, 90);
      if (inAnyZone(px, py)) continue;
      const sp = safeSpot(L, { x: px, y: py }, 18);
      if (!far(sp.x, sp.y)) continue;
      dzAddEnemy(sp.x, sp.y, arenaRandom() < 0.8 ? 'grunt' : 'spec');
      wild++;
    }
  }

  /* 打野第二层：五条路上放流动哨 —— 空地现在是"路上随时可能撞人"，
     不再是"出了五块区就安全"。每条路按长度铺 2~3 个，站在路肩。 */
  let road = 0;
  for (const r of (L.roads || [])){
    const horiz = r.w >= r.h;
    const len = horiz ? r.w : r.h;
    const n = Math.max(2, Math.round(len / 1400));
    for (let i = 0; i < n; i++){
      const d = 320 + (len - 640) * ((i + 0.5) / n) + rand(-90, 90);
      const side = (i % 2 ? 1 : -1) * rand(46, 84);
      const px = horiz ? r.x + d : r.x + r.w / 2 + side;
      const py = horiz ? r.y + r.h / 2 + side : r.y + d;
      const spot = safeSpot(L, { x: px, y: py }, 18);
      if (!far(spot.x, spot.y)) continue;
      dzAddEnemy(spot.x, spot.y, arenaRandom() < 0.8 ? 'grunt' : 'spec');
      road++;
    }
  }
}

function dzAddEnemy(x, y, kind){
  /* 岛图：落水的哨位/散兵往陆地里拉，拉不进来就不刷 */
  if (typeof dzIsland !== 'undefined' && dzIsland && !dzOnLand(x, y, 20)){
    const c = dzPolyClamp(x, y, dzIsland.poly, 60);
    x = c.x; y = c.y;
    if (!dzOnLand(x, y, 12)) return null;
  }
  const T = (typeof ENEMY_TYPES !== 'undefined' && ENEMY_TYPES[kind]) ? ENEMY_TYPES[kind] : ENEMY_TYPES.grunt;
  /* 巡逻线：只在出生点附近绕，不去追别区的人。
     主循环的巡逻分支是靠 e.wp 里多个点轮流走的 —— 只给一个点，人就站着当雕像。 */
  const wp = [[x, y]];
  const L0 = cur();
  for (let k = 0; k < 3; k++){
    const a = rand(0, TAU), rr = rand(130, 380);
    const c = (L0 && typeof safeSpot === 'function')
      ? safeSpot(L0, { x: x + Math.cos(a) * rr, y: y + Math.sin(a) * rr }, 18)
      : { x: x + Math.cos(a) * rr, y: y + Math.sin(a) * rr };
    wp.push([c.x, c.y]);
  }
  const e = {
    type: kind, x:x, y:y, r: T.r || 12, ang: rand(0, TAU),
    wp: wp, i: 0, wait: rand(0, 2),
    mode: 0, lastKnown: null, alertT: 0, sees: false, heard: false, chk: null,
    ammo: 8, fireCd: rand(0.3, 1.2), reloading: 0, muzzle: 0,
    hp: T.hp || 100, maxHp: T.hp || 100, fleeCd: 0
  };
  enemies.push(e);
  assignWeapon(e);
  e.ammo = weaponCore(e.wid).cap;
  return e;
}

/* 拿到黑匣子：三个撤离点里随机亮一个，全图敌人往那边压 */
function dzRevealExtract(L){
  const spots = L.dzExtracts || [];
  if (!spots.length) return;
  const s = spots[Math.floor(arenaRandom() * spots.length) % spots.length];
  L.extract = { x:s.x, y:s.y, w:s.w, h:s.h };
  setBark(null, '黑匣子被拿走了 —— 全部人往撤离点压！', 3.2);
}

/* 从死亡地带退出来时，把玩家自己的难度参数原样还回去（这个模式内部固定按噩梦跑） */
function dzRestoreDiff(){
  if (!dzSavedCfg) return;
  /* m32812：难度快照里带着当时的 dev / devExplicit，整体 Object.assign 回来会把
     devLeaveDz() 刚还原好的开发者模式再盖掉（面板文字与 CFG.dev 因此打架）。
     这两个开关不属于"难度参数"，原样保留当前值。 */
  const _devNow = CFG.dev, _devExpNow = CFG.devExplicit;
  Object.assign(CFG, dzSavedCfg);
  CFG.dev = _devNow; CFG.devExplicit = _devExpNow;
  diffName = dzSavedDiff || 'normal';
  dzSavedCfg = null; dzSavedDiff = '';
  try {
    buildRows();
    if (tagEl) tagEl.textContent = (DIFF_LABEL)[diffName] || '自定义';
    saveCfg();
  } catch (e){ if (typeof reportErr === 'function') reportErr('50-deathzone', e); }
}
/* m36161：进死亡地带前先放一帧加载界面。玩家抱怨的"开局卡卡的"其实是一次同步建图
   （建图 + 撒人 + 摆卡车炮塔 + 锁保险箱全在同一帧跑完），期间画面冻在上一帧上，
   看着像卡死。这里先把 state 切成 dzload、强制画一帧加载界面，下一帧再跑建图，
   跑完直接进 play —— 测试仍直连 startDeathZone()，不受影响。 */
var dzLoadOn = false;
function dzLoadPaint(){
  /* 加载期间把右下角三个 DOM 按钮藏掉，别压在加载界面上；进 play 后各自由自己的 sync 恢复 */
  try{
    ["btnNotice","btnFull","btnSettings"].forEach(function(id){
      var el = document.getElementById(id);
      if (el && el.style.display !== "none") el.style.display = "none";
    });
  }catch(e){}
  try{    ctx.setTransform(1,0,0,1,0,0);
    ctx.fillStyle = "#05070a"; ctx.fillRect(0,0,W,H);
    const cx = W/2, cy = H/2;
    ctx.save(); ctx.textAlign = "center";
    ctx.fillStyle = "rgba(150,190,225,0.92)";
    ctx.font = 'bold 34px "Microsoft YaHei",sans-serif';
    ctx.fillText("死亡地带", cx, cy - 46);
    ctx.fillStyle = "rgba(130,150,170,0.72)";
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText("正在生成地图 · 敌人正在布防", cx, cy - 14);
    /* 来回跑的一条进度光 */
    const bw = 260, bx = cx - bw/2, by = cy + 12;
    ctx.fillStyle = "rgba(255,255,255,0.10)";
    ctx.fillRect(bx, by, bw, 4);
    const t = (typeof performance !== "undefined" ? performance.now() : Date.now()) / 1000;
    const p = (t % 1.15) / 1.15;
    const ww = 60;
    const px = bx + (bw - ww) * (p < 0.5 ? p * 2 : (1 - p) * 2);
    const g = ctx.createLinearGradient(px, 0, px + ww, 0);
    g.addColorStop(0, "rgba(120,200,255,0)");
    g.addColorStop(0.5, "rgba(150,215,255,0.95)");
    g.addColorStop(1, "rgba(120,200,255,0)");
    ctx.fillStyle = g; ctx.fillRect(px, by, ww, 4);
    ctx.fillStyle = "rgba(110,130,150,0.5)";
    ctx.font = '11px "Microsoft YaHei",sans-serif';
    ctx.fillText("这一步只做一次，之后不会再卡", cx, by + 34);
    ctx.restore();
  }catch(e){}
}
function dzStartWithLoading(run){
  dzLoadOn = true;
  state = "dzload";
  dzLoadPaint();
  requestAnimationFrame(function(){
    requestAnimationFrame(function(){
      try{ if (typeof run === "function") run(); else startDeathZone(); }
      catch(e){ console.error("[DZLOAD]", e); if (typeof reportErr === "function") reportErr("50-deathzone", e); }
      dzLoadOn = false;
      if (state === "dzload") state = "play";
      try{
        ["btnFull","btnSettings"].forEach(function(id){
          var el = document.getElementById(id);
          if (el) el.style.display = "";
        });
        if (typeof noticeSyncVisible === "function") noticeSyncVisible();
      }catch(e){}
    });
  });
}
function startDeathZone({benchmark = false} = {}){
  devEnterDzTier(dzTier, benchmark);
  /* 换难度就把上一档的随身物品退回它自己的仓库 —— 结算界面之外的第二道闸：
     玩家可以"在 A 档取出、切到 B 档直接开局带进去"，那等于把两档仓库打通了。 */
  if (!benchmark && typeof stashSelectTier === 'function') stashSelectTier(dzTier);
  else if (!benchmark && typeof stashKitTier !== 'undefined') stashKitTier = dzTier;
  dzLvl = null; customLvl = null; arenaLvl = null; ar = null;
  thunderMaskT = 0; thunderTailT = 0;
  /* 这个模式固定按噩梦那一档的人机参数跑（视野/枪法/记性），
     伤害另算：见 rules.dmgMode/dmgMul。退出时 dzRestoreDiff() 把玩家的原难度还回去。 */
  if (!dzSavedCfg){ dzSavedCfg = Object.assign({}, CFG); dzSavedDiff = diffName; }
  applyPreset(dzTier === 'core' ? 'hard' : dzTier, false, !benchmark);   /* 硬核：人机按困难档跑，伤害另算 */
  devApplyDzTier();
  /* 先定种子再建房：生成阶段也要走种子流，否则同种子出不来同一张图 */
  if (!dzSeedFixed || !dzSeed) dzSeed = (Math.random() * 4294967296) >>> 0;
  dzSeedUsed = dzSeed >>> 0;
  arenaSeedRandom(dzSeedUsed);
  dzRngActive = true;      /* 一直开到 startDeathZone 结束：建图、铺人、撒钥匙、布景都要可复现 */
  const L = buildDeathZone();
  /* 出生点：四个角 + 四条边的中点，随机挑一个落地的。
     落在墙里/贴在楼边就换下一个 —— 小刀开局，出生在墙里直接卡死，出生在楼里直接被人堵门。
     挑完再 dzPopulate，那边会照着 L.start 空出 900px，所以不会刷到脸上。 */
  {
    const W0 = L.w, H0 = L.h, pd = 420;
    const cand = [[pd, H0 - pd], [W0 - pd, H0 - pd], [pd, pd], [W0 - pd, pd],
                  [W0 / 2, H0 - 240], [W0 - 240, H0 / 2], [W0 / 2, 240], [240, H0 / 2]];
    const solid = (x, y) => {
      for (const w of L.walls){
        if (w.dead) continue;
        if (x >= w.x - 30 && x <= w.x + w.w + 30 && y >= w.y - 30 && y <= w.y + w.h + 30) return true;
      }
      return false;
    };
    /* 岛图：候选点先过一遍"在陆地上"的筛（原来是按矩形四角/边中点给的） */
    const landOK = (c) => (typeof dzIsland === 'undefined' || !dzIsland) ? true : dzOnLand(c[0], c[1], 120);
    const ok = cand.filter(c => !solid(c[0], c[1]) && landOK(c));
    let pickS = ok.length ? ok[Math.floor(arenaRandom() * ok.length) % ok.length] : null;
    if (!pickS){
      if (typeof dzLandSpot === 'function' && typeof dzIsland !== 'undefined' && dzIsland){
        const sp0 = dzLandSpot(L.start ? L.start.x : W0 / 2, L.start ? L.start.y : H0 / 2, 140);
        pickS = [sp0.x, sp0.y];
      } else pickS = [420, 5580];
    }
    /* 选完再清一次场：70px 内不许有墙，否则一开局就贴墙/在屋里，敌人视线也被挡 */
    const clearAt = (x, y) => {
      for (const q of L.walls){
        if (q.dead) continue;
        if (x > q.x - 70 && x < q.x + q.w + 70 && y > q.y - 70 && y < q.y + q.h + 70) return false;
      }
      /* 也不许落在任何屋顶下（进屋出生=四面墙，敌人看不见你、你也看不见人） */
      for (const rf of (L.roofs || [])){
        if (x > rf.x + 8 && x < rf.x + rf.w - 8 && y > rf.y + 8 && y < rf.y + rf.h - 8) return false;
      }
      for (const r of (L.rooms || [])){
        /* 跳过"兜底整间"（把整张图都算成一间屋的那种） */
        if (r.w * r.h > L.w * L.h * 0.3) continue;
        if (x > r.x - 40 && x < r.x + r.w + 40 && y > r.y - 40 && y < r.y + r.h + 40) return false;
      }
      return true;
    };
    if (!clearAt(pickS[0], pickS[1])){
      let best = null;
      for (let r = 80; r <= 520 && !best; r += 80){
        for (let k = 0; k < 16 && !best; k++){
          const ang = (k / 16) * Math.PI * 2;
          const nx = pickS[0] + Math.cos(ang) * r, ny = pickS[1] + Math.sin(ang) * r;
          if (nx < 120 || ny < 120 || nx > L.w - 120 || ny > L.h - 120) continue;
          if (clearAt(nx, ny)) best = [nx, ny];
        }
      }
      if (best) pickS = best;
    }
    L.start = { x: Math.round(pickS[0]), y: Math.round(pickS[1]) };
  }
  /* 经典图也过一遍：经典图的 620,5420 是写死的，挪过房子/改过可拆墙之后也可能压到屋里 */
  L.start = dzFixSpawnPt(L, L.start);
  dzLvl = L;
  enemies = []; poolClearView(bullets); grenades = []; smokes = []; loots = [];
  trucks.length = 0;
  dzSiegeReset();
  intro = null;                   /* 别把上一关的开场字幕带进来 */
  state = 'play';
  L._safesDone = 0;   /* 本局重新摆一次保险箱（真的摆在 initBreakables 里） */
  const dzSafeCount = 0;   /* 占位：真实数量在 reset() 之后从 L.dzSafeCount 取 */

  /* 出发前整理拿的东西/穿的东西：reset() 会重建 player，先拍快照 */
  if (typeof stashExtracted !== 'undefined') stashExtracted = false;   /* m24812：新开一局，撤离标记作废 */
  const _preKit = (!benchmark && typeof stashSnapshotKit === 'function') ? stashSnapshotKit() : null;
  /* 最后一次校正出生点：必须紧挨着 reset() —— reset 里就会照着 L.start 造玩家，
     放到它后面改就没意义了（这一条踩过一次）。 */
  L.start = dzFixSpawnPt(L, L.start);
  reset();                        /* reset 里的 cur() 现在指向 dzLvl */
  if (_preKit) stashApplyKit(_preKit);   /* 把整理好的背包/装备贴回来 */
  /* 初始小背包只在真正入场后兜底发放：仓库阶段保持空装备栏；
     已经从仓库穿了战术包/远征包时这里不会覆盖。 */
  if (!benchmark && typeof stashEnsureRunBag === 'function') stashEnsureRunBag();

  /* 黑匣子：锁在某一只保险箱里。箱子在 reset() 之前就摆进 L.walls 了，
     但 reset 里的 coverMake 会把带 t 的墙换成正式对象，所以必须在这里重新认一遍再打标记。 */
  const _allSafes = L.walls.filter(w => w.lootKind === 'safe');
  /* 只挑"没被别的墙压住"的箱子：可拆掩体展开后可能比登记尺寸大，偶尔会盖到箱角 */
  const safes = _allSafes.filter(w => !L.walls.some(o => o !== w && !o.dead && !o.safeInner &&
    w.x + w.w > o.x + 1 && w.x < o.x + o.w - 1 && w.y + w.h > o.y + 1 && w.y < o.y + o.h - 1));
  let safePick = null;
  if (safes.length){
    const _keyOf = (q) => Math.round(q.x) + ',' + Math.round(q.y);
    /* 哈希挑：确定、不连刷、不吃随机流。带上"第几局打本模式"的序号，
       否则同一个尺寸下每把都是同一只箱子（测试里 30 把只落到 2 处就被抓到了）。 */
    dzBoxSeq = (dzBoxSeq + 1) >>> 0;
    let _seed = (((L.w * 7919) ^ (L.h * 104729) ^ (dzBoxSeq * 2654435761)) >>> 0);
    for (let i = 0; i < dzBoxPrevKey.length; i++) _seed = (_seed * 31 + dzBoxPrevKey.charCodeAt(i)) >>> 0;
    let bi = _seed % safes.length;
    if (safes.length > 1 && _keyOf(safes[bi]) === dzBoxPrevKey) bi = (bi + 1) % safes.length;
    dzBoxPrev = bi;
    dzBoxPrevKey = _keyOf(safes[bi]);
    safePick = safes[bi];
    for (const w of _allSafes) w.blackbox = false;   /* 上一把的标记别留着 */
    safePick.blackbox = true;
    safePick.noKey = true;      /* 这只不用万能钥匙：赢的那扇门不该再压一把钥匙 */
  }
  if (!safePick){
    /* 极端情况兜底（某些地图一间合格房间都没有）：退回到出生点附近放一只 */
    const bx = Math.max(140, Math.min(L.w - 200, (L.start ? L.start.x : L.w / 2) + 260));
    const by = Math.max(140, Math.min(L.h - 200, (L.start ? L.start.y : L.h / 2) + 200));
    safePick = (typeof coverMake === 'function')
      ? coverMake('safe', { x:bx, y:by, w:46, h:42 })
      : { t:'safe', cov:'safe', x:bx, y:by, w:46, h:42, loot:true, lootKind:'safe', label:'保险箱' };
    safePick.blackbox = true; safePick.noKey = true;
    L.walls.push(safePick);
  }
  dzBoxPos = { x: safePick.x + 23, y: safePick.y + 21 };
  const _zbz = (typeof dzZoneAt === 'function') ? dzZoneAt(dzBoxPos.x, dzBoxPos.y) : null;
  dzBoxTag = _zbz ? _zbz.name : '附近';
  dzBoxHintR = Math.round(Math.max(900, Math.min(1500, L.w * 0.11)));
  /* 商人先在开局摆好：开地图时游戏是暂停的，traderTick 不跑，不提前摆地图上就没有商 */
  if (typeof traderSpawn === 'function'){ try { traderSpawn(); } catch (e){ if (typeof reportErr === 'function') reportErr('50-deathzone', e); } }
  logInfo('dz', '黑匣子在保险箱里 · ' + dzBoxTag + ' · 全场保险箱 ' + (L.dzSafeCount || safes.length) + ' 只');
  dzPopulate(L);
  /* 人数兜底：随机图面积一放大容易刷爆（曾到 499），直接压到 380 */
  while (enemies.length > 380) enemies.pop();
  /* 玻璃窗体检：新大模板自带窗，偶尔会正好压在隔壁楼的墙上 —— 那就不再是"窗"了，
     直接恢复成实墙（几何不变，只是不再透光），免得出现"窗里还有一堵墙"的怪东西 */
  for (const g of L.walls){
    if (!g.glass || g.dead) continue;
    for (const w of L.walls){
      if (w === g || w.glass || w.dead) continue;
      if (g.x + g.w > w.x && g.x < w.x + w.w && g.y + g.h > w.y && g.y < w.y + w.h){ g.glass = false; break; }
    }
  }

  /* 车落地前最后过一遍：谁压到墙就把谁往外挪一格。车是实心块，压进墙里会卡住寻路 */
  for (const t of (L.dzTrucks || [])){
    for (let ring = 0; ring < 10; ring++){
      let bad = false;
      for (const w of L.walls){
        if (w.dead) continue;
        if (t.x + 46 > w.x - 10 && t.x - 46 < w.x + w.w + 10 && t.y + 34 > w.y - 10 && t.y - 34 < w.y + w.h + 10){ bad = true; break; }
      }
      if (!bad) break;
      const a2 = (ring / 10) * TAU, d2 = 60 + ring * 45;
      t.x = Math.round(t.x + Math.cos(a2) * d2);
      t.y = Math.round(t.y + Math.sin(a2) * d2);
    }
  }
  for (const t of (L.dzTrucks || [])) dzSpawnTruck(t, t.kind);   /* 皮卡/装甲皮卡靠 t.kind 选型 */
  for (const p of (L.dzTurrets || [])) dzAddTurret(L, p.x, p.y);
  /* 出生点最后一道：车/炮塔刚才那一圈"压墙外挪"可能把它们挪到了玩家脚底下（用户 m20965）。
     这里按实际落地坐标再推一次，玩家往反方向挪 230px。 */
  if (player && typeof safeSpot === 'function'){
    for (const t of trucks){
      if (!t || t.gone || t.wreck) continue;
      if (dist(player.x, player.y, t.x, t.y) > 170) continue;
      const a2 = Math.atan2(player.y - t.y, player.x - t.x) || 0.7;
      const sp2 = safeSpot(L, { x: t.x + Math.cos(a2) * 240, y: t.y + Math.sin(a2) * 240 }, 20);
      player.x = Math.round(sp2.x); player.y = Math.round(sp2.y); player.grace = 3;
      break;
    }
    for (const w2 of (L.walls || [])){
      if (!w2 || !w2.rocketTurret || w2.dead) continue;
      const cx2 = w2.x + w2.w / 2, cy2 = w2.y + w2.h / 2;
      if (dist(player.x, player.y, cx2, cy2) > 200) continue;
      const a3 = Math.atan2(player.y - cy2, player.x - cx2) || 0.7;
      const sp3 = safeSpot(L, { x: cx2 + Math.cos(a3) * 270, y: cy2 + Math.sin(a3) * 270 }, 20);
      player.x = Math.round(sp3.x); player.y = Math.round(sp3.y); player.grace = 3;
      break;
    }
  }
  /* 黑匣子：不再是"地图上找个点摆着" —— 它锁在一只保险箱里。
     以前那八处候选点用的是设计空间的坐标，随机图把核心块整体平移之后，
     点就落在平移前的空地上（甚至出图），所以会看到"黑匣子在地图外面"。
     现在保险箱是跟着房间走的：房间平移到哪，箱子就在哪。 */
  /* 保险箱与黑匣子见上面的 startDeathZone 开头（必须在 reset() 之前放进 L.walls） */
  /* 金库与钥匙：锁 8 间值钱房间，地上撒 4 把钥匙 —— 钥匙是「选哪扇门」的资源，不是开全图的万能卡。
     保险箱所在的那间房不能上锁（不然要两把钥匙才能拿一件东西）。 */
  dzLockVaults(L, dzBoxPos, 8);
  dzScatterKeys(L, 4);
  state = 'play';
  player.hasIntel = false;   /* 情报每局重新换：商人那里是这一局的唯一来源 */
  player.grace = 3;
  setMsg('死亡地带 ' + L.w + '×' + L.h +
    (dzMapMode === 'random' ? ' · 种子 ' + dzSeedUsed : '') +
    ' · 黑匣子锁在某只保险箱里 · 找抽奖商人换情报，按 M 看范围 · 拿到就撤离', 4.8);
  logInfo('dz', '进入死亡地带 · 黑匣子保险箱 @ ' + Math.round(dzBoxPos.x) + ',' + Math.round(dzBoxPos.y));
  player.loot = 0;
  dzRngActive = false;     /* 生成结束，之后回到普通随机（战斗随机性不锁死） */
}

/* 黑匣子的落点不能在任何「模板自带锁」的房间里：
   那几个房间（军械室/药房/后仓/三号房）的门是 data/roomTemplates.js 写死的 isLocked，
   黑匣子落进去而钥匙又正好没刷出来 = 这一把直接废。落进去就往外挪到房间外沿。 */
function dzBoxSafe(L, p){
  let sp = safeSpot(L, p, 16);
  for (let k = 0; k < 8; k++){
    let room = null;
    for (const r of (L.rooms || [])){
      if (!r.locked) continue;
      if (sp.x >= r.x && sp.x <= r.x + r.w && sp.y >= r.y && sp.y <= r.y + r.h){ room = r; break; }
    }
    if (!room) return sp;
    const out = [
      { x: room.x + room.w / 2, y: room.y - 46 },
      { x: room.x + room.w / 2, y: room.y + room.h + 46 },
      { x: room.x - 46, y: room.y + room.h / 2 },
      { x: room.x + room.w + 46, y: room.y + room.h / 2 }
    ];
    sp = safeSpot(L, out[k % out.length], 16);
  }
  return sp;
}

/* 锁起来的金库：让万能钥匙在这个模式里真的有意义。
   模板里 locked:true 的隔断门本来就带 isLocked（见 data/roomTemplates.js），
   这里再把军械室/药房/后仓/库房/经理室这类值钱房间的入口锁上，控制在 max 扇，
   让钥匙变成「先开哪一个」的选择，而不是一把开全图。
   黑匣子所在的房间永远不锁 —— 没钥匙就拿不到匣子 = 卡死。 */
const DZ_VAULT_ROOMS = { '军械室':1, '药房':1, '后仓':1, '库房':1, '经理室':1 };
/* ---- 保险箱：只在"值钱的房间里"放，数量少但不能少到离谱 ----
   为什么按房间放：保险箱是"屋子里那一格"的东西，摆在野地里就成了路标；
   挑房间时只认 danger>=3 的区（军事区/庄园/城区），并且跳过上锁房间
   （锁着的门后面放保险箱 = 玩家要两把钥匙才能拿一件东西）。 */
/* 出生点体检：矩形图与随机图共用。
   离墙 70px、不在屋里（跳过兜底整间）、至少两个方向 160px 内看得出去 —— 否则沿半径 80..560 换位。 */
/* 出生点"坏不坏"：在屋顶下 / 在真房间里 / 贴墙 / 压墙 —— 只有坏了才去挪。
   好点就原地不动，免得经典图那种手工摆好的出生位被无端改掉。 */
function dzSpawnBad(L, p){
  if (!p) return true;
  const x = p.x, y = p.y;
  if (x < 40 || y < 40 || x > L.w - 40 || y > L.h - 40) return true;
  for (const rf of (L.roofs || [])){
    if (x > rf.x + 8 && x < rf.x + rf.w - 8 && y > rf.y + 8 && y < rf.y + rf.h - 8) return true;
  }
  for (const r of (L.rooms || [])){
    if (r.w * r.h > L.w * L.h * 0.3) continue;      /* 跳过"兜底整间" */
    if (x > r.x - 6 && x < r.x + r.w + 6 && y > r.y - 6 && y < r.y + r.h + 6) return true;
  }
  for (const q of (L.walls || [])){
    if (q.dead) continue;
    if (x > q.x - 24 && x < q.x + q.w + 24 && y > q.y - 24 && y < q.y + q.h + 24) return true;
  }
  for (const b of (L.brk || [])){
    if (x > b.x - 24 && x < b.x + b.w + 24 && y > b.y - 24 && y < b.y + b.h + 24) return true;
  }
  /* 停机坪那排装甲车、南门两门炮塔（用户 m20965：曾经出生在车队正中间，一睁眼就被扫射）。
     这两样都是 reset() 之后才落地（trucks[] 与 L.walls），判定时只能读设计数据。 */
  for (const t of (L.dzTrucks || [])){
    if (Math.abs(x - t.x) < 210 && Math.abs(y - t.y) < 170) return true;
  }
  for (const tp of (L.dzTurrets || [])){
    if (Math.abs(x - tp.x) < 230 && Math.abs(y - tp.y) < 230) return true;
  }
  /* 军事重区 / 庄园：小刀开局出生在重装营区里，等于一睁眼就被围 */
  for (const z of (L.dzZones || [])){
    if ((z.danger || 0) < 4) continue;
    if (x > z.x - 60 && x < z.x + z.w + 60 && y > z.y - 60 && y < z.y + z.h + 60) return true;
  }
  return false;
}

function dzFixSpawnPt(L, pt){
  const okAt = (x, y) => {
    /* 离地图边至少 16%：边界墙本身是厚矩形（站太靠边会生成在墙里），
       而且地图四周有一圈黑雾，出生在雾里第一眼什么都看不见。 */
    const _m = Math.min(900, Math.max(150, Math.min(L.w, L.h) * 0.06));
    if (x < _m || y < _m || x > L.w - _m || y > L.h - _m) return false;
    for (const q of (L.walls || [])){
      if (q.dead) continue;
      if (x > q.x - 70 && x < q.x + q.w + 70 && y > q.y - 70 && y < q.y + q.h + 70) return false;
    }
    for (const r of (L.rooms || [])){
      if (r.w * r.h > L.w * L.h * 0.3) continue;
      if (x > r.x - 40 && x < r.x + r.w + 40 && y > r.y - 40 && y < r.y + r.h + 40) return false;
    }
    /* 屋顶下就是屋里。散房（网格撒的那些）不一定登记成 room，
       但它们都有 roof —— 只查 rooms 会漏掉这类"出生在别人家客厅"的情况。 */
    for (const rf of (L.roofs || [])){
      if (x > rf.x + 8 && x < rf.x + rf.w - 8 && y > rf.y + 8 && y < rf.y + rf.h - 8) return false;
    }
    for (const t of (L.dzTrucks || [])){
      if (Math.abs(x - t.x) < 240 && Math.abs(y - t.y) < 200) return false;
    }
    for (const tp of (L.dzTurrets || [])){
      if (Math.abs(x - tp.x) < 260 && Math.abs(y - tp.y) < 260) return false;
    }
    for (const z of (L.dzZones || [])){
      if ((z.danger || 0) < 4) continue;
      if (x > z.x - 80 && x < z.x + z.w + 80 && y > z.y - 80 && y < z.y + z.h + 80) return false;
    }
    return true;
  };
  const openDirs = (x, y) => {
    let n = 0;
    for (let k = 0; k < 8; k++){
      const a = k / 8 * Math.PI * 2;
      if (typeof losBlocked === 'function' && losBlocked(x, y, x + Math.cos(a) * 170, y + Math.sin(a) * 170)) continue;
      n++;
    }
    return n;
  };
  /* 好点就原样返回：四角/四边那 8 个候选点是设计好的，
     只要没压到房子/墙里就别去动它（动一下就会落到非候选位置上）。 */
  if (!dzSpawnBad(L, pt)) return pt;
  if (okAt(pt.x, pt.y) && openDirs(pt.x, pt.y) >= 2) return pt;
  let best = null, bestScore = -1;
  /* 先把近处一圈圈找完，再退到全图粗扫 —— 只搜 620px 在密集的随机图里会搜不到，
     原来那种情况会原样返回 pt（正好落在屋里）。 */
  for (let ring = 80; ring <= 2400; ring += 60){
    for (let k = 0; k < 16; k++){
      const a2 = k / 16 * Math.PI * 2;
      const x = pt.x + Math.cos(a2) * ring, y = pt.y + Math.sin(a2) * ring;
      if (!okAt(x, y)) continue;
      const sc = openDirs(x, y);
      if (sc > bestScore){ bestScore = sc; best = { x: Math.round(x), y: Math.round(y) }; }
      if (sc >= 5) return best;
    }
    if (best && bestScore >= 2) return best;
  }
  /* 全图粗扫：密集图里上面可能一个合格点都没有 */
  for (let gy = 220; gy < L.h - 220; gy += 140){
    for (let gx = 220; gx < L.w - 220; gx += 140){
      if (!okAt(gx, gy)) continue;
      const sc = openDirs(gx, gy);
      if (sc > bestScore){ bestScore = sc; best = { x: gx, y: gy }; }
      if (sc >= 5) return best;
    }
  }
  return best || pt;
}

function dzPlaceSafes(L, want, skipIdx){
  const out = [];
  /* 关卡对象跨局复用（L.walls / L.allWalls 留着上一把的箱子）：先摘干净，
     否则箱子越刷越多、旧的黑匣子标记也会留在某只箱子上。 */
  L.walls = (L.walls || []).filter(w => w.lootKind !== 'safe');
  if (L.allWalls) L.allWalls = L.allWalls.filter(w => w.lootKind !== 'safe');

  /* 候选房间：没上锁、够大（>=110×110）。
     注意**不再要求"高危区"** —— 那样会把箱子全挤在同一片城区里（实测 8 只扎堆在 900×800 范围）。
     改成"全图均匀撒"，靠下面的距离与网格配额控制密度。 */
  const rooms = [];
  for (const r of (L.rooms || [])){
    if (!r || r.locked) continue;
    if (r.w < 88 || r.h < 88) continue;   /* 保险箱 46×42 + 14 的余量，小屋也放得下 */
    rooms.push(r);
  }
  /* 打乱：坐标哈希排序，不动 arenaRandom 的随机流 */
  const _h = (q) => {
    let h = (q.x | 0) * 73856093 ^ (q.y | 0) * 19349663 ^ (q.w | 0) * 83492791 ^ (q.h | 0) * 2654435761;
    h = (h ^ (h >>> 13)) >>> 0;
    return h;
  };
  rooms.sort((p1, p2) => _h(p1) - _h(p2));

  const hit = (x, y, w, h) => {
    for (const q of L.walls){
      /* 以前这里跳过 decor，结果保险箱会直接摞在柜子/桌子上（用户报的"和某些容器重叠"） */
      if (q.dead) continue;
      if (x + w > q.x - 8 && x < q.x + q.w + 8 && y + h > q.y - 8 && y < q.y + q.h + 8) return true;
    }
    for (const q of L.brk){
      if (x + w > q.x - 8 && x < q.x + q.w + 8 && y + h > q.y - 8 && y < q.y + q.h + 8) return true;
    }
    return false;
  };
  const SW = 46, SH = 42;
  /* 密度控制两手：彼此至少 560px；再把全图切成 4×4 格，每格最多 1 只 */
  const MIN_SEP = 460;
  const CELLS = 4;
  const cellUse = {};
  const tooClose = (cx, cy) => out.some(q => {
    const dx = (q.x + SW / 2) - cx, dy = (q.y + SH / 2) - cy;
    return dx * dx + dy * dy < MIN_SEP * MIN_SEP;
  });
  const cellOf = (cx, cy) => {
    const gx = Math.max(0, Math.min(CELLS - 1, Math.floor(cx / (L.w / CELLS))));
    const gy = Math.max(0, Math.min(CELLS - 1, Math.floor(cy / (L.h / CELLS))));
    return gx + ',' + gy;
  };

  /* 分三轮放：第一轮每格最多 1 只（铺得开），不够再放宽到 2、3。
     这样大图不会只有 2 只，小图也不会满街都是。 */
  for (let pass = 1; pass <= 3 && out.length < want; pass++){
  for (const r of rooms){
    if (out.length >= want) break;
    const _cx = r.x + r.w / 2, _cy = r.y + r.h / 2;
    if (tooClose(_cx, _cy)) continue;
    const _ck = cellOf(_cx, _cy);
    if ((cellUse[_ck] || 0) >= pass) continue;
    /* 沿房间内圈转一圈找位置：先贴墙（顺手能当掩体），再试内圈 */
    let placed = null;
    const tries = [];
    for (let t = 0; t < 36; t++){
      const a = (t / 36) * Math.PI * 2;
      const cx = r.x + r.w / 2 + Math.cos(a) * (r.w / 2 - SW - 10);
      const cy = r.y + r.h / 2 + Math.sin(a) * (r.h / 2 - SH - 10);
      tries.push([Math.round(cx - SW / 2), Math.round(cy - SH / 2)]);
    }
    tries.push([r.x + 26, r.y + 26], [r.x + r.w - SW - 26, r.y + 26],
               [r.x + 26, r.y + r.h - SH - 26], [r.x + r.w - SW - 26, r.y + r.h - SH - 26]);
    for (const [x, y] of tries){
      if (x < 80 || y < 80 || x + SW > L.w - 80 || y + SH > L.h - 80) continue;
      if (hit(x, y, SW, SH)) continue;
      /* 地上的杂物堆（可走的 decor）也别压：箱子摞在垃圾上看着像穿模 */
      if (typeof piles !== 'undefined' && piles && piles.length){
        const _mx = x + SW / 2, _my = y + SH / 2;
        let _onPile = false;
        for (const _p of piles){
          const _dx = _p.x - _mx, _dy = _p.y - _my;
          if (_dx * _dx + _dy * _dy < 46 * 46){ _onPile = true; break; }
        }
        if (_onPile) continue;
      }
      placed = { x: x, y: y };
      break;
    }
    if (!placed) continue;
    /* 必须过 coverMake：drawCover 是按 w.cov 分派的，裸 {t:'safe'} 没有 cov → 世界里是空气 */
    const safe = (typeof coverMake === 'function')
      ? coverMake('safe', { x: placed.x, y: placed.y, w: SW, h: SH })
      : { t:'safe', cov:'safe', x: placed.x, y: placed.y, w: SW, h: SH, loot:true, lootKind:'safe', label:'保险箱' };
    safe.room = r.name || '';
    const _pk = cellOf(placed.x + SW / 2, placed.y + SH / 2);
    cellUse[_pk] = (cellUse[_pk] || 0) + 1;
    L.walls.push(safe);
    out.push(safe);
  }
  }
  return out;
}
function dzLockVaults(L, boxPt, max){
  let n = 0;
  const near = (r, x, y) => x >= r.x - 30 && x <= r.x + r.w + 30 && y >= r.y - 30 && y <= r.y + r.h + 30;
  for (const r of (L.rooms || [])){
    if (n >= max) break;
    if (!DZ_VAULT_ROOMS[r.name] || r.fallback) continue;
    if (boxPt && near(r, boxPt.x, boxPt.y)) continue;
    let best = null, bd = 1e9;
    for (const d of doors){
      if (d.isLocked || d.broken) continue;
      const cx = d.x + (d.w || 26) / 2, cy = d.y + (d.h || 26) / 2;
      if (!near(r, cx, cy)) continue;
      const dd = Math.abs(cx - (r.x + r.w / 2)) + Math.abs(cy - (r.y + r.h / 2));
      if (dd < bd){ bd = dd; best = d; }
    }
    if (!best) continue;
    best.isLocked = true; best.unlocked = false; best.keyId = r.name;
    n++;
  }
  return n;
}

/* 每局保证地上有几把钥匙：全撒在普通房间里，逼玩家进楼翻。
   锁着的房间本身不放（不然等于把钥匙锁在门后）。 */
function dzScatterKeys(L, n){
  const pool = [];
  for (const r of (L.rooms || [])){
    if (r.locked || r.fallback) continue;
    if (r.w < 70 || r.h < 70) continue;
    pool.push(r);
  }
  let got = 0;
  while (got < n && pool.length){
    const k = Math.floor(arenaRandom() * pool.length) % pool.length;
    const r = pool.splice(k, 1)[0];
    const sp = safeSpot(L, { x: r.x + r.w / 2, y: r.y + r.h / 2 }, 14);
    loots.push({ x: sp.x, y: sp.y, taken: false, kind: 'key', cool: 0 });
    got++;
  }
  return got;
}

/* 战斗，爽！！的关卡对象：复用一张现成地图的墙体，其它全都清空 */
function buildArenaLevel(src){
  doors = [];            /* 上一关（比如 2-4 自动门）的门不许带进割草 */
  return {
    name: src.name + ' · 割草', w: src.w, h: src.h, theme: src.theme || 'dark',
    arena: true, ver: 2, chapter: 0, devOnly: true,
    /* 割草里玩家一把都不缺：Uzi 泼水 / 霰弹贴脸 / AR 中远距离点名 / 火箭筒开团 / 小刀（大刀先不给）。
       AR 跟霰弹同档给，F 切枪按 WEAPON_ORDER 排出来是 霰弹 → Uzi → AR → 刀 → 火箭筒。
       火箭筒在这里没有备弹这个概念：开局 0 发，弹药从「这一局拿到的卡牌数」里来，
       池子逻辑见 arenaRocketMax() / arenaRocketLeft()。 */
    weapons: ['rifle','shotgun','ar','knife','rpg'],
    startMeds: 3, startSmokes: 2, enemyHp: 100, dropGuns: true, healHint: true,
    rules: { mode:'stealth', fog:false, nightGlow:130, hearK:1, walkDelay:0.12 },
    start: { x: src.w/2, y: src.h/2 },
    extract: { x:-9000, y:-9000, w:10, h:10 },
    /* 楼里的可破坏墙不带过来：割草要的是干净的场地 */
    walls: src.walls.filter(w => !w.brk).map(w => ({ x:w.x, y:w.y, w:w.w, h:w.h })),
    loot: [], slots: [], cameras: [], drones: []
  };
}

function arenaSrc(match){
  for (let i=0;i<LEVELS.length;i++){
    const nm = LEVELS[i].name || '';
    if (nm.indexOf(match) === 0) return LEVELS[i];
  }
  return LEVELS[0];
}


/* 三个存档位：入口只能读取或新建，覆盖只出现在手动保存流程。 */
let arenaSlotUI = null;
function arenaSlotResultOK(result){ return result === true || !!(result && result.ok === true); }
function arenaSlotResultError(result, fallback){
  return result && typeof result.error === 'string' ? result.error : fallback;
}
function arenaRefreshSlots(){
  if (arenaSlotUI) arenaSlotUI.slots = Array.from({length: ARENA_SLOT_COUNT}, (_, i) => arenaReadSlot(i));
}
function arenaOpenSlots(mode){
  mode = mode === 'manual' ? 'manual' : 'entry';
  if (mode === 'manual' && (!ar || ar.over || state !== 'play' || !player || player.hp <= 0)) return false;
  arenaSlotUI = { mode, confirm: null, index: -1, error: '', slots: [] };
  uiButtons = [];
  mouse.down = false; mouse.fire = false;
  for (const k in keys) keys[k] = false;
  if (mode === 'entry'){
    confirmBack = false;
    state = 'arenaSlots';
  }
  arenaRefreshSlots();
  return true;
}
function arenaCloseSlots(){
  if (!arenaSlotUI) return;
  const entry = arenaSlotUI.mode === 'entry';
  arenaSlotUI = null;
  uiButtons = [];
  mouse.down = false; mouse.fire = false;
  if (entry) state = 'arcade';
}
function arenaSlotCancel(){
  if (!arenaSlotUI) return;
  if (arenaSlotUI.confirm){
    uiButtons = [];
    arenaSlotUI.confirm = null;
    arenaSlotUI.index = -1;
    arenaSlotUI.error = '';
  } else arenaCloseSlots();
}
function arenaSlotChoose(index){
  if (!arenaSlotUI || !arenaValidSlot(index)) return;
  const snap = arenaReadSlot(index);
  uiButtons = [];
  arenaSlotUI.slots[index] = snap;
  arenaSlotUI.index = index;
  arenaSlotUI.error = '';
  if (arenaSlotUI.mode === 'manual'){
    if (snap) arenaSlotUI.confirm = 'overwrite';
    else arenaSlotSave(index);
  } else if (snap){
    arenaSlotUI.confirm = 'load';
  } else {
    arenaActiveSlot = index;
    arenaSlotUI = null;
    state = 'arenaPick';
  }
}
function arenaSlotSave(index){
  if (!arenaSlotUI || arenaSlotUI.mode !== 'manual') return false;
  const result = arenaWriteSlot(index);
  if (!arenaSlotResultOK(result)){
    arenaSlotUI.error = arenaSlotResultError(result, '保存失败，原有存档已保留。');
    return false;
  }
  arenaCloseSlots();
  setMsg('已保存到存档位 ' + (index + 1), 2.2);
  return true;
}
function arenaSlotLoad(index){
  if (!arenaSlotUI || arenaSlotUI.mode !== 'entry' || arenaSlotUI.confirm !== 'load' || arenaSlotUI.index !== index) return false;
  const result = arenaLoadSlot(index);
  if (!arenaSlotResultOK(result)){
    arenaSlotUI.error = arenaSlotResultError(result, '存档无法读取，请重新选择。');
    arenaSlotUI.confirm = null;
    arenaRefreshSlots();
    return false;
  }
  arenaSlotUI = null;
  return true;
}
function arenaSlotAskDelete(index){
  if (!arenaSlotUI || arenaSlotUI.mode !== 'entry' || !arenaReadSlot(index)) return;
  arenaSlotUI.confirm = 'delete';
  uiButtons = [];
  arenaSlotUI.index = index;
  arenaSlotUI.error = '';
}
function arenaSlotDelete(index){
  if (!arenaSlotUI || arenaSlotUI.mode !== 'entry' || arenaSlotUI.confirm !== 'delete' || arenaSlotUI.index !== index) return false;
  const result = arenaDeleteSlot(index);
  if (!arenaSlotResultOK(result)){
    arenaSlotUI.error = arenaSlotResultError(result, '删除失败，请重试。');
    return false;
  }
  arenaSlotUI.confirm = null;
  arenaSlotUI.index = -1;
  arenaSlotUI.error = '';
  arenaRefreshSlots();
  return true;
}
function arenaStartSelected(mapIndex){
  if (!arenaValidSlot(arenaActiveSlot) || arenaReadSlot(arenaActiveSlot)){
    arenaOpenSlots('entry');
    arenaSlotUI.error = '请先选择一个空存档位；位子已满时需要先删除一个。';
    return false;
  }
  startArena(mapIndex, true);
  return true;
}
function arenaRunSlotCommand(command,index){
  switch(command){
    case 'choose': return arenaSlotChoose(index);
    case 'ask-delete': return arenaSlotAskDelete(index);
    case 'load': return arenaSlotLoad(index);
    case 'delete': return arenaSlotDelete(index);
    case 'overwrite': return arenaSlotSave(index);
    case 'cancel': return arenaSlotCancel();
    case 'close': return arenaCloseSlots();
    case 'open-manual': return arenaOpenSlots('manual');
    case 'open-entry': return arenaOpenSlots('entry');
  }
}
function arenaSaveHandleKey(ev){
  if (!arenaSlotUI) return false;
  ev.preventDefault();
  if (ev.code === 'Escape') arenaRunSlotCommand('cancel');
  return true;
}
function arenaSaveHandleMouse(ev){
  if (arenaSlotUI){
    if (ev.button === 0){
      const hit = uiHit(mouse.x, mouse.y);
      if (hit && hit.fn) hit.fn();
    }
    return true;
  }
  if (ev.button !== 0 || !arenaSaveButtonVisible()) return false;
  const r = arenaSaveButtonRect();
  if (mouse.x < r.x || mouse.x > r.x + r.w || mouse.y < r.y || mouse.y > r.y + r.h) return false;
  arenaRunSlotCommand('open-manual');
  return true;
}

let lastShift = false;
function startArena(mapIdx, fresh){
  arenaSlotUI = null;

  /* 自定义地图要先放下，不然 cur() 还指着它，战斗，爽！！会沿用那张图的人和物资 */
  customLvl = null;
  const map = ARENA_MAPS[clamp(mapIdx,0,ARENA_MAPS.length-1)];
  arenaLvl = buildArenaLevel(arenaSrc(map.match));
  const ss = safeSpot(arenaLvl, { x: arenaLvl.w/2, y: arenaLvl.h/2 }, 20);
  arenaLvl.start = { x: ss.x, y: ss.y };
  /* 战斗，爽！！没收热成像：这个模式节奏快到用不上，而且"看不见的人"本来就不该出现
     （arena 里敌人一直知道你在哪、视野也不做遮挡）。rules.thermal=false 是现成的开关，
     HUD 会自己显示"这关没有热成像"。 */
  arenaLvl.rules = arenaLvl.rules || {};
  arenaLvl.rules.thermal = false;

  ar = { map: map.key, mapName: map.name, wave: 0, waveT: 0, burst: 0, spawnLeft: 0,
         kills: 0, level: 1, xp: 0, xpNext: 5, freeze: false, choices: null,
         time: 0, over: false, picks: [], inter: 0, cineT: 0, cineX: 0, cineY: 0, cineK: 0,
         dmgMul: 1, crit: 0, rofMul: 1, spdMul: 1, hpAdd: 0, hpMul: 1, ammoCost: 1, boom: 0, autoT: 0, multiShot: 0,
         score: 0, scoreKill: 0, scoreWave: 0, scoreBest: arenaBestScore(), bestSaved: false, newBest: false,
         tier: 0, tierBase: 0, tierMsgT: 0,
         armIdx: -1, callCd: 0, calls: 3, callMax: 5, burstT: 0, burstAdd: 0,
         rwT: 0, rwHeal: 0, rwAmmo: 0, rwSpent: 0, rwBurstT: 0, rwBurstA: 0, events: 0, devOpen: false, devTarget: 20,
         evKind: '', evT: 0 };
  arenaSeedRandom();
  ar.waveSpawned = 0;
  /* 开局档位跟着右上角选的难度走（自定义参数按普通算），之后每 10 波 +1 */
  const _ti = DIFF_ORDER.indexOf(diffName);
  ar.tierBase = _ti < 0 ? 1 : _ti;
  ar.tier = ar.tierBase;
  arOrbs = [];
  enemies = []; poolClearView(bullets); grenades = []; smokes = []; loots = [];
  state = 'play';
  ui.inv.open = false; invGeom = null; invGridGeom = null; ui.inv.drag = null;   /* 进割草前把背包收掉，否则点什么都被它吃掉 */
  reset();                       /* reset() 里的 cur() 现在指向 arenaLvl */
  player.hp = arenaMaxHp();
  player.aim = 0;
  setMsg('这个模式会自动打药 · 血掉到一半就自己吃', 4.6);
  player.grace = 2.2;                       /* 开局先给两秒，别一睁眼就挨枪 */
  player.loot = 0;
  ar.wave = 0; ar.waveT = 0.6; ar.spawnLeft = 0;
  setMsg('战斗，爽！！ · ' + map.name + ' · 活下去', 2.2);
  logInfo('arena', '进入战斗，爽！！ · ' + map.name);
}

function exitArena(){
  arenaSlotUI = null;
  arenaLvl = null; ar = null; arOrbs = [];
  goMenu();
}

/* 战斗，爽！！的档位：开局按右上角选的难度定档，之后每 10 波往上跳一档，跳满噩梦就停。
   档位只加在敌人身上（血量/伤害/移速/每波数量/督军/场上上限），玩家面板一点不动 ——
   applyPreset 那套连血上限、视野、移速、烟雾一起改，而且要写 localStorage，
   在局中跳档会变成"越打越弱"，还会把玩家自己设的难度覆盖掉。 */
/* 割草里“越打越快”的射速系数：每跳一档 +15%，封顶 2.4 倍；
   再乘上难度基础值后，最终射速由 ARENA_REF_ROF 兜住（3.0 发/秒） */
/* 上限本身做成数据（data/ai.js 的 DataROF_CAP），硬核等模式在 14-enemytypes 里取倍率。
   这里只留一个别名给老代码和测试用，别再往这里写死数字。 */
const ARENA_REF_ROF = (typeof DataROF_CAP !== 'undefined' && isFinite(DataROF_CAP.default)) ? DataROF_CAP.default : 3.6;
/* 「实弹」：敌人每一发更疼 */
function arenaEnemyDmgK(){ return (ar && arenaEventOn('heavy')) ? 1.4 : 1; }

/* 「卡壳」：玩家自己的射速砍半 */
/* 这个数会被乘进 g.cd（冷却时长，秒），不是乘射速：冷却 ×2 才是「射速砍半」。
   以前这里写 0.5 —— 冷却减半 —— 把 debuff 做成了加速。 */
function arenaRofK(){ return (ar && arenaEventOn('jam')) ? 2 : 1; }

/* 空投白给一张卡：从「还能拿」的卡里挑一张非取舍、非一次性的，直接生效。
   opts.show = true 时把这张卡也摊出来给玩家看一眼（空投只给一张，光靠一句提示太容易错过） */
function arenaFreeUpgrade(opts){
  if (!ar) return '';
  const pool = cardPoolFor(ar, 'supply');
  if (!pool.length) return '';
  const u = pool[Math.floor(arenaRandom() * pool.length)];
  if (u.apply) u.apply(ar);
  ar.picks.push(u.name);
  if (typeof arenaRebuildStats === 'function') arenaRebuildStats();
  if (opts && opts.show){
    ar.drawShow = {
      title: '空投 · 白给一张',
      sub: '已经算进这局了 · 按任意键继续打',
      cards: [{ id: u.id, name: u.name, desc: u.desc, tone: u.tone || '#ffd24a', trade: !!u.trade,
                max: u.max || 0, count: ar.picks.filter(function(x){ return x === u.name; }).length,
                isNew: true }],
      t: 0, closed: false, from: 'supply'
    };
    ar.freeze = true;
  }
  return u.name;
}

function arenaRofMul(){ return ar ? Math.min(2.4, 1 + 0.15 * arenaTierBonus()) * (arenaEventOn('frenzy') ? 1.45 : 1) : 1; }
function arenaTierBonus(){
  return ar ? Math.max(0, (ar.tier | 0) - (ar.tierBase | 0)) : 0;
}
function arenaTierName(){
  const t = ar ? clamp(ar.tier | 0, 0, DIFF_ORDER.length - 1) : 0;
  return DIFF_LABEL[DIFF_ORDER[t]] || DIFF_ORDER[t];
}

/* 战斗，爽！！的敌人武器池：按波次给，权重就是数组里重复的次数（一行改档，别写 if 链）。
   1-6 波只有手枪：前期逼你走位、贴脸；
   7-9 波混进 Uzi：开始有"泼水"压力；
   10 波以后才加霰弹和突击步枪：霰弹是贴脸威胁，AR 是远距离点名。
   AR 放在最后一档是有意的：敌人单发更疼也更准（npc.dmg 0.9 / spread 1.3），
   但射速被 ARENA_REF_ROF 压着，所以它是"压力上台阶"，不是"更强的 Uzi"。
   老关卡不读这张表，只影响割草。 */
const ARENA_WEAPON_POOL = [
  { maxWave: 6,  pool: ['pistol'] },
  { maxWave: 9,  pool: ['pistol', 'pistol', 'rifle'] },
  { maxWave: Infinity, pool: ['pistol', 'rifle', 'rifle', 'shotgun', 'ar'] }
];
function arenaWeaponPool(wv){
  for (let i = 0; i < ARENA_WEAPON_POOL.length; i++){
    if (wv <= ARENA_WEAPON_POOL[i].maxWave) return ARENA_WEAPON_POOL[i].pool;
  }
  return ARENA_WEAPON_POOL[ARENA_WEAPON_POOL.length - 1].pool;
}

function arenaMaxEnemies(){
  /* 场上同时存在的上限：难度越高越能堆，但永远不会把一整波全抛上来 */
  const base = { easy: 14, normal: 20, hard: 26, nightmare: 32 }[diffName] || 20;
  const wv = ar ? ar.wave : 1;
  /* 48 是性能硬上限，跳档加的那几个人也在里面抢，不再往上抬 */
  return Math.min(48, base + Math.floor(Math.max(0, wv - 1) / 2) + arenaTierBonus() * 4);
}

/* 催场就是"临时突破"：常规上限不动，只是在这几秒里额外放开一截，
   把两波的量真的塞进场；时间一到自己收回去，多出来的人不会凭空消失，只是不再补 */
function arenaBurstExtra(){
  if (!ar || !(ar.burstT > 0)) return 0;
  return ar.burstAdd | 0;
}
function arenaSpawnCap(){ return arenaMaxEnemies() + arenaBurstExtra(); }

/* 巢母的小兵走自己的名额：
   ① 不占全局敌人上限（不会把波次刷怪的名额挤没）
   ② 自己有上限，到了就停止召唤，不会无限叠到卡死 */
const SUMM_MINION_MAX = 8;
const CHARGER_DEATH_T = 1.15;   /* 疯狗自爆到炸开的时长 */
function arenaMinionCount(){
  let n = 0;
  for (let i = 0; i < enemies.length; i++){
    const e = enemies[i];
    if (e && e.isMinion && (e.hp || 0) > 0) n++;
  }
  return n;
}
/* 全局上限只算「不是小兵」的那些 */
function arenaFoeCount(){
  let n = 0;
  for (let i = 0; i < enemies.length; i++){
    const e = enemies[i];
    if (e && !e.isMinion) n++;
  }
  return n;
}

/* 孤注一掷还在生效吗：血只有 1 点，伤害 ×2、必穿 3 个、击杀回 1% */
function arenaDealOn(){ return !!(ar && (ar.dealT || 0) > 0); }

const ARENA_INTER = 5.0;          /* 清波后的喘息时长（秒） */

/* 清波那一下的声音：低频闷响 + 一下金属撞击 */
function noiseBurst(vol, cut, dur, q){
  if (!actx) return;
  ensureNoise();
  if (!noiseBuf) return;
  try{
    const sr = actx.createBufferSource(); sr.buffer = noiseBuf;
    const f = actx.createBiquadFilter();
    f.type = 'bandpass'; f.frequency.value = cut; f.Q.value = q || 1.0;
    const g = actx.createGain();
    g.gain.setValueAtTime(vol, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + dur);
    sr.connect(f); f.connect(g); g.connect(duckBus());
    sr.start(); sr.stop(actx.currentTime + dur + 0.02);
  }catch (e){ if (typeof reportErr === 'function') reportErr('50-deathzone', e); }
}

function sfxWaveClear(){
  if (sndPlay('boss.wave', 0.85)) return;
  beep(150, 0.55, 'sine', 0.42, 38);          /* 负责"沉" */
  beep(75, 0.70, 'triangle', 0.30, 32);        /* 更低一层的体重 */
  noiseBurst(0.30, 900, 0.55, 0.8);            /* 轰一下 */
  noiseBurst(0.16, 3400, 0.22, 2.2);           /* 金属尾巴 */
  setTimeout(()=>{ beep(1200, 0.10, 'square', 0.06, 640); }, 90);
}

function arenaNextWave(){
  if (ar.inter > 0) return;        /* 过场没走完就别推进波次，防重复刷 BOSS */
  ar.inter = 0; ar.cineT = 0; ar.cineK = 0;
  ar.cineZ = 1; ar.cineFlash = 0; ar.cineLines = 0;
  ar.wave++;
  ar.waveSpawned = 0;
  /* 老实抽卡：每打完 2 波开一次奖（挂起，等手上的界面都关掉再放） */
  if (ar.er && ar.er.on){
    ar.er.waves++;
    if (ar.er.waves % ER_PERIOD === 0) ar.er.pend = true;
  }
  /* 战地包扎：每开一波先把血垫回来一点（第一波不给） */
  if (ar.wave > 1 && ar.waveHeal)
    player.hp = Math.min(arenaMaxHp(), player.hp + Math.round(arenaMaxHp() * ar.waveHeal));
  /* 每 10 波跳一档：从开局那一档往上爬，噩梦封顶，封顶之后不再动 */
  const _tb = ar.tierBase | 0;
  const _nt = Math.min(DIFF_ORDER.length - 1, _tb + Math.floor((ar.wave - 1) / 10));
  const _up = _nt > (ar.tier | 0);
  if (_up) ar.tier = _nt;
  ar.spawnLeft = 4 + ar.wave*2 + arenaTierBonus() * 3;
  if (ar.wave % 5 === 0 && !arenaBossAlive()) spawnArenaBoss();             /* 第 1 波 6 个，之后每波 +2 */
  ar.burst = 0.5;
  ar.waveT = 1.8;
  if (_up){
    ar.tierMsgT = 3.0;
    /* 跳一档补一次催场，最多补到 callMax */
    ar.calls = Math.min(ar.callMax | 0 || 5, (ar.calls | 0) + 1);
    setMsg('第 ' + ar.wave + ' 波 · 难度升到 ' + arenaTierName() + ' · ' + ar.spawnLeft + ' 个', 3.0);
    beep(300, 0.20, 'sawtooth', 0.10, 140);
    setTimeout(()=>{ beep(620, 0.18, 'square', 0.07, 300); }, 150);
    logInfo('arena', '难度升级 · 第 ' + ar.wave + ' 波 · ' + arenaTierName());
  } else {
    setMsg('第 ' + ar.wave + ' 波 · ' + ar.spawnLeft + ' 个', 1.5);
    beep(520, 0.10, 'square', 0.045, 760);
  }
  /* 特殊事件放在最后判定：它的提示要盖住"第 N 波"，否则玩家永远看不见 */
  if (ar.wave > 10) arenaMaybeEvent();
  if (ar.wave % ARENA_AUTOSAVE_EVERY === 0 && arenaValidSlot(arenaActiveSlot)){
    const saved = arenaSaveNow();
    if (!saved.ok) setMsg(saved.error, 4);
  }
}

/* 催场（N）：把下一波直接叫上来，两波的怪一起冲。波次照常 +1，
   所以档位/难度也会跟着往前走 —— 想快可以快，代价是怪的强度也提前到。
   次数有限：开局 3 次，每跳一档补 1 次（最多 5 次），不能一直按。 */
function arenaCallNext(){
  if (!ar || state !== 'play' || ar.freeze || ar.over) return false;
  /* 过场里（BOSS 倒地定格那几秒）不许催场：那一帧世界还挂着“待开下一波”，
     催场会把波次推进一次、过场结束又推进一次，于是同一波刷出两只 BOSS */
  if (ar.inter > 0){
    setMsg('过场中 · 等这一下走完', 1.2);
    beep(200, 0.08, 'square', 0.04, 140);
    return false;
  }
  if (ar.callCd > 0) return false;
  if ((ar.calls | 0) <= 0){
    setMsg('催场用完了 · 每跳一档补一次', 1.6);
    beep(200, 0.10, 'square', 0.05, 120);
    return false;
  }
  ar.calls = (ar.calls | 0) - 1;
  ar.callCd = 1.2;
  arenaNextWave();
  /* 临时突破：场上上限立刻放开 12，持续 6 秒，让两波的量真的挤进来 */
  ar.burstAdd = 12;
  ar.burstT = 6.0;
  ar.burst = 0;                        /* 别等下一拍，马上开始放人 */
  setMsg('临时突破！场上上限 +12 · 还剩 ' + ar.calls + ' 次催场', 2.4);
  camShake = Math.max(camShake, 0.22);
  logInfo('arena', '催场 · 第 ' + ar.wave + ' 波 · 上限 ' + arenaSpawnCap() + ' · 还剩 ' + ar.calls + ' 次');
  return true;
}


/* ---------- 开发者：跳到第 N 波，并把没打的那些波该给的卡攒下来，
   一张一张慢慢选（freePicks 会一张一张弹，跟正常升级同一套 UI） ---------- */
function arenaDevJumpTo(w){
  if (!ar || !CFG.dev || state !== 'play') return false;
  w = Math.max(1, Math.min(300, w | 0));
  const from = ar.wave | 0;
  if (w <= from){ setMsg('只能往后跳（现在是第 ' + from + ' 波）', 1.8); return false; }
  const owed = Math.max(0, w - from);            /* 跳几波就补几张卡，不扣最后那一波 */
  ar.wave = w - 1;
  ar.spawnLeft = 0;
  arenaNextWave();                                /* 会自己推进到第 w 波 */
  ar.spawnLeft = 4 + ar.wave*2 + arenaTierBonus() * 3;
  if (owed > 0){
    ar.level += owed;
    ar.freePicks = (ar.freePicks | 0) + owed;
    if (!ar.freeze) arenaOffer();
  }
  /* 跳过的每一波都算"本来会过的那一波"，事件也按波数补判定 */
  let evHit = 0;
  for (let i = 0; i < owed; i++){ if (arenaMaybeEvent()) evHit++; }
  setMsg('开发者跳波 · 第 ' + ar.wave + ' 波 · 补 ' + owed + ' 张卡' +
         (evHit ? ' · 触发事件 ' + evHit + ' 次' : ' · 这次没撞上事件'), 3.2);
  logWarn('dev', '跳波 ' + from + ' → ' + ar.wave + ' · 补卡 ' + owed);
  return true;
}

function drawArenaDevJump(){
  if (!ar || !CFG.dev || !ar.devOpen) return;
  const pw = 620, ph = 168;
  const x = (W - pw)/2, y = 96;
  ctx.save();
  ctx.fillStyle = 'rgba(8,10,14,0.90)';
  roundRect(x, y, pw, ph, 12); ctx.fill();
  ctx.strokeStyle = 'rgba(255,180,120,0.55)'; ctx.lineWidth = 1.5;
  roundRect(x, y, pw, ph, 12); ctx.stroke();
  ctx.textAlign = 'left';
  ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#ffb877';
  ctx.fillText('开发者 · 跳到第几波', x + 20, y + 32);
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#9fb0c4';
  ctx.fillText('跳过的每一波补一张卡，会一张一张弹出来让你选', x + 20, y + 54);
  ctx.textAlign = 'center';
  ctx.font = 'bold 30px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#e8eef6';
  ctx.fillText('第 ' + (ar.devTarget | 0) + ' 波', x + pw/2, y + 104);
  ctx.restore();

  const by = y + 120;
  const mk = (bx, label, fn) => {
    ctx.save();
    ctx.fillStyle = 'rgba(30,38,50,0.95)';
    roundRect(bx, by, 64, 32, 8); ctx.fill();
    ctx.strokeStyle = 'rgba(150,175,205,0.45)'; ctx.lineWidth = 1;
    roundRect(bx, by, 64, 32, 8); ctx.stroke();
    ctx.fillStyle = '#cfe0f2';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(label, bx + 32, by + 21);
    ctx.restore();
    btn(bx, by, 64, 32, '', fn, { invisible: true, overlay: true });
  };
  const bx0 = x + 20;
  mk(bx0,       '-10', () => { ar.devTarget = Math.max(ar.wave + 1, (ar.devTarget | 0) - 10); });
  mk(bx0 + 72,  '-1',  () => { ar.devTarget = Math.max(ar.wave + 1, (ar.devTarget | 0) - 1); });
  mk(bx0 + 144, '+1',  () => { ar.devTarget = Math.min(300, (ar.devTarget | 0) + 1); });
  mk(bx0 + 216, '+10', () => { ar.devTarget = Math.min(300, (ar.devTarget | 0) + 10); });
  mk(bx0 + 288, '+50', () => { ar.devTarget = Math.min(300, (ar.devTarget | 0) + 50); });
  mk(bx0 + 360, '+100', () => { ar.devTarget = Math.min(300, (ar.devTarget | 0) + 100); });

  const gx = x + pw - 132;
  ctx.save();
  ctx.fillStyle = 'rgba(72,54,24,0.95)';
  roundRect(gx, by, 112, 32, 8); ctx.fill();
  ctx.strokeStyle = 'rgba(255,200,130,0.75)'; ctx.lineWidth = 1.4;
  roundRect(gx, by, 112, 32, 8); ctx.stroke();
  ctx.fillStyle = '#ffe6b8';
  ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('跳过去', gx + 56, by + 21);
  ctx.restore();
  btn(gx, by, 112, 32, '', () => { if (arenaDevJumpTo(ar.devTarget | 0)) ar.devOpen = false; }, { invisible: true, overlay: true });

  /* 右上角提示怎么关 */
  ctx.save();
  ctx.textAlign = 'right';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#8798ab';
  ctx.fillText('F2 关闭', x + pw - 18, y + 26);
  ctx.restore();
}

/* 带宝箱的兵：前期常见，越往后越少 —— 卡是有上限的，后期还满地图掉卡没意义 */
function arenaCarrierChance(wave){
  const w = Math.max(0, (wave | 0) - 2);
  return Math.max(0.02, 0.10 - w * 0.005);
}


/* ---------- 特殊事件：第 10 波之后才有，概率出现，每次只来一件 ---------- */
function arenaEventCarriers(n){
  for (let i = 0; i < n; i++){
    const ang = rand(0, TAU), r = rand(360, 700);
    const x = player.x + Math.cos(ang)*r, y = player.y + Math.sin(ang)*r;
    spawnArenaEnemy(x, y, ang + Math.PI);
    const e = enemies[enemies.length - 1];
    if (e){
      e.special = true;
      e.maxHp = Math.round(e.maxHp * 1.8);
      e.hp = e.maxHp;
      e.r = 15;
    }
  }
}

/* ---------- 特殊事件 ----------
   瞬间型：supply / carrier / boss  —— 当场生效
   持续型：burst / blackout / nocover / frenzy / jam —— 有持续时间，HUD 上会显示还剩几秒 */
const ARENA_EVENTS = [
  {k:'burst',    w:3, name:'临时突破', dur:6,  tip:'场上一下多十二个'},
  {k:'supply',   w:2, name:'空投',     dur:0,  tip:'白给一张卡，血也回满'},
  {k:'carrier',  w:2, name:'宝箱兵',   dur:0,  tip:'三只宝箱兵，打死掉物资'},
  {k:'boss',     w:1, name:'督军压境', dur:0,  tip:'来一只督军'},
  {k:'blackout', w:2, name:'停电',     dur:20, tip:'视野砍掉一半，屏幕外的人你看不见（二十秒）'},
  {k:'heavy',    w:2, name:'实弹',     dur:12, tip:'敌人每一发伤害 +40%'},
  {k:'frenzy',   w:2, name:'疾行',     dur:10, tip:'敌人移速 +40%、射速 +45%'},
  {k:'jam',      w:2, name:'卡壳',     dur:8,  tip:'你自己的射速砍一半'}
];

function arenaEventDef(k){
  for (const d of ARENA_EVENTS) if (d.k === k) return d;
  return null;
}
/* 某个持续型事件现在是不是生效中 */
function arenaEventOn(k){
  return !!(ar && ar.evKind === k && (ar.evT | 0) > 0);
}
function arenaEventName(k){
  const d = arenaEventDef(k);
  return d ? d.name : '';
}

function arenaMaybeEvent(){
  if (!ar || ar.wave <= 10) return false;
  const roll = 0.28 + Math.min(0.10, (ar.wave - 10) * 0.004);   /* 越往后越容易撞上 */
  if (arenaRandom() > roll) return false;
  let total = 0;
  for (const d of ARENA_EVENTS) total += d.w;
  let pick = arenaRandom() * total;
  let k = ARENA_EVENTS[ARENA_EVENTS.length - 1].k;
  for (const d of ARENA_EVENTS){ pick -= d.w; if (pick <= 0){ k = d.k; break; } }
  return arenaFireEvent(k);
}

function arenaFireEvent(k){
  if (!ar || state !== 'play') return false;
  const def = arenaEventDef(k);
  if (!def) return false;
  if (k === 'burst'){
    ar.burstAdd = 12; ar.burstT = def.dur; ar.burst = 0;
    ar.spawnLeft = Math.max(ar.spawnLeft, 10);
    ar.evKind = k; ar.evT = def.dur;
    beep(300, 0.22, 'sawtooth', 0.11, 130);
  } else if (k === 'supply'){
    /* 空投：血回满 + 白给一张卡。卡面摊出来给你看一眼（只有一张，不摊出来太容易错过） */
    player.hp = arenaMaxHp();
    for (const key in (player.guns || {})){
      const g = player.guns[key];
      if (g && g.cap) g.mag = g.cap;
    }
    if (player.gun && player.gun.cap) player.gun.mag = player.gun.cap;
    const gift = arenaFreeUpgrade({ show: true });
    beep(760, 0.16, 'triangle', 0.06, 1200);
    beep(1180, 0.22, 'triangle', 0.05, 1600);
    if (gift){ logInfo('arena', '空投 · 白给 ' + gift); }
  } else if (k === 'carrier'){
    arenaEventCarriers(3);
    beep(620, 0.18, 'square', 0.07, 300);
  } else if (k === 'boss'){
    spawnArenaBoss();
    beep(120, 0.5, 'triangle', 0.14, 60);
  } else {
    /* 剩下的都是场面事件：只记状态，效果在各自的系统里读 arenaEventOn() */
    ar.evKind = k; ar.evT = def.dur;
    if (k === 'blackout') beep(160, 0.55, 'sine', 0.12, 40);
    else if (k === 'jam') beep(1400, 0.12, 'sawtooth', 0.05, 300);
    else if (k === 'frenzy') beep(520, 0.16, 'square', 0.08, 900);
    else beep(240, 0.30, 'triangle', 0.10, 120);
  }
  const tail = def.dur > 0 ? ' · ' + def.dur + ' 秒' : '';
  setMsg('特殊事件 · ' + def.name + tail + ' · ' + def.tip + (ar._evExtra || ''), 3.2);
  ar._evExtra = '';
  ar.events = (ar.events | 0) + 1;
  logInfo('arena', '特殊事件 · ' + k + ' · 第 ' + ar.wave + ' 波' + (def.dur > 0 ? ' · ' + def.dur + '秒' : ''));
  return true;
}

/* 每 5 波一个督军：血厚、慢、伤害高，打死给两张卡 */
function arenaBossAlive(){
  for (const e of enemies) if (e.boss) return e;
  return null;
}

/* 竞技场的督军不是一个模子：五种波次轮着来，每种都有自己的脾气。
   数值都从原来的督军基线长出来，所以只改打法、不动难度曲线 */
const ARENA_BOSSES = {
  warlord: { name:'督军', tint:'#ff9a5a', hpK:1.00, spdK:0.92, wid:'rifle',
             tip:'三连点射 · 找掩体' },
  charger: { name:'疯狗', tint:'#ff5566', hpK:0.85, spdK:1.50, wid:'pistol',
             tip:'它不带枪，冲上来就炸 · 提前打掉' },
  shield:  { name:'盾卫', tint:'#9ad0ff', hpK:1.25, spdK:0.80, wid:'shotgun',
             tip:'两片盾绕身转 · 抓空档打' },
  spawner: { name:'巢母', tint:'#c8a8ff', hpK:1.55, spdK:0.98, wid:'pistol',
             tip:'一直放小兵 · 优先打掉' }
};
const ARENA_BOSS_ORDER = ['warlord', 'charger', 'shield', 'spawner'];
function arenaBossKindFor(wave){
  const i = Math.max(0, Math.floor((wave | 0) / 5) - 1);
  return ARENA_BOSS_ORDER[i % ARENA_BOSS_ORDER.length];
}

function spawnArenaBoss(){
  /* 只要场上还有督军，就不再放新的。之前只在"每 5 波"那条路上判断，
     特殊事件 boss 还能直接叠一只进来，变成两个督军同时在场。 */
  if (arenaBossAlive()) return;
  const L = cur();
  for (let t = 0; t < 60; t++){
    const ang = rand(0, TAU), r = rand(620, 950);
    const x = player.x + Math.cos(ang)*r, y = player.y + Math.sin(ang)*r;
    if (x < 60 || y < 60 || x > L.w-60 || y > L.h-60) continue;
    const q = safeSpot(L, {x, y}, 24);
    if (dist(q.x, q.y, player.x, player.y) < 460) continue;
    const _bb = arenaTierBonus();
    const _kind = arenaBossKindFor(ar.wave);
    const _bd = ARENA_BOSSES[_kind] || ARENA_BOSSES.warlord;
    const hp = bossHpFor(ar.wave, _bb, _bd.hpK);
    const b = { type:'grunt', x:q.x, y:q.y, r:21, ang: ang + Math.PI,
                wp:[[q.x, q.y]], i:0, wait:0, mode:1,
                lastKnown:{x:player.x, y:player.y}, alertT:99,
                sees:false, heard:false, chk:null,
                ammo: _kind === 'charger' ? 0 : 60, fireCd: 0.6, reloading:0, muzzle:0,
                hp: hp, maxHp: hp, dmgK: bossPowerK(ar.wave, _bb),
                spdK: _bd.spdK,
                wid:_bd.wid, boss:true, bossName:_bd.name, bossKind:_kind,
                bossTint:_bd.tint, bossTip:_bd.tip,
                shieldAng: ang + Math.PI, burstLeft: 0, spawnCd: 3.5,
                dashT: 0, dashWind: 0, dashCd: 2.6, dashDir: ang };
    enemies.push(b);
    ar.waveSpawned = (ar.waveSpawned || 0) + 1;
    if (_kind === 'spawner') spawnerBanStart();
    setMsg('第 ' + ar.wave + ' 波 · ' + _bd.name + '下场', 2.2);
    sfxAlarm();
    return b;
  }
  return null;
}

/* 前两波全是近战（刀手），第三波开始慢慢掺带枪的，越往后近战越少。
   近战在割草里是"逼你走位"的东西：不开枪、只能贴脸，但你停下就打不了它。 */
function arenaKindFor(wave){
  const w = wave | 0;
  if (w <= 4) return 'blade';                                   /* 前四波全近战，先把刀法看懂 */
  if (w === 5) return (arenaRandom() < 0.65) ? 'blade' : 'gunner';
  if (w <= 8)  return (arenaRandom() < 0.45) ? 'blade' : 'gunner';
  return (arenaRandom() < 0.28) ? 'blade' : 'gunner';
}

function spawnArenaEnemy(x, y, ang, kind){
  const ds = ar.wave - 1;
  /* 最后一道保险：任何一条路径（落点表 / 随机点 / 兜底最远点）给进来的坐标，
     都不许落在墙里或贴着地图边 —— 玩家贴着边界打的时候最容易撞见这个。 */
  {
    const _L = cur(), _m = 90;
    x = Math.max(_m, Math.min(_L.w - _m, x));
    y = Math.max(_m, Math.min(_L.h - _m, y));
    const _w = collisionWalls(_L, x, y, 22).some(ww =>
      x > ww.x - 22 && x < ww.x + ww.w + 22 && y > ww.y - 22 && y < ww.y + ww.h + 22);
    if (_w){ const _q = safeSpot(_L, { x, y }, 22); x = _q.x; y = _q.y; }
  }
  const tb = arenaTierBonus();
  const hp = Math.round(100 * (1 + ds*0.20) * (1 + tb*0.22));
  if (kind === 'blade'){
    const bHp = Math.max(30, Math.round(hp * 0.82));
    const e = { type:'blade', x, y, r:13, ang: ang + Math.PI,
                wp:[[x,y]], i:0, wait:0, mode:1,
                lastKnown:{x:player.x, y:player.y}, alertT:99,
                sees:false, heard:false, chk:null,
                ammo:0, fireCd:0, reloading:0, muzzle:0,
                bladeCd: rand(0.3, 0.9), windup:0, huntT:0, slashT:0, slashA:0, trail:[],
                wid: (arenaRandom() < 0.25 ? 'dao' : 'knife'),
                hp: bHp, maxHp: bHp,
                dmgK: (1 + ds*0.09) * (1 + tb*0.15),
                spdK: 1 + Math.min(0.85, ds*0.025) };
    e.HM = enemyType(e).hearMul;
    enemies.push(e);
    ar.waveSpawned = (ar.waveSpawned || 0) + 1;
    return;
  }
  const e = { type:'grunt', x, y, r:12, ang: ang + Math.PI,
              wp:[[x,y]], i:0, wait:0, mode:1,
              lastKnown:{x:player.x, y:player.y}, alertT:99,
              sees:false, heard:false, chk:null,
              ammo: CFG.mag, fireCd: rand(0.25, 0.9), reloading:0, muzzle:0,
              hp: hp, maxHp: hp, dmgK: (1 + ds*0.09) * (1 + tb*0.15),
              spdK: 1 + Math.min(0.85, ds*0.025) };
  /* 小概率刷出「带宝箱」的特殊目标 */
  if (ar && ar.wave >= 2 && arenaRandom() < arenaCarrierChance(ar.wave)){
    e.special = true;
    e.maxHp = Math.round(e.maxHp * 1.8); e.hp = e.maxHp;
    e.r = 15;
  }   /* 移速上限 +85% */
  assignWeapon(e);
  /* 战斗，爽！！的武器解锁：池子见 ARENA_WEAPON_POOL（1-6 手枪 / 7-9 加 Uzi / 10 波以后加霰弹和 AR） */
  if (ar){
    const pool = arenaWeaponPool(ar.wave);
    const pick = pool[Math.floor(arenaRandom()*pool.length) % pool.length];
    e.wid = pick;
    e.ammo = weaponCore(pick).cap;
  }
  e.HM = enemyType(e).hearMul;
  enemies.push(e);
    ar.waveSpawned = (ar.waveSpawned || 0) + 1;
}

/* 刷怪落点表：地图是死的，落点也是死的，算一次就够。
   以前第一只敌人出现的那一帧会同步跑完 26×12 个 safeSpot；玩家看到的就是
   “敌人一刷出来画面顿一下”。现在利用开波前 0.6 秒，把这 312 格分帧预热。
   属性设成不可枚举：这是派生缓存，不该跟完整存档一起写进 localStorage。 */
const ARENA_SPAWN_COLS = 26, ARENA_SPAWN_ROWS = 12, ARENA_SPAWN_TOTAL = 26 * 12;
function arenaSpawnCacheInit(L){
  /* 兼容旧存档/旧测试留下的完整表：没有进度字段的非空表视为已经算完。 */
  if (Array.isArray(L._spawnPts) && L._spawnPtsAt === undefined){
    if (L._spawnPts.length) return { pts: L._spawnPts, at: ARENA_SPAWN_TOTAL, ready: true };
  }
  if (!Array.isArray(L._spawnPts)){
    Object.defineProperty(L, '_spawnPts', { value: [], writable: true, configurable: true });
  }
  if (L._spawnPtsAt === undefined){
    Object.defineProperty(L, '_spawnPtsAt', { value: 0, writable: true, configurable: true });
    Object.defineProperty(L, '_spawnPtsReady', { value: false, writable: true, configurable: true });
  }
  return { pts: L._spawnPts, at: L._spawnPtsAt, ready: !!L._spawnPtsReady };
}
function arenaSpawnPtsWarm(L, budget){
  const s = arenaSpawnCacheInit(L);
  if (s.ready) return s.pts;
  let left = Math.max(0, budget | 0);
  while (left-- > 0 && L._spawnPtsAt < ARENA_SPAWN_TOTAL){
    /* 73 与 312 互质：先把候选点均匀撒遍全图。低帧设备即使还没完全预热，
       已有的部分表也不会只集中在左上角。 */
    const k = (L._spawnPtsAt * 73) % ARENA_SPAWN_TOTAL;
    const r = (k / ARENA_SPAWN_COLS) | 0, c = k % ARENA_SPAWN_COLS;
    const x = 60 + (L.w - 120) * (c / (ARENA_SPAWN_COLS - 1));
    const y = 60 + (L.h - 120) * (r / (ARENA_SPAWN_ROWS - 1));
    const q = safeSpot(L, { x, y }, 14);
    /* safeSpot 在"96px 内找不到空地"时会原样返回（它只能保 8 个方向 × 8 圈），
       地图边界墙又厚，于是会出现"人站在边界墙里"的落点。这里再兜一层：
       落点必须离墙 >= 26、离地图边 >= 90，否则这张表就不收它。 */
    const _inWall = collisionWalls(L, q.x, q.y, 26).some(w =>
      q.x > w.x - 26 && q.x < w.x + w.w + 26 && q.y > w.y - 26 && q.y < w.y + w.h + 26);
    const _nearEdge = (q.x < 90 || q.y < 90 || q.x > L.w - 90 || q.y > L.h - 90);
    if (!_inWall && !_nearEdge && Math.hypot(q.x - x, q.y - y) <= 34) L._spawnPts.push(q);
    L._spawnPtsAt++;
  }
  if (L._spawnPtsAt >= ARENA_SPAWN_TOTAL) L._spawnPtsReady = true;
  return L._spawnPts;
}
function arenaSpawnPts(L){
  arenaSpawnCacheInit(L);
  if (!L._spawnPtsReady) arenaSpawnPtsWarm(L, ARENA_SPAWN_TOTAL - L._spawnPtsAt);
  return L._spawnPts;
}

function arenaSpawnOne(){
  const L = cur();
  /* 屏幕外判定：不能在玩家眼皮底下凭空出人 */
  const M = 90;
  const offscreen = (x, y) => (x - cam.x < -M || x - cam.x > W + M || y - cam.y < -M || y - cam.y > H + M);
  /* 先在现成的落点表里抽：命中率高，几乎不用重试 */
  const pts = arenaSpawnPts(L);
  for (let t = 0; t < 14 && pts.length; t++){
    const q = pts[(arenaRandom() * pts.length) | 0];
    if (dist(q.x, q.y, player.x, player.y) < 420) continue;
    if (!offscreen(q.x, q.y)) continue;
    spawnArenaEnemy(q.x, q.y, Math.atan2(player.y - q.y, player.x - q.x), arenaKindFor(ar.wave));
    return;
  }
  for (let t=0;t<40;t++){
    const ang = rand(0, TAU);
    const r = rand(560, 900);
    const x = player.x + Math.cos(ang)*r, y = player.y + Math.sin(ang)*r;
    if (x < 40 || y < 40 || x > L.w-40 || y > L.h-40) continue;
    const q = safeSpot(L, {x, y}, 14);
    if (dist(q.x, q.y, player.x, player.y) < 420) continue;
    if (!offscreen(q.x, q.y)) continue;
    spawnArenaEnemy(q.x, q.y, ang + Math.PI, arenaKindFor(ar.wave));
    return;
  }
  /* 最后兜底：拿表里离玩家最远的那点，屏幕边上也认了 ——
     总比这一波平白少一个人强，也不用再空转八十次。 */
  let far = null, fd = -1;
  for (const q of pts){
    const d = dist(q.x, q.y, player.x, player.y);
    if (d > fd){ fd = d; far = q; }
  }
  if (far) spawnArenaEnemy(far.x, far.y, rand(0, TAU), arenaKindFor(ar.wave));
}

function arenaCommitBestScore(run){
  if(run.bestSaved)return;
  run.bestSaved=true;
  if(run.score>(run.scoreBest|0)){
    run.newBest=run.score>0;
    run.scoreBest=run.score;
    try{localStorage.setItem('after5_arenabest',String(run.score|0));}catch (error){ if (typeof reportErr === 'function') reportErr('50-deathzone', error); }
  }
}
function arenaBestScore(){
  try { return Math.max(0, parseInt(localStorage.getItem('after5_arenabest') || '0', 10) || 0); }
  catch(e){ return 0; }
}

/* ---------- 分数 ----------
   倍率由两段相乘：
     · 阶段难度（选中/普通/困难，ar.tierBase）—— 开局定死
     · 爬升档位（每 10 波 +1 档）—— arenaTierBonus()
   所以"难度是动态的"这件事自动同步，不需要另存一份。 */
function arenaScoreMul(){
  if (!ar) return 1;
  const base = 1 + 0.25 * Math.max(0, ar.tierBase | 0);
  const climb = 1 + 0.45 * Math.max(0, arenaTierBonus());
  return base * climb;
}
function arenaScoreBase(e){
  if (!e) return 0;
  if (e.boss) return 400 + (ar ? (ar.wave | 0) * 25 : 0);   /* 督军：越晚出现越值钱 */
  if (e.special) return 60;                                  /* 带宝箱 / 事件强化的 */
  return 10;                                                 /* 普通兵 */
}
function arenaScoreKill(e){
  if (!ar) return 0;
  const v = Math.round(arenaScoreBase(e) * arenaScoreMul());
  ar.score += v; ar.scoreKill += v;
  return v;
}
/* 清波：给一笔"活下来了"的分，越往上越值 */
function arenaScoreWave(){
  if (!ar) return 0;
  const v = Math.round(120 * arenaScoreMul());
  ar.score += v; ar.scoreWave += v;
  return v;
}

/* 打死督军：宝箱 + 两张卡（抽一次 + 必定再抽一次）+ 大量经验 */
function bossReward(e){
  if (!ar || e._bossRewarded) return;
  e._bossRewarded = true;
  ar.freePicks = (ar.freePicks || 0) + 2;
  arenaXp(60 + ar.wave * 8);
  for (let i = 0; i < 7; i++) arenaOrb(e.x + rand(-26, 26), e.y + rand(-26, 26));
  setMsg('督军倒下 · 宝箱打开，抽两张卡', 2.6);
  if (!ar.freeze) arenaOffer();          /* 立刻弹第一张 */
  sfxWaveClear();
}

function arenaXp(v){
  /* 整成一格一格的经验，别让浮点尾巴跑到界面上 */
  ar.xp += Math.round(v * (ar.xpMul || 1) * 10) / 10;
  while (ar.xp >= ar.xpNext){
    ar.xp -= ar.xpNext;
    ar.level++;
    ar.xpNext = Math.round(5 + ar.level*3.4);
    arenaOffer();
  }
}

/* 场上最多堆多少颗经验球。超出就并到最近的那颗上 —— 经验一点不少，
   只是一颗球代表更多经验。不加这个上限，远处的球（超过吸附半径 430px
   就永远不动）会整局堆在场上，越玩越卡。 */
const ORB_MAX = 200;
function arenaOrb(x, y){
  arOrbs.push({ x, y, v: 1, t: 0, bob: fxRand(0, TAU) });
  while (arOrbs.length > ORB_MAX){
    const old = arOrbs.shift();
    let best = null, bd = 1e9;
    for (const o of arOrbs){
      const d = dist(old.x, old.y, o.x, o.y);
      if (d < bd){ bd = d; best = o; }
    }
    if (best) best.v += old.v; else arOrbs.push(old);
    if (!best) break;
  }
}

/* 每张卡的上限：叠到顶就不再刷出来，避免后期数值滚雪球。
   现在的顶：伤害 1.18^8≈3.8 倍、射速 0.88^6≈2.2 倍、护甲正好叠满 60%、
   暴击 48% / 暴伤 +150%、回血（收割 12/杀 · 自愈 2.4/秒）都压住了。 */
const UPG_MAX_EXTRA = { sg:1, pierce:4, noclip:1, trade1:2, trade2:2, last:1, aim:4, god:3, deal:2,
                        debt:2, dump:1, gamble:2, burst2:2, ricochet:4, reload:4, draw2:2, draw4:1,
                        bulk:3,     /* m32458 成排压弹：三级封顶（2/4/6 发） */
                        close:3, far:3, rage:2, pick:3, patch:3, allin:1, honest:1,
                        rwburst:1, rwcap:3, rwboom:3, rwammo:2 };
const UPG_MAX = { dmg:8, crit:6, rof:6, spd:6, hp:8, leech:3, mag:3,
                  armor:5, xp:3, cdmg:3, reg:3, boom:2, magnet:2 };
for (const u of UPGRADES){ u.max = UPG_MAX[u.id] || UPG_MAX_EXTRA[u.id] || 99; }

/* 每张卡的两套说法：
   desc   = 卡片正面那行简略（只写"拿一张加多少"）
   detail = 选中之后在卡片下面展开的详细说明：隐藏冷却、层数上限、是乘算还是加算
   nx     = 现在再拿一张会变成多少（按玩家已经叠的层数现算，不是写死的文案） */
const UPG_INFO = {
  dmg: { nx: a => '伤害 ×' + ((a.dmgMul||1)).toFixed(2) + ' → ×' + ((a.dmgMul||1)*1.18).toFixed(2),
         detail: '子弹伤害 ×1.18/层，是乘算不是加算。最多 8 层，叠满约 ×3.76。满层之后这张卡不再刷出来。' },
  crit: { nx: a => '暴击 ' + Math.round((a.crit||0)*100) + '% → ' + (Math.round((a.crit||0)*100)+8) + '%',
          detail: '暴击率 +8%/层，最多 6 层 = 48%。暴击时伤害按暴伤倍数结算，和破防那张卡叠乘。' },
  rof: { nx: a => '射速 ×' + (1/(a.rofMul||1)).toFixed(2) + ' → ×' + (1/((a.rofMul||1)*0.88)).toFixed(2),
         detail: '射速 +14%/层（乘算），换弹时间和弹匣容量不受影响。最多 6 层 ≈ ×2.2。' },
  spd: { nx: a => '移速 ×' + (a.spdMul||1).toFixed(2) + ' → ×' + ((a.spdMul||1)*1.09).toFixed(2),
         detail: '移动速度 +9%/层，最多 6 层 ≈ ×1.68。蹲下、静步的减速照旧另算。' },
  hp: { nx: a => '生命上限 +' + (a.hpAdd|0) + ' → +' + ((a.hpAdd|0)+16),
        detail: '生命上限 +16 并立刻回 16，最多 8 层（+128）。上限变了之后自动打药的血线也跟着变。' },
  leech: { nx: a => '回血 ' + (a.leech||0) + ' /杀 → ' + ((a.leech||0)+2) + ' /杀',
           detail: '每次击杀回 2 点，最多 3 层 = 6/杀。一枪多杀时，同一个 0.18 秒窗口最多只结算 6 点，不会一枪回满。' },
  mag: { nx: a => '弹匣 +8/层（已 ' + (a.picks||[]).filter(n => n === '弹匣扩容').length + ' 层）',
         detail: '所有枪的弹匣 +8 并当场装满，最多 3 层（累计 +24）。备用弹不变，不会白送子弹。' },
  armor: { nx: a => '减伤 ' + Math.round((a.armor||0)*100) + '% → ' + Math.min(60, Math.round((a.armor||0)*100)+12) + '%',
           detail: '每层减伤 12%，最多 5 层 = 60% 封顶，再拿也不会超过。' },
  xp: { nx: a => '经验 ×' + (a.xpMul||1).toFixed(2) + ' → ×' + ((a.xpMul||1)*1.3).toFixed(2),
        detail: '获得经验 +30%/层（乘算），最多 3 层 ≈ ×2.2。升级越快，后面的卡来得越勤。' },
  cdmg: { nx: a => '暴伤 +' + Math.round((a.critDmg||0)*100) + '% → +' + (Math.round((a.critDmg||0)*100)+50) + '%',
          detail: '暴击伤害 +50%/层，最多 3 层 = +150%。只对暴击生效，所以要和致命一击一起拿才有用。' },
  sg: { nx: a => '霰弹射速 ×' + (a.sgRof||1).toFixed(2) + ' → ×' + ((a.sgRof||1)*0.75).toFixed(2),
        detail: '只影响霰弹枪，射速 ×0.75。只有 1 层，拿完不再出现。' },
  pierce: { nx: a => '穿透率 ' + Math.min(100, (a.pierce|0)*25) + '% → ' + Math.min(100, ((a.pierce|0)+1)*25) + '%',
            detail: '每层让"打穿一个人继续往后飞"的概率 +25%，最多 4 层 = 100%。能穿的人数也有罩门：最多 1 + 层数 个人，所以满层是必定穿 4 个人。穿透后伤害不衰减。' },
  noclip: { nx: null,
            detail: '能钻进墙里走，但没有白待的地方：墙里每秒掉 6% 最大生命，移速只剩两成二，不能打药，子弹照打不误；在墙里待满 3 秒会被直接挤出去。只有 1 层。' },
  trade1: { nx: a => '伤害 ×' + (a.dmgMul||1).toFixed(2) + ' → ×' + ((a.dmgMul||1)*1.35).toFixed(2) + ' · 暴击再 -10%',
            detail: '伤害 ×1.35，代价是暴击率 -10%。最多 2 层。取舍卡：走暴击流的话拿了会很难受。' },
  trade2: { nx: a => '暴击 +18% · 伤害 ×' + (a.dmgMul||1).toFixed(2) + ' → ×' + ((a.dmgMul||1)*0.8).toFixed(2),
            detail: '暴击率 +18%，代价是伤害 ×0.80。最多 2 层。取舍卡：配合破防走暴击流才划算。' },
  last: { nx: null,
          detail: '血量掉到 25% 以下瞬间回满，然后进入 60 秒冷却——这个冷却界面上不显示倒计时，但确实在跑。整局只生效一次，不叠层。' },
  reg: { nx: a => '每秒回 ' + (a.reg||0).toFixed(1) + ' → ' + ((a.reg||0)+0.8).toFixed(1),
         detail: '每秒回 0.8 点，最多 3 层 = 2.4/秒。不需要脱战，一直在回。' },
  boom: { nx: a => '爆炸 ' + Math.round((a.boom||0)*100) + '% → ' + (Math.round((a.boom||0)*100)+18) + '%',
          detail: '命中时 18% 概率范围爆炸，最多 2 层 = 36%。爆炸不额外耗弹，对被挡在墙后的人也有效。' },
  aim: { nx: a => '自动瞄准 ' + Math.round(a.autoT||0) + ' 秒 → ' + (Math.round(a.autoT||0)+8) + ' 秒',
         detail: '立刻获得 8 秒自动锁定最近的敌人，可叠层延长，没有冷却。' },
  god: { nx: a => '无敌 5 秒（已 ' + (a.picks||[]).filter(n => n === '短暂无敌').length + ' 层）',
         detail: '立刻 5 秒无敌，期间被打不掉血。最多 3 层，层与层之间不会自动接上，是立刻生效的。' },
  magnet: { nx: a => '吸取范围 +' + (a.pickR|0) + ' → +' + ((a.pickR|0)+130),
            detail: '经验球的吸取半径 +130，最多 2 层。球还是要自己走过去，只是范围更大。' },
  close: { nx: a => '近距离 +' + Math.round((a.closeDmg||0)*100) + '% → +' + (Math.round((a.closeDmg||0)*100)+22) + '%',
           detail: '220 距离内伤害 +22%/层，最多 3 层。只在开枪命中时算，不挑枪。' },
  far: { nx: a => '远距离 +' + Math.round((a.farDmg||0)*100) + '% → +' + (Math.round((a.farDmg||0)*100)+18) + '%',
         detail: '380 距离外伤害 +18%/层，最多 3 层。和贴脸互相排斥：一次命中只算一种。' },
  rage: { nx: a => '残血伤害 +' + Math.round((a.rageDmg||0)*100) + '% → +' + (Math.round((a.rageDmg||0)*100)+30) + '%',
          detail: '血量低于 40% 时伤害 +30%/层，最多 2 层（+60%）。血回上去就失效。' },
  pick: { nx: a => '击杀补弹 ' + (a.ammoKill||0) + ' → ' + ((a.ammoKill||0)+2) + ' 发',
          detail: '只对 AR15 生效，霰弹枪和手枪都不吃：霰弹一炮八颗弹丸，一炮打死几个人就等于白送半个弹匣，太离谱。补 2 发/层，最多 3 层 = 6 发；一枪多杀时 0.18 秒内最多补 4 发，且不会超过弹匣容量。' },
  patch: { nx: a => '每波回 ' + Math.round((a.waveHeal||0)*100) + '% → ' + (Math.round((a.waveHeal||0)*100)+12) + '%',
           detail: '每波开始回 12% 最大生命，最多 3 层 = 36%。第一波不触发。' },
  debt: { nx: a => '伤害 ×' + (a.dmgMul||1).toFixed(2) + ' → ×' + ((a.dmgMul||1)*1.4).toFixed(2) + ' · 生命上限 ×' + (a.hpMul||1).toFixed(2) + ' → ×' + ((a.hpMul||1)*0.75).toFixed(2),
          detail: '子弹伤害 ×1.40，代价是生命上限 ×0.75。上限是从「基础 150 + 厚皮加成」整体乘的，所以厚皮拿得越多，这一刀砍掉的绝对血量也越多；拿的瞬间当前血按同一比例缩，不会白送。最多 2 层。' },
  dump: { nx: a => '射速 ×' + (1/(a.rofMul||1)).toFixed(2) + ' → ×' + (1/((a.rofMul||1)*0.5)).toFixed(2) + ' · 每枪 2 发',
          detail: '射速翻倍（乘算），但每扣一次扳机吃 2 发子弹：12 发的弹匣只能打 6 次，霰弹枪一次也只算 2 发、不是每颗弹丸都算。弹匣容量和换弹时间不变，所以备弹会掉得很快。只有 1 层。' },
  gamble: { nx: a => '暴击 ' + Math.round((a.crit||0)*100) + '% → ' + Math.round(((a.crit||0)+0.20)*100) + '% · 暴伤 ' + (2.0+(a.critDmg||0)).toFixed(1) + ' → ' + (1.7+(a.critDmg||0)).toFixed(1),
            detail: '暴击率 +20%，代价是暴击倍率 -0.3（基础 2.0 → 1.7，也就是暴击从「伤害翻倍」变成「伤害 +70%」）。和破防（暴伤 +0.5/层）是同一根轴上的加法：先拿破防再拿赌徒，结果一样。最多 2 层。' },
  burst2: { nx: a => '每扣一次扳机 ' + (1 + (a.multiShot||0)) + ' 发 → ' + (1 + Math.min(2, (a.multiShot||0)+1)) + ' 发',
            detail: '一次扣扳机连打 2 发（再拿一张 3 发），同时消耗同样份数的弹药。弹匣不够整份时只打够的那几发 —— 只剩 1 发就只打 1 发，不会白扣。霰弹枪是「一整轮弹丸 × 发数」，所以一枪的弹丸会翻倍。最多 2 层。' },
  ricochet: { nx: a => '反弹率 ' + Math.round(Math.min(4,(a.ricochet||0))*25) + '% → ' + Math.round(Math.min(4,(a.ricochet||0)+1)*25) + '%',
              detail: '子弹撞墙时按 25%/层 的概率反弹一次（满 4 层 100%）。反弹后的那一段也会打人、也能触发穿透，但不会再弹第二次。只有墙能弹，人和门不行。' },
  reload: { nx: a => '换弹速度 +' + Math.round((1-(a.reloadMul||1))*100) + '% → +' + Math.round((1-(a.reloadMul||1)*0.88)*100) + '%',
            detail: '换弹时间 ×0.88/层，最多 4 层（时间 ×0.60，等于快 40%）。只影响换弹，不影响射速。' },
  draw2: { nx: a => '已抽 ' + (a.picks||[]).filter(n=>n==='赌徒').length + ' / 2 次',
           detail: '当场从还能拿的卡里随机抽两张，直接生效 —— 抽到什么吃什么，不能反悔。抽卡卡本身不会被抽到，所以不会连锁。抽到的两张会摊在屏幕上给你看。最多 2 层。' },
  draw4: { nx: a => '拿一次：生命上限 ×' + (a.hpMul||1).toFixed(2) + ' → ×' + ((a.hpMul||1)*0.5).toFixed(2),
           detail: '当场随机抽四张，代价是生命上限 ×0.5、当前血量在「新上限」的基础上再减半（1000 血满血 → 上限 500、血 250；当前只有 300 血 → 150）。抽完的卡直接生效。只有 1 层，抽完这张就没了。' },
  deal: { nx: a => '持续 ' + Math.round(a.dealT||0) + ' 秒 → ' + (Math.round(a.dealT||0)+60) + ' 秒',
          detail: '血量立刻变成 1 点，60 秒内伤害 ×2、子弹必定穿 3 个目标、每杀一个回 1% 最大生命。这段时间自动打药会关掉（不然一嗑药这张卡就白拿了）。最多 2 层，时长相加；结束时回半血。' },
  allin: { nx: a => '现在手上 ' + ((a.picks||[]).length) + ' 张 → 换 ' + (((a.picks||[]).length)+1) + ' 张',
           detail: '把所有卡一次全扔掉（不用你一张张点），再从池子里随机补「原来的数量 + 1」张——多给的那张会标「新」。不会抽到豪赌、赌徒、洗牌、梭哈这几张开界面的卡。只有 1 层；手上没牌就不刷出来。' }
};
for (const u of UPGRADES){
  const inf = UPG_INFO[u.id];
  if (inf){ u.detail = inf.detail; u.nx = inf.nx; }
}
/* 卡面简略、选中后详细：这两个取值函数让绘制和测试共用一套 */
function upgDetail(u){ return (u && u.detail) || (u && u.desc) || ''; }
function upgNext(u){ return (u && u.nx && ar) ? (u.nx(ar) || '') : ''; }

function upgAvailable(a, u){
  const cnt = a.picks.filter(n => n === u.name).length;
  return cnt < (u.max || 99);
}

/* 赌徒/豪赌：当场从还能拿的卡里随机抽 n 张，直接生效。
   抽卡卡本身不进奖池，免得递归出"抽到抽卡"的链子；
   抽完把卡面挂到 ar.drawShow，选完卡会定住世界、一张张翻给玩家看。 */
/* ---------------- 卡池统一入口 ----------------
   每张卡在 UPGRADES 里都有一个 cat：
     stack   可叠层（受 u.max 管）
     once    一次性：拿完就消失，不进 picks、不占牌位
     special 特殊：会改牌堆 / 开界面（洗牌、赌徒、豪赌、梭哈）
   约定：cat !== 'stack' 必须正好等于 ONCE_UPG 里那 7 张（_tCards.js 会校验）。

   三个抽池场景都从这里拿，规则只写一遍：
     offer   升级三选一
     draw    赌徒 / 豪赌的奖池
     swap    梭哈的候选池
     supply  空投白给的那一张（不要取舍卡，也别给一次性/特殊卡）
   （洗牌摊牌用的是 shuffleItems()，不归这里管。） */
function cardPoolFor(a, ctx){
  const out = [];
  for (const u of UPGRADES){
    if (!upgAvailable(a, u)) continue;
    /* 火箭筒专属卡：手里没炮就别刷出来，免得抽到一张纯废牌 */
    if (u.rwOnly && !(player && player.guns && player.guns.rpg)) continue;
    const cat = u.cat || 'stack';
    /* 梭哈：只换能叠层的卡 —— 一次性卡不占牌位，混进来就凑不齐"原数量 + 1" */
    if (ctx === 'swap' && cat !== 'stack') continue;
    /* 空投：白给的别塞取舍卡，也别塞一次性/特殊卡（那些该由玩家自己选） */
    if (ctx === 'supply' && (u.trade || cat !== 'stack')) continue;
    /* 抽卡池：不再抽到"自己也开界面"的卡，免得递归出「抽到抽卡」的链子 */
    /* honest 也会立刻打开整屏赌注界面；若由豪赌抽中，它会藏在翻牌层下面，
       关掉翻牌后仍冻结战斗，看起来就像所有卡都点不动。 */
    if (ctx === 'draw' && (u.id === 'draw2' || u.id === 'draw4' || u.id === 'allin' || u.id === 'honest')) continue;
    if (u.id === 'shuffle'){
      if (ctx === 'draw' && a._shufBusy) continue;   /* 正在洗牌就别再发洗牌卡 */
      if (shuffleItems().length < 2) continue;       /* 手上没牌可洗就别发这张 */
    }
    /* 梭哈：手上没牌就没得换，一张都不换等于白拿 */
    if (u.id === 'allin' && ctx === 'offer' && !a.picks.length) continue;
    out.push(u);
  }
  return out;
}

function drawCards(a, n){
  const out = [], cards = [];
  const pool = cardPoolFor(a, 'draw');
  for (let i = 0; i < n && pool.length; i++){
    const u = pool.splice(Math.floor(arenaRandom() * pool.length), 1)[0];
    u.apply(a);
    if (!ONCE_UPG[u.id]) a.picks.push(u.name);   /* 一次性卡用完就没了，不占牌位 */
    out.push(u.name + ' · ' + u.desc);
    cards.push({ id: u.id, name: u.name, desc: u.desc, tone: u.tone || '#ffd24a', trade: !!u.trade,
                 max: u.max || 0, count: a.picks.filter(function(x){ return x === u.name; }).length });
    if (upgAvailable(a, u)) pool.push(u);      /* 没到上限的卡允许重复抽到 */
  }
  a.drawShow = {
    title: (n >= 4 ? '豪赌' : '赌徒') + ' · 抽到 ' + out.length + ' 张',
    cards: cards, t: 0, closed: !out.length, from: ar.freeze ? 'card' : 'field'
  };
  if (out.length) logInfo('upg', '抽卡 · ' + out.map(x => x.split(' · ')[0]).join(' / '));
  return out;
}

function arenaOffer(){
  /* 池子规则全在 cardPoolFor 里：洗牌要手上够两张、梭哈要手上有牌 */
  const pool = cardPoolFor(ar, 'offer');
  const pick = [];
  for (let i=0;i<3 && pool.length;i++){
    pick.push(pool.splice(Math.floor(arenaRandom()*pool.length), 1)[0]);
  }
  ar.armIdx = -1;
  if (!pick.length){
    /* 卡池抽干了（每张都到上限）：别再停在这个界面上，给个回满血直接继续 */
    ar.choices = null; ar.freeze = false;
    player.hp = arenaMaxHp();
    setMsg('该拿的卡都拿满了 · 回满血', 2.2);
    beep(660, 0.12, 'triangle', 0.05, 990);
    return;
  }
  ar.choices = pick;
  ar.freeze = true;
  beep(880, 0.10, 'square', 0.05, 1240);
}

/* 点卡要两下：第一下只是把这张"举起来"（防手滑），再点同一张才真拿。
   键盘 1/2/3 走同一条路，两个入口的行为必须一致。 */
function arenaArm(i){
  if (!ar || ar.shuf || !ar.freeze || !ar.choices || (ar.drawShow && !ar.drawShow.closed)) return;
  if (!ar.choices[i]) return;
  if (ar.armIdx === i){ arenaPick(i); return; }
  ar.armIdx = i;
  if (ar.choices[i].id === 'honest' && !ar.honestSeen){
    ar.honestSeen = true;
    ar.honestAt = sndNow();
    if (typeof sndPlay === 'function') sndPlay('card.honest', 0.9);
  }
  beep(700, 0.07, 'square', 0.035, 900);
}

function arenaPick(i){
  if (!ar || ar.shuf || !ar.freeze || !ar.choices || (ar.drawShow && !ar.drawShow.closed)) return;
  const u = ar.choices[i];
  if (!u) return;
  ar.armIdx = -1;
  u.apply(ar);
  /* 洗牌没开成（拿卡之后又被巢母锁掉一张）：补一张别的 */
  let _shufFail = '';
  if (u.id === 'shuffle' && !(ar && ar.shuf)) _shufFail = arenaFreeUpgrade();
  /* 三个入口都得过一遍：一次性卡用完就没了，不占牌位 */
  if (!ONCE_UPG[u.id]) ar.picks.push(u.name);
  ar.choices = null;
  /* 如果这张卡开了整屏界面（洗牌），就别把世界解冻了 */
  ar.freeze = !!(ar.shuf || (ar.drawShow && !ar.drawShow.closed));
  /* freePicks = 这次奖励总共能抽几张；抽一张减一，还有就继续 */
  if (ar.freePicks > 0){
    ar.freePicks--;
    if (ar.freePicks > 0) arenaOffer();
  }
  player.hp = Math.min(player.hp, arenaMaxHp());
  if (_shufFail) setMsg('没牌可洗 · 换你一张「' + _shufFail + '」', 2.2);
  else  setMsg(u.name + ' · ' + u.desc, 1.8);
  beep(660, 0.10, 'triangle', 0.05, 990);
  /* 抽卡类：定住世界，把抽到的牌一张张翻出来 */
  if (ar.drawShow && !ar.drawShow.closed){
    ar.drawShow.from = 'card';
    ar.drawShow.t = 0;
    ar.freeze = true;                  /* 抽卡卡一律定住看牌，不会和“选卡界面”抢输入 */
  }
}

/* 赌徒抽到的那几张，在屏幕中上摊 4 秒，让人知道刚才吃进去的是什么 */
function closeDrawShow(){
  if (!ar || !ar.drawShow) return;
  ar.drawShow.closed = true;
  ar.drawShow = null;
  /* 抽卡可能开出洗牌；关掉展示不等于所有界面都已结束。
     洗牌结束后若还有 BOSS 奖励，也要交回选卡而不是恢复战斗。 */
  ar.freeze = !!(ar.shuf || ar.choices || ar.over);
}

/* 技能卡上的小符号：纯矢量画，不依赖字体，缩到 20px 也认得出 */
function cardGlyph(id, cx, cy, R, tone){
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = tone; ctx.fillStyle = tone;
  ctx.lineWidth = Math.max(1.3, R * 0.16);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const u = R / 10;                       /* 统一以 10 为半径单位 */
  const star = (n, r1, r2, rot) => {
    ctx.beginPath();
    for (let i = 0; i < n * 2; i++){
      const a = (rot || -Math.PI/2) + i * Math.PI / n;
      const rr = (i % 2 ? r2 : r1) * u;
      const x = Math.cos(a) * rr, y = Math.sin(a) * rr;
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    }
    ctx.closePath(); ctx.fill();
  };
  switch (id){
    case 'dmg': star(5, 9, 4.2); break;
    case 'crit': case 'cdmg':
      ctx.beginPath(); ctx.moveTo(0, -9*u); ctx.lineTo(2.6*u, 0);
      ctx.lineTo(0, 9*u); ctx.lineTo(-2.6*u, 0); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-9*u, 0); ctx.lineTo(0, -2.2*u);
      ctx.lineTo(9*u, 0); ctx.lineTo(0, 2.2*u); ctx.closePath(); ctx.fill();
      break;
    case 'rof': case 'spd': case 'dump':
      for (let i = -1; i <= 1; i++){
        const o = i * 4.4 * u;
        ctx.beginPath();
        if (id === 'rof'){ ctx.moveTo(-4*u + o, 3*u); ctx.lineTo(o, -3*u); ctx.lineTo(4*u + o, 3*u); }
        else { ctx.moveTo(-3*u, -4*u + o); ctx.lineTo(3*u, o); ctx.lineTo(-3*u, 4*u + o); }
        ctx.stroke();
      }
      break;
    case 'hp': case 'armor':
      ctx.beginPath(); ctx.moveTo(0, -9*u); ctx.lineTo(7.5*u, -6*u);
      ctx.lineTo(7.5*u, 1*u); ctx.quadraticCurveTo(7.5*u, 7*u, 0, 10*u);
      ctx.quadraticCurveTo(-7.5*u, 7*u, -7.5*u, 1*u); ctx.lineTo(-7.5*u, -6*u);
      ctx.closePath();
      if (id === 'armor'){ ctx.stroke(); ctx.beginPath(); ctx.moveTo(-4*u, 0); ctx.lineTo(4*u, 0); ctx.stroke(); }
      else ctx.fill();
      break;
    case 'leech': case 'debt': case 'patch':
      ctx.beginPath();
      ctx.moveTo(0, 7.5*u);
      ctx.bezierCurveTo(-9*u, 0, -6.5*u, -8*u, 0, -3.5*u);
      ctx.bezierCurveTo(6.5*u, -8*u, 9*u, 0, 0, 7.5*u);
      ctx.closePath(); ctx.fill();
      if (id === 'debt'){ ctx.strokeStyle = '#0b0f14'; ctx.beginPath(); ctx.moveTo(-4*u, 1.5*u); ctx.lineTo(4*u, 1.5*u); ctx.stroke(); }
      if (id === 'patch'){ ctx.strokeStyle = '#0b0f14'; ctx.lineWidth = Math.max(1.4, R*0.2); ctx.beginPath(); ctx.moveTo(0, -3*u); ctx.lineTo(0, 4*u); ctx.moveTo(-3.4*u, 0.5*u); ctx.lineTo(3.4*u, 0.5*u); ctx.stroke(); }
      break;
    case 'reg': case 'god':
      ctx.beginPath(); ctx.arc(0, 0, 7.5*u, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, -4.5*u); ctx.lineTo(0, 4.5*u); ctx.moveTo(-4.5*u, 0); ctx.lineTo(4.5*u, 0); ctx.stroke();
      break;
    case 'mag': case 'pick':
      ctx.beginPath(); ctx.rect(-4.5*u, -8*u, 9*u, 16*u); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-4.5*u, -4*u); ctx.lineTo(4.5*u, -4*u);
      if (id === 'pick'){ ctx.moveTo(-4.5*u, 0); ctx.lineTo(4.5*u, 0); ctx.moveTo(-4.5*u, 4*u); ctx.lineTo(4.5*u, 4*u); }
      ctx.stroke();
      break;
    case 'burst2':
      for (const dx of [-3.4, 3.4]){
        ctx.beginPath(); ctx.moveTo(dx*u, -8*u); ctx.lineTo(dx*u + 3.4*u, 0);
        ctx.lineTo(dx*u, 8*u); ctx.lineTo(dx*u - 3.4*u, 0); ctx.closePath(); ctx.fill();
      }
      break;
    case 'ricochet':
      ctx.beginPath(); ctx.moveTo(-8*u, 6*u); ctx.lineTo(-1*u, -5*u); ctx.lineTo(3.5*u, 4*u);
      ctx.lineTo(8.5*u, -6*u); ctx.stroke();
      break;
    case 'reload':
      ctx.beginPath(); ctx.arc(0, 0, 7*u, -2.4, 2.2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(5.2*u, -6*u); ctx.lineTo(8.4*u, -3.4*u); ctx.lineTo(4.6*u, -1.4*u);
      ctx.closePath(); ctx.fill();
      break;
    case 'pierce': case 'noclip':
      ctx.beginPath(); ctx.moveTo(-8.5*u, 0); ctx.lineTo(7*u, 0); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(3.4*u, -3.6*u); ctx.lineTo(8.6*u, 0); ctx.lineTo(3.4*u, 3.6*u);
      ctx.closePath(); ctx.fill();
      ctx.beginPath();
      if (id === 'pierce'){ ctx.rect(-1.4*u, -7.6*u, 2.8*u, 15.2*u); }
      else { ctx.setLineDash([2.4*u, 2.2*u]); ctx.rect(-8*u, -7*u, 16*u, 14*u); }
      ctx.stroke();
      break;
    case 'boom': case 'chaos':
      star(8, 9, 4.6); break;
    case 'aim': case 'trade2':
      ctx.beginPath(); ctx.arc(0, 0, 7*u, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-9.5*u, 0); ctx.lineTo(-3*u, 0); ctx.moveTo(3*u, 0); ctx.lineTo(9.5*u, 0);
      ctx.moveTo(0, -9.5*u); ctx.lineTo(0, -3*u); ctx.moveTo(0, 3*u); ctx.lineTo(0, 9.5*u); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, 1.8*u, 0, Math.PI*2); ctx.fill();
      break;
    case 'magnet':
      ctx.beginPath(); ctx.arc(0, 1*u, 6.6*u, Math.PI, 0); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-6.6*u, 1*u); ctx.lineTo(-6.6*u, 8*u);
      ctx.moveTo(6.6*u, 1*u); ctx.lineTo(6.6*u, 8*u); ctx.stroke();
      break;
    case 'close': case 'far':
      const d = id === 'close' ? -1 : 1;
      for (const y of [-4.2, 4.2]){
        ctx.beginPath(); ctx.moveTo(-8*u*d, y*u); ctx.lineTo(6*u*d, y*u); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(2*u*d, y*u - 3.4*u); ctx.lineTo(7*u*d, y*u); ctx.lineTo(2*u*d, y*u + 3.4*u);
        ctx.closePath(); ctx.fill();
      }
      break;
    case 'rage': case 'smoke':
      ctx.beginPath(); ctx.moveTo(0, -9*u);
      ctx.bezierCurveTo(7*u, -1*u, 5.5*u, 8*u, 0, 9*u);
      ctx.bezierCurveTo(-6*u, 8*u, -7*u, -1*u, 0, -9*u); ctx.closePath(); ctx.fill();
      break;
    case 'xp':
      ctx.beginPath(); ctx.rect(-7.5*u, -7*u, 15*u, 14*u); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, -7*u); ctx.lineTo(0, 7*u); ctx.stroke();
      break;
    case 'trade1': case 'deal':
      ctx.beginPath(); ctx.moveTo(-7*u, -7*u); ctx.lineTo(7*u, 7*u);
      ctx.moveTo(7*u, -7*u); ctx.lineTo(-7*u, 7*u); ctx.stroke();
      if (id === 'deal'){ ctx.beginPath(); ctx.arc(0, 0, 9*u, 0, Math.PI*2); ctx.stroke(); }
      break;
    case 'gamble': case 'draw2': case 'draw4':
      const cnt = id === 'draw4' ? 4 : id === 'gamble' ? 1 : 2;
      const w = 7*u, h = 9.5*u;
      for (let i = cnt - 1; i >= 0; i--){
        const ox = (i % 2 ? 2.6*u : -2.6*u), oy = (i < 2 ? -2.2*u : 2.2*u);
        ctx.beginPath(); roundRect(ox - w/2, oy - h/2, w, h, 1.8*u);
        if (i === 0){ ctx.fillStyle = 'rgba(0,0,0,0)'; ctx.fill(); ctx.strokeStyle = tone; ctx.stroke(); }
        else ctx.stroke();
      }
      if (id === 'gamble'){
        ctx.fillStyle = tone;
        for (const p2 of [[-1.4,-2.4],[1.4,-2.4],[-1.4,0.6],[1.4,0.6]])
          { ctx.beginPath(); ctx.arc(p2[0]*u, p2[1]*u, 1.1*u, 0, Math.PI*2); ctx.fill(); }
      }
      break;
    case 'sg':
      for (const a of [-0.5, 0, 0.5]){
        ctx.beginPath();
        ctx.arc(Math.sin(a)*6*u, -Math.cos(a)*6*u, 2.1*u, 0, Math.PI*2); ctx.fill();
      }
      ctx.beginPath(); ctx.moveTo(0, 9*u); ctx.lineTo(0, 2*u); ctx.stroke();
      break;
    default:
      ctx.beginPath(); ctx.arc(0, 0, 6.5*u, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, -2.4*u); ctx.lineTo(0, 4*u); ctx.moveTo(0, -6.2*u); ctx.lineTo(0, -5.2*u); ctx.stroke();
  }
  ctx.restore();
}
/* 卡面左上角的小徽章：底色淡淡一层，符号压在上头 */
function cardBadge(id, x, y, R, tone){
  ctx.save();
  ctx.globalAlpha = ctx.globalAlpha * 0.16;
  ctx.fillStyle = tone;
  ctx.beginPath(); ctx.arc(x, y, R + 5, 0, Math.PI*2); ctx.fill();
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = ctx.globalAlpha * 0.92;
  cardGlyph(id, x, y, R, tone);
  ctx.restore();
}

const _ARENA_DRAW_SHOW_LAYOUT={};
function arenaDrawShowLayout(count,width,height,scrollOffset,result){
  /* 张数不定（梭哈最多能换出十来张）：先缩卡宽，缩到底还放不下就拆行，别让卡排到屏幕外 */
  const maxW = width - 60, maxH = height - 190;
  const plans = [
    { rows: 1, cw: 236, gap: 26 },
    { rows: 1, cw: 208, gap: 20 },
    { rows: 1, cw: 178, gap: 16 },
    { rows: 1, cw: 152, gap: 12 },
    { rows: 2, cw: 208, gap: 20 },
    { rows: 2, cw: 176, gap: 16 },
    { rows: 2, cw: 150, gap: 12 },
    { rows: 3, cw: 176, gap: 16 },
    { rows: 3, cw: 150, gap: 12 },
    { rows: 4, cw: 152, gap: 12 }
  ];
  let rows = 1, cw = 236, gap = 26, cols = count, fitted = false;
  for (const pl of plans){
    const c = Math.ceil(count / pl.rows);
    const chh = Math.round(pl.cw * 1.07);
    if (c * pl.cw + (c - 1) * pl.gap <= maxW && pl.rows * chh + (pl.rows - 1) * 20 <= maxH){
      rows = pl.rows; cw = pl.cw; gap = pl.gap; cols = c; fitted = true; break;
    }
  }
  /* 张数多到所有预案都塞不进：横向按最大列数排，纵向多出来的交给滚动。
     以前这里会一路落到初始值（rows=1、cols=count），二十几张牌直接排到屏幕外。 */
  if (!fitted){
    cw = 150; gap = 12;
    cols = Math.max(1, Math.floor((maxW + gap) / (cw + gap)));
    rows = Math.ceil(count / cols);
  }
  const ch = Math.round(cw * 1.07);
  const rowH = ch + 20;
  /* 可视区：标题下面到提示词上面。张数太多时这里只显示一段，用滚轮上下翻。 */
  const viewTop = 140, viewBot = height - 122;
  const availH = Math.max(120, viewBot - viewTop);
  const contentH = rows * rowH - 20;
  const needScroll = contentH > availH;
  const maxSc = Math.max(0, contentH - availH);
  const scroll = needScroll ? clamp(scrollOffset || 0, 0, maxSc) : 0;
  /* 要滚动时内容从顶上排起（不能居中，否则第一排会被裁掉一半） */
  const cy = needScroll ? (viewTop + contentH / 2 - scroll) : (viewTop + availH / 2);
  result.rows=rows;
  result.cw=cw;
  result.gap=gap;
  result.cols=cols;
  result.ch=ch;
  result.rowH=rowH;
  result.viewTop=viewTop;
  result.viewBot=viewBot;
  result.availH=availH;
  result.contentH=contentH;
  result.needScroll=needScroll;
  result.maxSc=maxSc;
  result.scroll=scroll;
  result.cy=cy;
  return result;
}
function drawDrawShow(){
  const d = ar && ar.drawShow;
  if (!d || d.closed || !d.cards || !d.cards.length) return;
  const n = d.cards.length;
  uiButtons = [];
  ctx.save();
  /* 底：压暗一点，但别全黑，场上还在动 */
  ctx.fillStyle = 'rgba(4,7,11,0.62)';
  ctx.fillRect(0, 0, W, H);

  const {rows,cw,gap,cols,ch,rowH,viewTop,viewBot,availH,contentH,needScroll,maxSc,scroll,cy}=arenaDrawShowLayout(n,W,H,d.scroll,_ARENA_DRAW_SHOW_LAYOUT);
  d.scroll = scroll;
  d.view = { top: viewTop, h: availH, need: needScroll, max: maxSc };
  const topY = 92;
  const nameF = cw >= 200 ? 22 : (cw >= 172 ? 20 : 18);
  const descF = cw >= 200 ? 13 : 12;

  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffd24a';
  ctx.font = 'bold 26px "Microsoft YaHei",sans-serif';
  ctx.shadowColor = 'rgba(255,196,80,0.55)'; ctx.shadowBlur = 18;
  ctx.fillText(d.title, W/2, topY);
  ctx.shadowBlur = 0;
  ctx.fillStyle = 'rgba(220,232,244,0.55)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText(d.sub || '已经算进这局了，看一眼就走', W/2, topY + 24);

  ctx.save();
  ctx.beginPath(); ctx.rect(0, viewTop, W, availH); ctx.clip();
  for (let i = 0; i < n; i++){
    const c = d.cards[i];
    const p = clamp((d.t - i * 0.15) / 0.30, 0, 1);
    if (p <= 0) continue;
    const e = 1 - Math.pow(1 - p, 3);
    const sc = 0.86 + 0.14 * e;
    const iRow = Math.floor(i / cols);
    const iCol = i - iRow * cols;
    const inRow = Math.min(cols, n - iRow * cols);
    const rowTotal = cw * inRow + gap * (inRow - 1);
    const bx = W/2 - rowTotal/2 + iCol * (cw + gap) + cw/2;
    const by = cy + (iRow - (rows - 1) / 2) * rowH + (1 - e) * 26;

    ctx.save();
    ctx.globalAlpha = p;
    ctx.translate(bx, by);
    ctx.scale(sc, sc);
    ctx.translate(-cw/2, -ch/2);

    /* 卡面 */
    const g = ctx.createLinearGradient(0, 0, 0, ch);
    g.addColorStop(0, 'rgba(26,36,50,0.98)');
    g.addColorStop(1, 'rgba(12,18,26,0.98)');
    ctx.fillStyle = g;
    roundRect(0, 0, cw, ch, 14); ctx.fill();
    ctx.strokeStyle = c.tone; ctx.lineWidth = 2.2; ctx.globalAlpha = p * 0.9;
    roundRect(0, 0, cw, ch, 14); ctx.stroke();
    ctx.globalAlpha = p;
    /* 顶上一条同色高光，像卡牌稀有度 */
    ctx.fillStyle = c.tone; ctx.globalAlpha = p * 0.85;
    roundRect(0, 0, cw, 5, 3); ctx.fill();
    ctx.globalAlpha = p;

    if (c.trade){
      ctx.fillStyle = 'rgba(255,86,72,0.20)';
      roundRect(cw/2 - 32, 16, 64, 20, 10); ctx.fill();
      ctx.strokeStyle = 'rgba(255,120,104,0.85)'; ctx.lineWidth = 1.1;
      roundRect(cw/2 - 32, 16, 64, 20, 10); ctx.stroke();
      ctx.fillStyle = '#ffb3a6'; ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
      ctx.fillText('取舍', cw/2, 30);
    }
    if (c.isNew){
      /* 梭哈多给的那一张：右上角盖个「新」，一眼能挑出来 */
      ctx.fillStyle = 'rgba(255,150,205,0.24)';
      roundRect(cw - 56, 16, 40, 20, 10); ctx.fill();
      ctx.strokeStyle = 'rgba(255,150,205,0.95)'; ctx.lineWidth = 1.2;
      roundRect(cw - 56, 16, 40, 20, 10); ctx.stroke();
      ctx.fillStyle = '#ffd0e8'; ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
      ctx.fillText('新', cw - 36, 30);
      ctx.fillStyle = c.tone;
      ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
    }
    ctx.textAlign = 'center';
    cardBadge(c.id, 24, c.trade ? 30 : 26, 9, c.tone);
    ctx.fillStyle = c.tone;
    ctx.font = 'bold ' + nameF + 'px "Microsoft YaHei",sans-serif';
    ctx.fillText(c.name, cw/2, c.trade ? 74 : 62);

    ctx.fillStyle = 'rgba(226,236,246,0.88)';
    ctx.font = descF + 'px "Microsoft YaHei",sans-serif';
    let line = '', ly = c.trade ? 108 : 96, ln = 0;
    for (const ch2 of c.desc){
      if (ctx.measureText(line + ch2).width > cw - 34){
        ctx.fillText(line, cw/2, ly); line = ch2; ly += 19;
        if (++ln >= 3) break;
      } else line += ch2;
    }
    if (line && ln < 3) ctx.fillText(line, cw/2, ly);

    ctx.fillStyle = 'rgba(200,214,230,0.5)';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('已拿 ' + c.count + (c.max ? ' / ' + c.max : ''), cw/2, ch - 20);
    ctx.restore();
  }
  ctx.restore();   /* 结束卡片裁剪 */

  /* 还有卡在下面：画个滚动条 + 提示 */
  if (needScroll){
    const barH = Math.max(40, availH * availH / contentH);
    const barY = viewTop + (availH - barH) * (maxSc ? d.scroll / maxSc : 0);
    ctx.fillStyle = 'rgba(255,210,120,0.10)';
    roundRect(W - 26, viewTop, 6, availH, 3); ctx.fill();
    ctx.fillStyle = 'rgba(255,210,120,0.62)';
    roundRect(W - 26, barY, 6, barH, 3); ctx.fill();
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255,210,120,0.72)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText('滚轮上下翻 · 第 ' + (Math.round(d.scroll / rowH) + 1) + ' / ' + rows + ' 排', W/2, viewBot + 14);
  }

  /* 都弹完之后给个提示 */
  const doneAt = (n - 1) * 0.15 + 0.42;
  if (d.t >= doneAt){
    const pl = 0.55 + 0.45 * Math.sin(uiT * 3.4);
    ctx.globalAlpha = pl;
    ctx.fillStyle = '#ffe6b8';
    ctx.font = '14px "Microsoft YaHei",sans-serif';
    ctx.fillText('按任意键 / 点一下 继续', W/2, viewBot + (needScroll ? 52 : 26));
  }
  ctx.restore();
}
/* 选牌展示的滚轮：一次翻一行（约 90px），到底了返回 false 让别的界面接着用 */
function drawShowWheel(dir){
  const d = ar && ar.drawShow;
  if (!d || d.closed || !d.view || !d.view.need) return false;
  const step = 90;
  d.scroll = clamp((d.scroll || 0) + (dir > 0 ? step : -step), 0, d.view.max);
  return true;
}
function arenaGameOver(){
  if (!ar || ar.over) return;
  /* 对局结束不删除存档；删除只能由玩家在存档位界面确认。 */
  ar.over = true; ar.freeze = true;
  ar.shuf = null; ar.drawShow = null; ar.choices = null; ar.armIdx = -1;
  ar._shufBusy = false;
  if (!deathMsgText){
    if (!deathHit) markDeath('bullet', null, 0, 0);
    else { deathCause = deathCauseKey(deathHit.src, deathHit.by); deathMsgText = pickDeathMsg(deathCause); }
  }
  lowHpStop();
  deathView = true; deathViewT = 0;
  state = 'arenaOver';
  stopSiren();
  sfxAlarm();
  logWarn('arena', '割草结束 · 第 ' + ar.wave + ' 波 · 击杀 ' + ar.kills + ' · 等级 ' + ar.level);
}

/* 命中时的爆炸（高爆弹） */
/* 特殊目标的宝箱：三倍经验 + 一张卡 */
function specialReward(e){
  if (!ar || !e || e._specialDone) return;
  e._specialDone = true;
  ar.freePicks += 1;
  for (let i = 0; i < 4; i++) arenaOrb(e.x + rand(-28, 28), e.y + rand(-28, 28));
  setMsg('宝箱打开 · 三倍经验 + 抽一张卡', 2.6);
  sfxWaveClear();
  if (!ar.freeze) arenaOffer();
}

/* 拾荒：打死一个就给手里的枪补几发。只在弹匣没满时补，
   不碰备弹，所以不会把"弹药管理"这件事整个抹掉 */
function arenaAmmoOnKill(){
  if (!ar || !ar.ammoKill) return;
  if ((ar.rwAmmo | 0) >= 4) return;          /* 一枪最多补 4 发，霰弹一炮就不是无限弹 */
  const g = player.gun;
  if (!g || g.kind === 'throw' || !g.cap) return;
  /* m32458：只认"连发步枪"这一类 —— Uzi 的 wid 是 'rifle'、AR15 是 'ar'，两张都要算上。
     霰弹一炮八颗弹丸，配这张卡等于无限弹匣，所以照旧挡在外面。 */
  if (g.wid !== 'rifle' && g.wid !== 'ar') return;
  const add = Math.min(ar.ammoKill, 4 - (ar.rwAmmo | 0), g.cap - g.mag);
  if (add <= 0) return;
  g.mag += add;
  ar.rwAmmo = (ar.rwAmmo | 0) + add;
}

/* 一次开火窗口（180ms）里的多杀不能各算各的：霰弹一炮打死五个人，
   回血最多 6 点、补弹最多 4 发，不然一枪就是满血满弹 */
/* 这次击杀是谁造成的：'blast' = 火箭/高爆的爆炸。
   以前不分来源，一律 180ms 内最多回 6 点 —— 那是为了防"霰弹一炮八个弹丸一枪满血"，
   但火箭一发清一片也被这 6 点卡死，玩家会觉得收割是坏的。 */
var arKillSrc = 'bullet';     /* 用 var：块里声明也照样能全局看见，测试和别的文件都能改 */

function arenaKillReward(){
  if (!ar) return;
  const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  if (!(ar.rwT > now)){ ar.rwT = now + 180; ar.rwHeal = 0; ar.rwAmmo = 0; }
  const _capHp = (arKillSrc === 'blast') ? 30 : 6;   /* 爆炸一次清一片，上限放宽到 30 */
  if (ar.leech && (ar.rwHeal | 0) < _capHp){
    const h = Math.min(ar.leech, _capHp - (ar.rwHeal | 0));
    ar.rwHeal = (ar.rwHeal | 0) + h;
    player.hp = Math.min(arenaMaxHp(), player.hp + h);
  }
  arenaAmmoOnKill();
  /* 孤注一掷：每杀一个回 1% 最大生命（不进上面那个 6 点封顶，它本来就很小） */
  if (arenaDealOn()){
    player.hp = Math.min(arenaMaxHp(), player.hp + Math.max(1, Math.round(arenaMaxHp() * 0.01)));
  }
}

function arenaBoom(e, dmg){
  if (!ar || ar.boom <= 0) return;
  if (arenaRandom() > ar.boom) return;
  const R = 74;
  for (const o of enemies.slice()){
    if (o === e) continue;
    if (dist(o.x, o.y, e.x, e.y) > R) continue;
    o.hp = (o.hp === undefined ? 100 : o.hp) - dmg*0.55;
    arKillSrc = 'blast';
    if (o.hp <= 0) killTestEnemy(o);
    else eStatusSet(o, 'hurt', 0.3);
    arKillSrc = 'bullet';
  }
  impactFx(e.x, e.y, fxRand(0, TAU), true, 26);
  /* 这一下是真的炸开了周围，但以前只有一发普通的命中火花，玩家看不出范围 —— 补一圈小冲击波 */
  blastRings.push({ x:e.x, y:e.y, R:R, t:0, life:0.42, small:true });
  camShake = Math.max(camShake, 0.35);
  sfxHit(false);
}

/* 督军的"脾气"全在这里，正常关卡一行都碰不到 */

/* ================= 老实抽卡，很枯燥吧？ =================
   一张"赌卡"：先挑一张自己的卡当赌注，之后每打完 2 波开一次奖。
     赢 → 那张卡 +1 级；小概率一次 +2 级（等级越高越容易连升）。
     输 → 她带着那叠牌跑路，整张卡作废、效果结束。
   目标卡等级越高，成功率越高（Lv1 50% → Lv2 75% → 88% 封顶）—— 这是"越往上越值得赌"的唯一钩子，
   也是这张卡不烂的唯一理由：低等级赌是纯亏，高等级赌才是划算买卖。
   四条结束条件，缺一条都会变成"白嫖一个永动机"：
     1. 升到满级 → 玩家自己决定换一张接着赌，还是收手；
     2. 跑路 → 效果结束，赌注那张牌也没了；
     3. 这张卡自己被洗牌/梭哈扔掉 → 立即结束（静默，不弹提示）；
     4. 赌注被别人洗掉/扔掉 → 结束。
   巢母不能封这张卡（spawnerBanNext 里跳过它）。 */
const ER_NAME = '老实抽卡，很枯燥吧？';
const ER_PERIOD = 2;         /* 每打过几波开一次奖 */
const ER_ROLL_T = 1.10;      /* 摇奖动画时长（秒） */

function erDef(nm){
  if (typeof UPGRADES === 'undefined') return null;
  return UPGRADES.find(function(q){ return q.name === nm; }) || null;
}
/* 这张卡现在几级（就是它在 picks 里出现几次） */
function erLevel(nm){
  if (!ar || !ar.picks || !nm) return 0;
  let n = 0;
  for (const x of ar.picks) if (x === nm) n++;
  return n;
}
/* 能拿来赌的卡：会叠层、还没满级、不是这张赌卡自己 */
function erCands(){
  const out = [], seen = Object.create(null);
  if (!ar || !ar.picks) return out;
  for (const nm of ar.picks){
    if (nm === ER_NAME || seen[nm]) continue;
    const u = erDef(nm);
    if (!u || (u.cat || 'stack') !== 'stack') continue;   /* 一次性/特殊卡不进牌位，也没得升 */
    const lv = erLevel(nm), mx = u.max || 99;
    if (lv <= 0 || lv >= mx) continue;
    seen[nm] = 1;
    out.push({ name: nm, id: u.id, tone: u.tone || '#ffd24a', desc: u.desc || '', lv: lv, max: mx });
  }
  /* 等级高的排前面：这张卡的核心就是"赌高的那张" */
  /* m32388：先说颜色，再说等级 —— 同一色相的卡扎堆排在一起（跟洗牌界面同一套规则：
     红→橙→黄→绿→青→蓝→紫），同色里等级高的往上一格，等级一样再按名字稳定排。
     以前只按等级排，一整屏五颜六色混着，眼睛没法扫。 */
  out.sort(function(a, b){
    const ha = (typeof toneHue === 'function') ? toneHue(a.tone) : 999;
    const hb = (typeof toneHue === 'function') ? toneHue(b.tone) : 999;
    if (Math.abs(ha - hb) > 0.001) return ha - hb;
    if (b.lv !== a.lv) return b.lv - a.lv;
    if (a.name !== b.name) return a.name < b.name ? -1 : 1;
    return 0;
  });
  return out;
}
/* 成功率：等级越高越敢赌 */
function erP1(lv){
  if (lv <= 1) return 0.50;                       /* 开局就得让玩家尝到甜头，别一上来就劝退 */
  if (lv === 2) return 0.75;                      /* 一升二级整整多 25 个点，这是这张卡的钩子 */
  return Math.min(0.88, 0.75 + 0.045 * (lv - 2));  /* 三级 79.5%　四级 84%　五级起 88% 封顶 */
}
/* 连升两级的概率（在"已经成功"之后再判一次） */
function erP2(lv){ return Math.min(0.35, 0.05 + 0.05 * lv); }

function erStart(){
  if (!ar) return;
  if (!ar.er) ar.er = { on: true, target: '', waves: 0, stage: '', t: 0, res: null, pick: null, hit: null, pend: true };
  else { ar.er.on = true; ar.er.pend = true; }
  ar.er.stage = '';
}
function erStop(msg){
  if (!ar || !ar.er) return;
  ar.er = null;
  /* 一次性卡：不管哪种收场（跑路 / 收手 / 没牌可选 / 被洗掉），
     这张牌都从背包里消失，一点痕迹不留；以后还能再抽到、再选一次。
     删牌会让 ar.picks 的下标整体前移，巢母封卡的索引得跟着重映射。 */
  ar.honestSeen = false;          /* 下次再抽到，红光和音效重新来一遍 */
  if (ar.picks){
    let at = ar.picks.indexOf(ER_NAME);
    if (at >= 0){
      if (ar.banIdx && ar.banIdx.length){
        ar.banIdx = ar.banIdx.map(function(q){ return q > at ? q - 1 : (q === at ? -1 : q); })
                           .filter(function(q){ return q >= 0; });
      }
      while (at >= 0){ ar.picks.splice(at, 1); at = ar.picks.indexOf(ER_NAME); }
      arenaRebuildStats();
    }
  }
  /* 界面没了就得把世界放行，否则会留下"半边黑、HUD 全消失、还动不了"的死画面 */
  ar.freeze = !!(ar.shuf || ar.choices || (ar.drawShow && !ar.drawShow.closed) || ar.over);
  if (msg) setMsg(msg, 2.4);
}
/* 每帧收口：牌没了就结束，别留一个悬空状态在结算里 */
/* 不管这张卡是从挑卡界面拿的、洗牌换来的、还是别的途径塞进背包的，
   只要手上有了它而赌局没在跑，就自动开局一次（每局只自动开一次）。
   顺带把"到手那一刻"记下来，加成一览里它就会慢慢渗出红光。 */
function erAutoBegin(){
  if (!ar || ar.er) return;
  if (!ar.picks) return;
  if (ar.picks.indexOf(ER_NAME) < 0) return;
  if (ar.over) return;
  erStart();
  ar.honestAt = sndNow();
  ar.honestSeen = true;
}

function erGuard(){
  if (!ar || !ar.er || !ar.picks) return;
  if (ar.picks.indexOf(ER_NAME) < 0){ erStop(''); return; }          /* 自己被洗掉：静默结束 */
  if (ar.er.target && !ar.er.res && erLevel(ar.er.target) <= 0){
    erStop('赌注没了 · 老实抽卡结束');
  }
}
function erOpenPick(mode){
  const st = ar && ar.er;
  if (!st) return;
  st.pick = erCands();
  st.stage = mode || 'pick';
  st.t = 0;
  st.res = null;
  ar.freeze = true;
  if (!st.pick.length){
    erStop('没有能升级的卡了 · 老实抽卡结束');
    ar.freeze = false;
  }
}
/* 开一次奖：没赌注先挑，赌注满级了就换一张 */
function erFire(){
  const st = ar && ar.er;
  if (!st) return;
  st.pend = false;
  if (!st.target){ erOpenPick('pick'); return; }
  const u = erDef(st.target), lv = erLevel(st.target);
  if (!u || lv <= 0){ erStop('赌注没了 · 老实抽卡结束'); return; }
  if (lv >= (u.max || 99)){ erOpenPick('ask'); return; }
  st.roll = { lv: lv, p1: erP1(lv), p2: erP2(lv) };
  st.stage = 'roll';
  st.t = 0;
  st.res = null;
  ar.freeze = true;
  beep(520, 0.09, 'square', 0.05, 760);
}
/* 摇完落地：真正的判定 + 改牌 */
function erApply(){
  const st = ar && ar.er;
  if (!st || !st.roll) return;
  const r = st.roll, nm = st.target, u = erDef(nm);
  const win = arenaRandom() < r.p1;
  let up = 0, lost = false;
  if (win){
    const mx = (u && u.max) || 99;
    up = 1 + (arenaRandom() < r.p2 ? 1 : 0);
    up = Math.min(up, Math.max(0, mx - erLevel(nm)));
    for (let i = 0; i < up; i++) ar.picks.push(nm);
    arenaRebuildStats();
  } else {
    /* 跑路：整叠牌一起没。封卡索引要先重映射，不然巢母封的牌会错位 */
    const drop = nm, remap = [];
    let nn = 0;
    for (let i = 0; i < ar.picks.length; i++){
      if (ar.picks[i] === drop) continue;
      remap[i] = nn++;
    }
    if (ar.banIdx && ar.banIdx.length){
      ar.banIdx = ar.banIdx.map(function(q){ return remap[q]; }).filter(function(q){ return q !== undefined; });
    }
    const keep = [];
    for (const x of ar.picks) if (x !== drop) keep.push(x);
    ar.picks.length = 0;
    for (const x of keep) ar.picks.push(x);
    arenaRebuildStats();
    lost = true;
  }
  st.res = { win: win, up: up, lost: lost, name: nm, before: r.lv, after: r.lv + up, tone: (u && u.tone) || '#ffd24a' };
  st.stage = 'result';
  st.t = 0;
  if (win){
    beep(880, 0.10, 'triangle', 0.06, 1300);
    setTimeout(function(){ beep(1180, 0.12, 'triangle', 0.05, 1560); }, 110);
  } else {
    beep(170, 0.45, 'sawtooth', 0.10, 70);
    beep(90, 0.60, 'triangle', 0.12, 50);
  }
  logInfo('upg', '老实抽卡 · ' + nm + ' Lv' + r.lv + ' → ' + (win ? ('Lv' + (r.lv + up)) : '跑路（牌没了）'));
}
/* 结果界面按继续：满级就换一张接着赌，没满就回去打 */
function erNext(){
  const st = ar && ar.er;
  if (!st || st.stage !== 'result' || !st.res) return;
  const res = st.res;
  st.res = null;
  if (res.lost){ erStop('她带着你的牌跑路了 · 老实抽卡结束'); ar.freeze = false; return; }
  const u = erDef(st.target), lv = erLevel(st.target);
  if (u && lv >= (u.max || 99)){
    const rest = erCands();
    if (rest.length){ erOpenPick('ask'); return; }
    erStop('满级了，也没有别的卡可赌 · 老实抽卡结束');
    ar.freeze = false;
    return;
  }
  st.stage = '';
  ar.freeze = false;
}
function erGiveUp(){
  if (!ar || !ar.er) return;
  erStop('收手 · 老实抽卡结束');
  ar.freeze = false;
}
/* 挑中一张当赌注：立刻开这一次奖 */
function erChoose(name){
  const st = ar && ar.er;
  if (!st || (st.stage !== 'pick' && st.stage !== 'ask')) return;
  if (!name || erLevel(name) <= 0) return;
  const u = erDef(name);
  if (!u) return;
  st.target = name;
  st.pick = null;
  st.res = null;
  beep(660, 0.07, 'square', 0.04, 900);
  erFire();
}
/* 每帧：摇奖推进 + 没别的界面时把挂起的开奖放出来 */
function erTick(dt){
  if (!ar || !ar.er || state !== 'play' || ar.over) return;
  erGuard();
  const st = ar.er;
  if (!st) return;
  if (st.stage === 'roll'){
    st.t += dt;
    if (st.t >= ER_ROLL_T) erApply();
    return;
  }
  if (st.stage === 'result'){ st.t += dt; return; }
  if (st.stage) return;                               /* 正在挑卡：等玩家点 */
  if (ar.drawShow && !ar.drawShow.closed) return;      /* 先让抽卡展示播完，别两个界面叠一起 */
  if (ar.freeze || ar.choices || ar.shuf || ar.over) return;
  if (ar.drawShow && !ar.drawShow.closed) return;
  if (!st.pend) return;
  erFire();
}

/* ---------------- 界面 ---------------- */
function erCardRect(i, n, cols, cw, chh, gap, top, bx){
  const c = i % cols, r = Math.floor(i / cols);
  return { x: bx + c * (cw + gap), y: top + r * (chh + gap), w: cw, h: chh };
}
/* 老实抽卡选卡的滚轮：一次翻一行 */
function erPickWheel(dir){
  const st = ar && ar.er;
  if (!st || !st.view || !st.view.need) return false;
  if (st.stage !== 'pick' && st.stage !== 'ask') return false;
  st.scroll = clamp((st.scroll || 0) + (dir > 0 ? 86 : -86), 0, st.view.max);
  return true;
}
function drawErUI(){
  const st = ar && ar.er;
  if (!st || !st.stage) return;
  uiButtons = [];
  const W2 = W, H2 = H;
  ctx.save();
  ctx.fillStyle = 'rgba(4,7,11,0.994)';
  ctx.fillRect(0, 0, W2, H2);
  ctx.textAlign = 'center';

  /* 标题 */
  ctx.fillStyle = '#ff6a58';
  ctx.font = 'bold 28px "Microsoft YaHei",sans-serif';
  ctx.shadowColor = 'rgba(255,90,74,0.50)'; ctx.shadowBlur = 16;
  ctx.fillText(ER_NAME, W2/2, 46);
  ctx.shadowBlur = 0;

  st.hit = [];

  if (st.stage === 'pick' || st.stage === 'ask'){
    const list = st.pick || [];
    ctx.fillStyle = 'rgba(220,232,244,0.72)';
    ctx.font = '14px "Microsoft YaHei",sans-serif';
    ctx.fillText(st.stage === 'ask'
      ? '赌注满级了 · 换一张接着赌，还是现在收手？'
      : '挑一张卡当赌注 · 每打过 2 波开一次奖，输了整张卡被她带走', W2/2, 76);

    const cols = 2, cw = Math.min(420, (W2 - 200) / 2), chh = 74, gap = 12;
    const rows = Math.ceil(list.length / cols);
    const totalH = rows * chh + (rows - 1) * gap;
    /* 卡多的时候整列会溢出屏幕：给一段可视区，滚轮上下翻（和洗牌界面一个手感） */
    const viewTop = 106, viewBot = H2 - 128;
    const availH = Math.max(140, viewBot - viewTop);
    const needScroll = totalH > availH;
    const maxSc = Math.max(0, totalH - availH);
    st.scroll = needScroll ? clamp(st.scroll || 0, 0, maxSc) : 0;
    st.view = { top: viewTop, h: availH, need: needScroll, max: maxSc };
    const top = needScroll ? (viewTop - st.scroll) : Math.max(120, (H2 - totalH) / 2 - 10);
    const bx = (W2 - (cols * cw + (cols - 1) * gap)) / 2;
    if (needScroll){ ctx.save(); ctx.beginPath(); ctx.rect(0, viewTop, W2, availH); ctx.clip(); }
    for (let i = 0; i < list.length; i++){
      const it = list[i];
      const p = erCardRect(i, list.length, cols, cw, chh, gap, top, bx);
      const hv = mouse.x >= p.x && mouse.x <= p.x + p.w && mouse.y >= p.y && mouse.y <= p.y + p.h;
      ctx.fillStyle = hv ? 'rgba(30,48,62,0.98)' : 'rgba(16,24,34,0.96)';
      roundRect(p.x, p.y, p.w, p.h, 12); ctx.fill();
      ctx.strokeStyle = hv ? it.tone : 'rgba(140,170,200,0.32)';
      ctx.lineWidth = hv ? 2.2 : 1.2;
      roundRect(p.x, p.y, p.w, p.h, 12); ctx.stroke();
      cardBadge(it.id, p.x + 30, p.y + p.h/2, 11, it.tone);
      ctx.textAlign = 'left';
      ctx.fillStyle = it.tone;
      ctx.font = 'bold 18px "Microsoft YaHei",sans-serif';
      ctx.fillText(it.name, p.x + 54, p.y + 27);
      /* 只报这一把的成功率，不写"涨了多少个点" —— 玩家关心的是这次能不能成 */
      ctx.fillStyle = 'rgba(226,236,246,0.78)';
      ctx.font = '13px "Microsoft YaHei",sans-serif';
      ctx.fillText('Lv ' + it.lv + ' / ' + it.max + ' · 成功率 ' + Math.round(erP1(it.lv) * 100) + '%' +
                   ' · 连升 ' + Math.round(erP2(it.lv) * 100) + '%', p.x + 54, p.y + 48);
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(160,180,200,0.55)';
      ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
      ctx.fillText('[' + (i + 1) + ']', p.x + p.w - 22, p.y + 27);
      const idx = i;
      btn(p.x, p.y, p.w, p.h, '', function(){ erChoose(list[idx].name); }, { dark: true, invisible: true });
      st.hit.push(p);
    }
    if (needScroll){
      ctx.restore();
      const barH = Math.max(36, availH * availH / totalH);
      const barY = viewTop + (availH - barH) * (maxSc ? st.scroll / maxSc : 0);
      ctx.fillStyle = 'rgba(255,210,120,0.10)';
      roundRect(W2 - 26, viewTop, 6, availH, 3); ctx.fill();
      ctx.fillStyle = 'rgba(255,210,120,0.62)';
      roundRect(W2 - 26, barY, 6, barH, 3); ctx.fill();
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(255,210,120,0.70)';
      ctx.font = '13px "Microsoft YaHei",sans-serif';
      ctx.fillText('滚轮上下翻 · 共 ' + list.length + ' 张', W2/2, viewBot + 18);
    }
    /* 收手 */
    const by = Math.min(H2 - 96, top + totalH + 28);
    ctx.fillStyle = 'rgba(220,232,244,0.55)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText('Esc 也能收手：收了这张卡就作废，但手上已经拿到的牌都留着', W2/2, by + 20);
    btn(W2/2 - 90, by + 30, 180, 46, '收手（结束）', function(){ erGiveUp(); }, { dark: true });
  } else if (st.stage === 'roll'){
    const r = st.roll || { lv: 1 };
    const u = erDef(st.target);
    const cw = 260, chh = 320;
    const x = (W2 - cw) / 2, y = (H2 - chh) / 2 - 20;
    const k = Math.min(1, st.t / ER_ROLL_T);
    const tilt = Math.sin(st.t * 26) * 0.035 * (1 - k);
    ctx.save();
    ctx.translate(x + cw/2, y + chh/2);
    ctx.rotate(tilt);
    ctx.translate(-cw/2, -chh/2);
    ctx.fillStyle = 'rgba(18,28,40,0.98)';
    roundRect(0, 0, cw, chh, 18); ctx.fill();
    ctx.strokeStyle = (u && u.tone) || '#ffd24a';
    ctx.lineWidth = 2.0 + 0.6 * Math.sin(st.t * 18);
    roundRect(0, 0, cw, chh, 18); ctx.stroke();
    if (u) cardBadge(u.id, cw/2, 52, 16, u.tone);
    ctx.textAlign = 'center';
    ctx.fillStyle = (u && u.tone) || '#ffd24a';
    ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
    ctx.fillText(st.target, cw/2, 108);
    ctx.fillStyle = 'rgba(226,236,246,0.9)';
    ctx.font = 'bold 40px "Microsoft YaHei",sans-serif';
    ctx.fillText('Lv ' + r.lv, cw/2, 176);
    /* 转动的等级条：摇奖过程一眼看得出来在赌什么 */
    const pips = r.lv, maxp = Math.max(pips + 2, 5);
    for (let i = 0; i < maxp; i++){
      const px = cw/2 - (maxp * 18) / 2 + i * 18 + 9;
      const lit = i < pips || (i < pips + (k > 0.55 ? 1 : 0));
      ctx.fillStyle = lit ? ((u && u.tone) || '#ffd24a') : 'rgba(120,140,160,0.35)';
      ctx.beginPath(); ctx.arc(px, 214, 6, 0, TAU); ctx.fill();
    }
    ctx.fillStyle = 'rgba(220,232,244,0.7)';
    ctx.font = '14px "Microsoft YaHei",sans-serif';
    ctx.fillText('成功率 ' + Math.round(r.p1 * 100) + '% · 连升 ' + Math.round(r.p2 * 100) + '%', cw/2, 258);
    ctx.fillStyle = 'rgba(160,180,200,0.6)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText('她在翻你的牌…', cw/2, 288);
    ctx.restore();
    /* 进度条 */
    const bw = 300, bx2 = (W2 - bw) / 2, by2 = H2/2 + 190;
    ctx.fillStyle = 'rgba(255,255,255,0.10)';
    roundRect(bx2, by2, bw, 5, 2.5); ctx.fill();
    ctx.fillStyle = 'rgba(160,230,170,0.85)';
    roundRect(bx2, by2, bw * k, 5, 2.5); ctx.fill();
  } else if (st.stage === 'result'){
    const res = st.res;
    if (!res) return;
    const cw = 420, chh = 210;
    const x = (W2 - cw) / 2, y = (H2 - chh) / 2 - 20;
    const win = res.win;
    ctx.fillStyle = win ? 'rgba(16,34,24,0.98)' : 'rgba(38,14,18,0.98)';
    roundRect(x, y, cw, chh, 18); ctx.fill();
    ctx.strokeStyle = win ? 'rgba(126,231,135,0.75)' : 'rgba(255,110,110,0.7)';
    ctx.lineWidth = 2;
    roundRect(x, y, cw, chh, 18); ctx.stroke();
    ctx.fillStyle = win ? '#9ef2a8' : '#ff9a9a';
    ctx.font = 'bold 30px "Microsoft YaHei",sans-serif';
    ctx.fillText(win ? '升上去了' : '她带着牌跑路了', W2/2, y + 66);
    ctx.fillStyle = 'rgba(230,240,250,0.92)';
    ctx.font = 'bold 20px "Microsoft YaHei",sans-serif';
    if (win){
      ctx.fillText(res.name + '  Lv' + res.before + ' → Lv' + res.after +
                   (res.up >= 2 ? '（连升两级）' : ''), W2/2, y + 112);
      ctx.fillStyle = 'rgba(200,220,235,0.7)';
      ctx.font = '14px "Microsoft YaHei",sans-serif';
      ctx.fillText('赌注还在 · ' + ER_PERIOD + ' 波后再开一次', W2/2, y + 146);
    } else {
      ctx.fillText(res.name + ' · Lv' + res.before + ' 整张被带走了', W2/2, y + 112);
      ctx.fillStyle = 'rgba(200,220,235,0.7)';
      ctx.font = '14px "Microsoft YaHei",sans-serif';
      ctx.fillText('老实抽卡结束 · 手上的其他牌不受影响', W2/2, y + 146);
    }
    btn(W2/2 - 80, y + chh + 22, 160, 46, '继续', function(){ erNext(); }, { dark: true, primary: true });
    ctx.fillStyle = 'rgba(150,170,190,0.5)';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('空格 / 回车继续', W2/2, y + chh + 86);
  }
  ctx.restore();
  flushButtons();          /* btn() 只是登记，真正画出来要靠这一下 */
}

/* 第一次把这张卡「举起来」时，卡牌四周慢慢渗出红光（1.4 秒渐亮，之后呼吸）
   rim=false 画外面的血雾与环（要垫在卡牌底下），rim=true 画卡框本身发烫 */

/* 加成一览里那一行"老实抽卡"：名字底下一直渗着红光（到手 1.4 秒内渐亮，之后常亮呼吸） */
function drawHonestRowGlow(x, y, w, h){
  if (!ar || !ar.honestSeen) return;
  const age = sndNow() - (ar.honestAt || 0);
  const k = age < 0 ? 0 : Math.min(1, age / 1.4);
  if (k <= 0) return;
  const pulse = 0.78 + 0.22 * Math.sin(age * 3.2);
  ctx.save();
  const g = ctx.createLinearGradient(x, y, x + w, y);
  g.addColorStop(0, 'rgba(255,58,48,0)');
  g.addColorStop(0.35, 'rgba(255,58,48,' + (0.30 * k * pulse).toFixed(3) + ')');
  g.addColorStop(0.75, 'rgba(255,58,48,' + (0.20 * k * pulse).toFixed(3) + ')');
  g.addColorStop(1, 'rgba(255,58,48,0)');
  ctx.fillStyle = g;
  roundRect(x, y, w, h, 6); ctx.fill();
  ctx.shadowColor = 'rgba(255,66,54,' + (0.85 * k).toFixed(2) + ')';
  ctx.shadowBlur = 12 * k * pulse;
  ctx.strokeStyle = 'rgba(255,104,88,' + (0.35 * k).toFixed(2) + ')';
  ctx.lineWidth = 1;
  roundRect(x, y, w, h, 6); ctx.stroke();
  ctx.restore();
}

function drawHonestGlow(bx, by, w, h, rim){
  if (!ar || !ar.honestSeen) return;
  const age = sndNow() - (ar.honestAt || 0);
  if (!(age >= 0)) return;
  const k = Math.min(1, age / 1.4);
  const pulse = 0.80 + 0.20 * Math.sin(age * 3.4);
  const cx = bx + w / 2, cy = by + h / 2;
  ctx.save();
  if (!rim){
    const R = Math.max(w, h) * 0.98;
    const g = ctx.createRadialGradient(cx, cy, R * 0.32, cx, cy, R);
    g.addColorStop(0, 'rgba(255,58,48,0)');
    g.addColorStop(0.60, 'rgba(255,58,48,' + (0.22 * k * pulse).toFixed(3) + ')');
    g.addColorStop(1, 'rgba(255,58,48,0)');
    ctx.fillStyle = g;
    ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
    for (let n = 0; n < 3; n++){
      const t = ((age * 0.40) + n / 3) % 1;
      const rr = Math.max(w, h) * (0.52 + t * 0.52);
      ctx.strokeStyle = 'rgba(255,84,70,' + ((1 - t) * 0.40 * k).toFixed(3) + ')';
      ctx.lineWidth = 2.4 * (1 - t) + 0.6;
      ctx.beginPath(); ctx.arc(cx, cy, rr, 0, TAU); ctx.stroke();
    }
  } else {
    ctx.shadowColor = 'rgba(255,66,54,' + (0.9 * k).toFixed(2) + ')';
    ctx.shadowBlur = 26 * k * pulse;
    ctx.strokeStyle = 'rgba(255,104,88,' + (0.62 * k).toFixed(2) + ')';
    ctx.lineWidth = 2.4;
    roundRect(bx, by, w, h, 14); ctx.stroke();
    ctx.shadowBlur = 0;
  }
  ctx.restore();
}

function drawErTag(){
  const st = ar && ar.er;
  if (!st || st.stage) return;
  const nm = st.target;
  if (!nm) return;
  const lv = erLevel(nm), u = erDef(nm), mx = (u && u.max) || 99;
  const left = ER_PERIOD - (st.waves % ER_PERIOD);
  ctx.save();
  ctx.textAlign = 'center';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(150,235,165,0.78)';
  ctx.fillText('老实抽卡 · 赌注 ' + nm + ' Lv' + lv + '/' + mx + ' · 还差 ' + left + ' 波开奖', W/2, 92);
  ctx.restore();
}

/* 输入：键盘先吃，鼠标走 mousedown */
function erKey(e){
  const st = ar && ar.er;
  if (!st || !st.stage) return false;
  if (st.stage === 'roll'){ e.preventDefault(); return true; }
  if (st.stage === 'result'){
    if (e.code === 'Space' || e.code === 'Enter' || e.code === 'Escape' || e.code === 'KeyE'){
      erNext(); e.preventDefault(); return true;
    }
    e.preventDefault(); return true;
  }
  /* pick / ask */
  if (e.code === 'Escape' || e.code === 'Digit0'){
    erGiveUp(); e.preventDefault(); return true;
  }
  const m = /^Digit([1-9])$/.exec(e.code || '');
  if (m){
    const i = (+m[1]) - 1;
    const list = st.pick || [];
    if (list[i]) erChoose(list[i].name);
    e.preventDefault(); return true;
  }
  e.preventDefault(); return true;
}
function erClick(mx, my){
  const st = ar && ar.er;
  if (!st || !st.stage) return false;
  if (st.stage === 'roll') return true;
  if (st.stage === 'result'){ erNext(); return true; }
  const hit = st.hit || [];
  for (let i = 0; i < hit.length && i < (st.pick || []).length; i++){
    const p = hit[i];
    if (mx >= p.x && mx <= p.x + p.w && my >= p.y && my <= p.y + p.h){ erChoose(st.pick[i].name); return true; }
  }
  return true;   /* 弹窗开着就别让点击穿到世界里 */
}
