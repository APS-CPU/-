/* 火箭弹爆炸的「过程」：火球膨胀 + 碎片抛射 + 贴地尘环 + 白闪顿帧
   ---------------------------------------------------------------------------
   以前爆炸只有「一帧白闪 + 一堆黑烟」，没有从亮到灭的过程，看着不重。
   这里补三件事，全部走预烘贴图，一帧最多 3 + 12 次 drawImage：
     1. 火球：三张（白热 / 橙红 / 暗烟），沿 t 依次叠，0.4 秒内膨胀到 1.25R 再散
     2. 尘环：一圈贴地粉尘往外推（不是几何圆线，那个像 UI）
     3. 顿帧：近距离给 40~60ms 世界定格 + 短暂慢放，配合白闪把"重量"压出来
   放在世界层（和血渣同一个绘制段），所以会被夜色/雾影响，但不影响 HUD。
   --------------------------------------------------------------------------- */

var rocketBalls = [];      /* { x, y, R, t, life, rot, seed } */
var rocketDusts = [];
/* 视觉冲击波：两圈一前一后往外推的空气墙（不是画 stroke 的硬圆环） */
var rocketShocks = [];      /* { x, y, R, t, life } */
var rocketBloomT = 0;
var RBF_SPR = null;

/* 造一张预烘贴图：内部画什么由 fn 决定，返回 canvas */
function _rbCanvas(w, fn){
  const c = document.createElement('canvas');
  c.width = w; c.height = w;
  const g = c.getContext('2d');
  fn(g, w);
  return c;
}

/* 一团软光：中心亮、边缘透明，加几个偏心的小团破对称 */
function _rbBlob(g, cx, cy, r, stops){
  const gd = g.createRadialGradient(cx, cy, 0, cx, cy, r);
  for (const s of stops) gd.addColorStop(s[0], s[1]);
  g.fillStyle = gd;
  g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill();
}

function rbSprites(){
  if (RBF_SPR) return RBF_SPR;
  const S = 128;
  /* 白热核心：一堆偏心的小亮团叠出来，边缘才不是个光滑的圆 */
  const hot = _rbCanvas(S, (g, w) => {
    const c = w / 2;
    g.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 22; i++){
      const ang = Math.random() * TAU, dd = Math.random() * c * 0.40;
      const r = c * (0.18 + Math.random() * 0.26);
      _rbBlob(g, c + Math.cos(ang) * dd, c + Math.sin(ang) * dd, r,
              [[0, 'rgba(255,255,238,0.55)'], [0.55, 'rgba(255,236,170,0.22)'], [1, 'rgba(255,210,120,0)']]);
    }
    _rbBlob(g, c, c, c * 0.46, [[0, 'rgba(255,255,255,1)'], [0.45, 'rgba(255,252,232,0.92)'], [1, 'rgba(255,236,180,0)']]);
  });
  /* 橙红火球：外圈带几团拉长的火舌 */
  const warm = _rbCanvas(S, (g, w) => {
    const c = w / 2;
    g.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 26; i++){
      const ang = Math.random() * TAU, dd = c * (0.12 + Math.random() * 0.42);
      const r = c * (0.16 + Math.random() * 0.30);
      _rbBlob(g, c + Math.cos(ang) * dd, c + Math.sin(ang) * dd, r,
              [[0, 'rgba(255,176,84,0.45)'], [0.5, 'rgba(240,110,40,0.22)'], [1, 'rgba(190,60,16,0)']]);
    }
    _rbBlob(g, c, c, c * 0.86, [[0, 'rgba(255,206,132,0.62)'], [0.42, 'rgba(252,140,52,0.5)'], [1, 'rgba(180,52,12,0)']]);
  });
  /* 暗油烟 */
  const dim = _rbCanvas(S, (g, w) => {
    const c = w / 2;
    for (let i = 0; i < 18; i++){
      const ang = Math.random() * TAU, dd = c * (0.1 + Math.random() * 0.4);
      const r = c * (0.2 + Math.random() * 0.3);
      _rbBlob(g, c + Math.cos(ang) * dd, c + Math.sin(ang) * dd, r,
              [[0, 'rgba(88,70,54,0.34)'], [1, 'rgba(40,32,26,0)']]);
    }
  });
  /* 贴地粉尘（横向压扁的软团） */
  const dust = _rbCanvas(S, (g, w) => {
    const c = w / 2;
    _rbBlob(g, c, c, c * 0.9, [[0, 'rgba(196,178,150,0.5)'], [0.55, 'rgba(150,134,112,0.28)'], [1, 'rgba(120,108,90,0)']]);
    _rbBlob(g, c * 1.24, c * 1.1, c * 0.42, [[0, 'rgba(170,154,128,0.3)'], [1, 'rgba(120,108,90,0)']]);
  });
  RBF_SPR = { hot: hot, warm: warm, dim: dim, dust: dust };
  return RBF_SPR;
}

/* 爆炸开始：近距离才顿帧（远处炸就别恶心玩家） */
function rocketFxStart(x, y, R, screenFeedback=true){
  const _R = R || 320;
  rocketBalls.push({ x: x, y: y, R: _R, t: 0, life: 0.42, rot: fxRand(0, TAU), seed: fxRand(0, 100) });
  rocketDusts.push({ x: x, y: y, R: _R, t: 0, life: 0.62 });
  if(screenFeedback)rocketBloomT = 1;
  /* 两圈冲击波：主波 + 0.08s 后跟的副波 */
  rocketShocks.push({ x: x, y: y, R: _R, t: 0, delay: 0,    life: 0.44, w: 0.30 });
  rocketShocks.push({ x: x, y: y, R: _R, t: 0, delay: 0.09, life: 0.52, w: 0.20 });
  /* 被气浪推着走的尘：沿圆周撒一圈，速度朝外 */
  for (let i = 0; i < 18; i++){
    const a = (i / 18) * TAU + fxRand(-0.12, 0.12);
    spawnPart(x + Math.cos(a) * _R * 0.16, y + Math.sin(a) * _R * 0.16,
              a, fxRand(560, 980), fxRand(0.5, 0.9), 'smoke', fxRand(4, 7));
  }
  /* 碎片：土块/砖渣往外抛，落地前带旋转（复用现有粒子池，不加新绘制） */
  for (let i = 0; i < 16; i++){
    const a = fxRand(0, TAU), sp = fxRand(150, 520);
    spawnPart(x + Math.cos(a) * fxRand(0, _R * 0.18), y + Math.sin(a) * fxRand(0, _R * 0.18),
              a, sp, fxRand(0.75, 1.5), 'chip', fxRand(1.1, 2.4));
  }
  for (let i = 0; i < 6; i++){
    const a = fxRand(0, TAU);
    spawnPart(x, y, a, fxRand(40, 150), fxRand(0.7, 1.3), 'smoke', fxRand(4, 8));
  }
  if(!screenFeedback)return;
  const d = player ? Math.hypot(x - player.x, y - player.y) : 9999;
  const near = Math.max(0, 1 - d / (_R * 1.6));
  if (near > 0.05){
    hitStopT = Math.max(hitStopT || 0, 0.03 + 0.03 * near);
    if (typeof slowT !== 'undefined') slowT = Math.max(slowT || 0, 0.12 * near);
  }
  if (typeof fxFlash !== 'undefined') fxFlash = Math.max(fxFlash, 0.72 + 0.22 * near);
}

function rocketFxClear(){
  rocketBalls.length = 0; rocketDusts.length = 0; rocketShocks.length = 0; rocketBloomT = 0;
}

function updateRocketFx(dt){
  for (let i = rocketShocks.length - 1; i >= 0; i--){
    const w = rocketShocks[i];
    w.t += dt;
    if (w.t - w.delay >= w.life) rocketShocks.splice(i, 1);
  }
  for (let i = rocketBalls.length - 1; i >= 0; i--){
    const b = rocketBalls[i];
    b.t += dt;
    if (b.t >= b.life) rocketBalls.splice(i, 1);
  }
  for (let i = rocketDusts.length - 1; i >= 0; i--){
    const d = rocketDusts[i];
    d.t += dt;
    if (d.t >= d.life) rocketDusts.splice(i, 1);
  }
  if (rocketBloomT > 0) rocketBloomT = Math.max(0, rocketBloomT - dt / 0.14);
}

/* 世界坐标下绘制（调用点在 drawImpactFx 之后） */
function drawRocketFx(){
  if (!rocketBalls.length && !rocketDusts.length && !rocketShocks.length && rocketBloomT <= 0) return;
  const S = rbSprites();
  ctx.save();

  /* 0) 视觉冲击波：一个宽度有限的环带，用径向渐变做软边，不用 stroke */
  for (const w of rocketShocks){
    const age = w.t - w.delay;
    if (age < 0) continue;
    const p = Math.min(1, age / w.life);
    const ease = 1 - (1 - p) * (1 - p);
    const rr = w.R * (0.16 + 1.06 * ease);
    const band = w.R * (0.05 + 0.13 * p);           /* 环带厚度：越推越厚一点 */
    const a = Math.pow(1 - p, 1.35) * 0.92;         /* 越远越淡 */
    if (a <= 0.01) continue;
    const g = ctx.createRadialGradient(w.x, w.y, Math.max(1, rr - band), w.x, w.y, rr + band);
    g.addColorStop(0.00, 'rgba(255,226,180,0)');
    g.addColorStop(0.50, 'rgba(255,220,170,' + (a * 0.60).toFixed(3) + ')');
    g.addColorStop(0.64, 'rgba(255,250,232,' + (a * 1.00).toFixed(3) + ')');
    g.addColorStop(0.80, 'rgba(255,210,155,' + (a * 0.40).toFixed(3) + ')');
    g.addColorStop(1.00, 'rgba(255,190,130,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(w.x, w.y, rr + band, 0, TAU);
    ctx.fill();
  }

  /* 1) 贴地尘环：一圈粉尘往外推（在火球下面） */
  for (const d of rocketDusts){
    const p = Math.min(1, d.t / d.life);
    const rr = d.R * (0.34 + 0.86 * p);
    const a = (1 - p) * (1 - p) * 0.85;
    if (a <= 0.01) continue;
    const n = 12;
    for (let i = 0; i < n; i++){
      const ang = (i / n) * TAU + d.R * 0.01;
      const sx = d.x + Math.cos(ang) * rr, sy = d.y + Math.sin(ang) * rr * 0.72;
      const size = d.R * (0.30 + 0.30 * p) * (0.75 + 0.35 * Math.sin(i * 2.1 + d.R));
      ctx.globalAlpha = a * 0.55;
      ctx.drawImage(S.dust, sx - size / 2, sy - size / 2, size, size);
    }
  }

  /* 2) 火球：中心白热 + 橙红外壳 + 外圈暗烟，边缘再撒几团"火舌"打破圆形 */
  for (const b of rocketBalls){
    const p = Math.min(1, b.t / b.life);
    /* 前 1/3 时间冲得快，之后摊开变暗 */
    const e = p < 0.34 ? (p / 0.34) : 1;
    const ease = e * (2 - e);
    const rr = b.R * (0.26 + 0.30 * ease) * (1 + 0.08 * Math.max(0, p - 0.34));
    const fade = p < 0.22 ? 1 : (1 - (p - 0.22) / 0.78);
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.rotate(b.rot + p * 0.30);
    ctx.globalCompositeOperation = 'source-over';
    /* 外圈暗烟（先画，压在最下面） */
    if (p > 0.16){
      ctx.globalAlpha = Math.min(1, (p - 0.16) * 4) * fade * 0.62;
      const dsz = rr * 2.1;
      ctx.drawImage(S.dim, -dsz / 2, -dsz / 2, dsz, dsz);
    }
    /* 火舌：几团偏心的热斑，让边缘不圆 */
    if (p < 0.75){
      const n = 4;
      for (let i = 0; i < n; i++){
        const ang = b.rot * 1.7 + i * (TAU / n) + Math.sin(b.seed + i) * 0.5;
        const lr = rr * (0.80 + 0.20 * Math.sin(b.seed * 3.1 + i * 1.7));
        const sz = rr * (0.52 + 0.16 * Math.cos(b.seed + i * 2.3));
        ctx.globalAlpha = fade * 0.55;
        ctx.drawImage(S.warm, Math.cos(ang) * lr - sz / 2, Math.sin(ang) * lr * 0.9 - sz / 2, sz, sz);
      }
    }
    /* 橙红主体 */
    ctx.globalAlpha = fade * 0.85;
    ctx.drawImage(S.warm, -rr, -rr, rr * 2, rr * 2);
    /* 白热核心：只在前半段 */
    if (p < 0.55){
      const hsz = rr * 0.55 * (1 - p / 0.55) + rr * 0.10;
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = Math.min(1, (0.55 - p) * 2.4) * fade;
      ctx.drawImage(S.hot, -hsz, -hsz, hsz * 2, hsz * 2);
      ctx.globalCompositeOperation = 'source-over';
    }
    ctx.globalCompositeOperation = 'source-over';
    ctx.restore();
  }

  /* 3) 炸点那一下的白光（很短的 bloom，压在火球上） */
  if (rocketBloomT > 0){
    const R0 = (rocketBalls[0] ? rocketBalls[0].R : 320) * 0.88;
    const bx = rocketBalls[0] ? rocketBalls[0].x : (rocketDusts[0] ? rocketDusts[0].x : 0);
    const by = rocketBalls[0] ? rocketBalls[0].y : (rocketDusts[0] ? rocketDusts[0].y : 0);
    const gd = ctx.createRadialGradient(bx, by, 0, bx, by, R0);
    const a = rocketBloomT * 0.26;
    gd.addColorStop(0, 'rgba(255,250,235,' + a.toFixed(3) + ')');
    gd.addColorStop(0.45, 'rgba(255,196,120,' + (a * 0.45).toFixed(3) + ')');
    gd.addColorStop(1, 'rgba(255,150,70,0)');
    ctx.globalAlpha = 1;
    ctx.fillStyle = gd;
    ctx.beginPath(); ctx.arc(bx, by, R0, 0, TAU); ctx.fill();
  }
  ctx.restore();
}
