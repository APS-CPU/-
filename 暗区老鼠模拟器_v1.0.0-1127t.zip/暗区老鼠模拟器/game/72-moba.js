/* 72-moba.js —— 军团推塔（娱乐模式·独立观战关卡）
   三条路汇合到双方火箭炮塔；
   每边六座机枪阵地（每路两座）。每 30 秒两边各出 6 个手枪小兵自动推进，
   遇敌交战。玩家是上帝视角的指挥官：隔一段时间拿到 3 个随机精英兵，
   点"上/中/下"把人投到那条路，从自己大本营出发。打到对面炮塔血量归零即胜。
   所有数值集中在 MOBA_DEF，改一个文件就够。 */

const MOBA_DEF = {
  w: 7200, h: 4800,
  laneY: [700, 2400, 4100],      /* 上/中/下三条路的纵向位置（间距 780，听觉范围 800 也不至于串线） */
  laneBend: 1400,                 /* 上路往上走、下路往下走的横移量：先把人拉到本路高度再横推 */
  baseX: 520,                    /* 左右大本营中心距边界的距离 */
  coreHp: 5000,
  fortAt: [0.10, 0.24],          /* 中路两座阵地 */
  outerFortAt: [0.50, 0.20],     /* 上下路：斜段中点、直段前沿（从己方起算） */
  coverRestore: 180,
  coverRetry: 2,
  laneCover: [
    {type:'crate', offset:190, shoulder:128},
    {type:'wreckcar', offset:450, shoulder:-168, skin:'rust'},
    {type:'crate2', offset:700, shoulder:156}
  ],
  spawnBelow: 105, spawnGap: 40,
  waveT: 30, waveN: 6,           /* 每 30 秒 6 个兵 */
  cardT: 22, cardN: 3,           /* 每 22 秒 3 个随机精英 */
  squad: ['spec', 'spec', 'spec', 'specFlank'],   /* 精英池（ENEMY_TYPES 的 key） */
  minionKind: 'grunt',
  /* m21343：本模式自己的行军速度（px/秒），不吃全局 CFG.eSpeed 和难度档位。
     小兵慢一点、精英队快一点，玩家能看出"这波是兵还是人"。 */
  minionSpd: 112, squadSpd: 148,
  camSpd: 3.2, zoom: 0.30, zoomMin: 0.10, zoomMax: 1.4,
};
const MOBA_SINGLE_DEF = {
  ...MOBA_DEF,
  name: '军团推塔 · 单路',
  w: 5100, h: 1180,
  laneY: [590],
  baseX: 220,
  fortAt: [1500 / (5100 - 2 * 220)],
  laneCover: [
    ...MOBA_DEF.laneCover.map(cover=>({...cover,offset:Math.min(cover.offset,540)})),
    {type:'crate', offset:600, shoulder:-260, side:-1},
    {type:'crate', offset:580, shoulder:-280, side:1},
    {type:'wreckcar', offset:350, shoulder:260, side:-1, skin:'olive'},
    {type:'wreckcar', offset:320, shoulder:235, side:1, skin:'blue'},
    {type:'crate2', offset:75, shoulder:-190, side:-1},
    {type:'crate2', offset:110, shoulder:168, side:1}
  ],
  waveN: 2, zoom: 0.25, zoomMin: 0.15,
};
var mobaLvl = null;   /* 用 var：cur() 在 12-levels.js 里先于本文件定义，let 会撞 TDZ */
var mobaSavedCfg = null, mobaSavedDiff = '';   /* 进场前备份玩家难度，走的时候还回去 */

function mobaDef(L=mobaLvl){ return L?.mobaDef || MOBA_DEF; }
function mobaNewState(D=mobaDef()){
  return {
    t: 0, waveT: 1.2, cardT: 6, over: 0, winner: -1, msg: '', msgT: 0,
    wave: 0, kills: [0, 0],      /* 已出兵波数 / 双方击杀 */
    cores: [], forts: [], covers: [], cards: D.cardN, maxCards: D.cardN * 2,
    zoom: D.zoom, pick: -1, help: 0,
  };
}
function mobaOn(L){
  L = L || (typeof cur === 'function' ? cur() : null);
  return !!(L && L.moba && mobaLvl && L === mobaLvl);
}
function mobaSuppressCombatFeedback(source){return mobaOn() && source!==player;}
function mobaSideOf(o){ return (o && o.mobaSide === 1) ? 1 : 0; }
function mobaFac(side){ return side ? 'bandit' : 'enemy'; }
function mobaEnemySide(side){ return side ? 0 : 1; }

/* ---------- 1. 关卡数据 ---------- */
function buildMobaLevel(D=MOBA_DEF){
  const W = D.w, H = D.h;
  const walls = [];
  const add = (x, y, w, h) => walls.push({ x, y, w, h, mapBoundary:true });
  /* 外围：留出口子给镜头，只挡人不挡弹 */
  const t = 40;
  add(0, 0, W, t); add(0, H - t, W, t); add(0, 0, t, H); add(W - t, 0, t, H);
  const lanes = D.laneY, brk = [];
  for (const y of lanes){
    for (const cover of D.laneCover){
      const def = COVER_DEF[cover.type], [w,h] = def.sz;
      for (const side of cover.side ? [cover.side] : [-1,1]){
        const item = {t:cover.type, x:W/2+side*cover.offset-w/2, y:y+cover.shoulder-h/2, w,h, skin:cover.skin};
        (def.st === 'brk' ? brk : walls).push(item);
      }
    }
  }
  return {
    name: D.name || '军团推塔', mobaDef:D, w: W, h: H, theme: 'dark',
    moba: true, ver: 2, chapter: 0, devOnly: true,
    weapons: ['knife'], startMeds: 0, startSmokes: 0, enemyHp: 100,
    dropGuns: false, healHint: false,
    rules: { mode: 'stealth', human: true, fog: false, nightGlow: 0, noMark: true, noExtract: true, hearK: 1, walkDelay: 0.12, thermal: false, noTalk: true },
    start: { x: D.baseX, y: lanes[Math.floor(lanes.length/2)] },
    extract: { x: -9000, y: -9000, w: 10, h: 10 },
    walls, brk, loot: [], slots: [], cameras: [], drones: [],
  };
}

/* ---------- 2. 路线 ---------- */
/* 每条路一组航点；side 0 从左边出发，side 1 从右边出发。
   路径先收拢到大本营，再分成三路，最后在对面大本营再收拢。 */
function mobaWaypoints(side, lane){
  const D = mobaDef(), W = D.w;
  const y = D.laneY[lane];
  const x0 = side ? W - D.baseX : D.baseX;
  const x1 = side ? D.baseX : W - D.baseX;
  if (D.laneY.length===1 || lane===1) return [[x0,y],[x1,y]];
  const bx0 = side ? x0 - D.laneBend : x0 + D.laneBend;
  const bx1 = side ? x1 + D.laneBend : x1 - D.laneBend;
  const list = [[x0, D.laneY[1]], [bx0, y], [bx1, y], [x1, D.laneY[1]]];
  return list;
}
function mobaCleaner(){
  enemies = []; poolClearView(bullets); grenades = []; smokes = []; loots = [];
}

/* ---------- 3. 兵 ---------- */
function mobaSpawnPoint(side, lane, slot){
  const D=mobaDef(), mid=Math.floor(D.laneY.length/2), x=side?D.w-D.baseX:D.baseX;
  return {x:x+(side?-1:1)*(3+(lane-mid)*2+slot)*D.spawnGap, y:D.laneY[mid]+D.spawnBelow};
}
function mobaAssignRoute(e,side,lane){
  e.mobaSide=side; e.mobaLane=lane;
  e.mobaRoute=mobaWaypoints(side,lane).slice(1);
  e.mobaRouteIndex=0;
  e.wp=e.mobaRoute;
  e.i=0; e.path=null; e.goal=null; e.chk=null;
  /* m21422：marchK 是全局乘在"所有移动状态"上的（见 34-status），
     这里要是给 0.52，追击/撤退/换位全部被拖慢 —— 这才是"怎么都不加速"的原因。
     推塔的行军慢，只由下面的 mobaSpd 负责。 */
  e.marchK=1;
  e.mobaCreep=true;   /* m21393：本模式的兵走"沿线推进"，不套通用 AI 的追击/加速 */
}
function mobaBackupFollower(caller,responder){
  const direction=caller.mobaSide ? -1 : 1;
  return responder.mobaSide===caller.mobaSide && responder.mobaLane===caller.mobaLane &&
    direction*(caller.x-responder.x)>0;
}
function mobaMarchPoint(e){
  const route=e.mobaRoute, dir=e.mobaSide ? -1 : 1;
  const previous=e.mobaRouteIndex;
  let next=previous;
  while(next<route.length){
    const [x,y]=route[next];
    if (dir*(e.x-x)<0 && dist(e.x,e.y,x,y)>=8) break;
    next++;
  }
  if(next!==previous){
    e.mobaRouteIndex=next;
    e.path=null; e.goal=null;
  }
  return route[next] || null;
}
function mobaMakeMinion(side, lane, slot=0){
  if (typeof cricketMake !== 'function') return null;
  const D = mobaDef();
  const p0 = mobaSpawnPoint(side,lane,slot);
  const e = cricketMake(D.minionKind, side, p0.x, p0.y);
  if (!e) return null;
  mobaAssignRoute(e,side,lane);
  e.mobaKind = 'minion';
  e.mobaSpd = D.minionSpd || 112;   /* m21343：自己的速度，不吃全局 */
  /* 小兵统一手枪（武器池里 grunt 默认可能抽到步枪） */
  e.wid = 'pistol';
  e.ammo = Math.max(1, ((typeof weaponCore === 'function' ? weaponCore('pistol').cap : 12) | 0));
  /* 这里不能再调 assignWeapon：它按 weaponPool 抽枪，会把上面的 pistol 覆盖成步枪 */
  enemies.push(e);
  return e;
}
function mobaMakeSquad(side, lane){
  if (typeof cricketMake !== 'function') return null;
  const D = mobaDef();
  const kind = D.squad[Math.floor(Math.random() * D.squad.length)];
  const p0 = mobaSpawnPoint(side,lane,0);
  const e = cricketMake(kind, side, p0.x, p0.y);
  if (!e) return null;
  mobaAssignRoute(e,side,lane);
  e.mobaKind = 'squad';
  e.mobaSpd = D.squadSpd || 148;    /* m21343：精英队比小兵快 */
  /* 小兵统一手枪（武器池里 grunt 默认可能抽到步枪） */
  e.wid = 'pistol';
  e.ammo = Math.max(1, ((typeof weaponCore === 'function' ? weaponCore('pistol').cap : 12) | 0));
  e.hp = e.maxHp = Math.round((e.maxHp || 100) * 1.6);
  if (typeof assignWeapon === 'function') assignWeapon(e);
  enemies.push(e);
  return e;
}

/* ---------- 4. 双方炮塔与三路机枪阵地 ---------- */
function mobaBuildStructures(){
  const D=mobaDef(), st=mobaLvl.moba;
  st.cores=[];st.forts=[];
  for(let side=0;side<2;side++){
    const fac=mobaFac(side), x=side?D.w-D.baseX:D.baseX;
    const core=spawnRocketTurret({x,y:D.laneY[Math.floor(D.laneY.length/2)]},fac);
    if(core){
      core.kind='core';core.side=side;core.hp=core.maxHp=D.coreHp;
      core.ang=side?Math.PI:0;
      st.cores.push(core);
    }
    for(let lane=0;lane<D.laneY.length;lane++){
      const wp=mobaWaypoints(side,lane), outer=D.laneY.length>1&&lane!==1;
      const fractions=outer ? D.outerFortAt : D.fortAt;
      for(let i=0;i<fractions.length;i++){
        const segment=outer ? i : 0, a=wp[segment], b=wp[segment+1], k=fractions[i];
        const x=a[0]+(b[0]-a[0])*k, y=a[1]+(b[1]-a[1])*k;
        const fort=spawnMgSentry({x,y},fac);
        if(fort){
          fort.mobaSide=side;fort.mobaLane=lane;
          fort.ang=fort.baseAng=Math.atan2(b[1]-a[1],b[0]-a[0]);
          st.forts.push(fort);
        }
      }
    }
  }
}
function mobaCenterX(s){return s.x+s.w/2;}
function mobaCenterY(s){return s.y+s.h/2;}

function mobaStructDown(s){
  const st = mobaLvl.moba;
  if (typeof spawnPart === 'function'){
    for (let i = 0; i < 10; i++) spawnPart(s.x + (Math.random() - 0.5) * 50, s.y + (Math.random() - 0.5) * 50, Math.random() * 6.28, 120, 0.4, 'spark', 4);
  }
  if (typeof dzABoom === 'function') dzABoom(0.5, 1.1);
  mobaSay(s.kind === 'core' ? '炮塔被摧毁了' : '机枪棱堡被拆了', 2.2);
  if (s.kind === 'core'){
    st.over = 1; st.winner = mobaEnemySide(s.side);
  }
}

function mobaCoverDestroyed(w,debris){
  w.mobaRestoreAt=cur().moba.t+mobaDef().coverRestore;
  w.mobaDebris=debris;
}
function mobaCoverOccupied(w,units){
  return units.some(e=>{
    if (!e || e.dead || !(e.hp>0)) return false;
    const x=clamp(e.x,w.x,w.x+w.w), y=clamp(e.y,w.y,w.y+w.h);
    return dist(e.x,e.y,x,y)<(e.r || 12)+4;
  });
}
function mobaCoverTick(L){
  const st=L.moba;
  let changed=false;
  for (const w of st.covers){
    if (!w.dead || !(st.t>=w.mobaRestoreAt)) continue;
    if (mobaCoverOccupied(w,enemies) || mobaCoverOccupied(w,allies)){
      w.mobaRestoreAt=st.t+mobaDef(L).coverRetry;
      continue;
    }
    const debris=decals.indexOf(w.mobaDebris);
    if (debris>=0) decals.splice(debris,1);
    w.mobaDebris=null;
    w.mobaRestoreAt=0;
    w.hp=w.maxHp;
    w.hits=w.hitT=w.sndT=0;
    w.dead=false;
    L.walls.push(w);
    wallGeomVer++;
    navPatchRect(L,w.x,w.y,w.w,w.h);
    changed=true;
  }
  if (changed) staticInvalidate();
}

/* ---------- 5. 每帧 ---------- */
var _mobaMsgUntil = 0;
function mobaSay(text, dur){
  if (!mobaLvl) return;
  mobaLvl.moba.msg = text;
  mobaLvl.moba.msgT = dur || 2.2;
}
function mobaEnter(){
  mobaLvl.moba.pick = -1;
  mobaLvl.moba.cards = mobaDef().cardN;
}
function mobaSpawn(L){
  if (typeof uiHideSet === 'function') uiHideSet(true);   /* 观战图：常规 HUD 全藏，只留军团推塔自己的界面 */
  if (!mobaOn(L)) return;
  mobaLvl.moba = mobaLvl.moba || mobaNewState();
  mobaLvl.moba.covers=L.walls.filter(w=>w.brk);
  for (const w of L.walls) if (w.brk || w.cov==='wreckcar') w.mobaCover=true;
  mobaBuildStructures();
  mobaEnter();
  if (player){
    player.x = L.w / 2; player.y = L.h / 2;
    player.god = true; player.grace = Math.max(player.grace || 0, 3);
    player.thermal = false; player.hp = player.hpMax || player.hp;
  }
}

function mobaTick(dt, L){
  if (!mobaOn(L)) return;
  const st = L.moba, D = mobaDef();
  if (!st || !st.cores || !st.cores.length) return;
  if (st.over){
    if (typeof keys !== 'undefined' && (keys['Escape'] || keys['Enter'] || keys['Space'])) { exitMoba(); }
    return;
  }
  st.t += dt;
  if (st.msgT > 0) st.msgT -= dt;
  if(player){
    player.god=true;player.grace=Math.max(player.grace||0,3);
    player.thermal=false;player.cricketSpdK=D.camSpd;
  }
  /* 缩放：- / = 与滚轮（滚轮在 mobaWheel） */
  if (typeof keys !== 'undefined'){
    if (keys['Minus'] || keys['NumpadSubtract']) st.zoom = Math.max(D.zoomMin, st.zoom * 0.985);
    if (keys['Equal'] || keys['NumpadAdd']) st.zoom = Math.min(D.zoomMax, st.zoom * 1.015);
    if (keys['Escape']) st.pick = -1;
  }
  /* 兵线 */
  st.waveT -= dt;
  if (st.waveT <= 0){
    st.waveT = D.waveT;
    st.wave++;
    const per = Math.round(D.waveN / D.laneY.length);
    for (let side = 0; side < 2; side++){
      for (let lane = 0; lane < D.laneY.length; lane++){
        for (let i = 0; i < per; i++) mobaMakeMinion(side, lane, i);
      }
    }
    mobaSay('第 ' + st.wave + ' 波兵出门（每边 ' + D.waveN + ' 个）', 2.0);
  }
  /* 卡牌：玩家部队库 */
  st.cardT -= dt;
  if (st.cardT <= 0 && st.cards < st.maxCards){
    st.cardT = D.cardT;
    st.cards = Math.min(st.maxCards, st.cards + D.cardN);
    mobaSay('部队库 +' + D.cardN + '（' + st.cards + '/' + st.maxCards + '）', 1.8);
  }
  /* 结构：开火 + 攻城结算 */
  const destroyed=st.cores.find(s=>s.hp<=0);
  if(destroyed){mobaStructDown(destroyed);return;}
  mobaCoverTick(L);
  for (const fort of st.forts){
    if (fort.hp > 0 || fort.mobaDownReported) continue;
    fort.mobaDownReported = true;
    mobaStructDown(fort);
  }
}

/* ---------- 6. 投兵：点上/中/下 ---------- */
function mobaDeploy(lane){
  const st = mobaLvl && mobaLvl.moba;
  const lanes=mobaDef().laneY.length;
  if (!st || st.over || !Number.isInteger(lane) || lane<0 || lane>=lanes) return false;
  if (st.cards <= 0) { mobaSay('部队库空了，等一下', 1.6); return false; }
  st.cards--;
  mobaMakeSquad(0, lane);
  mobaSay(lanes===1 ? '已派出精英部队' : '派兵走' + ['上', '中', '下'][lane] + '路', 1.6);
  return true;
}
function mobaBarRect(){
  const bw = 150, bh = 46, gap = 12;
  const lanes=mobaDef().laneY.length;
  const total = bw * lanes + gap * (lanes-1);
  const x0 = W / 2 - total / 2, y = H - 78;
  return { x: x0, y: y, w: total, h: bh, bw: bw, gap: gap };
}
function mobaLaneAt(mx, my){
  const r = mobaBarRect();
  if (my < r.y - 6 || my > r.y + r.h + 6) return -1;
  for (let i = 0; i < mobaDef().laneY.length; i++){
    const x = r.x + i * (r.bw + r.gap);
    if (mx >= x - 4 && mx <= x + r.bw + 4) return i;
  }
  return -1;
}
function mobaMouseDown(mx, my, button){
  if (!mobaOn()) return false;
  if (typeof confirmBack !== 'undefined' && confirmBack) return false;
  const lane = mobaLaneAt(mx, my);
  if (lane >= 0){
    if (button === 2){ mobaLvl.moba.pick = -1; return true; }
    mobaDeploy(lane);
    return true;
  }
  return false;
}
function mobaWheel(deltaY){
  if (!mobaOn()) return false;
  const st = mobaLvl.moba, D = mobaDef();
  st.zoom = Math.max(D.zoomMin, Math.min(D.zoomMax, st.zoom * Math.exp(-deltaY * 0.0016)));
  return true;
}

/* ---------- 7. 画地面/结构/HUD ---------- */
function drawMobaField(L){
  if(!mobaOn(L))return;
  ctx.save();
  ctx.lineJoin='round';ctx.lineCap='round';
  for(let lane=0;lane<mobaDef(L).laneY.length;lane++){
    const wp=mobaWaypoints(0,lane);
    ctx.beginPath();
    wp.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));
    ctx.strokeStyle='rgba(120,150,190,0.10)';ctx.lineWidth=140;ctx.stroke();
    ctx.strokeStyle='rgba(150,180,220,0.16)';ctx.lineWidth=3;ctx.stroke();
  }
  ctx.restore();
}

/* 临时调试：把相机/缩放/结构的屏幕坐标打出来（用户看不到就查这个） */
function mobaDebugDump(){
  if (!mobaLvl || !mobaLvl.moba) return 'no moba';
  const st = mobaLvl.moba, z = st.zoom || 1;
  const sx=crkSX, sy=crkSY;
  const o = {
    W: W, H: H, cam: { x: Math.round(cam.x), y: Math.round(cam.y) }, zoom: z,
    player: { x: Math.round(player.x), y: Math.round(player.y) },
    lanes: mobaDef().laneY.map(y => ({ y: y, sy: Math.round(sy(y)) })),
    cores: st.cores.map(s2 => ({ side: s2.side, x: mobaCenterX(s2), y: mobaCenterY(s2), hp: s2.hp,
      sx: Math.round(sx(mobaCenterX(s2))), sy: Math.round(sy(mobaCenterY(s2))), r: s2.w/2 })),
    forts: st.forts.map(s2 => ({ side: s2.mobaSide, lane: s2.mobaLane, x: Math.round(s2.x + s2.w / 2), y: Math.round(s2.y + s2.h / 2),
      hp: Math.round(s2.hp), sx: Math.round(sx(s2.x + s2.w / 2)), sy: Math.round(sy(s2.y + s2.h / 2)) })),
    units: enemies.length
  };
  const str = JSON.stringify(o);
  try { if (typeof console !== 'undefined') console.log('[MOBA] ' + str); } catch (e) {}
  return str;
}

function drawMobaHud(){
  if (!mobaOn()) return;
  const st=mobaLvl.moba, D=mobaDef();
  if(st.cores.length!==2)return;
  const barW = 330, barY = 18;
  for (let side = 0; side < 2; side++){
    const c = st.cores[side];
    const x = side ? W - barW - 24 : 24;
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(x, barY, barW, 20);
    ctx.fillStyle = side ? '#7fd7ff' : '#ff9c6a';
    ctx.fillRect(x, barY, barW * Math.max(0, c.hp / c.maxHp), 20);
    ctx.fillStyle = 'rgba(240,244,250,0.92)';
    ctx.font = 'bold 13px system-ui,sans-serif'; ctx.textAlign = side ? 'right' : 'left';
    ctx.fillText((side ? '蓝方' : '红方') + ' 炮塔 ' + Math.max(0, Math.round(c.hp)) + ' / ' + c.maxHp,
                 side ? x + barW - 6 : x + 6, barY + 15);
    ctx.textAlign = 'left';
  }
  /* 小地图：大地图下必须有个总览，否则只能看到镜头里那点东西 */
  const mmW = 190, mmH = Math.round(mmW * D.h / D.w);
  const mmX = W - mmW - 18, mmY = 52;
  const mx = wx => mmX + wx / D.w * mmW;
  const my = wy => mmY + wy / D.h * mmH;
  ctx.fillStyle = 'rgba(6,10,16,0.82)';
  ctx.fillRect(mmX, mmY, mmW, mmH);
  ctx.strokeStyle = 'rgba(150,185,225,0.35)'; ctx.lineWidth = 1;
  ctx.strokeRect(mmX + 0.5, mmY + 0.5, mmW - 1, mmH - 1);
  /* 三路 */
  ctx.strokeStyle = 'rgba(120,150,185,0.45)';
  for (let lane = 0; lane < D.laneY.length; lane++){
    const wp = mobaWaypoints(0, lane);
    ctx.beginPath();
    for (let i = 0; i < wp.length; i++){
      const px = mx(wp[i][0]), py = my(wp[i][1]);
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.stroke();
  }
  /* 三路阵地与双方炮塔 */
  for (const f of st.forts){
    if(f.dead || f.hp<=0)continue;
    ctx.fillStyle = f.mobaSide ? 'rgba(127,215,255,0.85)' : 'rgba(255,156,106,0.85)';
    ctx.fillRect(mx(f.x + f.w / 2) - 1.5, my(f.y + f.h / 2) - 1.5, 3, 3);
  }
  for (const c of st.cores){
    ctx.fillStyle = c.side ? '#7fd7ff' : '#ff9c6a';
    ctx.fillRect(mx(mobaCenterX(c)) - 3, my(mobaCenterY(c)) - 3, 6, 6);
  }
  /* 单位 */
  for (const e of enemies){
    if (e.dead || e.mobaSide === undefined) continue;
    ctx.fillStyle = e.mobaSide ? 'rgba(127,215,255,0.9)' : 'rgba(255,156,106,0.9)';
    ctx.fillRect(mx(e.x) - 0.8, my(e.y) - 0.8, 1.6, 1.6);
  }
  /* 镜头框 */
  const vw = (W / (st.zoom || 1)) / D.w * mmW;
  const vh = (H / (st.zoom || 1)) / D.h * mmH;
  const viewX=mx(cam.x+W/2), viewY=my(cam.y+H/2);
  const viewLeft=Math.max(mmX,viewX-vw/2), viewRight=Math.min(mmX+mmW,viewX+vw/2);
  const viewTop=Math.max(mmY,viewY-vh/2), viewBottom=Math.min(mmY+mmH,viewY+vh/2);
  ctx.strokeStyle = 'rgba(240,244,250,0.55)';
  if (viewRight>viewLeft&&viewBottom>viewTop) ctx.strokeRect(viewLeft,viewTop,viewRight-viewLeft,viewBottom-viewTop);
  /* 底部：三条路 + 部队库 */
  const r = mobaBarRect();
  ctx.font = 'bold 17px system-ui,sans-serif'; ctx.textAlign = 'center';
  for (let i = 0; i < mobaDef().laneY.length; i++){
    const x = r.x + i * (r.bw + r.gap);
    const can = st.cards > 0;
    ctx.fillStyle = can ? 'rgba(28,42,58,0.92)' : 'rgba(24,28,34,0.85)';
    ctx.fillRect(x, r.y, r.bw, r.h);
    ctx.strokeStyle = can ? 'rgba(150,210,255,0.75)' : 'rgba(120,140,160,0.35)';
    ctx.lineWidth = 1.4; ctx.strokeRect(x + 0.5, r.y + 0.5, r.bw - 1, r.h - 1);
    ctx.fillStyle = can ? 'rgba(226,240,255,0.96)' : 'rgba(150,160,172,0.65)';
    ctx.fillText(D.laneY.length===1 ? '投兵' : ['上路', '中路', '下路'][i], x + r.bw / 2, r.y + 30);
  }
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(200,220,240,0.9)';
  ctx.font = 'bold 14px system-ui,sans-serif';
  const summaryX=D.laneY.length===1 ? W/2-220 : r.x;
  ctx.fillText('部队库 ' + st.cards + ' 个' + (D.laneY.length>1 ? ' · 点一路投兵' : ''), summaryX, r.y - 12);
  ctx.fillStyle = 'rgba(170,190,210,0.75)';
  ctx.font = '12px system-ui,sans-serif';
  ctx.fillText('第 ' + st.wave + ' 波 · 下一波 ' + Math.max(0, Math.ceil(st.waveT)) + 's · 滚轮缩放 · Esc 暂停',
               summaryX + 190, r.y - 12);
  /* 提示条 */
  if (st.msgT > 0 && st.msg){
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    const tw = ctx.measureText(st.msg).width + 26;
    ctx.fillRect(W / 2 - tw / 2, 54, tw, 26);
    ctx.fillStyle = 'rgba(240,246,255,0.95)';
    ctx.font = 'bold 15px system-ui,sans-serif';
    ctx.fillText(st.msg, W / 2, 72);
    ctx.textAlign = 'left';
  }
  if (st.over){
    ctx.fillStyle = 'rgba(4,6,10,0.62)'; ctx.fillRect(0, 0, W, H);
    ctx.textAlign = 'center';
    ctx.fillStyle = st.winner === 0 ? '#ff9c6a' : '#7fd7ff';
    ctx.font = 'bold 44px system-ui,sans-serif';
    ctx.fillText(st.winner === 0 ? '红方胜利' : '蓝方胜利', W / 2, H / 2 - 10);
    ctx.fillStyle = 'rgba(230,238,248,0.9)';
    ctx.font = '16px system-ui,sans-serif';
    ctx.fillText('按 Esc / Enter 回大厅', W / 2, H / 2 + 34);
    ctx.textAlign = 'left';
  }
}

/* ---------- 8. 进出 ---------- */
function startMoba(D=MOBA_DEF){
  /* 纯 AI 对打：双方固定按噩梦档的人机参数跑（视野/枪法/记性），走的时候还给玩家 */
  if (!mobaSavedCfg){ mobaSavedCfg = Object.assign({}, CFG); mobaSavedDiff = (typeof diffName === 'string' ? diffName : 'normal'); }
  if (typeof applyPreset === 'function') applyPreset('nightmare');   /* 双方人机默认噩梦 */
  if (typeof arenaSlotUI !== 'undefined') arenaSlotUI = null;
  customLvl = null;
  mobaLvl = buildMobaLevel(D);
  mobaLvl.moba = mobaNewState();
  arenaLvl = null; ar = null; arOrbs = [];
  mobaCleaner();
  state = 'play';
  ui.inv.open = false; invGeom = null; invGridGeom = null; ui.inv.drag = null;
  reset();
  player.aim = 0; player.grace = 999;
  player.loot = 0; player.gun = null;
  mobaSpawn(cur());
  updateCam();
  mobaSay(D.laneY.length===1 ? '军团推塔 · 单路出兵' : '军团推塔 · 三路出兵，打爆对面炮塔', 4.0);
  if (typeof logInfo === 'function') logInfo('moba', '进入军团推塔');
}
function exitMoba(){
  mobaLvl = null;
  goMenu();
}
function mobaLeave(){
  if (typeof uiHideSet === 'function') uiHideSet(false);
  if (mobaSavedCfg){
    Object.assign(CFG, mobaSavedCfg);
    if (typeof diffName !== 'undefined') diffName = mobaSavedDiff || 'normal';
    mobaSavedCfg = null; mobaSavedDiff = '';
    try {
      if (typeof buildRows === 'function') buildRows();
      if (typeof tagEl !== 'undefined' && tagEl && typeof DIFF_LABEL !== 'undefined') tagEl.textContent = DIFF_LABEL[diffName] || '自定义';
      if (typeof saveCfg === 'function') saveCfg();
    } catch(e){}
  }
  mobaLvl = null;
}
