/* 背包与皮卡货斗共用的物资手势。鼠标按住扫货与点取到光标是两种独立状态。 */
function inventoryInputActive(){
  return state === 'play' && player?.hp > 0 && ui.inv.open && !!invGridGeom &&
    !ui.inv.companion && !paused && uiTopLayer() === 'inv';
}

function inventoryCargoTruck(){
  const t = cargoOpenTruck;
  if (!player || !cargoCanUse(t)) return null;
  return playerTruck === t || dist(player.x, player.y, t.x, t.y) < CARGO_ACCESS_RANGE ? t : null;
}
function inventoryUnits(it){ return Math.max(1, Math.trunc(it.n) || 1); }
function inventoryStackLimit(it){
  if (it.k === 'ammo') return ammoCellCap(it.t || 'pistol');
  if (it.k === 'heatcell') return HEATCELL_STACK;
  if (it.k === 'rope') return Infinity;
  return 1;
}
function inventorySameStack(a, b){
  return a.k === b.k && inventoryStackLimit(a) > 1 &&
    (a.q || 0) === (b.q || 0) &&
    (a.k !== 'ammo' || (a.t || 'pistol') === (b.t || 'pistol'));
}
function inventoryStoreItems(truck){ return truck ? truckCargoOf(truck) : bagItems(); }

function inventorySlotAt(mx, my){
  const G = invGridGeom;
  const step = G.cell + G.gap;
  const x = Math.floor((mx - G.gx) / step), y = Math.floor((my - G.gy) / step);
  if (bagCellOk(x, y)) return { truck:null, x, y };
  const truck = inventoryCargoTruck(), C = G.cargo;
  if (!truck || !C || mx < C.x || my < C.y || mx > C.x + C.w || my > C.y + C.h) return null;
  const span = C.cell + C.gap;
  return { truck, x:Math.floor((mx - C.x) / span), y:Math.floor((my - C.y) / span) };
}
function inventoryItemIn(slot){
  return slot && inventoryStoreItems(slot.truck).find(it =>
    slot.x >= it.x && slot.x < it.x + it.w && slot.y >= it.y && slot.y < it.y + it.h);
}
function inventorySetUnits(it, count){
  if (it.n !== undefined || count !== 1) it.n = count;
}
function inventoryTakeToCursor(slot, it, half){
  if (!it || (slot.truck && !cargoCanUse(slot.truck))) return;
  const items = inventoryStoreItems(slot.truck), at = items.indexOf(it);
  if (at < 0) return;
  const inv = ui.inv;
  let carry = inv.carry;
  const part = carry?.parts.find(p => p.item === it);
  if (carry && !part && !inventorySameStack(carry.item, it)){
    setMsg('先放下手上的物资', 1.3); return;
  }
  const units = inventoryUnits(it), limit = Math.max(inventoryStackLimit(it), units);
  const count = Math.min(half ? Math.ceil(units / 2) : 1, carry ? carry.limit - carry.count : limit);
  if (count < 1){ setMsg('手上这堆已满', 1.3); return; }
  if (!carry) carry = inv.carry = { owner:player, item:{...it}, count:0, limit, parts:[] };
  if (count === units) items.splice(at, 1);
  else inventorySetUnits(it, units - count);
  if (part) part.count += count;
  else carry.parts.push({ truck:slot.truck, item:it, count, limit });
  carry.count += count;
  inventorySetUnits(carry.item, carry.count);
  if (!slot.truck) bagRebuild();
}

function inventoryClippedStack(it, count){
  const cell = {...it};
  inventorySetUnits(cell, count);
  return cell;
}
/* 点选摆放只占光标选中的起始格，校验整个物品的形状（可以旋转，不能越界或挤走别的物品）。 */
function inventoryPlaceIn(slot, it, rotate = true){
  const {truck, x, y} = slot;
  const occ = truck ? cargoOccupancy(truck) : bagOcc(null);
  const fits = truck ? cargoFreeAt : bagFreeAt;
  let w = it.w || 1, h = it.h || 1, rot = it.rot || 0;
  if (!fits(occ, w, h, x, y)){
    if (!rotate || w === h || !fits(occ, h, w, x, y)) return false;
    [w, h] = [h, w];
    rot = rot ? 0 : 1;
  }
  const placed = {...it, x, y, w, h, rot};
  if (truck) cargoInsert(truck, placed, x, y);
  else bagItems().push({...placed, uid:_bagUid++});
  return true;
}
function inventorySpendCursor(count){
  const carry = ui.inv.carry;
  carry.count -= count;
  while (count > 0){
    const part = carry.parts[0], n = Math.min(count, part.count);
    if (!part.truck && part.item.k === 'ammo') part.item.manualStack = true;
    part.count -= n; count -= n;
    if (!part.count) carry.parts.shift();
  }
  if (carry.count) inventorySetUnits(carry.item, carry.count);
  else ui.inv.carry = null;
  bagRebuild();
}
function inventoryRotateCursor(){
  const it = ui.inv.carry.item;
  if (it.w === it.h) return;
  [it.w, it.h] = [it.h, it.w];
  it.rot = it.rot ? 0 : 1;
  it.rotManual = 1;
}
function inventoryPlaceCursor(slot){
  if (!slot){ setMsg('把物资放在背包或货斗的格子里', 1.3); return; }
  const carry = ui.inv.carry, target = inventoryItemIn(slot);
  if (target){
    if (!inventorySameStack(carry.item, target)){ setMsg('这格已有物资', 1.3); return; }
    const have = inventoryUnits(target), count = Math.min(carry.count, inventoryStackLimit(target) - have);
    if (count < 1){ setMsg('这堆物资已满', 1.3); return; }
    inventorySetUnits(target, have + count);
    if (target.k === 'ammo') target.manualStack = true;
    inventorySpendCursor(count);
    return;
  }
  const placed = {...carry.item};
  if (placed.k === 'ammo') placed.manualStack = true;
  if (inventoryPlaceIn(slot, placed)) inventorySpendCursor(carry.count);
  else setMsg('格子放不下这件物资', 1.3);
}

/* 关背包时按来源退回。原格被填满或车辆被毁时，剩下的物资回背包，塞不下才落地。 */
function inventoryReturnCursor(){
  const carry = ui.inv.carry;
  ui.inv.carry = null;
  if (!carry || carry.owner !== player) return;
  for (const part of carry.parts){
    let left = part.count;
    const {truck, item} = part;
    if (!truck || cargoCanUse(truck)){
      const items = inventoryStoreItems(truck);
      if (items.includes(item)){
        const have = inventoryUnits(item), restored = Math.min(left, Math.max(0, part.limit - have));
        inventorySetUnits(item, have + restored);
        left -= restored;
      } else if (inventoryPlaceIn({truck, x:item.x, y:item.y}, inventoryClippedStack(item,left), false)) continue;
      if (truck && left > 0){
        const spot = cargoFree(truck, item.w, item.h);
        if (spot){ cargoInsert(truck, inventoryClippedStack(item,left), spot.x, spot.y); continue; }
      }
    }
    if (!left) continue;
    const {x, y, ...extra} = inventoryClippedStack(item, left);
    if (bagAddCell(item.k, extra)) continue;
    if (item.k === 'ammo' || item.k === 'heatcell') bagLootFromItem(extra);
    else for (let i = 0; i < left; i++) bagLootFromItem(inventoryClippedStack(extra, 1));
  }
  bagRebuild();
}
function inventoryStopGestures(){
  ui.inv.sweep = null;
  if (ui.inv.tripTap) tripDisarmCancel();
  ui.inv.tripTap = null;
  bindDeferredKeys.clear();
}
function inventoryClose(){
  inventoryStopGestures();
  inventoryReturnCursor();
  ui.inv.open = false; ui.inv.drag = null; ui.inv.gunDrag = null; ui.inv.companion = null;
  invHover = -1; invGridGeom = null;
  cargoPanelDetach();
}
function inventoryInputSync(){
  if ((ui.inv.carry || ui.inv.sweep || ui.inv.tripTap) &&
      (!ui.inv.open || state !== 'play' || !(player?.hp > 0))) inventoryClose();
}

function inventorySweepTo(x, y){
  const sweep = ui.inv.sweep, G = invGridGeom;
  const grid = sweep.fromCargo ? G.cargo : G;
  if (!grid) return;
  const gx = sweep.fromCargo ? grid.x : grid.gx, gy = sweep.fromCargo ? grid.y : grid.gy;
  const step = grid.cell + grid.gap, crossed = [];
  for (const it of inventoryStoreItems(sweep.fromCargo ? sweep.truck : null)){
    if (sweep.seen.has(it)) continue;
    const t = segRectEntryT(sweep.x, sweep.y, x, y, {
      x:gx + it.x * step, y:gy + it.y * step,
      w:it.w * step - grid.gap, h:it.h * step - grid.gap
    });
    if (t !== null) crossed.push({it, t});
  }
  sweep.x = x; sweep.y = y;
  crossed.sort((a, b) => a.t - b.t);
  for (const {it} of crossed){
    sweep.seen.add(it);
    if (sweep.fromCargo) cargoBagTakeOut({c:it});
    else cargoBagPut(it);
  }
}
function inventoryInputMove(ev){
  const sweep = ui.inv.sweep;
  if (!sweep) return;
  if (!inventoryInputActive() || inventoryCargoTruck() !== sweep.truck ||
      !bindModifierHeld(sweep.modifier, ev) ||
      (sweep.mouseMask && typeof ev.buttons === 'number' && !(ev.buttons & sweep.mouseMask))){
    ui.inv.sweep = null;
    return;
  }
  const p = toScreen(ev);
  inventorySweepTo(p.x, p.y);
}

function inventoryPress(row, code, ev){
  const action = row.bindAction, inv = ui.inv;
  if (ev.repeat || inv.sweep) return true;
  if (action === 'cargoQuickMove'){
    if (inv.carry || inv.drag || inv.gunDrag){ setMsg('先放下手上的物资', 1.3); return true; }
    const mouseButtons = {mouse0:1, mouse1:4, mouse2:2, mouse3:8, mouse4:16};
    inv.sweep = {
      truck:inventoryCargoTruck(), fromCargo:!!inventorySlotAt(mouse.x, mouse.y)?.truck,
      trigger:code, modifier:BINDS[action][0],
      mouseMask:mouseButtons[code] || 0, x:mouse.x, y:mouse.y, seen:new Set()
    };
    inventorySweepTo(mouse.x, mouse.y);
    return true;
  }
  if (action === 'inventoryPlace' && !inv.carry) return Array.isArray(BINDS[action]);
  if (inv.drag || inv.gunDrag) return true;
  const slot = inventorySlotAt(mouse.x, mouse.y);
  if (action === 'inventoryPlace'){
    const carry = inv.carry;
    const equipped = carry.count === 1 ? bagEquipAtPointer(carry.item, () => {
      inventorySpendCursor(1);
      return true;
    }) : null;
    if (equipped === null) inventoryPlaceCursor(slot);
  }
  else {
    const item = inventoryItemIn(slot), half = action === 'inventoryTakeHalf';
    if (!half && code === 'mouse2' && item?.k === 'tripwire' && !slot.truck && !inv.carry){
      tripDisarmStart(item);
      inv.tripTap = { slot, item, attempt:tripDisarm };
    } else inventoryTakeToCursor(slot, item, half);
  }
  return true;
}
function inventoryInputRelease(code, ev){
  const inv = ui.inv, sweep = inv.sweep;
  if (sweep && (sweep.trigger === code || !bindModifierHeld(sweep.modifier, ev))) inv.sweep = null;
  if (code !== 'mouse2' || !inv.tripTap) return;
  const tap = inv.tripTap;
  inv.tripTap = null;
  const wasTap = tap.attempt === tripDisarm;
  tripDisarmCancel();
  if (wasTap && inventoryInputActive() && inventoryItemIn(inventorySlotAt(mouse.x, mouse.y)) === tap.item){
    inventoryTakeToCursor(tap.slot, tap.item, false);
  }
}

