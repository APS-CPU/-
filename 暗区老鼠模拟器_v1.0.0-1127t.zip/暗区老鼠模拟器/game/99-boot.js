/* 拆文件之后必须"最后再跑"的顶层语句：它们调用的东西在后面的文件里定义。
   原文件是一个 script，函数声明整篇提升所以顺序无所谓；拆开之后就得等所有人都到齐。 */
/* m23103：把上次存的渲染分辨率套上（画布后备缓冲要跟着改尺寸，否则会和 CSS 尺寸错位） */
if (typeof renderScaleSet === 'function' && renderScale() !== 1) renderScaleSet(renderScale());
if (typeof displayModeApply === 'function') displayModeApply();
if (typeof crashCount === 'function'){
  try{
    const _cn = crashCount();
    if (_cn > 0 && typeof setMsg === 'function'){
      setMsg('上次运行留下 ' + _cn + ' 条异常 · 按 L 打开日志（可复制/下载）', 6);
    }
  }catch(e){}
}
CHAPTERS = buildChapters();
cv.addEventListener('mousemove', ev=>{ const p = toScreen(ev); mouse.x=p.x; mouse.y=p.y; hoverBtn = uiHit(p.x, p.y); });
