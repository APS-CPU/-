/* 补音效：这些动作以前是「哑的」或者声音太小 —— 火箭筒、开箱、搜刮、
   背包开合、换弹。全部用 WebAudio 现场合成，不占素材体积。
   每个函数都自己判空（actx 还没起来就安静返回），所以随便挂在哪儿都安全。 */
var _xsGateT = {};
function _xsGate(key, gap){
  /* 搜刮声按帧询问，间隔定义的是动作节奏。 */
  if (!audioRateLimit && key !== 'rustle') return true;
  const t = (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000;
  if (_xsGateT[key] !== undefined && t - _xsGateT[key] < gap){
    if (key !== 'rustle') audioDiagBlock('动作音去重', key, undefined, 1, 'dedupe');
    return false;
  }
  _xsGateT[key] = t;
  return true;
}
function _xsDist(px, py){
  if (typeof player === 'undefined' || px === undefined) return 1;
  const d = Math.hypot(px - player.x, py - player.y);
  return Math.max(0.25, 1 - d / 2400);
}
/* 一段噪声：穿过 follow-type 滤波器，从 f0 滑到 f1，包络先快起后慢落 */
function _xsNoise(vol, f0, f1, dur, type, q, px, py){
  if (typeof actx === 'undefined' || !actx || typeof ensureNoise !== 'function') return;
  try {
    ensureNoise();
    if (!noiseBuf) return;
    const src = actx.createBufferSource();
    src.buffer = noiseBuf;
    src.loop = true;
    const flt = actx.createBiquadFilter();
    flt.type = type || 'bandpass';
    flt.frequency.setValueAtTime(f0, actx.currentTime);
    flt.frequency.exponentialRampToValueAtTime(Math.max(40, f1), actx.currentTime + dur);
    flt.Q.value = q === undefined ? 1.1 : q;
    const g = actx.createGain();
    g.gain.setValueAtTime(0.0001, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), actx.currentTime + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + dur);
    src.connect(flt); flt.connect(g);
    let out = g;
    if (typeof px === 'number') out = _xsPan(g, px, py);
    else g.connect(duckBus());
    src.onended = () => { src.disconnect(); flt.disconnect(); g.disconnect(); if (out !== g) out.disconnect(); };
    src.start(); src.stop(actx.currentTime + dur + 0.02);
  } catch (e) {}
}
/* 立体声定位：声音从哪边来就往哪边偏。返回串联节点（没有 panner 就返回原节点） */
function _xsPan(node, px, py){
  if (typeof px !== 'number' || typeof actx === 'undefined' || !actx) return node;
  try {
    if (!actx.createStereoPanner){ node.connect(duckBus()); return node; }
    const sx = px - (typeof cam !== 'undefined' ? cam.x : 0);
    const pan = Math.max(-0.85, Math.min(0.85, (sx - W / 2) / (W * 0.5) * 0.9));
    const p = actx.createStereoPanner();
    p.pan.value = pan;
    node.connect(p);
    p.connect(duckBus());
    return p;
  } catch (e) { node.connect(duckBus()); return node; }
}

/* 一个音高：sine/sawtooth 从 f0 滑到 f1 */
function _xsTone(vol, f0, f1, dur, type){
  if (typeof actx === 'undefined' || !actx) return;
  try {
    const o = actx.createOscillator();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f0, actx.currentTime);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), actx.currentTime + dur);
    const g = actx.createGain();
    g.gain.setValueAtTime(0.0001, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), actx.currentTime + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + dur);
    o.connect(g); g.connect(duckBus());
    o.onended = () => { o.disconnect(); g.disconnect(); };
    o.start(); o.stop(actx.currentTime + dur + 0.02);
  } catch (e) {}
}

/* ---- 火箭筒 ---------------------------------------------------------- */
/* 发射：点火"呼"的一下 + 低频推力。比普通枪声更闷更厚 */
/* ---- 火箭筒真实素材（用户提供的 火箭筒爆炸.wav 切两段）------------------ */
var rsFireBuf = null, rsBoomBuf = null, rsDecoding = false;
function rocketSfxDecode(){
  if (rsDecoding || typeof actx === 'undefined' || !actx) return;
  rsDecoding = true;
  try {
    rocketFlightWarm();
    if (window.ROCKET_FIRE_SRC && typeof b64ToBuf === 'function'){
      b64ToBuf(window.ROCKET_FIRE_SRC, function(buf){ rsFireBuf = buf; }, function(){ rsFireBuf = null; });
    }
    if (window.ROCKET_BOOM_SRC && typeof b64ToBuf === 'function'){
      b64ToBuf(window.ROCKET_BOOM_SRC, function(buf){ rsBoomBuf = buf; }, function(){ rsBoomBuf = null; });
    }
  } catch (e) { rsDecoding = false; }
}
/* 放一段采样：vol 已经算好距离衰减，rate 给一点随机避免复读机 */
function _rsPlay(buf, vol, rate, dur, px, py, voice){
  if (typeof actx === 'undefined' || !actx) return false;
  /* 第一次用到就顺手解码，省得首帧还要等 audioInit 的定时器 */
  if (!buf){ try { rocketSfxDecode(); } catch (e) {} return false; }
  try {
    const src = actx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = rate || 1;
    const g = actx.createGain();
    const t0 = actx.currentTime;
    const end = Math.min(buf.duration / (rate || 1), dur || 99);
    g.gain.setValueAtTime(Math.max(0.0001, vol), t0);
    g.gain.setValueAtTime(Math.max(0.0001, vol), t0 + end * 0.82);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + end);
    src.connect(g);
    let pan = g;
    if (typeof px === 'number') pan = _xsPan(g, px, py);
    else g.connect(duckBus());
    src.onended = () => { src.disconnect(); g.disconnect(); if (pan !== g) pan.disconnect(); };
    src.start(t0); src.stop(t0 + end + 0.02);
    if (voice){
      voice.end = t0 + end + 0.02;
      voice.fade = () => {
        const now = actx.currentTime;
        const fadeEnd = Math.min(voice.end - 0.02, now + 0.24);
        if (fadeEnd <= now + 0.04) return voice.end;
        if (g.gain.cancelAndHoldAtTime) g.gain.cancelAndHoldAtTime(now);
        else {
          const current = g.gain.value;
          g.gain.cancelScheduledValues(now);
          g.gain.setValueAtTime(current, now);
        }
        g.gain.linearRampToValueAtTime(0.0001, fadeEnd);
        src.stop(fadeEnd + 0.02);
        return fadeEnd + 0.02;
      };
    }
    return true;
  } catch (e) { return false; }
}

/* 按左、中、右分别留代表声。短窗口内先比较距离，再决定本批播放哪些。 */
var rocketLanes = {
  fire:{ gap:0.025, cap:8, range:2200, bins:[null,null,null], voices:[], fading:[], at:0 },
  boom:{ gap:0.025, cap:10, range:2800, bins:[null,null,null], voices:[], fading:[], at:0 }
};
var rocketFlight = null;
function rocketAudioReset(){
  if (rocketFlight){
    for (const layer of rocketFlight.layers) if (layer) rocketFlightRelease(layer);
    rocketFlight = null;
  }
  if (!rocketLanes) return; // Node 测试把脚本拼接后，首个 reset 可能早于本模块初始化。
  for (const lane of Object.values(rocketLanes)){
    lane.bins.fill(null); lane.at = 0;
    for (const voice of lane.voices) voice.fade?.();
    lane.voices.length = 0;
    lane.fading.length = 0;
  }
}
function rocketQueue(kind, x, y){
  if (!actx || !player || !Number.isFinite(x) || !Number.isFinite(y)) return;
  const dx = x - player.x, d = Math.hypot(dx, y - player.y), lane = rocketLanes[kind];
  if (d >= lane.range){ audioDiagCount('far'); return; }
  audioDiagCount(kind);
  if (!audioRateLimit){
    if (kind === 'fire') rocketPlayFire(x, y, d, 1);
    else rocketPlayBoom(x, y, d, 1);
    return;
  }
  const side = dx < -180 ? 0 : dx > 180 ? 2 : 1;
  const bin = lane.bins[side] || (lane.bins[side] = { first:null, second:null, count:0 });
  bin.count++;
  if (!bin.first || d < bin.first.d){
    bin.second = bin.first;
    bin.first = { x, y, d };
  } else if (d < 420 && (!bin.second || d < bin.second.d)){
    bin.second = { x, y, d };
  }
  if (!lane.at) lane.at = actx.currentTime + lane.gap;
}
function rocketVoice(lane, d, now){
  for (let i = lane.voices.length - 1; i >= 0; i--)
    if (lane.voices[i].end <= now) lane.voices.splice(i, 1);
  if (lane.voices.length >= lane.cap){
    for (let i = lane.fading.length - 1; i >= 0; i--)
      if (lane.fading[i] <= now) lane.fading.splice(i, 1);
    if (lane.fading.length >= 4) return null;
    let weakest = -1;
    for (let i = 0; i < lane.voices.length; i++){
      const voice = lane.voices[i];
      if (voice.fade && now - voice.start >= 0.2 &&
          (weakest < 0 || voice.d > lane.voices[weakest].d)) weakest = i;
    }
    if (weakest < 0 || d + 100 >= lane.voices[weakest].d){
      /* 近处连续炸时，给新起音让出已经响完主体的尾音。 */
      weakest = -1;
      if (d < 600){
        for (let i = 0; i < lane.voices.length; i++){
          const voice = lane.voices[i];
          if (voice.fade && now - voice.start >= 0.5 &&
              (weakest < 0 || voice.start < lane.voices[weakest].start)) weakest = i;
        }
      }
      if (weakest < 0) return null;
    }
    const old = lane.voices.splice(weakest, 1)[0];
    lane.fading.push(old.fade() ?? now + 0.26);
  }
  const voice = { d, start:now, end:now + 0.8 };
  lane.voices.push(voice);
  return voice;
}
function rocketAudioTick(){
  if (!actx) return;
  const now = actx.currentTime;
  rocketFlightTick(now);
  for (const kind of ['fire','boom']){
    const lane = rocketLanes[kind];
    if (!lane.at || now < lane.at) continue;
    const picks = [];
    let extra = null;
    let requested = 0;
    for (const bin of lane.bins){
      if (!bin) continue;
      requested += bin.count;
      const second = bin.second?.d < 420 ? bin.second : null;
      /* 远处同方向的事件共享一个尾音，近处还可保留第二个独立起音。 */
      const weight = 1 + 0.08 * Math.min(3, bin.count - 1 - (second ? 1 : 0));
      picks.push({ ...bin.first, weight });
      if (second && (!extra || second.d < extra.d)) extra = { ...second, weight:0.72 };
    }
    if (extra) picks.push(extra);
    const label = kind === 'fire' ? '火箭发射' : '火箭爆炸';
    if (requested > picks.length) audioDiagBlock('同方向合并', label, undefined, requested - picks.length);
    lane.bins.fill(null); lane.at = 0;
    picks.sort((a,b) => a.d - b.d);
    const mixGain = Math.max(0.65, 1 / Math.sqrt(picks.length));
    for (const event of picks){
      const {x,y,d,weight} = event;
      const voice = rocketVoice(lane, d, now);
      if (!voice){ audioDiagBlock('火箭音源满', label, d); continue; }
      if (kind === 'fire') rocketPlayFire(x, y, d, weight * mixGain, voice);
      else rocketPlayBoom(x, y, d, weight * mixGain, voice);
    }
  }
}
function rocketPlayFire(px, py, d, weight, voice){
  if (!actx) return;
  const v = Math.max(0.08, 1 - d / 2200) * weight;
  const k = px === undefined ? 1 : 0.76 * v;
  const pan = px === undefined ? undefined : Math.max(-0.85, Math.min(0.85, (px - player.x) / (W * 0.5)));
  sfxGunShot(gunDef({wid:'rpg'}), { gainK:k, pan });
  if (_rsPlay(rsFireBuf, 0.65 * k, 0.96 + Math.random() * 0.08, d > 650 ? 0.65 : undefined, px, py, voice)) return;
  _xsNoise(0.30 * k, 900, 140, 0.34, 'lowpass', 0.8, px, py);
}
function sfxRocketFire(px, py){
  if (px === undefined) rocketPlayFire(undefined, undefined, 0, 1);
  else rocketQueue('fire', px, py);
}
/* 飞行声由三条共享循环承载，按最近的火箭平滑更新音量和声像。 */
var rocketFlightNoise = null;
function rocketFlightWarm(){
  if (!rocketFlightNoise || rocketFlightNoise.sampleRate !== actx.sampleRate){
    rocketFlightNoise = actx.createBuffer(1, actx.sampleRate * 2, actx.sampleRate);
    const pcm = rocketFlightNoise.getChannelData(0);
    for (let i = 0; i < pcm.length; i++) pcm[i] = Math.random() * 2 - 1;
  }
}
function rocketFlightLayer(now){
  rocketFlightWarm();
  const src = actx.createBufferSource(), filter = actx.createBiquadFilter(), gain = actx.createGain();
  const pan = actx.createStereoPanner ? actx.createStereoPanner() : null;
  src.buffer = rocketFlightNoise; src.loop = true;
  filter.type = 'bandpass'; filter.frequency.value = 1030; filter.Q.value = 2.2;
  gain.gain.setValueAtTime(0, now);
  src.connect(filter); filter.connect(gain);
  if (pan){ gain.connect(pan); pan.connect(duckBus()); }
  else gain.connect(duckBus());
  src.onended = () => { src.disconnect(); filter.disconnect(); gain.disconnect(); pan?.disconnect(); };
  src.start(now);
  return {src, filter, gain, pan, seen:now};
}
function rocketFlightRelease(layer){
  const now = actx.currentTime;
  layer.gain.gain.setTargetAtTime(0, now, 0.09);
  layer.src.stop(now + 0.55);
}
function sfxRocketFly(px, py){
  if (!actx || !player) return;
  const dx = px - player.x, d2 = dx * dx + (py - player.y) ** 2;
  if (d2 >= 1600 ** 2) return;
  const f = rocketFlight || (rocketFlight = {bins:[null,null,null], layers:[null,null,null], next:0});
  const side = dx < -180 ? 0 : dx > 180 ? 2 : 1;
  const slot = f.bins[side];
  if (!slot || d2 < slot.d2) f.bins[side] = {d2, dx};
}
function rocketFlightTick(now){
  const f = rocketFlight;
  if (!f || now < f.next) return;
  f.next = now + 0.045;
  const occupied = f.bins.filter(Boolean).length;
  for (let i = 0; i < f.layers.length; i++){
    const event = f.bins[i];
    const layer = f.layers[i];
    if (event){
      const v = layer || (f.layers[i] = rocketFlightLayer(now));
      v.seen = now;
      const near = 1 - Math.sqrt(event.d2) / 1600;
      // 循环是连续响的，沿用短脉冲的峰值会把飞行声抬得过响。
      v.gain.gain.setTargetAtTime(0.012 * near / Math.sqrt(occupied), now, 0.085);
      v.filter.frequency.setTargetAtTime(750 + 420 * near, now, 0.11);
      v.pan?.pan.setTargetAtTime(clamp(event.dx / (W * 0.5), -0.85, 0.85), now, 0.11);
    } else if (layer && now - layer.seen >= 0.16){
      layer.gain.gain.setTargetAtTime(0, now, 0.17);
      if (now - layer.seen >= 1.05){
        layer.src.stop(now + 0.02);
        f.layers[i] = null;
      }
    }
  }
  f.bins.fill(null);
  if (!occupied && !f.layers.some(Boolean)) rocketFlight = null;
}
function rocketPlayBoom(px, py, d, weight, voice){
  const v = Math.pow(Math.max(0.07, 1 - d / 2800), 1.35) * weight;
  const tail = d > 600 ? 1.6 : (voice && rocketLanes.boom.voices.length >= 6 ? 2.1 : undefined);
  if (_rsPlay(rsBoomBuf, 0.82 * v, 0.97 + Math.random() * 0.06, tail, px, py, voice)) return;
  _xsNoise(0.62 * v, 2600, 90, 0.75, 'lowpass', 0.9, px, py);
  _xsTone(0.40 * v, 92, 26, 0.7, 'sine');
}
function sfxRocketBoom(px, py, own){
  if (own && player) rocketPlayBoom(px, py, Math.hypot(px - player.x, py - player.y), 1);
  else rocketQueue('boom', px, py);
}

/* ---- 箱子 / 容器 ------------------------------------------------------ */
/* 开箱：木头吱呀 + 盖子落地。metal=保险箱那种铁皮声 */
function sfxCrateOpen(w){
  if (!_xsGate('crate', 0.05)) return;
  const metal = !!(w && w.kind === 'safe');
  if (metal){
    _xsTone(0.30, 1450, 900, 0.22, 'square');
    _xsTone(0.20, 2100, 1500, 0.16, 'sine');
    _xsNoise(0.26, 2200, 400, 0.2, 'bandpass', 1.6);
  } else {
    _xsNoise(0.30, 420, 180, 0.26, 'bandpass', 1.8);   /* 木头拉开 */
    _xsTone(0.22, 190, 120, 0.26, 'sawtooth');
  }
  _xsTone(0.26, 120, 62, 0.24, 'sine');                 /* 盖子砸下来 */
  _xsNoise(0.18, 900, 260, 0.3, 'bandpass', 1.0);
}
/* 搜刮：手在箱子里翻。搜的过程中每 0.22 秒响一下 */
function sfxCrateRustle(){
  if (!_xsGate('rustle', 0.22)) return;
  _xsNoise(0.10, 1500, 800, 0.12, 'bandpass', 2.2);
}

/* ---- 背包 ------------------------------------------------------------ */
function sfxBagSfx(open){
  if (!_xsGate('bag', 0.06)) return;
  if (open){ _xsNoise(0.13, 1200, 2600, 0.13, 'bandpass', 1.6); _xsTone(0.08, 420, 620, 0.1, 'sine'); }
  else     { _xsNoise(0.11, 2600, 900, 0.12, 'bandpass', 1.6); _xsTone(0.07, 520, 340, 0.1, 'sine'); }
}


/* ---- 实录武器音效：AR15 枪声 / AR15 换弹 / 捡枪 / 手雷拉环 / 手雷爆炸 ----
   全部走 data/sfx_weapons.js 里内嵌的 mp3，解码一次常驻。 */
var wsFireBuf = null, wsReloadBuf = null, wsReload2Buf = null, wsPickBuf = null, wsPinBuf = null, wsBoomBuf = null, wsDecoding = false;
function weaponSfxDecode(){
  if (wsDecoding || typeof b64ToBuf !== 'function') return;
  wsDecoding = true;
  const grab = (src, set) => {
    if (!src) return;
    try { b64ToBuf(src, b => set(b), () => set(null)); } catch (e){ set(null); }
  };
  grab(window.AR15_FIRE_SRC,   b => wsFireBuf = b);
  grab(window.AR15_RELOAD_SRC, b => wsReloadBuf = b);
  grab(window.AR15_RELOAD2_SRC, b => wsReload2Buf = b);
  grab(window.GUN_PICKUP_SRC,  b => wsPickBuf = b);
  grab(window.NADE_PIN_SRC,    b => wsPinBuf = b);
  grab(window.NADE_BOOM_SRC2,  b => wsBoomBuf = b);
}
/* 放一段实录：rate 变速、dur 截断、px/py 给了就做左右声像 */
function _wsPlay(buf, vol, rate, dur, px, py){
  if (!buf || typeof actx === 'undefined' || !actx) return false;
  try {
    const t0 = actx.currentTime;
    const r = rate || 1;
    const end = Math.min(dur || buf.duration, buf.duration / r);
    const src = actx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = r;
    const g = actx.createGain();
    /* 尾音过渡：最后 18%（至少 60ms）线性收掉，避免波形被硬切出"啪"的一声 */
    const _rel = Math.max(0.06, Math.min(0.28, end * 0.18));
    g.gain.setValueAtTime(Math.max(0.0002, vol), t0);
    g.gain.setValueAtTime(Math.max(0.0002, vol), t0 + Math.max(0.001, end - _rel));
    g.gain.linearRampToValueAtTime(0.0001, t0 + end);
    src.connect(g);
    let out = g;
    if (typeof px === 'number') out = _xsPan(g, px, py);
    else g.connect(duckBus());
    src.onended = () => { src.disconnect(); g.disconnect(); if (out !== g) out.disconnect(); };
    src.start(t0); src.stop(t0 + end + 0.02);
    return true;
  } catch (e) { return false; }
}
function sfxAr15Fire(px, py, enemyGain){
  if (!wsFireBuf) return false;
  if (enemyGain !== undefined){
    const near = clamp(1 - Math.hypot(px - player.x, py - player.y) / 1000, 0, 1);
    const volume = clamp((CFG.gunVol ?? 100) / 100, 0, 1);
    if (!(near > 0) || !(volume > 0)) return true;
    return _wsPlay(wsFireBuf, 0.32 * near * (0.5 + 0.5 * near) * enemyGain * volume,
                   0.95 + Math.random() * 0.08, 0.50, px, py);
  }
  const d = (typeof _xsDist === 'function') ? _xsDist(px, py) : 1;
  return _wsPlay(wsFireBuf, 0.80 * Math.pow(d, 1.1), 0.97 + Math.random() * 0.06, 0.50, px, py);
}
function sfxAr15Reload2(px, py){
  if (wsReload2Buf) return _wsPlay(wsReload2Buf, 0.72, 1.0, 0.34, px, py);
  return false;
}
function sfxAr15Reload(){ return _wsPlay(wsReloadBuf, 0.70, 1, 1.95); }
/* m20234：换弹声分三段按总时长排期 —— 以前只有"拔弹匣"和"最后一下"，
   中间 1.5 秒多全是静音，听起来像"换到一半后面的声音全没了"。
   返回 [{at, vol, rate}]，at 单位秒，纯数据方便测试。 */
function ar15ReloadPlan(T){
  const t = Math.max(0.4, T || 2.45);
  return [
    { at: 0,          vol: 0.70, rate: 0.86 },   /* 拔弹匣（拉长一点，盖住前半段） */
    { at: t * 0.52,   vol: 0.72, rate: 1.00 },   /* 弹匣推入 */
    { at: t * 0.86,   vol: 0.52, rate: 1.14 }    /* 拉栓 */
  ];
}
function sfxAr15ReloadSeq(gun){
  if (!gun || typeof player === 'undefined' || !player) return false;
  const T = gun.reloading || 0;
  if (!(T > 0)) return false;
  const plan = ar15ReloadPlan(T);
  const _g = gun;
  for (let i = 0; i < plan.length; i++){
    const s = plan[i];
    if (i === 0){
      _wsPlay(wsReloadBuf, s.vol, s.rate, Math.min(1.95, T * 0.62));
      continue;
    }
    setTimeout(function(){
      try{
        if (typeof player === 'undefined' || !player) return;
        if (player.gun !== _g) return;              /* 切枪了就不响 */
        if ((_g.reloading || 0) <= 0) return;       /* 换完了也不响 */
        _wsPlay(wsReload2Buf, s.vol, s.rate, 0.55);
      } catch (e){}
    }, Math.max(80, Math.round(s.at * 1000)));
  }
  return true;
}
function sfxPickupGun(){ return _wsPlay(wsPickBuf, 0.75, 1, 1.30); }
function sfxNadePin(){ return _wsPlay(wsPinBuf, 0.85, 1, 0.30); }
function sfxNadeBoom2(px, py){
  if (!wsBoomBuf) return false;
  const d = (typeof _xsDist === 'function') ? _xsDist(px, py) : 1;
  return _wsPlay(wsBoomBuf, 0.95 * Math.pow(d, 1.2), 1, 2.50, px, py);
}

/* ---------------- 拾取类录音（m19010） ---------------- */
var wsArmorTakeBuf = null, wsArmorWearBuf = null, wsNadeTakeBuf = null, wsGenericBuf = null, wsAmmoTakeBuf = null;
var wsPickDecoding = false;
function pickSfxDecode(){
  if (wsPickDecoding) return;
  wsPickDecoding = true;
  if (typeof b64ToBuf !== 'function'){ wsPickDecoding = false; return; }
  const grab = (src, set) => {
    if (!src){ set(null); return; }
    try { b64ToBuf(src, b => set(b), () => set(null)); } catch (e){ set(null); }
  };
  grab(window.ARMOR_TAKE_SRC, b => wsArmorTakeBuf = b);
  grab(window.ARMOR_WEAR_SRC, b => wsArmorWearBuf = b);
  grab(window.GRENADE_TAKE_SRC, b => wsNadeTakeBuf = b);
  grab(window.PICKUP_GENERIC_SRC, b => wsGenericBuf = b);
  grab(window.AMMO_TAKE_SRC, b => wsAmmoTakeBuf = b);
}
function sfxArmorTake(){ return _wsPlay(wsArmorTakeBuf, 0.95, 0.98 + Math.random() * 0.05, 0.40); }
function sfxArmorWear(){ return _wsPlay(wsArmorWearBuf, 0.98, 0.98 + Math.random() * 0.05, 0.40); }
function sfxGrenadeTake(){ return _wsPlay(wsNadeTakeBuf, 0.85, 0.98 + Math.random() * 0.05, 0.40); }
function sfxPickupGeneric(){ return _wsPlay(wsGenericBuf, 0.72, 0.96 + Math.random() * 0.08, 0.40); }
/* 背包里"放下/互换/穿上身"的轻响：小声、短、比拾取高一点，听感上像东西搁到布面上 */
function sfxBagPlace(){ return _wsPlay(wsGenericBuf, 0.38, 1.22, 0.16); }
function sfxAmmoTake(){ return _wsPlay(wsAmmoTakeBuf, 0.78, 0.96 + Math.random() * 0.08, 0.40); }
