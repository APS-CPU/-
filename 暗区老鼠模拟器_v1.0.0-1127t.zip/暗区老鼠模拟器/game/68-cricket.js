/* ============================================================================
   68-cricket.js —— 娱乐图「斗蛐蛐 · 长廊」（m39768 / m40173）

   一条长走廊，中间一条漆线分两半：
     · 中线左边放的是 A 势力（faction 'enemy'），右边是 B 势力（'bandit'）
     · 两边各自往对面走到尽头，中间碰上了就打
     · 玩家不在局内：隐形、无敌、不带枪，WASD/方向键只是把镜头挪过去看

   为什么把玩家做成"看不见的摄像机"：
   渲染的相机变换是以 player 为中心的（`translate(-cam.x,-cam.y)` 那一套），
   另建一套自由摄像机会和双筒望远镜、分块裁剪、准星全撞上。
   把玩家变隐身 + 不吃伤害 + AI 不认他，WASD 就等于平移镜头 —— 一行相机代码都不用改。

   m40173：改成"卡牌投放"——底部一排兵种卡，点卡片再点地图落点；
   不再开局自动摆两队（那会看不出是谁先动的手，也没法按自己的想法排兵）。
   ============================================================================ */

var CRICKET_DEF = {
  on: true,  autoSpawn: false,     /* 开局不自动摆人，全靠底部卡牌点（m40173） */
  perSide: 8,           /* 只给"一键摆满"用 */
  padX: 170,
  lanePad: 90,
  endR: 150,
  reissueT: 0.8,
  /* 行军用步速：没看见人时只走 CFG.eSpeed 的这个比例。
     m41535「没发现敌人的时候走路有点快，怎么感觉是跑而不是走」——
     原来走的是通用 AI 的 0.8 档，观战放大后看着就是小跑。 */
  marchK: 0.52,
  camSpd: 2.6,          /* 观战镜头移动倍率（m40173：原来太慢） */
  zoom: 1.0,            /* 观战缩放（1 = 原始；<1 看得更远） */
  zoomMin: 0.5,
  zoomMax: 1.9,
  /* 底部卡池：点哪张，再点地图就放哪儿。
     摄像头/无人机/假人/哨兵不进观战图（用户 m41899：看不到它们做什么事），
     换成两种能真的"守在原地输出"的阵地。 */
  roster: [
    { k: 'grunt',      label: '普通兵' },
    { k: 'spec',       label: '职业兵' },
    { k: 'specFlank',  label: '突击兵' },
    { k: 'hunter',     label: '猎手' },
    { k: 'guard',      label: '守卫' },
    { k: 'blade',      label: '刀手' },
    { k: 'grenadier',  label: '掷弹兵' },
    { k: 'rocketman',  label: '火箭筒兵' },
    { k: 'mgnest',     label: '机枪阵地' },
    { k: 'rkturret',   label: '火箭炮塔' },
    { k: 'truckA',     label: 'A 运兵车' },
    { k: 'truckB',     label: 'B 运兵车' }
  ]
};

/* 这台机器是不是"斗蛐蛐"观战图。
   _crkLeft 是"已经回大厅了"标记：goMenu 之后 levelIdx 还指着那张图，
   光看 L.rules.cricket 会在主菜单上继续画卡牌/场地图层（m41820 用户截图）。 */
var _crkLeft = false;
function cricketLeave(){ _crkLeft = true; _crkPick = null; }
/* 进关卡时无条件清掉"已离开"标记：否则从大厅再进这张图会被自己挡住，
   直接走普通关卡的出兵流程（m41899 用户截图：进图后一个兵都没有） */
function cricketEnter(){ _crkLeft = false; }
function cricketOn(L){
  if (_crkLeft) return false;
  const lv = L || (typeof cur === 'function' ? cur() : null);
  return !!(lv && lv.rules && lv.rules.cricket && CRICKET_DEF.on);
}

/* 观战缩放系数（只有这张图 ≠1）。
   绘制层（血条 / 飘字 / 命中标记）算屏幕位置时要用它，
   否则一缩放，字和血条就跟人分家了（m40575）。 */
function spectatorViewOn(L){
  return cricketOn(L) || (typeof mobaOn==='function' && mobaOn(L));
}
function crkZoomK(){
  if(typeof mobaOn==='function' && mobaOn())return mobaLvl.moba.zoom;
  return (typeof cricketOn === 'function' && cricketOn()) ? (CRICKET_DEF.zoom || 1) : 1;
}
/* 世界坐标 → 屏幕坐标：必须和 cricketMouseWorld() 互为逆运算，
   否则一开缩放（117%）血条、伤害数字就整体偏离人（用户 m41130 的截图）。
   推导：mouseWorld 里 wx = cam.x + W/2 + (mx - W/2)/z，反过来 mx = (wx - cam.x - W/2)*z + W/2。 */
function crkSX(wx){ const z = crkZoomK(); return (wx - cam.x - W/2) * z + W/2; }
function crkSY(wy){ const z = crkZoomK(); return (wy - cam.y - H/2) * z + H/2; }

/* 当前选中的卡（null = 没选）。右键 / Esc 取消 */
var _crkPick = null;
/* 鼠标在地图上的世界坐标（屏幕 → 世界，考虑观战缩放） */
function cricketMouseWorld(mx, my){
  if (mx === undefined) mx = (typeof mouse !== 'undefined' ? mouse.x : W / 2);
  if (my === undefined) my = (typeof mouse !== 'undefined' ? mouse.y : H / 2);
  const z = crkZoomK();
  return { x: cam.x + W / 2 + (mx - W / 2) / z, y: cam.y + H / 2 + (my - H / 2) / z };
}

/* 造一个人：阵营、颜色、目标点都在这一处（卡牌投放和"一键摆满"共用） */
function cricketMake(kind, side, x, y){
  const T = (typeof ENEMY_TYPES !== 'undefined' && ENEMY_TYPES[kind]) || ENEMY_TYPES.grunt;
  const L = cur();
  const fac = side ? 'bandit' : 'enemy';
  const goal = side ? 40 : (L.w - 40);
  const e = {
    type: kind, x: x, y: y, r: (T.r || 12),
    hp: (T.hp || 100), maxHp: (T.hp || 100), dead: false, stunT: 0, fearT: 0,
    HM: (T.hearMul || 1),
    ang: side ? Math.PI : 0,
    wp: [[goal, y]], i: 0, wait: 0, mode: 0,
    lastKnown: null, alertT: 0, sees: false, heard: false, chk: null, tgtRef: null,
    ammo: CFG.mag, fireCd: rand(0.3, 1.4), reloading: 0, muzzle: 0,
    faction: fac,
    /* 颜色：显式写 factionTint，否则两边都退回同一个灰（用户 m40173 说的"分不出哪队"） */
    factionTint: (typeof _ftint === 'function') ? _ftint(fac) : (side ? '#7fbf6a' : '#6d8fb8'),
    cricketSide: side,
    cricketGoal: goal
  };
  if (typeof assignWeapon === 'function') assignWeapon(e);
  return e;
}

/* 卡牌投放：世界坐标 (wx,wy)，中线左边=A、右边=B */
function cricketPlaceAt(kind, wx, wy){
  const L = cur();
  if (!L) return null;
  if (!kind) return null;
  const x = clamp(wx, 46, L.w - 46), y = clamp(wy, 46, L.h - 46);
  const sideOf = (px) => (px > L.w * 0.5 ? 1 : 0);
  /* 阵地卡：机枪阵地 / 火箭炮塔（m41899）—— 都是"原地输出"，丢下去自己打对面 */
  if (kind === 'mgnest' || kind === 'rkturret'){
    const side = sideOf(x);
    const fac = side ? 'bandit' : 'enemy';
    if (kind === 'mgnest'){
      if (typeof spawnMgNest !== 'function') return null;
      spawnMgNest(x, y, side ? Math.PI : 0, fac);
      /* 空枪位不会自己开火（m42075），所以放下之后要把话说明白 */
      if (typeof setMsg === 'function') setMsg('机枪阵地架好了 · 派个兵走近才会坐上去开火', 2.4);
    } else {
      if (typeof spawnRocketTurret !== 'function') return null;
      spawnRocketTurret({ x: x, y: y }, fac);
    }
    if (typeof spawnPart === 'function') spawnPart(x, y, 12, 'dust', 9);
    return cur().walls[cur().walls.length - 1] || null;
  }
  /* 车辆卡：直接放一台车（车会自己下兵，下车的兵继承车的阵营） */
  if (kind === 'truckA' || kind === 'truckB'){
    if (typeof spawnTruck !== 'function') return null;
    const fac = (kind === 'truckB') ? 'bandit' : 'enemy';
    const n0 = (typeof trucks !== 'undefined' && trucks) ? trucks.length : 0;
    spawnTruck('truck', { x: x, y: y }, fac);
    const t = (typeof trucks !== 'undefined' && trucks && trucks.length > n0) ? trucks[trucks.length - 1] : null;
    if (typeof spawnPart === 'function') spawnPart(x, y, 10, 'dust', 8);
    return t;
  }
  const side = x > L.w * 0.5 ? 1 : 0;
  const e = cricketMake(kind, side, x, y);
  enemies.push(e);
  if (typeof spawnPart === 'function') spawnPart(x, y, 8, 'dust', 7);
  return e;
}

/* 一键摆满两边（保留给测试 / 手滑党） */
function cricketFillBothSides(){
  const L = cur();
  if (!L || !cricketOn(L)) return 0;
  const D = CRICKET_DEF;
  const y0 = D.lanePad, y1 = Math.max(y0 + 40, L.h - D.lanePad);
  let n = 0;
  for (let side = 0; side < 2; side++){
    const sx = side ? (L.w - D.padX) : D.padX;
    for (let i = 0; i < D.perSide; i++){
      const kind = D.roster[i % 5].k;
      const y = y0 + (y1 - y0) * ((i + 0.5) / D.perSide);
      enemies.push(cricketMake(kind, side, sx, y));
      n++;
    }
  }
  return n;
}

/* 开局只把玩家切成"观战"，不摆人（autoSpawn:true 时才摆） */
function cricketSpawn(L){
  _crkLeft = false;
  if (!cricketOn(L)) return 0;
  if (player){ player.god = true; player.grace = Math.max(player.grace || 0, 3); player.thermal = false; }
  _crkPick = null;
  CRICKET_DEF.zoom = 1.0;
  if (CRICKET_DEF.autoSpawn) return cricketFillBothSides();
  return 0;
}

/* 鼠标按下：返回 true 表示这一下已经被观战图吃掉了 */
function cricketMouseDown(mx, my, button){
  if (!cricketOn()) return false;
  /* 暂停层（回大厅确认框）在最上面：别让卡牌抢走那一下点击（m40368） */
  if (typeof confirmBack !== 'undefined' && confirmBack) return false;
  const hit = cricketCardAt(mx, my);
  if (button === 2){
    if (_crkPick || hit >= 0){ _crkPick = null; return true; }
    return false;
  }
  if (hit >= 0){
    const k = CRICKET_DEF.roster[hit].k;
    _crkPick = (_crkPick === k) ? null : k;   /* 再点一次取消 */
    return true;
  }
  /* 点在卡片条那一带但没点到卡：别顺手在地上放人 */
  if (cricketBarRect(mx, my)) return true;
  if (_crkPick){
    const w = cricketMouseWorld(mx, my);
    cricketPlaceAt(_crkPick, w.x, w.y);
    return true;
  }
  return false;
}

/* 滚轮：观战缩放 */
function cricketWheel(deltaY){
  if (!cricketOn()) return false;
  const D = CRICKET_DEF;
  const f = Math.exp(-deltaY * 0.0016);
  D.zoom = clamp((D.zoom || 1) * f, D.zoomMin, D.zoomMax);
  return true;
}

/* 每帧：观战状态 + 没交火的人继续往对面走 + 缩放快捷键 */
var _cricketReissue = 0;
function cricketTick(dt, L){
  if (!cricketOn(L)) return;
  if (!player) return;
  player.god = true;
  player.grace = Math.max(player.grace || 0, 3);
  player.thermal = false;
  if (player.hp > 0) player.hp = player.hpMax || player.hp;
  if (typeof playerGun === 'function' && playerGun() && player.gun && player.gun.kind === 'gun'){
    player.gun = null;
  }
  /* 镜头速度：不改 CFG（会影响别的关），只在移动公式里乘一个观战倍率 */
  player.cricketSpdK = CRICKET_DEF.camSpd || 1;
  /* 缩放快捷键：- / = （小键盘和主键盘都收） */
  if (typeof keys !== 'undefined'){
    if (keys['Minus'] || keys['NumpadSubtract']) CRICKET_DEF.zoom = clamp((CRICKET_DEF.zoom || 1) * 0.985, CRICKET_DEF.zoomMin, CRICKET_DEF.zoomMax);
    if (keys['Equal'] || keys['NumpadAdd']) CRICKET_DEF.zoom = clamp((CRICKET_DEF.zoom || 1) * 1.015, CRICKET_DEF.zoomMin, CRICKET_DEF.zoomMax);
  }
  if (typeof keys !== 'undefined' && keys['Escape']) _crkPick = null;
  /* 暂停层弹出来时也别留着选中的卡，否则"回大厅"那一下会被当成在地图上投放（m40368） */
  if (typeof confirmBack !== 'undefined' && confirmBack) _crkPick = null;

  /* 每帧校正：AI 自己的巡逻/搜索逻辑会在没人看见目标时把 wp 改写成"附近随便一个点"，
     只在定时器里下一次命令，人就会原地打转（m40173 复盘：探针打出来 wp 被改成了自己脚下）。 */
  for (const e of enemies){
    if (!e || e.dead || !(e.hp > 0)) continue;
    /* 运兵车下来的兵不是 cricketMake 造的，没有 cricketGoal ——
       以前这里直接 continue，于是它们没有目标点，只会原地转圈（m40575）。
       按阵营补一个目标：A 往右尽头、B 往左尽头。 */
    if (e.cricketGoal === undefined){
      const _fac = (typeof combatFaction === 'function') ? combatFaction(e) : (e.faction || 'enemy');
      const _side = (_fac === 'bandit') ? 1 : 0;
      e.cricketSide = _side;
      e.cricketGoal = _side ? 40 : (L.w - 40);
      if (!e.factionTint && typeof _ftint === 'function') e.factionTint = _ftint(_fac);
    }
    /* 只按"现在看不看得见对手"停：斗蛐蛐图里没有警戒/搜索这一套 */
    if (e.sees){ e.marchK = 1; continue; }
    /* 正在打/刚听见动静的人，别管他 —— 以前这里不看状态，每帧把 lastKnown 盖成
       "走到对面尽头"，于是：①枪声给的坐标活不过一帧（用户 m41341「声纹是不看的」）
       ②两个没对上眼的就直直从对方身边跑过去（「擦肩而过」）
       ③战术层刚想找掩体/拉开距离，下一帧目标点又被拽回直线（「贴脸打」）。 */
    if (e.tgtRef || (e.alertT || 0) > 0.1 || e.lastKnownSource){ e.marchK = 1; continue; }
    if (Math.abs(e.x - e.cricketGoal) < CRICKET_DEF.endR){ e.marchK = 1; continue; }
    /* 只剩"没人、没动静、还没走到头"这一种情况：按行军速度走（m41535） */
    e.marchK = CRICKET_DEF.marchK;
    const _w = e.wp;
    if (!_w || !_w.length || !_w[0] || _w[0][0] !== e.cricketGoal){
      e.wp = [[e.cricketGoal, e.y]];
      e.i = 0; e.path = null; e.goal = null;
      e.chk = null; e.chaseStall = 0;
    }
    /* 行军用巡逻态（mode 0），不要强设 mode=1：那会把"追击"这套状态机顶掉，
       等他真看见人时已经停在对面脸上。 */
    e.mode = 0;
    e.lastKnown = null;
  }
}

/* 地面：两半淡色 + 中间一条漆线 + 两端队标。画在"地面印"那一层，人踩在上面 */
function drawCricketField(L){
  if (!cricketOn(L)) return;
  const z = CRICKET_DEF.zoom || 1;
  const x0 = cam.x + W / 2 - (W / 2) / z, y0 = cam.y + H / 2 - (H / 2) / z;
  const x1 = cam.x + W / 2 + (W / 2) / z, y1 = cam.y + H / 2 + (H / 2) / z;
  const mx = L.w * 0.5;
  ctx.fillStyle = 'rgba(96,140,190,0.055)';
  ctx.fillRect(Math.max(0, x0), Math.max(0, y0), Math.min(mx, x1) - Math.max(0, x0), Math.min(L.h, y1) - Math.max(0, y0));
  ctx.fillStyle = 'rgba(120,170,110,0.055)';
  ctx.fillRect(Math.max(mx, x0), Math.max(0, y0), Math.min(L.w, x1) - Math.max(mx, x0), Math.min(L.h, y1) - Math.max(0, y0));
  if (mx > x0 - 40 && mx < x1 + 40){
    ctx.save();
    ctx.strokeStyle = 'rgba(228,232,238,0.30)';
    ctx.lineWidth = 4;
    ctx.setLineDash([26, 20]);
    ctx.beginPath();
    ctx.moveTo(mx, Math.max(40, y0));
    ctx.lineTo(mx, Math.min(L.h - 40, y1));
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }
  ctx.save();
  ctx.font = 'bold 96px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(120,164,214,0.16)';
  ctx.fillText('A', L.w * 0.14, L.h * 0.5 + 34);
  ctx.fillStyle = 'rgba(128,178,118,0.16)';
  ctx.fillText('B', L.w * 0.86, L.h * 0.5 + 34);
  ctx.restore();
  /* 投放预览：鼠标处一个圈，颜色表示会放进哪一边 */
  if (_crkPick){
    const w = cricketMouseWorld();
    const side = w.x > L.w * 0.5 ? 1 : 0;
    ctx.save();
    ctx.strokeStyle = side ? 'rgba(140,200,128,0.92)' : 'rgba(120,170,224,0.92)';
    ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.arc(w.x, w.y, 15, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = side ? 'rgba(140,200,128,0.16)' : 'rgba(120,170,224,0.16)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.55)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(w.x, w.y, 3, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
  }
}

/* ---- 底部卡牌条（屏幕空间）---- */
/* 卡牌排布：种类多了以后单行放不下（m41593「人机种类不齐全」），
   按窗口宽度自动折成多行，最下面一行贴底，往上叠。 */
function cricketCardLayout(){
  const n = CRICKET_DEF.roster.length;
  const cw = 104, ch = 56, gap = 10;
  const perRow = Math.max(4, Math.floor((W - 40 + gap) / (cw + gap)));
  const rows = Math.ceil(n / perRow);
  return { n, cw, ch, gap, perRow, rows };
}
function cricketCardRect(i){
  const L = cricketCardLayout();
  const row = Math.floor(i / L.perRow);
  const col = i % L.perRow;
  /* 每行自己的数量（最后一行可能不满），按行居中 */
  const inRow = Math.min(L.perRow, L.n - row * L.perRow);
  const total = inRow * L.cw + (inRow - 1) * L.gap;
  const x0 = (W - total) / 2;
  const y = H - 118 - (L.rows - 1 - row) * (L.ch + 8);
  return { x: x0 + col * (L.cw + L.gap), y: y, w: L.cw, h: L.ch };
}
function cricketBarRect(mx, my){
  const L = cricketCardLayout();
  const top = cricketCardRect(0), bot = cricketCardRect(L.n - 1);
  return mx >= 20 && mx <= W - 20 &&
         my >= top.y - 26 && my <= bot.y + bot.h + 8;
}
function cricketCardAt(mx, my){
  for (let i = 0; i < CRICKET_DEF.roster.length; i++){
    const r = cricketCardRect(i);
    if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) return i;
  }
  return -1;
}

function drawCricketCards(){
  if (!cricketOn()) return;
  const R = CRICKET_DEF.roster;
  ctx.save();
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (let i = 0; i < R.length; i++){
    const r = cricketCardRect(i);
    const on = (_crkPick === R[i].k);
    ctx.fillStyle = on ? 'rgba(96,150,206,0.92)' : 'rgba(12,17,23,0.82)';
    roundRect(r.x, r.y, r.w, r.h, 8); ctx.fill();
    ctx.strokeStyle = on ? 'rgba(210,232,255,0.95)' : 'rgba(120,140,160,0.55)';
    ctx.lineWidth = on ? 2 : 1;
    roundRect(r.x, r.y, r.w, r.h, 8); ctx.stroke();
    ctx.fillStyle = on ? 'rgba(255,255,255,0.98)' : 'rgba(214,224,234,0.92)';
    ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
    ctx.fillText(R[i].label, r.x + r.w / 2, r.y + r.h / 2 - 6);
    ctx.font = '11px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = on ? 'rgba(235,245,255,0.85)' : 'rgba(150,166,180,0.8)';
    ctx.fillText('点它 → 点地图', r.x + r.w / 2, r.y + r.h / 2 + 14);
  }
  /* 顶部提示 */
  const tip = _crkPick
    ? ('放着：' + (R.find(x => x.k === _crkPick) || {}).label + '　·　中线左边 = A，右边 = B　·　继续点就继续放，右键/Esc 取消')
    : '选一张兵种卡，再点地图投放（左半 = A 势力 · 右半 = B 势力）　·　滚轮 /  - =  缩放　·　WASD 挪镜头　·　B 切难度';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(200,212,222,0.86)';
  ctx.fillText(tip, W / 2, cricketCardRect(0).y - 30);
  ctx.restore();
}

/* 顶部比分条 */
function drawCricketHud(){
  if (!cricketOn()) return;
  let a = 0, b = 0;
  for (const e of enemies){
    if (!e || e.dead || !(e.hp > 0)) continue;
    if (e.cricketSide === 1) b++; else a++;
  }
  const txt = 'A 势力 ' + a + '   ·   ' + b + ' B 势力';
  ctx.save();
  ctx.font = 'bold 16px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  const w = ctx.measureText(txt).width + 34;
  ctx.fillStyle = 'rgba(10,14,18,0.72)';
  roundRect(W / 2 - w / 2, 52, w, 30, 8); ctx.fill();
  ctx.strokeStyle = 'rgba(150,170,190,0.35)'; ctx.lineWidth = 1;
  roundRect(W / 2 - w / 2, 52, w, 30, 8); ctx.stroke();
  ctx.fillStyle = 'rgba(226,234,242,0.94)';
  ctx.fillText(txt, W / 2, 73);
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(160,176,190,0.75)';
  ctx.fillText('观战 · 缩放 ' + Math.round((CRICKET_DEF.zoom || 1) * 100) + '%', W / 2, 97);
  ctx.restore();
  drawCricketCards();
}
