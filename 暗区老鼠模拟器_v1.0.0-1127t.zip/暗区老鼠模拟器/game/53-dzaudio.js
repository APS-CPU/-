/* ============================================================
   死亡地带 · 选图页的环境声（第 17 轮）
   ------------------------------------------------------------
   只在这一屏响：远处在烧、时不时炸一下、偶尔有流弹飞过。
   全部是现合成的（不加载素材），三档强度跟 dzBgD 走：
     困难 = 远处一点火 + 零星枪响；噩梦 = 火近了些；硬核 = 火就在旁边。
   走 duckBus()，所以耳鸣/开发者暂停会自动把它一起压住。
   ============================================================ */

let _dzA = null;            /* 播着的那些节点 */
let _dzAWant = 0;           /* 目标音量 0..1 */
let _dzALast = -1;          /* 上一次被 tick 的时间（秒，performance.now 换算） */
let _dzACount = { crack:0, boom:0, whizz:0 };   /* 只给测试/自查看：已经响了几声 */

function dzAVol(){
  /* m33587：这里是环境声（火/远爆/流弹），跟「环境声」滑条走；以前挂的是武器音量，概念不对 */
  const v = (typeof CFG !== "undefined" && typeof CFG.ambVol === "number") ? (CFG.ambVol / 100) : 0.8;
  return Math.max(0, Math.min(1, v));
}

/* 一段循环用的噪声（火底噪）：偏"棕"，比白噪声闷，像远处的燃烧 */
function dzANoise(sec){
  const sr = actx.sampleRate, len = Math.floor(sr * sec);
  const buf = actx.createBuffer(1, len, sr);
  const d = buf.getChannelData(0);
  let last = 0;
  for (let i = 0; i < len; i++){
    const w = Math.random() * 2 - 1;
    last = (last + 0.02 * w) / 1.02;
    d[i] = last * 3.2;
  }
  return buf;
}

function dzAStart(){
  if (_dzA) return _dzA;
  /* 这一屏是点进来的，正常已经有 context；万一是直接跳进来的，就着这个时机建一次 */
  if (typeof actx !== "undefined" && !actx && typeof audioInit === "function"){ try { audioInit(); } catch (e){} }
  if (typeof actx === "undefined" || !actx || typeof duckBus !== "function") return null;
  try {
    const master = actx.createGain();
    master.gain.value = 0.0001;
    master.connect(duckBus());

    const fire = actx.createBufferSource();
    fire.buffer = dzANoise(2.6);
    fire.loop = true;
    const lp = actx.createBiquadFilter();
    lp.type = "lowpass"; lp.frequency.value = 460; lp.Q.value = 0.8;
    const fg = actx.createGain(); fg.gain.value = 0.55;
    fire.connect(lp); lp.connect(fg); fg.connect(master);
    fire.start();

    _dzA = { master: master, fire: fire, fireGain: fg,
             nextCrack: 0.2, nextBoom: 2.2, nextWhizz: 1.4, t: 0 };
    return _dzA;
  } catch (e){ _dzA = null; return null; }
}

/* 一声"噼啪"：短噪声过带通，快速衰减 */
function dzACrack(a, gain){
  _dzACount.crack++;
  try {
    const t = actx.currentTime;
    const src = actx.createBufferSource();
    src.buffer = (noiseBuf || dzANoise(0.4));
    /* m33587：原来 900~2700Hz 的带通听着就是一串电流噪声，不像火。
       现在压到 240~620Hz 的"噗"，再补一记 60~120Hz 的闷响尾巴，才是火星崩开的感觉。 */
    const bp = actx.createBiquadFilter();
    bp.type = "bandpass"; bp.frequency.value = 240 + Math.random() * 380; bp.Q.value = 0.9;
    const g = actx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09 + Math.random() * 0.1);
    src.connect(bp); bp.connect(g); g.connect(a.master);
    src.start(t); src.stop(t + 0.3);
  } catch (e){}
}

/* 远处爆炸：低频一下 + 一层闷噪声尾 */
function dzABoom(a, gain, impact = false){
  _dzACount.boom++;
  try {
    const t = actx.currentTime;
    const o = actx.createOscillator(); o.type = "sine";
    o.frequency.setValueAtTime(impact ? 92 : 58, t);
    o.frequency.exponentialRampToValueAtTime(26, t + 0.55);
    const og = actx.createGain();
    og.gain.setValueAtTime(0.0001, t);
    og.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + 0.02);
    og.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    o.connect(og); og.connect(a.master);
    o.start(t); o.stop(t + 1.0);

    const src = actx.createBufferSource();
    src.buffer = (noiseBuf || dzANoise(0.6));
    const lp = actx.createBiquadFilter();
    lp.type = "lowpass"; lp.frequency.value = impact ? 680 : 260;
    const g = actx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain * 0.8), t + 0.03);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
    src.connect(lp); lp.connect(g); g.connect(a.master);
    src.start(t); src.stop(t + 1.2);
    if(impact){
      const crack=actx.createBufferSource();
      crack.buffer=src.buffer;
      const band=actx.createBiquadFilter();
      band.type='bandpass';band.frequency.value=1050;band.Q.value=.55;
      const peak=actx.createGain();
      peak.gain.setValueAtTime(.0001,t);
      peak.gain.exponentialRampToValueAtTime(gain*.64,t+.007);
      peak.gain.exponentialRampToValueAtTime(.0001,t+.28);
      crack.connect(band);band.connect(peak);peak.connect(a.master);
      crack.start(t);crack.stop(t+.3);
    }
  } catch (e){}
}

/* 流弹：由远及近再远去的一声"咻" */
function dzAWhizz(a, gain){
  _dzACount.whizz++;
  try {
    const t = actx.currentTime;
    const src = actx.createBufferSource();
    src.buffer = (noiseBuf || dzANoise(0.5));
    const bp = actx.createBiquadFilter();
    bp.type = "bandpass"; bp.Q.value = 6;
    const f0 = 1500 + Math.random() * 700;
    bp.frequency.setValueAtTime(f0, t);
    bp.frequency.exponentialRampToValueAtTime(f0 * 0.22, t + 0.26);
    const g = actx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
    src.connect(bp); bp.connect(g); g.connect(a.master);
    src.start(t); src.stop(t + 0.35);
    /* 闷响尾巴：给火星一点"重量"，纯粹的高频噪声太像静电 */
    try {
      const o = actx.createOscillator(); o.type = 'sine';
      o.frequency.setValueAtTime(60 + Math.random() * 60, t);
      o.frequency.exponentialRampToValueAtTime(48, t + 0.18);
      const og = actx.createGain();
      og.gain.setValueAtTime(0.0001, t);
      og.gain.exponentialRampToValueAtTime(Math.max(0.0004, gain * 0.55), t + 0.012);
      og.gain.exponentialRampToValueAtTime(0.0001, t + 0.20);
      o.connect(og); og.connect(a.master);
      o.start(t); o.stop(t + 0.22);
    } catch (e){}
  } catch (e){}
}

/* 选图页每帧调一次：k = 0(困难) .. 1(硬核) */
function dzAudioTick(dt, k){
  if (typeof audioIsBackground === 'function' && audioIsBackground()) return;
  _dzALast = (typeof performance !== "undefined" ? performance.now() : Date.now()) / 1000;
  const a = dzAStart();
  if (!a) return;
  k = (typeof k === "number") ? Math.max(0, Math.min(1, k)) : 0;
  /* m33587：dzAVol() 自己就含「环境声」了，这里别再乘一次（否则 50% 会变成 25%） */
  _dzAWant = (0.30 + 0.70 * k) * dzAVol();
  try { a.master.gain.setTargetAtTime(_dzAWant * 0.9, actx.currentTime, 0.25); } catch (e){}
  a.t += (dt || 0);

  /* 火的底噪随难度变响、变亮；困难的雨夜基本没火，就别硬放一层火声 */
  const _fireK = Math.max(0, Math.min(1, (k - 0.15) / 0.85));
  try { if (a.fireGain && a.fireGain.gain) a.fireGain.gain.setTargetAtTime(0.70 * _fireK, actx.currentTime, 0.4); } catch (e){}

  /* 噼啪：难度越高越密 */
  /* m32149：硬核以前 0.06~0.25 秒一声（每秒 4~16 声），叠起来就是『密集的颗粒噪音』，
     而且随机性太大、时有时无。改成稀疏一点的火星：1.4~4 声/秒，音量也压下去一档。 */
  if (_fireK > 0.02 && a.t >= a.nextCrack){
    a.nextCrack = a.t + (0.30 + Math.random() * 0.55) / (0.65 + 0.55 * _fireK);
    dzACrack(a, (0.020 + Math.random() * 0.040) * (0.55 + 0.65 * _fireK));
  }
  /* 远处爆炸：3.6~7 秒一次，硬核勤一点、也响一点 */
  if (a.t >= a.nextBoom){
    a.nextBoom = a.t + 3.6 + Math.random() * 3.4 - k * 1.6;
    dzABoom(a, (0.16 + Math.random() * 0.14) * (0.55 + 0.65 * k));
  }
  /* 流弹：2~5 秒一次 */
  if (a.t >= a.nextWhizz){
    a.nextWhizz = a.t + 2.0 + Math.random() * 3.0 - k * 0.8;
    dzAWhizz(a, (0.05 + Math.random() * 0.06) * (0.6 + 0.5 * k));
  }
}

function dzAudioStop(){
  const a = _dzA;
  _dzA = null; _dzALast = -1; _dzAWant = 0;
  if (!a) return;
  try {
    const now = actx.currentTime;
    a.master.gain.setTargetAtTime(0, now, 0.025);
    a.fire.onended = () => { a.fire.disconnect(); a.master.disconnect(); };
    a.fire.stop(now + 0.16);
  } catch (e){ try { a.master.disconnect(); } catch (_){} }
}

/* 主循环每帧调：离开选图页约 0.3 秒后开始淡出，淡到听不见再把节点停掉 */
function dzAudioFrame(){
  if (!_dzA) return;
  const now = (typeof performance !== "undefined" ? performance.now() : Date.now()) / 1000;
  if (_dzALast < 0 || now - _dzALast > 0.22){
    _dzAWant = 0;
    try { _dzA.master.gain.setTargetAtTime(0.0001, actx.currentTime, 0.10); } catch (e){}
    if (now - _dzALast > 0.55 || _dzALast < 0){
      dzAudioStop();
    }
  }
}
