/* ============ 屏幕空间灰烬（m30146）============
   爆炸瞬间一次撒一批，之后 ashDur 秒内持续飘落；飞出屏幕就当场重投（复用同一个对象）。
   画在 render 的最后一步，所以连 HUD 都盖得住。 */
function ashBurst(x, y){
  const D = wreckDef();
  if (!D || D.on === false) return 0;
  ashT = Math.max(ashT, D.ashDur || 6.0);
  let n = 0;
  for (let i = 0; i < (D.ashBurst || 0); i++) if (spawnAsh(true)) n++;
  return n;
}
function spawnAsh(atTop){
  const D = wreckDef();
  const p = poolTake(ASH_POOL, ashes);
  if (!p) return null;
  p.x = atTop ? fxRand(-20, W + 20) : fxRand(-80, W + 80);
  p.y = atTop ? fxRand(-40, H * 0.55) : fxRand(-60, -10);
  p.vx = fxRand(14, 46);
  p.vy = wreckRange(D && D.ashFall, 70);
  p.t = 0; p.dur = fxRand(3.4, 7.0);
  p.size = wreckRange(D && D.ashSize, 3);
  p.rot = fxRand(0, TAU); p.spin = fxRand(-3.2, 3.2);
  p.a = fxRand(0.30, 0.78);
  return p;
}
function updateAsh(dt){
  if (ashT > 0){
    ashT = Math.max(0, ashT - dt);
    const D = wreckDef();
    const rate = (D && D.ashRate) || 0.02;
    ashAcc -= dt;
    let guard = 0;
    while (ashAcc <= 0 && guard++ < 6){ ashAcc += rate; spawnAsh(false); }
  }
  for (let i = ashes.length - 1; i >= 0; i--){
    const p = ashes[i];
    p.t += dt;
    p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.spin * dt;
    const gone = p.y > H + 40 || p.x < -120 || p.x > W + 140;
    if (gone && ashT > 0 && p.t < p.dur){
      p.x = fxRand(-20, W + 20); p.y = fxRand(-50, -12);
      p.vx = fxRand(14, 46); p.vy = wreckRange(wreckDef() && wreckDef().ashFall, 70);
      p.size = wreckRange(wreckDef() && wreckDef().ashSize, 3);
      p.a = fxRand(0.30, 0.78);
      continue;
    }
    if (gone || p.t >= p.dur){ poolReleaseAt(ashes, i); continue; }
  }
}
/* 最顶层：连 HUD、气泡、结算页都在它下面 */
function drawAshScreen(){
  if (!ashes.length) return;
  ctx.save();
  ctxScreen();          /* m23103：跟着渲染分辨率，不能用 identity */
  for (const p of ashes){
    const k = Math.min(1, p.t / 0.25) * Math.min(1, Math.max(0, (p.dur - p.t) / 0.6));
    const al = p.a * Math.max(0, k);
    if (al <= 0.02) continue;
    ctx.globalAlpha = al;
    ctx.fillStyle = (p.size > 3.0) ? 'rgba(34,34,36,1)' : 'rgba(104,100,94,1)';
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rot);
    const sw = p.size, sh = p.size * 0.45;
    ctx.fillRect(-sw * 0.5, -sh * 0.5, sw, sh);
    ctx.restore();
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}

function glowSprite(key, stops, size){
  var c = _glowCache[key];
  if (c) return c;
  size = size || 64;
  c = document.createElement('canvas');
  c.width = c.height = size;
  var gg = c.getContext('2d');
  var grd = gg.createRadialGradient(size/2, size/2, 0, size/2, size/2, size/2);
  for (var i2 = 0; i2 < stops.length; i2++) grd.addColorStop(stops[i2][0], stops[i2][1]);
  gg.fillStyle = grd;
  gg.fillRect(0, 0, size, size);
  _glowCache[key] = c;
  return c;
}
var GLOW_FLASH = null, GLOW_SMOKE = null, GLOW_MUZZLE = null, GLOW_HOT = null;
/* 烟团贴图：一团边缘化开的软雾（每帧只 drawImage，不再每团烟建 7 个渐变） */
var SMOKE_PUFF_COLS = {
  pd:  ['rgba(236,242,249,0.95)', 'rgba(198,209,222,0.62)', 'rgba(150,164,182,0)'],
  pdd: ['rgba(120,132,148,0.62)', 'rgba(96,108,124,0.40)', 'rgba(70,80,94,0)'],
  pl:  ['rgba(216,240,255,0.94)', 'rgba(159,200,232,0.58)', 'rgba(120,150,180,0)'],
  pld: ['rgba(120,144,166,0.58)', 'rgba(96,116,136,0.38)', 'rgba(70,86,102,0)'],
  ed:  ['rgba(196,182,172,0.95)', 'rgba(132,116,106,0.62)', 'rgba(58,50,46,0)'],
  edd: ['rgba(104,88,78,0.60)', 'rgba(80,66,58,0.40)', 'rgba(50,40,34,0)'],
  el:  ['rgba(240,226,216,0.94)', 'rgba(178,146,128,0.58)', 'rgba(96,74,62,0)'],
  eld: ['rgba(148,118,100,0.55)', 'rgba(118,92,78,0.36)', 'rgba(80,60,48,0)']
};
function smokePuffSprite(key){
  var c = _glowCache['smokepuff_' + key];
  if (c) return c;
  var col = SMOKE_PUFF_COLS[key] || SMOKE_PUFF_COLS.pd;
  var size = 128;
  c = document.createElement('canvas');
  c.width = c.height = size;
  var g = c.getContext('2d');
  var grd = g.createRadialGradient(size/2, size/2, size*0.03, size/2, size/2, size/2);
  /* 中心浓、外圈化开：四边形插值让边缘不再是一圈硬边 */
  grd.addColorStop(0,    col[0]);
  grd.addColorStop(0.38, col[1]);
  grd.addColorStop(0.66, col[1].replace(/[\d.]+\)$/, '0.26)'));
  grd.addColorStop(0.86, col[2].replace(/0\)$/, '0.07)'));
  grd.addColorStop(1,    col[2]);
  g.fillStyle = grd;
  g.fillRect(0, 0, size, size);
  _glowCache['smokepuff_' + key] = c;
  return c;
}
function drawSmokePuff(key, x, y, rad, alpha){
  if (!(rad > 0.5) || alpha <= 0.004) return;
  var sp = smokePuffSprite(key);
  ctx.globalAlpha = alpha;
  ctx.drawImage(sp, x - rad, y - rad, rad*2, rad*2);
}
function glowInit(){
  if (GLOW_FLASH) return;
  GLOW_FLASH = glowSprite('flash', [[0,'rgba(255,255,255,1)'],[0.5,'rgba(255,240,205,0.38)'],[1,'rgba(255,220,160,0)']], 64);
  GLOW_SMOKE = glowSprite('smoke', [[0,'rgba(184,175,156,1)'],[0.55,'rgba(160,152,136,0.5)'],[1,'rgba(150,142,126,0)']], 64);
  GLOW_MUZZLE = glowSprite('muzzle', [[0,'rgba(255,246,214,1)'],[0.42,'rgba(255,190,90,0.6)'],[1,'rgba(255,150,60,0)']], 64);
  GLOW_HOT = glowSprite('hot', [[0,'rgba(255,246,214,1)'],[0.6,'rgba(255,190,120,0.55)'],[1,'rgba(255,150,60,0)']], 64);
}
/* draw a glow sprite: centre x,y, radius r, alpha a */
function drawGlow(sp, x, y, r, a){
  if (!sp || a <= 0.004 || r <= 0.2) return;
  var pa = ctx.globalAlpha;
  ctx.globalAlpha = pa * (a > 1 ? 1 : a);
  ctx.drawImage(sp, x - r, y - r, r * 2, r * 2);
  ctx.globalAlpha = pa;
}

/* 掉落物的贴地阴影（contact shadow）。
   一张烘好的软圆斑贴图，按 rx/ry 拉成压扁的椭圆 —— 不要每件物品每帧
   createRadialGradient 或者 shadowBlur，割草里药掉一地就是成百次模糊。 */
var SHADOW_LOOT = null;
function drawLootShadow(x, y, rx, ry, rot){
  if (rx <= 0.4 || ry <= 0.4) return;
  if (!SHADOW_LOOT){
    SHADOW_LOOT = glowSprite('lootshadow',
      [[0,'rgba(0,0,0,0.8)'],[0.45,'rgba(0,0,0,0.5)'],[0.78,'rgba(0,0,0,0.16)'],[1,'rgba(0,0,0,0)']], 64);
  }
  var pa = ctx.globalAlpha;
  ctx.globalAlpha = pa * 0.95;
  /* 圆斑边缘是渐变的，压扁成椭圆后就是一个"软边贴地影子"。
     枪是斜着放的，影子跟着枪身转，落在地上才像"躺着的"，不像"底下垫了个圆"。 */
  if (rot){
    ctx.save();
    ctx.translate(x, y); ctx.rotate(rot);
    ctx.drawImage(SHADOW_LOOT, -rx, -ry, rx * 2, ry * 2);
    ctx.restore();
  } else {
    ctx.drawImage(SHADOW_LOOT, x - rx, y - ry, rx * 2, ry * 2);
  }
  ctx.globalAlpha = pa;
}
/* 每类道具的落脚点：[rx, ry, dy, dx?, rot?]
   药/子弹/甲/包是立着丢在地上的，只压一道"脚下"的扁影子：dy = 图标底边相对 l.y 的偏移。
   枪是斜躺在地上的，影子是整条枪身压出来的椭圆（rot 跟着画枪的角度），dy 是枪身中线。
   数值都是拿 _tools/_mkMeasure.cjs 量出图标包围盒后填的，换画法要回来重量一遍。 */
var LOOT_FOOT = {
  med:   [15.0, 5.0, 15.5],
  ammo:  [11.0, 4.2,  7.5],
  gun:   [26.0, 9.0,  0.5,  1.0, -0.42],
  smoke: [10.2, 4.4, 14.5],
  armor: [ 9.0, 4.0,  9.5],
  shield:[10.4, 4.4, 13.4,  0.0]
};
var LOOT_FOOT_GUN = {
  pistol:  [14.0, 9.0,  5.5,  0.0, -0.42],
  rifle:   [26.0, 9.0,  0.5,  1.0, -0.42],
  shotgun: [24.0, 8.5, -2.0, -1.0, -0.42],
  knife:   [28.0, 4.0,  1.0, -2.0, -0.42],
  dao:     [35.0, 8.0, -2.0, -3.0, -0.42],
  smoke:   [16.5, 5.6,  0.0, -3.0, -0.42]
};
function lootFoot(l){
  var k = l && l.kind;
  if (k === 'gun') return LOOT_FOOT_GUN[(l && l.wid) || 'pistol'] || LOOT_FOOT.gun;
  if (k === 'med' && l.rarity === 'big') return [17.0, 5.4, 17.5];
  if (k === 'bag'){
    /* 三种包型高低差得多，阴影跟着包底走 */
    var B = bagDef(l.bag || 'small') || {};
    if (B.look === 'rucksack') return [12.0, 4.6, 12.5];
    if (B.look === 'pack')     return [ 9.2, 4.0, 10.5];
    return [ 8.2, 3.8,  8.5];
  }
  return LOOT_FOOT[k] || [9.0, 4.0, 8.0];
}

function drawImpactFx(){
  for (const p of fxParts){
    const k = p.t / p.dur, a = 1 - k;
    if (!cullPt(p.x, p.y, 90)) continue;          /* 屏幕外的粒子不画 */
    ctx.save();
    if (p.kind === 'flash'){
      const r = p.size * (1 + k*1.3);
      glowInit();
      drawGlow(GLOW_FLASH, p.x, p.y, r, 0.9 * a * a);
    } else if (p.kind === 'ring'){
      ctx.globalAlpha = a*0.85;
      ctx.strokeStyle = 'rgba(255,242,206,0.95)';
      ctx.lineWidth = 0.6 + 2.4*a;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size*(0.35 + k*1.6), 0, TAU); ctx.stroke();
    } else if (p.kind === 'blood'){
      ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(158,26,20,0.95)';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size*(0.55+0.45*a), 0, TAU); ctx.fill();
    } else if (p.kind === 'dust'){
      ctx.globalAlpha = a*0.85;
      ctx.fillStyle = 'rgba(196,192,178,0.9)';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, TAU); ctx.fill();
    } else if (p.kind === 'gold'){             /* 暴击的火星是金的，比普通火星粗一圈 */
      ctx.globalAlpha = a;
      ctx.strokeStyle = 'rgba(255,212,96,1)';
      ctx.lineWidth = 2.2;
      const len = p.size*4.0;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - Math.cos(p.ang)*len, p.y - Math.sin(p.ang)*len);
      ctx.stroke();
    } else if (p.kind === 'critstar'){         /* 六道金色放射线，往外抽 */
      ctx.globalAlpha = a*0.95;
      const r0 = p.size*0.25, r1 = p.size*(0.5 + k*1.1);
      /* 双层描边代替 shadowBlur=10（每颗暴击星一次模糊） */
      ctx.strokeStyle = 'rgba(255,196,60,0.42)';
      for (let i=0;i<6;i++){
        const ang = p.ang + i*Math.PI/3;
        ctx.beginPath();
        ctx.moveTo(p.x + Math.cos(ang)*r0, p.y + Math.sin(ang)*r0);
        ctx.lineTo(p.x + Math.cos(ang)*r1, p.y + Math.sin(ang)*r1);
        ctx.lineWidth = 6.0*(1 - k) + 2.2; ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(255,226,132,0.95)';
      for (let i=0;i<6;i++){
        const ang = p.ang + i*Math.PI/3;
        ctx.beginPath();
        ctx.moveTo(p.x + Math.cos(ang)*r0, p.y + Math.sin(ang)*r0);
        ctx.lineTo(p.x + Math.cos(ang)*r1, p.y + Math.sin(ang)*r1);
        ctx.lineWidth = 2.6*(1 - k) + 0.6; ctx.stroke();
      }
    } else if (p.kind === 'mspark'){          /* 金属火星：更亮、更细、带跟尾 */
      ctx.globalAlpha = a;
      ctx.strokeStyle = 'rgba(255,250,214,0.98)';
      ctx.lineWidth = 1.5;
      const len = p.size * 5.2;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - Math.cos(p.ang)*len, p.y - Math.sin(p.ang)*len);
      ctx.stroke();
      ctx.globalAlpha = a * 0.5;
      ctx.strokeStyle = 'rgba(255,186,60,0.9)';
      ctx.lineWidth = 2.6;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - Math.cos(p.ang)*len*0.55, p.y - Math.sin(p.ang)*len*0.55);
      ctx.stroke();
    } else if (p.kind === 'chip'){            /* 土墙的碎渣：不发光的小方块 */
      ctx.globalAlpha = a * 0.92;
      ctx.fillStyle = 'rgba(122,108,86,0.95)';
      const z = p.size * (0.9 + k * 0.4);
      ctx.fillRect(p.x - z/2, p.y - z/2, z, z);
    } else if (p.kind === 'bsmoke'){          /* 爆炸黑烟：复用烟雾贴图，越飘越大越淡 */
      drawSmokePuff('ed', p.x, p.y, p.size * (1.0 + k * 1.9), 0.34 * a);
    } else if (p.kind === 'fire'){            /* 火苗：往上舔、被风吹得抖，芯白边橙，外圈透亮 */
      const _fx = p.x - Math.cos(p.ang) * (2 + k*10);
      const _fy = p.y - Math.sin(p.ang) * (2 + k*12) - k*26;
      const fr = Math.max(1, p.size * (0.55 + k*0.85) * (1 + Math.sin(p.t*19 + p.x*0.7)*0.12));
      ctx.globalAlpha = a * 0.95;
      const _fg = ctx.createRadialGradient(_fx, _fy, 0, _fx, _fy, fr);
      _fg.addColorStop(0,   'rgba(255,246,212,0.98)');
      _fg.addColorStop(0.42,'rgba(255,170,62,0.92)');
      _fg.addColorStop(1,   'rgba(150,40,16,0)');
      ctx.fillStyle = _fg;
      /* 竖着的椭圆 = 火舌；圆的只是一颗橙色玻璃珠 */
      ctx.beginPath(); ctx.ellipse(_fx, _fy, fr*0.66, fr*1.05, Math.sin(p.t*7 + p.x)*0.12, 0, TAU); ctx.fill();
    } else if (p.kind === 'smoke'){           /* 一团往后漂、变大变淡的烟（软边，不是一个灰球） */
      const _sx = p.x - Math.cos(p.ang) * (5 + k * 22);
      const _sy = p.y - Math.sin(p.ang) * (5 + k * 22) - k * 5;
      const rs = p.size * (0.75 + k * 2.4);
      glowInit();
      drawGlow(GLOW_SMOKE, _sx, _sy, Math.max(1, rs), 0.26 * a);
    } else {                                   /* spark：一道短亮线 */
      ctx.globalAlpha = a;
      ctx.strokeStyle = 'rgba(255,218,146,0.95)';
      ctx.lineWidth = 1.6;
      const len = p.size*3.4;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - Math.cos(p.ang)*len, p.y - Math.sin(p.ang)*len);
      ctx.stroke();
    }
    ctx.restore();
  }
}

/* 溅在屏幕上的血点：只在击杀时出现，半秒内褪掉。
   画在屏幕空间，跟世界镜头无关 —— 这才是"溅到我脸上"的那一层。 */
function drawSplats(){
  if (!splats.length) return;
  ctx.save();
  for (const s of splats){
    const k = s.t / s.dur;
    const a = (1 - k) * 0.58;
    if (a <= 0) continue;
    ctx.globalAlpha = a;
    ctx.fillStyle = 'rgba(150,16,12,0.95)';
    /* 一小片溅上去的血：中间一坨、被甩出去的几滴、再加两三颗更远的小点 */
    const dir = s.rot;
    for (let i=0;i<7;i++){
      const f = i / 6;
      const ang = dir + (i - 3)*0.18;
      const dist = s.r * (0.20 + f*1.25);
      const rr = s.r * (0.46 - f*0.30) * (0.82 + 0.36*(((i*37) % 7)/7));
      ctx.beginPath();
      ctx.ellipse(s.x + Math.cos(ang)*dist, s.y + Math.sin(ang)*dist,
                  rr, rr*(1 + 0.55*f), ang, 0, TAU);
      ctx.fill();
    }
    for (let i=0;i<3;i++){
      const ang = dir + (i - 1)*0.34;
      const dist = s.r * (1.55 + 0.35*i);
      ctx.beginPath();
      ctx.arc(s.x + Math.cos(ang)*dist, s.y + Math.sin(ang)*dist, s.r*0.085, 0, TAU);
      ctx.fill();
    }
  }
  ctx.restore();
}
