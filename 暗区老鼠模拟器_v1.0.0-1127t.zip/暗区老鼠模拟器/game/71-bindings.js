/* game/71-bindings.js — 输入绑定审计 + 运行期追踪（F8）
 *
 * 用户的痛点："最近太多按键冲突了……而不是需要我这样一遍遍尝试"
 * 这里给两件东西：
 *   1) 静态审计：把 data/bindings.js 当唯一事实来源，同键同作用域且 prio 不唯一 → 红；
 *      同键不同作用域 → 灰（正常的分层，不算冲突）。
 *   2) 运行期追踪：mousedown / keydown 一进来就记一条，关键分支再打点（shot / order / place …），
 *      F8 面板直接告诉你"最近这一下被谁接走了"。
 *
 * 以后加按键：往 data/bindings.js 加一行；忘写 prio 或撞了同 grp，F8 当场红。
 */
'use strict';

let bindAuditOpen = false;
const bindTrace = [];              /* {t, what, detail, mark} 最近若干条 */
const BIND_TRACE_MAX = 24;

/* 设置页和库存共用这套绑定。旧动作仍保存单键字符串，包含修饰键的动作保存两个 code。 */
const bindInventoryRows = BIND_ORDER.map(action => BIND_ROWS[action]).filter(row => row.bindScope);
const BIND_MODIFIER = { Shift:'shiftKey', Control:'ctrlKey', Alt:'altKey', Meta:'metaKey' };
const bindHeldKeys = new Set(), bindSwallowedKeys = new Set();
const bindDeferredKeys = new Map();
let bindFirst = null, bindSettingButton = null, bindSettingHint = '';

function bindModifierFamily(code){
  const family = /^(Shift|Control|Alt|Meta)(?:Left|Right)?$/.exec(code);
  return family ? family[1] : null;
}
function bindCodeMatches(binding, code){
  return binding === code || (Object.hasOwn(BIND_MODIFIER, binding) && bindModifierFamily(code) === binding);
}
function bindCodesOverlap(a, b){ return bindCodeMatches(a, b) || bindCodeMatches(b, a); }
function bindKeyboardCode(code){ return typeof code === 'string' && /^[A-Z][A-Za-z0-9]*$/.test(code); }
function bindValidValue(row, value){
  const mouseOrKey = code => bindKeyboardCode(code) || /^mouse[0-4]$/.test(code);
  if (Array.isArray(value)){
    return !!row.bindScope && value.length === 2 && bindKeyboardCode(value[0]) &&
      mouseOrKey(value[1]) && !bindCodesOverlap(value[0], value[1]);
  }
  if (typeof value !== 'string' || row.pair) return false;
  return row.bindScope ? mouseOrKey(value) : bindKeyboardCode(value);
}
function bindModifierHeld(mod, ev){
  const flag = BIND_MODIFIER[mod];
  if (flag && typeof ev?.[flag] === 'boolean') return ev[flag];
  for (const code of bindHeldKeys) if (bindCodeMatches(mod, code)) return true;
  return false;
}
function bindInventoryAction(code, ev, hasCargo, singleOnly){
  let single = null, chord = null;
  for (const row of bindInventoryRows){
    if (row.bindScope === 'cargo' && !hasCargo) continue;
    const value = BINDS[row.bindAction];
    if (Array.isArray(value)){
      if (!singleOnly && bindCodeMatches(value[1], code) && bindModifierHeld(value[0], ev) &&
          (!chord || row.prio > chord.prio)) chord = row;
    } else if (bindCodeMatches(value, code) && (!single || row.prio > single.prio)) single = row;
  }
  return chord || single;
}
function bindInventoryPrefix(code, hasCargo){
  return bindInventoryRows.some(row => {
    if (row.bindScope === 'cargo' && !hasCargo) return false;
    const value = BINDS[row.bindAction];
    return Array.isArray(value) && bindCodeMatches(value[0], code);
  });
}

function bindExecuteInventory(row, code, ev){
  if (!row || !inventoryPress(row, code, ev)) return false;
  const binding = BINDS[row.bindAction];
  if (Array.isArray(binding)){
    for (const pressed of bindDeferredKeys.keys()){
      if (bindCodeMatches(binding[0], pressed)) bindDeferredKeys.delete(pressed);
    }
  }
  if (bindKeyboardCode(code)){
    bindStamp('key', code);
    if (bindHeldKeys.has(code)) bindSwallowedKeys.add(code);
  }
  bindMark(row.bindAction);
  bindConsumeInput(ev);
  return true;
}

function bindInventoryKeyDown(ev, singleOnly){
  if (!inventoryInputActive()) return false;
  const code = ev.code, hasCargo = !!inventoryCargoTruck();
  const row = bindInventoryAction(code, ev, hasCargo, singleOnly);
  if (!singleOnly && !Array.isArray(BINDS[row?.bindAction]) && bindInventoryPrefix(code, hasCargo)){
    if (!ev.repeat) bindDeferredKeys.set(code, ev);
    bindConsumeInput(ev);
    return true;
  }
  return bindExecuteInventory(row, code, ev);
}

function bindCaptureCancel(){
  bindTarget = null; bindFirst = null; bindSettingHint = '';
}
function bindCaptureStart(action){
  bindTarget = action; bindFirst = null; bindSettingHint = '';
}
function bindCaptureLabel(action){
  if (bindTarget !== action) return keyLabel(BINDS[action]);
  if (bindFirst) return keyLabel(bindFirst) + ' + …';
  if (bindSettingHint) return bindSettingHint;
  const row = BIND_ROWS[action];
  if (!row.bindScope) return '按任意键…';
  return row.pair ? '按住第一键…' : '先按一个键…';
}
function bindCaptureFinish(value){
  const action = bindTarget, row = BIND_ROWS[action];
  if (!bindValidValue(row, value)) return;
  const old = BINDS[action];
  for (const other of BIND_ORDER){
    if (other === action || !!BIND_ROWS[other].bindScope !== !!row.bindScope) continue;
    const assigned = BINDS[other];
    if (Array.isArray(value) !== Array.isArray(assigned)) continue;
    const same = Array.isArray(value)
      ? bindCodesOverlap(value[0], assigned[0]) && bindCodesOverlap(value[1], assigned[1])
      : bindCodesOverlap(value, assigned);
    if (!same) continue;
    if (!row.bindScope){ BINDS[other] = old; continue; }
    bindFirst = null;
    bindSettingHint = '与「' + BIND_NAME[other] + '」重复';
    refreshKeyRows();
    return;
  }
  BINDS[action] = value; saveBinds();
  bindCaptureCancel(); refreshKeyRows();
}

function bindConsumeInput(ev){
  ev.preventDefault?.();
  if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
  else ev.stopPropagation?.();
}
function bindCapturePress(code, ev){
  if (!bindTarget) return false;
  const row = BIND_ROWS[bindTarget];
  const isKey = bindKeyboardCode(code);
  if (!isKey && !row.bindScope) return false;
  bindConsumeInput(ev);
  if (isKey) bindSwallowedKeys.add(code);
  else bindSettingButton = ev.button;
  if (ev.repeat) return true;
  if (code === 'Escape' || (!row.bindScope && code === 'Tab')){
    bindCaptureCancel(); refreshKeyRows(); return true;
  }
  if (!row.bindScope){ bindCaptureFinish(code); return true; }
  if (!bindFirst){
    if (!isKey && row.pair){
      bindSettingHint = '请先按住一个键盘键'; refreshKeyRows();
    } else {
      bindFirst = code; bindSettingHint = ''; refreshKeyRows();
    }
    return true;
  }
  const first = bindModifierFamily(bindFirst) || bindFirst;
  const pair = [first, code];
  if (isKey && bindCodeMatches(first, code)) return true;
  if (bindValidValue(row, pair)) bindCaptureFinish(pair);
  return true;
}
function bindCaptureRelease(code, ev){
  if (!bindTarget || code !== bindFirst) return false;
  bindConsumeInput(ev);
  if (BIND_ROWS[bindTarget].pair){
    bindFirst = null; bindSettingHint = '请按住第一键，再按第二键'; refreshKeyRows();
  } else bindCaptureFinish(code);
  return true;
}
function bindCaptureMouseDown(ev){
  bindSettingButton = null;
  if (bindTarget) bindCapturePress('mouse' + ev.button, ev);
}
function bindCaptureMouseUp(ev){
  if (bindSettingButton !== ev.button) return false;
  if (!bindCaptureRelease('mouse' + ev.button, ev)) bindConsumeInput(ev);
  return true;
}
function bindCaptureClick(ev){
  if (bindSettingButton !== ev.button || ev.detail === 0) return;
  bindSettingButton = null; bindConsumeInput(ev);
}

loadBinds();
addEventListener('mousedown', bindCaptureMouseDown, true);
addEventListener('click', bindCaptureClick, true);
addEventListener('auxclick', bindCaptureClick, true);

function bindTable(){ return (typeof DataBINDINGS !== 'undefined' && DataBINDINGS) ? DataBINDINGS : []; }

/* ---------- 静态审计 ---------- */
function bindAudit(rows){
  rows = rows || bindTable();
  const byKey = new Map();
  for (const b of rows){
    const key = Array.isArray(b.key) ? b.key.join(' + ') : b.key;
    if (!byKey.has(key)) byKey.set(key, []);
    byKey.get(key).push(b);
  }
  const hard = [], layered = [];
  for (const [key, list] of byKey){
    if (list.length < 2) continue;
    const byGrp = new Map();
    for (const b of list){
      const g = b.grp || '*';
      if (!byGrp.has(g)) byGrp.set(g, []);
      byGrp.get(g).push(b);
    }
    for (const [g, same] of byGrp){
      if (same.length < 2) continue;
      const prios = same.map(b => (typeof b.prio === 'number' ? b.prio : NaN));
      const bad = prios.some(p => !isFinite(p)) || new Set(prios).size !== prios.length;
      (bad ? hard : layered).push({ key: key, grp: g, items: same, reason: bad ? '同键同作用域且 prio 未定/重复' : '同键同作用域，已用 prio 定序' });
    }
  }
  return { hard: hard, layered: layered, total: rows.length };
}

/* ---------- 运行期追踪 ---------- */
function bindStamp(what, detail){
  bindTrace.push({ t: (typeof T !== 'undefined' ? T : 0), what: what, detail: detail || '', mark: '' });
  while (bindTrace.length > BIND_TRACE_MAX) bindTrace.shift();
  return bindTrace[bindTrace.length - 1];
}
/* 分支打点：把"这一下被谁接走"补到最后一条输入记录上 */
function bindMark(mark){
  const last = bindTrace[bindTrace.length - 1];
  if (last){ last.mark = mark; last.t = (typeof T !== 'undefined' ? T : last.t); }
}

/* 从事件里抽取人话键名 */
function bindNameOf(ev){
  if (!ev) return '?';
  if (typeof ev.button === 'number') return 'mouse' + ev.button;
  return ev.code || ev.key || '?';
}

function bindAuditToggle(){
  bindAuditOpen = !bindAuditOpen;
  if (typeof setMsg === 'function') setMsg(bindAuditOpen ? '输入审计（F8 关闭）' : '输入审计关', 1.4);
}

/* ---------- 面板 ---------- */
function drawBindAudit(){
  if (!bindAuditOpen) return;
  const _vw = (typeof W === 'number') ? W : cv.width;
  const _vh = (typeof H === 'number') ? H : cv.height;
  const pw = Math.min(760, _vw - 80), px = (_vw - pw) / 2;
  const a = bindAudit();
  const rowsN = Math.min(10, a.hard.length * 2 + a.layered.length * 2 + 4);
  const ph = Math.min(_vh - 90, 210 + rowsN * 22 + Math.min(10, bindTrace.length) * 20);
  const py = (_vh - ph) / 2;

  ctx.save();
  ctx.fillStyle = 'rgba(8,11,15,0.93)';
  ctx.fillRect(px, py, pw, ph);
  ctx.strokeStyle = a.hard.length ? 'rgba(232,106,106,0.85)' : 'rgba(120,180,140,0.7)';
  ctx.lineWidth = 1.4;
  ctx.strokeRect(px + 0.5, py + 0.5, pw - 1, ph - 1);

  ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  ctx.fillStyle = '#dfe8f2'; ctx.font = '600 15px system-ui, "Microsoft YaHei", sans-serif';
  ctx.fillText('输入审计 · ' + a.total + ' 条绑定', px + 16, py + 20);
  ctx.font = '12px system-ui, "Microsoft YaHei", sans-serif';
  ctx.fillStyle = 'rgba(160,175,190,0.9)';
  ctx.fillText('F8 关闭 · 白名单在 data/bindings.js；红=同键同作用域且 prio 未定', px + 16, py + 40);

  let y = py + 66;
  const line = (color, txt) => {
    ctx.fillStyle = color; ctx.fillText(txt, px + 18, y); y += 20;
  };
  if (!a.hard.length){
    line('rgba(150,210,170,0.95)', '✓ 没有未定优先级的冲突');
  } else {
    for (const c of a.hard.slice(0, 6)){
      line('rgba(240,120,120,1)', '✗ ' + c.key + ' @' + c.grp + ' — ' + c.reason);
      for (const b of c.items) line('rgba(226,150,150,0.92)', '    · ' + b.id + '  ' + b.label + '  (prio ' + b.prio + ')');
    }
  }
  if (a.layered.length){
    const names = a.layered.slice(0, 4).map(c => c.key + '@' + c.grp).join('、');
    line('rgba(150,170,190,0.95)', '· 已定序的同键多分支：' + names + (a.layered.length > 4 ? ' …' : ''));
  }

  y += 6;
  ctx.strokeStyle = 'rgba(120,140,160,0.32)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(px + 16, y - 8); ctx.lineTo(px + pw - 16, y - 8); ctx.stroke();
  ctx.fillStyle = '#c9d6e2'; ctx.font = '600 13px system-ui, "Microsoft YaHei", sans-serif';
  ctx.fillText('最近输入（谁接走了）', px + 18, y + 4); y += 24;
  ctx.font = '12px ui-monospace, Consolas, monospace';
  if (!bindTrace.length){
    ctx.fillStyle = 'rgba(150,165,180,0.9)';
    ctx.fillText('（还没有输入）', px + 22, y); y += 20;
  }
  for (const r of bindTrace.slice(-10)){
    const ok = r.mark && r.mark !== 'none';
    ctx.fillStyle = ok ? 'rgba(150,205,170,0.95)' : 'rgba(200,180,150,0.9)';
    ctx.fillText(r.what.padEnd(10, ' ') + (r.detail ? ' ' + r.detail : '') + '   → ' + (r.mark || '（没人接）'), px + 22, y);
    y += 20;
  }
  ctx.restore();
}

/* F8 绑定：在 16-frag 的 keydown 里调用 */
function bindKeyHook(e){
  if (!e) return false;
  if (e.code === 'F8' && !e.repeat){
    if (e.preventDefault) e.preventDefault();
    bindAuditToggle();
    return true;
  }
  return false;
}
