/* \u6ca1\u627e\u5230\u6587\u4ef6\u7684\u90a3\u4e9b\uff0c\u4e0b\u6b21\u5c31\u4e0d\u518d\u5c1d\u8bd5\u4e86 */
const AUDIO_CACHE = {};
const AUDIO_MISSING = {};

/* \u540c\u4e00\u4e2a\u97f3\u6548\u4e00\u6b21\u53ef\u4ee5\u54cd\u51e0\u58f0\uff1a\u5355\u4e2a <audio> \u91cd\u64ad\u4f1a\u628a\u4e0a\u4e00\u58f0\u5207\u65ad */
const AUDIO_POOL = {};
const AUDIO_CURSOR = {};
const AUDIO_LAST = {};
const AUDIO_LOCAL_RESERVE = 2;
/* 对照测试：关闭会跳过独立起音的预算、去重和录音池上限。 */
let audioRateLimit = false;
let audioMasterLimit = false;
const AUDIO_OPTIONS_KEY = 'after5_audioOptions';
try{
  const options = JSON.parse(localStorage.getItem(AUDIO_OPTIONS_KEY) || '{}');
  audioRateLimit = options?.rateLimit === true;
  audioMasterLimit = options?.masterLimit === true;
} catch(e){}
function saveAudioOptions(){
  try{
    localStorage.setItem(AUDIO_OPTIONS_KEY, JSON.stringify({ rateLimit:audioRateLimit, masterLimit:audioMasterLimit }));
  } catch(e){}
}

let _enemyWinT = 0, _enemyWinN = 0;
const _enemyArEnds = [];

function sndNow(){
  return (typeof performance !== 'undefined' && performance.now)
    ? performance.now() / 1000 : Date.now() / 1000;
}

/* F3 的近一秒统计。只保留小窗口和最近一次限制原因。 */
const audioDiagBins = Array.from({ length:8 }, () => ({ tick:-1, counts:{} }));
let audioDiagLastBlock = null;
let audioDiagLastLimit = null;
let audioDiagWeb = null;
function audioDiagCount(key, count = 1, now = sndNow()){
  const tick = Math.floor(now * 8);
  const bin = audioDiagBins[tick % audioDiagBins.length];
  if (bin.tick !== tick){
    bin.tick = tick;
    bin.counts = {};
  }
  bin.counts[key] = (bin.counts[key] || 0) + count;
}
function audioDiagBlock(reason, name, distance, count = 1, key = 'limited'){
  const now = sndNow();
  audioDiagCount(key, count, now);
  audioDiagLastBlock = { reason, name, distance, now };
  if (key === 'limited') audioDiagLastLimit = audioDiagLastBlock;
}
function audioDiagRecent(now){
  const tick = Math.floor(now * 8), counts = {};
  for (const bin of audioDiagBins){
    if (bin.tick < 0 || tick - bin.tick >= audioDiagBins.length) continue;
    for (const key of Object.keys(bin.counts)) counts[key] = (counts[key] || 0) + bin.counts[key];
  }
  return counts;
}

/* 只在打开 F3 后追踪当前 AudioContext 新起的节点，离线预生成不经过这里。 */
function audioDiagWatch(on){
  if (audioDiagWeb && (!on || audioDiagWeb.ctx !== actx)){
    const {ctx, factories, sources} = audioDiagWeb;
    for (const [key, wrapper, original] of factories){
      if (ctx[key] === wrapper) ctx[key] = original;
    }
    sources.clear();
    audioDiagWeb = null;
  }
  if (!on || !actx || !actx.addEventListener || audioDiagWeb) return;
  const watch = { ctx:actx, factories:[], sources:new Map() };
  for (const key of ['createBufferSource','createOscillator']){
    const original = actx[key];
    if (typeof original !== 'function') continue;
    const wrapper = function(...args){
      const node = original.apply(this, args);
      const start = node.start;
      node.start = function(...times){
        const result = start.apply(this, times);
        if (audioDiagWeb === watch){
          watch.sources.set(node, times[0] || 0);
          node.addEventListener('ended', () => watch.sources.delete(node), { once:true });
          audioDiagCount('web');
        }
        return result;
      };
      return node;
    };
    actx[key] = wrapper;
    watch.factories.push([key, wrapper, original]);
  }
  audioDiagWeb = watch;
}

function audioDiagLines(){
  const now = sndNow(), counts = audioDiagRecent(now);
  const audioState = actx?.state || '未初始化';
  const mute = _pauseGainWant === 0 ? ' · 总线静音' : '';
  const tin = tinT > 0 ? ' · 耳鸣 ' + tinT.toFixed(1) + 's' : '';
  const mixGain = Math.round((_duckBus?.gain.value ?? 1) * 100);
  const limiter = !audioMasterLimit ? '关' : _masterLimiterOn
    ? '开 ' + (_masterLimiter.reduction || 0).toFixed(1) + 'dB' : '未接入';
  const activeMedia = _sndActive();
  const mediaNames = Object.keys(AUDIO_POOL).filter(name => AUDIO_POOL[name].some(_sndBusy));
  const otherMedia = Math.max(0, audioEls().filter(_sndBusy).length - activeMedia);
  let activeWeb = 0;
  if (audioDiagWeb){
    for (const start of audioDiagWeb.sources.values()) if (start <= actx.currentTime) activeWeb++;
  }
  const describe = (label, event) => {
    if (!event) return label + ' —';
    const age = Math.max(0, now - event.now).toFixed(1);
    const distance = Number.isFinite(event.distance) ? ' · ' + Math.round(event.distance) + 'px' : '';
    return label + ' ' + age + 's前 · ' + event.reason + ' · ' + (event.name || '—') + distance;
  };
  return [
    '音频 ' + audioState + mute + tin + ' · 音效总线 ' + mixGain + '% · 压限 ' + limiter,
    '限流 ' + (audioRateLimit ? '开' : '关') + ' · 录音池 ' + activeMedia + (audioRateLimit ? '/' + MAX_CONCURRENT : '') +
      ' · 其他录音 ' + otherMedia + ' · WebAudio ' + activeWeb + '（开 F3 后）',
    '近 1 秒起音 WebAudio ' + (counts.web || 0) + ' · 录音提交 ' + (counts.media || 0) + ' · 车载机枪请求 ' + (counts.truck || 0),
    '听距内请求 敌枪 ' + (counts.gun || 0) + ' · 敌脚步 ' + (counts.step || 0) + ' · 敌火箭 ' + (counts.fire || 0) + ' · 火箭爆炸 ' + (counts.boom || 0),
    '近 1 秒 限流 ' + (counts.limited || 0) + ' · 去重 ' + (counts.dedupe || 0) + ' · 兜底 ' + (counts.fallback || 0) + ' · 播放失败 ' + (counts.failed || 0) + ' · 超听距 ' + (counts.far || 0),
    describe('最近限流', audioDiagLastLimit),
    describe('最近处理', audioDiagLastBlock),
    '录音池正在使用 ' + (mediaNames.join(' · ') || '—')
  ];
}

/* \u5f00\u5c40\u9884\u52a0\u8f7d\uff1a\u8fd9\u6837\u201c\u6587\u4ef6\u4e0d\u5b58\u5728\u201d\u4f1a\u5728\u73a9\u5bb6\u7b2c\u4e00\u58f0\u4e4b\u524d\u5c31\u88ab\u53d1\u73b0 */
/* 一个音效建一组 <audio>（敌人枪声用懒加载，第一声才建） */
function audioPoolMake(name, n){
  if (AUDIO_MISSING[name]) return null;
  const rel = AUDIO_FILE[name];
  if (!rel || typeof Audio !== 'function') return null;
  const pool = [];
  try{
    for (let i = 0; i < n; i++){
      const el = new Audio(AUDIO_DIR + rel);
      el.preload = 'auto';
      el.addEventListener('error', function(){ AUDIO_MISSING[name] = true; });
      try{ el.load(); }catch (e){}
      pool.push(el);
    }
  } catch (e){ AUDIO_MISSING[name] = true; return null; }
  AUDIO_POOL[name] = pool;
  return pool;
}

/* 敌人开枪：声像看屏幕左右，音量看距离，同一瞬间最多两声
   不给每个小兵建播放器（那会卡），全场只用固定几个槽位轮流 */
function enemyGunSfx(ex, ey, wid){
  if (typeof Audio !== 'function') return false;
  const px = (typeof player !== 'undefined' && player) ? player.x : 0;
  const py = (typeof player !== 'undefined' && player) ? player.y : 0;
  const dx = ex - px;
  const d = Math.hypot(dx, ey - py);
  // 超出听距是有意处理，调用方不应再补一声居中的方波。
  if (d >= 1000){ audioDiagCount('far'); return true; }
  if (wid !== 'rpg') audioDiagCount('gun');
  const _half = (typeof W === 'number' ? W : 1280) * 0.33;
  const side = dx < -_half ? 'l' : (dx > _half ? 'r' : 'c');
  const k = Math.max(0, Math.min(1, 1 - d / 1000));
  if (wid === 'rpg'){
    if (actx && typeof sfxRocketFire === 'function'){
      sfxRocketFire(ex, ey);
      return true;
    }
    /* 极早期（合成器还没起来）才退回录音池，压低音高当闷响 */
    return sndPlay('gun.enemy.shotgun.' + side, 0.20 + 0.30 * k * k, 0.55, undefined, d);
  }
  const _w = (wid === 'rifle' || wid === 'shotgun') ? wid : 'pistol';
  if (audioRateLimit){
    const t = sndNow();
    if (t - _enemyWinT > ENEMY_GUN_WIN){ _enemyWinT = t; _enemyWinN = 0; }
    if (_enemyWinN >= ENEMY_MAX_PER_WIN){
      audioDiagBlock('敌枪窗口', wid, d);
      return true;
    }
    _enemyWinN++;
  }
  /* 敌方 AR15 和其它步枪共用起音预算。已经开始的尾音自然播完。 */
  if (wid === 'ar' && actx && typeof sfxAr15Fire === 'function'){
    if (audioRateLimit){
      const now = actx.currentTime;
      while (_enemyArEnds.length && _enemyArEnds[0] <= now) _enemyArEnds.shift();
      if (_enemyArEnds.length >= 4){
        audioDiagBlock('AR15 尾音占满', wid, d);
        return true;
      }
      const tailGain = _enemyArEnds.length >= 2 ? 0.8 : 1;
      if (sfxAr15Fire(ex, ey, tailGain)){
        _enemyArEnds.push(now + 0.52);
        return true;
      }
    } else if (sfxAr15Fire(ex, ey)){
      return true;
    }
  }
  /* HTMLAudio 音效绕过 WebAudio 压限，先在音源上留出混音余量。 */
  const vol = 0.30 * k * (0.35 + 0.65 * k);
  const rate = 0.90 + 0.10 * k;
  return sndPlay('gun.enemy.' + _w + '.' + side, vol, rate, undefined, d);
}


function audioPreload(){
  if (typeof Audio !== 'function') return;
  for (const k in AUDIO_FILE){
    if (k.indexOf('gun.enemy.') === 0) continue;   /* 敌人枪声第一声才建池子 */
    try{
      const el = new Audio(AUDIO_DIR + AUDIO_FILE[k]);
      el.preload = 'auto';
      el.addEventListener('error', function(){ AUDIO_MISSING[k] = true; });
      el.load();
      AUDIO_CACHE[k] = el;
      const pool = [el];
      for (let i = 1; i < AUDIO_POOL_N; i++){
        const c = new Audio(AUDIO_DIR + AUDIO_FILE[k]);
        c.preload = 'auto';
        c.addEventListener('error', function(){ AUDIO_MISSING[k] = true; });
        try{ c.load(); }catch (e){}
        pool.push(c);
      }
      AUDIO_POOL[k] = pool;
    } catch (e){ AUDIO_MISSING[k] = true; }
  }
}

function _sndBusy(el){
  return el?.paused === false && !el.ended && !el.error;
}

function _sndActive(){
  let n = 0;
  for (const k in AUDIO_POOL){
    const pool = AUDIO_POOL[k];
    for (let i = 0; i < pool.length; i++) if (_sndBusy(pool[i])) n++;
  }
  return n;
}

/* true 表示已处理（含主动去重），false 让调用方走备用音。 */
function sndPlay(name, vol, rate, onFailure, distance){
  const isEnemy = name.indexOf('gun.enemy.') === 0;
  if (AUDIO_MISSING[name]) return false;
  if (!AUDIO_POOL[name] && isEnemy && !audioPoolMake(name, ENEMY_POOL_N)) return false;
  const pool = AUDIO_POOL[name];
  if (!pool || !pool.length) return false;
  const isGun = name.indexOf('gun.') === 0;
  const gain = (isGun && typeof CFG !== 'undefined' && CFG.gunVol != null)
    ? Math.max(0, Math.min(1, CFG.gunVol / 100)) : 1;
  if (!gain || (typeof audioIsBackground === 'function' && audioIsBackground())) return true;
  const t = sndNow(), last = AUDIO_LAST[name];
  /* 同方向的敌人会共享录音键，敌枪由自己的起音预算控制。 */
  if (audioRateLimit && isGun && !isEnemy && last !== undefined && t >= last && t - last < GUN_MIN_GAP){
    audioDiagBlock('枪声去重', name, distance, 1, 'dedupe');
    return true;
  }
  /* pick a free element instead of a busy one: seeking a playing element
     resets its decoder and can stall the main thread for 10-20ms */
  const cur = (AUDIO_CURSOR[name] || 0) % pool.length;
  let idx = -1;
  for (let k = 0; k < pool.length; k++){
    const ci = (cur + k) % pool.length;
    const e2 = pool[ci];
    if (e2 && !e2.error && !_sndBusy(e2)){ idx = ci; break; }
  }
  /* 敌方密集声可以合并，给本地动作保留录音槽位。录音仍不够时，本地动作走调用方的备用音。 */
  const cap = isEnemy ? MAX_CONCURRENT - AUDIO_LOCAL_RESERVE : MAX_CONCURRENT;
  if (audioRateLimit && (idx < 0 || _sndActive() >= cap)){
    const reason = idx < 0 ? '同音效录音池满' : '录音总池满（上限 ' + cap + '）';
    audioDiagBlock(reason, name, distance, 1, isEnemy ? 'limited' : 'fallback');
    return isEnemy;
  }
  try{
    if (idx < 0){
      // 测试中按需扩池，已有音源的尾音继续自然播放。
      const rel = AUDIO_FILE[name];
      if (!rel || typeof Audio !== 'function') return false;
      idx = pool.length;
      pool.push(new Audio(AUDIO_DIR + rel));
    }
    const el = pool[idx];
    el.volume = Math.max(0, Math.min(1, (vol == null ? 0.7 : vol) * gain));
    el.playbackRate = AUDIO_PITCH[name]
      ? 1 + (Math.random() * 2 - 1) * AUDIO_PITCH_AMT
      : (rate == null ? 1 : rate);
    if (isGun && 'preservesPitch' in el) el.preservesPitch = false;
    if (el.currentTime > 0.02) el.currentTime = 0;
    const p = el.play();
    audioDiagCount('media');
    AUDIO_CURSOR[name] = (idx + 1) % pool.length;
    if (isGun) AUDIO_LAST[name] = t;
    if (p && p.catch) p.catch(() => {
      audioDiagBlock('浏览器拒绝播放', name, distance, 1, 'failed');
      if (isGun && AUDIO_LAST[name] === t) delete AUDIO_LAST[name];
      if (typeof onFailure === 'function' && sndNow() - t < 0.18 &&
          !(typeof audioIsBackground === 'function' && audioIsBackground())) onFailure();
    });
    return true;
  } catch (e){
    audioDiagBlock('录音播放失败', name, distance, 1, 'failed');
    return false;
  }
}

/* \u6709\u6587\u4ef6\u5c31\u7528\u6587\u4ef6\uff0c\u6ca1\u6709\u5c31\u8dd1 fallback\uff08\u539f\u6765\u90a3\u4e2a\u5408\u6210\u97f3\uff09 */
function sndOr(name, vol, fallback){
  if (sndPlay(name, vol, undefined, fallback)) return true;
  if (typeof fallback === 'function') fallback();
  return false;
}

if (typeof window !== 'undefined'){
  if (document.readyState === 'complete') setTimeout(audioPreload, 0);
  else window.addEventListener('load', function(){ setTimeout(audioPreload, 0); });
}
