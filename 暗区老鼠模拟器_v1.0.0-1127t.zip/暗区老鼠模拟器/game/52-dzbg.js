/* ============================================================================
   死亡地带 · 选图界面背景（按难度渐进变惨）
   ----------------------------------------------------------------------------
   以前这一页就是一块纯色（PAL.P258）—— 换个难度只是右上角按钮亮一下，
   背景完全不动，看着像"同一张图换个标签"。

   现在背景是一小片"会随难度恶化"的街景，而且是真的在变：
     困难     —— 雨夜、楼还立着、几盏路灯亮着、天上偶尔一道远处的光
     噩梦     —— 雨渐小、楼开始缺角塌顶、两处起火冒烟、灯开始闪、地面有裂缝
     硬核     —— 大火连片、浓烟蔽日、楼塌成残骸、灯全灭、火星横飞、频繁爆闪

   做法是"参数化"而不是"三张图切换"：楼群、火、烟、雨、火星全部由同一个
   连续量 d（0=困难, 1=噩梦, 2=硬核）驱动，所以换难度是**渐变**过去，
   不会啪一下跳帧。d 由 dzBgTick() 每帧朝目标缓动。

   只在 dzpick 这一页跑，不影响对局性能。
   ============================================================================ */

/* 三档的"天气/光度"参数：只当锚点用，实际取值在它们之间插值 */
const DZ_BG_KEY = [
  { /* 困难 */
    sky:['#0a1218', '#16222e', '#1e2c38'],
    glow:'#2f7f96', glowA:0.10,
    ruin:0.00, fires:0, smoke:0.00, rain:1.00, ember:0.10, cracks:0.00, flash:0.0,
    lampA:0.85
  },
  { /* 噩梦 */
    sky:['#130a0c', '#2a1216', '#3a181a'],
    glow:'#a8402a', glowA:0.20,
    ruin:0.55, fires:2, smoke:0.45, rain:0.55, ember:0.55, cracks:0.45, flash:0.45,
    lampA:0.45
  },
  { /* 硬核 */
    sky:['#170606', '#35110c', '#4d1a0c'],
    glow:'#ff6a2a', glowA:0.30,
    ruin:1.00, fires:4, smoke:1.00, rain:0.12, ember:1.00, cracks:1.00, flash:1.0,
    lampA:0.00
  }
];

const DZ_BG_BUILDINGS = 30, DZ_BG_RAIN = 150, DZ_BG_EMBER = 46, DZ_BG_SMOKE = 14, DZ_BG_CRACK = 7;
const DZ_BG_FIRE_X = [0.18, 0.36, 0.63, 0.82];   /* 起火点（相对宽度） */
const DZ_BG_LAMP_X = [0.12, 0.34, 0.68, 0.88];   /* 路灯位置 */

let dzBgD = 2;          /* 当前连续难度（0..2），开局按已选难度初始化 */
let dzBgD0 = 2;         /* 上一次的起点，用于缓动 */
let dzBgTgt = 2;
let dzBgLastT = -1;
let dzBgFlashAt = 0, dzBgFlashX = 0.5, dzBgFlashY = 0.5;
/* 硬核才有的东西：飞机掠过 + 投弹。
   飞机不是一张贴图，是每帧按速度推过去的一个轮廓；炸弹是真的会掉下来、砸地、炸开。 */
const DZ_BG_PLANES = [];
let dzBgPlaneNext = 3.2;      /* 下一架什么时候出现 */
const DZ_BG_BOMBS = [];


/* 稳定的伪随机：同一个下标永远同一个值，窗口大小变了楼群也不会乱跳 */
function dzbHash(i, salt){
  const s = Math.sin((i + 1) * 12.9898 + (salt || 0) * 78.233) * 43758.5453;
  return s - Math.floor(s);
}

function dzbLerp(a, b, t){ return a + (b - a) * t; }

/* 颜色 → [r,g,b]。两种都吃：'#rrggbb' 和 dzbMix 产出的 'rgb(r,g,b)'
   （之前只认十六进制，而 glow 已经是 dzbMix 的结果，于是 parseInt('gb') 得 NaN，
    渐变 addColorStop 直接抛异常，整页画不出来） */
function dzbRGB(c){
  if (typeof c !== 'string') return c || [0,0,0];
  if (c.charAt(0) === '#'){
    const h = c.slice(1);
    return [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
  }
  const m = c.match(/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
  return m ? [+m[1], +m[2], +m[3]] : [0,0,0];
}
function dzbMix(c1, c2, t){
  const a = typeof c1 === 'string' ? dzbRGB(c1) : c1;
  const b = typeof c2 === 'string' ? dzbRGB(c2) : c2;
  return 'rgb(' + Math.round(dzbLerp(a[0],b[0],t)) + ',' + Math.round(dzbLerp(a[1],b[1],t)) + ',' + Math.round(dzbLerp(a[2],b[2],t)) + ')';
}
function dzbRGBAMix(c1, c2, t, a){
  const A = typeof c1 === 'string' ? dzbRGB(c1) : c1;
  const B = typeof c2 === 'string' ? dzbRGB(c2) : c2;
  return 'rgba(' + Math.round(dzbLerp(A[0],B[0],t)) + ',' + Math.round(dzbLerp(A[1],B[1],t)) + ',' + Math.round(dzbLerp(A[2],B[2],t)) + ',' + a + ')';
}

/* 取某个连续难度 d 下的参数：在 DZ_BG_KEY 之间线性插值 */
function dzbAt(d, fn){
  const i = Math.max(0, Math.min(1, Math.floor(d)));
  const j = Math.min(2, i + 1);
  return fn(DZ_BG_KEY[i], DZ_BG_KEY[j], Math.max(0, Math.min(1, d - i)));
}

/* 每帧缓动：换难度时 d 平滑靠过去；同时驱动"远处爆闪"的节奏 */
function dzBgClock(){ return performance.now() / 1000; }

function dzBgTick(){
  const idx = (typeof DZ_TIERS !== 'undefined' && typeof dzTier === 'string') ? Math.max(0, DZ_TIERS.indexOf(dzTier)) : 2;
  dzBgTgt = idx;
  if (dzBgLastT < 0) dzBgD = dzBgTgt;   /* 第一次进来直接落在当前难度，别从硬核缓过来 */
  const _now = dzBgClock();
  const dt = dzBgLastT < 0 ? 0 : Math.max(0, Math.min(0.05, _now - dzBgLastT));
  dzBgLastT = _now;
  if (dt > 0){
    /* 0.9 秒左右走完，视觉上是"慢慢暗下去/烧起来" */
    const k = 1 - Math.pow(0.001, dt / 0.9);
    dzBgD += (dzBgTgt - dzBgD) * k;
    if (Math.abs(dzBgTgt - dzBgD) < 0.001) dzBgD = dzBgTgt;
  }
  dzBgPlanesTick(dt, dzBgD);

  /* 远处爆闪：间隔随难度缩短（3.4s → 1.1s），只在前 2/3 高度出现 */
  const d = dzBgD;
  const period = 3.4 - 2.3 * (d / 2);
  if (_now - dzBgFlashAt > period){
    dzBgFlashAt = _now;
    dzBgFlashX = 0.08 + dzbHash(Math.floor(_now * 7), 3) * 0.84;
    dzBgFlashY = 0.30 + dzbHash(Math.floor(_now * 5), 9) * 0.28;
  }
}

function drawDzBg(){
  const d = dzBgD;
  const t = dzBgClock();

  ctx.save();
  const impactAge=t-dzBgBoomAt;
  if(d>1.55 && impactAge>=0 && impactAge<.48){
    const decay=Math.pow(1-impactAge/.48,2);
    const motion=decay*H*.015;
    const extra=.04*decay;
    const sx=Math.cos(impactAge*67)*motion,sy=Math.cos(impactAge*84)*motion*.63;
    ctx.translate(sx-W*extra/2,sy-H*extra/2);
    ctx.scale(1+extra,1+extra);
  }

  /* ---------- 1. 天空 ---------- */
  const skyTop = dzbAt(d, (a,b,f)=> dzbMix(a.sky[0], b.sky[0], f));
  const skyMid = dzbAt(d, (a,b,f)=> dzbMix(a.sky[1], b.sky[1], f));
  const skyBot = dzbAt(d, (a,b,f)=> dzbMix(a.sky[2], b.sky[2], f));
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, skyTop);
  g.addColorStop(0.62, skyMid);
  g.addColorStop(1, skyBot);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  /* ---------- 2. 地平线火光（火烧云的底光） ---------- */
  const glow = dzbAt(d, (a,b,f)=> dzbMix(a.glow, b.glow, f));
  const glowA = dzbAt(d, (a,b,f)=> dzbLerp(a.glowA, b.glowA, f));
  const hz = H * 0.60;
  const gr = ctx.createRadialGradient(W * 0.5, hz, 10, W * 0.5, hz, W * 0.52);
  gr.addColorStop(0, dzbRGBAMix(glow, glow, 0, Math.min(0.45, glowA + 0.10)));
  gr.addColorStop(0.55, dzbRGBAMix(glow, glow, 0, glowA * 0.45));
  gr.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = gr;
  ctx.fillRect(0, 0, W, H);

  dzBgDrawPlanes(d);

  /* ---------- 2b. 天空的浓烟：越难越厚，硬核几乎把天压黑 ---------- */
  const cloudK = Math.max(0, (d - 0.35) / 1.65);
  if (cloudK > 0.01){
    for (let i = 0; i < 5; i++){
      const cy = H * (0.04 + i * 0.075) + Math.sin(t * 0.12 + i * 1.7) * 8;
      const cw2 = W * (0.55 + dzbHash(i, 40) * 0.55);
      const ch2 = H * (0.075 + dzbHash(i, 41) * 0.055);
      ctx.fillStyle = 'rgba(12,9,8,' + (0.20 * cloudK * (0.7 + 0.3 * dzbHash(i, 42))).toFixed(3) + ')';
      ctx.beginPath();
      ctx.ellipse(W * (0.1 + dzbHash(i, 43) * 0.8), cy, cw2, ch2, 0, 0, 7);
      ctx.fill();
    }
  }

  /* ---------- 3. 楼群（随难度塌） ---------- */
  const baseY = H * 0.66;
  const bw = W / DZ_BG_BUILDINGS;
  for (let i = 0; i < DZ_BG_BUILDINGS; i++){
    const hx = dzbHash(i, 1), hw = bw * (0.72 + dzbHash(i, 2) * 0.62);
    const h0 = H * (0.09 + hx * 0.17);
    const th = 0.25 + dzbHash(i, 3) * 0.85;            /* 这栋楼"塌"的阈值 */
    const frac = Math.max(0, Math.min(1, (d - th) * 2.0 + 0.5));
    const x = i * bw + (bw - hw) * 0.5;
    const h = h0 * (1 - frac * 0.62);
    if (h < 4){
      /* 塌完了也留一截废墟，高度随楼变，别整排一样高像垛口 */
      const stub = 6 + dzbHash(i, 35) * 24;
      const yj = (dzbHash(i, 36) - 0.5) * 9;
      ctx.fillStyle = dzbRGBAMix('#0d151d', '#1b0d0a', d / 2, 0.85);
      ctx.fillRect(x, baseY - stub + yj, hw, stub);
      continue;
    }

    /* 楼体：越暗越糊（但要比天空亮一点，否则看不出是楼） */
    const bodyA = 0.80 + 0.15 * (1 - d / 2);
    ctx.fillStyle = dzbRGBAMix('#111c28', '#231210', d / 2, bodyA);
    /* 顶面：没塌就是直角；塌了只往下啃 1~2 处缺口，绝不往上凸齿（那是装饰锯齿） */
    const topYb = baseY - h;
    const bites = [];
    if (frac > 0.06){
      const bn = 1 + Math.round(dzbHash(i, 33) * frac);
      let cx = x + hw * (0.12 + dzbHash(i, 31) * 0.16);
      for (let k = 0; k < bn; k++){
        const nwi = hw * (0.14 + dzbHash(i * 11 + k, 32) * 0.20);
        const ndp = h * (0.06 + dzbHash(i * 17 + k, 37) * 0.16) * (0.6 + 0.4 * frac);
        if (cx + nwi > x + hw * 0.94) break;
        bites.push({ x: cx, w: nwi, d: ndp });
        cx += nwi + hw * (0.20 + dzbHash(i * 11 + k, 38) * 0.18);
      }
    }
    if (bites.length === 0){
      ctx.fillRect(x, topYb, hw, h);
    } else {
      ctx.beginPath();
      ctx.moveTo(x, baseY);
      ctx.lineTo(x, topYb);
      for (let k = 0; k < bites.length; k++){
        const bt = bites[k];
        ctx.lineTo(bt.x, topYb);
        ctx.lineTo(bt.x + bt.w * 0.28, topYb + bt.d);
        ctx.lineTo(bt.x + bt.w * 0.7, topYb + bt.d * 0.86);
        ctx.lineTo(bt.x + bt.w, topYb);
      }
      ctx.lineTo(x + hw, topYb);
      ctx.lineTo(x + hw, baseY);
      ctx.closePath();
      ctx.fill();
    }

    /* 顶沿高光：夜里靠这道线才读得出轮廓；烧起来的档换成火的暖光 */
    const rimC = d < 1.0 ? 'rgba(150,196,226,' + (0.16 * (1 - d)).toFixed(3) + ')' : 'rgba(255,150,80,' + (0.22 * (d - 1)).toFixed(3) + ')';
    ctx.fillStyle = rimC;
    let rx0 = x;
    for (let k = 0; k < bites.length; k++){
      const bt = bites[k];
      if (bt.x > rx0 + 1) ctx.fillRect(rx0, topYb, bt.x - rx0, 1.4);
      rx0 = bt.x + bt.w;
    }
    if (x + hw > rx0 + 1) ctx.fillRect(rx0, topYb, x + hw - rx0, 1.4);

    /* 窗户：困难时亮一点，越往后越黑（停电 + 烧掉） */
    const winA = Math.max(0, 0.32 * (1 - 0.72 * (d / 2)) * (1 - frac)) * (0.55 + 0.45 * Math.sin(t * 0.7 + i));
    if (winA > 0.02){
      ctx.fillStyle = 'rgba(255,206,120,' + winA.toFixed(3) + ')';
      const rows = Math.max(1, Math.floor(h / 14));
      for (let r = 0; r < rows; r++){
        for (let c = 0; c < 3; c++){
          if (dzbHash(i * 31 + r * 7 + c, 5) < 0.42) continue;
          ctx.fillRect(x + 5 + c * (hw - 12) / 3, baseY - h + 8 + r * 14, 4, 5);
        }
      }
    }
  }

  /* ---------- 3b. 残梁 / 断墙：越难越多的斜插结构 ---------- */
  if (d > 0.32){
    const beams = Math.round(3 + 6 * (d / 2));
    ctx.strokeStyle = 'rgba(22,16,14,' + (0.55 + 0.30 * (d / 2)).toFixed(3) + ')';
    ctx.lineWidth = 3;
    for (let i = 0; i < beams; i++){
      const bx = W * (0.05 + dzbHash(i, 30) * 0.90);
      const bh = H * (0.04 + dzbHash(i, 31) * 0.08) * (0.45 + 0.55 * (d / 2));
      const lean = (dzbHash(i, 32) - 0.5) * 0.9;
      ctx.beginPath();
      ctx.moveTo(bx, baseY);
      ctx.lineTo(bx + lean * bh, baseY - bh);
      ctx.stroke();
      /* 断口上还亮着一点火 */
      if (dzbHash(i, 33) < 0.45 * (d / 2)){
        ctx.fillStyle = 'rgba(255,140,60,' + (0.35 * (d / 2)).toFixed(3) + ')';
        ctx.fillRect(bx + lean * bh - 1.2, baseY - bh - 1.2, 2.4, 2.4);
      }
    }
  }

  /* ---------- 3c. 塌掉的楼：矮下去 + 断口朝天 + 露柱 + 碎石场 + 贴地尘云 ---------- */
  const collapseK = Math.max(0, Math.min(1, (d - 1.2) / 0.8));
  if (collapseK > 0.02){
    /* 位置避开四个起火点，免得和火光糊在一起 */
    const DZ_BG_FALL_X = [0.16, 0.84, 0.30, 0.70];
    const fallCount = 1 + Math.round(collapseK);
    const skinS = dzbRGBAMix('#111c28', '#231210', d / 2, 0.80 + 0.15 * (1 - d / 2));
    const rimS = d < 1 ? 'rgba(150,196,226,0.09)' : 'rgba(255,150,80,0.12)';
    const colS = dzbRGBAMix('#0b1420', '#1d100c', d / 2, 0.78);
    const rubS = dzbRGBAMix('#22303e', '#3a2018', d / 2, (0.80 + 0.15 * collapseK).toFixed(3));
    const dustS = dzbRGBAMix('#191412', '#2a1813', d / 2, (0.14 + 0.10 * collapseK).toFixed(3));
    for (let i = 0; i < fallCount; i++){
      const fx = W * DZ_BG_FALL_X[i % DZ_BG_FALL_X.length] + (dzbHash(i, 60) - 0.5) * W * 0.05;
      const bw = W * (0.034 + dzbHash(i, 63) * 0.016);            /* 楼宽：和普通楼同量级 */
      const hUp = H * (0.075 + dzbHash(i, 62) * 0.035) * (0.85 + 0.15 * collapseK);  /* 塌掉一半：要高出地面火光带，否则崩口里全是亮的 */

      /* 1) 还立着的矮残段：上沿大体平，2~3 处崩口 —— 不是等宽锯齿 */
      const notches = [];
      const nN = 2 + Math.round(dzbHash(i, 71) * 1.2);
      let curX = fx - bw * 0.50;
      for (let k = 0; k < nN; k++){
        const gap = bw * (0.06 + dzbHash(i * 13 + k, 72) * 0.16);
        const nw = bw * (0.10 + dzbHash(i * 13 + k, 73) * 0.18);
        let nd = H * (0.012 + dzbHash(i * 13 + k, 74) * 0.040) * (0.6 + 0.4 * collapseK);
        if (k === 0) nd *= 1.5;
        curX += gap;
        if (curX + nw > fx + bw * 0.46) break;
        notches.push({ x: curX, w: nw, d: nd });
        curX += nw;
      }
      const topY = baseY - hUp;
      const jit = H * 0.0018;
      const tilt = (dzbHash(i, 75) - 0.5) * hUp * 0.30;   /* 断口整体微斜，避免像垛口 */
      ctx.fillStyle = skinS;
      ctx.beginPath();
      ctx.moveTo(fx - bw * 0.50, baseY);
      const topAt = (x) => topY + tilt * ((x - fx) / (bw * 0.5)) - dzbHash(i, 68) * jit;
      ctx.lineTo(fx - bw * 0.50, topAt(fx - bw * 0.50));
      for (let k = 0; k < notches.length; k++){
        const nt = notches[k];
        ctx.lineTo(nt.x, topAt(nt.x) - dzbHash(i * 7 + k, 69) * jit);
        const b0 = topAt(nt.x);
        ctx.lineTo(nt.x + nt.w * 0.22, b0 + nt.d);
        ctx.lineTo(nt.x + nt.w * 0.62, b0 + nt.d * 0.92);
        ctx.lineTo(nt.x + nt.w, b0 + nt.d * 0.12);
      }
      ctx.lineTo(fx + bw * 0.50, topAt(fx + bw * 0.50));
      ctx.lineTo(fx + bw * 0.50, baseY);
      ctx.closePath();
      ctx.fill();

      /* 断口内壁：只在崩口里压暗，平的那段保持楼体色 */
      ctx.fillStyle = colS;
      for (let k = 0; k < notches.length; k++){
        const nt = notches[k];
        ctx.beginPath();
        const w0 = topAt(nt.x), w1 = topAt(nt.x + nt.w);
        ctx.moveTo(nt.x, w0);
        ctx.lineTo(nt.x + nt.w * 0.22, w0 + nt.d);
        ctx.lineTo(nt.x + nt.w * 0.62, w0 + nt.d * 0.92);
        ctx.lineTo(nt.x + nt.w, w1 + nt.d * 0.12);
        ctx.lineTo(nt.x + nt.w, w1 + nt.d * 0.12 + H * 0.006);
        ctx.lineTo(nt.x + nt.w * 0.62, w0 + nt.d * 0.92 + H * 0.006);
        ctx.lineTo(nt.x + nt.w * 0.22, w0 + nt.d + H * 0.006);
        ctx.lineTo(nt.x, w0 + H * 0.006);
        ctx.closePath();
        ctx.fill();
      }

      /* 顶沿微光只描"没崩的面"，崩口里不描 —— 否则整条边像山脊雪线 */
      ctx.strokeStyle = rimS; ctx.lineWidth = 1;
      let seg0 = fx - bw * 0.50;
      for (let k = 0; k <= notches.length; k++){
        const seg1 = k < notches.length ? notches[k].x : fx + bw * 0.50;
        if (seg1 > seg0 + 1){
          ctx.beginPath();
          ctx.moveTo(seg0, topAt(seg0)); ctx.lineTo(seg1, topAt(seg1));
          ctx.stroke();
        }
        if (k < notches.length) seg0 = notches[k].x + notches[k].w;
      }

      /* 2) 崩口里戳出来的钢筋头：细、略歪，两段折线 */
      ctx.strokeStyle = 'rgba(146,132,116,0.55)'; ctx.lineWidth = 1;
      for (let k = 0; k < Math.min(2, notches.length); k++){
        const nt = notches[k];
        const bx = nt.x + nt.w * (0.35 + dzbHash(i * 19 + k, 75) * 0.3);
        const by = topY + nt.d * 0.55;
        const l1 = H * (0.007 + dzbHash(i * 19 + k, 76) * 0.006);
        const tilt = (dzbHash(i * 19 + k, 77) - 0.5) * H * 0.006;
        ctx.beginPath();
        ctx.moveTo(bx, by);
        ctx.lineTo(bx + tilt, by - l1);
        ctx.lineTo(bx + tilt * 1.6, by - l1 * 1.9);
        ctx.stroke();
      }

      /* 3) 碎石场：以断口为中心往两侧铺开，越远越细碎 */
      const rubN = 16 + Math.round(12 * collapseK);
      for (let k = 0; k < rubN; k++){
        const u = dzbHash(i * 23 + k, 76);
        const side = dzbHash(i * 23 + k, 77) < 0.5 ? -1 : 1;
        const dist = Math.pow(u, 1.5) * W * 0.16;      /* 越远越稀 */
        const dw = W * (0.013 - 0.007 * u) * (0.55 + 0.45 * collapseK);
        const dh = dw * (0.8 + dzbHash(i * 23 + k, 78) * 1.7);
        ctx.fillStyle = rubS;
        ctx.fillRect(fx + side * dist, baseY - dh, dw, dh);
      }
      /* 几块平躺的楼板残片 */
      ctx.fillStyle = rubS;
      for (let k = 0; k < 3; k++){
        const side = dzbHash(i * 31 + k, 79) < 0.5 ? -1 : 1;
        const dist = bw * (0.55 + dzbHash(i * 31 + k, 80) * 1.1);
        const dw = W * (0.030 + dzbHash(i * 31 + k, 81) * 0.028);
        const dhh = Math.max(1.6, H * (0.008 + dzbHash(i * 31 + k, 85) * 0.006));
        ctx.fillRect(fx + side * dist, baseY - dhh, dw, dhh);
        ctx.fillRect(fx + side * dist, baseY - dhh - Math.max(1, H * 0.002), dw, Math.max(1, H * 0.002));
      }

      /* 4) 贴地低矮尘云：塌方特有的那层灰 */
      ctx.fillStyle = dustS;
      for (let k = 0; k < 3; k++){
        const side = k === 0 ? 0 : (k === 1 ? -1 : 1);
        const dx = fx + side * bw * (0.35 + dzbHash(i * 37 + k, 82) * 0.85);
        const rx = bw * (0.95 + dzbHash(i * 37 + k, 83) * 0.85);
        ctx.beginPath();
        ctx.ellipse(dx, baseY - H * 0.005, rx, H * (0.012 + dzbHash(i * 37 + k, 84) * 0.010), 0, 0, 7);
        ctx.fill();
      }
    }
  }

  /* ---------- 4. 起火点：火苗 + 烟柱 ---------- */
  const fires = dzbAt(d, (a,b,f)=> dzbLerp(a.fires, b.fires, f));
  for (let i = 0; i < DZ_BG_FIRE_X.length; i++){
    const a = Math.max(0, Math.min(1, fires - i));
    if (a <= 0.02) continue;
    const fx = W * DZ_BG_FIRE_X[i] + Math.sin(t * 0.5 + i) * 10;
    const fy = baseY - H * (0.02 + dzbHash(i, 6) * 0.06);

    /* 火光：半径固定，只让亮度跳，避免一伸一缩 */
    const rr = H * 0.17;
    const fg = ctx.createRadialGradient(fx, fy, 2, fx, fy, rr);
    const flick = 0.78 + 0.12 * Math.sin(t * 9.3 + i * 1.7) + 0.08 * Math.sin(t * 23.1 + i);
    fg.addColorStop(0, 'rgba(255,205,110,' + (0.78 * a * flick).toFixed(3) + ')');
    fg.addColorStop(0.35, 'rgba(255,120,45,' + (0.40 * a * flick).toFixed(3) + ')');
    fg.addColorStop(1, 'rgba(120,20,0,0)');
    ctx.fillStyle = fg;
    ctx.beginPath(); ctx.arc(fx, fy, rr, 0, 7); ctx.fill();

    /* 地上的一小片反光：固定大小 */
    ctx.fillStyle = 'rgba(255,120,40,' + (0.10 * a * flick).toFixed(3) + ')';
    ctx.beginPath(); ctx.ellipse(fx, baseY + 4, H * 0.20, H * 0.016, 0, 0, 7); ctx.fill();

    /* 烟柱：往上飘、变淡变宽 */
    const smokeA = dzbAt(d, (x,y,f)=> dzbLerp(x.smoke, y.smoke, f));
    for (let k = 0; k < 4; k++){
      const ph = (t * (0.10 + k * 0.015) + k * 0.25 + i * 0.13) % 1;
      const sy = fy - ph * H * 0.34;
      const sr = H * (0.045 + ph * 0.075);
      ctx.fillStyle = 'rgba(26,22,20,' + (0.26 * a * smokeA * (1 - ph) * (1 - ph)).toFixed(3) + ')';
      ctx.beginPath(); ctx.ellipse(fx + Math.sin(ph * 5 + i) * 14, sy, sr, sr * 0.66, 0, 0, 7); ctx.fill();
    }
  }

  /* ---------- 5. 全局浓烟（越难越闷） ---------- */
  const smokeA = dzbAt(d, (a,b,f)=> dzbLerp(a.smoke, b.smoke, f));
  if (smokeA > 0.01){
    for (let i = 0; i < DZ_BG_SMOKE; i++){
      const ph = (t * 0.035 + i / DZ_BG_SMOKE) % 1;
      const x = W * (dzbHash(i, 7) * 1.1 - 0.05) + Math.sin(t * 0.2 + i) * 30;
      const y = H * (0.72 - ph * 0.62);
      const r = H * (0.16 + dzbHash(i, 8) * 0.20);
      ctx.fillStyle = 'rgba(20,16,15,' + (0.085 * smokeA).toFixed(3) + ')';
      ctx.beginPath(); ctx.ellipse(x, y, r, r * 0.55, 0, 0, 7); ctx.fill();
    }
  }

  /* ---------- 6. 地面裂缝（只在更难的档出现） ---------- */
  const crackA = dzbAt(d, (a,b,f)=> dzbLerp(a.cracks, b.cracks, f));
  if (crackA > 0.02){
    ctx.strokeStyle = 'rgba(255,120,50,' + (0.13 * crackA).toFixed(3) + ')';
    ctx.lineWidth = 1.6;
    for (let i = 0; i < DZ_BG_CRACK; i++){
      const x0 = W * (0.05 + dzbHash(i, 10) * 0.9);
      ctx.beginPath();
      ctx.moveTo(x0, H);
      let cx = x0, cy = H;
      for (let k = 0; k < 6; k++){
        cx += (dzbHash(i * 13 + k, 11) - 0.5) * 46;
        cy -= H * 0.02 + dzbHash(i * 7 + k, 12) * H * 0.02;
        ctx.lineTo(cx, cy);
      }
      ctx.stroke();
    }
  }

  /* ---------- 7. 雨（困难最密，硬核几乎没有） ---------- */
  const rainA = dzbAt(d, (a,b,f)=> dzbLerp(a.rain, b.rain, f));
  if (rainA > 0.02){
    ctx.strokeStyle = 'rgba(150,190,220,' + (0.10 * rainA).toFixed(3) + ')';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i < DZ_BG_RAIN; i++){
      const sx = (dzbHash(i, 13) * W + t * 120 * (0.5 + dzbHash(i, 14))) % (W + 40) - 20;
      const sy = (dzbHash(i, 15) * H + t * 900 * (0.6 + dzbHash(i, 16) * 0.8)) % (H + 60) - 30;
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx - 4, sy + 16);
    }
    ctx.stroke();
  }

  /* ---------- 8. 火星（越难越多，往上飘） ---------- */
  const emberA = dzbAt(d, (a,b,f)=> dzbLerp(a.ember, b.ember, f));
  if (emberA > 0.02){
    for (let i = 0; i < DZ_BG_EMBER; i++){
      const sp = 26 + dzbHash(i, 17) * 58;
      const px = (dzbHash(i, 18) * W + Math.sin(t * 0.9 + i) * 24 + W) % W;
      const py = H - ((t * sp + dzbHash(i, 19) * H * 1.2) % (H * 1.2));
      const a = (0.25 + 0.55 * dzbHash(i, 20)) * emberA * (0.55 + 0.45 * Math.sin(t * 6 + i * 2));
      if (a <= 0.02) continue;
      ctx.fillStyle = 'rgba(255,' + (140 + Math.round(70 * dzbHash(i, 21))) + ',60,' + a.toFixed(3) + ')';
      const r = 0.8 + dzbHash(i, 22) * 1.5;
      ctx.fillRect(px, py, r, r);
    }
  }

  /* ---------- 9. 路灯（困难亮着，噩梦闪，硬核全灭） ---------- */
  const lampA = dzbAt(d, (a,b,f)=> dzbLerp(a.lampA, b.lampA, f));
  for (let i = 0; i < DZ_BG_LAMP_X.length; i++){
    const own = Math.max(0, Math.min(1, lampA - i * 0.16));      /* 一盏一盏灭 */
    if (own <= 0.03) continue;
    const on = 0.72 + 0.28 * Math.sin(t * (2.4 + i) + i * 3);    /* 接触不良的闪 */
    const lx = W * DZ_BG_LAMP_X[i], ly = baseY - H * 0.13;
    const lg = ctx.createRadialGradient(lx, ly, 2, lx, ly, H * 0.16);
    lg.addColorStop(0, 'rgba(255,226,160,' + (0.30 * own * on).toFixed(3) + ')');
    lg.addColorStop(1, 'rgba(255,200,120,0)');
    ctx.fillStyle = lg;
    ctx.beginPath(); ctx.arc(lx, ly, H * 0.16, 0, 7); ctx.fill();
    ctx.fillStyle = 'rgba(255,240,200,' + (0.75 * own * on).toFixed(3) + ')';
    ctx.fillRect(lx - 1.5, ly - 1.5, 3, 3);
    ctx.strokeStyle = 'rgba(120,130,140,' + (0.30 * own).toFixed(3) + ')';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(lx, ly + 3); ctx.lineTo(lx, baseY); ctx.stroke();
  }

  /* ---------- 10. 远处爆闪 ---------- */
  const flashK = dzbAt(d, (a,b,f)=> dzbLerp(a.flash, b.flash, f));
  if (flashK > 0.05){
    const age = dzBgClock() - dzBgFlashAt;
    if (age >= 0 && age < 0.55){
      const k = Math.pow(1 - age / 0.55, 2) * flashK;
      const fx = W * dzBgFlashX, fy = H * dzBgFlashY;
      const rg = ctx.createRadialGradient(fx, fy, 4, fx, fy, H * 0.42);
      rg.addColorStop(0, 'rgba(255,235,200,' + (0.55 * k).toFixed(3) + ')');
      rg.addColorStop(0.3, 'rgba(255,140,60,' + (0.24 * k).toFixed(3) + ')');
      rg.addColorStop(1, 'rgba(255,80,20,0)');
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, W, H);
    }
  }

  /* ---------- 10b. 爆点照亮远景 ---------- */
  dzBgDrawImpact(d,t);

  /* ---------- 11. 压暗：保证上面的字看得清 ---------- */
  const vg = ctx.createLinearGradient(0, 0, 0, H);
  vg.addColorStop(0, 'rgba(0,0,0,0.42)');
  vg.addColorStop(0.28, 'rgba(0,0,0,0.10)');
  vg.addColorStop(0.55, 'rgba(0,0,0,0.16)');
  vg.addColorStop(1, 'rgba(0,0,0,0.58)');
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);

  /* 中心再压一层，卡片和标题才不糊 */
  const cg = ctx.createRadialGradient(W * 0.5, H * 0.45, H * 0.12, W * 0.5, H * 0.45, H * 0.78);
  cg.addColorStop(0, 'rgba(0,0,0,0.20)');
  cg.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = cg;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}

/* ============================================================================
   飞机 / 投弹（硬核专属）
   ----------------------------------------------------------------------------
   出现条件：d >= 1.55（从噩梦后半段开始偶尔来一架，硬核固定有）。
   飞机从一侧飞进、另一侧飞出；飞到画面中段时投一颗炸弹，炸弹带一点前抛速度、
   边落边加速，砸地后：白闪 + 火球 + 冲击环 + 烟柱，并且喊一声远处爆炸（和背景音效联动）。
   ============================================================================ */
let dzBgBoomAt = -9, dzBgBoomX = 0.5, dzBgBoomY = 0.6;

function dzBgPlanesTick(dt, d){
  if (dt <= 0) return;
  const wantK = Math.max(0, (d - 1.55) / 0.45);   /* 0 → 1，硬核为 1 */

  /* 生成 */
  dzBgPlaneNext -= dt;
  if (wantK > 0.01 && dzBgPlaneNext <= 0 && DZ_BG_PLANES.length < 2){
    const dir = dzbHash(Math.floor(dzBgClock() * 13), 51) < 0.5 ? 1 : -1;
    DZ_BG_PLANES.push({
      x: dir > 0 ? -W * 0.18 : W * 1.18,
      y: H * (0.10 + dzbHash(Math.floor(dzBgClock() * 7), 52) * 0.09),
      dir: dir,
      spd: W * (0.085 + dzbHash(Math.floor(dzBgClock() * 5), 53) * 0.05),
      dropped: false,
      blink: 0
    });
    dzBgPlaneNext = (9.0 + dzbHash(Math.floor(dzBgClock() * 11), 55) * 7.0) / wantK;
  }

  /* 推进 + 投弹 */
  for (let i = DZ_BG_PLANES.length - 1; i >= 0; i--){
    const pl = DZ_BG_PLANES[i];
    pl.x += pl.spd * pl.dir * dt;
    pl.blink += dt;
    if (pl.lift > 0) pl.lift = Math.max(0, pl.lift - dt * 2.2);
    const crossK = pl.dir > 0 ? (pl.x / W) : (1 - pl.x / W);
    if (!pl.dropped && crossK > 0.34 && crossK < 0.66){
      pl.dropped = true;
      pl.lift = 1;
      DZ_BG_BOMBS.push({ x: pl.x, y: pl.y + H * 0.012, ox: pl.x, oy: pl.y + H * 0.012, vx: pl.spd * pl.dir * 0.12, vy: H * 0.06 });
    }
    if (pl.x < -W * 0.25 || pl.x > W * 1.25) DZ_BG_PLANES.splice(i, 1);
  }

  /* 炸弹 */
  for (let i = DZ_BG_BOMBS.length - 1; i >= 0; i--){
    const b = DZ_BG_BOMBS[i];
    b.x += b.vx * dt;
    b.vy += H * 0.55 * dt;            /* 越掉越快 */
    b.y += b.vy * dt;
    const groundY = H * 0.60;
    if (b.y >= groundY){
      dzBgBoomAt = dzBgClock();
      dzBgBoomX = b.x / W;
      dzBgBoomY = groundY / H;
      if (typeof dzAStart === 'function' && typeof dzABoom === 'function'){
        const audio=dzAStart();
        if(audio){
          dzABoom(audio,.82,true);
          audio.nextBoom=Math.max(audio.nextBoom,audio.t+1.3);
        }
      }
      DZ_BG_BOMBS.splice(i, 1);
    }
  }
  if (DZ_BG_BOMBS.length > 6) DZ_BG_BOMBS.splice(0, DZ_BG_BOMBS.length - 6);
}

function dzFlightPoly(fill,points){
  ctx.fillStyle=fill;ctx.beginPath();ctx.moveTo(points[0],points[1]);
  for(let i=2;i<points.length;i+=2)ctx.lineTo(points[i],points[i+1]);
  ctx.closePath();ctx.fill();
}

function dzBgDrawPlanes(d){
  const wantK = Math.max(0, Math.min(1, (d - 1.55) / 0.45));
  if (wantK <= 0.01) return;
  const a = Math.sqrt(wantK);

  // 下落剪影随速度俯转，尾迹渐隐，弹体有金属亮边和尾翼。
  for (const b of DZ_BG_BOMBS){
    const u = Math.max(4, H * 0.008);
    const angle = Math.atan2(b.vy, b.vx);

    /* 投弹轨迹：从飞机投下那一点连到弹体，越往下越淡，读起来才像扔下来的 */
    const ox = (typeof b.ox === 'number') ? b.ox : b.x, oy = (typeof b.oy === 'number') ? b.oy : b.y;
    const tg = ctx.createLinearGradient(ox, oy, b.x, b.y);
    tg.addColorStop(0, 'rgba(58,54,52,0)');
    tg.addColorStop(0.55, 'rgba(46,42,40,' + (0.16 * a).toFixed(3) + ')');
    tg.addColorStop(1, 'rgba(32,29,28,' + (0.30 * a).toFixed(3) + ')');
    ctx.save();
    ctx.strokeStyle = tg; ctx.lineWidth = u * 0.26; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.restore();

    /* 弹体：整根黑，只有一点冷调高光 */
    ctx.save();
    ctx.translate(b.x, b.y); ctx.rotate(angle); ctx.scale(u, u);
    ctx.globalAlpha *= a;
    dzFlightPoly('#0b0b0d', [-2.05, -0.16, -2.45, -0.42, -2.45, 0.42, -2.05, 0.16]);
    const bodyGrad = ctx.createLinearGradient(0, -0.62, 0, 0.62);
    bodyGrad.addColorStop(0, '#1a1a1e');
    bodyGrad.addColorStop(0.45, '#0d0d10');
    bodyGrad.addColorStop(1, '#050507');
    ctx.fillStyle = bodyGrad;
    ctx.beginPath(); ctx.ellipse(0, 0, 2.0, 0.60, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(126,132,140,0.16)';
    ctx.lineWidth = 0.06;
    ctx.beginPath(); ctx.ellipse(0, -0.28, 1.9, 0.30, 0, 0, Math.PI * 2); ctx.stroke();
    /* 尾翼 */
    dzFlightPoly('#0a0a0c', [-1.55, -0.10, -1.95, -0.46, -2.08, -0.40, -1.90, -0.06]);
    dzFlightPoly('#0a0a0c', [-1.55, 0.10, -1.95, 0.46, -2.08, 0.40, -1.90, 0.06]);
    ctx.restore();
  }

  for (const pl of DZ_BG_PLANES){
    const s = H * 0.055;                 /* 按"在天上、在楼后"的层次缩小，别再跟楼一样大 */
    ctx.save();
    ctx.translate(pl.x, pl.y - (pl.lift || 0) * H * 0.004); ctx.scale(s * pl.dir, s * 0.86);
    ctx.globalAlpha *= a * 0.62;         /* 远，就淡：雾化一层，别抢楼群的视觉重量 */

    /* 速度感只留一条极淡的横痕（原来的渐变尾流+双尾迹细节太多了） */
    ctx.strokeStyle = 'rgba(190,184,178,0.07)';
    ctx.lineWidth = 0.05;
    ctx.beginPath();
    ctx.moveTo(-0.80, 0);
    ctx.lineTo(-2.30, 0.03);
    ctx.stroke();

    /* 机身与机翼：跟远处的楼群同一套画法 —— 扁平剪影 + 一道顶沿微光 */
    const skin = dzbRGBAMix('#131a22', '#20120e', d / 2, 0.97);   /* 提亮一点：暗红天上要能看出是金属 */
    /* 主翼：明显后掠 */
    for (const n of [-1, 1]){
      dzFlightPoly(skin, [0.34, 0.03 * n, -0.22, 0.55 * n, -0.58, 0.50 * n, -0.34, 0.10 * n]);
    }
    /* 机身 */
    dzFlightPoly(skin, [1.14, 0, 0.66, -0.10, 0.12, -0.145, -0.58, -0.19, -0.98, -0.155, -1.00, 0.155, -0.58, 0.19, 0.12, 0.145, 0.66, 0.10]);
    /* 垂直尾翼 / 水平尾翼 */
    dzFlightPoly(skin, [-0.58, -0.02, -0.88, -0.34, -1.00, -0.32, -0.92, -0.01]);
    for (const n of [-1, 1]){
      dzFlightPoly(skin, [-0.66, 0.02 * n, -1.02, 0.26 * n, -1.10, 0.22 * n, -0.86, 0.04 * n]);
    }
    /* 顶沿微光：和楼群一样，只在背光侧留一条极细的亮边 */
    ctx.strokeStyle = d < 1 ? 'rgba(150,196,226,0.34)' : 'rgba(255,150,80,0.36)';   /* 和楼群顶沿同规格 */
    ctx.lineWidth = 1 / (s * 0.86);
    ctx.lineWidth = 0.030;
    ctx.beginPath();
    ctx.moveTo(1.12, -0.01); ctx.lineTo(0.12, -0.135); ctx.lineTo(-0.58, -0.175); ctx.lineTo(-0.98, -0.140);
    ctx.stroke();
    /* 机腹压一条暗边，剪影才有金属厚度 */
    ctx.strokeStyle = 'rgba(4,6,9,0.55)';
    ctx.lineWidth = 0.034;
    ctx.beginPath();
    ctx.moveTo(1.10, 0.015); ctx.lineTo(0.14, 0.140); ctx.lineTo(-0.58, 0.182); ctx.lineTo(-0.98, 0.150);
    ctx.stroke();
    /* 尾喷口一个小暖点：和远处楼里的窗灯同色，夜里才认得出这是活的 */
    ctx.fillStyle = 'rgba(255,206,120,' + (0.34 * a).toFixed(3) + ')';
    ctx.fillRect(-1.04, -0.028, 0.11, 0.056);

    ctx.restore();
  }
}

function dzBgDrawImpact(d,t){
  if(d<=1.55)return;
  /* 短促全景反光、贴地扬尘和弹着冲击环。 */
  const age=t-dzBgBoomAt;
  if(age>=0 && age<.23){
    ctx.fillStyle='rgba(255,189,120,'+(.30*Math.pow(1-age/.23,2))+')';
    ctx.fillRect(0,0,W,H);
  }
  if (age >= 0 && age < 1.5){
    const fx = W * dzBgBoomX, fy = H * dzBgBoomY;
    const k = Math.max(0, 1 - age / 1.5);
    if (age < 0.14){
      const wk = 1 - age / 0.14;
      const rg = ctx.createRadialGradient(fx, fy, 2, fx, fy, H * 0.20);
      rg.addColorStop(0, 'rgba(255,250,235,' + (0.85 * wk).toFixed(3) + ')');
      rg.addColorStop(0.45, 'rgba(255,190,120,' + (0.40 * wk).toFixed(3) + ')');
      rg.addColorStop(1, 'rgba(255,120,40,0)');
      ctx.fillStyle = rg;
      ctx.fillRect(fx - H * 0.2, fy - H * 0.2, H * 0.4, H * 0.4);
    }
    const fr = H * (0.055 + 0.105 * (1 - k));
    const fg = ctx.createRadialGradient(fx, fy, fr * 0.15, fx, fy, fr);
    fg.addColorStop(0, 'rgba(255,244,214,' + (0.92 * k).toFixed(3) + ')');
    fg.addColorStop(0.5, 'rgba(255,146,54,' + (0.70 * k).toFixed(3) + ')');
    fg.addColorStop(1, 'rgba(120,40,10,0)');
    ctx.fillStyle = fg;
    ctx.beginPath(); ctx.arc(fx, fy, fr, 0, 7); ctx.fill();
    const rr = H * (0.04 + 0.46 * (1 - k));
    ctx.strokeStyle = 'rgba(255,214,164,' + (0.60 * k).toFixed(3) + ')';
    ctx.lineWidth = Math.max(1, H * 0.0026 * k);
    ctx.beginPath(); ctx.ellipse(fx, fy, rr, rr * 0.28, 0, 0, 7); ctx.stroke();
    for (let i = 0; i < 5; i++){
      const sk = k * (1 - i * 0.14);
      if (sk <= 0) continue;
      const sy = fy - H * (0.02 + i * 0.035) - age * H * 0.03;
      const sr = H * (0.020 + i * 0.012) * (0.7 + age);
      ctx.fillStyle = 'rgba(30,26,24,' + (0.16 * sk).toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(fx + Math.sin(age * 2 + i) * H * 0.006, sy, sr, 0, 7); ctx.fill();
    }
  }
}
