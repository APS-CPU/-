/* 局部矩形 → 地图坐标。rot 只认 0 / 90 / 180 / 270（顺时针）。 */
function roomTplRect(base, tw, th, b, rot){
  const r = ((rot % 360) + 360) % 360;
  if (r === 90)  return { x: base.x + (th - b.y - b.h), y: base.y + b.x,           w: b.h, h: b.w };
  if (r === 180) return { x: base.x + (tw - b.x - b.w), y: base.y + (th - b.y - b.h), w: b.w, h: b.h };
  if (r === 270) return { x: base.x + b.y,              y: base.y + (tw - b.x - b.w), w: b.h, h: b.w };
  return { x: base.x + b.x, y: base.y + b.y, w: b.w, h: b.h };
}

/* 箱型名 → covers.js 里的类型名（mixed→lootcrate，其余 crateXxx）
   m35424：armor 没有 crateArmor 这个掩体定义，按老写法会退化成 COVER_DEF.wall
   —— 一个 90×90、不能搜刮的灰水泥块（庄园主楼里那块）。护甲本来就从军械箱出，
   所以这里把 armor 映射到 gear，保证「模板写出来的箱子一定是真箱子」。 */
const LOOT_CRATE_KIND_ALIAS = { mixed: 'lootcrate', armor: 'crateGear' };
function LOOT_CRATE_KIND_TYPE(k){
  if (LOOT_CRATE_KIND_ALIAS[k]) return LOOT_CRATE_KIND_ALIAS[k];
  return 'crate' + k.charAt(0).toUpperCase() + k.slice(1);
}

/* 一个模板 → 一整套可以直接并进关卡的几何（纯函数，不动全局）。 */
function roomTplBuild(id, x, y, rot){
  const T = ROOM_TEMPLATES[id];
  if (!T) return null;
  const base = { x: x || 0, y: y || 0 };
  const R = rot || 0;
  const mk = b => roomTplRect(base, T.w, T.h, b, R);
  const walls = [], doors = [], roofs = [], rooms = [], decors = [], crates = [], glass = [];
  const t = T.t;

  /* ---- 四面外墙。开门那一面拆成两截，中间留门洞 ---- */
  const d = T.door || {};
  const dw = d.width || 64;
  const edges = {
    north: { x: 0, y: 0, w: T.w, h: t },
    south: { x: 0, y: T.h - t, w: T.w, h: t },
    west:  { x: 0, y: t, w: t, h: T.h - t * 2 },
    east:  { x: T.w - t, y: t, w: t, h: T.h - t * 2 }
  };
  for (const side of Object.keys(edges)){
    const e = edges[side];
    const horiz = (side === 'north' || side === 'south');
    const span = horiz ? T.w : (T.h - t * 2);
    const at = Math.round((span - dw) * Math.max(0, Math.min(1, d.at == null ? 0.5 : d.at)));

    /* 这一面墙上的"洞"：门洞 + 若干窗洞，按位置排好，中间填墙 */
    const gaps = [];
    if (side === d.side) gaps.push({ a: at, b: at + dw, door: true });
    for (const o of (T.windows || [])){
      if (o.side !== side) continue;
      const ww = Math.max(48, o.w || 96);
      const g0 = Math.round((span - ww) * Math.max(0, Math.min(1, o.at == null ? 0.5 : o.at)));
      gaps.push({ a: g0, b: Math.min(span, g0 + ww), win: true });
    }
    gaps.sort((p, q) => p.a - q.a);

    const wallSeg = (a, b) => {
      if (b - a < 1) return;
      const box = horiz ? { x: e.x + a, y: e.y, w: b - a, h: e.h }
                        : { x: e.x, y: e.y + a, w: e.w, h: b - a };
      const r = mk(box);
      walls.push({ x: r.x, y: r.y, w: r.w, h: r.h, mat: T.mat });
    };

    let cur = 0;
    for (const g of gaps){
      const a = Math.max(0, Math.min(span, g.a));
      const b = Math.max(a, Math.min(span, g.b));
      wallSeg(cur, a);
      if (g.door){
        const dr = horiz ? mk({ x: e.x + a, y: e.y, w: b - a, h: t })
                         : mk({ x: e.x, y: e.y + a, w: t, h: b - a });
        doors.push({ t: 'doorSwing', x: dr.x, y: dr.y, w: dr.w, h: dr.h, manual: true, skin: d.skin || 'wood' });
      } else if (g.win){
        /* 玻璃：占满墙厚，和墙同高 —— 一枪就碎，碎了可以翻窗 */
        const gr = horiz ? mk({ x: e.x + a, y: e.y, w: b - a, h: t })
                         : mk({ x: e.x, y: e.y + a, w: t, h: b - a });
        glass.push({ x: gr.x, y: gr.y, w: gr.w, h: gr.h });
      }
      cur = Math.max(cur, b);
    }
    wallSeg(cur, span);
  }

  /* ---- 隔断 + 隔断门 ---- */
  for (const p of (T.parts || [])){
    for (const b of p.walls){
      const r = mk({ x: b.x, y: b.y, w: b.w, h: b.h });
      walls.push({ x: r.x, y: r.y, w: r.w, h: r.h, mat: T.mat });
    }
    if (p.door){
      const r = mk(p.door);
      const dd = { t: 'doorSwing', x: r.x, y: r.y, w: r.w, h: r.h, manual: true, skin: p.door.skin || 'wood' };
      if (p.door.locked){ dd.isLocked = true; dd.unlocked = false; if (p.door.keyId) dd.keyId = p.door.keyId; }
      doors.push(dd);
    }
  }

  /* ---- 屋顶 ---- */
  const oh = (T.roof && T.roof.overhang) || 0;
  const rf = mk({ x: -oh, y: -oh, w: T.w + oh * 2, h: T.h + oh * 2 });
  roofs.push({ x: rf.x, y: rf.y, w: rf.w, h: rf.h, mat: (T.roof && T.roof.mat) || 'tile', building: 0 });

  /* ---- 房间 ---- */
  for (const rm of (T.rooms || [])){
    const r = mk(rm);
    rooms.push({ x: r.x, y: r.y, w: r.w, h: r.h, name: rm.name, building: 0, locked: !!rm.locked });
  }

  /* ---- 家具：[类型, 局部 x, 局部 y] ---- */
  for (const p of (T.props || [])){
    const r = mk({ x: p[1], y: p[2], w: 1, h: 1 });
    decors.push({ t: p[0], x: Math.round(r.x), y: Math.round(r.y) });
  }

  /* ---- 战利品箱：[箱型, 局部 x, 局部 y] ---- */
  for (const c of (T.crates || [])){
    const r = mk({ x: c[1], y: c[2], w: 1, h: 1 });
    crates.push({ t: LOOT_CRATE_KIND_TYPE(c[0]), x: Math.round(r.x), y: Math.round(r.y) });
  }

  /* ---- 统一放大：小屋太挤，玩家连转身的地方都没有 ---- */
  const k = T.scale || (T.w <= 300 ? 1.34 : (T.w <= 400 ? 1.22 : 1.12));
  if (k !== 1){
    const S = v => Math.round(v * k);
    const rel = o => { o.x = base.x + S(o.x - base.x); o.y = base.y + S(o.y - base.y); o.w = S(o.w); o.h = S(o.h); };
    for (const o of walls) rel(o);
    for (const o of doors) rel(o);
    for (const o of roofs) rel(o);
    for (const o of rooms) rel(o);
    for (const o of glass) rel(o);
    for (const o of decors) o.x = base.x + S(o.x - base.x), o.y = base.y + S(o.y - base.y);
    for (const o of crates){ o.x = base.x + S(o.x - base.x); o.y = base.y + S(o.y - base.y);
                             o._lx = o.x; o._ly = o.y; }
  }

  /* ---- 箱子配额：普通房子最多 2 个，有上锁房间的最多 5 个 ---- */
  const lockedHouse = rooms.some(r => r.locked);
  const quota = T.maxCrates || (lockedHouse ? CRATE_CAP.locked : CRATE_CAP.normal);
  if (crates.length > quota) crates.length = quota;

  /* ---- 第 59 轮：箱子按房间网格撒点 ----
     模板里只写"这屋该有几个箱子"，具体坐标由房间范围决定：
     网格步长 78px，自动避开墙、门、家具和别的箱子。这样不会插墙、
     不会堵门、也不会挤成一堆。 */
  {
    const hit = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
    const box = (x, y, w = 46) => ({ x: x - 3, y: y - 3, w, h: w });
    const wallBoxes = walls.map(w => ({ x: w.x - 2, y: w.y - 2, w: w.w + 4, h: w.h + 4 }));
    const doorBoxes = doors.map(d => ({ x: d.x - 20, y: d.y - 20, w: d.w + 40, h: d.h + 40 }));
    const propBoxes = decors.map(d => box(d.x, d.y, 46));
    const placed = [];
    const want = crates.slice();
    crates.length = 0;
    /* 上锁的屋子先各塞一个，免得"锁屋当仓库"却一个箱子都没分到 */
    const lockedFirst = [];
    for (const r of rooms) if (r.locked) lockedFirst.push(r);
    for (let i = 0; i < want.length; i++){
      const c = want[i];
      const pref = (i < lockedFirst.length) ? [lockedFirst[i]] : [];
      const rest = rooms.slice(i % Math.max(1, rooms.length)).concat(rooms.slice(0, i % Math.max(1, rooms.length)));
      const order = pref.concat(rest);
      let spot = null;
      for (const r of order){
        const step = Math.min(r.w, r.h) < 140 ? 58 : 76;
        for (let y = r.y + 24; y <= r.y + r.h - 48 && !spot; y += step){
          for (let x = r.x + 28; x <= r.x + r.w - 48 && !spot; x += step){
            const p = { x, y };
            if (wallBoxes.some(w => hit(box(p.x, p.y), w))) continue;
            if (doorBoxes.some(w => hit(box(p.x, p.y), w))) continue;
            if (propBoxes.some(w => hit(box(p.x, p.y), w))) continue;
            if (placed.some(o => Math.abs(o.x - p.x) < 54 && Math.abs(o.y - p.y) < 54)) continue;
            spot = p;
          }
        }
        if (spot) break;
      }
      if (!spot) continue;
      c.x = spot.x; c.y = spot.y; c._lx = c.x; c._ly = c.y;
      placed.push(c); crates.push(c);
    }
  }

  /* ---- 家具让位：和箱子/墙重叠的家具直接不摆（扫把插在箱子里那种） ---- */
  const boxOf = (o, w, h) => ({ x: o.x, y: o.y, w: w || 16, h: h || 16 });
  const overlaps = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  /* 只让"和箱子重叠"的家具消失；贴墙摆是正常的，不该丢 */
  const blockRects = crates.map(c => boxOf(c, 46, 46));
  const kept = [];
  for (const d of decors){
    const sz = (typeof DECOR_DEF !== 'undefined' && DECOR_DEF[d.t] && DECOR_DEF[d.t].sz) || [24, 24];
    const fits = (o) => !blockRects.some(b => overlaps(boxOf(o, sz[0] + 8, sz[1] + 8), b));
    if (fits(d)){ kept.push(d); continue; }
    /* 和箱子撞了就挪一挪，别直接把家具删掉（贴墙摆到箱子旁边很正常） */
    let placed = false;
    for (const off of [[0, 58], [58, 0], [0, -58], [-58, 0], [58, 58], [-58, -58]]){
      const t = { t: d.t, x: d.x + off[0], y: d.y + off[1] };
      if (fits(t)){ kept.push(t); placed = true; break; }
    }
    /* 实在没地方就算了 */
  }
  decors.length = 0;
  for (const d of kept) decors.push(d);

  return { w: Math.round(T.w * k), h: Math.round(T.h * k), walls, doors, roofs, rooms, decors, crates, glass };
}

/* 把关卡 placed 里列的模板全部摆上去。只跑一次；没有 placed 的老关卡什么都不动。 */
function placeRooms(L){
  if (!L || !L.placed || !L.placed.length) return 0;
  if (L._placedDone) return 0;
  L._placedDone = true;
  L.walls = L.walls || [];
  L.doors = L.doors || [];
  L.roofs = L.roofs || [];
  L.rooms = L.rooms || [];
  L.decors = L.decors || [];
  let n = 0, base = 0;
  for (const r of L.rooms.concat(L.roofs)) base = Math.max(base, ((r && r.building) | 0) + 1);
  for (const p of L.placed){
    const one = roomTplBuild(p.t, p.x, p.y, p.rot || 0);
    if (!one) continue;
    const bid = base + n;
    for (const w of one.walls) L.walls.push(w);
    /* 箱子必须进 L.brk —— 进 L.walls 的话它只是一块"长得像箱子的墙"：
       能挡人、能搜刮，但 damageWall 不认它，永远打不坏。 */
    L.brk = L.brk || [];
    for (const c of one.crates) L.brk.push(c);
    for (const g of (one.glass || [])){ L.glass = L.glass || []; L.glass.push(g); }
    for (const d of one.doors) L.doors.push(d);
    for (const r of one.roofs){ r.building = bid; L.roofs.push(r); }
    for (const r of one.rooms){ r.building = bid; r.template = p.t; roomAdd(L, r); }
    /* 兜底房间：模板手写的 rooms 盖不满整栋楼（过道、门口、隔断边角），
       玩家站在这些地方就会被判成"在屋外"、屋顶不淡出。这里按屋顶矩形
       内缩一圈墙厚补一块，只用来回答"人在不在屋里"，不参与压暗。 */
    {
      const rf0 = one.roofs[0];
      const t0 = Math.max(10, Math.round((one.walls[0] && one.walls[0].h) || 16));
      if (rf0) roomAdd(L, { x: rf0.x + t0, y: rf0.y + t0,
                              w: Math.max(8, rf0.w - t0 * 2), h: Math.max(8, rf0.h - t0 * 2),
                              name: '室内', building: bid, fallback: true, template: p.t });
    }
    for (const dd of one.decors) L.decors.push(dd);
    n++;
  }
  return n;
}
