/* 70-devorder.js —— 开发者"指挥移动"（m42994 / m43351）
 *
 * 用法（CFG.dev 打开时，不需要先按什么键）：
 *   鼠标中键点单位        选中（青色环）
 *   左键点地面            该单位"用 N 秒走过去"；车就地变成无人驾驶开过去
 *   [ / ]                调"多少秒到达"（1 / 1.5 / 2 / 3 / 4 / 6 / 8 / 12 秒循环）
 *   右键 / Esc           取消选中（F7 仍可整体关掉指挥层）
 *
 * 设计要点：
 *   - 敌人只走"巡逻"分支（写 e.wp 一个点），并且整段命令期间 e.devCalm 让感知强制看不见人，
 *     所以不会半路变成追击、也不会一边走一边朝你开枪。走完全程就恢复原来的巡逻/警戒。
 *   - 速度不是倍率，而是"按你设定秒数走完直线距离"反算出来的 px/s（e.devSpd），
 *     所以设 3 秒就真的差不多 3 秒到（绕路/被墙挡住会久一点）。
 *   - 车走 tstate='devdrive'，自己转向、加速、避墙；到点或撞墙就停在原地。
 */
const DEVORD_SECS = [1, 1.5, 2, 3, 4, 6, 8, 12];
let devOrd = { on: true, pick: null, secIx: 3 };
function devOrdSec(){ return DEVORD_SECS[Math.max(0, Math.min(DEVORD_SECS.length - 1, devOrd.secIx | 0))]; }
function devOrdSecStep(d){
  devOrd.secIx = (devOrd.secIx + d + DEVORD_SECS.length) % DEVORD_SECS.length;
  setMsg('到达时间：' + devOrdSec() + ' 秒', 1.2);
  return devOrdSec();
}

function devOrderToggle(){
  if (!CFG.dev){ setMsg('先打开开发者模式', 1.6); return false; }
  if (state !== 'play') return false;
  devOrd.on = !devOrd.on; devOrd.pick = null;
  setMsg(devOrd.on ? '指挥层：中键点单位/车 → 左键点目标（右键取消 · F7 隐藏）' : '指挥层已隐藏（中键仍可直接选）', 1.8);
  return devOrd.on;
}

function devOrderUnitAt(wx, wy){
  let best = null, bd = 1e9;
  for (const e of enemies){
    if (!e || e.dead || e.hp <= 0) continue;
    const d = dist(wx, wy, e.x, e.y);
    if (d <= Math.max(26, e.r + 16) && d < bd){ bd = d; best = { kind: 'enemy', e: e, x: e.x, y: e.y }; }
  }
  for (const t of trucks){
    if (!t || t.gone || t.dead) continue;
    const d = dist(wx, wy, t.x, t.y);
    if (d <= t.r + 14 && d < bd){ bd = d; best = { kind: 'truck', t: t, x: t.x, y: t.y }; }
  }
  return best;
}

/* m43955：选中之后用方向键微调坐标（1px，按住 Shift 10px）。
 * 车辆尤其需要——一排车差几个像素，看着就不齐。 */
function devOrderNudge(dx, dy){
  const p = devOrd && devOrd.pick;
  if (!p) return false;
  const ent = (p.kind === 'enemy') ? p.e : p.t;
  if (!ent || ent.dead || ent.gone) return false;
  const L = cur();
  const r = Math.max(8, ent.r || 12);
  const nx = clamp(ent.x + dx, r, (L.w || 4000) - r);
  const ny = clamp(ent.y + dy, r, (L.h || 4000) - r);
  if (nx === ent.x && ny === ent.y) return false;
  ent.x = nx; ent.y = ny;
  if (p.kind === 'truck'){
    if (typeof navPatchTruck === 'function') navPatchTruck(ent);
    if (ent.tstate === 'devdrive' && ent.devGo){ ent.devGo.x += dx; ent.devGo.y += dy; }
  } else {
    ent.path = null; ent.goal = null;
    if (ent.devOrd){ ent.devOrd.x += dx; ent.devOrd.y += dy; ent.wp = [[ent.devOrd.x, ent.devOrd.y]]; ent.i = 0; }
    else { ent.wp = null; ent.i = 0; }
  }
  return true;
}

function devOrderAssign(u, x, y){
  if (!u) return false;
  const _sec = devOrdSec();
  if (u.kind === 'truck'){
    const t = u.t;
    const d = dist(t.x, t.y, x, y);
    t.devGo = { x: x, y: y };
    t.devSec = _sec;
    t.devSpd = clamp(d / Math.max(0.3, _sec), 40, 420);   /* px/s：直线上按秒数到 */
    t.tstate = 'devdrive'; t.spd = (t.spd || 0);
    t.devStuckT = 0; t.devNavT = 0;
    navPatchTruck(t);
    setMsg('无人驾驶：车 → ' + Math.round(x) + ',' + Math.round(y) + ' · ' + _sec + ' 秒', 1.8);
    return true;
  }
  const e = u.e;
  const dd = dist(e.x, e.y, x, y);
  e.devOrd = { x: x, y: y };
  e.devSec = _sec;
  e.devSpd = clamp(dd / Math.max(0.3, _sec), 18, 360);    /* 巡逻分支直接用它当速度 */
  e.devCalm = true;
  e.alertT = 0; e.mode = 0; e.lastKnown = null; e.heard = false;
  e.sees = false; e.seesPlayer = false;
  e.path = null; e.goal = null; e.chk = null; e.chaseStall = 0;
  e.wp = [[x, y]]; e.i = 0; e.wait = 0; e.patrolStuck = 0;
  setMsg('已下令：单位 → ' + Math.round(x) + ',' + Math.round(y) + ' · ' + _sec + ' 秒', 1.8);
  return true;
}

/* 鼠标：true 表示这次点击被指挥层吃掉了。
 * m43351：改成**鼠标中键选中**，不再需要先按 F7；左键点地面才是下令。 */
function devOrderMouse(mx, my, button){
  if (!CFG.dev || state !== 'play') return false;
  /* m43827：中键必须"直接能选"，不能因为指挥层被 Esc/F7 关掉就失效。
     中键永远放行（顺手把指挥层打开），其它键才看 devOrd.on。 */
  if (!devOrd.on){
    if (button !== 1) return false;
    devOrd.on = true;
  }
  /* 放置模式 / 投放面板 / 物资面板开着时，点击归它们，指挥层让位（m43322 的"按了指挥就放不下兵"） */
  if (typeof devPlaceKind !== 'undefined' && devPlaceKind) return false;
  if (typeof devSpawnOpen !== 'undefined' && devSpawnOpen) return false;
  if (typeof devItemOpen !== 'undefined' && devItemOpen) return false;
  const w = screenToWorld(mx, my);
  if (button === 1){                       /* 中键：选中/取消选中 */
    if (typeof bindMark === 'function') bindMark('order-pick');
    const u = devOrderUnitAt(w.x, w.y);
    if (!u){ devOrd.pick = null; return true; }
    /* devOrderUnitAt 每次都新建对象，只能比底层实体 */
    const _p = devOrd.pick;
    const same = !!_p && ((u.kind === 'enemy' && _p.kind === 'enemy' && _p.e === u.e)
                       || (u.kind === 'truck' && _p.kind === 'truck' && _p.t === u.t));
    devOrd.pick = same ? null : u;
    setMsg(devOrd.pick ? (u.kind === 'truck' ? '选中：车辆（左键点目标）' : '选中：人机（左键点目标）') : '取消选中', 1.4);
    return true;
  }
  if (button === 2){
    if (!devOrd.pick) return false;
    devOrd.pick = null; setMsg('取消选中', 1.0); return true;
  }
  if (button !== 0) return false;
  if (!devOrd.pick) return false;          /* 没选中就让左键正常开枪 */
  devOrderAssign(devOrd.pick, w.x, w.y);
  if (typeof bindMark === 'function') bindMark('order-go');
  devOrd.pick = null;
  return true;
}

function devOrderTick(dt){
  if (!CFG.dev) return;
  if (devOrd.pick){
    const p = devOrd.pick;
    if (p.kind === 'enemy' ? (p.e.dead || p.e.hp <= 0) : (p.t.gone || p.t.dead)) devOrd.pick = null;
  }
  /* 敌人：命令期间只走巡逻，感知强制关掉（由 42-actors 里的 e.devCalm 兜底） */
  for (const e of enemies){
    if (!e || !e.devOrd) continue;
    if (e.dead || e.hp <= 0){ e.devOrd = null; e.devCalm = false; continue; }
    const d = dist(e.x, e.y, e.devOrd.x, e.devOrd.y);
    if (d < 16){
      e.devOrd = null; e.devCalm = false; e.devSpd = 0;
      e.wp = [[e.x, e.y]]; e.i = 0; e.wait = 0.6;
      setMsg('到点了', 1.0);
      continue;
    }
    e.alertT = 0; e.mode = 0; e.lastKnown = null; e.heard = false;
    e.sees = false; e.seesPlayer = false;
    e.path = null;
    e.wp = [[e.devOrd.x, e.devOrd.y]]; e.i = 0; e.wait = 0;
  }
  /* 车：到点/撞墙就停；导航格每 0.2 秒补一次，别每帧重刷 */
  for (const t of trucks){
    if (!t || !t.devGo) continue;
    if (t.gone || t.dead){ t.devGo = null; continue; }
    t.devNavT = (t.devNavT || 0) + dt;
    if (t.devNavT > 0.2){ t.devNavT = 0; if (typeof navPatchTruck === 'function') navPatchTruck(t); }
  }
}

function devDriveTick(e, dt){
  const g = e.devGo;
  if (!g){ e.spd = 0; e.tstate = 'parked'; return; }
  const L = cur();
  const dx = g.x - e.x, dy = g.y - e.y;
  const d = Math.hypot(dx, dy);
  if (d < 30){
    e.devGo = null; e.spd = 0; e.tstate = 'parked';
    if (typeof navPatchTruck === 'function') navPatchTruck(e);
    setMsg('车到位了', 1.4);
    return;
  }
  const want = Math.atan2(dy, dx);
  const diff = normAng(want - e.ang);
  const maxTurn = 2.4 * dt;
  e.ang = normAng(e.ang + clamp(diff, -maxTurn, maxTurn));
  /* 大幅度要掉头时先龟速，转正了再上速度 —— 和真人开车的观感一致。
     m43351：巡航速度由"多少秒到达"反算，慢速档按它等比缩放（不然设 12 秒也还是 150 冲过去）。 */
  const _cruise = Math.max(40, Math.min(420, e.devSpd || 240));
  const targetSpd = (Math.abs(diff) > 1.0 ? _cruise * 0.30 : (Math.abs(diff) > 0.5 ? _cruise * 0.62 : _cruise));
  e.spd += (targetSpd - e.spd) * Math.min(1, dt * 4);
  const nx = e.x + Math.cos(e.ang) * e.spd * dt;
  const ny = e.y + Math.sin(e.ang) * e.spd * dt;
  /* 探路点要放到车头再往前一点：车自己会占住脚下的导航格，拿车身中心去问必然"被挡" */
  const _look = (e.r || 22) + 20;
  const _px = nx + Math.cos(e.ang) * _look;
  const _py = ny + Math.sin(e.ang) * _look;
  const blocked = NavQuery.isBlocked(L, {x: _px, y: _py}, 0, 'vehicle');
  if (blocked){
    e.devStuckT = (e.devStuckT || 0) + dt;
    if (e.devStuckT > 0.5){
      e.devGo = null; e.spd = 0; e.tstate = 'parked'; e.devStuckT = 0;
      if (typeof navPatchTruck === 'function') navPatchTruck(e);
      setMsg('车过不去，停在原地', 1.6);
      return;
    }
    e.spd *= Math.max(0, 1 - dt * 12);
    return;
  }
  e.devStuckT = 0;
  e.x = nx; e.y = ny;
  e.wheelRot = (e.wheelRot || 0) + e.spd * dt / 9;
  if (Math.abs(e.spd) > 200 && typeof spawnPart === 'function'){
    e.dustT = (e.dustT || 0) - dt;
    if (e.dustT <= 0){
      e.dustT = 0.06;
      const back = e.ang + Math.PI, side = e.ang + Math.PI / 2;
      for (const sgn of [-1, 1]){
        spawnPart(e.x + Math.cos(back) * 30 + Math.cos(side) * 18 * sgn,
                  e.y + Math.sin(back) * 30 + Math.sin(side) * 18 * sgn,
                  back + rand(-0.4, 0.4), rand(20, 60), rand(0.3, 0.6), 'dust', rand(3, 6));
      }
    }
  }
}

/* 世界坐标 → 屏幕坐标。
   指挥层是在 render() 末尾、世界矩阵 restore 之后画的，所以每一点都得自己换算，
   不然就和摄像机脱钩（斗蛐蛐缩放下偏得最明显）。
   换算顺序必须和 44-sfxcombat.js 里的世界变换一致：
     屏幕 = 望远镜缩放(以玩家屏幕位置为锚) ∘ 观战缩放(绕屏幕中心) ∘ translate(-cam) */
function devOrderScreen(wx, wy){
  let sx, sy;
  if (typeof cricketOn === 'function' && cricketOn() &&
      typeof crkSX === 'function' && typeof crkSY === 'function'){
    sx = crkSX(wx); sy = crkSY(wy);
  } else {
    sx = wx - cam.x; sy = wy - cam.y;
  }
  if (typeof binoZoomK === 'function' && player){
    const bz = binoZoomK();
    if (Math.abs(bz - 1) > 0.001){
      const ax = player.x - cam.x, ay = player.y - cam.y;
      sx = ax + (sx - ax) * bz;
      sy = ay + (sy - ay) * bz;
    }
  }
  return { x: sx, y: sy };
}
/* 同上的缩放系数：半径、线宽都要跟着缩，不然圈会跟单位脱开 */
function devOrderK(){
  let k = 1;
  if (typeof cricketOn === 'function' && cricketOn() &&
      typeof crkZoomK === 'function') k *= crkZoomK();
  if (typeof binoZoomK === 'function') k *= binoZoomK();
  return k;
}

/* 这一层该不该画：开发者模式 + 指挥模式开着，且没进 F9 拍照模式 */
function devOrderVisible(){
  if (!CFG.dev || !devOrd.on) return false;
  if (typeof window !== 'undefined' && window.uiHideAll) return false;
  return true;
}

function drawDevOrder(){
  if (!devOrderVisible()) return;   /* F9 拍照模式：指挥层也一起藏掉 */
  const K = devOrderK();
  ctx.save();
  ctx.lineWidth = 2 * K;
  /* 选中环 */
  const p = devOrd.pick;
  if (p){
    const w0 = devOrderScreen(p.kind === 'enemy' ? p.e.x : p.t.x, p.kind === 'enemy' ? p.e.y : p.t.y);
    ctx.strokeStyle = 'rgba(120,220,255,0.95)';
    ctx.beginPath(); ctx.arc(w0.x, w0.y, (p.kind === 'enemy' ? (p.e.r + 12) : (p.t.r + 12)) * K, 0, TAU); ctx.stroke();
    const w = { x: mouse.x, y: mouse.y };   /* 鼠标本来就是屏幕坐标 */
    ctx.setLineDash([6 * K, 6 * K]);
    ctx.strokeStyle = 'rgba(120,220,255,0.45)';
    ctx.beginPath(); ctx.moveTo(w0.x, w0.y); ctx.lineTo(w.x, w.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = 'rgba(120,220,255,0.85)';
    ctx.beginPath(); ctx.arc(w.x, w.y, 10 * K, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(w.x - 14 * K, w.y); ctx.lineTo(w.x + 14 * K, w.y); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(w.x, w.y - 14 * K); ctx.lineTo(w.x, w.y + 14 * K); ctx.stroke();
  }
  /* 已下令的目标旗 */
  for (const e of enemies){
    if (!e || !e.devOrd) continue;
    const a = devOrderScreen(e.x, e.y), b = devOrderScreen(e.devOrd.x, e.devOrd.y);
    ctx.strokeStyle = 'rgba(255,214,90,0.85)'; ctx.lineWidth = 1.6 * K;
    ctx.setLineDash([4 * K, 5 * K]);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(b.x, b.y, 12 * K, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x, b.y - 22 * K); ctx.stroke();
    ctx.fillStyle = 'rgba(255,214,90,0.9)';
    ctx.beginPath(); ctx.moveTo(b.x, b.y - 22 * K);
    ctx.lineTo(b.x + 14 * K, b.y - 17 * K); ctx.lineTo(b.x, b.y - 12 * K); ctx.closePath(); ctx.fill();
  }
  for (const t of trucks){
    if (!t || !t.devGo) continue;
    const a = devOrderScreen(t.x, t.y), b = devOrderScreen(t.devGo.x, t.devGo.y);
    ctx.strokeStyle = 'rgba(140,255,190,0.8)'; ctx.lineWidth = 1.6 * K;
    ctx.setLineDash([4 * K, 5 * K]);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(b.x, b.y, 16 * K, 0, TAU); ctx.stroke();
  }
  ctx.restore();
  /* 顶部提示条 */
  ctx.save();
  ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  const tip = devOrd.pick
    ? ('指挥：左键点目标（' + devOrdSec() + ' 秒到）· ↑↓←→ 微调坐标 · 中键再点/右键取消')
    : '指挥：鼠标中键点单位/车辆选中（F7 隐藏）';
  const tw = ctx.measureText(tip).width + 24;
  ctx.fillStyle = 'rgba(10,16,22,0.82)';
  ctx.fillRect(W / 2 - tw / 2, 44, tw, 26);
  ctx.strokeStyle = 'rgba(120,220,255,0.65)';
  ctx.lineWidth = 1;
  ctx.strokeRect(W / 2 - tw / 2, 44, tw, 26);
  ctx.fillStyle = 'rgba(180,236,255,0.96)';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(tip, W / 2, 57);
  ctx.restore();
}

window.addEventListener('keydown', function(ev){
  if (!CFG || !CFG.dev) return;
  const t = ev.target;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
  if (ev.code === 'F7'){ ev.preventDefault(); devOrderToggle(); return; }
  /* m43955：选中后用方向键微调坐标（Shift 走 10px）。放在 Esc 之前，避免方向键被别处吃掉。 */
  if (devOrd && devOrd.pick && state === 'play' &&
      !(typeof devPlaceKind !== 'undefined' && devPlaceKind) &&
      !(typeof devSpawnOpen !== 'undefined' && devSpawnOpen) &&
      !(typeof devItemOpen !== 'undefined' && devItemOpen)){
    const _d = ev.shiftKey ? 10 : 1;
    let _dx = 0, _dy = 0;
    if (ev.code === 'ArrowUp') _dy = -_d;
    else if (ev.code === 'ArrowDown') _dy = _d;
    else if (ev.code === 'ArrowLeft') _dx = -_d;
    else if (ev.code === 'ArrowRight') _dx = _d;
    if (_dx || _dy){
      if (ev.preventDefault) ev.preventDefault();
      if (devOrderNudge(_dx, _dy)) setMsg('微调 ' + (devOrd.pick.kind === 'truck' ? '车辆' : '单位') + ' → ' +
        Math.round(devOrd.pick.kind === 'truck' ? devOrd.pick.t.x : devOrd.pick.e.x) + ',' +
        Math.round(devOrd.pick.kind === 'truck' ? devOrd.pick.t.y : devOrd.pick.e.y), 0.6);
      return;
    }
  }
  /* m43827：Esc 只取消选中，不再把整个指挥层关掉（以前按一次 Esc，中键就失效，
     用户就会以为"必须先按 F7"）。想隐藏指挥层请按 F7。 */
  if (ev.code === 'Escape' && devOrd && devOrd.pick){
    devOrd.pick = null; setMsg('取消选中（F7 可隐藏指挥层）', 1.3);
  }
}, true);
