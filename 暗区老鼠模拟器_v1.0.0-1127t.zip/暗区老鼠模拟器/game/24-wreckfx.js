/* ============ 运兵车残骸的火焰 / 黑烟 / 火星（m30146） ============
   全部粒子从 WRECKFX_POOL 取，池满就放弃这一颗，绝不 new。
   残骸长期燃烧：只要 truck.wreck 还在，就一直冒。 */
function wreckDef(){ return (typeof DataWRECK !== 'undefined' && DataWRECK) ? DataWRECK : null; }
function wreckRange(arr, dflt){ return (arr && arr.length === 2) ? fxRand(arr[0], arr[1]) : dflt; }
function spawnWreckFx(kind, x, y, vx, vy, dur, size){
  const p = poolTake(WRECKFX_POOL, wreckFxs);
  if (!p) return null;
  p.kind = kind; p.x = x; p.y = y; p.vx = vx; p.vy = vy;
  p.t = 0; p.dur = dur; p.size = size; p.seed = fxRand(0, 100);
  return p;
}
function updateWreckFx(dt){
  const D = wreckDef();
  if (!D || D.on === false){ if (wreckFxs.length) poolClearView(wreckFxs); return; }
  for (const t of trucks){
    if (!t || !t.wreck || t.tstate === 'gone') continue;
    const cx = t.x, cy = t.y;
    t.fxFireAcc = (t.fxFireAcc || 0) - dt;
    let guard = 0;
    while (t.fxFireAcc <= 0 && guard++ < 12){
      t.fxFireAcc += (D.fireRate || 0.03);
      const a = fxRand(0, TAU), rr = fxRand(0, D.fireR || 26);
      spawnWreckFx('fire', cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.7,
        fxRand(-9, 9), fxRand(-40, -16), wreckRange(D.fireLife, 0.8),
        wreckRange(D.fireSize, 11));
    }
    t.fxSmokeAcc = (t.fxSmokeAcc || 0) - dt;
    guard = 0;
    while (t.fxSmokeAcc <= 0 && guard++ < 8){
      t.fxSmokeAcc += (D.smokeRate || 0.10);
      spawnWreckFx('smoke', cx + fxRand(-22, 22), cy - 12 + fxRand(-8, 8),
        fxRand(-7, 7), fxRand(-26, -10), wreckRange(D.smokeLife, 2.2),
        wreckRange(D.smokeSize, 15));
    }
    t.fxEmberAcc = (t.fxEmberAcc || 0) - dt;
    guard = 0;
    while (t.fxEmberAcc <= 0 && guard++ < 8){
      t.fxEmberAcc += (D.emberRate || 0.14);
      spawnWreckFx('ember', cx + fxRand(-20, 20), cy + fxRand(-8, 8),
        fxRand(-22, 22), fxRand(-95, -45), wreckRange(D.emberLife, 0.9), fxRand(1.2, 2.4));
    }
  }
  for (let i = wreckFxs.length - 1; i >= 0; i--){
    const p = wreckFxs[i];
    p.t += dt;
    if (p.t >= p.dur){ poolReleaseAt(wreckFxs, i); continue; }
    p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.kind === 'fire'){ p.y -= 26 * dt; p.vx *= (1 - 1.6 * dt); }
    else if (p.kind === 'smoke'){ p.vx *= (1 - 0.7 * dt); }
    else { p.vy -= 40 * dt; }
  }
}
/* 残骸火画在"地面之上、人和车之下"—— 属于场地，不该盖住站在旁边的单位 */
function drawWreckFx(){
  if (!wreckFxs.length) return;
  const gf = glowSprite('wfire', [[0,'rgba(255,238,180,0.95)'],[0.35,'rgba(255,150,55,0.72)'],[1,'rgba(130,36,10,0)']], 64);
  const gs = glowSprite('wsmoke', [[0,'rgba(96,78,66,0.72)'],[0.45,'rgba(40,37,35,0.50)'],[1,'rgba(16,15,14,0)']], 64);
  const ge = glowSprite('wember', [[0,'rgba(255,245,200,1)'],[0.45,'rgba(255,140,50,0.8)'],[1,'rgba(170,36,8,0)']], 32);
  ctx.save();
  for (const p of wreckFxs){
    if (!cullPt(p.x, p.y, p.size + 40)) continue;
    const k = Math.max(0, 1 - p.t / p.dur);
    if (p.kind === 'smoke'){
      const r = p.size * (1.0 + (1 - k) * 1.35);
      ctx.globalAlpha = 0.42 * k;
      ctx.drawImage(gs, p.x - r, p.y - r, r * 2, r * 2);
      continue;
    }
    ctx.globalCompositeOperation = 'lighter';
    if (p.kind === 'fire'){
      const fl = 0.82 + 0.18 * Math.sin(uiT * 13 + p.seed);
      const r = p.size * (0.55 + 0.45 * k) * fl;
      ctx.globalAlpha = 0.78 * k;
      ctx.drawImage(gf, p.x - r, p.y - r * 1.35, r * 2, r * 2.7);
    } else {
      ctx.globalAlpha = 0.85 * k;
      const r = p.size * 2.2;
      ctx.drawImage(ge, p.x - r, p.y - r, r * 2, r * 2);
    }
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}
