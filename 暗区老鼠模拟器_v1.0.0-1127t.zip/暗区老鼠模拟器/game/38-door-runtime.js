function updateDoors(dt){
  if (!doors.length) return;
  /* 大图上门口一百多扇、人两百多号：每扇门都 enemies.concat(allies) 一遍
     等于每帧新建一百个数组、跑几十万次 bbox（实测量出来 0.45ms/帧）。
     这一帧的"会走路的人"先按 256px 粗格装桶，门口只查自己周围那几格。 */
  const _wg = new Map();
  const _wlist = enemies.concat(allies);
  for (let _i = 0; _i < _wlist.length; _i++){
    const e = _wlist[_i];
    if (!e || e.dead || e.dummy) continue;
    const _k = ((e.x / 256) | 0) + ',' + ((e.y / 256) | 0);
    let _a = _wg.get(_k);
    if (!_a){ _a = []; _wg.set(_k, _a); }
    _a.push(e);
  }
  for (const d of doors){
    /* 判定"有人要过门"必须用**门框**，不能用 d.x/d.w ——
       平开门打开后 d.x/d.w 会被换成横着的门板矩形，用它来判距离的话，
       门一开，"附近"那块区域就跟着跑到门外侧去了，于是门关上、人又变"近"、门再开 —— 这就是抽搐。 */
    const fx0 = d.fx != null ? d.fx : d.x, fy0 = d.fy != null ? d.fy : d.y;
    const fw0 = d.fw || d.w, fh0 = d.fh || d.h;
    const cx = fx0 + fw0 / 2, cy = fy0 + fh0 / 2;
    d.hitT = Math.max(0, (d.hitT || 0) - dt);
    d.pierceT = Math.max(0, (d.pierceT || 0) - dt);
    if (d.broken){                       /* 碎了的门等于一直开着，不再参与开关 */
      d.open += (1 - d.open) * Math.min(1, dt * 4);
      if (d.open > 0.99) d.open = 1;
      if (!d.snd){ d.snd = true; }
      continue;
    }
    let near = false;
    {
      const _gx0 = ((fx0 - 96) / 256) | 0, _gx1 = ((fx0 + fw0 + 96) / 256) | 0;
      const _gy0 = ((fy0 - 96) / 256) | 0, _gy1 = ((fy0 + fh0 + 96) / 256) | 0;
      for (let _gy = _gy0; _gy <= _gy1 && !near; _gy++){
        for (let _gx = _gx0; _gx <= _gx1 && !near; _gx++){
          const _arr = _wg.get(_gx + ',' + _gy);
          if (!_arr) continue;
          for (let _wi = 0; _wi < _arr.length; _wi++){
            const e = _arr[_wi];
            if (e.x > fx0-34 && e.x < fx0+fw0+34 && e.y > fy0-34 && e.y < fy0+fh0+34){ near = true; break; }
            const _dx = e.x - cx, _dy = e.y - cy;
            if (_dx*_dx + _dy*_dy < 9216){ near = true; break; }   /* 96² */
          }
        }
      }
    }
    if (!near){
      for (const h of hunters){
        if (!h) continue;
        if (h.x > fx0-34 && h.x < fx0+fw0+34 && h.y > fy0-34 && h.y < fy0+fh0+34){ near = true; break; }
        if (dist(h.x, h.y, cx, cy) < 96){ near = true; break; }
      }
    }
    if (!d.manual){
      if (near) d.hold = (cur().rules && cur().rules.doorHold) || 2.6;
      else d.hold = Math.max(0, d.hold - dt);
    }
    /* 手开关门：玩家按 E 定下的 want 说了算，但**敌人贴到门口也会把门顶开**
       （测"敌人开门"用；人走了门自己回到玩家设的状态）。
       这里必须有迟滞：门一开，躲在门口的敌人被门板扫开、`near` 立刻变 false，
       门就关回去，敌人再走回来又开 —— 那一来一回就是"门在抽搐"。
       所以敌人顶开的门额外保持 1.8 秒，等它真的走开再关。 */
    /* 锁着又没解锁：谁都推不开 —— 敌人只会绕着走（寻路把 doorSolid 当墙），
       玩家按 E 也只会得到「门锁着」。解锁之后才回到上面那套自动开门。 */
    if (d.isLocked && !d.unlocked){
      near = false;
      d.enemyHold = 0;
      d.hold = 0;
      d.open = 0;                       /* 锁着的门就是关着的，没有半开这一说 */
      d.snd = false;
      if (d.swing){ d.x = d.fx; d.y = d.fy; d.w = d.fw; d.h = d.fh; }
      continue;
    }
    if (near) d.enemyHold = 1.8;
    else d.enemyHold = Math.max(0, (d.enemyHold || 0) - dt);
    const target = d.manual ? ((d.want || near || d.enemyHold > 0) ? 1 : 0) : ((d.hold > 0) ? 1 : 0);
    /* 开得快、关得稍慢：给玩家留半个身位的机会 */
    const rate = target > d.open ? 5.0 : 2.4;
    d.open += (target - d.open) * Math.min(1, dt * rate);
    if (Math.abs(target - d.open) < 0.008) d.open = target;
    const isOpen = (d.open > 0.5);
    if (isOpen !== d.snd){ d.snd = isOpen; sfxDoor(isOpen, cx, cy); }
    /* 平开门：碰撞体跟着门板走。关着时 = 门框（竖着的一条），
       转到能过人（open ≥ 0.55，和 doorSolid 同一条线）之后 = 横过来的一条。
       中间那半个转不算 —— 用旋转矩形的包围盒会在 45° 时鼓成一个比门洞还大的方块，
       玩家贴着门框就会被弹出去，手感很怪。 */
    if (d.swing){
      if (d.open < 0.55){ d.x = d.fx; d.y = d.fy; d.w = d.fw; d.h = d.fh; }
      else { d.x = d.ox; d.y = d.oy; d.w = d.ow; d.h = d.oh; }
      doorSweep(d);            /* 转的过程中门板真的会推人，不能从人身上穿过去 */
    }
  }
}


/* 平开门转到一半时，门板本身也得有碰撞：门外站着的人会被板子顶开，
   而不是被门"穿过去"。在门板的局部坐标里算最近点，再转回世界推。 */
function pushByLeaf(p, d){
  const th = d.th || 18, len = d.len || (d.fh - 2);
  if (len <= 2) return false;
  const r = (p.r || 12) + 0.4;
  const hx = d.hx != null ? d.hx : d.fx + d.fw * 0.5;
  const hy = d.hy != null ? d.hy : d.fy + 1;
  const a = d.open * Math.PI / 2;               /* 门板转过的角度 */
  const ca = Math.cos(a), sa = Math.sin(a);
  const dx = p.x - hx, dy = p.y - hy;
  const lx = dx * ca - dy * sa;                 /* 世界 → 门板局部 */
  const ly = dx * sa + dy * ca;
  const qx = clamp(lx, -th / 2, th / 2);
  const qy = clamp(ly, 0, len);
  let nx = lx - qx, ny = ly - qy;
  const dd = Math.hypot(nx, ny);
  if (dd > r) return false;
  let tlx, tly;
  if (dd < 1e-4){                               /* 整个人在板子里：沿厚度方向顶出去 */
    tlx = (lx >= 0 ? th / 2 : -th / 2) + (lx >= 0 ? r : -r);
    tly = ly;
  } else {
    tlx = qx + (nx / dd) * (r + 0.4);
    tly = qy + (ny / dd) * (r + 0.4);
  }
  p.x = hx + tlx * ca + tly * sa;               /* 局部 → 世界 */
  p.y = hy - tlx * sa + tly * ca;
  return true;
}
/* 门板本身的碰撞：**只在转动过程中**推开挡路的人。
   全开（open ≥ 0.95）之后门板是贴着门垛摊平的，不再当实体 ——
   以前全开也算实心，窄走廊里门板正好横在通道上，AI 一路被顶、又看不见这堵"墙"，
   就卡在门口反复撞，门还因为"附近有人"一直开着 —— 死循环。 */
function doorSweep(d){
  if (!d.swing || d.broken) return;
  if (d.open <= 0.02) return;
  if (d.open >= 0.95) return;        /* 全开 = 贴墙摊平，不再挡人 */
  if (player && player.hp > 0) pushByLeaf(player, d);
  for (const e of enemies) if (e && !e.dead) pushByLeaf(e, d);
  for (const h of hunters) if (h && !h.dead) pushByLeaf(h, d);
}
