/* 拍照模式：一键把所有 HUD / 界面层藏掉，只留世界画面。
   F9 切换；隐藏时不弹任何提示（提示本身也是 UI）。 */
var uiHideAll = false;
window.uiHideAll = false;

function uiHideToggle(){
  const was = uiHideAll;
  uiHideAll = !uiHideAll;
  window.uiHideAll = uiHideAll;
  /* 藏起来的时候一个字都不弹，画面必须干净；恢复时才提示一下 */
  if (was && typeof setMsg === 'function') setMsg('UI 已恢复显示', 1.2);
  return uiHideAll;
}

/* 供截图脚本直接调用 */
function uiHideSet(v){
  uiHideAll = !!v;
  window.uiHideAll = uiHideAll;
  return uiHideAll;
}
