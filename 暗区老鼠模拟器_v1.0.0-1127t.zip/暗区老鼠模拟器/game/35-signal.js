/* ================= 信号枪 + 空投（m09393）=================
   信号枪占副武器栏，一发一装：扣一次扳机吃掉一颗红色信号弹，
   信号弹带着红火星飞出去、落地后原地冒 15 秒红烟（signalSpot），
   然后空投挂着降落伞从天上慢慢落到落点附近，落地变成一个能按 E 搜的箱子。
   箱子里必给：精锐甲 / 远征背包 / 3~5 个绿药包 / 四种口径各 1~2 盒子弹；
   六成概率再给一把火箭筒 + 1~6 发火箭弹。
   ========================================================== */
const FLARE_WAIT   = 15;     /* 信号弹落地到空投开始下落（秒） */
const FLARE_SPD    = 880;    /* 信号弹初速 */
const FLARE_LIFE   = 1.3;    /* 飞这么久还没撞墙就自己落地 */
const FLARE_DRAG   = 1.5;    /* 空气阻力：速度每秒衰减这么多 */
const AIR_FALL_H   = 1150;   /* 空投起始高度（px，纯视觉） */
const AIR_FALL_SPD = 95;     /* 下落速度：约 12 秒落地 */
const AIR_SPREAD   = 40;     /* 落点相对信号弹的随机偏移 */
const AIR_RPG_CH   = 0.60;   /* 空投里出火箭筒的概率 */

function fireFlare(a){
  const dx = Math.cos(a), dy = Math.sin(a);
  const ax = player.x + dx * 20, ay = player.y + dy * 20;
  flares.push({ x: ax, y: ay, vx: dx * FLARE_SPD, vy: dy * FLARE_SPD, t: 0 });
  for (let i = 0; i < 6; i++)
    spawnPart(ax, ay, a + fxRand(-0.45, 0.45), fxRand(90, 280), fxRand(0.10, 0.26), 'flash', fxRand(3, 6));
  gunNoise(1.6);
}

/* 信号弹落地：那片地方冒 15 秒红烟，倒计时到了就把空投放下来 */
function dropFlareAt(x, y){
  signalSpots.push({ x: x, y: y, t: FLARE_WAIT });
  /* 同时存在的落点最多 8 个，再多就把最早的那个丢掉（免得刷屏） */
  while (signalSpots.length > 8) signalSpots.shift();
  for (let i = 0; i < 10; i++)
    spawnPart(x, y, fxRand(0, TAU), fxRand(40, 150), fxRand(0.3, 0.7), 'gold', fxRand(2, 4));
  beep(520, 0.14, 'square', 0.10, 1200);
  setMsg('信号弹上天了 · 15 秒后空投落到红烟这里', 2.4);
  logInfo('item', '打出信号弹 · 空投 15 秒后落地');
}

function updateFlares(dt){
  const L = cur();
  for (let i = flares.length - 1; i >= 0; i--){
    const f = flares[i];
    f.t += dt;
    f.px = f.x; f.py = f.y;                 /* 上一帧位置，画拖尾 */
    const nx = f.x + f.vx * dt, ny = f.y + f.vy * dt;
    let hit = false;
    if (L && L.walls){
      for (const w of L.walls){
        if (w.dead) continue;
        if (nx > w.x - 3 && nx < w.x + w.w + 3 && ny > w.y - 3 && ny < w.y + w.h + 3){ hit = true; break; }
      }
    }
    f.x = nx; f.y = ny;
    f.vy += 46 * dt;                       /* 稍微往下坠，看着像抛出去的一发 */
    const dk = Math.max(0, 1 - FLARE_DRAG * dt);
    f.vx *= dk; f.vy *= dk;
    if (fxRand(0, 1) < 0.85)
      spawnPart(f.x, f.y, fxRand(0, TAU), fxRand(15, 70), fxRand(0.18, 0.45), 'gold', fxRand(1.4, 2.8));
    if (hit || f.t >= FLARE_LIFE){
      flares.splice(i, 1);
      dropFlareAt(f.x, f.y);
    }
  }
  for (let i = signalSpots.length - 1; i >= 0; i--){
    const s = signalSpots[i];
    s.t -= dt;
    if (s.t > 0) continue;
    signalSpots.splice(i, 1);
    airDrops.push({ x: s.x + fxRand(-AIR_SPREAD, AIR_SPREAD),
                    y: s.y + fxRand(-AIR_SPREAD, AIR_SPREAD), alt: AIR_FALL_H });
    setMsg('空投来了 · 抬头看天', 2.2);
    beep(200, 0.55, 'sine', 0.16, 900);
    logInfo('item', '空投开始下落');
  }
}

function drawFlares(){
  for (const f of flares){
    if (!cullPt(f.x, f.y, 46)) continue;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    /* 拖尾：从上一帧的位置拉一条渐隐红带（一帧 880px/s ≈ 14px，肉眼看就是短短一截） */
    if (f.px !== undefined && f.px !== f.x){
      const lg = ctx.createLinearGradient(f.px, f.py, f.x, f.y);
      lg.addColorStop(0, 'rgba(255,70,80,0)');
      lg.addColorStop(1, 'rgba(255,110,110,0.55)');
      ctx.strokeStyle = lg;
      ctx.lineWidth = 5.5;
      ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(f.px, f.py); ctx.lineTo(f.x, f.y); ctx.stroke();
    }
    const g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, 26);
    g.addColorStop(0, 'rgba(255,190,190,0.98)');
    g.addColorStop(0.28, 'rgba(255,96,100,0.55)');
    g.addColorStop(1, 'rgba(255,40,40,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(f.x, f.y, 26, 0, TAU); ctx.fill();
    ctx.fillStyle = '#fff6f6';
    ctx.beginPath(); ctx.arc(f.x, f.y, 3.2, 0, TAU); ctx.fill();
    ctx.restore();
  }
  for (const s of signalSpots){
    if (!cullPt(s.x, s.y, 120)) continue;
    /* 红烟柱：越往上越大越淡 */
    ctx.save();
    for (let i = 0; i < 6; i++){
      const k = i / 5;
      const yy = s.y - 12 - k * 66;
      const r = 20 + k * 15;
      const xx = s.x + Math.sin(s.t * 1.4 + i * 1.7) * (5 + k * 8);
      const al = 0.30 * (1 - k * 0.55);
      const pg = ctx.createRadialGradient(xx, yy, 0, xx, yy, r);
      pg.addColorStop(0, 'rgba(228,64,74,' + al.toFixed(3) + ')');
      pg.addColorStop(0.55, 'rgba(198,42,52,' + (al * 0.55).toFixed(3) + ')');
      pg.addColorStop(1, 'rgba(170,30,40,0)');
      ctx.fillStyle = pg;
      ctx.beginPath(); ctx.arc(xx, yy, r, 0, TAU); ctx.fill();
    }
    /* 地上一圈脉冲红环 */
    const pulse = (Math.sin(s.t * 4) * 0.5 + 0.5);
    ctx.strokeStyle = 'rgba(255,90,96,' + (0.35 + 0.4 * pulse).toFixed(3) + ')';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(s.x, s.y, 26 + pulse * 10, 0, TAU); ctx.stroke();
    /* 倒计时 */
    ctx.fillStyle = 'rgba(255,188,188,0.96)';
    ctx.font = 'bold 14px system-ui, "Microsoft YaHei", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('空投 ' + Math.ceil(s.t) + 's', s.x, s.y - 96);
    ctx.textAlign = 'left';
    ctx.restore();
  }
}

/* 落地撒点：同心圆 + 每圈等角 + 最小间距 36px。
   （之前箱子用 fxRand(26,46) 随机撒，十几件物资糊成一坨，鼠标根本点不到想要的那件） */
function airSpots(w, count){
  const cx = w.x + w.w / 2, cy = w.y + w.h / 2;
  const out = [];
  for (let ring = 0; ring < 5 && out.length < count; ring++){
    const r = 80 + ring * 36;
    const n = 7 + ring * 3;
    for (let i = 0; i < n && out.length < count; i++){
      const a = (i / n) * TAU + ring * 0.31;
      let x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
      for (let tries = 0; tries < 14; tries++){
        const okCrate = distToRect(x, y, w) > 26;
        let okItems = true;
        for (const p of out){ if (Math.hypot(p.x - x, p.y - y) < 36){ okItems = false; break; } }
        if (okCrate && okItems) break;
        x += Math.cos(a) * 12; y += Math.sin(a) * 12;
      }
      out.push({ x: x, y: y });
    }
  }
  return out;
}

/* 空投落地：变回一个能搜的箱子（和木箱同一套，只是 lootKind 换成 air） */
function spawnAirCrate(d){
  const L = cur();
  if (!L || !L.walls) return;
  const bd = coverMake('crateAir', { x: d.x - 60, y: d.y - 22 });
  const w = {
    x: bd.x, y: bd.y, w: bd.w, h: bd.h, brk: true, mat: bd.mat || 'metal',
    cov: bd.cov, ch: bd.ch, sight: bd.sight || 'high',
    loot: true, lootKind: 'air', opened: false, searchT: 0,
    maxHp: bd.hp || BRK_HP, hp: bd.hp || BRK_HP,
    seed: ((d.x | 0) * 37 + (d.y | 0) * 91) | 0,
    hitT: 0, dead: false, cracks: null
  };
  makeCracks(w); makeSegs(w);
  L.walls.push(w);
  wallGeomVer++;
  if (L.allWalls) L.allWalls.push(w);
  if (typeof navPatchRect === 'function') navPatchRect(L, w.x, w.y, w.w, w.h);
  else navCache = null;
  try { staticInvalidate(); } catch (err) {}
  camShake = Math.max(camShake, 0.5);
  for (let i = 0; i < 20; i++)
    spawnPart(d.x, d.y, fxRand(0, TAU), fxRand(70, 280), fxRand(0.25, 0.6), 'dust', fxRand(4, 9));
  beep(66, 0.26, 'sine', 0.30, 260);
  setMsg('空投落地了 · 走过去按 ' + keyLabel(BINDS.interact) + ' 开箱', 2.6);
  logInfo('item', '空投落地');
}

/* 空投专属掉落：不走权重表，必给的先用，再用概率补火箭筒 */
function dropAirCrate(w){
  const spots = airSpots(w, 18);
  let si = 0;
  const cx = w.x + w.w / 2, cy = w.y + w.h / 2;
  const put = (extra) => {
    const p = spots[si++] || { x: cx + fxRand(-70, 70), y: cy + 190 };
    loots.push(Object.assign({ x: p.x, y: p.y, taken: false, cool: 0.45, fromSearch: true, newT: 3.2 }, extra));
  };
  /* 三级甲（精锐）：耐久 85%~100%，空投里的东西不该是残的 */
  const AD = (typeof ARMOR_DEF !== 'undefined' && ARMOR_DEF.elite) || null;
  const adur = AD ? AD.dur : 250;
  put({ kind:'armor', armor:'elite', hp: Math.max(1, Math.round(adur * fxRand(0.85, 1))), maxHp: adur });
  /* 三级包（远征） */
  put({ kind:'bag', bag:'big' });
  /* 绿药包（大号医疗包）：3~5 个 */
  const nMeds = 3 + Math.floor(fxRand(0, 3));
  for (let i = 0; i < nMeds; i++) put({ kind:'med', rarity:'big' });
  /* 各种子弹：四种口径，各 1~2 盒 */
  const TYPES = ['pistol', 'shotgun', 'rifle', 'ar'];
  for (const t of TYPES){
    const A = ammoDef(t);
    const nb = 1 + Math.floor(fxRand(0, 2));
    for (let i = 0; i < nb; i++) put({ kind:'ammo', ammo:t, n: A.box });
  }
  /* 较大概率：一把火箭筒 + 1~6 发火箭弹（一个落地物代表一堆，捡的时候自动分格） */
  if (fxRand(0, 1) < AIR_RPG_CH){
    put({ kind:'gun', wid:'rpg', mag:0 });
    const nr = 1 + Math.floor(fxRand(0, 6));
    put({ kind:'ammo', ammo:'rocket', n: nr });
  }
  /* 空投里【不放】信号弹：不然就是无限刷空投 */
}

function updateAirdrops(dt){
  for (let i = airDrops.length - 1; i >= 0; i--){
    const d = airDrops[i];
    d.alt -= AIR_FALL_SPD * dt;
    if (d.alt <= 0){
      d.alt = 0;
      airDrops.splice(i, 1);
      spawnAirCrate(d);
    }
  }
}

function drawAirdrops(){
  for (const d of airDrops){
    const yy = d.y - d.alt;
    const near = clamp(1 - d.alt / AIR_FALL_H, 0, 1);
    /* 地上那个影子：越高越淡越大 */
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,' + (0.10 + 0.30 * near).toFixed(3) + ')';
    ctx.beginPath();
    ctx.ellipse(d.x, d.y, 44 + 26 * near, 14 + 8 * near, 0, 0, TAU);
    ctx.fill();
    ctx.restore();
    /* 到画面外就不画了（但影子留着，方便知道落点） */
    if (yy < -260) continue;
    ctx.save();
    /* 箱体 */
    ctx.fillStyle = '#3b2b30';
    roundRect(d.x - 27, yy - 11, 54, 22, 3); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#ff5d6c';
    ctx.fillRect(d.x - 27, yy - 3.5, 54, 7);
    ctx.fillStyle = 'rgba(255,220,220,0.85)';
    ctx.fillRect(d.x - 9, yy - 2, 18, 4);
    /* 降落伞：大伞面（以前只有箱子那么宽，远看跟没有伞一样） */
    const sway = Math.sin(timeAlive * 1.4) * 3;
    const ux = d.x + sway;                    /* 伞心（带一点摆动） */
    const CW = 66, CH = 54, BY = yy - 78;     /* 伞半宽 / 伞高 / 伞沿高度 */
    /* 吊索：箱子四角 → 伞沿 */
    ctx.strokeStyle = 'rgba(228,232,238,0.70)'; ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(d.x - 24, yy - 11); ctx.lineTo(ux - CW * 0.86, BY + 2);
    ctx.moveTo(d.x + 24, yy - 11); ctx.lineTo(ux + CW * 0.86, BY + 2);
    ctx.moveTo(d.x - 10, yy - 11); ctx.lineTo(ux - CW * 0.34, BY + 2);
    ctx.moveTo(d.x + 10, yy - 11); ctx.lineTo(ux + CW * 0.34, BY + 2);
    ctx.stroke();
    /* 伞布：上半椭圆 */
    ctx.fillStyle = 'rgba(242,242,247,0.95)';
    ctx.beginPath();
    ctx.ellipse(ux, BY, CW, CH, 0, Math.PI, Math.PI * 2);
    ctx.closePath(); ctx.fill();
    /* 底边的荷叶边（四个小弧，让伞沿不是一条死直线） */
    ctx.beginPath();
    for (let i = 0; i < 4; i++){
      const x1 = ux - CW + (CW / 2) * i;
      ctx.moveTo(x1, BY);
      ctx.quadraticCurveTo(x1 + CW / 4, BY + 10, x1 + CW / 2, BY);
    }
    ctx.fill();
    /* 中间那块红伞布 */
    ctx.fillStyle = 'rgba(226,86,96,0.92)';
    ctx.beginPath();
    ctx.moveTo(ux, BY - CH);
    ctx.lineTo(ux - CW * 0.30, BY + 1);
    ctx.quadraticCurveTo(ux, BY + 9, ux + CW * 0.30, BY + 1);
    ctx.closePath(); ctx.fill();
    /* 伞骨 */
    ctx.strokeStyle = 'rgba(150,154,162,0.62)'; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(ux, BY - CH); ctx.lineTo(ux - CW * 0.55, BY + 1);
    ctx.moveTo(ux, BY - CH); ctx.lineTo(ux + CW * 0.55, BY + 1);
    ctx.stroke();
    /* 伞沿描边 */
    ctx.strokeStyle = 'rgba(120,124,132,0.85)'; ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.ellipse(ux, BY, CW, CH, 0, Math.PI, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

