function combatFaction(e){return e===player?'player':(e&&e.faction)||(e&&e.team)||'enemy';}
function combatHostile(a,b){
  if(!a||!b||a===b)return false;
  const fa=combatFaction(a),fb=combatFaction(b);
  if(fa===fb||fa==='neutral'||fb==='neutral')return false;
  /* 谁跟谁打现在由 data/factions.js 的 FACTION_DEF 说了算：
     A 势力(enemy) 与 B 势力(bandit) 天生敌对；B 对玩家中立（被打才记仇）。 */
  if(typeof factionWantsFight==='function')return factionWantsFight(a,b);
  if(typeof factionsHostile==='function')return factionsHostile(fa,fb);
  return true;
}
function combatCanDamage(source,target){
  if(!target||target.dead)return false;
  // Preserve existing enemy-on-enemy blast rules; player-side immunity is explicit.
  if(combatFaction(source)==='player'&&combatFaction(target)==='player'){
    if(source===target)return true; // existing self-explosion behavior
    return companionRules.friendlyFire;
  }
  return true;
}
/* 弹体是否应被这具身体拦下。玩家可以主动攻击中立 B，NPC 则必须确实把目标
   视为敌对；同阵营只保留噩梦模式下玩家/队友之间的友伤。 */
function combatCanProjectileHit(source,target){
  /* 旧关卡/测试里的环境弹体没有 by。它们过去默认能命中玩家，继续保留；
     只有带明确射手的 NPC 弹体才进入阵营过滤。 */
  if(!target)return false;
  if(!source)return true;
  if(source===target||!combatCanDamage(source,target))return false;
  const fs=combatFaction(source),ft=combatFaction(target);
  if(fs===ft)return fs==='player'&&companionRules.friendlyFire;
  if(fs==='player')return true;
  return combatHostile(source,target);
}
/* 战斗判定的第一层公开门面。现阶段只包装弹体阵营许可，实际规则仍由旧函数
   唯一决定；调用方可传入复用结果对象，后续热路径迁移不会被迫逐弹分配。 */
const CombatQuery=Object.freeze({
  version:1,
  projectilePermission:function(request,result){
    const source=request&&request.source,target=request&&request.target;
    const out=result||{};
    out.kind='projectile';out.source=source;out.target=target;
    /* 阵营关系由旧函数内部计算；这里不重复扫描，热路径迁移后保持原开销级别。 */
    out.sourceFaction=null;out.targetFaction=null;
    out.allowed=combatCanProjectileHit(source,target);
    out.blockedReason=out.allowed?null:'combat-rule';
    out.hitEntity=out.allowed?target:null;
    out.damage=null;out.penetrationRemaining=null;out.effectHint=null;
    return out;
  },
  areaPermission:function(request,result){
    const source=request&&request.source,target=request&&request.target;
    const out=result||{};
    out.kind='area';out.source=source;out.target=target;
    out.sourceFaction=null;out.targetFaction=null;
    out.allowed=combatCanAreaHit(source,target);
    out.blockedReason=out.allowed?null:'combat-rule';
    out.hitEntity=out.allowed?target:null;
    out.damage=null;out.penetrationRemaining=null;out.effectHint=null;
    return out;
  }
});
/* 爆炸沿用原有 NPC 同阵营溅射；跨阵营仍需敌对。玩家主动攻击中立单位合法，
   但中立 B 的误飞爆炸不能先手伤害玩家。 */
function combatCanAreaHit(source,target){
  if(!source)return true;
  if(!target||source===target||!combatCanDamage(source,target))return source===target;
  const fs=combatFaction(source),ft=combatFaction(target);
  if(fs===ft){
    if(fs==='player')return source===target||companionRules.friendlyFire;
    return true;
  }
  if(fs==='player')return true;
  return combatHostile(source,target);
}

function companionDamage(e,dmg,source,kind,ang){
  if(!e||e.dead||!combatCanDamage(source,e)||!(dmg>0))return 0;
  const real=absorbEnemyArmor(e,dmg,kind||'bullet');e.hp=Math.max(0,e.hp-real);
  eStatusSet(e,'hurt',0.25);e.coverCd=0;
  spawnDamageNum(e.x,e.y-25,real,e.hp<=0,false);
  // Never call alertByHit: it would aim suppressive fire back at the player.
  if(combatFaction(source)==='player'){
    if(!(e.complaintCd>0)){e.bark='别打自己人！我换个位置！';e.barkT=2.5;e.complaintCd=3;}
    e.avoidT=1.2;e.avoidGoal=null;e.friendlyThreat={x:source.x,y:source.y};
  }
  if(e.hp<=0){
    companionBreakPair(e);
    e.dead=true;e._settled=true;addCorpse(e,(ang||0)+Math.PI);
    const i=allies.indexOf(e);if(i>=0)allies.splice(i,1);
    setMsg('一名队友倒下了',2);
  }
  return real;
}
function combatFinishNPC(e,source,ang,fallen){
  /* NPC 之间互相击杀只留尸体，不冒领玩家分数、掉落和清波奖励。 */
  if(source&&combatFaction(source)!=='player'){
    if(fallen)fallen.push(e);
    else if(typeof humanComradeFall==='function')humanComradeFall(e,source);
    addCorpse(e,(ang||0)+Math.PI);
    e.dead=true;e._settled=true;
    const i=enemies.indexOf(e);if(i>=0)enemies.splice(i,1);
    return;
  }
  killTestEnemy(e,fallen);
}
function combatDamageNPC(e,dmg,source,kind,ang){
  if(e.controller==='companion')return companionDamage(e,dmg,source,kind,ang);
  if(e.dead||!combatCanDamage(source,e))return 0;
  const real=absorbEnemyArmor(e,dmg,kind||'bullet');e.hp=(e.hp===undefined?100:e.hp)-real;
  registerHit(e,ang||0,real,e.hp<=0,false,source||null);spawnDamageNum(e.x,e.y-30,real,e.hp<=0,false);
  if(typeof factionNoteDamage==='function')factionNoteDamage(e,source,real,kind||'bullet');
  if(e.hp<=0)combatFinishNPC(e,source,ang);
  else if(source===player)alertByHit(e,ang||0);
  else if(source&&combatHostile(e,source)){
    e.combatTargetId=combatId(source);
    /* 玩家命中和 NPC 命中走同一战术入口：转身、压制、找掩体、叫同伴都由
       alertByHit 处理，目标实体显式传入，不再复制一份“只会站撸”的简化逻辑。 */
    alertByHit(e,ang||0,source);
  }
  return real;
}
const CombatDamage=Object.freeze({
  version:1,
  applyNPC:function(request){
    return combatDamageNPC(request.target,request.damage,request.source,request.kind,request.angle);
  }
});
function companionDamagePlayer(b){
  if(!combatCanDamage(b.by,player))return;
  const hit=playerShieldBulletHit(b);
  if(hit){playerShieldImpact(b,hit);return;}
  if(player.god){player.flash=1;return;}
  const dmg=guardDamage(b.dmg*(ar?(1-(ar.armor||0)):1));
  player.hp-=absorbArmor(dmg,'bullet');hurtNum(dmg);stOnHurt(dmg,'bullet');
  player.flash=1;hitFlash=1;camShake=Math.max(camShake,.55);sfxHurt();
  if(player.hp<=0)markDeath('bullet',b.by,dmg,Math.atan2(b.vy,b.vx));
}
/* Swept segment/circle entry, rather than frame-end overlap. */
function combatSegmentEntry(x,y,dx,dy,e,pad){
  const len=Math.hypot(dx,dy);if(!len)return dist(x,y,e.x,e.y)<(e.r||12)+pad?0:null;
  const ux=dx/len,uy=dy/len,ex=e.x-x,ey=e.y-y,r=(e.r||12)+pad;
  const along=ex*ux+ey*uy,perp=ex*ex+ey*ey-along*along;
  if(perp>r*r)return null;const h=Math.sqrt(Math.max(0,r*r-perp));
  if(along+h<0||along-h>len)return null;return Math.max(0,along-h);
}
/* 只在实际飞到目标侧面时判一次近失弹。墙、车壳和先命中的人体都会截断它。 */
function projectileNearMiss(b,dx,dy,len,stop){
  const L=cur(), source=b.by;
  if (b.rocket || !humanOn(L) || !Number.isFinite(source.x) || !Number.isFinite(source.y)) return;
  const ux=dx/len, uy=dy/len, radius=HUMAN.nearMiss;
  const consider=e=>{
    if (!e || e.dead || e.hp<=0 || e===source || e.tucked || e.boss || e.devCalm) return;
    const ex=e.x-b.px, ey=e.y-b.py, along=ex*ux+ey*uy;
    if (along<=0 || along>len || along>=stop) return;
    const off=Math.abs(ex*uy-ey*ux);
    if (off<=(e.r || 12)+6 || off>radius || !factionWantsFight(e,source) || eStatusHas(e,'stun')) return;
    const T=enemyType(e);
    if (T.static || T.fly || eStatusHas(e,'fear')) return;
    if (losBlocked(b.px+ux*along,b.py+uy*along,e.x,e.y,true)) return;
    humanFear(e,L,HUMAN.fearP*0.8,null,source);
  };
  factionSpatialSegmentCandidates(b.px,b.py,b.x,b.y,radius,consider);
}
const _COMPANION_PROJECTILE_REQUEST={source:null,target:null};
const _COMPANION_PROJECTILE_RESULT={};
const _COMPANION_PROJECTILE_DAMAGE={source:null,target:null,damage:0,kind:'bullet',angle:0};
/* Return true only if a body consumed the projectile before any solid obstacle.
   名字为兼容旧测试保留；现在它是所有 NPC 弹体的统一人体命中入口。 */
function companionBulletHit(b, truckHit){
  if(!b||!b.by)return false;
  const dx=b.x-b.px,dy=b.y-b.py,len=Math.hypot(dx,dy);if(!len)return false;
  let limit=len+1,best=null,bestT=limit;
  const obstacle=w=>{const t=rayEnter(b.px,b.py,dx/len,dy/len,w,len);if(t>=0)limit=Math.min(limit,t);};
  /* m45306：炮塔炮弹穿墙 —— 墙不参与"最远有效位置"的裁切，也别让墙把弹丸吃掉 */
  if(!b.turretRocket){
    for(const w of cur().walls)if(!w.dead&&!(b.rocket&&w.glass))obstacle(w);
  }
  if(truckHit===undefined)truckHit=projectileTruckHit(b);
  if(truckHit)limit=Math.min(limit,truckHit.distance);
  if(b.rocket&&!b.turretRocket)for(const d of doors)if(doorSolid(d))obstacle(d);
  /* 解算落点就是这发火箭的最远有效飞行位置。落点后方的人体不能抢先吃掉弹丸；
     落点前的人体仍按正常碰撞提前引爆。 */
  if(b.rocket&&typeof rocketLandingFusePoint==='function'){
    const fuse=rocketLandingFusePoint(b);if(fuse)limit=Math.min(limit,fuse.d+1e-4);
  }
  _COMPANION_PROJECTILE_REQUEST.source=b.by;
  const consider=e=>{
    if(!e||e.dead||e===b.by)return;
    _COMPANION_PROJECTILE_REQUEST.target=e;
    if(!CombatQuery.projectilePermission(_COMPANION_PROJECTILE_REQUEST,_COMPANION_PROJECTILE_RESULT).allowed)return;
    const t=combatSegmentEntry(b.px,b.py,dx,dy,e,b.rocket?8:3);
    if(t!==null&&t<limit&&t<bestT){best=e;bestT=t;}
  };
  consider(player);for(const e of allies)consider(e);
  if(typeof factionSpatialSegmentCandidates==='function')
    factionSpatialSegmentCandidates(b.px,b.py,b.x,b.y,b.rocket?28:18,consider);
  else for(const e of enemies)consider(e);
  projectileNearMiss(b,dx,dy,len,Math.min(bestT,limit));
  if(!best)return false;
  b.x=b.px+dx/len*bestT;b.y=b.py+dy/len*bestT;
  if(b.rocket)rocketBlast(b.x,b.y,b.by);
  else {
    // Doors can be penetrated; only those before the body receive this shot.
    if(doors.length)doorHitAlongShot(b);
    if(best===player)companionDamagePlayer(b);
    else {
      _COMPANION_PROJECTILE_DAMAGE.target=best;
      _COMPANION_PROJECTILE_DAMAGE.damage=b.dmg;
      _COMPANION_PROJECTILE_DAMAGE.source=b.by;
      _COMPANION_PROJECTILE_DAMAGE.angle=Math.atan2(dy,dx);
      CombatDamage.applyNPC(_COMPANION_PROJECTILE_DAMAGE);
    }
  }
  return true;
}
