/* ================= 破碎残留物（Decals）=================
   纯粹的地面装饰：不进 L.walls、不进寻路、不参与子弹判定，
   所以无论留多少都挡不住人/弹。形状参数在 data/debris.js，这里只管画。 */
let decals = [];                 /* {k:种类, x,y,w,h, seed} —— 只存矩形与种子，碎片每帧现算 */

function decalKindOf(w){
  if (!w) return 'stone';
  if (w.glass) return 'glass';
  if (w.cov === 'crate' || w.cov === 'crate2' || w.cov === 'lootcrate') return 'wood';
  if (w.mat === 'metal') return 'metal';
  return 'stone';
}

function pushDecal(x, y, w, h, kind){
  if (typeof DEBRIS_DEF === 'undefined' || !DEBRIS_DEF[kind]) return;
  if (w < 2 || h < 2) return;
  const decal = { k: kind, x: x, y: y, w: w, h: h, seed: ((x | 0) * 13 + (y | 0) * 7 + decals.length * 29) | 0 };
  decals.push(decal);
  const cap = DEBRIS_DEF.pool || 200;
  if (decals.length > cap) decals.splice(0, decals.length - cap);   /* 超了顶掉最旧的 */
  return decal;
}

/* ============================================================
   物资堆的画法（第 28 轮）
   ------------------------------------------------------------
   三态只改"散开的程度 + 还剩几件"：
     0 没搜过 = 一堆鼓着的，东西挤在中间、互相压着
     1 搜过几次 = 明显变少变散，中间空出来一块
     2 搜空了 = 只剩边上一圈破烂
   位置用 covHash 按 seed 算，所以每堆不一样、每帧一样，不会抖。
   颜色从 LOOT_SKIN.pile.junk 里取，一个都不写死。
   ============================================================ */
function drawPiles(){
  if (!piles.length) return;
  const SK = (typeof LOOT_SKIN !== 'undefined' && LOOT_SKIN.pile) ? LOOT_SKIN.pile : null;
  const setOf = (k, dflt) => (SK && Array.isArray(SK[k]) && SK[k].length) ? SK[k] : dflt;
  const palWood    = setOf('wood',    ['#6b563f', '#5b4a36', '#7a6248']);
  const palCarton  = setOf('carton',  ['#8a6f4c', '#9c7f57', '#ab8d63']);
  const palMetal   = setOf('metal',   ['#6a7078', '#565c64', '#8d949c']);
  const palGlass   = setOf('glass',   ['rgba(150,205,190,0.62)', 'rgba(140,180,215,0.58)']);
  const palPlastic = setOf('plastic', ['#a8543c', '#3f6b8a', '#b8903a', '#4d7a52']);
  const palPaper   = setOf('paper',   ['#c9c2ae', '#b8b0a0', '#d8d2c0']);
  const palCloth   = setOf('junk',    ['#4a4034', '#5a5042', '#39322a']);
  const pick = (arr, r) => arr[Math.min(arr.length - 1, Math.floor(r * arr.length))];
  for (const p of piles){
    if (p.dead) continue;
    /* 一堆要画二十来件碎屑，11000² 的图有 300 多堆 —— 不裁剪的话每帧白画六七千个图形（实测 8ms/帧） */
    if (!cullPt(p.x + p.w / 2, p.y + p.h / 2, Math.max(p.w, p.h) / 2 + 90)) continue;
    const st = pileState(p);
    const X = p.x, Y = p.y, Wd = p.w, Ht = p.h;
    const cx = X + Wd / 2, cy = Y + Ht / 2;
    /* 摊得开：横向用满整个 AABB，纵向只占 0.36（平摊在地上的感觉） */
    const rx = Wd * 0.44, ry = Ht * 0.36;
    const n = st === 0 ? 24 : (st === 1 ? 13 : 5);
    /* 三态都摊开：搜空之后剩的几件是"散在地上"，不是缩成一坨 */
    const shrink = st === 0 ? 1 : 0.96;
    /* ① 底：地面被压出来的污渍，三态都画 */
    ctx.fillStyle = st === 2 ? 'rgba(0,0,0,0.08)' : 'rgba(0,0,0,0.12)';
    ctx.beginPath();
    ctx.ellipse(cx, cy + Ht * 0.08, Wd * 0.48, Ht * 0.40, 0, 0, TAU);
    ctx.fill();

    const spot = (i) => {
      const a = covHash(p.seed + i * 71, 3) * TAU;
      const rr = 0.15 + covHash(p.seed + i * 71, 11) * 0.92;
      return [cx + Math.cos(a) * rx * rr * shrink,
              cy + Math.sin(a) * ry * rr * shrink * 0.92 + (st === 2 ? Ht * 0.08 : 0)];
    };
    const soft = (bx, by, bw, bh) => {                 /* 每件东西底下那道影 */
      ctx.fillStyle = 'rgba(6,5,4,0.45)';
      ctx.fillRect(bx - bw / 2 + 1, by - bh / 2 + 1.3, bw, bh);
    };
    /* ② 大件先垫底：木箱 / 纸箱 / 一坨布 —— 堆子之所以"鼓"靠它们 */
    for (let i = 0; i < n; i++){
      const tp = covHash(p.seed + i * 71, 43);
      if (tp >= 0.46) continue;
      const [bx, by] = spot(i);
      const rot = (covHash(p.seed + i * 71, 5) - 0.5) * 0.9;
      const bw = Wd * (0.15 + covHash(p.seed + i * 71, 19) * 0.11);
      const bh = Ht * (0.30 + covHash(p.seed + i * 71, 29) * 0.26);
      const isCarton = tp >= 0.30;
      const col = pick(isCarton ? palCarton : palWood, covHash(p.seed + i * 71, 61));
      ctx.save();
      ctx.translate(bx, by); ctx.rotate(rot);
      soft(0, 0, bw, bh);
      ctx.fillStyle = col;
      ctx.fillRect(-bw / 2, -bh / 2, bw, bh);
      ctx.fillStyle = covMix(col, 1.22);               /* 顶面受光 */
      ctx.fillRect(-bw / 2, -bh / 2, bw, Math.max(1.2, bh * 0.22));
      ctx.fillStyle = 'rgba(8,7,5,0.50)';              /* 腰上一道缝 */
      ctx.fillRect(-bw / 2, -bh / 2 + bh * 0.58, bw, Math.max(0.8, bh * 0.06));
      ctx.restore();
    }
    /* ③ 小件压在上面：铁罐 / 玻璃片 / 塑料 / 纸 —— 这一层就是"宝贝的样子" */
    for (let i = 0; i < n; i++){
      const tp = covHash(p.seed + i * 71, 43);
      if (tp < 0.46) continue;
      const [bx, by] = spot(i);
      const rot = (covHash(p.seed + i * 71, 5) - 0.5) * 1.7;
      if (tp < 0.66){                                   /* 铁罐：躺着的圆柱 */
        const r = 3.4 + covHash(p.seed + i * 71, 19) * 3.2;
        ctx.save(); ctx.translate(bx, by); ctx.rotate(rot);
        soft(0, 0, r * 2.1, r * 1.7);
        ctx.fillStyle = pick(palMetal, covHash(p.seed + i * 71, 61));
        ctx.beginPath(); ctx.ellipse(0, 0, r * 1.05, r * 0.85, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(235,242,248,0.28)';
        ctx.beginPath(); ctx.ellipse(-r * 0.25, -r * 0.28, r * 0.52, r * 0.34, 0, 0, TAU); ctx.fill();
        ctx.restore();
      } else if (tp < 0.82){                            /* 玻璃片：半透明三角 + 一道反光 */
        const s = 5 + covHash(p.seed + i * 71, 19) * 6;
        ctx.save(); ctx.translate(bx, by); ctx.rotate(rot);
        ctx.fillStyle = pick(palGlass, covHash(p.seed + i * 71, 61));
        ctx.beginPath();
        ctx.moveTo(-s * 0.5, s * 0.4); ctx.lineTo(s * 0.55, s * 0.2); ctx.lineTo(-s * 0.1, -s * 0.55);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.42)';
        ctx.beginPath();
        ctx.moveTo(-s * 0.1, -s * 0.55); ctx.lineTo(s * 0.55, s * 0.2); ctx.lineTo(s * 0.15, s * 0.05);
        ctx.closePath(); ctx.fill();
        ctx.restore();
      } else if (tp < 0.92){                            /* 塑料：亮色小片，最扎眼 */
        const bw = 4 + covHash(p.seed + i * 71, 19) * 5, bh = 3 + covHash(p.seed + i * 71, 29) * 4;
        ctx.save(); ctx.translate(bx, by); ctx.rotate(rot);
        soft(0, 0, bw, bh);
        ctx.fillStyle = pick(palPlastic, covHash(p.seed + i * 71, 61));
        ctx.fillRect(-bw / 2, -bh / 2, bw, bh);
        ctx.restore();
      } else {                                          /* 纸 / 布片：浅色一片，压住一块 */
        const bw = 6 + covHash(p.seed + i * 71, 19) * 6, bh = 4 + covHash(p.seed + i * 71, 29) * 3;
        ctx.save(); ctx.translate(bx, by); ctx.rotate(rot);
        ctx.fillStyle = 'rgba(6,5,4,0.35)';
        ctx.fillRect(-bw / 2 + 0.8, -bh / 2 + 1, bw, bh);
        ctx.fillStyle = pick(palPaper, covHash(p.seed + i * 71, 61));
        ctx.fillRect(-bw / 2, -bh / 2, bw, bh);
        ctx.restore();
      }
    }
    /* ④ 最上面再撒两块碎布/破箱子，把缝补一下（没搜过的才有） */
    if (st === 0){
      for (let k = 0; k < 2; k++){
        const r5 = covHash(p.seed + 977 + k * 41, 5), r6 = covHash(p.seed + 977 + k * 41, 13);
        const ox = cx + (r5 - 0.5) * Wd * 0.52, oy = cy + (r6 - 0.5) * Ht * 0.34;
        const bw = Wd * 0.13, bh = Ht * 0.20;
        ctx.save(); ctx.translate(ox, oy); ctx.rotate((r5 - 0.5) * 1.1);
        soft(0, 0, bw, bh);
        ctx.fillStyle = pick(palCloth, r6);
        ctx.fillRect(-bw / 2, -bh / 2, bw, bh);
        ctx.fillStyle = covMix(pick(palCloth, r6), 1.3);
        ctx.fillRect(-bw / 2, -bh / 2, bw, 1.4);
        ctx.restore();
      }
    }
    /* 玩家在范围内：头顶给个提示（和箱子一个样式，好认） */
    if (!window.uiHideAll && player && !p.dead && typeof pileCfg === 'function' && pileCfg() &&
        distToRect(player.x, player.y, p) <= pileCfg().range){
      const by2 = Y - 8 + Math.sin(uiT * 4) * 1.5;
      ctx.save();
      ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(10,12,14,0.72)';
      ctx.fillRect(cx - 27, by2 - 10, 54, 13);
      ctx.fillStyle = (crateSearch && crateSearch.w === p) ? '#e8c579' : 'rgba(238,228,204,0.95)';
      ctx.fillText((crateSearch && crateSearch.w === p) ? '翻找中…' : '[' + keyLabel(BINDS.interact) + '] 翻找', cx, by2 - 1);
      ctx.textAlign = 'left';
      ctx.restore();
    }
  }
}

/* 把一片碎片挪进 [lo, hi]：放不下（框比碎片还窄）就摆在正中间，
   绝不溢出、也绝不裁成直边。 */
function clampFit(v, lo, hi){
  if (lo > hi) return (lo + hi) * 0.5;
  return v < lo ? lo : (v > hi ? hi : v);
}

function drawDecals(){
  if (!decals.length || typeof DEBRIS_DEF === 'undefined') return;
  for (let di = 0; di < decals.length; di++){
    const d = decals[di], def = DEBRIS_DEF[d.k];
    if (!def) continue;
    if (!cullPt(d.x, d.y, 70)) continue;
    /* 不是"铺格子"，是几坨砸出来的堆：
       ① 先在地上垫一层碎渣毯（盖住地板，不然碎块之间全是缝，看着像被打少了）
       ② 再绕着几个簇心堆大小不一的块，越靠中间越密、边上一圈稀稀拉拉
       位置全用 covHash(seed) 算，每块残留物长得不一样，但同一块每帧一样。 */
    const area = Math.max(1, d.w * d.h);
    const n = clamp(Math.round(area / (def.per || 1200)), def.n[0], Math.round(def.n[1] * 1.35));
    const base = Math.min(d.w, d.h);
    const cl = Math.max(2, Math.min(7, Math.round(n / 6)));
    const clX = [], clY = [];
    for (let c = 0; c < cl; c++){
      const a1 = covHash(d.seed + c * 211, 13), a2 = covHash(d.seed + c * 211, 29);
      clX.push(d.x + 0.16 * d.w + a1 * 0.68 * d.w);
      clY.push(d.y + 0.16 * d.h + a2 * 0.68 * d.h);
    }
    /* 第 40 轮：底下的"碎渣毯"整个删掉了。用户原话：「干脆直接去掉算了，多加点杂物，
       和小木屑什么的」—— 加垫底色怎么画都像贴纸，不如把碎块本身加多、加碎。 */
    for (let i = 0; i < n; i++){
      const r1 = covHash(d.seed + i * 97, 7), r2 = covHash(d.seed + i * 97, 23);
      const r3 = covHash(d.seed + i * 97, 41), r4 = covHash(d.seed + i * 97, 59);
      const r5 = covHash(d.seed + i * 97, 83), r6 = covHash(d.seed + i * 97, 101);
      const c = i % cl;
      const ang = r1 * TAU;
      const rad = Math.pow(r2, 0.62) * base * (0.30 + r6 * 0.22);   /* 幂次 <1 = 往中间挤 */
      const cell = base * (0.14 + r5 * 0.20);      /* 大小差得开：有整块，也有一把渣 */
      const col = def.tone[Math.floor(r3 * def.tone.length) % def.tone.length];
      /* 每片碎块按自己的实际大小把自己收进墙框里 —— 不是拿矩形去裁，
         而是"这块放不下就挪进来"。所以边缘不会出现直角切边，也不会碎到墙外面去。 */
      if (d.k === 'glass'){
        /* 碎玻璃：半透明白 / 浅蓝小三角，撒满一整片；块要小，大了就像贴纸 */
        const s = Math.max(1.6, Math.min(9, cell * (0.30 + r4 * 0.30)));
        const px = clampFit(clX[c] + Math.cos(ang) * rad, d.x + 0.5, d.x + d.w - s - 0.5);
        const py = clampFit(clY[c] + Math.sin(ang) * rad * 0.80, d.y + 0.5, d.y + d.h - s - 0.5);
        ctx.fillStyle = 'rgba(0,0,0,0.20)';           /* 一点底影，玻璃才不飘 */
        ctx.beginPath();
        ctx.moveTo(px + 0.8, py + 0.9);
        ctx.lineTo(px + s * 0.92, py + s * 0.30);
        ctx.lineTo(px + s * 0.16, py + s * 0.92);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px + s, py + s * (0.20 + r3 * 0.45));
        ctx.lineTo(px + s * (0.12 + r4 * 0.46), py + s * 0.92);
        ctx.closePath();
        ctx.fill();
      } else if (d.k === 'wood'){
        /* 碎木板：短条，顺着墙铺、左右歪开；偶尔一块特别长（整块板子没断透） */
        const big = (r6 > 0.86) ? 1.9 : 1;
        const L2 = Math.max(5, Math.min(40, cell * (0.85 + r4 * 0.75) * big));
        const H2 = Math.max(1.6, Math.min(5.5, cell * (0.20 + r3 * 0.18)));
        const a = (d.w > d.h ? 0 : 1.57) + (r1 - 0.5) * 1.3;
        /* 转过的板子占多宽多高：按旋转后的包围盒收进框里 */
        const hx2 = (Math.abs(Math.cos(a)) * L2 + Math.abs(Math.sin(a)) * H2) * 0.5;
        const hy2 = (Math.abs(Math.sin(a)) * L2 + Math.abs(Math.cos(a)) * H2) * 0.5;
        const px = clampFit(clX[c] + Math.cos(ang) * rad, d.x + hx2 + 0.4, d.x + d.w - hx2 - 0.4);
        const py = clampFit(clY[c] + Math.sin(ang) * rad * 0.80, d.y + hy2 + 0.4, d.y + d.h - hy2 - 0.4);
        ctx.save();
        ctx.translate(px, py);
        ctx.rotate(a);
        ctx.fillStyle = 'rgba(0,0,0,0.32)';
        ctx.fillRect(-L2 / 2 + 0.7, -H2 / 2 + 0.9, L2, H2);
        ctx.fillStyle = col;
        ctx.fillRect(-L2 / 2, -H2 / 2, L2, H2);
        ctx.fillStyle = 'rgba(198,178,144,0.10)';    /* 顶面受光：一条就够 */
        ctx.fillRect(-L2 / 2, -H2 / 2, L2, Math.max(0.7, H2 * 0.34));
        ctx.fillStyle = 'rgba(12,10,7,0.45)';
        ctx.fillRect(-L2 / 2, H2 / 2 - 0.8, L2, 0.8);
        ctx.restore();
      } else {
        /* 碎砖 / 铁片：不规则小块，大小错开（大块也给个上限，别糊成整面墙） */
        const s = Math.max(2.4, Math.min(15, cell * (0.50 + r4 * 0.50)));
        const px = clampFit(clX[c] + Math.cos(ang) * rad, d.x + 0.6, d.x + d.w - s - 0.6);
        const py = clampFit(clY[c] + Math.sin(ang) * rad * 0.80, d.y + s * 0.2 + 0.6, d.y + d.h - s * 0.95 - 0.6);
        ctx.fillStyle = 'rgba(0,0,0,0.30)';
        ctx.beginPath();
        ctx.moveTo(px + 0.8, py + 1.0);
        ctx.lineTo(px + s * (0.74 + r3 * 0.5), py - s * 0.16 + 1);
        ctx.lineTo(px + s + 1, py + s * (0.5 + r1 * 0.4) + 1);
        ctx.lineTo(px + s * 0.3 + 1, py + s * 0.92 + 1);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px + s * (0.70 + r3 * 0.5), py - s * 0.18);
        ctx.lineTo(px + s, py + s * (0.48 + r1 * 0.40));
        ctx.lineTo(px + s * 0.28, py + s * 0.90);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = 'rgba(210,216,224,0.08)';
        ctx.fillRect(px + s * 0.10, py - s * 0.04, s * 0.55, 0.8);
      }
    }
    /* 碎屑末：一堆 1~2px 的小渣撒在碎块之间。远看就是"这地方被砸碎了"，
       比垫一层底色自然得多（第 40 轮加）。 */
    const _specks = Math.round(n * 0.9);
    for (let i = 0; i < _specks; i++){
      const q1 = covHash(d.seed + i * 53 + 7, 131), q2 = covHash(d.seed + i * 53 + 7, 137);
      const q3 = covHash(d.seed + i * 53 + 7, 139), q4 = covHash(d.seed + i * 53 + 7, 149);
      const sx = clampFit(d.x + 1 + q1 * (d.w - 2), d.x + 0.5, d.x + d.w - 1.5);
      const sy = clampFit(d.y + 1 + q2 * (d.h - 2), d.y + 0.5, d.y + d.h - 1.5);
      const ss = 0.8 + q3 * 1.3;
      ctx.fillStyle = def.tone[Math.floor(q4 * def.tone.length) % def.tone.length];
      ctx.fillRect(sx, sy, ss, ss * (0.7 + q1 * 0.6));
    }
  }
}

/* 玻璃碎掉：比墙轻、碎片细长、没有灰尘，只有一片瞬间的碎光 */
function shatterGlass(w, hx, hy, ang){
  if (!w || w.dead) return;
  staticInvalidate();                    /* 墙上少了一块：静态层必须重画 */
  w.dead = true;
  const L = cur();
  const i = L.walls.indexOf(w);
  if (i >= 0){ L.walls.splice(i, 1); wallGeomVer++; }
  pushDecal(w.x, w.y, w.w, w.h, 'glass');   /* 满地碎玻璃渣，纯装饰 */
  navPatchRect(L, w.x, w.y, w.w, w.h);   /* 只重刷这一块，不再整张网重建 */
  const cxm = w.x + w.w/2, cym = w.y + w.h/2;
  const n = clamp(Math.round((w.w + w.h) / 26), 8, 34);
  for (let k = 0; k < n; k++){
    const px = w.x + Math.random()*w.w, py = w.y + Math.random()*w.h;
    const a = Math.atan2(py - cym, px - cxm) * 0.5 + ang * 0.5 + fxRand(-0.9, 0.9);
    const sp = fxRand(110, 430);
    brkChunks.push({
      x: px, y: py, vx: Math.cos(a)*sp, vy: Math.sin(a)*sp,
      s: fxRand(1.6, 4.2), rot: fxRand(0, TAU), vr: fxRand(-16, 16),
      t: 0, dur: fxRand(0.55, 1.15), glass: true,
      w: fxRand(3, 9), h: fxRand(6, 16)
    });
  }
  for (let k = 0; k < 6; k++){
    brkDust.push({x: w.x + Math.random()*w.w, y: w.y + Math.random()*w.h,
                  vx: fxRand(-40, 40), vy: fxRand(-40, 40),
                  r: fxRand(3, 7), t: 0, dur: fxRand(0.25, 0.5), glass: true});
  }
  camShake = Math.max(camShake, 0.22);
  brkShake = Math.max(brkShake, 0.06);
  if (!(glassSndT > 0)){ glassSndT = 0.11; sfxGlass(0.62, cxm, cym); }
}

/* 玻璃面板：半透明 + 铝合金框 + 一道斜的反光 */
function drawGlassPane(w){
  const g = ctx.createLinearGradient(w.x, w.y, w.x + w.w, w.y + w.h);
  g.addColorStop(0, 'rgba(150,196,214,0.20)');
  g.addColorStop(0.45, 'rgba(120,170,196,0.12)');
  g.addColorStop(1, 'rgba(160,204,222,0.18)');
  ctx.fillStyle = g;
  ctx.fillRect(w.x, w.y, w.w, w.h);
  ctx.strokeStyle = 'rgba(178,190,198,0.55)';
  ctx.lineWidth = 2;
  ctx.strokeRect(w.x + 1, w.y + 1, w.w - 2, w.h - 2);
  ctx.beginPath();
  if (w.w >= w.h){ ctx.moveTo(w.x + w.w/2, w.y + 1); ctx.lineTo(w.x + w.w/2, w.y + w.h - 1); }
  else { ctx.moveTo(w.x + 1, w.y + w.h/2); ctx.lineTo(w.x + w.w - 1, w.y + w.h/2); }
  ctx.stroke();
  ctx.strokeStyle = 'rgba(226,244,255,0.30)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(w.x + w.w*0.18, w.y + w.h*0.82);
  ctx.lineTo(w.x + w.w*0.52, w.y + w.h*0.18);
  ctx.stroke();
  if (w.hitT > 0){
    ctx.fillStyle = 'rgba(240,252,255,' + (w.hitT * 2.0).toFixed(2) + ')';
    ctx.fillRect(w.x, w.y, w.w, w.h);
  }
}

/* 一整块（或其中一段）墙崩掉时的碎块与灰。sliced=true 只是卸掉一段：动静小一号 */
function wallBurstRect(x, y, w, h, ang, sliced){
  const cols = Math.max(2, Math.round(w / 62));
  const rows = Math.max(2, Math.round(h / 62));
  const cw = w / cols, chh = h / rows;
  const cxm = x + w/2, cym = y + h/2;
  for (let cy = 0; cy < rows; cy++){
    for (let cx = 0; cx < cols; cx++){
      const px = x + cw*(cx + 0.5), py = y + chh*(cy + 0.5);
      /* 往外炸的方向 = 从墙心指向这块 + 一点弹道方向 */
      let a = Math.atan2(py - cym, px - cxm);
      a = a * 0.55 + ang * 0.45 + fxRand(-0.5, 0.5);
      const sp = fxRand(90, 340) * (0.7 + 0.5*Math.random());
      brkChunks.push({
        x: px, y: py, vx: Math.cos(a)*sp, vy: Math.sin(a)*sp,
        s: Math.min(cw, chh) * fxRand(0.30, 0.55),
        rot: fxRand(0, TAU), vr: fxRand(-10, 10),
        t: 0, dur: fxRand(0.75, 1.35), big: true,
        w: cw * fxRand(0.5, 0.85), h: chh * fxRand(0.5, 0.85)
      });
    }
  }
  /* 一团灰：sliced 时量少一点，不然打穿一小段却像整面墙倒了 */
  const puffs = clamp(Math.round((w + h) / 34), sliced ? 3 : 8, sliced ? 9 : 26);
  for (let i = 0; i < puffs; i++){
    brkDust.push({
      x: x + Math.random() * w, y: y + Math.random() * h,
      vx: fxRand(-46, 46) + Math.cos(ang)*40, vy: fxRand(-46, 46) + Math.sin(ang)*40,
      r: fxRand(8, 17), t: 0, dur: fxRand(1.1, 2.0)
    });
  }
  if (sliced){
    camShake = Math.max(camShake, 0.18);
    brkShake = Math.max(brkShake, 0.12);
    sfxCrack(true);
  }
}
/* 只卸掉一段（打哪段碎哪段） */
function sliceBurst(x, y, w, h, ang){ wallBurstRect(x, y, w, h, ang, true); }

/* 整面墙碎掉：从墙上摘掉 → 寻路自动重算 → 碎块 + 一大团灰 */
function shatterWall(w, ang){
  if (w.dead) return;
  w.dead = true;
  const L = cur();
  const i = L.walls.indexOf(w);
  if (i >= 0){ L.walls.splice(i, 1); wallGeomVer++; }
  const debris=pushDecal(w.x, w.y, w.w, w.h, decalKindOf(w));
  if (w.brk && w.mobaCover) mobaCoverDestroyed(w,debris);
  navPatchRect(L, w.x, w.y, w.w, w.h);   /* 这一块现在能走了；只刷这块，别整张重建 */

  wallBurstRect(w.x, w.y, w.w, w.h, ang, false);
  camShake = Math.max(camShake, 0.5);
  brkShake = 0.35;
  sfxCollapse();
  if (isTestZone()){
    logWarn('wall', '一堵墙被打穿了 · 位置 ' + Math.round(w.x) + ',' + Math.round(w.y) +
            ' · 现在这块能走过去');
  }
}

/* 射线打在破墙上：返回被打中的那块（没有就 null） */
function breakWallAt(ox, oy, ang, maxT){
  const dx = Math.cos(ang), dy = Math.sin(ang);
  let best = null, bestT = maxT + 1;
  for (const w of cur().walls){
    /* 装饰物（桌/椅）也在这里面 —— 它们 brk:false，只走 damageDecor 那条路 */
    if (!(w.brk || w.decor) || w.dead) continue;
    const t = rayEnter(ox, oy, dx, dy, w, maxT + 1);
    if (t >= 0.5 && t < bestT && t <= maxT + 0.6){ bestT = t; best = w; }
  }
  return best;
}

function updateBrkFx(dt){
  brkShake = Math.max(0, brkShake - dt * 1.4);
  if (glassSndT > 0) glassSndT = Math.max(0, glassSndT - dt);
  for (let i = brkChunks.length - 1; i >= 0; i--){
    const c = brkChunks[i];
    c.t += dt;
    if (c.t >= c.dur){ brkChunks.splice(i, 1); continue; }
    c.x += c.vx * dt; c.y += c.vy * dt;
    c.rot += c.vr * dt;
    const f = Math.max(0, 1 - dt * 3.2);
    c.vx *= f; c.vy *= f;
  }
  for (let i = brkDust.length - 1; i >= 0; i--){
    const d = brkDust[i];
    d.t += dt;
    if (d.t >= d.dur){ brkDust.splice(i, 1); continue; }
    d.x += d.vx * dt; d.y += d.vy * dt;
    const f = Math.max(0, 1 - dt * 1.6);
    d.vx *= f; d.vy *= f;
    d.r += dt * 9;                        /* 灰尘会散开 */
  }
}

/* 墙本体：水泥底 + 麻点 + 随血条长出来的裂纹 + 快碎时露出的钢筋 */
function drawBreakWall(w){
  if (w.glass){ drawGlassPane(w); return; }
  const dmg = 1 - Math.max(0, w.hp) / (w.hp0 || w.maxHp);
  if (!w.cracks) makeCracks(w);
  /* 整块墙都裁在自己矩形里：裂纹 / 麻点 / 砌缝都是按"原来那堵墙"的坐标画的，
     被挖掉一段之后矩形变小了，不裁就会画到空气上 */
  ctx.save();
  if (w.cut && (w.cut.l || w.cut.r || w.cut.t || w.cut.b)) breakClipPath(w);
  else { ctx.beginPath(); ctx.rect(w.x, w.y, w.w, w.h); }
  ctx.clip();
  /* 夜里是阴沉的旧水泥，不是白色的板子 —— 亮度压到只比普通墙高一点点，
     靠顶光、麻点和"竖着三道砌缝"认出来，不靠亮 */
  ctx.fillStyle = 'rgba(49,49,48,0.97)';
  ctx.fillRect(w.x, w.y, w.w, w.h);
  ctx.strokeStyle = 'rgba(20,19,18,0.9)';
  ctx.lineWidth = 2;
  ctx.strokeRect(w.x + 1, w.y + 1, w.w - 2, w.h - 2);
  ctx.fillStyle = 'rgba(150,149,145,0.13)';
  ctx.fillRect(w.x + 2, w.y + 2, w.w - 4, 4);
  ctx.fillStyle = 'rgba(8,8,7,0.30)';
  ctx.fillRect(w.x + 2, w.y + w.h - 6, w.w - 4, 4);
  /* 砌缝：三道横缝 + 一个错开的竖缝，远看是"砖砌的"，普通墙没有这个 */
  /* 砌缝按"这堵墙原来多大"排（gx/gy/gw/gh）：断成两截之后两边的缝还是同一条线下来的，
     不会每截都从自己 1/4 处重排一遍、看着像贴图在跳 */
  const gx = (w.gx !== undefined ? w.gx : w.x), gy = (w.gy !== undefined ? w.gy : w.y);
  const gw = (w.gw !== undefined ? w.gw : w.w), gh = (w.gh !== undefined ? w.gh : w.h);
  ctx.fillStyle = 'rgba(14,13,12,0.55)';
  if (gh >= gw){
    for (let i = 1; i <= 3; i++) ctx.fillRect(w.x + 2, gy + gh * i / 4, w.w - 4, 1.6);
    ctx.fillRect(gx + gw * 0.5, gy + gh * 0.25, 1.6, gh * 0.16);
    ctx.fillRect(gx + gw * 0.5, gy + gh * 0.75, 1.6, gh * 0.16);
  } else {
    for (let i = 1; i <= 3; i++) ctx.fillRect(gx + gw * i / 4, w.y + 2, 1.6, w.h - 4);
    ctx.fillRect(gx + gw * 0.25, gy + gh * 0.5, gw * 0.16, 1.6);
    ctx.fillRect(gx + gw * 0.75, gy + gh * 0.5, gw * 0.16, 1.6);
  }
  /* 麻点 */
  ctx.fillStyle = 'rgba(118,116,110,0.16)';
  for (const sp of w.specks){
    ctx.fillRect(sp[0], sp[1], sp[2], sp[2]);
  }
  /* 快碎的时候从缝里透出钢筋 */
  if (dmg > 0.55){
    const ra = Math.min(0.50, (dmg - 0.55) * 1.10);
    /* 断在混凝土里的钢：冷灰、只露一小截。
       横墙只画一两段、竖墙才画三段 —— 在扁墙上排三四条平行线会糊成一片横纹，
       那正是"贴图感"的来源；而且原来用的是锈橙色，在夜里的墙上一眼就看出是画的。 */
    ctx.strokeStyle = 'rgba(96,94,90,' + ra.toFixed(2) + ')';
    ctx.lineWidth = 1.2;
    const wide = (w.w > w.h);
    const n = wide ? Math.min(2, 1 + Math.floor((dmg - 0.55) * 3))
                   : Math.min(3, 1 + Math.floor((dmg - 0.55) * 5));
    for (let i = 0; i < n; i++){
      const yy = wide
        ? w.y + w.h * (0.34 + i * 0.26) + ((i * 7) % 5) - 2
        : w.y + w.h * (0.22 + i * 0.24) + ((i * 37) % 9) - 4;
      const x0 = w.x + 4 + ((i * 53) % Math.max(1, Math.floor(w.w * 0.34)));
      const len = w.w * (wide ? (0.14 + 0.08 * ((i * 29) % 4))
                              : (0.16 + 0.10 * ((i * 29) % 5)));
      ctx.beginPath();
      ctx.moveTo(x0, yy);
      ctx.lineTo(x0 + len * 0.55, yy + Math.sin(i * 2.7) * 2.4);
      ctx.stroke();
      if (dmg > 0.72 && i === 0){
        ctx.beginPath();
        ctx.moveTo(x0 + len * 0.55, yy + Math.sin(i * 2.7) * 2.4);
        ctx.lineTo(x0 + len, yy + Math.cos(i * 1.9) * 3);
        ctx.stroke();
      }
    }
  }
  /* 裂纹：一道一道长出来，越靠后越长越粗。暗底上用"亮边 + 暗芯"，
     像被凿开的一道缝，而不是一根黑线 */
  ctx.lineCap = 'round';
  /* 裂纹画两遍：先一道冷灰的"断口边"，再压一道近黑的芯。
     只描黑线在暗墙上根本看不见，描亮线又会变成一根根白刺 */
  for (const c of w.cracks){
    if (dmg < c.at) continue;
    const grow = clamp((dmg - c.at) / 0.10, 0, 1);      /* 刚露头时从短变长 */
    const n = Math.max(2, Math.ceil(c.pts.length * grow));
    for (let pass = 0; pass < 2; pass++){
      ctx.beginPath();
      for (let i = 0; i < n; i++){
        const px = c.pts[i][0], py = c.pts[i][1];
        if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      const lw = c.wdt * (0.45 + grow * 0.60);
      if (pass === 0){
        ctx.strokeStyle = 'rgba(150,148,143,' + (0.16 * grow).toFixed(2) + ')';
        ctx.lineWidth = lw + 1.1;
      } else {
        ctx.strokeStyle = 'rgba(10,10,11,' + (0.88 * grow).toFixed(2) + ')';
        ctx.lineWidth = lw;
      }
      ctx.stroke();
    }
  }
  ctx.restore();                          /* 结束"只画在自己矩形里"的裁剪 */
  /* 刚挨打那一下：整块亮一下，跟"打到了"对上 */
  if (w.hitT > 0){
    ctx.fillStyle = 'rgba(255,246,222,' + (w.hitT * 1.7).toFixed(3) + ')';
    ctx.fillRect(w.x, w.y, w.w, w.h);
  }
}

function drawBrkFx(){
  for (const d of brkDust){
    const k = d.t / d.dur, a = (1 - k) * 0.20;
    /* 由内到外越来越淡：中心也不厚，才像灰而不是球 */
    ctx.fillStyle = 'rgba(198,192,178,' + (a * 0.55).toFixed(3) + ')';
    ctx.beginPath(); ctx.arc(d.x, d.y, d.r * 0.55, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(198,192,178,' + (a * 0.40).toFixed(3) + ')';
    ctx.beginPath(); ctx.arc(d.x, d.y, d.r * 0.80, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(198,192,178,' + (a * 0.22).toFixed(3) + ')';
    ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, TAU); ctx.fill();
  }
  for (const c of brkChunks){
    const k = c.t / c.dur, a = (1 - k) * (c.big ? 0.95 : 0.85);
    ctx.save();
    ctx.globalAlpha = a;
    ctx.translate(c.x, c.y); ctx.rotate(c.rot);
    ctx.fillStyle = c.big ? 'rgba(126,120,110,0.98)' : 'rgba(188,182,170,0.98)';
    if (c.big){
      ctx.fillRect(-c.w/2, -c.h/2, c.w, c.h);
      ctx.strokeStyle = 'rgba(44,42,38,0.7)'; ctx.lineWidth = 1;
      ctx.strokeRect(-c.w/2, -c.h/2, c.w, c.h);
    } else {
      ctx.fillRect(-c.s/2, -c.s/2, c.s, c.s);
    }
    ctx.restore();
  }
}

/* 中弹的"啪"：一小段带通噪声，脆、短 */
function sfxCrack(soft){
  if (!actx) return;
  try {
    const t0 = actx.currentTime;
    const src = actx.createBufferSource(); src.buffer = noiseBuf;
    const bp = actx.createBiquadFilter(); bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1900, t0);
    bp.frequency.exponentialRampToValueAtTime(820, t0 + 0.11);
    bp.Q.value = 1.2;
    const g = actx.createGain();
    g.gain.setValueAtTime(soft ? 0.16 : 0.26, t0);
    g.gain.exponentialRampToValueAtTime(0.0008, t0 + (soft ? 0.10 : 0.14));
    src.connect(bp); bp.connect(g); g.connect(duckBus());
    src.start(t0); src.stop(t0 + 0.18);
  } catch(e){}
}

/* 塌下来的"哗啦"：一长段噪声从亮到闷，再随机撒几块碎的落下来 */
/* 一个小小的声像帮手：世界坐标 -> 左右 -1..1（不支持的浏览器返回 null，调用方自己降级） */
function sfxPan(px, py){
  try {
    if (!actx || !actx.createStereoPanner) return null;
    const dx = px - (player ? player.x : px);
    const p = Math.max(-1, Math.min(1, dx / 520));
    const n = actx.createStereoPanner();
    n.pan.value = p;
    return n;
  } catch(e){ return null; }
}

/* 铁皮：高频的“叮” + 一条金属尾音（两个不和谐的高次分量叠在一起就是铁味） */
function sfxMetalHit(px, py){
  if (!actx) return;
  try {
    const t0 = actx.currentTime;
    const pan = (typeof sfxPan === 'function') ? sfxPan(px, py) : null;
    const out = actx.createGain(); out.gain.value = 0.5;
    if (pan){ out.connect(pan); pan.connect(duckBus()); } else out.connect(duckBus());
    for (let i = 0; i < 2; i++){
      const o = actx.createOscillator();
      o.type = 'triangle';
      const f = i === 0 ? 2450 : 3820;
      o.frequency.setValueAtTime(f, t0);
      o.frequency.exponentialRampToValueAtTime(f * 0.72, t0 + 0.16);
      const g = actx.createGain();
      g.gain.setValueAtTime(i === 0 ? 0.16 : 0.075, t0);
      g.gain.exponentialRampToValueAtTime(0.0006, t0 + (i === 0 ? 0.26 : 0.17));
      o.connect(g); g.connect(out);
      o.start(t0); o.stop(t0 + 0.30);
    }
    const src = actx.createBufferSource(); src.buffer = noiseBuf;
    const hp = actx.createBiquadFilter(); hp.type = 'highpass';
    hp.frequency.setValueAtTime(3200, t0);
    const g2 = actx.createGain();
    g2.gain.setValueAtTime(0.10, t0);
    g2.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.06);
    src.connect(hp); hp.connect(g2); g2.connect(out);
    src.start(t0); src.stop(t0 + 0.09);
  } catch(e){}
}
/* 土墙 / 木箱 / 沙袋：低沉的“嘘”，没有高频 */
function sfxDirtHit(px, py){
  if (!actx) return;
  try {
    const t0 = actx.currentTime;
    const pan = (typeof sfxPan === 'function') ? sfxPan(px, py) : null;
    const out = actx.createGain(); out.gain.value = 0.42;
    if (pan){ out.connect(pan); pan.connect(duckBus()); } else out.connect(duckBus());
    const src = actx.createBufferSource(); src.buffer = noiseBuf;
    const lp = actx.createBiquadFilter(); lp.type = 'lowpass';
    lp.frequency.setValueAtTime(760, t0);
    lp.frequency.exponentialRampToValueAtTime(260, t0 + 0.13);
    lp.Q.value = 0.8;
    const g = actx.createGain();
    g.gain.setValueAtTime(0.34, t0);
    g.gain.exponentialRampToValueAtTime(0.0007, t0 + 0.15);
    src.connect(lp); lp.connect(g); g.connect(out);
    src.start(t0); src.stop(t0 + 0.18);
  } catch(e){}
}

/* 穿门的声音：和"打在实心墙上"完全是两回事 —— 木门是闷闷的一声"噗"，
   铁门是又短又薄的"叮"；都比撞墙轻、短，低频和高频两头都收着 */
function sfxDoorPierce(px, py, metal){
  if (!actx) return;
  try {
    const t0 = actx.currentTime;
    const pan = (typeof sfxPan === 'function') ? sfxPan(px, py) : null;
    const out = actx.createGain(); out.gain.value = metal ? 0.30 : 0.26;
    if (pan){ out.connect(pan); pan.connect(duckBus()); } else out.connect(duckBus());
    if (metal){
      for (let i = 0; i < 2; i++){
        const at = t0 + i * 0.018;
        const o = actx.createOscillator(); o.type = 'triangle';
        o.frequency.setValueAtTime(i ? 2600 : 3150, at);
        const g = actx.createGain();
        g.gain.setValueAtTime(0.001, at);
        g.gain.linearRampToValueAtTime(0.45, at + 0.004);
        g.gain.exponentialRampToValueAtTime(0.001, at + 0.085);
        o.connect(g); g.connect(out); o.start(at); o.stop(at + 0.11);
      }
    } else {
      const src = actx.createBufferSource(); src.buffer = noiseBuf;
      const lp = actx.createBiquadFilter(); lp.type = 'lowpass';
      lp.frequency.setValueAtTime(520, t0);
      lp.frequency.exponentialRampToValueAtTime(180, t0 + 0.10);
      lp.Q.value = 0.7;
      const g = actx.createGain();
      g.gain.setValueAtTime(0.62, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.13);
      src.connect(lp); lp.connect(g); g.connect(out);
      src.start(t0); src.stop(t0 + 0.16);
    }
  } catch(e){}
}

function sfxCollapse(){
  if (!actx) return;
  try {
    const t0 = actx.currentTime;
    const src = actx.createBufferSource(); src.buffer = noiseBuf;
    const lp = actx.createBiquadFilter(); lp.type = 'lowpass';
    lp.frequency.setValueAtTime(2600, t0);
    lp.frequency.exponentialRampToValueAtTime(240, t0 + 0.55);
    const g = actx.createGain();
    g.gain.setValueAtTime(0.42, t0);
    g.gain.exponentialRampToValueAtTime(0.0008, t0 + 0.7);
    src.connect(lp); lp.connect(g); g.connect(duckBus());
    src.start(t0); src.stop(t0 + 0.75);
    for (let i = 0; i < 5; i++){
      const tt = t0 + 0.03 + i * 0.055 + Math.random() * 0.05;
      const s2 = actx.createBufferSource(); s2.buffer = noiseBuf;
      const bp = actx.createBiquadFilter(); bp.type = 'bandpass';
      bp.frequency.value = 700 + Math.random() * 1500;
      bp.Q.value = 2.2;
      const g2 = actx.createGain();
      g2.gain.setValueAtTime(0.16, tt);
      g2.gain.exponentialRampToValueAtTime(0.0008, tt + 0.13);
      s2.connect(bp); bp.connect(g2); g2.connect(duckBus());
      s2.start(tt); s2.stop(tt + 0.16);
    }
  } catch(e){}
}

/* ── 掩体画法（第 12 轮）───────────────────────────────────────────────
   按 w.cov 分派。每块只画在自己的矩形里、四角不出界 ——
   「画出来多大就挡多大」是第 3 条铁律，掩体上不许画超出 AABB 的装饰。
   想加一种新掩体：data/covers.js 里加一行，这里加一个分支，别的地方不用动。 */
/* 小块掩体上的木纹 / 褶子：要"每块都不太一样，但每一帧都一样"。
   用坐标算一个稳定的伪随机，不存字段、不占内存。 */
function covHash(a, b){
  let h = (Math.floor(a) * 374761393 + Math.floor(b) * 668265263) | 0;
  h = (h ^ (h >>> 13)) * 1274126177 | 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}
/* f<1 压暗、f>1 提亮（只认 #rrggbb），画伪 3D 明暗用 */
function covMix(hex, f){
  const n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const c = v => Math.max(0, Math.min(255, Math.round(f <= 1 ? v * f : v + (255 - v) * (f - 1))));
  return 'rgb(' + c(r) + ',' + c(g) + ',' + c(b) + ')';
}
/* ============================================================================
   瞭望塔的画法拆成三块（第 66 轮）：
     · drawTowerBase(w, hi) —— 地基木板 + 四个柱脚 + 斜撑 + 梯子（画在墙那一层）
     · drawTowerTop(w, hi)  —— 抬到半空的平台 + 三面栏杆（正常情况画在"人之后"那一层，
        这样走在塔背后的人会被平台挡住；人在塔上时改在墙那一层画，否则平台会盖住自己）
     · towerDeckRect(w, hi) —— 平台矩形，逻辑和画法共用同一份，别各算一套
   hi 只影响画法，碰撞永远是 w×h 那块地基。
   ============================================================================ */
function towerDeckRect(d, hi){
  const H = (hi != null) ? hi : (d.hi || 64);
  /* 平台跟塔身同宽：窄一圈会像"一块板插在墙里"，同宽才像挑出来的楼板 */
  return { x: d.x, y: d.y - H, w: d.w, h: d.h * 0.50 };
}
function drawTowerBase(w, hi){
  const x = w.x, y = w.y, W = w.w, H = w.h;
  
  const wood = '#4a3c2a', woodLo = '#241d13', woodHi = '#6b573c';
  const d = towerDeckRect(w, hi);
  ctx.save();
  /* —— 地基：铺满整块 AABB（碰撞和画面必须对得上）—— */
  ctx.fillStyle = 'rgba(0,0,0,0.45)';
  ctx.fillRect(x, y, W, H);

  /* —— 塔身四个侧面：从地基四角收到平台四角，这就是"高"的本体 ——
     俯视图里看不见侧面，但把侧面画成暗色梯形，人一眼就知道这是立起来的东西。 */
  const face = (ax, ay, bx2, by2, cx2, cy2, dx2, dy2, fill) => {
    ctx.beginPath();
    ctx.moveTo(ax, ay); ctx.lineTo(bx2, by2); ctx.lineTo(cx2, cy2); ctx.lineTo(dx2, dy2);
    ctx.closePath();
    ctx.fillStyle = fill; ctx.fill();
    ctx.strokeStyle = woodLo; ctx.lineWidth = 1.6; ctx.stroke();
  };
  /* 南面（正面，最亮）：地基下缘 → 平台下缘 */
  face(x + 2, y + H - 2, x + W - 2, y + H - 2, d.x + d.w, d.y + d.h, d.x, d.y + d.h,
       'rgba(74,60,42,0.96)');
  /* 左、右面（暗一点，表示侧壁） */
  face(x + 2, y + 2, x + 2, y + H - 2, d.x, d.y + d.h, d.x, d.y + 2, 'rgba(52,42,30,0.96)');
  face(x + W - 2, y + 2, x + W - 2, y + H - 2, d.x + d.w, d.y + d.h, d.x + d.w, d.y + 2, 'rgba(38,30,21,0.96)');

  /* 正面板缝 + 高光，看起来是木板墙 */
  const cols = Math.max(4, Math.round(W / 16));
  ctx.strokeStyle = 'rgba(0,0,0,0.30)'; ctx.lineWidth = 1.2;
  for (let i2 = 1; i2 < cols; i2++){
    const t = i2 / cols;
    const bx2 = x + 2 + (x + W - 2 - (x + 2)) * t;
    const tx = d.x + d.w * t;
    ctx.beginPath(); ctx.moveTo(bx2, y + H - 3); ctx.lineTo(tx, d.y + d.h - 1); ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(226,216,196,0.10)'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(d.x + 1, d.y + d.h - 1); ctx.lineTo(d.x + d.w - 1, d.y + d.h - 1); ctx.stroke();

  /* 平台底下的暗影：让人看出平台是从塔身上挑出来的一块，而不是和墙面平齐 */
  const sh = Math.max(5, H * 0.10);
  const gsh = ctx.createLinearGradient(0, d.y + d.h, 0, d.y + d.h + sh);
  gsh.addColorStop(0, 'rgba(0,0,0,0.55)');
  gsh.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = gsh;
  ctx.fillRect(x + 1, d.y + d.h, W - 2, sh);

  /* 地基上再压一圈边框，把 AABB 的边"钉"出来 */
  ctx.strokeStyle = woodLo; ctx.lineWidth = 2.4; ctx.strokeRect(x + 1, y + 1, W - 2, H - 2);

  /* —— 四个角柱：立在地基四角，顶到平台四角（压在侧面之上，像真的柱子） —— */
  const pw = Math.max(9, W * 0.085);
  const post = (bx, by, tx, ty, dark) => {
    ctx.beginPath();
    ctx.moveTo(bx, by); ctx.lineTo(tx, ty); ctx.lineTo(tx + pw, ty); ctx.lineTo(bx + pw, by);
    ctx.closePath();
    ctx.fillStyle = dark ? 'rgba(58,46,32,0.98)' : woodHi; ctx.fill();
    ctx.strokeStyle = woodLo; ctx.lineWidth = 1.3; ctx.stroke();
  };
  post(x + 3, y + 3, d.x, d.y, true);
  post(x + W - 3 - pw, y + 3, d.x + d.w - pw, d.y, true);
  post(x + 3, y + H - 3 - pw * 1.6, d.x, d.y + d.h - pw, false);
  post(x + W - 3 - pw, y + H - 3 - pw * 1.6, d.x + d.w - pw, d.y + d.h - pw, false);

  /* —— 交叉斜撑：画在正面上 —— */
  ctx.strokeStyle = 'rgba(96,79,54,0.95)'; ctx.lineWidth = Math.max(2.4, W * 0.026);
  ctx.beginPath();
  ctx.moveTo(x + W * 0.14, y + H * 0.94); ctx.lineTo(x + W * 0.86, y + H * 0.30);
  ctx.moveTo(x + W * 0.86, y + H * 0.94); ctx.lineTo(x + W * 0.14, y + H * 0.30);
  ctx.stroke();

  /* —— 南面梯子：从平台下沿垂到地基下缘 —— */
  const lw = Math.max(14, W * 0.18);
  const ly0 = d.y + d.h, ly1 = y + H * 0.96;
  if (ly1 > ly0 + 6){
    ctx.fillStyle = woodLo; ctx.fillRect(x + W * 0.5 - lw / 2, ly0, lw, ly1 - ly0);
    ctx.fillStyle = '#93794f';
    const rungs = Math.max(3, Math.round((ly1 - ly0) / 9));
    for (let i2 = 0; i2 < rungs; i2++){
      ctx.fillRect(x + W * 0.5 - lw / 2 + 2, ly0 + 2 + i2 * (ly1 - ly0 - 4) / rungs, lw - 4, 1.8);
    }
  }
  ctx.restore();
}
function drawTowerTop(w, hi){
  const W = w.w;
  const wood = '#4a3c2a', woodLo = '#241d13', railC = '#7c6644';
  const d = towerDeckRect(w, hi);
  ctx.save();
  /* 平台顶面：整块木板 */
  ctx.fillStyle = wood;
  ctx.fillRect(d.x, d.y, d.w, d.h);
  const planks = Math.max(3, Math.round(d.w / 13));
  ctx.fillStyle = 'rgba(0,0,0,0.24)';
  for (let i2 = 1; i2 < planks; i2++) ctx.fillRect(d.x + i2 * d.w / planks - 0.7, d.y + 2, 1.4, d.h - 4);
  ctx.fillStyle = 'rgba(226,216,196,0.10)';
  ctx.fillRect(d.x + 1, d.y + 1, d.w - 2, 2.6);
  ctx.strokeStyle = woodLo; ctx.lineWidth = 2.2; ctx.strokeRect(d.x, d.y, d.w, d.h);
  /* 三面栏杆（南面留口上梯子） */
  ctx.strokeStyle = railC; ctx.lineWidth = Math.max(4, W * 0.05); ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(d.x - 2, d.y - 3); ctx.lineTo(d.x + d.w + 2, d.y - 3);
  ctx.moveTo(d.x - 2, d.y - 3); ctx.lineTo(d.x - 2, d.y + d.h + 2);
  ctx.moveTo(d.x + d.w + 2, d.y - 3); ctx.lineTo(d.x + d.w + 2, d.y + d.h + 2);
  ctx.stroke();
  ctx.lineCap = 'butt';
  ctx.fillStyle = '#8a7452';
  for (const q of [[d.x - 2, d.y - 3], [d.x + d.w + 2, d.y - 3], [d.x - 2, d.y + d.h + 2], [d.x + d.w + 2, d.y + d.h + 2]]){
    ctx.fillRect(q[0] - 2.6, q[1] - 8, 5.2, 11);
  }
  ctx.restore();
}
function drawCover(w){
  const x = w.x, y = w.y, W = w.w, H = w.h, c = w.cov;
  if (c === 'glass'){ drawGlassPane(w); return; }
  const hurt = (w.brk && w.maxHp) ? clamp(1 - (w.hp || 0) / w.maxHp, 0, 1) : 0;

  /* 统一先压一道三分偏移的暗影：所有掩体都"立"在地上，不然贴图是平的。
     沙袋例外 —— 它的轮廓是一袋袋弧形的，套一个矩形影子就变成"托盘"了。
     报废汽车也例外 —— 车身是收窄的梯形，套矩形影子会在四角露出一个黑框（第 62 轮踩过）。 */
  if (c !== 'sackpile' && c !== 'wreckcar'){
    ctx.fillStyle = 'rgba(0,0,0,0.26)';
    ctx.fillRect(x + 3, y + 3, W, H);
  }

  if (c === 'crate' || c === 'crate2'){
    /* 木箱：外框 + 三块横板 + 四角铁片。四档状态 —— 完好 / 起裂 / 板条错位 / 板条塌了一块。
       裂纹条数跟着命中次数走：每挨一下多一条，最多 9 条。 */
    const tier = hurt > 0.72 ? 3 : hurt > 0.48 ? 2 : hurt > 0.22 ? 1 : 0;
    const nCk = w.hits != null ? Math.min(9, w.hits) : (tier >= 3 ? 4 : tier === 2 ? 3 : tier === 1 ? 1 : 0);
    const wd = covMix('#3b3226', 1 - tier * 0.09);
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, W, H); ctx.clip();
    ctx.fillStyle = '#221e18';
    ctx.fillRect(x, y, W, H);
    ctx.fillStyle = wd;
    ctx.fillRect(x + 3, y + 3, W - 6, H - 6);
    const ph = (H - 6) / 3;
    for (let i = 0; i < 3; i++){
      const py = y + 3 + i * ph;
      /* 第 2 档：最下面那块板条被撞得歪了一点 */
      const offx = tier >= 2 && i === 2 ? 3.5 : 0;
      ctx.fillStyle = covMix('#3b3226', 1 - i * 0.05 - tier * 0.07);
      ctx.fillRect(x + 3 + offx, py, W - 6 - offx, ph - 2);
      ctx.fillStyle = 'rgba(9,8,6,0.6)';
      ctx.fillRect(x + 3, py + ph - 2, W - 6, 1.8);
      for (let k = 0; k < 3; k++){
        const gx = x + 4 + covHash(x + i * 31 + k * 7, y + k * 17) * (W - 24);
        const gy = py + 2 + covHash(y + k * 41, x + i * 13) * Math.max(1, ph - 7);
        ctx.fillStyle = k % 2 ? 'rgba(200,190,166,0.05)' : 'rgba(7,6,4,0.18)';
        ctx.fillRect(gx, gy, 6 + covHash(gx, gy) * 10, 1);
      }
      /* 第 3 档：中间那块板条塌掉半截，露出一道黑洞（必须画在板条之后，否则被盖住）*/
      if (tier >= 3 && i === 1){
        const hx0 = x + 6 + covHash(x + 3, y + 9) * W * 0.32;
        const hw = Math.max(10, W * 0.22);
        ctx.fillStyle = '#120f0b';
        ctx.fillRect(hx0, py + ph * 0.16, hw, ph * 0.56 + 2);
        ctx.fillStyle = 'rgba(120,104,78,0.18)';
        ctx.fillRect(hx0, py + ph * 0.16, hw, 1.4);
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.fillRect(hx0, py + ph * 0.66, hw, 2);
      }
    }
    ctx.fillStyle = 'rgba(210,208,198,0.055)';
    ctx.fillRect(x + 3, y + 3, W - 6, 1.6);
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.fillRect(x + 3, y + H - 5, W - 6, 2);
    const pl = Math.max(6, Math.round(Math.min(W, H) * 0.13));
    for (const q of [[1, 1], [-1, 1], [1, -1], [-1, -1]]){
      const bx = q[0] > 0 ? x + 1 : x + W - pl - 1;
      const by = q[1] > 0 ? y + 1 : y + H - pl - 1;
      ctx.fillStyle = '#312c24';
      ctx.fillRect(bx, by, pl, pl);
      ctx.fillStyle = 'rgba(214,198,166,0.10)';
      ctx.fillRect(bx, by, pl, 1);
      ctx.fillStyle = 'rgba(198,182,150,0.40)';
      ctx.fillRect(bx + (q[0] > 0 ? 2 : pl - 4), by + (q[1] > 0 ? 2 : pl - 4), 2, 2);
    }
    if (tier > 0){
      ctx.fillStyle = 'rgba(6,5,4,' + (0.06 + tier * 0.05).toFixed(2) + ')';
      ctx.fillRect(x, y, W, H);
      /* 裂纹：每条随机起止、只走一段路、带一点横向拐折；第 n 条的位置由命中次数决定，画过的不会乱动 */
      for (let k = 0; k < nCk; k++){
        const cx0 = x + 5 + covHash(x + k * 13, y + 11) * (W - 12);
        const cy0 = y + 4 + covHash(x + k * 29, y + 31) * (H * 0.42);
        const len = H * (0.22 + covHash(x + k * 5, y + 47) * 0.34);
        const cy1 = Math.min(y + H - 4, cy0 + len);
        const dx = (covHash(x + k * 41, y + k * 7) - 0.5) * W * 0.16;
        ctx.strokeStyle = 'rgba(5,4,3,0.74)';
        ctx.lineWidth = k === 0 ? 1.5 : 1.1;
        ctx.beginPath();
        ctx.moveTo(cx0, cy0);
        ctx.lineTo(cx0 + dx * 0.55, (cy0 + cy1) * 0.5);
        ctx.lineTo(cx0 - dx * 0.4, cy1);
        ctx.stroke();
        ctx.strokeStyle = 'rgba(196,178,146,0.09)';   /* 裂口边上的木茬受光 */
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.moveTo(cx0 + 0.9, cy0 + 1);
        ctx.lineTo(cx0 + dx * 0.55 + 0.9, (cy0 + cy1) * 0.5 + 1);
        ctx.lineTo(cx0 - dx * 0.4 + 0.9, cy1);
        ctx.stroke();
      }
    }
    ctx.restore();
    ctx.strokeStyle = 'rgba(10,9,7,0.8)'; ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, W - 2, H - 2);

  } else if (c === 'lootcrate' || c === 'crateMed' || c === 'crateAmmo' || c === 'crateGear' || c === 'crateJunk' || c === 'crateWeap' || c === 'crateAir'){
    /* 战利品箱（第 27 轮分主题）：形状一样、配色和胸标不一样 ——
       医疗箱白灰带红十字、弹药箱军绿带黄斜纹、军械箱墨绿带铆钉条、杂物箱灰木带胶带。
       配色全在 data/lootcrate.js 的 LOOT_SKIN 里，这里一个颜色都不许写死。
       闭合 = 箱盖；打开 = 盖子掀掉、露出暗色内衬。搜刮时整块微微发抖。 */
    const lk = w.lootKind || 'mixed';
    const LP = (typeof LOOT_SKIN !== 'undefined' && LOOT_SKIN[lk]) || (typeof LOOT_SKIN !== 'undefined' ? LOOT_SKIN.mixed : null);
    const lBody = LP ? LP.body : '#3a3126', lBand = LP ? LP.band : '#454b52';
    const lBandHi = LP ? LP.bandHi : 'rgba(206,222,238,0.16)';
    const lWall = LP ? LP.wall : '#4a3f2e', lCloth = LP ? LP.cloth : '#2a231b';
    const sh = (w.searchT > 0) ? Math.sin(uiT * 46) * 1.3 * w.searchT : 0;
    const X = x + sh, XW = W;
    ctx.save();
    ctx.beginPath(); ctx.rect(x - 12, y - 14, W + 24, H + 28); ctx.clip();
    ctx.fillStyle = '#1c1914';
    ctx.fillRect(X, y, XW, H);
    if (!w.opened){
      /* —— 闭合：板面 + 两道铁箍 + 四角包边 + 锁扣 —— */
      ctx.fillStyle = lBody;
      ctx.fillRect(X + 2, y + 2, XW - 4, H - 4);
      for (let i = 0; i < 3; i++){
        const py = y + 2 + i * ((H - 4) / 3);
        ctx.fillStyle = covMix(lBody, 1 - i * 0.06);
        ctx.fillRect(X + 2, py, XW - 4, (H - 4) / 3 - 1.6);
        ctx.fillStyle = 'rgba(8,7,5,0.62)';
        ctx.fillRect(X + 2, py + (H - 4) / 3 - 2.4, XW - 4, 1.6);
      }
      /* 竖向铁箍 */
      for (const bx of [X + 3.5, X + XW - 7.5]){
        ctx.fillStyle = lBand;
        ctx.fillRect(bx, y + 1.5, 4, H - 3);
        ctx.fillStyle = lBandHi;
        ctx.fillRect(bx, y + 1.5, 1.2, H - 3);
        ctx.fillStyle = 'rgba(8,10,12,0.42)';
        ctx.fillRect(bx + 3, y + 1.5, 1, H - 3);
      }
      /* 四角包边 */
      const pl = Math.max(5, Math.round(Math.min(W, H) * 0.16));
      for (const q of [[1, 1], [-1, 1], [1, -1], [-1, -1]]){
        const bx = q[0] > 0 ? X + 1 : X + XW - pl - 1;
        const by = q[1] > 0 ? y + 1 : y + H - pl - 1;
        ctx.fillStyle = lBand;
        ctx.fillRect(bx, by, pl, pl);
        ctx.fillStyle = lBandHi;
        ctx.fillRect(bx, by, pl, 1);
        ctx.fillStyle = 'rgba(190,206,220,0.5)';
        ctx.fillRect(bx + (q[0] > 0 ? 2 : pl - 4), by + (q[1] > 0 ? 2 : pl - 4), 2, 2);
      }
      /* 锁扣：正中一小块铁片 + 钥匙孔 */
      const lw = Math.max(7, W * 0.22), lh = Math.max(6, H * 0.20);
      const lx = X + XW / 2 - lw / 2, ly = y + H * 0.44;
      ctx.fillStyle = lBand;
      ctx.fillRect(lx, ly, lw, lh);
      ctx.fillStyle = lBandHi;
      ctx.fillRect(lx, ly, lw, 1);
      ctx.fillStyle = '#14171a';
      ctx.beginPath(); ctx.arc(lx + lw / 2, ly + lh * 0.42, Math.max(1.2, lw * 0.11), 0, TAU); ctx.fill();
      ctx.fillRect(lx + lw / 2 - 0.8, ly + lh * 0.52, 1.6, lh * 0.30);
      /* 胸标：一眼分出这是哪一型箱子（颜色之外再给个形状，颜色认不出的人也能读） */
      const mk = LP ? LP.mark : null;
      const mw = Math.min(XW, H);
      if (mk === 'cross'){                       /* 医疗箱：白底红十字 */
        const cw2 = Math.max(3.5, mw * 0.16), cl2 = Math.max(9, mw * 0.42);
        ctx.fillStyle = 'rgba(248,246,240,0.92)';
        ctx.fillRect(X + XW * 0.5 - cw2 / 2, y + H * 0.30, cw2, cl2);
        ctx.fillRect(X + XW * 0.5 - cl2 / 2, y + H * 0.30 + (cl2 - cw2) / 2, cl2, cw2);
      } else if (mk === 'stripe'){               /* 弹药箱：两道黄斜纹（用横条近似，40px 下更清楚） */
        ctx.fillStyle = 'rgba(226,196,96,0.80)';
        ctx.fillRect(X + XW * 0.14, y + H * 0.20, XW * 0.72, Math.max(2, H * 0.08));
        ctx.fillRect(X + XW * 0.14, y + H * 0.34, XW * 0.72, Math.max(2, H * 0.08));
      } else if (mk === 'bolt'){                 /* 军械箱：一条亮钢横梁 + 四个铆钉 */
        ctx.fillStyle = 'rgba(206,216,198,0.55)';
        ctx.fillRect(X + XW * 0.10, y + H * 0.47, XW * 0.80, Math.max(2.4, H * 0.10));
        ctx.fillStyle = 'rgba(238,244,232,0.70)';
        for (let i = 0; i < 4; i++) ctx.fillRect(X + XW * (0.16 + i * 0.22), y + H * 0.47 + Math.max(1, H * 0.035), 1.8, 1.8);
      } else if (mk === 'tape'){                 /* 杂物箱：一道灰胶带横过箱面 */
        ctx.fillStyle = 'rgba(196,188,170,0.42)';
        ctx.fillRect(X + 2, y + H * 0.46, XW - 4, Math.max(2.6, H * 0.13));
        ctx.fillStyle = 'rgba(120,112,98,0.35)';
        ctx.fillRect(X + 2, y + H * 0.46, XW - 4, 1);
      } else if (mk === 'flare'){
        /* 空投箱：白底圆 + 红心，像信号弹打上去的那团火 */
        const fr = Math.max(6, mw * 0.20);
        ctx.fillStyle = 'rgba(246,244,240,0.90)';
        ctx.beginPath(); ctx.arc(X + XW * 0.5, y + H * 0.5, fr, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(226,60,70,0.95)';
        ctx.beginPath(); ctx.arc(X + XW * 0.5, y + H * 0.5, fr * 0.52, 0, TAU); ctx.fill();
      } else if (mk === 'rifle'){
        /* 长条武器箱：箱面横躺一把枪 —— 枪托 + 机匣 + 细枪管 + 弹匣
           （箱子是 96×30 的长条，横着画才看得清是"装枪的"） */
        const gy = y + H * 0.44, gu = Math.min(H * 0.30, 10);
        ctx.fillStyle = 'rgba(232,222,198,0.88)';
        ctx.fillRect(X + XW * 0.22, gy, XW * 0.20, gu * 0.62);          /* 枪托 */
        ctx.fillRect(X + XW * 0.40, gy - gu * 0.10, XW * 0.22, gu * 0.72); /* 机匣 */
        ctx.fillRect(X + XW * 0.61, gy + gu * 0.16, XW * 0.17, Math.max(1.6, gu * 0.22)); /* 枪管 */
        ctx.fillRect(X + XW * 0.47, gy + gu * 0.60, Math.max(2.4, XW * 0.035), gu * 0.62); /* 弹匣 */
        ctx.fillStyle = 'rgba(120,132,142,0.75)';
        ctx.fillRect(X + XW * 0.40, gy + gu * 0.62, XW * 0.22, 1.4);    /* 机匣下沿阴影 */
      }
      ctx.fillStyle = 'rgba(216,208,188,0.06)';
      ctx.fillRect(X + 2, y + 2, XW - 4, 1.4);
    } else {
      /* —— 打开：厚箱壁 + 掀到上半截的盖子 + 下半截露出的布料 —— */
      ctx.fillStyle = lWall;                         /* 箱壁：比闭合时亮一档，才看得出是"边" */
      ctx.fillRect(X, y, XW, H);
      const t = Math.max(5, Math.min(W, H) * 0.19);
      /* 箱壁上的板缝：四边各一道，木箱不是一整块 */
      ctx.fillStyle = 'rgba(12,10,7,0.5)';
      ctx.fillRect(X + t * 0.55, y, 1.2, H);
      ctx.fillRect(X + XW - t * 0.55, y, 1.2, H);
      ctx.fillRect(X, y + t * 0.55, XW, 1.2);
      ctx.fillRect(X, y + H - t * 0.55, XW, 1.2);
      /* 内腔：比箱壁暗两三档，才像"里面是空的" */
      ctx.fillStyle = '#0f0d0b';
      ctx.fillRect(X + t, y + t, XW - t * 2, H - t * 2);
      /* 下半截的货：暗色布料 + 两团鼓包 + 一道褶 */
      const cavY = y + t + (H - t * 2) * 0.44;
      ctx.fillStyle = lCloth;
      ctx.fillRect(X + t + 1, cavY, XW - t * 2 - 2, (y + H - t) - cavY);
      ctx.fillStyle = covMix(lCloth, 1.18);
      ctx.beginPath();
      ctx.arc(X + XW * 0.40, y + H * 0.78, Math.max(2.6, W * 0.085), 0, TAU); ctx.fill();
      ctx.beginPath();
      ctx.arc(X + XW * 0.62, y + H * 0.81, Math.max(2, W * 0.065), 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(150,128,96,0.16)';
      ctx.fillRect(X + t + 2, y + H * 0.68, XW - t * 2 - 4, 1.1);
      /* 掀到上面、还搭在箱口上的盖子：正的，别转 —— 40px 下斜的会糊成一团 */
      const lh2 = (H - t * 2) * 0.46, lY = y + t + 1;
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      ctx.fillRect(X + t + 2.2, lY + 2.6, XW - t * 2 - 2, lh2);
      ctx.fillStyle = covMix(lWall, 1.30);
      ctx.fillRect(X + t + 1, lY, XW - t * 2 - 2, lh2);
      ctx.fillStyle = lBand;
      ctx.fillRect(X + t + 1 + (XW - t * 2) * 0.12, lY, 2.6, lh2);
      ctx.fillRect(X + t + 1 + (XW - t * 2) * 0.78, lY, 2.6, lh2);
      ctx.fillStyle = lBandHi;
      ctx.fillRect(X + t + 1, lY, XW - t * 2 - 2, 1.3);
      ctx.fillStyle = 'rgba(10,9,7,0.8)';             /* 盖子底边：和下面的货拉开一条硬边 */
      ctx.fillRect(X + t + 1, lY + lh2 - 1.4, XW - t * 2 - 2, 1.4);
      ctx.fillStyle = 'rgba(0,0,0,0.55)';             /* 箱口内沿一圈阴影 */
      ctx.fillRect(X + t, y + t, XW - t * 2, 1.6);
      /* 断板：两根短木条翘在箱口边上（小角度，别画成放射状） */
      for (let i = 0; i < 2; i++){
        ctx.save();
        ctx.translate(X + XW * (i ? 0.78 : 0.24), y + H * 0.20);
        ctx.rotate((i ? 1 : -1) * 0.22);
        ctx.fillStyle = covMix(lWall, 1.30);
        ctx.fillRect(-2.2, -H * 0.10, 4.4, H * 0.20);
        ctx.restore();
      }
      /* 箱壁受光 + 破口 */
      ctx.fillStyle = 'rgba(214,198,166,0.10)';
      ctx.fillRect(X, y, XW, 1.6);
      ctx.fillStyle = 'rgba(10,8,6,0.55)';
      ctx.fillRect(X + 1, y + H - 2.4, XW - 2, 1.8);
    }
    ctx.restore();
    ctx.strokeStyle = 'rgba(10,9,7,0.82)'; ctx.lineWidth = 2;
    ctx.strokeRect(X + 1, y + 1, XW - 2, H - 2);
    /* 范围内提示「按 E 搜刮」：只在玩家够得着、还没打开的时候画 */
    if (!w.opened && player && typeof LOOT_CRATE !== 'undefined' &&
        distToRect(player.x, player.y, w) <= LOOT_CRATE.range){
      const by = y - 8 + Math.sin(uiT * 4) * 1.5;
      ctx.save();
      ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(10,12,14,0.72)';
      const tw = 52, th = 13;
      ctx.fillRect(x + W / 2 - tw / 2, by - th + 3, tw, th);
      ctx.fillStyle = crateSearch ? '#e8c579' : 'rgba(238,228,204,0.95)';
      ctx.fillText(crateSearch ? '搜刮中…' : '[' + keyLabel(BINDS.interact) + '] 搜刮', x + W / 2, by - 1);
      ctx.textAlign = 'left';
      ctx.restore();
    }
  } else if (c === 'crateAttach'){
    /* 配件箱（第 73 轮）：小铁盒，只有 30×26。钢壳 + 一道窄箍 + 扣锁 + 一个"配件"标，
       盖子比箱体亮一档，打开后盖掀到后上方、里面能看见一两件小零件的剪影。 */
    const AS = (typeof LOOT_SKIN !== 'undefined' && LOOT_SKIN.attach) || null;
    const aBody = AS ? AS.body  : '#343a3f';
    const aBand = AS ? AS.band  : '#8f9aa4';
    const aHi   = AS ? AS.bandHi: 'rgba(232,240,248,0.22)';
    const aWall = AS ? AS.wall  : '#3d4348';
    const aCloth= AS ? AS.cloth : '#22262b';
    ctx.save();
    /* 影子收在框内 */
    ctx.fillStyle = 'rgba(0,0,0,0.34)';
    ctx.fillRect(x + 3, y + 3, W - 4, H - 4);
    if (!w.opened){
      /* 箱体 */
      ctx.fillStyle = aBody;
      ctx.fillRect(x, y + H * 0.10, W, H * 0.90);
      /* 盖子（上缘亮一档） */
      ctx.fillStyle = covMix(aBody, 1.18);
      ctx.fillRect(x, y + H * 0.10, W, H * 0.34);
      /* 窄钢箍：一道横的，压在盖子下沿 */
      ctx.fillStyle = aBand;
      ctx.fillRect(x, y + H * 0.42, W, Math.max(2, H * 0.075));
      ctx.fillStyle = aHi;
      ctx.fillRect(x, y + H * 0.42, W, 1);
      /* 扣锁 */
      const cw = Math.max(5, W * 0.20), ch = Math.max(5, H * 0.20);
      ctx.fillStyle = aBand;
      ctx.fillRect(x + W * 0.5 - cw / 2, y + H * 0.50, cw, ch);
      ctx.fillStyle = covMix(aBand, 0.55);
      ctx.fillRect(x + W * 0.5 - cw / 6, y + H * 0.55, cw / 3, ch * 0.45);
      /* "配件"标：一枚小方块 + 两道刻线（远看是个零件符号，不写字） */
      ctx.fillStyle = 'rgba(240,236,226,0.82)';
      ctx.fillRect(x + W * 0.20, y + H * 0.18, W * 0.16, H * 0.14);
      ctx.fillStyle = aBody;
      ctx.fillRect(x + W * 0.235, y + H * 0.215, W * 0.06, H * 0.05);
      ctx.strokeStyle = 'rgba(10,12,14,0.85)'; ctx.lineWidth = 1.4;
      ctx.strokeRect(x + 0.7, y + H * 0.10 + 0.7, W - 1.4, H * 0.90 - 1.4);
    } else {
      /* 打开：箱子底座 + 掀到后上方的盖子 + 里面两件零件的剪影 */
      ctx.fillStyle = aCloth;
      ctx.fillRect(x, y + H * 0.34, W, H * 0.66);
      ctx.fillStyle = aBody;
      ctx.fillRect(x, y + H * 0.34, W, H * 0.16);
      ctx.fillRect(x, y + H * 0.80, W, H * 0.20);
      /* 里面的零件：一截管子 + 一个方弹匣 */
      ctx.fillStyle = covMix(aBand, 0.75);
      ctx.fillRect(x + W * 0.14, y + H * 0.52, W * 0.34, H * 0.10);
      ctx.fillRect(x + W * 0.56, y + H * 0.48, W * 0.22, H * 0.22);
      /* 掀起的盖子 */
      ctx.save();
      ctx.translate(x + W * 0.5, y + H * 0.36);
      ctx.rotate(-0.16);
      ctx.fillStyle = covMix(aBody, 1.10);
      ctx.fillRect(-W * 0.5, -H * 0.26, W, H * 0.26);
      ctx.strokeStyle = aWall; ctx.lineWidth = 1.2;
      ctx.strokeRect(-W * 0.5, -H * 0.26, W, H * 0.26);
      ctx.restore();
    }
    ctx.restore();
    if (!w.opened && player && typeof LOOT_CRATE !== 'undefined' &&
        distToRect(player.x, player.y, w) <= LOOT_CRATE.range){
      const by = y - 8 + Math.sin(uiT * 4) * 1.5;
      ctx.save();
      ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      const tw = 52, th = 13;
      ctx.fillStyle = 'rgba(10,12,14,0.72)';
      ctx.fillRect(x + W / 2 - tw / 2, by - th + 3, tw, th);
      ctx.fillStyle = crateSearch ? '#e8c579' : 'rgba(238,228,204,0.95)';
      ctx.fillText(crateSearch ? '搜刮中…' : '[' + keyLabel(BINDS.interact) + '] 搜刮', x + W / 2, by - 1);
      ctx.textAlign = 'left';
      ctx.restore();
    }
  } else if (c === 'safe'){
    /* 保险箱（第 70 轮）：打不烂，只能用万能钥匙。
       钢壳 + 内凹门框 + 转盘 + 三根压把 + 合页；开过之后门缝变黑、转盘歪到一边。 */
    const SK = (typeof LOOT_SKIN !== 'undefined' && LOOT_SKIN.safe) || null;
    const body  = SK ? SK.body  : '#39424a';
    const bodyHi= SK ? SK.bodyHi: '#4c5761';
    const bodyLo= SK ? SK.bodyLo: '#212831';
    const rimC  = SK ? SK.rim   : '#8d9aa4';
    const op = !!w.opened;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.42)';
    ctx.fillRect(x + 3, y + 3, W - 4, H - 4);

    /* 箱体：底部一条厚底座，上面是门 */
    ctx.fillStyle = bodyLo;
    ctx.fillRect(x + 1, y + 1, W - 2, H - 2);
    ctx.fillStyle = body;
    ctx.fillRect(x + 2, y + 2, W - 4, H - 5);
    /* 顶面高光 */
    ctx.fillStyle = bodyHi;
    ctx.fillRect(x + 2, y + 2, W - 4, 3);
    /* 底座 */
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    ctx.fillRect(x + 1, y + H - 4, W - 2, 3);

    /* 门框：往里收一圈 */
    const dx0 = x + W * 0.14, dy0 = y + H * 0.16, dw = W * 0.72, dh = H * 0.68;
    ctx.strokeStyle = rimC; ctx.lineWidth = 1.4;
    ctx.strokeRect(dx0, dy0, dw, dh);
    ctx.fillStyle = op ? 'rgba(6,7,9,0.92)' : 'rgba(0,0,0,0.22)';
    ctx.fillRect(dx0 + 1.5, dy0 + 1.5, dw - 3, dh - 3);

    if (!op){
      /* 没开：转盘 + 压把 */
      const cx2 = x + W * 0.5, cy2 = y + H * 0.44;
      const rr = Math.max(4, W * 0.13);
      ctx.fillStyle = '#3d464f';
      ctx.beginPath(); ctx.arc(cx2, cy2, rr, 0, TAU); ctx.fill();
      ctx.strokeStyle = rimC; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(cx2, cy2, rr, 0, TAU); ctx.stroke();
      ctx.fillStyle = bodyHi;
      ctx.fillRect(cx2 - 1, cy2 - rr - 1.5, 2, 3.5);
      /* 三根压把 */
      ctx.fillStyle = '#9aa6b0';
      const hy = y + H * 0.66;
      ctx.fillRect(x + W * 0.30, hy, W * 0.12, 2.4);
      ctx.fillRect(x + W * 0.48, hy, W * 0.12, 2.4);
      ctx.fillRect(x + W * 0.66, hy, W * 0.12, 2.4);
      /* 合页 */
      ctx.fillStyle = '#6a757e';
      ctx.fillRect(x + W * 0.06, y + H * 0.28, 3, H * 0.14);
      ctx.fillRect(x + W * 0.06, y + H * 0.58, 3, H * 0.14);
    } else {
      /* 开过：门斜着敞开，里面一块暗腔 + 一点反光 */
      ctx.fillStyle = '#0c0e11';
      ctx.fillRect(dx0 + 2, dy0 + 2, dw - 4, dh - 4);
      ctx.fillStyle = 'rgba(150,170,190,0.10)';
      ctx.fillRect(dx0 + 4, dy0 + 4, dw - 8, 3);
      /* 门板：贴在右侧，斜一点 */
      ctx.save();
      ctx.translate(x + W * 0.86, y + H * 0.5);
      ctx.rotate(0.5);
      ctx.fillStyle = body;
      ctx.fillRect(-W * 0.08, -H * 0.30, W * 0.16, H * 0.60);
      ctx.strokeStyle = rimC; ctx.lineWidth = 1.1;
      ctx.strokeRect(-W * 0.08, -H * 0.30, W * 0.16, H * 0.60);
      ctx.restore();
    }
    ctx.restore();

    /* 保险箱的提示：有钥匙写在能开，没钥匙直接写"上锁" */
    if (!w.opened && player && typeof LOOT_CRATE !== 'undefined' &&
        distToRect(player.x, player.y, w) <= LOOT_CRATE.range){
      const hasKey = (typeof keyCount === 'function') ? keyCount() > 0 : false;
      const label = hasKey ? ('[' + keyLabel(BINDS.interact) + '] 开箱') : '上锁 · 需万能钥匙';
      const by = y - 8 + Math.sin(uiT * 4) * 1.5;
      ctx.save();
      ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      const tw = hasKey ? 56 : 84, th = 13;
      ctx.fillStyle = 'rgba(10,12,14,0.72)';
      ctx.fillRect(x + W / 2 - tw / 2, by - th + 3, tw, th);
      ctx.fillStyle = hasKey ? '#8fe0a8' : 'rgba(232,170,150,0.95)';
      ctx.fillText(label, x + W / 2, by - 1);
      ctx.textAlign = 'left';
      ctx.restore();
    }
  } else if (c === 'watchtower'){
    /* 瞭望塔（第 66 轮）：伪 3D 的"高"。
       · 地基 = AABB 那块（塔底铺满木板，所以碰撞和画面是对得上的，人绕着塔脚走）
       · 柱脚 + 平台抬到 y - hi，平台和三面栏杆由 drawTowerTop() 画
       · 人在塔上时平台在这一层画（否则会盖住玩家），人不在时留给上面那一层画（才能挡住走在塔后的人）
       数据里只有 hi（往上长多少像素）跟 TOWER_TUNE，画法全在这里。 */
    const hi = (w.hi != null ? w.hi : 64);
    drawTowerBase(w, hi);
    if (typeof towerSeat !== 'undefined' && (towerSeat === w || towerEnemyOf(w))) drawTowerTop(w, hi);
    else if (typeof towerSeat === 'undefined') drawTowerTop(w, hi);
  } else if (c === 'watchtowerOld'){
    /* 瞭望塔 · 第一版（平的、不抬高）：用户说"第一版也挺好看"，留着当另一个款。
       玩法完全一样（也走 game/31-watchtower.js），只是画在地上、没有 hi。 */
    const wood = '#4a3c2a', woodLo = '#2b2318', railC = '#7c6644';
    const pw = Math.max(13, W * 0.20);
    ctx.fillStyle = 'rgba(0,0,0,0.34)';
    ctx.fillRect(x + 3, y + 3, W - 4, H - 4);
    ctx.fillStyle = 'rgba(6,8,10,0.55)';
    ctx.fillRect(x + pw * 0.5, y + pw * 0.5, W - pw, H - pw);
    ctx.strokeStyle = 'rgba(110,90,62,0.95)'; ctx.lineWidth = Math.max(4, W * 0.055);
    ctx.beginPath();
    ctx.moveTo(x + pw * 0.5, y + pw * 0.5); ctx.lineTo(x + W - pw * 0.5, y + pw * 0.5);
    ctx.moveTo(x + pw * 0.5, y + H - pw * 0.5); ctx.lineTo(x + W - pw * 0.5, y + H - pw * 0.5);
    ctx.moveTo(x + pw * 0.5, y + pw * 0.5); ctx.lineTo(x + pw * 0.5, y + H - pw * 0.5);
    ctx.moveTo(x + W - pw * 0.5, y + pw * 0.5); ctx.lineTo(x + W - pw * 0.5, y + H - pw * 0.5);
    ctx.stroke();
    for (const q of [[x, y], [x + W - pw, y], [x, y + H - pw], [x + W - pw, y + H - pw]]){
      ctx.fillStyle = woodLo; ctx.fillRect(q[0], q[1], pw, pw);
      ctx.fillStyle = wood;   ctx.fillRect(q[0] + 2, q[1] + 2, pw - 4, pw - 4);
      ctx.fillStyle = 'rgba(226,216,196,0.09)';
      ctx.fillRect(q[0] + 2, q[1] + 2, pw - 4, 2);
    }
    const pad = W * 0.22;
    const px0 = x + pad, py0 = y + pad, pw2 = W - pad * 2, ph2 = H - pad * 2;
    ctx.fillStyle = 'rgba(0,0,0,0.42)';
    ctx.fillRect(px0 + 4, py0 + 5, pw2, ph2);
    ctx.fillStyle = wood; ctx.fillRect(px0, py0, pw2, ph2);
    const planks2 = Math.max(3, Math.round(pw2 / 13));
    ctx.fillStyle = 'rgba(0,0,0,0.26)';
    for (let i3 = 1; i3 < planks2; i3++) ctx.fillRect(px0 + i3 * pw2 / planks2 - 0.6, py0 + 2, 1.2, ph2 - 4);
    ctx.fillStyle = 'rgba(226,216,196,0.08)'; ctx.fillRect(px0 + 1, py0 + 1, pw2 - 2, 2.4);
    ctx.strokeStyle = woodLo; ctx.lineWidth = 1.8; ctx.strokeRect(px0, py0, pw2, ph2);
    ctx.strokeStyle = railC; ctx.lineWidth = Math.max(4, W * 0.055); ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(px0 - 2, py0 - 2); ctx.lineTo(px0 + pw2 + 2, py0 - 2);
    ctx.moveTo(px0 - 2, py0 - 2); ctx.lineTo(px0 - 2, py0 + ph2 + 2);
    ctx.moveTo(px0 + pw2 + 2, py0 - 2); ctx.lineTo(px0 + pw2 + 2, py0 + ph2 + 2);
    ctx.stroke();
    ctx.lineCap = 'butt';
    ctx.fillStyle = '#8a7452';
    for (const q of [[px0 - 2, py0 - 2], [px0 + pw2 + 2, py0 - 2], [px0 - 2, py0 + ph2 + 2]]){
      ctx.fillRect(q[0] - 2.5, q[1] - 2.5, 5, 5);
    }
    const lw2 = Math.max(13, W * 0.17);
    const ly0 = py0 + ph2, ly1 = y + H - 2;
    ctx.fillStyle = woodLo; ctx.fillRect(x + W * 0.5 - lw2 / 2, ly0, lw2, ly1 - ly0);
    ctx.fillStyle = '#8a7452';
    const rungs2 = Math.max(3, Math.round((ly1 - ly0) / 8));
    for (let i3 = 0; i3 < rungs2; i3++){
      ctx.fillRect(x + W * 0.5 - lw2 / 2 + 2, ly0 + 2 + i3 * (ly1 - ly0 - 4) / rungs2, lw2 - 4, 1.8);
    }
  } else if (c === 'wreckcar' || c === 'wreckcarHalf'){
    /* 报废汽车（第 62 轮）：俯视的锈车，8 款（6 个配色 + 缺头 + 断一半），配色全在 data/covers.js 的 CAR_SKIN。
       · 无血量、打不掉 —— st:'solid'，永远不进 L.brk，damageWall 也不认它
       · 挡视线：sight 默认 'high'（木箱那种腰高的才写 'low'）
       俯视图的辨识点（少一个就变成"长凳"或"货箱"）：
         车头收窄 → 前风挡 → 车顶（比车身窄）→ 后窗 → 后备箱，四轮从车身底下露出来。 */
    const CS = (typeof CAR_SKIN !== 'undefined' && CAR_SKIN[w.skin]) ||
               (typeof CAR_SKIN !== 'undefined' && CAR_SKIN.rust) ||
               { body:'#5a4e42', roof:'#6a5e50', edge:'#17130f', rust:'rgba(126,76,38,0.34)' };
    const half = !!CS.half, noHead = !!CS.noHead, burnt = !!CS.burnt;
    const carBody = CS.body, carRoof = CS.roof, carEdge = CS.edge, rustC = CS.rust || 'rgba(126,76,38,0.32)';
    const X = f => x + W * f;
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, W, H); ctx.clip();

    /* 车轮与车身的上下边界：**必须贴着 AABB 的边缘**（0 和 1）。
       第 64 轮用户报过"碰撞体积和视觉对不上，玩家下面还有那么多空位"——
       根因就是车身只画到 y+H*0.17 … y+H*0.83，上下各留 13px 的视觉空隙，
       但碰撞箱用的是整个 132×78，人站在车下面会被一条看不见的边挡住。
       现在：车轮顶到 y 和 y+H，车身从 0.15 到 0.85，整块 AABB 都被画满。 */
    const wTop = 0.15, wBot = 0.85;

    /* 自己的影子：跟着车身形状走，不是整个 AABB 的方框（套方框四角会露黑边） */
    ctx.fillStyle = 'rgba(0,0,0,0.30)';
    ctx.beginPath();
    ctx.moveTo(X(0.07) + 3, y + H * 0.30 + 4);
    ctx.lineTo(X(0.94) + 3, y + H * wTop + 4);
    ctx.lineTo(X(0.94) + 3, y + H * wBot + 4);
    ctx.lineTo(X(0.07) + 3, y + H * 0.70 + 4);
    ctx.closePath();
    ctx.fill();

    /* —— 车轮先画：压在车身外侧，正好把 AABB 的上下边缘填满 —— */
    const ww = Math.max(10, W * 0.095), wh = Math.max(8, H * 0.15);
    const wheel = (fx, fy, gone) => {
      const wx = X(fx), wy = y + H * fy - wh * 0.5;   /* fy = 轮子中心 */
      ctx.fillStyle = gone ? '#070605' : '#0b0908';
      ctx.fillRect(wx, wy, ww, wh);
      if (!gone){
        ctx.fillStyle = 'rgba(198,184,158,0.14)';
        ctx.fillRect(wx + 1, wy + 1, ww - 2, 1.4);
      }
    };
    if (half){
      wheel(0.55, 0.075, false); wheel(0.55, 0.925, true);    /* 只剩后半段：后轴一对，左后缺 */
      wheel(0.16, 0.30, false);                                /* 断口处翘出来的一截轮轴 */
    } else {
      wheel(0.115, 0.075, false); wheel(0.115, 0.925, !noHead);  /* 左前（缺头的那辆前轮也炸没了）*/
      wheel(0.745, 0.075, false); wheel(0.745, 0.925, false);
    }

    /* —— 车身 —— */
    const ny0 = y + H * 0.21, ny1 = y + H * 0.79;   /* 车头那端收进来 */
    const ty0 = y + H * wTop, ty1 = y + H * wBot;   /* 车尾那端顶到 AABB 边缘 */
    const f0 = half ? 0.10 : (noHead ? 0.24 : 0.05);
    const bx0 = X(f0), bx1 = X(0.95);
    ctx.beginPath();
    if (half || noHead){
      /* 断口 / 撞烂的车头：不做圆角，走锯齿，一眼看得出"断了" */
      ctx.moveTo(bx0, y + H * 0.34);
      ctx.lineTo(bx0 + W * 0.035, y + H * 0.42);
      ctx.lineTo(bx0 - W * 0.01, y + H * 0.52);
      ctx.lineTo(bx0 + W * 0.03, y + H * 0.62);
      ctx.lineTo(bx0, y + H * 0.72);
      ctx.lineTo(bx1 - W * 0.03, ty1);
    } else {
      ctx.moveTo(bx0, ny0);
      ctx.lineTo(bx1 - W * 0.03, ty0);
    }
    ctx.quadraticCurveTo(bx1, ty0, bx1, y + H * 0.30);
    ctx.lineTo(bx1, y + H * 0.70);
    ctx.quadraticCurveTo(bx1, ty1, bx1 - W * 0.03, ty1);
    if (!(half || noHead)){ ctx.lineTo(bx0, ny1); }
    ctx.quadraticCurveTo(bx0 - W * 0.01, y + H * 0.74, bx0 - W * 0.01, y + H * 0.40);
    ctx.lineTo(bx0 - W * 0.01, y + H * 0.34);
    ctx.closePath();
    ctx.fillStyle = carBody; ctx.fill();
    ctx.strokeStyle = carEdge; ctx.lineWidth = 2; ctx.stroke();

    /* —— 分段：引擎盖 / 前风挡 / 车顶 / 后窗 / 后备箱（残的两种少掉前面几段）—— */
    let sec;
    if (half) sec = [ { a:0.13, b:0.44, k:'roof' }, { a:0.44, b:0.58, k:'glass' }, { a:0.58, b:0.92, k:'trunk' } ];
    else if (noHead) sec = [ { a:0.34, b:0.58, k:'roof' }, { a:0.58, b:0.68, k:'glass' }, { a:0.68, b:0.93, k:'trunk' } ];
    else sec = [ { a:0.06, b:0.26, k:'hood' }, { a:0.26, b:0.35, k:'glass' },
                 { a:0.35, b:0.65, k:'roof' }, { a:0.65, b:0.74, k:'glass' }, { a:0.74, b:0.94, k:'trunk' } ];
    const gy0 = y + H * 0.185, gy1 = y + H * 0.815;
    for (const t of sec){
      const sx = X(t.a), sw = X(t.b) - sx;
      if (t.k === 'glass'){
        ctx.fillStyle = burnt ? '#0a0b0c' : '#0d1418';
        ctx.fillRect(sx, gy0, sw, gy1 - gy0);
        ctx.fillStyle = burnt ? 'rgba(150,150,150,0.14)' : 'rgba(146,178,206,0.30)';
        ctx.fillRect(sx + 1, gy0 + (gy1 - gy0) * 0.16, Math.max(2, sw * 0.55), 1.6);
        ctx.fillStyle = burnt ? 'rgba(150,150,150,0.08)' : 'rgba(146,178,206,0.16)';
        ctx.fillRect(sx + 1, gy0 + (gy1 - gy0) * 0.62, Math.max(2, sw * 0.8), 1.2);
        ctx.fillStyle = 'rgba(214,224,232,0.10)';
        ctx.fillRect(sx, gy0, 1.2, gy1 - gy0);
        ctx.fillRect(sx + sw - 1.2, gy0, 1.2, gy1 - gy0);
      } else if (t.k === 'roof'){
        ctx.fillStyle = carRoof;
        ctx.fillRect(sx, gy0 + 2, sw, (gy1 - gy0) - 4);
        ctx.fillStyle = 'rgba(0,0,0,0.30)';
        ctx.fillRect(sx, gy0, 2, gy1 - gy0);
        ctx.fillRect(sx + sw - 2, gy0, 2, gy1 - gy0);
        ctx.fillStyle = 'rgba(255,255,255,0.05)';
        ctx.fillRect(sx + 2, gy0 + 2, sw - 4, 2);
      } else {
        ctx.fillStyle = 'rgba(0,0,0,0.16)';
        ctx.fillRect(sx, gy0, sw, gy1 - gy0);
        ctx.fillStyle = 'rgba(255,255,255,0.05)';
        ctx.fillRect(sx + 2, y + H * 0.40, sw - 4, 1.4);
        ctx.fillRect(sx + 2, y + H * 0.60, sw - 4, 1.4);
      }
    }
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    for (const t of sec) if (t.k !== 'hood') ctx.fillRect(X(t.a) - 0.8, gy0, 1.6, gy1 - gy0);

    /* —— 车灯：有车头才画前灯；尾巴那盏永远留一道红 —— */
    if (!half && !noHead){
      ctx.fillStyle = burnt ? 'rgba(120,110,96,0.30)' : 'rgba(238,214,150,0.42)';
      ctx.fillRect(X(0.065), y + H * 0.30, Math.max(3, W * 0.03), Math.max(3, H * 0.10));
      ctx.fillRect(X(0.065), y + H * 0.60, Math.max(3, W * 0.03), Math.max(3, H * 0.10));
    }
    ctx.fillStyle = burnt ? 'rgba(120,50,40,0.30)' : 'rgba(176,58,44,0.40)';
    ctx.fillRect(X(0.925), y + H * 0.30, Math.max(2.6, W * 0.025), Math.max(3, H * 0.10));

    /* —— 断口：撞烂的车头 / 撕开的半截。别糊一整块黑（会变成一坨脏影子），
       要的是"金属撕开"：一条亮茬 + 两道黑缝 + 一截翘出来的铁皮 —— */
    if (noHead || half){
      const ex = X(f0);
      ctx.fillStyle = burnt ? 'rgba(150,146,138,0.30)' : 'rgba(206,196,176,0.34)';
      ctx.beginPath();
      ctx.moveTo(ex - W * 0.008, y + H * 0.30);
      ctx.lineTo(ex + W * 0.030, y + H * 0.38);
      ctx.lineTo(ex + W * 0.004, y + H * 0.46);
      ctx.lineTo(ex + W * 0.034, y + H * 0.54);
      ctx.lineTo(ex + W * 0.002, y + H * 0.62);
      ctx.lineTo(ex + W * 0.026, y + H * 0.70);
      ctx.lineTo(ex - W * 0.008, y + H * 0.74);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(10,8,6,0.55)';
      for (let k = 0; k < 2; k++){
        ctx.fillRect(ex + W * 0.012, y + H * (0.34 + k * 0.20), Math.max(1.5, W * 0.016), H * 0.09);
      }
      /* 翘出来的一截铁皮 */
      ctx.fillStyle = carBody;
      ctx.strokeStyle = carEdge; ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(ex + W * 0.02, y + H * 0.44);
      ctx.lineTo(ex + W * 0.12, y + H * 0.33);
      ctx.lineTo(ex + W * 0.13, y + H * 0.41);
      ctx.lineTo(ex + W * 0.03, y + H * 0.52);
      ctx.closePath(); ctx.fill(); ctx.stroke();
    }

    /* —— 锈斑 / 焦痕（稳定伪随机，不占全局 RNG）—— */
    for (let k = 0; k < 18; k++){
      const rx = X(0.08) + covHash(x + k * 29, y + k * 13) * W * 0.84;
      const ry = y + H * 0.22 + covHash(y + k * 17, x + k * 31) * H * 0.58;
      const rr = 1.4 + covHash(rx, ry) * Math.min(5, H * 0.11);
      ctx.fillStyle = k % 3 ? rustC : (burnt ? 'rgba(170,164,152,0.14)' : 'rgba(24,18,12,0.34)');
      ctx.beginPath(); ctx.arc(rx, ry, rr, 0, TAU); ctx.fill();
    }

    /* —— 塌陷：车顶后半压凹一小块 + 亮折痕（画大了就成破洞）—— */
    const dentA = half ? 0.26 : (noHead ? 0.46 : 0.52);
    const dentB = half ? 0.38 : (noHead ? 0.55 : 0.63);
    ctx.fillStyle = 'rgba(0,0,0,0.26)';
    ctx.beginPath();
    ctx.moveTo(X(dentA), gy0 + (gy1 - gy0) * 0.28);
    ctx.lineTo(X(dentB), gy0 + (gy1 - gy0) * 0.20);
    ctx.lineTo(X(dentB), gy0 + (gy1 - gy0) * 0.72);
    ctx.lineTo(X(dentA + 0.01), gy0 + (gy1 - gy0) * 0.80);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(226,216,196,0.16)'; ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(X(dentA), gy0 + (gy1 - gy0) * 0.28);
    ctx.lineTo(X(dentA + 0.01), gy0 + (gy1 - gy0) * 0.80);
    ctx.stroke();

    /* 上沿受光 + 下沿投影 */
    ctx.fillStyle = 'rgba(226,216,196,0.08)';
    ctx.fillRect(X(0.10), y + H * 0.20, W * 0.80, 1.4);
    ctx.fillStyle = 'rgba(0,0,0,0.32)';
    ctx.fillRect(X(0.10), y + H * 0.80, W * 0.80, 2);
    ctx.restore();

  } else if (c === 'pillar'){
    /* 水泥墩 / 立柱：比普通墙亮一档、带一圈倒角，看得出来是个"墩" */
    ctx.fillStyle = THEME_LIGHT ? PAL.P280 : PAL.P22;
    ctx.fillRect(x, y, W, H);
    ctx.fillStyle = 'rgba(255,255,255,0.07)';
    ctx.fillRect(x + 2, y + 2, W - 4, Math.max(3, H * 0.18));
    ctx.fillStyle = 'rgba(0,0,0,0.22)';
    ctx.fillRect(x + 2, y + H - 6, W - 4, 4);
    ctx.strokeStyle = THEME_LIGHT ? PAL.P306 : PAL.P24; ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, W - 2, H - 2);
    /* 顶上一个缺角，让它不像是从墙里剪下来的方块 */
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    ctx.beginPath();
    ctx.moveTo(x + W - 2, y + H * 0.30);
    ctx.lineTo(x + W * 0.72, y + H * 0.12);
    ctx.lineTo(x + W - 2, y + 2);
    ctx.closePath(); ctx.fill();

  } else if (c === 'shelf' || c === 'panel'){
    /* 货架 / 铁挡板：跟元代码里的铁皮墙一致（冷板 + 高光 + 四角铆钉） */
    ctx.fillStyle = THEME_LIGHT ? PAL.P25 : PAL.P24;
    ctx.fillRect(x, y, W, H);
    ctx.fillStyle = THEME_LIGHT ? 'rgba(150,175,200,0.20)' : 'rgba(150,175,200,0.17)';
    ctx.fillRect(x + 2, y + 2, Math.max(2, W * 0.28), Math.max(2, H - 4));
    ctx.fillRect(x + 2, y + 2, Math.max(2, W - 4), Math.max(2, H * 0.16));
    ctx.strokeStyle = PAL.P27; ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, W - 2, H - 2);
    ctx.fillStyle = THEME_LIGHT ? PAL.P30 : PAL.P27;
    const rv = Math.max(2, Math.min(3.2, Math.min(W, H) * 0.10));
    const pad = Math.min(W, H) * 0.5;
    for (const t of [[x + pad, y + pad], [x + W - pad, y + pad],
                     [x + pad, y + H - pad], [x + W - pad, y + H - pad]]){
      ctx.beginPath(); ctx.arc(t[0], t[1], rv, 0, TAU); ctx.fill();
    }

  } else {
    /* 兜底：清单里没登记的类型按水泥墙画，绝不画成空白 */
    ctx.fillStyle = THEME_LIGHT ? PAL.P280 : PAL.P22;
    ctx.fillRect(x, y, W, H);
    ctx.strokeStyle = THEME_LIGHT ? PAL.P306 : PAL.P24; ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, W - 2, H - 2);
  }
  if (typeof drawCoverFlash === 'function') drawCoverFlash(w);
}
