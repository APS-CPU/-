/* 交替掩护跃进（bounding overwatch）—— m37743
   两个人一组：一个原地压制（"架枪"），另一个往当前敌对目标跃进 150px；到位后交换角色。
   只在 humanOn(L) 的关生效，且只在"两个人都看得见同一目标"时用，
   这样不会和躲掩体 / 包抄 / 盲射那几套状态机抢控制权。

   注意：这里只做两件很轻的事
     ①给"跃进的那个"写一个临时路点（e.wp 一套现成机制，正常 AI 会走过去）
     ②给"架枪的那个"置 e.boundHold（移动段看到就 speed = 0），并周期性触发一次压制扫射
   不接管朝向、不接管开火 —— 开火仍走原来的逻辑，避免"开枪的人变成木头"。 */

var BOUND_DEF = {
  on: true,
  pairR: 460,      /* 两个人相距多远以内算一组 */
  minR: 200,       /* 离玩家太近就不跃进了（已经贴脸，直接打） */
  maxR: 900,       /* 太远也不跃进（先跑过来） */
  leap: 150,       /* 一次跃进的距离 */
  moveT: 2.6,      /* 跃进最多持续这么久，超时就交换 */
  overT: 2.6,      /* 架枪最多持续这么久 */
  arrive: 52,      /* 距目标点这么近算到位 */
  cd: 2.4,         /* 一组交换完的冷却 */
  pairCd: 1.2,     /* 新组的冷却 */
  /* 压制要"压得住"：一梭子打久一点、间隔短一点、子弹扫得宽一点，
     让玩家探头的那一瞬间有实打实的"会被打中"的预期。 */
  sprayT: 1.70,    /* 压制一次打多久（要盖住同伴整个跃进过程） */
  sprayGap: 1.05,  /* 两次压制之间至少隔多久（几乎不停火） */
  sprayN: 10,      /* 一梭子几发 */
  sprayStep: 0.085,/* 发与发之间的间隔 */
  sprayJit: 0.50,  /* 扫射半角（rad）：±28°，正好扫过掩体边缘 */
  moveSpdK: 1.38,  /* 跃进的加速度倍率（冲刺感） */
  barkP: 0.45
};
var boundPairSeq = 0, boundGroupCd = 0;

function boundTargetOf(e){
  var t=e&&e.bound&&typeof tacticTargetById==='function'?tacticTargetById(e.bound.targetId):null;
  if(t&&factionWantsFight(e,t))return t;
  t=(typeof enemyTargetEntity==='function')?enemyTargetEntity(e):null;
  if(t&&typeof tacticTargetAlive==='function'&&tacticTargetAlive(t)&&factionWantsFight(e,t))return t;
  for(const q of [e&&e.lastKnownSource,e&&e.heardSource])
    if(q&&(!q.dead)&&(q.hp===undefined||q.hp>0)&&factionWantsFight(e,q))return q;
  return null;
}
function boundTargetPoint(e,t){
  if(e&&e.sees&&t&&enemyTargetEntity(e)===t)return {x:t.x,y:t.y};
  if(e&&e.bound&&Number.isFinite(e.bound.tx)&&Number.isFinite(e.bound.ty))return {x:e.bound.tx,y:e.bound.ty};
  return e&&e.lastKnown?{x:e.lastKnown.x,y:e.lastKnown.y}:(t?{x:t.x,y:t.y}:null);
}

function boundReset(){
  boundGroupCd = 0;
  for (var i = 0; i < enemies.length; i++){ boundDrop(enemies[i]); }
}
/* 跃进会临时改写 e.wp（沿用巡逻那套路点），收尾必须原样还回去，
   否则巡逻线被换成一个点，老关卡里敌人就再也回不到自己的巡逻路线。 */
function boundRestore(e){
  if (!e || !e.boundSaved) return;
  var s = e.boundSaved;
  /* 跃进是"往巡逻线末尾临时追加一个点"，所以这里只截回原来的长度，
     不换数组 —— 换数组会让巡逻线在别处（存档、测试、读档）看起来变成 1 个点。 */
  if (e.wp && e.wp.length > s.len) e.wp.length = s.len;
  e.i = s.i; e.wait = s.wait; e.goal = s.goal; e.path = s.path;
  e.boundSaved = null; e.boundWp = null;
}
function boundDrop(e){
  if (!e) return;
  if(e.suppressOwner==='bound'){
    if(typeof eStatusClear==='function')eStatusClear(e,'suppress');
    e.suppressOwner=null;e.suppressPoints=null;
  }
  e.bound = null; e.boundHold = 0; e.boundSpdK = 1;
  e.boundWp = null;
  boundRestore(e);
}
function boundEligible(e, L){
  if (!e || e.dead || e.gone) return false;
  var T = null;
  try { T = enemyType(e); } catch (err){ return false; }
  if (!T || T.static || T.fly || T.kind === 'blade' || !T.canShoot) return false;
  /* 交替掩护跃进是训练水平的事：普通小兵不做，只有老兵/精英做 */
  if (typeof tacticsPlus === 'function' && !tacticsPlus(e, L || cur())) return false;
  if (e.faction === 'player') return false;
  if (e.flank || e.tacticPhase || e.hideGoal || e.fleeing) return false;
  if (e.mode === 0) return false;            /* 巡逻中的不跃进：不能把巡逻线换成临时路点 */
  if (e.boundWait > 0) return false;
  if (!e.sees) return false;                 /* 只在看得见当前目标时用，避免和"找人"那套打架 */
  if (!(e.ammo > 0) || e.reloading > 0) return false;
  var target=boundTargetOf(e);
  if(!target)return false;
  var d = dist(e.x, e.y, target.x, target.y);
  return d >= BOUND_DEF.minR && d <= BOUND_DEF.maxR;
}
/* 为什么这个人不能进组？（调试/测试用，返回第一个不满足的条件） */
function boundWhy(e, L){
  if (!e) return 'no-entity';
  if (e.dead || e.gone) return 'dead';
  var T = null;
  try { T = enemyType(e); } catch (err){ return 'no-type'; }
  if (!T) return 'no-type';
  if (T.static) return 'static';
  if (T.fly) return 'fly';
  if (T.kind === 'blade') return 'blade';
  if (!T.canShoot) return 'no-gun';
  if (e.faction === 'player') return 'player-side';
  if (e.flank) return 'flanking';
  if (e.tacticPhase) return 'tactic:' + e.tacticPhase;
  if (e.hideGoal) return 'hiding';
  if (e.fleeing) return 'fleeing';
  if (e.mode === 0) return 'patrolling';
  if (e.boundWait > 0) return 'cooldown';
  if (!e.sees) return 'cannot-see';
  if (!(e.ammo > 0)) return 'no-ammo';
  if (e.reloading > 0) return 'reloading';
  var target=boundTargetOf(e);
  if(!target)return 'no-target';
  var d = dist(e.x, e.y, target.x, target.y);
  if (d < BOUND_DEF.minR) return 'too-close(' + Math.round(d) + ')';
  if (d > BOUND_DEF.maxR) return 'too-far(' + Math.round(d) + ')';
  return 'ok';
}
function boundSpray(e){
  if (typeof eStatusSet !== 'function' || typeof eStatusHas !== 'function') return;
  if (e.boundSprayLock > 0) return;
  if (eStatusHas(e, 'suppress') || eStatusHas(e, 'hurt') || eStatusHas(e, 'stun')) return;
  var target=boundTargetOf(e),point=boundTargetPoint(e,target);
  if(!target||!point)return false;
  /* 只扫真实可见的目标/掩体出口。没有可见拐角就暂缓，禁止隔墙锁实体坐标。 */
  var lane=(typeof tacticalSuppressPoints==='function')?tacticalSuppressPoints(e,point):[];
  if(!lane.length){e.boundSprayLock=.18;return false;}
  eStatusSet(e, 'suppress', BOUND_DEF.sprayT);
  e.suppressPoints=lane;e.suppressOwner='bound';
  e.suppressAng = Math.atan2(lane[0].y - e.y, lane[0].x - e.x);
  e.suppressN = BOUND_DEF.sprayN;
  e.suppressGap = BOUND_DEF.sprayStep;
  e.suppressI = 0;
  e.suppressJit = .015;
  e.suppressStep = 0;
  e.suppressDir = (Math.random() < 0.5 ? -1 : 1);
  e.boundSprayLock = BOUND_DEF.sprayGap;
  /* 架枪位不许打到一半哑火：每次压制前补满一梭子（换弹匣留给两次压制之间） */
  if ((e.ammo | 0) < BOUND_DEF.sprayN){ e.reloading = 0; e.ammo = BOUND_DEF.sprayN; }
  return true;
}
/* 把跃进目标点定在“自己和当前目标之间、最多 leap 远”的地方；被墙挡住就往两侧让一点 */
function boundLeapPoint(L, e){
  var target=boundTargetOf(e),point=boundTargetPoint(e,target);
  if(!target||!point)return null;
  var a = Math.atan2(point.y - e.y, point.x - e.x);
  var d = Math.min(BOUND_DEF.leap, Math.max(60, dist(e.x, e.y, point.x, point.y) - BOUND_DEF.minR * 0.8));
  var tries = [0, 0.42, -0.42, 0.8, -0.8, 1.2, -1.2];
  for (var i = 0; i < tries.length; i++){
    var x = e.x + Math.cos(a + tries[i]) * d;
    var y = e.y + Math.sin(a + tries[i]) * d;
    if (typeof navBlockedAt === 'function' && navBlockedAt(L, x, y)) continue;
    if (typeof clearWalkLine === 'function' && !clearWalkLine(L, e.x, e.y, x, y)) continue;
    return { x: x, y: y };
  }
  return null;
}
function boundSetLeap(L, e){
  var p = boundLeapPoint(L, e);
  if (!p) return false;
  if (!e.wp) e.wp = [];
  if (!e.boundSaved) e.boundSaved = { len: e.wp.length, i: e.i, wait: e.wait, goal: e.goal, path: e.path };
  e.wp.push([p.x, p.y]);
  e.i = e.wp.length - 1;
  e.path = null; e.goal = null; e.wait = 0;
  e.boundWp = p;
  e.boundSpdK = BOUND_DEF.moveSpdK;      /* 冲过去，别散步 */
  e.fireCd = Math.max(e.fireCd || 0, 0.28);  /* 冲刺那一下不还击：要跑就真跑 */
  return true;
}
function boundSwap(L, a, b){
  var id = a.bound ? a.bound.id : (b.bound ? b.bound.id : 0);
  var over = (a.bound && a.bound.role === 'over') ? a : b;
  var move = (over === a) ? b : a;
  var nm = over, no = move;
  var old=over.bound||move.bound||{};
  /* 老架枪手现在要跃进：立即停掉上一轮压制，不能边跑边继续扫。 */
  if(nm.suppressOwner==='bound'){
    eStatusClear(nm,'suppress');nm.suppressOwner=null;nm.suppressPoints=null;
  }
  const contactT=Math.max(old.contactT||0,(no.bound&&no.bound.contactT)||0);
  nm.bound = { id: id, role: 'move', peer: no, targetId:old.targetId, tx:old.tx, ty:old.ty, contactT };
  no.bound = { id: id, role: 'over', peer: nm, targetId:old.targetId, tx:old.tx, ty:old.ty, contactT };
  nm.boundT = 0; no.boundT = 0;
  nm.boundWait = BOUND_DEF.cd; no.boundWait = BOUND_DEF.cd;
  /* 变成架枪位的那个：把巡逻线还回去，站回原来的站位，速度恢复 */
  no.boundWp = null; no.boundSpdK = 1; no.boundHold = 0;
  boundRestore(no);
  if (!boundSetLeap(L, nm)){ nm.bound = null; no.bound = null; boundGroupCd = BOUND_DEF.cd; return false; }
  if (typeof tacBump === 'function') tacBump('bound');
  if (Math.random() < BOUND_DEF.barkP) setBark(nm, '我上！你压住！', 1.6, 1);
  return true;
}
function boundTick(L, dt){
  if (!BOUND_DEF.on) return;
  if (typeof humanOn === 'function' && !humanOn(L)) return;
  boundGroupCd = Math.max(0, boundGroupCd - dt);
  var i, e;
  for (i = 0; i < enemies.length; i++){
    e = enemies[i];
    if (e.boundWait > 0) e.boundWait = Math.max(0, e.boundWait - dt);
    if (e.boundSprayLock > 0) e.boundSprayLock = Math.max(0, e.boundSprayLock - dt);
  }
  /* 维护已有的组 */
  var seenIds = {};
  for (i = 0; i < enemies.length; i++){
    e = enemies[i];
    if (!e.bound) continue;
    var id = e.bound.id;
    if (seenIds[id]) continue;
    seenIds[id] = 1;
    var peer = e.bound.peer;
    var okA = e.bound && boundEligible2(e, L), okB = peer.bound && boundEligible2(peer, L);
    if (!okA || !okB){ boundDrop(e); boundDrop(peer); boundGroupCd = BOUND_DEF.pairCd; continue; }
    e.boundT += dt; peer.boundT += dt;
    var mover = (e.bound.role === 'move') ? e : peer;
    var over = (mover === e) ? peer : e;
    var target=boundTargetOf(over)||boundTargetOf(mover);
    if(!target){boundDrop(e);boundDrop(peer);boundGroupCd=BOUND_DEF.pairCd;continue;}
    const hasContact=(over.sees&&enemyTargetEntity(over)===target)||(mover.sees&&enemyTargetEntity(mover)===target);
    if(hasContact){
      e.bound.tx=peer.bound.tx=target.x;e.bound.ty=peer.bound.ty=target.y;
      e.bound.contactT=peer.bound.contactT=3.2;
    }else{
      /* 跃进组丢失目标后只压住最后出口一小段时间。旧逻辑只检查距离，
         因此目标早已离开也会每秒重新开一梭子，持续朝废车/旧墙角扫射。 */
      const left=Math.max(0,Math.min(e.bound.contactT||0,peer.bound.contactT||0)-dt);
      e.bound.contactT=peer.bound.contactT=left;
      if(left<=0){boundDrop(e);boundDrop(peer);boundGroupCd=BOUND_DEF.pairCd;continue;}
    }
    /* 架枪的：站住 + 周期性压制 */
    over.boundHold = 0.2;
    boundSpray(over);
    /* 跃进的：朝路点走；到位 / 超时 / 路点没了就交换 */
    var reached = mover.boundWp && dist(mover.x, mover.y, mover.boundWp.x, mover.boundWp.y) < BOUND_DEF.arrive;
    if (reached || mover.boundT > BOUND_DEF.moveT || !mover.boundWp){
      over.boundHold = 0;
      mover.boundSpdK = 1;              /* 到位就恢复正常速度 */
      boundSwap(L, e, peer);
    } else {
      if (!mover.wp || !mover.wp.length) boundSetLeap(L, mover);
      /* 冲刺期间保持加速（每次 setLeap 会重置，这里兜底）。
         注意：只能在"没人交换"的分支里加，否则交换之后 mover 已经变成架枪的那个，
         会把加速塞给新架枪位 → 架枪的满场跑。 */
      mover.boundSpdK = BOUND_DEF.moveSpdK;
    }
  }
  /* 组建新组：两个人相距近、同阵营、都看见同一敌对目标、都空闲 */
  if (boundGroupCd > 0) return;
  var pool = [];
  for (i = 0; i < enemies.length; i++){
    e = enemies[i];
    if (e.bound) continue;
    if (boundEligible(e, L)) pool.push(e);
  }
  if (pool.length < 2) return;
  var best = null, bestD = 1e9;
  for (i = 0; i < pool.length; i++){
    for (var j = i + 1; j < pool.length; j++){
      var dd = dist(pool[i].x, pool[i].y, pool[j].x, pool[j].y);
      if (dd > BOUND_DEF.pairR) continue;
      var ta=boundTargetOf(pool[i]),tb=boundTargetOf(pool[j]);
      if(!ta||!tb||tacticTargetId(ta)!==tacticTargetId(tb)||combatFaction(pool[i])!==combatFaction(pool[j]))continue;
      if (dd < bestD){ bestD = dd; best = [pool[i], pool[j]]; }
    }
  }
  if (!best) return;
  var a = best[0], b = best[1];
  var target=boundTargetOf(a),targetId=tacticTargetId(target);
  if(!target)return;
  /* 远的那个先跃进，近的那个架枪 */
  var da = dist(a.x, a.y, target.x, target.y), db = dist(b.x, b.y, target.x, target.y);
  var mover = (da >= db) ? a : b, over = (mover === a) ? b : a;
  var pair = ++boundPairSeq;
  mover.bound = { id: pair, role: 'move', peer: over, targetId:targetId, tx:target.x, ty:target.y, contactT:3.2 };
  over.bound = { id: pair, role: 'over', peer: mover, targetId:targetId, tx:target.x, ty:target.y, contactT:3.2 };
  mover.boundT = 0; over.boundT = 0;
  mover.boundWait = BOUND_DEF.cd; over.boundWait = BOUND_DEF.cd;
  if (!boundSetLeap(L, mover)){ boundDrop(mover); boundDrop(over); boundGroupCd = BOUND_DEF.pairCd; return; }
  if (typeof tacBump === 'function') tacBump('bound');
  if (Math.random() < BOUND_DEF.barkP) setBark(over, '我压住，你上！', 1.6, 1);
}
/* 维护时用的宽松判定：允许已经看不见（打着打着烟起来了），但别在被冻/被晕时硬撑 */
function boundEligible2(e, L){
  if (!e || e.dead || e.gone) return false;
  var T = null;
  try { T = enemyType(e); } catch (err){ return false; }
  if (!T || T.static || T.fly) return false;
  if (e.flank || e.fleeing) return false;
  if (typeof eStatusHas === 'function' && (eStatusHas(e, 'stun') || eStatusHas(e, 'hurt'))) return false;
  var target=boundTargetOf(e),point=boundTargetPoint(e,target);
  return !!target&&!!point&&dist(e.x,e.y,point.x,point.y)<=BOUND_DEF.maxR;
}
