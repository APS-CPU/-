/* 74-menubg.js —— m33007：主界面背景
   雨夜街区：远处楼群剪影 + 斜雨 + 零星窗灯 + 偶尔一次很淡的远景闪电。
   1) 楼群在初始化时按固定种子算好，之后每帧只是几次 fillRect，不重新算布局。
   2) 画质关（perfLv() >= 2）只留静态剪影，不画雨和闪电。
   3) 闪电是"远处"的：只提亮天光、不闪白整屏，避免主界面看着像故障。 */
(function(){
  'use strict';

  let mbW = 0, mbH = 0;          /* 记住上次按哪个体积算的，尺寸变了才重算 */
  let mbFar = [], mbNear = [];   /* 两层楼群：远=更低更暗，近=更高更实 */
  let mbLights = [];             /* 零星窗灯 + 路灯 */
  let mbRain = [];               /* 雨丝（斜的，跟风向一起摆） */
  let mbT = 0;                   /* 背景自己的时钟 */
  let mbBolt = -99;              /* 上一次闪电的时刻 */
  let mbNextBolt = 4;            /* 下一次闪电的间隔 */

  /* 固定种子的小随机：每次开游戏楼群一样，不会一刷新就换一条街 */
  function mbRnd(seed){
    let s = seed >>> 0;
    return function(){
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
  }

  function baseYTop(h, r){ return mbH * 0.78 - h * (0.10 + r * 0.78); }

  function mbBuild(){
    /* 先把尺寸记下来：下面的循环和雨量都要用 mbW/mbH，否则第一次会按 0 算，楼和雨全是空的 */
    mbW = W; mbH = H;
    const rnd = mbRnd(20260101);
    mbFar = []; mbNear = []; mbLights = [];
    /* 远层：从右往左拼一堆矮楼，底部落在 H*0.86 */
    let x = -60;
    while (x < mbW + 80){
      const w = 46 + rnd() * 74;
      const h = mbH * (0.10 + rnd() * 0.16);
      mbFar.push({ x: x, w: w, h: h });
      /* 远层偶尔一盏窗灯 */
      if (rnd() < 0.5){
        mbLights.push({ x: x + w * (0.2 + rnd() * 0.6), y: mbH * 0.86 - h * (0.25 + rnd() * 0.55),
                        r: 1.1 + rnd() * 1.2, a: 0.28 + rnd() * 0.30, ph: rnd() * 6.28, warm: rnd() < 0.5 });
      }
      x += w + 6 + rnd() * 16;
    }
    /* 近层：更高、更稀、更暗 */
    x = -80;
    while (x < mbW + 120){
      const w = 70 + rnd() * 120;
      const h = mbH * (0.16 + rnd() * 0.26);
      const b2 = { x: x, w: w, h: h, props: [], wins: [] };
      /* 楼顶细节：水箱 / 天线 / 女儿墙，免得一排方盒子太假 */
      const np = rnd() < 0.55 ? 1 + Math.floor(rnd() * 2) : 0;
      for (let k = 0; k < np; k++){
        const px2 = x + w * (0.15 + rnd() * 0.7);
        if (rnd() < 0.5) b2.props.push({ k: 'tank', x: px2, w: 10 + rnd() * 12, h: 7 + rnd() * 9 });
        else b2.props.push({ k: 'ant', x: px2, h: 14 + rnd() * 26 });
      }
      /* 亮窗：不是每栋都亮，亮的那几栋也稀稀拉拉 */
      if (rnd() < 0.55){
        const nw = 1 + Math.floor(rnd() * 4);
        for (let k = 0; k < nw; k++){
          b2.wins.push({ x: x + 6 + rnd() * Math.max(4, w - 14), y: baseYTop(h, rnd()), a: 0.30 + rnd() * 0.45,
                         ph: rnd() * 6.28, warm: rnd() < 0.62 });
        }
      }
      mbNear.push(b2);
      x += w + 40 + rnd() * 120;
    }
    /* 雨丝：按屏幕宽高撒，密度跟画质走（下面画的时候再按 perfLv 砍） */
    mbRain = [];
    const n = Math.round(mbW * mbH / 26000);
    for (let i = 0; i < n; i++){
      mbRain.push({ x: rnd() * (mbW + 200) - 100, y: rnd() * mbH,
                    len: 10 + rnd() * 20, sp: 380 + rnd() * 320, a: 0.16 + rnd() * 0.18 });
    }
  }

  function menuBgTick(dt){
    if (typeof W !== 'number' || typeof H !== 'number') return;
    if (mbW !== W || mbH !== H || !mbFar.length) mbBuild();
    mbT += (dt > 0 ? dt : 0.016);
    if (mbT > mbNextBolt){ mbBolt = mbT; mbNextBolt = mbT + 6 + Math.random() * 9; }
  }

  /* 天光颜色：平时是深蓝黑，闪电时整体提一点冷白 */
  function mbSky(){
    const since = mbT - mbBolt;
    let k = 0;
    if (since >= 0 && since < 0.55){
      /* 两下：先一下强的，再一下弱的，像远处连续两次的雷 */
      k = since < 0.16 ? Math.sin(since / 0.16 * Math.PI) : (since > 0.30 && since < 0.46 ? 0.45 * Math.sin((since - 0.30) / 0.16 * Math.PI) : 0);
    }
    return k;
  }

  function drawMenuBg(){
    if (typeof W !== 'number' || typeof H !== 'number') return;
    if (mbW !== W || mbH !== H || !mbFar.length) mbBuild();
    const lv = (typeof perfLv === 'function') ? perfLv() : 0;
    const flash = mbSky();

    /* 天空：上深下亮一点，像城市边缘的天光 */
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#060a10');
    g.addColorStop(0.42, '#0e1a26');
    g.addColorStop(0.74, '#213247');
    g.addColorStop(1, '#0b1219');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    /* 地平线往上的一层城市辉光：楼才有"站在天光里"的层次，不然全糊成黑 */
    const hz = ctx.createRadialGradient(W * 0.52, H * 0.88, 20, W * 0.52, H * 0.88, Math.max(W, H) * 0.62);
    hz.addColorStop(0, 'rgba(120,152,190,0.34)');
    hz.addColorStop(0.5, 'rgba(60,82,112,0.12)');
    hz.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = hz;
    ctx.fillRect(0, 0, W, H);
    if (flash > 0.01){
      ctx.fillStyle = 'rgba(150,185,225,' + (flash * 0.16).toFixed(3) + ')';
      ctx.fillRect(0, 0, W, H);
    }

    const baseY = H * 0.78;

    /* 远层剪影：主体很暗，顶沿给一道冷光（像远处楼顶反着天光） */
    for (const b of mbFar){
      ctx.fillStyle = 'rgba(3,6,10,0.97)';
      ctx.fillRect(b.x, baseY - b.h, b.w, b.h);
      ctx.fillStyle = 'rgba(126,166,206,0.16)';
      ctx.fillRect(b.x, baseY - b.h, b.w, 1.5);
    }
    /* 远层窗灯（会呼吸一点点，像有人在家） */
    for (const l of mbLights){
      const a = l.a * (0.75 + 0.25 * Math.sin(mbT * 1.7 + l.ph));
      ctx.fillStyle = l.warm ? 'rgba(255,196,120,' + a.toFixed(3) + ')' : 'rgba(150,205,255,' + a.toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(l.x, l.y, l.r, 0, Math.PI * 2); ctx.fill();
    }
    /* 近层剪影（更深，压住远层） */
    for (const b of mbNear){
      ctx.fillStyle = 'rgba(2,4,7,1)';
      ctx.fillRect(b.x, baseY - b.h, b.w, b.h);
      ctx.fillStyle = 'rgba(96,140,180,0.10)';
      ctx.fillRect(b.x, baseY - b.h, b.w, 1.5);
      /* 楼顶水箱 / 天线 */
      for (const pr of (b.props || [])){
        if (pr.k === 'tank'){ ctx.fillRect(pr.x, baseY - b.h - pr.h, pr.w, pr.h); }
        else { ctx.fillRect(pr.x, baseY - b.h - pr.h, 1.6, pr.h); }
      }
      /* 亮窗：只有几格，会慢慢呼吸 */
      for (const w2 of (b.wins || [])){
        const al = w2.a * (0.72 + 0.28 * Math.sin(mbT * 0.9 + w2.ph));
        ctx.fillStyle = w2.warm ? 'rgba(255,190,120,' + al.toFixed(3) + ')' : 'rgba(150,205,240,' + al.toFixed(3) + ')';
        ctx.fillRect(w2.x, w2.y, 3, 4);
      }
      ctx.fillStyle = 'rgba(2,4,7,1)';
    }
    /* 地面：稍亮一点点，好让楼"站"在地上而不是飘着 */
    const gd = ctx.createLinearGradient(0, baseY, 0, H);
    gd.addColorStop(0, 'rgba(18,26,36,1)');
    gd.addColorStop(1, 'rgba(5,8,12,1)');
    ctx.fillStyle = gd;
    ctx.fillRect(0, baseY, W, H - baseY);

    if (lv >= 2) return;   /* 画质关：只留静态剪影 */

    /* 雨：斜着下，方向跟游戏里的风一致（这里固定一点小斜角） */
    const slope = 0.28;
    const speedK = lv === 0 ? 1 : 0.7;
    const cap = lv === 0 ? mbRain.length : Math.round(mbRain.length * 0.55);
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(178,206,230,0.26)';
    ctx.beginPath();
    for (let i = 0; i < cap; i++){
      const d = mbRain[i];
      d.y += d.sp * speedK * 0.016;
      d.x += d.sp * speedK * 0.016 * slope;
      if (d.y > H + 20){ d.y = -20 - Math.random() * 80; d.x = Math.random() * (W + 200) - 100; }
      if (d.x > W + 60) d.x = -60;
      ctx.moveTo(d.x, d.y);
      ctx.lineTo(d.x - d.len * slope, d.y - d.len);
    }
    ctx.stroke();

    /* 顶部和底部的暗角，让 UI 文字压得住 */
    const vg = ctx.createLinearGradient(0, 0, 0, H);
    vg.addColorStop(0, 'rgba(0,0,0,0.48)');
    vg.addColorStop(0.42, 'rgba(0,0,0,0.10)');
    vg.addColorStop(1, 'rgba(0,0,0,0.42)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);
  }

  window.menuBgTick = menuBgTick;
  window.drawMenuBg = drawMenuBg;
})();
