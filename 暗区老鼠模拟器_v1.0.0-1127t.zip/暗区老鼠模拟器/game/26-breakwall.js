/* ================= 可破坏的墙 =================
   数据里只写一块矩形 + 血量，剩下的全算出来：
   · 裂纹：按"还剩多少血"一层层长出来；形状由墙的种子决定，同一堵墙每次崩得一模一样
   · 碎块：碎掉的瞬间按尺寸切成十几块飞出去，落地前带一点翻转
   · 碎掉之后把这块从 L.walls 里摘掉 —— 碰撞、视线、寻路都会当它不存在，
     所以"碎掉后那块能走"是免费的，不用到处加判断 */
let brkChunks = [];      /* 飞出去的碎块 */
let brkDust = [];        /* 墙上的灰 */
let brkShake = 0;        /* 墙挨打时的一点镜头反应（比打肉轻） */
/* 旧名称继续保留给现有初始化和空投箱代码；权威数值已迁到 data/covers.js。 */
const BRK_HP = BREAKABLE_WALL_DEF.hp;

/* 稳定的伪随机：同一个种子每次给出同一串数，裂纹才不会每帧乱跳 */
function brkRand(seed){
  let s = Math.abs(seed | 0) % 2147483647;
  if (s <= 0) s += 2147483646;
  return function(){ s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
}

function makeCracks(w){
  const R = brkRand(w.seed || 7);
  const list = [];
  for (let i = 0; i < 9; i++){
    const at = 0.88 - i * 0.09;              /* 掉到这条线以下，这道裂纹才露出来 */
    let ang = R() * TAU;
    let x = 0.10 + R() * 0.80, y = 0.10 + R() * 0.80;
    const pts = [[x, y]];
    const seg = 3 + Math.floor(R() * 4);
    for (let k = 0; k < seg; k++){
      ang += (R() - 0.5) * 1.2;
      const step = 0.05 + R() * 0.11;
      x = clamp(x + Math.cos(ang) * step, 0.02, 0.98);
      y = clamp(y + Math.sin(ang) * step, 0.02, 0.98);
      pts.push([x, y]);
    }
    list.push({at: at, pts: pts.map(function(p){ return [w.x + p[0]*w.w, w.y + p[1]*w.h]; }), wdt: 0.9 + R() * 1.6});
  }
  w.cracks = list;
  /* 表面的麻点也一次算好，别每帧再摇随机数。
     裂纹和麻点都存**绝对坐标**：墙被打掉一段之后矩形会缩，
     如果还按 0~1 的比例画，剩下那截上的裂纹会跟着一起被拉伸、位置乱跳。 */
  const R2 = brkRand((w.seed || 7) * 31 + 17);
  const sp = [];
  for (let i = 0; i < 26; i++) sp.push([w.x + R2()*w.w, w.y + R2()*w.h, 1 + R2() * 2.2]);
  w.specks = sp;
}

/* 一堵大墙要被切成几段（第 12 轮：打哪段碎哪段）
   · 只有「够长」的墙才切，小块掩体保持原样（一拳碎一块才是对的）
   · 切几段由长度决定，每段 ~74px，最多 12 段，免得一段只有指甲盖大
   · 血也是按段分：整面墙的总血量不变，只是分散到各段上 */
const BRK_SEG_PX = BREAKABLE_WALL_DEF.segmentPx;  /* 兼容别名：打哪段碎哪段 */
const BRK_SEG_MAX = BREAKABLE_WALL_DEF.maxSegments;
function makeSegs(w){
  if (!w || w.glass || w.segs) return;
  /* 原始总血：裂纹浓度按整面墙算，断掉一截之后那截不该"恢复成新墙" */
  if (w.hp0 === undefined) w.hp0 = w.maxHp;
  const horiz = w.w >= w.h;
  const len = horiz ? w.w : w.h;
  const n = Math.min(BRK_SEG_MAX, Math.floor(len / BRK_SEG_PX));
  if (n < 2){ w.segs = null; return; }
  const segLen = len / n, base = horiz ? w.x : w.y;
  w.segAxis = horiz ? 'x' : 'y';
  /* 记下"这堵墙原来多大"：断成两截之后砌缝还按原来的格子画，
     不然每截都从自己的 1/4 处重新排一遍，看着像贴图在跳 */
  w.gx = w.x; w.gy = w.y; w.gw = w.w; w.gh = w.h;
  w.segs = [];
  for (let i = 0; i < n; i++){
    const a = base + i * segLen;
    w.segs.push({ a: a, b: a + segLen, hp: w.maxHp / n, max: w.maxHp / n, dead: false });
  }
}
/* 命中点落在第几段（沿长边投影；点在墙外就夹到两头） */
function segIndexAt(w, hx, hy){
  if (!w.segs) return -1;
  const v = w.segAxis === 'x' ? hx : hy;
  for (let i = 0; i < w.segs.length; i++){
    if (v < w.segs[i].b) return i;
  }
  return w.segs.length - 1;
}

/* 一块墙挨了一下：掉血、崩渣、冒灰、出声 */
/* 装饰物挨打：桌/椅/瓦罐有血，打空了就散架（撤出墙表 + 留残渣），
   扫把瓶子没有血（hp 0），子弹直接穿过去。 */
function damageDecor(w, dmg, hx, hy, ang){
  if (!w || w.dead || !(w.maxHp > 0)) return;
  w.hp -= dmg;
  w.hits = (w.hits || 0) + 1;
  w.hitT = 0.16;
  const d = w.dec;
  if (d){ d.hitT = DECOR_FLASH_T; d.hp = w.hp; }
  const a0 = (ang == null) ? 0 : ang;
  for (let i = 0; i < 4; i++){
    const a = a0 + Math.PI + fxRand(-1.0, 1.0);
    const sp = fxRand(60, 240);
    brkChunks.push({x: hx, y: hy, vx: Math.cos(a)*sp, vy: Math.sin(a)*sp,
                    s: fxRand(1.2, 2.8), rot: fxRand(0, TAU), vr: fxRand(-10, 10),
                    t: 0, dur: fxRand(0.4, 0.75), big: false});
  }
  brkShake = Math.max(brkShake, 0.06);
  if (!(w.sndT > 0)){ sfxCrack(w.hp < w.maxHp * 0.3); w.sndT = 0.07; }
  if (w.hp <= 0) breakDecor(w, hx, hy);
}

/* 装饰物散了：从墙表里撤掉（不然看不见的桌腿还挡人），留下残渣 */
function breakDecor(w, hx, hy){
  if (!w || w.dead) return;
  w.dead = true;
  const d = w.dec;
  if (d){ d.dead = true; d.hitT = 0; }
  const L = cur();
  if (L && L.walls){
    const i = L.walls.indexOf(w);
    if (i >= 0){ L.walls.splice(i, 1); wallGeomVer++; }
  }
  if (L && L.allWalls) L.allWalls = null;
  try { staticInvalidate(); } catch (e){ if (typeof reportErr === 'function') reportErr('26-breakwall', e); }
  try { navCache = null; } catch (e){ if (typeof reportErr === 'function') reportErr('26-breakwall', e); }
  /* 残渣按材质走：陶/土 → 石，玻璃 → 玻璃碴，金属 → 铁屑，其余按木头。
     花这种小东西（nodecal）留一地碎渣反而脏，直接不留。 */
  if (!(d && d.nodecal)){
    const _kind = d ? d.mat : (w.mat || 'wood');
    const _dk = (_kind === 'clay' || _kind === 'plant') ? 'stone'
              : (_kind === 'glass') ? 'glass'
              : (_kind === 'metal') ? 'metal'
              : (_kind === 'junk') ? 'stone'
              : 'wood';
    pushDecal(w.x, w.y, w.w, w.h, _dk);
  }
  for (let i = 0; i < 6; i++){
    const a = fxRand(0, TAU), sp = fxRand(50, 220);
    brkChunks.push({x: hx || (w.x + w.w * 0.5), y: hy || (w.y + w.h * 0.5),
                    vx: Math.cos(a)*sp, vy: Math.sin(a)*sp,
                    s: fxRand(1.6, 3.6), rot: fxRand(0, TAU), vr: fxRand(-12, 12),
                    t: 0, dur: fxRand(0.5, 0.9), big: false});
  }
  if (typeof sfxCrack === 'function') sfxCrack(true);
}

function damageWall(w, dmg, hx, hy, ang, source){
  if (source && enemyIsFortification(w) && factionAlias(combatFaction(source)) === factionAlias(combatFaction(w))){
    impactWallFx(hx,hy,ang || 0);
    return;
  }
  if(w && w.rocketTurret){damageRocketTurret(w,dmg,hx,hy,ang);return;}
  if(w && w.decor){damageDecor(w,dmg,hx,hy,ang);return;}
  if (!w || !w.brk || w.dead) return;
  staticInvalidate();                    /* 墙面裂纹会变：静态层必须重画 */
  /* 玻璃：没有“越打越裂”过程，一枪就碎，声音也是另一套 */
  if (w.glass){ shatterGlass(w, hx, hy, ang); return; }
  /* 大墙分了几段：这一下只算在它打中的那一段上。
     别的段还是满血 —— 所以打穿中间只会开一个洞，不会整面塌。
     小墙没分段（seg 为 null），仍然是老行为：整块一起掉血。 */
  let seg = null;
  if (w.segs && w.segs.length > 1){
    const si = segIndexAt(w, hx, hy);
    if (si >= 0 && w.segs[si] && !w.segs[si].dead) seg = w.segs[si];
  }
  if (seg){
    seg.hp -= dmg;
    w.hp = 0;
    for (let i = 0; i < w.segs.length; i++) w.hp += Math.max(0, w.segs[i].hp);
  } else {
    w.hp -= dmg;
    /* 只剩最后一段时不再走分段那条路，把血同步给段，免得两边记的数对不上 */
    if (w.segs && w.segs.length === 1) w.segs[0].hp = w.hp;
  }
  w.hitT = 0.14;
  /* m45955：机枪棱堡挨了"视野外"的打要还手 —— 记住**射手的方位**并锁 1.6 秒，
     哪怕看不见人也朝那儿盲打一阵，免得玩家站视野外白刮。
     m46018：不能用"弹着点相对圆心的方向"——玩家斜着擦墙时，弹着点会贴着墙面跑，
     那个方向根本不是射手方向。子弹传进来的 ang 是**飞行方向**，射手在它的反方向。 */
  const laneSentry=w.mobaSide!==undefined && mobaOn();
  const mayRetaliate=!laneSentry || (source && !source.mgSentry && mgSentryHostile(w,source));
  if (w.mgSentry && mayRetaliate && typeof hx === 'number' && typeof hy === 'number'){
    const _cx = w.x + w.w / 2, _cy = w.y + w.h / 2;
    const _aim = (typeof ang === 'number' && isFinite(ang)) ? (ang + Math.PI)
               : Math.atan2(_cy - hy, _cx - hx);   /* 爆炸/载具撞击没有飞行方向时退回法线 */
    w.lockX = hx + Math.cos(_aim) * 300;
    w.lockY = hy + Math.sin(_aim) * 300;
    w.lockT = (typeof MG_SENTRY_DEF === 'object' && MG_SENTRY_DEF && MG_SENTRY_DEF.lockT) || 1.6;
    w.hitAng = _aim;   /* 火花朝子弹飞来的方向喷（m45899 的兜底可以退休了） */
  }
  /* 命中次数：木箱裂纹按"每打一下多一条"往上长（渲染时读 w.hits） */
  w.hits = (w.hits || 0) + 1;
  const ratio = Math.max(0, w.hp) / (w.hp0 || w.maxHp || 1);
  for (let i = 0; i < 5; i++){
    const a = ang + Math.PI + fxRand(-1.0, 1.0);
    const sp = fxRand(70, 300);
    brkChunks.push({x: hx, y: hy, vx: Math.cos(a)*sp, vy: Math.sin(a)*sp,
                    s: fxRand(1.4, 3.4), rot: fxRand(0, TAU), vr: fxRand(-12, 12),
                    t: 0, dur: fxRand(0.45, 0.85), big: false});
  }
  for (let i = 0; i < 3; i++){
    brkDust.push({x: hx + fxRand(-7, 7), y: hy + fxRand(-7, 7),
                  vx: fxRand(-30, 30), vy: fxRand(-30, 30),
                  r: fxRand(4, 10), t: 0, dur: fxRand(0.55, 1.05)});
  }
  brkShake = Math.max(brkShake, 0.10);
  /* 霰弹一枪八颗会同时打在同一块上，声音只出一下，不然像爆豆子 */
  if (!(w.sndT > 0)){ sfxCrack(ratio < 0.3); w.sndT = 0.07; }
  if (seg){
    if (seg.hp <= 0 && !carveSeg(w, w.segs.indexOf(seg), ang)) shatterWall(w, ang);
    return;
  }
  if (w.hp <= 0 && w.loot && !w.opened){ openLootCrate(w, true); return; }   /* 打爆 = 开箱 */
  if (w.hp <= 0) shatterWall(w, ang);
}

/* 一整段被打空：把这一段从矩形里"挖掉"。
   挖中间 → 这堵墙当场断成两截（左边留在原对象上，右边成一堵新墙推进 L.walls）；
   挖两头 → 剩下的部分挪坐标。挖完要局部重刷寻路网格，不然人机会往洞里撞。 */
function carveSeg(w, si, ang){
  const L = cur();
  const seg = w.segs[si];
  if (!seg || seg.dead) return false;
  seg.dead = true;
  seg.hp = 0;
  /* 只有这一段崩：碎块、灰、镜头抖都按这一段的矩形来 */
  const horiz = w.segAxis === 'x';
  sliceBurst(horiz ? seg.a : w.x, horiz ? w.y : seg.a,
             horiz ? (seg.b - seg.a) : w.w, horiz ? w.h : (seg.b - seg.a), ang);
  pushDecal(horiz ? seg.a : w.x, horiz ? w.y : seg.a,
            horiz ? (seg.b - seg.a) : w.w, horiz ? w.h : (seg.b - seg.a), decalKindOf(w));
  const old = { x: w.x, y: w.y, w: w.w, h: w.h };
  /* 还活着的段按"连通"分组：中间断掉就是两组 */
  const runs = [];
  let run = null;
  for (let i = 0; i < w.segs.length; i++){
    const s = w.segs[i];
    if (s.dead){ run = null; continue; }
    if (!run){ run = { segs: [] }; runs.push(run); }
    run.segs.push(s);
  }
  if (!runs.length) return false;        /* 整面都没了，交给 shatterWall 收尾 */
  applyRun(w, runs[0]);
  for (let k = 1; k < runs.length; k++){
    const nw = cloneBrkWall(w);
    applyRun(nw, runs[k]);
    L.walls.push(nw);
  }
  NavQuery.invalidateRegion(L, old);   /* 只重刷这一整块，别整张重建 */
  return true;
}
/* 让一堵墙只保留某几个连续段：坐标、宽高、血都跟着改 */
function applyRun(w, run){
  const first = run.segs[0], last = run.segs[run.segs.length - 1];
  let hp = 0;
  for (let i = 0; i < run.segs.length; i++) hp += Math.max(0, run.segs[i].hp);
  w.segs = run.segs;
  w.hp = hp;
  /* maxHp 保持"整面墙原来的总血"，不改：裂纹浓度按整面对比，
     断掉一截之后剩下的那截才不会又变成"满血新墙" */
  if (w.segAxis === 'x'){ w.x = first.a; w.w = last.b - first.a; }
  else { w.y = first.a; w.h = last.b - first.a; }
  wallGeomVer++;                         /* 射线格索引里的旧包围盒立刻作废 */
  /* 记下哪几条边是"刚被削出来的断口"：画的时候要在这几条边上打锯齿，
     不然断墙就是一摞切得整整齐齐的砖头，一眼就知道是"少了一块"不是"碎了"。 */
  const gx0 = (w.gx !== undefined ? w.gx : w.x), gy0 = (w.gy !== undefined ? w.gy : w.y);
  const gw0 = (w.gw !== undefined ? w.gw : w.w), gh0 = (w.gh !== undefined ? w.gh : w.h);
  if (w.segAxis === 'x') w.cut = { l: first.a > gx0 + 1.5, r: last.b < gx0 + gw0 - 1.5, t: false, b: false };
  else w.cut = { t: first.a > gy0 + 1.5, b: last.b < gy0 + gh0 - 1.5, l: false, r: false };
}
/* 断成两截时，右/下那半截要复制：裂纹和麻点是绝对坐标，直接共用就行（画的时候按矩形裁） */
function cloneBrkWall(w){
  return {
    x: w.x, y: w.y, w: w.w, h: w.h, brk: true, mat: w.mat, cov: w.cov, ch: w.ch,
    maxHp: w.maxHp, hp: w.hp, hp0: w.hp0, seed: (w.seed || 7) * 13 + 5,
    hitT: 0, dead: false, sndT: 0, hits: w.hits || 0,
    loot: !!w.loot, opened: !!w.opened, searchT: 0,
    segAxis: w.segAxis, segs: w.segs.slice(),
    gx: w.gx, gy: w.gy, gw: w.gw, gh: w.gh, cut: w.cut,
    cracks: w.cracks, specks: w.specks
  };
}

/* 断口的锯齿路径：被削掉的那条边不再是直线，而是一排深浅不一的豁口。
   clip 只做减法，所以"啃掉"几口之后露出来的就是地板，看着才像被打碎的。 */
function breakClipPath(w){
  const x0 = w.x, y0 = w.y, x1 = w.x + w.w, y1 = w.y + w.h;
  const T = Math.min(8, Math.max(2.5, Math.min(w.w, w.h) * 0.42));
  const jt = (i, s) => covHash((w.seed || 7) + i * 37 + s, 91);
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  /* 上边（左→右） */
  if (w.cut.t){
    const k = Math.max(3, Math.round(w.w / 13));
    for (let i = 1; i <= k; i++){
      const t = i / k;
      ctx.lineTo(x0 + w.w * t, y0 + ((i % 2) ? T * (0.45 + jt(i, 1) * 0.55) : 0));
    }
  } else ctx.lineTo(x1, y0);
  /* 右边（上→下） */
  if (w.cut.r){
    const k = Math.max(3, Math.round(w.h / 13));
    for (let i = 1; i <= k; i++){
      const t = i / k;
      ctx.lineTo(x1 - ((i % 2) ? T * (0.45 + jt(i, 2) * 0.55) : 0), y0 + w.h * t);
    }
  } else ctx.lineTo(x1, y1);
  /* 下边（右→左） */
  if (w.cut.b){
    const k = Math.max(3, Math.round(w.w / 13));
    for (let i = 1; i <= k; i++){
      const t = i / k;
      ctx.lineTo(x1 - w.w * t, y1 - ((i % 2) ? T * (0.45 + jt(i, 3) * 0.55) : 0));
    }
  } else ctx.lineTo(x0, y1);
  /* 左边（下→上） */
  if (w.cut.l){
    const k = Math.max(3, Math.round(w.h / 13));
    for (let i = 1; i <= k; i++){
      const t = i / k;
      ctx.lineTo(x0 + ((i % 2) ? T * (0.45 + jt(i, 4) * 0.55) : 0), y1 - w.h * t);
    }
  } else ctx.lineTo(x0, y0);
  ctx.closePath();
}
