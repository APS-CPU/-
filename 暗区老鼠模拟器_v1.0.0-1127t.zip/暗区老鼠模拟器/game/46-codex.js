/* ============================== 机制图鉴（H） ==============================
   这里不手写内容：能力、BOSS、敌人、技能卡都是现从数据表里读的，
   所以以后加了新能力 / 新卡，图鉴自动就有了，不会漏。
   ========================================================================= */
const MECH_NOTES = [
  ['烟雾', '扔一团烟，挡住别人看你的视线；自己站在烟里，别人也看不见你。'],
  ['声纹', '敌人走动会在脚下荡开波纹。波纹越大，它越近。'],
  ['脚步声', '你走路会被听见。蹲下慢走声音传得近，但会被看得更早。'],
  ['热成像', '按住空格看热源，能穿烟雾。耗电，用完要等它充回 30%。'],
  ['自动门', '门要刷卡。你等敌人刷卡时跟着溜进去，门关着的时候连视线一起挡住。'],
  ['电闸', '拉闸才能跑。拉的时候整层都听见，会有人过来。'],
  ['重击', '被刀或爆炸打到，眼前会糊几秒，站住不动恢复得快。枪打不会糊。'],
  ['流血', '低血量会持续掉血，地上留血印，10 秒后淡掉。'],
  ['背包', 'Tab 开背包，能看枪、弹药、药。点药可以直接用。'],
  ['升级卡', '割草模式每次升级三选一，带取舍的卡会写清楚代价。'],
];
function codexLines(){
  const out = [];
  out.push({ k: 'h', t: 'BOSS 能力' });
  for (const id in ABILITY_DEF){
    const a = ABILITY_DEF[id];
    out.push({ k: 'i', t: a.label + '：' + a.brief });
  }
  out.push({ k: 'h', t: 'BOSS（谁会什么）' });
  for (const id in BOSS_KIT){
    const k = BOSS_KIT[id];
    const ab = k.abilities.map(a => (ABILITY_DEF[a] ? ABILITY_DEF[a].label : a)).join(' + ');
    const ph = k.phases ? '；残血会变凶' : '';
    out.push({ k: 'i', t: k.label + '（' + k.tag + '）：' + ab + ph });
  }
  if (typeof ENEMY_TYPES !== 'undefined'){
    out.push({ k: 'h', t: '小兵' });
    let n = 0;
    for (const id in ENEMY_TYPES){
      const t = ENEMY_TYPES[id];
      if (!t || !t.label) continue;
      if (n++ > 7) break;
      out.push({ k: 'i', t: t.label + (t.brief ? '：' + t.brief : (t.kind === 'gunner' ? '：会开枪的人形。' : '')) });
    }
  }
  if (typeof UPGRADES !== 'undefined'){
    out.push({ k: 'h', t: '升级卡（割草）' });
    let n = 0;
    for (const u of UPGRADES){
      if (n++ > 9) break;
      out.push({ k: 'i', t: u.name + (u.trade ? '（取舍）' : '') + '：' + (u.desc || '') });
    }
  }
  out.push({ k: 'h', t: '机制' });
  for (const m of MECH_NOTES) out.push({ k: 'i', t: m[0] + '：' + m[1] });
  return out;
}
function toggleCodex(force){
  codexOpen = (force === undefined) ? !codexOpen : !!force;
  if (codexOpen) codexPage = 0;
}
function drawCodex(){
  const lines = codexLines();
  const PER = 13;
  const pages = Math.max(1, Math.ceil(lines.length / PER));
  codexPage = clamp(codexPage, 0, pages - 1);
  ctx.fillStyle = 'rgba(4,8,11,0.90)';
  ctx.fillRect(0, 0, W, H);
  const PW = Math.min(980, W - 120), PX = (W - PW) / 2, PY = 70, PH = H - 170;
  ctx.fillStyle = 'rgba(12,20,26,0.96)';
  ctx.fillRect(PX, PY, PW, PH);
  ctx.strokeStyle = PAL.P48; ctx.lineWidth = 1.5;
  ctx.strokeRect(PX + 0.5, PY + 0.5, PW - 1, PH - 1);
  ctx.fillStyle = PAL.P2;
  ctx.font = 'bold 22px "Microsoft YaHei", sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('机制图鉴', PX + 26, PY + 40);
  ctx.font = '13px "Microsoft YaHei", sans-serif';
  ctx.fillStyle = PAL.P9;
  ctx.fillText('第 ' + (codexPage + 1) + ' / ' + pages + ' 页    ← → 翻页   F1 或 Esc 关闭', PX + 26, PY + 64);

  let y = PY + 96;
  const slice = lines.slice(codexPage * PER, codexPage * PER + PER);
  for (const ln of slice){
    if (ln.k === 'h'){
      y += 6;
      ctx.fillStyle = '#ffcf7a';
      ctx.font = 'bold 15px "Microsoft YaHei", sans-serif';
      ctx.fillText('· ' + ln.t, PX + 26, y);
      y += 22;
      ctx.fillStyle = 'rgba(255,255,255,0.10)';
      ctx.fillRect(PX + 26, y - 14, PW - 52, 1);
    } else {
      ctx.fillStyle = 'rgba(225,235,240,0.92)';
      ctx.font = '13.5px "Microsoft YaHei", sans-serif';
      const maxW = PW - 52;
      let txt = ln.t;
      while (txt.length > 3 && ctx.measureText(txt).width > maxW) txt = txt.slice(0, -2);
      if (txt !== ln.t) txt = txt.slice(0, -1) + '…';
      ctx.fillText(txt, PX + 30, y);
      y += 23;
    }
  }
  ctx.textAlign = 'left';
}


/* ============ 打雷提示（屏幕正上方） ============
   画风照抄 BOSS 关拉完闸那个居中大字「跑」：大字 + 白色描边 + 呼吸辉光，不画底板、不画进度条。
   它是一句"状态宣告"，不是弹窗 —— 有框就显得像 UI，跟游戏里其他东西不是一套。
   从雷响那一刻起一直亮到掩盖结束（thunderMaskT 归零），中途不淡出。 */
function drawThunderBanner(){
  if (state !== 'play' || (dzLvl && dzTier === 'core')) return;
  const k = hearMaskK();
  /* m13205：掩盖结束后还有 2.6 秒的"慢慢放开"，这期间提示继续挂着、跟着淡出，
     免得"字没了但听力还没恢复"这种信息错位。 */
  const inTail = (thunderMaskT <= 0 && thunderTailT > 0);
  if (k >= 1 || (thunderMaskT <= 0 && !inTail)) return;
  const pct = Math.round(k * 100);
  ctx.save();
  ctx.textAlign = 'center';
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  /* 满遮盖期间满亮；回落期跟着听力恢复淡出 */
  const aIn = inTail ? Math.min(1, thunderTailT / THUNDER_TAIL) : 1;
  ctx.globalAlpha = aIn;
  const y1 = (ar ? 122 : 96);
  const fs1 = Math.round(Math.min(52, W * 0.039));
  ctx.font = 'bold ' + fs1 + 'px "Microsoft YaHei",sans-serif';
  /* 不要辉光：雷雨天画面本来就亮，加光晕会晃眼。只在字底下压一圈深色描边保证可读。 */
  ctx.lineWidth = 6;
  ctx.strokeStyle = 'rgba(10,10,12,0.72)';
  ctx.strokeText('雷声盖住了脚步', W/2, y1);
  ctx.fillStyle = '#f4c76a';
  ctx.fillText('雷声盖住了脚步', W/2, y1);
  /* 第二行：小一号，白描边压住雨幕 */
  ctx.font = 'bold ' + Math.round(fs1 * 0.34) + 'px "Microsoft YaHei",sans-serif';
  ctx.lineWidth = 4;
  ctx.strokeStyle = 'rgba(10,10,12,0.7)';
  const t2 = inTail
    ? '雷声散了 · 听觉慢慢恢复 · 传声 ' + pct + '%'
    : '这几秒他们听不见你 · 你也听不见他们 · 传声 ' + pct + '%';
  ctx.strokeText(t2, W/2, y1 + fs1 * 0.62);
  ctx.fillStyle = 'rgba(226,206,168,0.92)';
  ctx.fillText(t2, W/2, y1 + fs1 * 0.62);
  ctx.restore();
}
const _HUD_HEALTH_VIEW={};
function hudHealthView(hp,baseHp,maxHp,result){
  result.ratio=clamp(hp/Math.max(1,maxHp),0,1);
  result.low=!(hp>baseHp*0.4);
  result.label='HP '+Math.ceil(hp);
  return result;
}
const _HUD_ARMOR_VIEW={};
function hudArmorView(armor,ratio,result){
  const definition=armorDef(armor.kind)||ARMOR_DEF.light;
  result.ratio=ratio;
  result.barColor=definition.pal;
  result.labelColor=definition.fg;
  result.label=definition.short + ' ' + Math.ceil(armor.hp) + '/' + armor.maxHp;
  return result;
}
const _HUD_STATUS_VIEW={};
function hudStatusView(status,result){
  result.label=status.label + (status.lv ? (' ' + (status.lv === 2 ? 'II' : 'I')) : '') + ' · ' +
    (status.pct ? Math.round(status.t * 100) + '%' : status.t.toFixed(1) + 's');
  result.progress=clamp(status.t / Math.max(0.001,status.total),0,1);
  result.color=status.col;
  return result;
}
function drawCompanionOrderMarker(map=null){
  const m=companionOrderMarker;if(!m||uiT>m.until||state!=='play')return;
  const x=map?map.ox+m.x*map.k:m.x-cam.x,y=map?map.oy+m.y*map.k:m.y-cam.y;
  ctx.save();ctx.globalAlpha=Math.min(1,(m.until-uiT)*2);ctx.strokeStyle='#77efac';ctx.fillStyle='rgba(65,230,130,.15)';ctx.lineWidth=2;
  ctx.beginPath();ctx.arc(x,y,16+Math.sin((uiT-m.at)*7)*3,0,TAU);ctx.fill();ctx.stroke();
  ctx.beginPath();ctx.moveTo(x,y+5);ctx.lineTo(x,y-17);ctx.lineTo(x+13,y-12);ctx.lineTo(x,y-7);ctx.stroke();
  ctx.font='12px sans-serif';ctx.textAlign='center';ctx.fillStyle='#a3ffd0';ctx.fillText(m.targetId?'集火':'前往并坚守',x,y+35);ctx.restore();
}

function drawCompanionHUD(){
  if(!allies.length||state!=='play'||uiBlocksGameplay())return;
  drawCompanionOrderMarker();
  ctx.save();ctx.font='12px sans-serif';ctx.textAlign='right';ctx.fillStyle='#8ee8cf';
  ctx.fillText('队友 '+allies.length+' | 右键指挥'+(companionMouseMode?'开':'关')+' · '+keyLabel(BINDS.commandMode)+'切换 · '+keyLabel(BINDS.commandModifier)+'＋左键坚守 · F7跟随 | 友伤'+(companionRules.friendlyFire?'开启':'关闭'),W-18,H-55);
  ctx.restore();
}

function drawHUD(){
  if (!player) return;
  if (THEME_LIGHT){
    /* 这一关背景是亮的，HUD 直接写会撞上深色货架，先垫两块半透明纸 */
    ctx.fillStyle = PAL.P93;
    ctx.fillRect(12, 12, 268, 132);
    ctx.fillRect(W-236, 12, 224, 92);
    ctx.strokeStyle = PAL.P89; ctx.lineWidth = 1;
    ctx.strokeRect(12.5, 12.5, 267, 131);
    ctx.strokeRect(W-235.5, 12.5, 223, 91);
  }
  if (cur().boss){ drawHUDBoss(); drawDevBadge(); return; }
  if (CFG.dev){
    ctx.save();
    ctx.textAlign = 'center';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = PAL.P59;
    ctx.fillText(devBadgeText(), W/2, H - 16);
    ctx.restore();
  }
  ctx.save();
  ctx.textAlign = 'left';

  const _stamMode = !!(cur().rules && cur().rules.stamina);
  const showAlert = !_stamMode && !!dzLvl;
  const health=hudHealthView(player.hp,CFG.hp,ar?arenaMaxHp():CFG.hp,_HUD_HEALTH_VIEW);
  ctx.fillStyle = PAL.P13; ctx.fillRect(24,24,236,16);
  ctx.fillStyle = health.low ? PAL.P32 : PAL.P83;
  ctx.fillRect(24, 24, 236*health.ratio, 16);
  ctx.strokeStyle = PAL.P240; ctx.lineWidth = 1;
  ctx.strokeRect(24.5,24.5,235,15);
  ctx.fillStyle = PAL.P57; ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText(health.label, 30, 37);
  /* 流血：血条边一圈红光一直闪 */
  if (stBleedT > 0){
    const pl = 0.42 + 0.40 * Math.sin(uiT * 8.0);
    ctx.save();
    ctx.strokeStyle = 'rgba(226,52,36,' + (0.75 * pl).toFixed(2) + ')';
    ctx.shadowColor = 'rgba(226,52,36,0.85)';
    ctx.shadowBlur = 12 + 8 * pl;
    ctx.lineWidth = 2;
    ctx.strokeRect(22.5, 22.5, 239, 19);
    ctx.restore();
  }
  /* 护甲条：夹在血条和电池之间，不穿就整条不画（用户要求） */
  if (player.armor){
    const armor=hudArmorView(player.armor,armorPct(),_HUD_ARMOR_VIEW);
    ctx.save();
    ctx.fillStyle = 'rgba(18,22,28,0.72)';
    ctx.fillRect(24, 41, 236, 6);
    ctx.fillStyle = armor.barColor;
    ctx.fillRect(24, 41, 236 * armor.ratio, 6);
    ctx.strokeStyle = 'rgba(150,168,190,0.55)';
    ctx.lineWidth = 1;
    ctx.strokeRect(24.5, 41.5, 235, 5);
    /* 护甲刚碎的一瞬间：整条红光闪两下 */
    if (armorBreakT > 0){
      const bk = armorBreakT * (0.6 + 0.4 * Math.sin(uiT * 30));
      ctx.strokeStyle = 'rgba(226,52,36,' + (0.9 * bk).toFixed(2) + ')';
      ctx.shadowColor = 'rgba(226,52,36,0.9)';
      ctx.shadowBlur = 14 * bk;
      ctx.lineWidth = 2;
      ctx.strokeRect(22.5, 39.5, 239, 9);
    }
    ctx.restore();
    ctx.fillStyle = armor.labelColor;
    ctx.font = '11px "Microsoft YaHei",sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(armor.label, showAlert ? 24 : 270, showAlert ? 62 : 47);
  }
  /* 状态栏：数据流驱动 —— 每条状态一个小胶囊（名称 + 等级 + 倒计时 + 进度条） */
  {
    const _sts = statusList();
    const sy = showAlert ? 254 : 21;
    let sx = showAlert ? 24 : 270;
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    for (const st of _sts){
      const status = hudStatusView(st,_HUD_STATUS_VIEW);
      const tw = ctx.measureText(status.label).width;
      const w = tw + 16, h = 18;
      ctx.fillStyle = 'rgba(12,14,18,0.62)';
      roundRect(sx, sy, w, h, 9); ctx.fill();
      ctx.fillStyle = status.color;
      roundRect(sx + 4, sy + 3, 3, h - 6, 1.5); ctx.fill();
      ctx.save();
      ctx.globalAlpha = 0.22; ctx.fillStyle = status.color;
      roundRect(sx + 2, sy, Math.max(4, (w - 4) * status.progress), h, 9); ctx.fill();
      ctx.restore();
      ctx.fillStyle = status.color;
      ctx.fillText(status.label, sx + 10, sy + 13);
      sx += w + 8;
      if (sx > W - 160) break;
    }
  }

  /* 3-4 这类纯逃跑关：同一个位置换成体力条（这关没热成像，不会打架） */
  const _heatV2UI = !!(cur().rules && cur().rules.thermalV2);
  if (showAlert){
  /* 与血条并排。两排文字分别留给当前警觉状态、下次围剿和冷却。 */
  const _al = dzSiege ? dzSiege.alert : 0;
  const _on = !!(dzSiege && dzSiege.on);
  /* m22195：做成一块"状态牌" —— 深色底 + 描边 + 加粗金星 + 粗进度条 + 百分比，
     以前只是两行小字，暗图里根本看不见 */
  const _fillCol = _on ? 'rgba(255,86,64,0.98)'
                  : (_al >= 85 ? 'rgba(255,150,60,0.98)' : (_al >= 60 ? 'rgba(255,196,90,0.96)' : 'rgba(120,190,255,0.92)'));
  const _lv = _on ? ((dzSiege && dzSiege.level) || 1) : 0;
  /* 说明文字与原因（原来这两段在下面被一起替换掉了，补回来） */
  const _at = _on ? ((_lv >= 3 ? '职业兵 · 还有车' : (_lv === 2 ? '全员二级甲' : '零星轻甲'))
                    + ' · 剩余 ' + Math.max(0, Math.ceil(dzSiege.endT - timeAlive)) + ' 秒')
                  : (Math.round(_al) + ' / 100' + (_al >= 85 ? ' · 他们快到了' : (_al >= 60 ? ' · 有人在报你的位置' : '')));
  let _why = ((dzSiege?.round || 0) >= 3) ? '下次 Lv3（封顶）' : ('下次 Lv' + Math.min(3, (dzSiege?.round || 0) + 1));
  if (dzSiege){
    const _gs = (typeof godSilent === 'function') && godSilent();
    if (dzSiege.coolT > 0) _why += ' · 冷却 ' + Math.ceil(dzSiege.coolT) + ' 秒';
    else if (_gs) _why += ' · 静默中';
  }
  const _bx = 274, _by = 12, _bw = 252, _bh = 31;
  const textX = _bx + 8, right = _bx + _bw - 8;
  ctx.save();
  ctx.fillStyle = 'rgba(4,8,14,0.74)';
  ctx.strokeStyle = _on ? 'rgba(255,96,72,0.85)' : 'rgba(120,180,255,0.26)';
  ctx.lineWidth = 1;
  roundRect(_bx, _by, _bw, _bh, 6); ctx.fill(); ctx.stroke();

  const title = _lv > 0 ? '★'.repeat(_lv) : '警觉';
  ctx.textAlign = 'left';
  ctx.font = 'bold 13px "Segoe UI Symbol","Microsoft YaHei",sans-serif';
  ctx.fillStyle = _lv >= 3 ? '#ff5640' : _lv === 2 ? '#ffc85a' : '#a0cdff';
  ctx.fillText(title, textX, _by + 13);
  const detailsX = textX + ctx.measureText(title).width + 9;
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = _on ? '#ff9682' : '#d6e8f8';
  ctx.fillText(_at, detailsX, _by + 13, right - detailsX);

  const barWidth = 60, barX = right - barWidth - 27, barY = _by + 19, barHeight = 8;
  ctx.fillStyle = '#b4cbe0';
  ctx.fillText(_why, textX, barY + 8, barX - textX - 8);
  ctx.fillStyle = 'rgba(255,255,255,0.16)';
  roundRect(barX, barY, barWidth, barHeight, 4); ctx.fill();
  const progress = clamp(_on ? 1 : _al / 100, 0, 1);
  if (progress > 0){
    ctx.fillStyle = _fillCol;
    const fillWidth = barWidth * progress;
    roundRect(barX, barY, fillWidth, barHeight, Math.min(4, fillWidth / 2)); ctx.fill();
  }
  ctx.textAlign = 'right';
  ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#d6e8f8';
  ctx.fillText(Math.round(_al) + '%', right, barY + 8);
  ctx.restore();
  /* 死亡地带的热成像电量独占护甲与烟雾之间的一行。 */
  if (player.heatWorn){
    ctx.font = '11px "Microsoft YaHei",sans-serif'; ctx.textAlign = 'left';
    const _hv2a = (typeof thermalV2 === 'function' && thermalV2()) || !!player.heatV2Batt;
    const _swapping = player.batSwapT > 0;
    const _hs2 = _swapping ? '正在换电池 · ' + player.batSwapT.toFixed(1) + ' 秒' : player.thermal
      ? ('热成像 ' + heatPct(player.battery || 0) + '% · 使用中（空格关）')
      : (player.battery >= (_hv2a ? 1 : 30) ? ('热成像 ' + heatPct(player.battery || 0) + '% · 空格开')
                              : ('热成像 ' + heatPct(player.battery || 0) + '% · 没电了，用电池充'));
    ctx.fillStyle = (_swapping || player.thermal) ? PAL.P217 : 'rgba(180,200,220,0.9)';
    ctx.fillText(_hs2, 30, 76);
  }
  } else if (!_stamMode){
  ctx.fillStyle = PAL.P13; ctx.fillRect(24,50,236,10);
  ctx.fillStyle = player.batLock ? PAL.P86 : PAL.P81;
  ctx.fillRect(24,50,236*(player.battery/heatCapNow()),10);
  ctx.fillStyle = PAL.P156; ctx.fillText('热成像电量', 30, 76);
  {
    const _hd = Math.max(0, DIFF_ORDER.indexOf(diffName));
    let _hs = '';
    if ((player.batSwapT || 0) > 0) _hs = '换电池中 ' + player.batSwapT.toFixed(1) + ' 秒 · 可取消';
    else if (cur().rules && cur().rules.thermal === false) _hs = '这关没有热成像';
    else if (!player.heatWorn) _hs = '没戴 · 捡到后拖到装备栏';
    else if (player.heatCd > 0) _hs = '冷却 ' + Math.ceil(player.heatCd) + ' 秒';
    else if (player.thermal) _hs = '使用中 · 还剩 ' + Math.ceil(player.battery / ((_heatV2UI ? 4 : 13) * (1 + _hd*0.15))) + ' 秒 · 空格关';
    else if (player.battery >= ((typeof thermalV2 === 'function' && thermalV2()) || player.heatV2Batt ? 1 : 30)) _hs = '空格开机（再按一下关）';
    else _hs = ((typeof thermalV2 === 'function' && thermalV2()) || player.heatV2Batt)
      ? ('没电了 · 用热成像电池充（点背包）')
      : ('充电中 ' + heatPct(player.battery) + '%');
    if (_hs){
      ctx.fillStyle = player.thermal ? PAL.P217 : PAL.P156;
      ctx.fillText(_hs, 112, 76);
    }
    /* v2：兜里还有几颗电池，一眼能看到（单独一行，免得跟状态文字挤在一起） */
    if (_heatV2UI){
      const _cn = heatCellLeft();
      ctx.fillStyle = _cn > 0 ? 'rgba(255,186,110,0.98)' : 'rgba(150,150,150,0.8)';
      ctx.fillText(_cn > 0 ? ('电池 ×' + _cn + '（点背包里那格充电）') : '没有电池 · 找箱子搜', 30, 94);
    }
  }
  } else {
    const _sr = clamp(player.stam / (player.stamMax || 100), 0, 1);
    ctx.fillStyle = PAL.P13; ctx.fillRect(24,50,236,10);
    ctx.fillStyle = player.stamLock ? 'rgba(255,120,96,0.95)'
                  : (_sr > 0.5 ? 'rgba(126,206,255,0.95)' : 'rgba(255,196,110,0.95)');
    ctx.fillRect(24,50,236*_sr,10);
    ctx.fillStyle = PAL.P156; ctx.fillText('体力', 30, 76);
    ctx.fillStyle = player.stamLock ? 'rgba(255,120,96,0.98)' : PAL.P156;
    ctx.fillText(player.stamLock
      ? '跑不动了 · 慢走恢复中 ' + Math.round(_sr * 100) + '%'
      : Math.round(player.stam) + '% · 静步慢慢回', 112, 76);
  }

  if (playerInWall){
    ctx.fillStyle = 'rgba(255,138,104,0.98)';
    ctx.fillText('墙里在掉血 · 快出去', 24, 94);
  }
  ctx.fillStyle = PAL.P18; ctx.fillText('烟雾', 24, 112);
  const maxShow = Math.max(CFG.grenades, player.grenades);
  for (let i=0;i<maxShow;i++){
    ctx.beginPath(); ctx.arc(62+i*22, 107, 7, 0, TAU);
    ctx.fillStyle = i < player.grenades ? PAL.P4 : PAL.P14;
    ctx.fill();
  }

  ctx.textAlign = 'left';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  /* 这一行永远是常态脚步提示；打雷时的提示挪到屏幕正上方的大字（drawThunderBanner） */
  ctx.fillStyle = player.crouch ? PAL.P28 : PAL.P54;
  const _obs2 = (typeof spectatorViewOn === 'function' && spectatorViewOn()) || player.god === true || (typeof godOn === 'function' && godOn());
  ctx.fillText(player.crouch ? ('静步中 · 脚步 '+Math.round(maskedHearR(playerHearR()))+' · 被看见 ×'+(_obs2 ? 1 : CROUCH_SEE)) : ('正常 · 脚步 '+Math.round(maskedHearR(playerHearR()))), 24, 136);
  const _fogHud = cur().blind || (typeof fogVisionOn === 'function' && fogVisionOn());
  if (_fogHud){
    ctx.fillStyle = PAL.P159;
    /* 原来这里写死'停电层'：别的 blind 关（BOSS 猎场 / 死亡地带）跟着叫错了。
       面板自己开的"视野外隐身"要给个名分，否则玩家不知道敌人为什么突然不见了。 */
    ctx.fillText((cur().blind ? (cur().name || '黑暗') : '视野外隐身') +
      ' · 视野外的敌人看不见 · 视距 '+Math.round(seeRange(cur()))+' · 视角 '+Math.round(seeFov(cur()))+'°', 24, 158);
  } else if (levelIdx === 0){
    /* 第一关是新手关：把"按静步能减少脚步声"明说一次，别指望自己摸出来 */
    ctx.fillStyle = player.crouch ? PAL.P144 : 'rgba(255,210,120,'+(0.55 + 0.35*Math.abs(Math.sin(uiT*2.2))).toFixed(2)+')';
    ctx.fillText(player.crouch
        ? '静步中 · 你的脚步声传不远了'
        : '新手提示 · 按住 Ctrl / Shift 静步，脚步传播范围缩到 35%（'+Math.round(Math.min(CFG.hearR, PRESETS.hard.hearR) * CROUCH_NOISE)+'）', 24, 158);
  }

  ctx.textAlign = 'right';
  if (ar){
    /* 战斗，爽！！：没有物资、也没有"暴露"这回事 */
    ctx.restore();
    return;
  }
  /* m37154：死亡地带没有"物资 x/y"这回事（总量恒 0），右上角只留状态行 */
  if (!dzLvl){
    ctx.font = 'bold 16px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = player.loot >= lootTotal ? PAL.P1 : PAL.P0;
    ctx.fillText('物资  '+player.loot+' / '+lootTotal, W-28, 42);
  }

  ctx.font = '13px "Microsoft YaHei",sans-serif';
  if (concealed){
    ctx.fillStyle = PAL.P1;
    ctx.fillText('遮蔽中 · '+concealLeft.toFixed(1)+'s', W-28, 70);
  } else {
    ctx.fillStyle = PAL.P56;
    ctx.fillText('暴露中', W-28, 70);
  }
  /* m37154：死亡地带里"人机 N · 伤害 N"没有意义（人数是动态刷的、伤害按枪算），整行不画 */
  if (!dzLvl){
    ctx.fillStyle = PAL.P48;
    {
      const _dm = cur().rules && cur().rules.dmgMode === 'gun';
      ctx.fillText(_dm ? ('人机 ' + enemies.length + ' · 伤害 按枪') : ('人机 ' + CFG.enemies + ' · 伤害 ' + CFG.eDmg), W-28, 92);
    }
  }
  ctx.fillStyle = PAL.P0;
  ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillText('难度 ' + (dzLvl ? DZ_TIER_LABEL[dzTier] : (DIFF_LABEL[diffName] || diffName)), W-28, 114);

  /* 玩家换了阵营才显示，免得正常局多一行噪音 */
  if (typeof playerFactionId === 'function' && playerFactionId() !== 'player'){
    const _pf = playerFactionId();
    const _pd = (typeof FACTION_DEF !== 'undefined') ? FACTION_DEF[_pf] : null;
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = (_pf === 'neutral') ? PAL.P48 : '#f0a24a';
    ctx.fillText('阵营 ' + ((_pd && _pd.label) || _pf) + ' · ' + factionStanceText(_pf), W-28, 136);
  }

  /* 开发模式：场上各势力人数。一眼看出"这两拨到底打不打" */
  if (CFG.dev && state === 'play' && enemies.length){
    let na = 0, nb = 0, nn = 0;
    for (const e of enemies){
      const f = e.faction || 'enemy';
      if (f === 'bandit') nb++; else if (f === 'neutral') nn++; else na++;
    }
    if (nb || nn){
      ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'right';
      ctx.fillStyle = '#8fd6a8';
      const seg = 'B ' + nb;
      ctx.fillText(seg, W - 28, 158);
      const w1 = ctx.measureText(seg).width;
      ctx.fillStyle = '#8bb6d8';
      ctx.fillText('A ' + na + '  ·', W - 28 - w1 - 6, 158);
      if (nn){
        ctx.fillStyle = '#9aa4ae';
        ctx.fillText('中立 ' + nn, W - 28 - w1 - 6 - 74, 158);
      }
      ctx.textAlign = 'right';
    }
  }

  ctx.textAlign = 'left';
  ctx.fillStyle = PAL.P16;
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText(cur().name + '   ·   M 地图', 24, H-20);

  /* 教程关的常驻提示：一直挂在屏幕下方，拿到东西才消失 */
  if (cur().rules && cur().rules.hint && state === 'play' && player.loot === 0 && !tutHordeDone){
    const hint = cur().rules.hint;
    ctx.textAlign = 'center';
    ctx.font = '16px "Microsoft YaHei",sans-serif';
    const hw = ctx.measureText(hint).width;
    ctx.globalAlpha = 0.72 + 0.28*Math.sin(uiT*2.6);
    ctx.fillStyle = THEME_LIGHT ? 'rgba(250,248,242,0.90)' : 'rgba(10,14,18,0.78)';
    ctx.fillRect(W/2 - hw/2 - 14, H-140, hw + 28, 30);
    ctx.fillStyle = PAL.P21;
    ctx.fillText(hint, W/2, H-119);
    ctx.globalAlpha = 1;
  }

  /* m37250：围剿开场横幅（顶部居中，画在雾/遮罩之后才读得清） */
  if (typeof drawDzBounty === 'function') drawDzBounty();

  if (msgT > 0 && msg){
    ctx.globalAlpha = Math.min(1, msgT*1.5);
    ctx.textAlign = 'center';
    ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
    /* 提示字可能压在深色货架上（浅色关卡尤其明显）→ 垫一块底色，
       浅色关卡用纸色、深色关卡用墨色，保证任何背景上都读得清 */
    const mw = ctx.measureText(msg).width;
    ctx.fillStyle = THEME_LIGHT ? 'rgba(250,248,242,0.86)' : 'rgba(10,14,18,0.72)';
    ctx.fillRect(W/2 - mw/2 - 12, H-74-22, mw + 24, 32);
    ctx.fillStyle = PAL.P21;
    ctx.fillText(msg, W/2, H-74);
    ctx.globalAlpha = 1;
  }

  if (player.holdT > 0){
    /* 死亡地带的撤离要读 9 秒、故事关 1.6 秒 —— 进度条必须跟着真实时长走，
       否则读条 1.6 秒就满了，玩家会以为"卡住了没法撤离"（这是实际踩到的 bug）。 */
    const _need = (typeof dzLvl !== 'undefined' && dzLvl) ? 9 : 1.6;
    const p = Math.min(1, player.holdT / _need);
    ctx.fillStyle = PAL.P108; ctx.fillRect(W/2-130, H-110, 260, 14);
    ctx.fillStyle = PAL.P1; ctx.fillRect(W/2-130, H-110, 260*p, 14);
    ctx.textAlign = 'center';
    ctx.fillStyle = PAL.P58; ctx.font = '13px "Microsoft YaHei",sans-serif';
    const _left = Math.max(0, _need - player.holdT);
    ctx.fillText('撤离中… ' + _left.toFixed(1) + ' 秒（站住别动）', W/2, H-120);
  }
  ctx.restore();
}

/* ---------------- 全图 ---------------- */
/* 这关没来过——地图能打开，但上面什么都没有，只有打听到的物资点 */
function drawBlankMap(L){
  ctx.save();
  ctx.fillStyle = PAL.P260; ctx.fillRect(0,0,W,H);

  const bw = Math.min(W - 220, 760), bh = Math.min(H - 240, 460);
  const bx = (W - bw)/2, by = (H - bh)/2 + 10;
  ctx.fillStyle = 'rgba(14,18,24,0.96)';
  ctx.fillRect(bx, by, bw, bh);
  ctx.strokeStyle = 'rgba(150,170,190,0.35)';
  ctx.lineWidth = 2;
  ctx.setLineDash([12, 9]);
  ctx.strokeRect(bx, by, bw, bh);
  ctx.setLineDash([]);

  /* 遗忘的那一块：手写样的涂鸦 */
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(150,170,190,0.10)';
  ctx.font = 'bold 76px "Microsoft YaHei",sans-serif';
  ctx.fillText('？', bx + bw/2, by + bh*0.34);

  ctx.fillStyle = PAL.P53;
  ctx.font = 'bold 24px "Microsoft YaHei",sans-serif';
  ctx.fillText('街区地图', W/2, 92);
  ctx.fillStyle = 'rgba(150,170,190,0.75)';
  ctx.font = '15px "Microsoft YaHei",sans-serif';
  ctx.fillText('这地方我没来过 —— 图上一片空白，只有打听到的物资点', W/2, 122);

  /* 物资点：只给位置，不给路 */
  const pts = [];
  for (const l of loots) if (!l.taken) pts.push(l);
  const mx0 = bx + 70, my0 = by + 50, mw = bw - 140, mh = bh - 100;
  for (const l of pts){
    const px = mx0 + (l.x / L.w) * mw;
    const py = my0 + (l.y / L.h) * mh;
    ctx.fillStyle = 'rgba(255,206,86,0.95)';
    ctx.beginPath(); ctx.arc(px, py, 6.4, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,206,86,0.45)';
    ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(px, py, 11, 0, TAU); ctx.stroke();
  }
  if (!pts.length){
    ctx.fillStyle = 'rgba(150,170,190,0.55)';
    ctx.font = '14px "Microsoft YaHei",sans-serif';
    ctx.fillText('物资都捡完了 —— 往你来的方向撤', W/2, by + bh - 40);
  }

  ctx.fillStyle = 'rgba(150,170,190,0.55)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('只知道物资大致在哪个方位，墙和门都不熟', W/2, by + bh - 22);
  ctx.fillStyle = 'rgba(150,170,190,0.45)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('按 M 或点一下关闭', W/2, H - 40);
  ctx.restore();
}

/* 地图底图缓存：路 / 墙 / 边框是死的，11000² 有 2000+ 面墙，
   每帧逐面 fillRect+strokeRect 就是 10ms。开图时烘一张，之后只贴图；
   门、电闸、物资点、敌人、玩家这些会变的照旧每帧画。 */
let mapBg = null, mapBgLvl = null, mapBgKey = '';
function mapBgMake(L, k, ox, oy){
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const g = c.getContext('2d');
  g.fillStyle = (typeof dzLvl !== 'undefined' && dzLvl) ? PAL.P140 : PAL.P260;
  g.fillRect(0, 0, W, H);
  g.save(); g.translate(ox, oy); g.scale(k, k);
  /* 底色已经整块铺过了，这里不再叠一层（PAL 颜色带 alpha，叠两次会亮出一圈边界） */
  /* 岛图不画外面的方框（用户 m12652：把外面那个正方形撤掉），海自己就是边界 */
  /* 用户 m13137：不画地图外框，边界交给边缘浓雾吃掉 */
  if (L.roads && L.roads.length){
    g.fillStyle = 'rgba(62,70,86,0.95)';
    for (const r of L.roads){ if (r._noDraw) continue; g.fillRect(r.x, r.y, r.w, r.h); }
  }
  /* 蛛网路：地图上也用平滑折线画一遍 */
  if (false && L.roadPaths && L.roadPaths.length){   /* 用户 m13089：地图不画路 */
    g.save();
    g.lineCap = 'round'; g.lineJoin = 'round';
    for (const rp of L.roadPaths){
      const ps = rp.pts || [];
      if (ps.length < 2) continue;
      g.strokeStyle = 'rgba(62,70,86,0.95)';
      g.lineWidth = Math.max(2, rp.w * 0.9);
      g.beginPath();
      g.moveTo(ps[0].x, ps[0].y);
      for (let i = 1; i < ps.length - 1; i++){
        const mx = (ps[i].x + ps[i + 1].x) / 2, my = (ps[i].y + ps[i + 1].y) / 2;
        g.quadraticCurveTo(ps[i].x, ps[i].y, mx, my);
      }
      g.lineTo(ps[ps.length - 1].x, ps[ps.length - 1].y);
      g.stroke();
    }
    g.restore();
  }
  /* 墙：合成一条路径，一次 fill + 一次 stroke（原来每面墙两次调用） */
  g.beginPath();
  for (const w of L.walls){ if (w._dzEdge) continue; g.rect(w.x, w.y, w.w, w.h); }
  g.fillStyle = PAL.P79; g.fill();
  g.strokeStyle = PAL.P127; g.lineWidth = 1.5 / k; g.stroke();
  g.restore();
  return c;
}

function drawMap(){
  /* 版本戳：地图界面右上角，方便用户截图时确认构建（画在 mapView 之后，见下） */
  if (cur().rules && cur().rules.mapBlank){ drawBlankMap(cur()); return; }
  const _tlSave = THEME_LIGHT; THEME_LIGHT = false;   /* 地图是深色板，别套浅色 */
  const L = cur();
  ctx.save();
  /* 死亡地带：底色直接用地图地面色，别让四周露出一圈更深的画布底 */
  ctx.fillStyle = (typeof dzLvl !== 'undefined' && dzLvl) ? '#000000' : PAL.P260;
  ctx.fillRect(0,0,W,H);

  /* 用户 m12734：地图放大 —— 不要让人一眼看到整块矩形边界，
     按"能放下 62% 的地图"来定缩放，再以玩家为中心，四条边自然出画。 */
  const padX = 90, padTop = 80, padBot = 90;
  const fitK = Math.min((W-padX*2)/L.w, (H-padTop-padBot)/L.h);
  const ZOOM = 1;   /* 用户 m13089：整张图完整摆在正中间 */
  const k = fitK * ZOOM;
  /* 中心：地图正中（用户 m13089：完整居中，不跟玩家走） */
  const cwx = L.w / 2, cwy = L.h / 2;
  /* 完整居中：不再夹边、不跟随玩家 */
  const ox = Math.round((W - L.w * k) / 2);
  const oy = Math.round((H - L.h * k) / 2);
  mapView = {ox:ox, oy:oy, k:k};

  const _mbKey = k + '|' + ox + '|' + oy + '|' + W + 'x' + H + '|' + L.walls.length;
  if (!mapBg || mapBgLvl !== L || mapBgKey !== _mbKey){
    mapBg = mapBgMake(L, k, ox, oy);
    mapBgLvl = L; mapBgKey = _mbKey;
  }
  ctx.drawImage(mapBg, 0, 0);
  ctx.save();
  ctx.translate(ox,oy); ctx.scale(k,k);
  /* 自动门：红=关、绿=开，规划路线时一眼看得出哪道还锁着 */
  for (const d of doors){
    const isOpen = d.open > 0.5;
    ctx.fillStyle = isOpen ? 'rgba(70,205,130,0.95)' : 'rgba(230,80,60,0.95)';
    ctx.fillRect(d.x - 3/k, d.y, d.w + 6/k, d.h);
    if (!isOpen){
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      ctx.fillRect(d.x - 3/k, d.y + d.h*0.18, d.w + 6/k, d.h*0.10);
      ctx.fillRect(d.x - 3/k, d.y + d.h*0.72, d.w + 6/k, d.h*0.10);
    }
  }
  if (L.boss){
    for (let i2=0;i2<switches.length;i2++){
      const sw = switches[i2];
      if (!sw.on && i2 !== swDone) continue;
      ctx.fillStyle = sw.on ? PAL.P8 : PAL.P0;
      ctx.beginPath(); ctx.arc(sw.x, sw.y, 7/k, 0, TAU); ctx.fill();
    }
    if (exitOpen){
      const X = L.extract;
      ctx.fillStyle = PAL.P287;
      ctx.fillRect(X.x,X.y,X.w,X.h);
      ctx.strokeStyle = PAL.P309; ctx.lineWidth = 2.5/k;
      ctx.strokeRect(X.x,X.y,X.w,X.h);
    }
    if (bossExposed || (CFG.dev && CFG.xray)){
      for (const h of hunters){
        ctx.fillStyle = bossExposed ? PAL.P35 : PAL.P207;
        ctx.beginPath(); ctx.arc(h.x, h.y, 7/k, 0, TAU); ctx.fill();
        if (CFG.dev && CFG.xray && !bossExposed){
          ctx.strokeStyle = PAL.P206; ctx.lineWidth = 1.5/k;
          ctx.beginPath(); ctx.arc(h.x, h.y, 12/k, 0, TAU); ctx.stroke();
        }
      }
    }
  }
  const E = L.extract, ready = player.loot >= lootTotal;
  ctx.fillStyle = ready ? PAL.P286 : PAL.P68;
  ctx.fillRect(E.x,E.y,E.w,E.h);
  ctx.strokeStyle = ready ? PAL.P308 : PAL.P143;
  ctx.setLineDash([10,7]); ctx.lineWidth = 2.5/k;
  ctx.strokeRect(E.x,E.y,E.w,E.h); ctx.setLineDash([]);

  /* 地面物资默认不在地图上打点：物资是"走过去才看见"的东西，
     全图密密麻麻的黄点只会把黑匣子范围、商人、撤离点这些真正有用的信息盖掉。
     例外：老关卡那种"方块物资"（kind === 'supply'）只有坐标、没有种类，
     玩家没法靠形状判断该不该绕过去，所以给它单独标一个小方块点（m20147）。 */
  for (const l of loots){
    if (l.taken || l.kind !== 'supply') continue;
    const _r = Math.max(4 / k, 4);
    ctx.fillStyle = 'rgba(255,206,90,0.95)';
    ctx.fillRect(l.x - _r, l.y - _r, _r * 2, _r * 2);
    ctx.strokeStyle = 'rgba(120,78,18,0.9)';
    ctx.lineWidth = 1.5 / k;
    ctx.strokeRect(l.x - _r, l.y - _r, _r * 2, _r * 2);
  }
  /* 岛图：地图上也把陆地之外涂成海（不然玩家在地图上看到的是个方块） */
  if (typeof dzDrawSea === 'function' && typeof dzIsland !== 'undefined' && dzIsland && dzLvl === L){
    dzDrawSea(ctx, { x0: -ox / k, y0: -oy / k, w: W / k, h: H / k, thin: true,
                     water: 'rgba(24,50,68,0.98)', deep: 'rgba(44,92,118,0.55)',
                     shore: 'rgba(216,192,142,0.88)' });
  }
  /* 黑匣子：只标"大概这一片"，不标点 —— 大图上直接给坐标就等于跳过探索。
     画成一个虚线大圈（半径 DZ_BOX_HINT_R），玩家进圈之后靠自己找。 */
  if (typeof dzLvl !== 'undefined' && dzLvl === L){
    /* 黑匣子锁在保险箱里，开局 loots 里没有它 —— 圈画在 dzBoxPos（那只箱子）上；
       拿出来之后改成跟着掉落物走（玩家看得见"东西就在这儿"）。 */
    const _bbl = loots.find(l => l.kind === 'blackbox' && !l.taken);
    const _bb = _bbl || ((typeof dzBoxPos !== 'undefined' && dzBoxPos) ? dzBoxPos : null);
    if (_bb && player && player.hasIntel){
      const _r = (typeof dzBoxHintR === 'number' && dzBoxHintR > 0) ? dzBoxHintR : ((typeof DZ_BOX_HINT_R === 'number') ? DZ_BOX_HINT_R : 900);
      ctx.save();
      ctx.strokeStyle = 'rgba(246,196,96,0.55)';
      ctx.lineWidth = 2.6 / k;
      ctx.setLineDash([12 / k, 9 / k]);
      ctx.beginPath(); ctx.arc(_bb.x, _bb.y, _r, 0, TAU); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(246,196,96,0.75)';
      ctx.font = 'bold ' + Math.max(11, 13 / k) + 'px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('黑匣子在附近', _bb.x, _bb.y - _r - 8 / k);
      ctx.restore();
    }
  }
  /* 开地图时游戏是暂停的，traderTick 不跑 —— 这里补一次生成，保证地图上有数据 */
  if (typeof traderSpawn === 'function' && typeof traders !== 'undefined'){ try { traderSpawn(); } catch (e){ if (typeof reportErr === 'function') reportErr('46-codex', e); } }

  /* 长条武器箱：全图 10 个，是"要不要绕这一趟"的决策点，所以标出来。
     画成空心琥珀框（跟实心红点/绿框都不一样），框里一道横线表示箱子里躺着一把枪。 */
  for (const w of L.walls){
    if (w.lootKind !== 'weap' || w.dead) continue;
    ctx.save();
    ctx.strokeStyle = 'rgba(242,176,86,0.95)';
    ctx.lineWidth = 2.2 / k;
    ctx.strokeRect(w.x, w.y, w.w, w.h);
    ctx.beginPath();
    ctx.moveTo(w.x + w.w * 0.22, w.y + w.h * 0.5);
    ctx.lineTo(w.x + w.w * 0.78, w.y + w.h * 0.5);
    ctx.lineWidth = 1.6 / k;
    ctx.stroke();
    ctx.restore();
  }
  for (const e of enemies){
    /* 第三关 / 开了遮挡的测试区：地图也不报位置（开发者透视除外） */
    if ((L.blind || (L.rules && (L.rules.testFog || L.rules.fog)) ||
         (typeof fogVisionOn === 'function' && fogVisionOn())) && !(CFG.dev && CFG.xray)) continue;
    if (e.mode !== 1 && !(CFG.dev && CFG.xray)) continue;
    ctx.fillStyle = e.sees ? PAL.P35 : (e.mode === 1 ? PAL.P90 : PAL.P125);
    ctx.beginPath(); ctx.arc(e.x,e.y,6/k,0,TAU); ctx.fill();
  }
  ctx.fillStyle = PAL.P2;
  ctx.beginPath(); ctx.arc(player.x,player.y,6/k,0,TAU); ctx.fill();
  ctx.strokeStyle = PAL.P3; ctx.lineWidth = 2/k;
  ctx.beginPath(); ctx.arc(player.x,player.y,10/k,0,TAU); ctx.stroke();
  ctx.restore();
  drawCompanionOrderMarker(mapView);

  /* 用户 m13174：地图最外圈那圈"纯黑矩形"要彻底消失 ——
     做法分两步：①地图矩形**之外**一律涂成同一个纯黑；②矩形之内再用黑到透明的渐变带，
     让黑从边缘往里渗。两段在矩形边界处是同一种黑，接缝就不存在了。 */
  if (typeof dzLvl !== 'undefined' && dzLvl && mapView){
    const mw = L.w * mapView.k, mh = L.h * mapView.k;
    const ox2 = mapView.ox, oy2 = mapView.oy;
    const BLACK = '#000000';
    const bw = Math.max(80, mw * 0.16);      /* 左右渗入宽度 */
    const bh = Math.max(80, mh * 0.18);      /* 上下渗入宽度 */
    ctx.save();
    /* ① 矩形之外：四个黑块，跟画布底完全同色 */
    ctx.fillStyle = BLACK;
    ctx.fillRect(0, 0, W, oy2);                                  /* 上 */
    ctx.fillRect(0, oy2 + mh, W, H - (oy2 + mh));                /* 下 */
    ctx.fillRect(0, oy2, ox2, mh);                               /* 左 */
    ctx.fillRect(ox2 + mw, oy2, W - (ox2 + mw), mh);             /* 右 */
    /* ② 矩形之内：四条向内的渐变 */
    const g0 = 'rgba(0,0,0,1)', g1 = 'rgba(0,0,0,0)';
    let gr;
    gr = ctx.createLinearGradient(ox2, 0, ox2 + bw, 0);
    gr.addColorStop(0, g0); gr.addColorStop(1, g1);
    ctx.fillStyle = gr; ctx.fillRect(ox2, oy2, bw, mh);
    gr = ctx.createLinearGradient(ox2 + mw, 0, ox2 + mw - bw, 0);
    gr.addColorStop(0, g0); gr.addColorStop(1, g1);
    ctx.fillStyle = gr; ctx.fillRect(ox2 + mw - bw, oy2, bw, mh);
    gr = ctx.createLinearGradient(0, oy2, 0, oy2 + bh);
    gr.addColorStop(0, g0); gr.addColorStop(1, g1);
    ctx.fillStyle = gr; ctx.fillRect(ox2, oy2, mw, bh);
    gr = ctx.createLinearGradient(0, oy2 + mh, 0, oy2 + mh - bh);
    gr.addColorStop(0, g0); gr.addColorStop(1, g1);
    ctx.fillStyle = gr; ctx.fillRect(ox2, oy2 + mh - bh, mw, bh);
    ctx.restore();
  }

  /* m19042：撤离点常贴着地图边，会被上面那圈"边缘浓雾"吃掉 —— 雾之后重画一遍。
     而且它只有拿到黑匣子后才出现（L.extract 默认是 -9000 占位），所以必须判 x>-1000，
     否则会在屏幕角落画出一个假标记。整段用屏幕坐标画，保证小图上也有固定尺寸、看得清。 */
  if (typeof dzLvl !== 'undefined' && dzLvl && dzLvl === L && mapView && L.extract && L.extract.x > -1000){
    const X = L.extract;
    const _rdy = (typeof ready === 'boolean') ? ready : !!(player && player.loot >= (L.lootTotal || 0));
    const _cx = mapView.ox + (X.x + X.w / 2) * mapView.k;
    const _cy = mapView.oy + (X.y + X.h / 2) * mapView.k;
    const _rad = Math.max(11, Math.max(X.w, X.h) * mapView.k * 0.62);
    ctx.save();
    /* 底色：一块比地图更亮的暗绿/暗蓝，先把雾"擦"掉 */
    ctx.fillStyle = _rdy ? 'rgba(30,86,56,0.92)' : 'rgba(34,52,66,0.92)';
    ctx.beginPath(); ctx.arc(_cx, _cy, _rad + 5, 0, TAU); ctx.fill();
    /* 双环 + 十字：远处一眼可见 */
    ctx.strokeStyle = _rdy ? 'rgba(120,255,175,0.98)' : 'rgba(198,224,240,0.95)';
    ctx.lineWidth = 2.6;
    ctx.beginPath(); ctx.arc(_cx, _cy, _rad, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 0.55;
    ctx.beginPath(); ctx.arc(_cx, _cy, _rad + 5, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.beginPath();
    ctx.moveTo(_cx - _rad * 0.5, _cy); ctx.lineTo(_cx + _rad * 0.5, _cy);
    ctx.moveTo(_cx, _cy - _rad * 0.5); ctx.lineTo(_cx, _cy + _rad * 0.5);
    ctx.lineWidth = 1.8; ctx.stroke();
    /* 标签带深色胶囊底，压在雾上也读得出来 */
    const _tx = Math.max(46, Math.min(W - 46, _cx));
    const _ty = Math.max(24, Math.min(H - 26, _cy - _rad - 14));
    const _txt = _rdy ? '撤离点 · 已开' : '撤离点';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    const _tw = ctx.measureText(_txt).width + 16;
    ctx.fillStyle = 'rgba(6,10,14,0.88)';
    ctx.beginPath();
    if (typeof roundRect === 'function') roundRect(_tx - _tw / 2, _ty - 13, _tw, 20, 6); else ctx.rect(_tx - _tw / 2, _ty - 13, _tw, 20);
    ctx.fill();
    ctx.fillStyle = _rdy ? 'rgba(150,255,190,1)' : 'rgba(214,232,244,1)';
    ctx.textAlign = 'center';
    ctx.fillText(_txt, _tx, _ty);
    ctx.restore();
  }

  ctx.textAlign = 'center';
  ctx.fillStyle = PAL.P53;
  ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
  ctx.fillText(L.name + '   全图  ' + L.w + ' × ' + L.h +
    ((typeof dzLvl !== 'undefined') && dzLvl === L && typeof dzMapMode !== 'undefined' && dzMapMode === 'random' &&
      typeof dzSeedUsed === 'number' && dzSeedUsed ? '   · 种子 ' + dzSeedUsed : ''), W/2, 46);

  ctx.font = '14px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = PAL.P230;
  /* 物资点已经不在图上画了，图例也别留着"● 物资 x/y"，那行会让人以为还有黄点 */
  if (L.boss) ctx.fillText('● 电闸 ' + swDone + ' / 3', W/2-235, H-40);
  ctx.fillStyle = PAL.P139;
  ctx.fillText('■ 撤离点', W/2-92, H-40);
  ctx.fillStyle = PAL.P251;
  ctx.fillText('● 已警觉的人机', W/2+10, H-40);
  if (CFG.dev && CFG.xray){   /* 只有透视打开时才会画没警觉的人，图例跟着出现 */
    ctx.fillStyle = PAL.P126;
    ctx.fillText('● 没发现你的人机', W/2+150, H-40);
  }
  if (doors.length){          /* 有门的关卡才显示，绿开红关 */
    /* 图例文字是居中排的，所以直接给整段上色，别再塞小色块 */
    ctx.fillStyle = 'rgba(70,205,130,0.95)';
    ctx.fillText('门（绿开 · 红关）', W/2+300, H-40);
  }
  /* 抽奖商人：金色「商」标记。注意必须画在"边缘浓雾"之后，否则会被雾吃掉 */
  if (typeof traders !== 'undefined' && traders && traders.length){
    ctx.save();
    ctx.translate(mapView.ox, mapView.oy); ctx.scale(mapView.k, mapView.k);   /* 回到世界坐标再画 */
    for (const t of traders){
      if (t.dead) continue;
      /* 不要用 cullRect：那个是按"当前镜头可视区"裁的，地图上看的是整张图，
         玩家站在角落时会把另外三个角的商人全裁掉（就是这么丢的）。 */
      ctx.save();
      ctx.translate(t.x, t.y);
      const _gl = ctx.createRadialGradient(0, 0, 2 / k, 0, 0, 32 / k);
      _gl.addColorStop(0, t.angry > 0 ? 'rgba(255,120,90,0.40)' : 'rgba(246,206,110,0.42)');
      _gl.addColorStop(1, 'rgba(246,206,110,0)');
      ctx.fillStyle = _gl;
      ctx.beginPath(); ctx.arc(0, 0, 32 / k, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(26,22,10,0.9)';
      ctx.strokeStyle = t.angry > 0 ? 'rgba(255,120,90,0.95)' : 'rgba(246,206,110,0.95)';
      ctx.lineWidth = 2.4 / k;
      ctx.beginPath(); ctx.arc(0, 0, 14 / k, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.fillStyle = t.angry > 0 ? '#ff9a7a' : '#f6ce6e';
      ctx.font = 'bold ' + Math.max(11, 15 / k) + 'px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('商', 0, 0.5 / k);
      ctx.restore();
    }
    ctx.restore();
    ctx.textAlign = 'left';
  }

  /* 保险箱：只在开发者模式下画（普通玩家应该自己摸房间找）。
     画在版本戳之前、且不进 cullRect —— 和商人一样，地图看的是整张图，站角落不能把别的角裁掉。 */
  if (CFG.dev && typeof dzLvl !== 'undefined' && dzLvl === cur()){
    const _safes = (L.walls || []).filter(w => w.lootKind === 'safe' && !w.dead);
    if (_safes.length){
      ctx.save();
      ctx.translate(mapView.ox, mapView.oy); ctx.scale(mapView.k, mapView.k);
      for (const sw of _safes){
        const cx = sw.x + sw.w / 2, cy = sw.y + sw.h / 2;
        ctx.save();
        ctx.translate(cx, cy);
        /* 外圈：青灰，和黑匣子的琥珀、商人的金色都区分开 */
        ctx.fillStyle = 'rgba(12,20,28,0.85)';
        ctx.strokeStyle = sw.blackbox ? 'rgba(246,196,96,0.95)' : 'rgba(150,200,230,0.85)';
        ctx.lineWidth = 2.2 / k;
        ctx.beginPath(); ctx.rect(-9 / k, -9 / k, 18 / k, 18 / k); ctx.fill(); ctx.stroke();
        /* 中心点：锁孔感 */
        ctx.fillStyle = sw.blackbox ? 'rgba(246,196,96,0.95)' : 'rgba(150,200,230,0.90)';
        ctx.beginPath(); ctx.arc(0, 0, 2.6 / k, 0, TAU); ctx.fill();
        ctx.restore();
      }
      ctx.restore();
      ctx.textAlign = 'left';
    }
  }

  /* 版本戳：地图右上角，截图就能确认跑的是哪一版 */
  if (mapView && typeof BUILD_TAG !== 'undefined'){
    ctx.save();
    ctx.textAlign = 'right';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(150,170,190,0.55)';
    ctx.fillText((typeof GAME_VER !== 'undefined' ? GAME_VER : '') + ' · ' + BUILD_TAG, mapView.ox + L.w * mapView.k - 12, mapView.oy + 20);
    ctx.restore();
  }
  /* 图例：不管黑匣子还在不在箱子里，这两条都要能看见 */
  if (typeof dzLvl !== 'undefined' && dzLvl === cur()){
    /* 贴着地图矩形画，不用画布坐标：窗口缩放/横向滚动时画布边缘会被裁掉 */
    const _lgX = (mapView ? mapView.ox : 90) + 16;
    const _lgY = mapView ? (mapView.oy + L.h * mapView.k) - 66 : H - 106;
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(246,206,110,0.95)';
    ctx.fillText('◎ 抽奖商人（四角）', _lgX, _lgY);
    if (player && player.hasIntel){
      ctx.fillStyle = 'rgba(246,196,96,0.98)';
      ctx.fillText('◌ 黑匣子在' + (typeof dzBoxTag === 'string' && dzBoxTag ? dzBoxTag : '附近') + '一带', _lgX, _lgY + 22);
    } else {
      ctx.fillStyle = 'rgba(170,180,195,0.85)';
      ctx.fillText('◌ 黑匣子位置未知 · 找抽奖商人换「情报」', _lgX, _lgY + 22);
    }
    ctx.textAlign = 'center';
  }
  if (cur().walls.some(w => w.lootKind === 'weap')){
    ctx.fillStyle = 'rgba(242,176,86,0.95)';
    ctx.textAlign = 'left';
    const _wgX = (mapView ? mapView.ox : 90) + 16;
    const _wgY = (mapView ? (mapView.oy + L.h * mapView.k) - 66 : H - 106) + 44;
    ctx.fillText('▭ 长条武器箱', _wgX, _wgY);
    ctx.textAlign = 'center';
    if (CFG.dev && (L.walls || []).some(w => w.lootKind === 'safe')){
      ctx.fillStyle = 'rgba(150,200,230,0.92)';
      ctx.textAlign = 'left';
      ctx.fillText('▣ 保险箱（开发者可见）', _wgX, _wgY + 22);
      ctx.textAlign = 'center';
    }
  }
  ctx.fillStyle = PAL.P55;
  ctx.fillText(CFG.dev
      ? '开发者 · 点地图任意位置瞬移过去   ·   按 M 关闭   ·   开着地图时游戏暂停'
      : '按 M 或点一下关闭   ·   开着地图时游戏暂停', W/2, H-14);
  ctx.restore();
  THEME_LIGHT = _tlSave;
}

/* ---------------- 回大厅二次确认 ---------------- */
function drawConfirm(){
  uiButtons = [];
  ctx.save();
  /* 确认框是一层深色遮罩，字必须按深色主题取色；
     浅色关卡里不关掉主题，字会被翻成墨色压在遮罩上，直接看不见 */
  const _cSave = THEME_LIGHT;
  THEME_LIGHT = false;
  ctx.fillStyle = PAL.P188; ctx.fillRect(0,0,W,H);

  /* 割草模式：Esc 就是暂停菜单，顺便把加成一览摊开（这一帧游戏是真停住的） */
  if (ar && state === 'play'){
    drawArenaPause();
    ctx.restore();
    THEME_LIGHT = _cSave;
    return;
  }

  const bw = 420, bh = 196;
  const bx = (W-bw)/2, by = (H-bh)/2;
  ctx.fillStyle = PAL.P119;
  ctx.strokeStyle = PAL.P155;
  ctx.lineWidth = 1.5;
  roundRect(bx, by, bw, bh, 14); ctx.fill(); ctx.stroke();

  ctx.textAlign = 'center';
  ctx.fillStyle = PAL.P202;
  ctx.font = 'bold 24px "Microsoft YaHei",sans-serif';
  ctx.fillText('回大厅？', W/2, by+52);

  ctx.fillStyle = PAL.P182;
  ctx.font = '14px "Microsoft YaHei",sans-serif';
  ctx.fillText('这一局的进度不会保存，物资和烟雾都白扔了。', W/2, by+86);
  ctx.fillStyle = PAL.P149;
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('Esc 取消   ·   Enter 确认', W/2, by+112);

  btn(W/2-176, by+134, 160, 44, '继续躲着', ()=>{ confirmBack = false; logInfo('ui', '取消回大厅，继续本局'); }, {primary:true, dark:true});
  btn(W/2+16, by+134, 160, 44, '回大厅', ()=>{
    confirmBack = false;
    logInfo('ui', '确认回大厅');
    goMenu();
  }, {dark:true});

  ctx.restore();
  THEME_LIGHT = _cSave;
}

/* ---------------- 界面按钮 ---------------- */
function uiHit(mx, my){
  for (const b of uiButtons){
    if (mx >= b.x && mx <= b.x+b.w && my >= b.y && my <= b.y+b.h) return b;
  }
  return null;
}
function btn(x, y, w, h, label, fn, opt){
  const b = { x, y, w, h, label, fn, primary: !!(opt && opt.primary), sub: opt && opt.sub, dim: opt && opt.dim, dark: !!(opt && opt.dark), invisible: !!(opt && opt.invisible), overlay: !!(opt && opt.overlay) };
  uiButtons.push(b); return b;
}
function roundRect(x,y,w,h,r){
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.quadraticCurveTo(x+w,y,x+w,y+r);
  ctx.lineTo(x+w,y+h-r); ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
  ctx.lineTo(x+r,y+h); ctx.quadraticCurveTo(x,y+h,x,y+h-r);
  ctx.lineTo(x,y+r); ctx.quadraticCurveTo(x,y,x+r,y); ctx.closePath();
}
/* 按钮回调一律从这里走：抛异常就弹红条 + 记日志，别让界面看起来"点不动" */
function uiCall(fn){
  try { fn(); }
  catch (e){
    try { logCrash('ui', e); } catch (_){ if (typeof reportErr === 'function') reportErr('46-codex', _); }
    try { showCrash('界面出错：' + (e && e.message ? e.message : e)); } catch (_){ if (typeof reportErr === 'function') reportErr('46-codex', _); }
    try { console.error('[ui]', e); } catch (_){ if (typeof reportErr === 'function') reportErr('46-codex', _); }
  }
}
function flushButtons(){
  const hv = uiHit(mouse.x, mouse.y);
  for (const b of uiButtons){
    if (b.invisible) continue;
    const on = (b === hv);
    const _tlB = THEME_LIGHT;
    if (b.dark) THEME_LIGHT = false;   /* 确认框这类深色遮罩上的按钮 */
    ctx.save();
    /* m33967：dim 的按钮要真的看起来点不动（以前只存标记没画） */
    if (b.dim) ctx.globalAlpha = 0.56;
    if (b.primary){
      ctx.fillStyle = on ? PAL.P136 : PAL.P135;
      ctx.strokeStyle = on ? PAL.P170 : PAL.P137;
    } else {
      ctx.fillStyle = on ? PAL.P305 : PAL.P300;
      ctx.strokeStyle = on ? PAL.P172 : PAL.P134;
    }
    ctx.lineWidth = on ? 2 : 1.4;
    roundRect(b.x, b.y, b.w, b.h, 9); ctx.fill(); ctx.stroke();

    ctx.textAlign = 'center';
    ctx.fillStyle = b.sub
      ? (b.primary ? (on?PAL.P10:PAL.P9) : (on?PAL.P11:PAL.P19))
      : (b.primary ? (on?PAL.P10:PAL.P9) : (on?PAL.P11:PAL.P19));
    ctx.font = 'bold ' + (b.sub ? 22 : 20) + 'px "Microsoft YaHei",sans-serif';
    const cy = b.y + b.h/2 + (b.sub ? -6 : 7);
    ctx.fillText(b.label, b.x+b.w/2, cy);
    if (b.sub){
      ctx.font = '12px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = PAL.P168;
      ctx.fillText(b.sub, b.x+b.w/2, b.y+b.h/2+18);
    }
    ctx.restore();
    THEME_LIGHT = _tlB;
  }
}


/* ============================================================
   战斗，爽！！ · Horde
   ------------------------------------------------------------
   独立入口，独立关卡对象（arenaLvl），不写进 LEVELS —— 正式关卡
   的索引、章节数量、定种子哈希都不受影响。
   升级选项是纯数据：加一项就在 UPGRADES 里加一条。
   ============================================================ */

let ar = null;            /* 这一局的割草状态 */
let arOrbs = [];          /* 地上的经验球 */

const ARENA_MAPS = [
  { key:'open', name:'中庭 · 开阔', hint:'柱子散、视野长', match:'3-2' },
  { key:'maze', name:'旧城 · 迷宫', hint:'巷子窄、转角贴脸', match:'3-3' }
];

/* 升级池：id / 名字 / 说明 / 颜色 / apply(ar) */
const UPGRADES = [
  { id:'dmg', cat:'stack',  name:'伤害强化', tone:'#ff9a6a', desc:'伤害 +18%',
    apply(a){ a.dmgMul *= 1.18; } },
  { id:'crit', cat:'stack', name:'致命一击', tone:'#ffd24a', desc:'暴击率 +8%',
    apply(a){ a.crit += 0.08; } },
  { id:'rof', cat:'stack',  name:'扳机改造', tone:'#9ad0ff', desc:'射速 +14%',
    apply(a){ a.rofMul *= 0.88; } },
  { id:'spd', cat:'stack',  name:'轻装', tone:'#8ef0c8', desc:'移动速度 +9%',
    apply(a){ a.spdMul *= 1.09; } },
  { id:'hp', cat:'stack',   name:'厚皮', tone:'#7ee07e', desc:'最大生命 +16，并回 16',
    apply(a){ a.hpAdd += 16; if (!ARENA_REBUILD) player.hp = Math.min(arenaMaxHp(), player.hp + 16); } },
  { id:'leech', cat:'stack', name:'收割', tone:'#6ee0a8', desc:'每击杀一个回 2 点血',
    apply(a){ a.leech = (a.leech || 0) + 2; } },
  { id:'mag', cat:'stack', name:'弹匣扩容', tone:'#ffb066', desc:'所有枪弹匣 +8，并当场装满',
    /* 只往面板上加数，真正改 g.cap 的是 arenaSyncCaps()。
       以前这里是直接 g.cap += 8，且 ARENA_REBUILD 时整个 return —— 结果封了卡、
       重放时跳过这一张，可枪身上的 cap 早就被加上去了，再也退不回来。 */
    apply(a){ a.magAdd = (a.magAdd || 0) + 8; if (!ARENA_REBUILD) arenaSyncCaps(true); } },
  /* ---- 火箭筒专属金卡（只在手里有火箭筒时才会刷出来，见 cardPoolFor 的 rwOnly） ----
     注意：上面那张「弹匣扩容」对火箭筒无效 —— arenaSyncCaps() 跳过 rocket。
     火箭筒的弹匣和双发只能由这两张动，免得普通卡把「一发一装」整个抹平。 */
  { id:'rwburst', cat:'stack', max:1, rwOnly:true, name:'火箭筒扩容', tone:'#ffd24a',
    desc:'一次扳机连打两发，只耗一发弹药',
    detail:'扣一次扳机出两发火箭，第二发隔 0.12 秒跟上；弹药只算一发。两发都不打折，该炸多远还是多远。',
    apply(a){ a.rwBurst = 1; } },
  { id:'rwcap', cat:'stack', max:3, rwOnly:true, name:'火箭筒弹匣', tone:'#ffd24a',
    desc:'火箭筒弹匣容量 +1（最多叠 3 层）',
    detail:'弹匣 1 → 2 → 3 → 4 发。叠满能把「一发一装」变成「四发连打」，装填本身不因此变快；' +
           '而且它只加"装得下多少"，弹药还是得靠拿卡换。',
    apply(a){ a.rwMagStacks = Math.min(3, (a.rwMagStacks | 0) + 1); if (!ARENA_REBUILD) arenaSyncCaps(false); } },
  { id:'rwammo', cat:'stack', rwOnly:true, name:'火箭弹补给', tone:'#ffd24a',
    desc:'火箭弹 +5 发（最多叠 2 层）',
    detail:'直接往弹药池里塞 5 发 —— 不是弹匣，是「这一局总共还能打几发」的那个数。' +
           '火箭弹平时只靠拿卡一张一发地攒，这张是唯一一次给一沓的。',
    apply(a){ a.rwAmmo = (a.rwAmmo | 0) + 5; } },
  { id:'rwboom', cat:'stack', max:3, rwOnly:true, name:'高爆弹头', tone:'#ff9a4a',
    desc:'火箭爆炸半径 +12%（最多叠 3 层）',
    detail:'弹头装药换得更狠：爆炸圈每层大 12%，连伤害衰减也跟着圈一起放大 —— ' +
           '不是"圈画大了但边上没伤害"，是整圈等比放出去（320 → 359 → 397 → 435）。',
    apply(a){ a.rwBoom = Math.min(3, (a.rwBoom | 0) + 1); } },
  { id:'armor', cat:'stack', name:'防弹插板', tone:'#8ab4ff', desc:'受到的伤害 -12%（最多叠到 60%）',
    apply(a){ a.armor = Math.min(0.60, (a.armor || 0) + 0.12); } },
  { id:'xp', cat:'stack',   name:'老练', tone:'#c8f07a', desc:'获得经验 +30%',
    apply(a){ a.xpMul = (a.xpMul || 1) * 1.30; } },
  { id:'cdmg', cat:'stack', name:'破防', tone:'#ff8a5a', desc:'暴击伤害 +50%',
    apply(a){ a.critDmg = (a.critDmg || 0) + 0.50; } },
  { id:'sg', cat:'stack', name:'专武加强', tone:'#ffb066', desc:'霐弹枪射速 +25%',
    apply(a){ a.sgRof = (a.sgRof || 1) * 0.75; } },
  { id:'pierce', cat:'stack', name:'子弹穿透', tone:'#a8e0ff', desc:'穿透率 +25%（最多 100%）',
    apply(a){ a.pierce = Math.min(4, (a.pierce || 0) + 1); } },
  { id:'noclip', cat:'stack', name:'无视地形', tone:'#c8a8ff', desc:'能钻墙，但墙里会掉血、撑不了几秒',
    apply(a){ a.noclip = 1; } },
  { id:'trade1', cat:'stack', name:'搏命', tone:'#ff6b5e', trade:true, desc:'伤害 +35%，暴击率 -10%',
    apply(a){ a.dmgMul *= 1.35; a.crit = Math.max(0, a.crit - 0.10); } },
  { id:'trade2', cat:'stack', name:'稳压射击', tone:'#ff6b5e', trade:true, desc:'暴击率 +18%，伤害 -20%',
    apply(a){ a.crit += 0.18; a.dmgMul *= 0.80; } },
  { id:'reg', cat:'stack',  name:'自愈', tone:'#7ef0c0', desc:'每秒回复 0.8 点生命',
    apply(a){ a.reg = (a.reg || 0) + 0.8; } },
  { id:'boom', cat:'stack', name:'高爆弹', tone:'#ff7a4a', desc:'命中 18% 概率炸开，波及周围',
    apply(a){ a.boom += 0.18; } },
  { id:'aim', cat:'once',  name:'自动瞄准', tone:'#c58cff', desc:'8 秒自动锁定最近的敌人',
    apply(a){ a.autoT += 8; } },
  { id:'god', cat:'once',  name:'短暂无敌', tone:'#ffe066', desc:'获得 5 秒无敌',
    apply(a){ if (!ARENA_REBUILD) player.grace = Math.max(player.grace, 5); } },
  /* 下面这几张是"看你怎么打"的卡：不加面板，改的是打法本身 */
  { id:'magnet', cat:'stack', name:'磁力', tone:'#7ee8ff', desc:'经验球吸取范围 +130',
    apply(a){ a.pickR = (a.pickR || 0) + 130; } },
  { id:'close', cat:'stack', name:'贴脸', tone:'#ffb08a', desc:'220 距离内伤害 +22%',
    apply(a){ a.closeDmg = (a.closeDmg || 0) + 0.22; } },
  { id:'far', cat:'stack',  name:'远射', tone:'#8ab8ff', desc:'380 距离外伤害 +18%',
    apply(a){ a.farDmg = (a.farDmg || 0) + 0.18; } },
  { id:'rage', cat:'stack', name:'背水一战', tone:'#ff7a8a', desc:'血量低于 40% 时伤害 +30%',
    apply(a){ a.rageDmg = (a.rageDmg || 0) + 0.30; } },
  { id:'pick', cat:'stack', name:'拾荒', tone:'#c8c07a', desc:'Uzi / AR15 上：击杀补 2 发',
    apply(a){ a.ammoKill = (a.ammoKill || 0) + 2; } },
  /* m32458：只对霰弹枪生效的装填提速卡。霰弹是逐发压的，这张一次往里塞 2 发；
     三级封顶就是 6 发一次塞满（弹匣本来就是 6 发）。别的枪拿了一分钱效果没有。 */
  { id:'bulk', cat:'stack', name:'成排压弹', tone:'#ffb066', max:3,
    desc:'霰弹枪一次装 2 发（满级 6 发）',
    detail:'只对霰弹枪生效：枪管里那颗还在一颗一颗往里压，这张让你一次压 2 发，三级就是一次 6 发——一管弹匣一口气装完。换别的枪就当没这张卡。',
    apply(a){ a.shellBulk = Math.min(6, (a.shellBulk || 0) + 2); } },
  { id:'patch', cat:'stack', name:'战地包扎', tone:'#8ef0b8', desc:'每波开始回 12% 生命',
    apply(a){ a.waveHeal = (a.waveHeal || 0) + 0.12; } },
  /* 下面三张是这轮新加的取舍卡：爽点明确，代价也明确 */
  { id:'debt', cat:'stack', name:'血债', tone:'#ff6b5e', trade:true, desc:'伤害 +40%，最大生命 -25%',
    apply(a){
      const before = arenaMaxHp();
      a.dmgMul *= 1.40;
      a.hpMul = (a.hpMul || 1) * 0.75;
      const after = arenaMaxHp();
      /* 血条按同一比例缩，不然拿卡的瞬间等于白回一管血 */
      player.hp = Math.max(1, Math.min(after, Math.round(player.hp * (after / before))));
    } },
  { id:'dump', cat:'stack', name:'倾泻', tone:'#ffb066', trade:true, desc:'射速 ×2，弹药消耗 ×2',
    apply(a){ a.rofMul *= 0.50; a.ammoCost = 2; } },
  { id:'gamble', cat:'stack', name:'亡命徒', tone:'#ffd24a', trade:true, desc:'暴击 +20%，暴击伤害 -30%',
    apply(a){ a.crit += 0.20; a.critDmg = (a.critDmg || 0) - 0.30; } },
  /* ---- 这一批是"改打法"的卡 ---- */
  { id:'burst2', cat:'stack', name:'双发', tone:'#ffd9a0', desc:'一次扣扳机打两发（多耗一发）',
    apply(a){ a.multiShot = Math.min(2, (a.multiShot || 0) + 1); } },
  { id:'ricochet', cat:'stack', name:'跳弹', tone:'#9ad0ff', desc:'子弹打墙 25% 概率反弹一次',
    apply(a){ a.ricochet = Math.min(4, (a.ricochet || 0) + 1); } },
  { id:'reload', cat:'stack', name:'快手', tone:'#8ef0c8', desc:'换弹速度 +10%',
    apply(a){ a.reloadMul = (a.reloadMul || 1) * 0.88; } },
  { id:'draw2', cat:'special', name:'赌徒', tone:'#ffd24a', trade:true, desc:'随机抽两张卡，抽到什么吃什么',
    apply(a){ if (ARENA_REBUILD) return; drawCards(a, 2); } },
  { id:'draw4', cat:'special', name:'豪赌', tone:'#ff6b5e', trade:true, desc:'抽四张卡 · 血量与上限各减半',
    apply(a){
      /* hpMul 要在 return 之前写：它是面板数据，重放时必须还原（不然封一张卡就白赚血上限）；
         扣血和抽牌才是「当场发生一次」的事，重放时不能再来一遍。 */
      a.hpMul = (a.hpMul || 1) * 0.5;
      if (ARENA_REBUILD) return;
      const _cap = arenaMaxHp();
      player.hp = Math.max(1, Math.round(Math.min(player.hp, _cap) * 0.5));
      drawCards(a, 4);
    } },
  /* 洗牌：把已经拿过的卡摊开，挑两张丢掉，再随机补两张新的 */
  /* 老实抽卡，很枯燥吧？—— 拿一张自己的卡当赌注，每两波开一次奖 */
  { id:'honest', cat:'stack', name:'老实抽卡，很枯燥吧？', tone:'#ff5a4a',
    desc:'挑一张卡赌升级 · 输了连牌一起带走',
    detail:'卡等级越高，爆率越高；等级越低跑路越快。每两波公布一次——一无所有，亦或者赢下所有？（可以按 Esc 右边查看卡的等级）',
    apply(a){ if (ARENA_REBUILD) return; erStart(); } },
  { id:'shuffle', cat:'special', name:'洗牌', tone:'#c8a8ff', desc:'摊开已有卡 · 丢掉 2 张 · 再补 2 张',
    detail:'当场把手上所有卡摊在屏幕上，自己挑 2 张扔掉，再从池子里随机补 2 张回来——补的什么在点之前看不到。去掉的卡直接消失，不会退回选中池，所以卡少的时候是重抽救命，卡多了基本是拿两张已知换两张未知。只有 1 层。',
    apply(a){ if (ARENA_REBUILD) return; openShuffle(); } },
  /* 梭哈：把手上所有卡一次全扔了，重抽「原来数量 + 1」张（多给的那张会标出来） */
  { id:'allin', cat:'special', name:'梭哈', tone:'#ff6fb0', trade:true,
    desc:'扔光所有卡 · 重抽 同数量+1 张',
    detail:'手上所有卡一次全部扔掉（不用你一张张点），然后从还能拿的卡里随机补「原来的数量 + 1」张回来，多给的那一张会标「新」。不会抽到豪赌、赌徒、洗牌、梭哈这几张开界面的卡。只有 1 层；手上没有卡的时候这张不会刷出来。',
    apply(a){ if (ARENA_REBUILD) return; openAllin(); } },
  /* 拿命换牌：血只剩 1 点，但接下来 60 秒伤害翻倍、子弹必穿三个人 */
  { id:'deal', cat:'once', name:'孤注一掷', tone:'#ff5566', trade:true, desc:'血量只剩 1，伤害翻倍 60 秒',
    apply(a){
      /* dealT 同样先写：封卡重放时要能还原「60 秒爆发」，但血只剩 1 只该发生一次 */
      a.dealT = (a.dealT || 0) + 60;
      if (ARENA_REBUILD) return;
      player.hp = 1;
    } }
];

/* ---------------- 巢母的封卡机制 ----------------
   它一上场先封你一张牌，之后每隔一段时间再封一张，封得越多你越弱；
   把它打死，所有被封的牌立刻全部解锁。 */
const ARENA_STAT_DEFAULTS = {
  dmgMul:1, crit:0, critDmg:0, rofMul:1, spdMul:1, hpAdd:0, hpMul:1, armor:0,
  leech:0, reg:0, boom:0, xpMul:1, sgRof:1, pierce:0, reloadMul:1, multiShot:0,
  ricochet:0, ammoCost:1, ammoKill:0, pickR:0, closeDmg:0, farDmg:0, rageDmg:0,
  waveHeal:0, noclip:0, dealT:0, autoT:0, magAdd:0,
  rwBurst:0, rwMagStacks:0, rwBoom:0, rwAmmo:0, shellBulk:0
};
let ARENA_REBUILD = false;
/* ---------------- 火箭筒的弹药账（战斗，爽！！）----------------
   这里没有"备弹"这个概念，只有"这一局总共几发"：
     · 上限 = 已经拿到的卡牌张数（ar.picks.length）+【火箭弹补给】给的 rwAmmo，所以开局是 0 发
     · 每拿一张卡 +1 发；洗牌净 0 张不增不减，梭哈 +1 张就 +1 发
     · 一次性卡（自动瞄准 / 短暂无敌 / 孤注一掷）不进 picks，也就不给弹药
     · 已经取走的发数记在 ar.rwSpent 里，池子空了就是真没得打了
   换弹是一发一发从池子里装进膛，不是凭空补满 —— 所以「换弹慢」就是它的真实代价。 */
function arenaRocketMax(){ return ar ? ((ar.picks ? ar.picks.length : 0) + (ar.rwAmmo | 0)) : 0; }
function arenaRocketLeft(){
  if (!ar) return 0;
  return Math.max(0, arenaRocketMax() - (ar.rwSpent | 0));
}
/* 弹匣：出厂 1 发；【火箭筒弹匣】金卡 → 2 发。普通「弹匣扩容」对它无效。 */
function arenaRocketCap(){
  if (!ar) return 1;
  return 1 + Math.min(3, ar.rwMagStacks | 0);
}
/* 弹匣上限 = 枪的出厂 cap（WEAPONS[wid].cap）+ 每层「弹匣扩容」的 8 发。
   为什么要现算：封卡 / 洗牌 / 梭哈都只改 ar.picks，谁也不会回头去把已经加过的 g.cap 减回来。
   以前 g.cap 是「拿卡时加一次，之后只能往上走」，所以巢母把「弹匣扩容」封了，上限还是 54。
   refill=true 时顺手装满（拿卡、空投那种「当场装满」）；否则只把当前弹匣夹到新上限。 */
function arenaSyncCaps(refill){
  if (!ar) return;
  const add = ar.magAdd || 0;
  for (const k in (player.guns || {})){
    const g = player.guns[k];
    if (!g || g.kind === 'throw') continue;
    /* 火箭筒不吃「弹匣扩容」：它的弹匣是"一次装几发"，只有专属金卡能动它。
       也绝不 refill —— 它的每一发都必须从弹药池里取，白送就等于无限炮。 */
    if (g.rocket){ g.cap = arenaRocketCap(); if (g.mag > g.cap) g.mag = g.cap; continue; }
    const def = WEAPONS[g.wid];
    const base = (def && def.cap) || g.cap || 1;
    g.cap = base + add;
    if (refill) g.mag = g.cap;
    else if (g.mag > g.cap) g.mag = g.cap;
  }
}
function arenaRebuildStats(){
  if (!ar) return;
  if (!ar.banIdx) ar.banIdx = [];
  Object.assign(ar, ARENA_STAT_DEFAULTS);
  ARENA_REBUILD = true;
  for (let i = 0; i < ar.picks.length; i++){
    if (ar.banIdx.indexOf(i) >= 0) continue;
    const u = UPGRADES.find(x => x.name === ar.picks[i]);
    if (!u) continue;
    try{ u.apply(ar); }catch (e){ if (typeof reportErr === 'function') reportErr('46-codex', e); }
  }
  ARENA_REBUILD = false;
  /* 面板算完了，把「写在面板上的数」落到枪身上：弹匣上限跟着 magAdd 走，封卡会真的掉下来 */
  arenaSyncCaps(false);
  player.hp = Math.max(1, Math.min(player.hp, arenaMaxHp()));
  /* 老实抽卡：洗牌/换牌等途径塞进来的也要立刻开局，别只认 arenaPick 那一条路 */
  if (typeof erAutoBegin === 'function') erAutoBegin();
}
function spawnerAlive(){
  return !!(ar && enemies.some(e => e.boss && e.bossKind === 'spawner' && !e.dead));
}
/* 同一只巢母最多同时封 2 张：随机封 + 每张 8 秒起步已经够了，再叠就是纯折磨 */
/* 同一只巢母最多同时封 4 张：随机封 + 每张 8 秒起步，到 4 张就停手 */
const SUMM_BAN_MAX = 4;
function spawnerBanNext(){
  if (!ar) return false;
  if (!ar.banIdx) ar.banIdx = [];
  if (ar.banIdx.length >= SUMM_BAN_MAX) return false;   /* 到上限就不再封 */
  const free = [], cnt = {};
  for (let i = 0; i < ar.picks.length; i++){
    if (ar.banIdx.indexOf(i) >= 0) continue;
    if (ar.picks[i] === ER_NAME) continue;          /* 老实抽卡：这张卡锁不了（用户要求） */
    free.push(i);
    const n = ar.picks[i];
    cnt[n] = (cnt[n] || 0) + 1;
  }
  if (!free.length) return false;
  /* 开局那一下封你「最高级」的牌 —— 也就是叠层最多的那张（三张快手 → 先封快手），同票随机；
     之后每次纯随机，不再专门盯着你最狠的那张打 */
  let best = -1;
  if (ar.banFresh){
    let bestN = -1;
    for (const i of free){
      const c = cnt[ar.picks[i]];
      if (c > bestN){ bestN = c; best = i; }
      else if (c === bestN && arenaRandom() < 0.5) best = i;
    }
  } else {
    best = free[Math.floor(arenaRandom() * free.length)];
  }
  ar.banFresh = false;
  ar.banIdx.push(best);
  arenaRebuildStats();
  const nm = ar.picks[best];
  ar.banMsgT = 3.0; ar.banMsg = nm;
  /* 左边飞出一张牌、铁链缠上、拖走 */
  const _u = UPGRADES.find(function(u){ return u.name === nm; });
  ar.banAnim = { t: 0, dur: 4.0, name: nm, tone: (_u && _u.tone) || '#c8a8ff' };
  setMsg('巢母封了你的「' + nm + '」· 打死它才能解锁', 2.6);
  sfxAlarm();
  beep(1180, 0.05, 'square', 0.05, 820);
  beep(210, 0.22, 'sawtooth', 0.05, 90);
  logWarn('arena', '巢母封卡 · ' + nm + ' · 已封 ' + ar.banIdx.length + ' 张');
  return true;
}
function spawnerBanStart(){
  if (!ar) return;
  ar.banIdx = []; ar.banT = 0; ar.banCd = 12.0; ar.banFresh = true;
  ar.banAnim = null;
  spawnerBanNext();
}
function spawnerBanClear(){
  if (!ar) return;
  if (!ar.banIdx || !ar.banIdx.length) return;
  const n = ar.banIdx.length;
  ar.banIdx = []; ar.banAnim = null; ar.banFresh = true;
  arenaRebuildStats();
  setMsg('巢母倒了 · ' + n + ' 张牌全部解锁', 2.6);
  beep(720, 0.14, 'triangle', 0.06, 1080);
  logInfo('arena', '巢母死亡 · 解锁 ' + n + ' 张');
}
function spawnerBanTick(dt){
  /* 洗牌界面是整屏模态的：它开着的时候不锁牌，
     否则锁完可洗的牌不足两张，确认按钮会一直是灰的 */
  if (ar.shuf) return;
  if (!ar) return;
  if (!spawnerAlive()) return;
  ar.banT = (ar.banT || 0) + dt;
  if (ar.banT >= (ar.banCd || 7.0)){
    ar.banT = 0;
    ar.banCd = Math.max(8.0, (ar.banCd || 12.0) - 0.5);
    spawnerBanNext();
  }
}

function arenaMaxHp(){
  const base = Math.round(CFG.hp * 1.5) + (ar ? (ar.hpAdd || 0) : 0);
  return Math.round(base * (ar && ar.hpMul ? ar.hpMul : 1));
}
