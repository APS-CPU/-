/* ---------------- 战斗，爽！！存档：没死就能随时退出，回来接着打当前波 ---------------- */
/* 战斗模式完整快照。正式关卡不进入这个存档空间。 */
const ARENA_SAVE_VERSION = 2;
const ARENA_SLOT_COUNT = 3;
const ARENA_AUTOSAVE_EVERY = 5;
const ARENA_SLOT_PREFIX = 'dsh_arena_slot_v2_';
let arenaActiveSlot = -1;
let arenaSaveError = '';
const ARENA_SAVE_UI_FIELDS = new Set(['freeze','choices','drawShow','shuf','_shufBusy','armIdx','devOpen','banAnim']);
/* _cone 是敌人视野锥的离屏缓存，里面是 canvas / context 对象：
   JSON 存不进去，存了也会变成 {}；读回来 coneBake 会报 g.setTransform is not a function，
   整帧渲染从那里断掉 —— 玩家看到的就是「没有 HUD、没有玩家、只剩墙和声纹圈」，
   也就是 m33679 那个黑屏。纯绘制缓存一律不进存档。 */
const ARENA_SAVE_DERIVED_FIELDS = new Set(['bladeNavGrid','bladeNavPath','bladeNavPoint','wpRef','_cone','_coneSoft']);
function arenaSlotKey(i){ return ARENA_SLOT_PREFIX + i; }
function arenaValidSlot(i){ return Number.isInteger(i) && i >= 0 && i < ARENA_SLOT_COUNT; }
function arenaSaveClone(v){
  return JSON.parse(JSON.stringify(v, (key,value) => {
    if (ARENA_SAVE_DERIVED_FIELDS.has(key)) return undefined;
    if (typeof value === 'number' && !Number.isFinite(value)) throw Error('战斗状态含无效数值');
    return value;
  }));
}
function arenaSaveChecksum(data){
  const text=JSON.stringify(data); let h=2166136261;
  for(let i=0;i<text.length;i++){ h=Math.imul(h^text.charCodeAt(i),16777619); }
  return (h>>>0).toString(16).padStart(8,'0');
}
function companionSave(){
  for(const e of allies)companionSyncGun(e);
  return {version:2,rules:{...companionRules},seq:companionSeq,commandSeq:companionCommandSeq,
    units:allies.map(e=>{const out={...e};for(const k of ['path','goal','bladeNavGrid','bladeNavPath','bladeNavPoint','wpRef','_cone','_coneSoft'])delete out[k];return out;})};
}
function companionValid(s){
  if(s===undefined)return true; // pre-companion save
  return !!s&&[1,2].includes(s.version)&&s.rules&&typeof s.rules.friendlyFire==='boolean'&&Number.isInteger(s.seq)&&Number.isInteger(s.commandSeq)&&
    Array.isArray(s.units)&&s.units.length<=4&&new Set(s.units.map(e=>e.id)).size===s.units.length&&s.units.every(e=>
      e&&typeof e.id==='string'&&e.controller==='companion'&&e.faction==='player'&&ENEMY_TYPES[e.type]&&
      ['x','y','r','hp','maxHp','ammo','fireCd','reloading'].every(k=>Number.isFinite(e[k]))&&e.hp>0&&e.maxHp>0&&
      typeof e.wid==='string'&&!!WEAPONS[e.wid]&&(s.version===1||!!e.pack)&&companionPackValid(e)&&
      e.command&&['follow','hold','move','focus'].includes(e.command.type)&&
      (!['hold','move'].includes(e.command.type)||!!e.command.point)&&
      (!e.command.point||Number.isFinite(e.command.point.x)&&Number.isFinite(e.command.point.y))&&
      (!e.tactical||e.tactical.point&&Number.isFinite(e.tactical.point.x)&&Number.isFinite(e.tactical.point.y)&&Number.isFinite(e.tactical.time)));
}
function companionRestore(s){
  if(!s)return;
  companionConeCache=new WeakMap();companionSightCache=new WeakMap();
  companionVisualCache=new WeakMap();
  allies=s.units;companionRules=s.rules;companionSeq=s.seq;companionCommandSeq=s.commandSeq;
  for(const e of allies)companionPack(e);
  companionTrail=[];companionLastPlayer=null;
}

function arenaCaptureSnapshot(){
  if (!ar || ar.over || !player || !arenaLvl) return null;
  const a={};
  for(const key of Object.keys(ar)) if(!ARENA_SAVE_UI_FIELDS.has(key)) a[key]=ar[key];
  /* performance.now 的绝对时间只存剩余值，离线期间不消耗冷却。 */
  a.rwT = Math.max(0,(ar.rwT||0)-performance.now());
  const equippedGun=Object.keys(player.guns||{}).find(k=>player.guns[k]===player.gun)||null;
  const layers={}; for(const name of ar.picks) layers[name]=(layers[name]||0)+1;
  const data=arenaSaveClone({
    arena:a, player, equippedGun, autoSlot:arenaActiveSlot, maxHp:arenaMaxHp(), armor:ar.armor||0,
    difficulty:{name:diffName,config:CFG},
    build:{layers,banned:(ar.banIdx||[]).slice()},
    rng:arenaGetRandomState(),
    world:{level:arenaLvl,enemies,loots,grenades,smokes,orbs:arOrbs,doors,companions:companionSave()},
    runtime:{timeAlive,uiT,stBleedT,visionBlur,visionBlind,visionCd,blindAlphaK,bleedDripT,stRng,
      hitStopT,slowT,concealed,concealLeft,reinforceT,reinforceN,chargeCd,chargeLockT,
      meleeT,meleeA,playerInWall,cam,stepRipples,enemySteps,lootTotal,
      barkCoolT,barkLastAt,critChance,heatGlitch,weather,thunderWait,
      cinePendingIndex:ar.cinePending?enemies.indexOf(ar.cinePending):-1}
  });
  const _mapName=(arenaLvl&&typeof arenaLvl.name==='string')?arenaLvl.name.replace(' · 割草',''):'';
  const snap={version:ARENA_SAVE_VERSION,meta:{wave:ar.wave,map:_mapName,difficulty:DIFF_LABEL[diffName]||diffName,
    score:ar.score,savedAt:Date.now()},data};
  snap.checksum=arenaSaveChecksum({version:snap.version,meta:snap.meta,data:snap.data});
  if(!arenaValidateSnapshot(snap)) throw Error('当前战斗数据不完整，未写入存档');
  return snap;
}
function arenaValidateSnapshot(s){
  try{
    const obj=v=>v&&typeof v==='object'&&!Array.isArray(v);
    const nums=(o,ks)=>obj(o)&&ks.every(k=>typeof o[k]==='number'&&Number.isFinite(o[k]));
    const uint=v=>Number.isInteger(v)&&v>=0&&v<=4294967295;
    if(!obj(s)||s.version!==ARENA_SAVE_VERSION||!obj(s.meta)||!obj(s.data))return false;
    if(s.checksum!==arenaSaveChecksum({version:s.version,meta:s.meta,data:s.data}))return false;
    if(!nums(s.meta,['wave','score','savedAt'])||typeof s.meta.difficulty!=='string')return false;
    const d=s.data,a=d.arena,p=d.player,w=d.world,r=d.runtime;
    if(!arenaValidSlot(d.autoSlot))return false;
    if(!nums(a,['wave','waveT','burst','spawnLeft','waveSpawned','kills','level','xp','xpNext','time','score','tier','tierBase','dmgMul','rofMul','spdMul','hpAdd','hpMul'])||a.over!==false)return false;
    if(!Array.isArray(a.picks)||!a.picks.every(n=>UPGRADES.some(u=>u.name===n)))return false;
    if(a.wave<0||a.spawnLeft<0||a.waveSpawned<0||a.level<1)return false;
    if(!nums(p,['x','y','r','hp','grace','battery','stunT'])||!obj(p.guns)||!obj(p.meds)||p.hp<=0)return false;
    if(!Object.values(p.guns).every(g=>obj(g)&&typeof g.wid==='string'))return false;
    if(d.equippedGun!==null&&(!Object.hasOwn(p.guns,d.equippedGun)||!obj(p.gun)))return false;
    if(!nums(d,['maxHp','armor'])||d.maxHp<=0||p.hp>d.maxHp+0.001)return false;
    if(!obj(w)||!obj(w.level)||!nums(w.level,['w','h'])||w.level.w<=0||w.level.h<=0||w.level.arena!==true)return false;
    if(!obj(w.level.rules)||!nums(w.level.start,['x','y'])||!Array.isArray(w.level.loot)||!Array.isArray(w.level.slots))return false;
    if(!Array.isArray(w.level.walls)||!w.level.walls.every(q=>nums(q,['x','y','w','h'])))return false;
    for(const k of ['enemies','loots','grenades','smokes','orbs','doors'])if(!Array.isArray(w[k]))return false;
    if(!w.enemies.every(e=>nums(e,['x','y','r','hp','maxHp'])&&typeof e.type==='string'&&!!ENEMY_TYPES[e.type]))return false;
    if(!companionValid(w.companions))return false;
    if(!nums(r,['timeAlive','uiT','stBleedT','visionBlur','visionBlind','visionCd','blindAlphaK','bleedDripT','stRng','hitStopT','slowT','concealLeft','reinforceT','reinforceN','chargeCd','chargeLockT','meleeT','meleeA','lootTotal','barkCoolT','barkLastAt','critChance','heatGlitch','thunderWait','cinePendingIndex']))return false;
    if(!nums(r.cam,['x','y'])||!Array.isArray(r.stepRipples)||!Array.isArray(r.enemySteps))return false;
    if(!obj(d.difficulty)||typeof d.difficulty.name!=='string'||!obj(d.difficulty.config)||!nums(d.difficulty.config,['hp','pSpeed','eSpeed','eDmg']))return false;
    if(!obj(d.build)||!obj(d.build.layers)||!Array.isArray(d.build.banned)||!d.build.banned.every(i=>Number.isInteger(i)&&i>=0&&i<a.picks.length))return false;
    const layers={};for(const n of a.picks)layers[n]=(layers[n]||0)+1;
    if(JSON.stringify(layers)!==JSON.stringify(d.build.layers)||JSON.stringify(a.banIdx||[])!==JSON.stringify(d.build.banned))return false;
    if(!arenaValidRandomState(d.rng))return false;
    return true;
  }catch(e){return false;}
}
function arenaReadSlot(i){
  if(!arenaValidSlot(i))return null;
  try{const s=JSON.parse(localStorage.getItem(arenaSlotKey(i))||'null');return arenaValidateSnapshot(s)?s:null;}catch(e){return null;}
}
function arenaWriteSlot(i){
  if(!arenaValidSlot(i))return {ok:false,error:'无效的存档位'};
  const key=arenaSlotKey(i),temp=key+'.tmp';
  try{
    const snap=arenaCaptureSnapshot();if(!snap)return {ok:false,error:'当前没有可保存的对局'};
    const raw=JSON.stringify(snap);
    localStorage.setItem(temp,raw);
    const check=localStorage.getItem(temp);
    if(check!==raw||!arenaValidateSnapshot(JSON.parse(check)))throw Error('临时存档校验失败');
    /* setItem 单个键整值替换；失败时旧正式档保持不变。 */
    localStorage.setItem(key,raw);
    try{localStorage.removeItem(temp);}catch(e){}
    arenaSaveError='';return {ok:true,bytes:raw.length*2};
  }catch(e){
    try{localStorage.removeItem(temp);}catch(ignore){}
    arenaSaveError='保存失败，原存档已保留：'+(e&&e.message||e);
    return {ok:false,error:arenaSaveError};
  }
}
function arenaDeleteSlot(i){
  if(!arenaValidSlot(i))return {ok:false,error:'无效的存档位'};
  try{localStorage.removeItem(arenaSlotKey(i));return {ok:true};}catch(e){return {ok:false,error:'删除失败：'+e.message};}
}
/* m33679：读档如果中途抛错（旧存档缺字段、关卡对象不完整…），以前会留下
   "地形没画、玩家对象没换" 的半死状态，屏幕上只剩物资和声纹圈。
   现在整段包起来：出错或读出来是空世界，就按存档里的地图名重开一局，
   再也不把坏状态直接摆给玩家看。 */
function arenaRestoreSnapshotSafe(s,slot=arenaActiveSlot){
  let res=null;
  try{ res=arenaRestoreSnapshot(s,slot); }
  catch(e){ logWarn('arena','读档异常，已按原地图重开：'+(e&&e.message||e)); return arenaRestoreFallback(s); }
  if(res&&res.ok&&!arenaWorldLooksSane(s)){
    logWarn('arena','读档后世界不完整（地形/玩家缺失），已按原地图重开');
    return arenaRestoreFallback(s);
  }
  return res;
}
function arenaWorldLooksSane(s){
  if(!player||!arenaLvl||state!=='play')return false;
  if(!Array.isArray(arenaLvl.walls))return false;
  /* 存档里明明有墙，读回来一面都没有 = 世界没重建起来（用户 m33679 那个黑洞画面）。
     存档本身就是空墙（测试用的极简关卡）不算异常。 */
  const wantWalls=(s&&s.data&&s.data.world&&s.data.world.level&&Array.isArray(s.data.world.level.walls))?s.data.world.level.walls.length:0;
  if(wantWalls>0&&arenaLvl.walls.length===0)return false;
  return true;
}
function arenaRestoreFallback(s){
  const nm=(s&&s.meta&&typeof s.meta.map==='string')?s.meta.map:'';
  let idx=0;
  try{ if(typeof ARENA_MAPS!=='undefined'&&Array.isArray(ARENA_MAPS)){ const k=ARENA_MAPS.findIndex(m=>nm&&m.match&&nm.indexOf(m.match)===0); if(k>=0)idx=k; } }catch(e){}
  try{
    if(typeof startArena==='function'){ startArena(idx,true); if(player&&arenaLvl&&state==='play')return {ok:true,recovered:true}; }
  }catch(e){ logWarn('arena','重开也失败：'+(e&&e.message||e)); }
  state='arcade'; uiButtons=[]; arenaSlotUI=null;
  return {ok:false,error:'存档读不进来，已退回娱乐模式'};
}
function arenaRestoreSnapshot(s,slot=arenaActiveSlot){
  if(!arenaValidateSnapshot(s)||!arenaValidSlot(slot))return {ok:false,error:'存档缺失或版本不兼容'};
  const d=arenaSaveClone(s.data),w=d.world,r=d.runtime;
  /* 先清场，再重建世界；玩家最后整体替换，绝不沿用旧敌人/旧子弹。 */
  stopSiren();rainWant=false;rainStop();
  poolClearView(bullets);enemies=[];grenades=[];smokes=[];loots=[];doors=[];hunters=[];boss=null;arOrbs=[];
  customLvl=null;arenaLvl=arenaSaveClone(w.level);CFG=arenaSaveClone(d.difficulty.config);diffName=d.difficulty.name;
  ar=Object.assign(d.arena,{freeze:false,choices:null,drawShow:null,shuf:null,_shufBusy:false,armIdx:-1,devOpen:false,banAnim:null});
  state='play';reset();
  arenaLvl=w.level;enemies=w.enemies;loots=w.loots;grenades=w.grenades;smokes=w.smokes;arOrbs=w.orbs;doors=w.doors;
  companionRestore(w.companions);
  navCache=null;PF_BUF=null;
  for(const e of enemies){
    if(e.path){e.bladeNavPath=e.path;e.bladeNavGrid=navFor(arenaLvl);e.bladeNavPoint=e.path[e.pi]||null;e.wpRef=e.path[e.pi]||null;}
  }
  if(r.cinePendingIndex>=0) ar.cinePending=enemies[r.cinePendingIndex];
  ar.rwT=performance.now()+d.arena.rwT;
  timeAlive=r.timeAlive;uiT=r.uiT;stBleedT=r.stBleedT;visionBlur=r.visionBlur;visionBlind=r.visionBlind;visionCd=r.visionCd;
  blindAlphaK=r.blindAlphaK;bleedDripT=r.bleedDripT;stRng=r.stRng;hitStopT=r.hitStopT;slowT=r.slowT;
  concealed=r.concealed;concealLeft=r.concealLeft;reinforceT=r.reinforceT;reinforceN=r.reinforceN;
  chargeCd=r.chargeCd;chargeLockT=r.chargeLockT;meleeT=r.meleeT;meleeA=r.meleeA;playerInWall=r.playerInWall;
  cam=r.cam;stepRipples=r.stepRipples;enemySteps=r.enemySteps;lootTotal=r.lootTotal;
  barkCoolT=r.barkCoolT;barkLastAt=r.barkLastAt;barkLastOwner=null;critChance=r.critChance;heatGlitch=r.heatGlitch;
  weather=r.weather;thunderWait=r.thunderWait;
  player=d.player;if(d.equippedGun!==null)player.gun=player.guns[d.equippedGun];
  paused=false;mapOpen=false;confirmBack=false;ui.inv.open=false;invGeom=null;codexOpen=false;devSpawnOpen=false;arenaSlotUI=null;
  logOpen=false;if(logEl)logEl.style.display='none';
  for(const k of Object.keys(keys))delete keys[k];mouse.down=false;lastShift=false;uiButtons=[];
  ARENA_REBUILD=false;arenaActiveSlot=d.autoSlot;arenaSetRandomState(d.rng);
  state='play';return {ok:true};
}
function arenaLoadSlot(i){const s=arenaReadSlot(i);return s?arenaRestoreSnapshotSafe(s,i):{ok:false,error:'这个存档位为空或存档不完整'};}
function arenaSaveNow(){return arenaWriteSlot(arenaActiveSlot);}
