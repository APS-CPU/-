/* 抽奖商人 / 转盘音效 ------------------------------------------------
   转盘：启动（机械上劲）→ 旋转中每过一格 tick（按转速变调）→ 停住（咔哒定住）
   结算：中奖上行琶音 / 没中下行两声
   商人：靠近或开面板时招呼一声（双音口哨），站在旁边偶尔低哼
   全部走 duckBus() 总线，耳鸣/爆炸压低其它音效时它也一起被压。
   ------------------------------------------------------------------ */
let _gachaSfxLast = 0;
/* 整体音量：用户说转盘声音太小，统一抬一档（1.0 = 原始） */
const GACHA_GAIN = 2.0;
function _gb(f, d, t, v, to){
  if (typeof beep !== 'function') return;
  try { beep(f, d, t, Math.min(0.9, (v === undefined ? 0.05 : v) * GACHA_GAIN), to); } catch (e) {}
}
/* 计数（测试用：验证「转一圈会格格响」而不必听声音） */
var GACHA_SFX_STAT = { spin:0, tick:0, stop:0, win:0, lose:0, hi:0, hum:0, live:0 };      /* 上一声 tick 的时间戳（节流用） */
let _traderHiT = 0;         /* 招呼冷却 */
let _traderHumT = 0;        /* 低哼冷却 */

function _gsfxNow(){ return (typeof actx !== 'undefined' && actx) ? actx.currentTime : 0; }

/* 一小撮高频噪声：机械「嗒」的那一下 */
function _gsfxClick(vol, freq, dur){
  if (!actx) return;
  try{
    ensureNoise();
    if (!noiseBuf) return;
    const s = actx.createBufferSource();
    s.buffer = noiseBuf;
    const f = actx.createBiquadFilter();
    f.type = 'highpass'; f.frequency.value = freq || 1800;
    const g = actx.createGain();
    g.gain.setValueAtTime(Math.min(0.6, (vol || 0.05) * GACHA_GAIN), actx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + (dur || 0.05));
    s.connect(f); f.connect(g); g.connect(duckBus());
    s.start(); s.stop(actx.currentTime + (dur || 0.05) + 0.02);
  }catch(e){}
}

/* 转盘上劲：低频电机 + 噪声渐强 */
function sfxGachaSpin(){
  GACHA_SFX_STAT.spin++;
  if (actx && typeof beep === 'function') GACHA_SFX_STAT.live++;
  if (!actx) return;
  _gachaSfxLast = 0;
  try{
    _gb(78, 0.42, 'sawtooth', 0.045, 210);
    _gsfxClick(0.045, 900, 0.30);
    _gb(156, 0.10, 'square', 0.022, 300);
  }catch(e){}
}

/* 每过一格：tick。speed 0..1，越慢越闷越小 */
function sfxGachaTick(speed){
  GACHA_SFX_STAT.tick++;
  if (actx && typeof beep === 'function') GACHA_SFX_STAT.live++;
  if (!actx) return;
  const now = _gsfxNow();
  if (now - _gachaSfxLast < 0.028) return;   /* 高速时别轰成机枪 */
  _gachaSfxLast = now;
  const k = Math.max(0, Math.min(1, speed === undefined ? 1 : speed));
  _gsfxClick(0.016 + 0.030 * k, 2600 + 900 * k, 0.035 + 0.02 * k);
  _gb(1500 + 700 * k, 0.028, 'square', 0.010 + 0.012 * k);
}

/* 停住：一声定音 + 低频闷响 */
function sfxGachaStop(){
  GACHA_SFX_STAT.stop++;
  if (actx && typeof beep === 'function') GACHA_SFX_STAT.live++;
  if (!actx) return;
  try{
    _gsfxClick(0.055, 700, 0.09);
    _gb(180, 0.16, 'triangle', 0.05, 96);
    _gb(1180, 0.10, 'sine', 0.030, 900);
  }catch(e){}
}

/* 中奖：三音上行 */
function sfxGachaWin(){
  GACHA_SFX_STAT.win++;
  if (actx && typeof beep === 'function') GACHA_SFX_STAT.live++;
  if (!actx) return;
  try{
    _gb(660, 0.12, 'triangle', 0.055);
    setTimeout(function(){ try{ _gb(880, 0.12, 'triangle', 0.055); }catch(e){} }, 90);
    setTimeout(function(){ try{ _gb(1320, 0.20, 'triangle', 0.05); _gb(990, 0.20, 'sine', 0.03); }catch(e){} }, 180);
  }catch(e){}
}

/* 没中：两声下行，闷 */
function sfxGachaLose(){
  GACHA_SFX_STAT.lose++;
  if (actx && typeof beep === 'function') GACHA_SFX_STAT.live++;
  if (!actx) return;
  try{
    _gb(240, 0.16, 'sawtooth', 0.035, 190);
    setTimeout(function(){ try{ _gb(150, 0.26, 'sawtooth', 0.032, 96); }catch(e){} }, 150);
  }catch(e){}
}

/* 商人招呼：两声短口哨（不同商人略有音高差） */
function sfxTraderHi(pitch){
  GACHA_SFX_STAT.hi++;
  if (actx && typeof beep === 'function') GACHA_SFX_STAT.live++;
  if (!actx) return;
  const k = pitch || 1;
  try{
    _gb(430 * k, 0.09, 'sine', 0.030, 520 * k);
    setTimeout(function(){ try{ _gb(560 * k, 0.10, 'sine', 0.028, 470 * k); }catch(e){} }, 110);
    _traderHiT = _gsfxNow();
  }catch(e){}
}

/* 商人存在感：站在旁边时的低哼（鼻音，不刺耳） */
function sfxTraderHum(){
  GACHA_SFX_STAT.hum++;
  if (actx && typeof beep === 'function') GACHA_SFX_STAT.live++;
  if (!actx) return;
  try{
    _gb(96, 0.55, 'sine', 0.016, 104);
    _gb(144, 0.42, 'triangle', 0.010, 132);
    _traderHumT = _gsfxNow();
  }catch(e){}
}
