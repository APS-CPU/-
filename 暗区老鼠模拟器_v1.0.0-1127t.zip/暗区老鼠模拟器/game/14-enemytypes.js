/* ===== 敌人类型表 =====
   加一种敌人 = 在这张表里加一条，不用改逻辑。
   字段为 null 的，表示"跟设置面板里玩家调的值走"（人机数量/伤害/射速/视野…）。
   kind: gunner = 会开枪的普通敌人；hunter = 会扑人的猎手
   onCatch: damage = 抓到扣血；kill = 抓到直接淘汰 */
/* 敌人类型已移到 data/enemies.js */
function enemyType(o){ return ENEMY_TYPES[(o && o.type) || 'grunt'] || ENEMY_TYPES.grunt; }
/* 刷兵点统一用这个取血量上限：
   兵种自己写了 hp 就用它；没写（现在所有普通兵、职业兵、火箭筒兵、协同精英都不写）
   就跟关卡走 —— L.enemyHp，关卡没配就是 100。
   这样"精英更耐打"只能靠三级甲，不会有人偷偷在数据里加血条；
   以后要整体调难度只改关卡 enemyHp，不用逐个兵种改。 */
function enemyBaseHp(DT, L){
  if (DT && DT.hp !== undefined && DT.hp !== null) return DT.hp;
  return (L && L.enemyHp) || 100;
}
/* 行为特征：预设 + 兵种自己的覆盖项，浅合并后缓存。
   数据在 data/enemies.js 的 BEHAVIOR_DEF；主文件里不再写 e.type === 'xxx' 这种判断。 */
const _BEH_CACHE = Object.create(null);
let behaviorWarnCount = 0;
const _BEH_WARNED = Object.create(null);
/* 防呆：预设漏字段 / 写错类型的后果不是报错，而是 undefined 让比较恒 false（AI 悄悄变傻）。
   这里统一兜底成 normal 的值，并在控制台报一次警。清单与类型见 data/enemies.js 的 BEH_KEYS / BEH_TYPE。 */
function _behTypeOK(v, t){
  if (t === 'num') return typeof v === 'number' && isFinite(v);
  if (t === 'bool') return typeof v === 'boolean';
  if (t === 'str') return typeof v === 'string';
  if (t === 'obj?') return v === null || (typeof v === 'object');
  return true;
}
function behaviorOf(o){
  const T = enemyType(o);
  const raw = T && T.behavior;
  const typeName = (o && o.type) || 'grunt';
  const key = (raw && typeof raw === 'object') ? typeName : (raw || 'normal');
  let b = _BEH_CACHE[key];
  if (b) return b;
  const base = BEHAVIOR_DEF[(typeof raw === 'string' ? raw : 'normal')] || BEHAVIOR_DEF.normal;
  b = Object.assign({}, base, (raw && typeof raw === 'object') ? raw : null);
  if (typeof BEH_KEYS !== 'undefined' && BEH_KEYS.length){
    for (let i = 0; i < BEH_KEYS.length; i++){
      const k = BEH_KEYS[i];
      const t = (typeof BEH_TYPE !== 'undefined' && BEH_TYPE[k]) || '';
      if (_behTypeOK(b[k], t)) continue;
      behaviorWarnCount++;
      if (!_BEH_WARNED[key + '.' + k]){
        _BEH_WARNED[key + '.' + k] = 1;
        if (typeof console !== 'undefined' && console.warn)
          console.warn('[behavior] 预设 "' + key + '" 的字段 ' + k + ' 缺失或类型不对（' + t + '），已回退默认值');
      }
      b[k] = BEHAVIOR_DEF.normal[k];
    }
  }
  _BEH_CACHE[key] = b;
  return b;
}

/* 给一个敌人发枪。正式关卡只取池子第一条（难度和以前一样），
   靶场里才随机 —— 想挨哪种枪就去靶场挨。想改谁拿什么，只改 ENEMY_TYPES 里那一条。 */
/* ---------- \u6d3b\u4eba\u611f\uff08\u53ea\u5728\u300c\u6d4b\u8bd5\u533a \u00b7 \u9776\u573a\u300d\u751f\u6548\uff0c\u6b63\u5f0f\u5173\u5361\u4e00\u70b9\u4e0d\u53d7\u5f71\u54cd\uff09 ----------
   1. \u6123\u795e\uff1a\u7b2c\u4e00\u6b21\u770b\u89c1\u4f60\uff0c\u7ad9\u4f4f 0.3 \u79d2\uff0c\u5934\u9876\u5192\u4e2a\u5c0f\u7ea2\u53f9\u53f7
   2. \u538b\u5236\u6050\u60e7\uff1a\u5b50\u5f39\u64e6\u8eab\u800c\u8fc7 / \u65c1\u8fb9\u540c\u4f34\u521a\u6b7b\uff0c\u6709\u6982\u7387\u4e22\u4e0b\u8def\u7ebf\u53bb\u627e\u6700\u8fd1\u7684\u63a9\u4f53
   3. \u63a2\u5934\uff1a\u8eb2\u597d\u4ee5\u540e\u7f29\u5934\uff08\u6253\u4e0d\u4e2d\uff09\u548c\u63a2\u5934\uff08\u9732\u4e00\u70b9\u3001\u80fd\u5f00\u67aa\uff09\u4ea4\u66ff
   \u5168\u90e8\u8d70\u73b0\u6709\u7684 navSteer / pickHideSpot\uff0c\u4e0d\u78b0\u516c\u5171\u5bfb\u8def\u3002 */
/* 人机「真人感」行为参数现在在 data/ai.js（定义在 data/levels.js 前面导入）。 */
const HUMAN = DataHUMAN;
const HIDE_CFG = DataHIDE;

/* 交战节奏（仅测试区）：想调手感就改这一行
   safe        安全距离：拿枪的步兵靠到这个距离就不往前了
   back        你再逼近多少，它就开始往后退（safe - back 就是退后线）
   backSpd     后退速度（px/秒）
   strafeSpd   找射界时横移的速度（px/秒）
   strafeHold  横移多久换一个方向（秒） */
const ENGAGE = DataENGAGE;   /* 数值在 data/ai.js，改手感别改这里 */
/* 远程挨枪的反应：不许当场找掩体，先朝开枪的方向压上去。
   以前 alertByHit 一律 specSeekCover()，人在 700px 外点射，
   这些兵就一路躲到反方向去，看着就是"怎么打都不还手"。 */
const HITREACT = (typeof DataHITREACT === 'object' && DataHITREACT) ? DataHITREACT : null;
const HIT_FAR_R = (HITREACT && HITREACT.farR) || 360;
const HIT_RUSH_T = (HITREACT && HITREACT.rushT) || 2.6;
const HIT_RUSH_SPD = (HITREACT && HITREACT.spdK) || 1.12;
const HIT_RUSH_KEEP = (HITREACT && HITREACT.keepR) || 0.55;   /* 数值在 data/ai.js，改手感别改这里 */
const HIT_RUSH_STOP = (HITREACT && HITREACT.stopR) || 230;     /* 压到这么近就收手 */
const HIT_RUSH_LEG = (HITREACT && HITREACT.legT !== undefined) ? HITREACT.legT : 1.0;
const HIT_RUSH_PAUSE = (HITREACT && HITREACT.legPause !== undefined) ? HITREACT.legPause : 0.9;
const HIT_RUSH_SWAY = (HITREACT && HITREACT.swayK !== undefined) ? HITREACT.swayK : 0.35;
const HIT_RUSH_BREAK = (HITREACT && HITREACT.breakHits) || 2;
const HIT_RUSH_LOCK  = (HITREACT && HITREACT.lockT) || 3.0;   /* 被打断后的压制锁：这么久内不再往前顶 */
const TAC = (typeof DataTAC !== 'undefined') ? DataTAC : {
  pushCd: 6, pushR: 560, pushAdvR: 360, pushFireGap: 0.22,
  followR: 420, followWait: 1.2, runBoost: 1.34,
  fireK: 1.9, shotgunK: 1.55, suppressMin: 0.55, anyShotR: 460,
  holdR: 320, holdPeek: 0.30, holdBackSpd: 52, holdBackMax: 2.4, holdBackPause: 1.0, lowHpK: 0.45
};
/* 玩家是不是正在换弹：步枪的整匣换弹、霰弹枪的逐发装填、以及打空那一刻
   都算。这一瞬间是对面唯一该主动压出来的窗口。 */
function playerReloading(){
  if (!player || !player.gun || player.hp <= 0) return false;
  const g = player.gun;
  if ((player.reloadT || 0) > 0) return true;
  if (g.shelling) return true;
  return (g.mag | 0) <= 0;
}
/* 你正在不正在看这个点：用来判断「敌人背对着你偷探头」和「你在换弹时压出来」。
   和 enemySees 的视野判定不是一回事 —— 这里只问「你的准星朝不朝这边」。 */
function playerLookingAt(x, y, half){
  if (!player || player.hp <= 0) return false;
  const toward = Math.atan2(y - player.y, x - player.x);
  const aim = (typeof player.aim === 'number') ? player.aim : toward;
  return Math.abs(normAng(toward - aim)) < (half === undefined ? 1.15 : half);
}
/* 残血的只守掩体：不压出、不跟人 */
function enemyLowHp(e){
  return e.hp / e.maxHp < (TAC.lowHpK === undefined ? 0.45 : TAC.lowHpK);
}
/* 找一个「比现在更靠近玩家」的掩体：不是朝玩家直线走，而是挑一个更靠前的点。
   采样十几个候选，只要玩家看不见它（有墙挡）且比现在更近就算。 */
/* AI 查询使用关卡原始房间；绘制的 roomAt(x,y) 使用 rooms，避免同名覆盖。 */
function levelRoomAt(L, x, y){
  if (!L || !L.rooms) return null;
  /* 关卡侧维护了 200px 网格索引（game/12-levels.js 的 roomGridBuild/roomAtFast）：
     大图上"每帧每敌一次"时只扫桶+邻桶；没有索引就走原来的线性遍历，结果一致。 */
  if (typeof roomAtFast === 'function' && (L.roomGrid || L.rooms.length > 8)) return roomAtFast(L, x, y);
  let fallback = null;
  for (const r of L.rooms){
    if (!r || !roomHasPoint(r,x,y)) continue;
    if (!r.fallback) return r;
    fallback = r;
  }
  return fallback;
}
function roomDoorFrame(d){
  const x=d.fx!=null?d.fx:d.x, y=d.fy!=null?d.fy:d.y;
  const w=d.fw||d.w, h=d.fh||d.h;
  return {x,y,w,h,cx:x+w/2,cy:y+h/2,vertical:h>w};
}
/* 兼容诊断入口：只选紧邻目标房间边界的门，不再扫描全图最近门。 */
function roomDoorOf(L,x,y,fromX,fromY){
  const r=levelRoomAt(L,x,y);
  if(!r)return null;
  let best=null,score=Infinity;
  for(const d of doors){
    if(d.isLocked&&!d.unlocked&&!d.broken)continue;
    const f=roomDoorFrame(d), n=(f.vertical?f.w:f.h)/2+4;
    const a=levelRoomAt(L,f.cx+(f.vertical?n:0),f.cy+(f.vertical?0:n));
    const b=levelRoomAt(L,f.cx-(f.vertical?n:0),f.cy-(f.vertical?0:n));
    if(a!==r&&b!==r)continue;
    const cost=dist(fromX==null?x:fromX,fromY==null?y:fromY,f.cx,f.cy);
    if(cost<score){score=cost;best={x:f.cx,y:f.cy};}
  }
  return best;
}
/* 穿门按门框，而不是会旋转的门板。锁门仍是墙；已破坏的门是通道。 */
function roomSearchWalk(L,e,x1,y1,x2,y2,ban,radius=e.roomSearch?.walkRadius ?? (e.r||13)){
  if(!bladeWalkLine(L,radius,x1,y1,x2,y2,true,undefined,true))return false;
  for(const d of doors){
    if((d.isLocked&&!d.unlocked&&!d.broken)||d===ban){
      const f=roomDoorFrame(d), r=radius;
      if(segHitsRect(x1,y1,x2,y2,{x:f.x-r,y:f.y-r,w:f.w+2*r,h:f.h+2*r}))return false;
    }
  }
  return true;
}
function roomSearchDoorWaypoints(door, exitSide, radius){
  const f=roomDoorFrame(door), offset=(f.vertical?f.w:f.h)/2+radius+10;
  const dx=f.vertical?exitSide*offset:0, dy=f.vertical?0:exitSide*offset;
  return [
    {x:f.cx-dx,y:f.cy-dy,phase:'approach',door,exitSide},
    {x:f.cx+dx,y:f.cy+dy,phase:'cross',door,exitSide}
  ];
}
function roomSearchReachedWaypoint(L,e,s){
  const p=s.points[s.index];
  const d=dist(e.x,e.y,p.x,p.y);
  const next=s.points[s.index+1];
  // 窄缝的下一段可能要求精确对齐，先走到当前点再转弯。
  if(d<.5 && (!s.tightLayout || !next || d<.001 ||
      roomSearchWalk(L,e,e.x,e.y,next.x,next.y,s.ban)))return true;
  // 同伴会把人从门前中心点推开，能直达穿门点时就继续走。
  return s.stall>=.15 && p.phase==='approach' && next?.phase==='cross' && p.door===next.door &&
    d<=(e.r||13) && roomSearchWalk(L,e,e.x,e.y,next.x,next.y,s.ban);
}
/* 尚在门外，原来的斜线路点贴住门框时，先对准同一扇门再穿过。 */
function roomSearchRealignDoor(L,e,s,p){
  if(p.phase!=='cross' || !p.door || !p.exitSide || p.door===s.ban)return false;
  const f=roomDoorFrame(p.door);
  if((f.vertical?e.x-f.cx:e.y-f.cy)*p.exitSide>=0)return false;
  const [approach,cross]=roomSearchDoorWaypoints(p.door,p.exitSide,s.walkRadius ?? (e.r||13));
  if(dist(cross.x,cross.y,p.x,p.y)<.5 ||
     !roomSearchWalk(L,e,e.x,e.y,approach.x,approach.y,s.ban) ||
     !roomSearchWalk(L,e,approach.x,approach.y,cross.x,cross.y,s.ban) ||
     !roomSearchWalk(L,e,cross.x,cross.y,p.x,p.y,s.ban))return false;
  s.points.splice(s.index,1,approach,cross,{x:p.x,y:p.y,phase:'search'});
  s.best=Infinity;s.stall=0;
  return true;
}
/* 室内搜索按 0.4 秒重算，但仍复用门面的结构化参数，避免为接口迁移新增短命对象。 */
const _ROOM_SEARCH_PATH_START={x:0,y:0}, _ROOM_SEARCH_PATH_GOAL={x:0,y:0};
const _ROOM_SEARCH_PATH_OPTIONS={walkClear:null,navOverride:null};
let roomPathUi=-1,roomPathTime=-1,roomPathUsed=false;
const roomClearanceGrids=new WeakMap(), roomFineGrids=new WeakMap();
const ROOM_LOCAL_RANGE=200;
function roomUsesFineClearance(layout){
  return layout?.template==='office'||layout?.template==='grand_hall';
}
function roomSearchLayout(L,here,there){
  const room=[here,there].find(r=>r?.template==='two_room'||roomUsesFineClearance(r)) ||
    [there,here].find(r=>r?.template==='big_house');
  return room && (room.fallback ? room : L.rooms.find(r=>r.fallback&&r.building===room.building));
}
function grandHallSqueezePoint(L,e,room,x,y){
  if(room?.template!=='grand_hall')return false;
  const r=roomSearchRadius(e,room);
  return bladeWalkLine(L,r,x,y,x,y,false,undefined,true)&&
    !bladeWalkLine(L,Math.max(e.r||13,r+2),x,y,x,y,false,undefined,true);
}
function roomSearchRadius(e,layout){
  if(!layout || layout.template==='big_house')return e.r||13;
  // 办公室会议桌和隔断间最窄只剩 19px。搜查走位侧身过缝，保留原始身体/命中半径。
  return Math.min(e.r||13,layout.template==='office' ? 9 : player.r||11);
}
function roomFineGrid(L,layout,radius,blocked,routeKey){
  const cached=roomFineGrids.get(layout);
  if(cached?.ver===navVer&&cached.walls===wallGeomVer&&cached.grid.routeKey===routeKey)return cached.grid;
  // 10px 网格可能漏掉门垛和家具之间的窄缝。按圆形身体补一张局部 2px 网格，
  // 只在粗网格无法抵达目标时使用。靠近障碍的细格连边仍按实际碰撞复核。
  const cell=2,pad=ROOM_LOCAL_RANGE+24;
  const ox=layout.x-pad-1,oy=layout.y-pad-1;
  const cw=Math.ceil((layout.w+2*pad+2)/cell),ch=Math.ceil((layout.h+2*pad+2)/cell);
  const b=new Uint8Array(cw*ch),preciseEdges=new Uint8Array(b.length);
  const r=radius-.0001,edge=r+cell*Math.SQRT2;
  const r2=r*r,edge2=edge*edge;
  const obstacles=wallBoxCandidates(L,ox-edge,oy-edge,ox+cw*cell+edge,oy+ch*cell+edge);
  for(const wall of [...obstacles,...blocked.map(roomDoorFrame)]){
    if(wall.dead)continue;
    const left=Math.max(0,Math.floor((wall.x-edge-ox)/cell)),
          right=Math.min(cw-1,Math.floor((wall.x+wall.w+edge-ox)/cell));
    const top=Math.max(0,Math.floor((wall.y-edge-oy)/cell)),
          bottom=Math.min(ch-1,Math.floor((wall.y+wall.h+edge-oy)/cell));
    for(let y=top;y<=bottom;y++){
      const wy=oy+(y+.5)*cell,dy=wy-clamp(wy,wall.y,wall.y+wall.h);
      for(let x=left;x<=right;x++){
        const wx=ox+(x+.5)*cell,dx=wx-clamp(wx,wall.x,wall.x+wall.w);
        const d2=dx*dx+dy*dy,i=y*cw+x;
        if(d2<r2)b[i]=1;
        else if(d2<edge2)preciseEdges[i]=1;
      }
    }
  }
  const grid={cw,ch,cell,ox,oy,b,preciseEdges,routeKey};
  roomFineGrids.set(layout,{ver:navVer,walls:wallGeomVer,grid});
  return grid;
}
function roomSearchEntrance(L,e,layout,radius,walk,requireCross=false){
  let best=null,nearest=Infinity;
  for(const door of doors){
    const f=roomDoorFrame(door),offset=(f.vertical?f.w:f.h)/2+1;
    if(f.cx<layout.x-offset||f.cx>layout.x+layout.w+offset||
       f.cy<layout.y-offset||f.cy>layout.y+layout.h+offset)continue;
    for(const side of [-1,1]){
      const dx=f.vertical?offset*side:0,dy=f.vertical?0:offset*side;
      const inside={x:f.cx+dx,y:f.cy+dy},outside={x:f.cx-dx,y:f.cy-dy};
      if(levelRoomAt(L,inside.x,inside.y)?.building!==layout.building ||
         levelRoomAt(L,outside.x,outside.y)?.building===layout.building)continue;
      const [approach]=roomSearchDoorWaypoints(door,side,radius);
      if(!walk(L,approach.x,approach.y,approach.x,approach.y))continue;
      // 只取刚过门框的位置，门后紧贴容器时也给身体留出站位。
      const entry=requireCross ? {
        x:inside.x+(f.vertical ? (radius-.5)*side : 0),
        y:inside.y+(!f.vertical ? (radius-.5)*side : 0)
      } : inside;
      const pass=walk(L,approach.x,approach.y,entry.x,entry.y);
      if(requireCross && !pass)continue;
      const target=pass ? entry : approach;
      const d=dist(e.x,e.y,target.x,target.y);
      if(d<nearest){best=target;nearest=d;}
    }
  }
  return best;
}
function roomSearchPlan(L,e,s,spread=false){
  if(roomPathUi!==uiT || roomPathTime!==timeAlive){
    roomPathUi=uiT;roomPathTime=timeAlive;roomPathUsed=false;
  }
  s.planDeferred=false;
  navWork.deferred=false;
  const here=levelRoomAt(L,e.x,e.y);
  const layout=roomSearchLayout(L,here,s.roomObj);
  const radius=roomSearchRadius(e,layout);
  const ban=s.ban;
  const walk=(map,x1,y1,x2,y2)=>roomSearchWalk(map,e,x1,y1,x2,y2,ban,radius);
  // 先完成进入同一建筑的路线，避免每条室内脚步都把门外的寻路改成新的请求。
  const enter=layout?.template==='big_house' && here?.building!==layout.building &&
    s.roomObj?.building===layout.building && s.entryFailed!==layout.building &&
    dist(e.x,e.y,s.target.x,s.target.y)<900;
  s.entry=enter ? roomSearchEntrance(L,e,layout,radius,walk,true) : null;
  const target=s.entry || (s.sweep ? s.sweep[s.sweepIndex] : s.target);
  // 锁门/失败入口只覆盖本次 A*，不改全局导航网格或其它敌人的路线。
  const blocked=doors.filter(d=>(d.isLocked&&!d.unlocked&&!d.broken)||d===s.ban);
  let localNav=null;
  if(blocked.length || layout){
    const base=navFor(L);
    const blockedKey=blocked.map(d=>{const f=roomDoorFrame(d);return f.x+','+f.y;}).join(';');
    const routeKey=(layout ? 'room:'+layout.building+':'+radius+':' : '')+blockedKey;
    const cached=layout && roomClearanceGrids.get(layout);
    if(cached?.base===base && cached.ver===navVer && cached.walls===wallGeomVer && cached.grid.routeKey===routeKey){
      localNav=cached.grid;
    }else{
      localNav={...base,b:base.b.slice(),routeKey};
      if(layout){
        const opened=new Set();
        for(let gy=Math.max(0,Math.floor(layout.y/NAV_CELL));gy<base.ch&&gy*NAV_CELL<layout.y+layout.h;gy++){
          for(let gx=Math.max(0,Math.floor(layout.x/NAV_CELL));gx<base.cw&&gx*NAV_CELL<layout.x+layout.w;gx++){
            const x=(gx+.5)*NAV_CELL,y=(gy+.5)*NAV_CELL,i=gy*base.cw+gx;
            if(base.b[i] && walk(L,x,y,x,y)){localNav.b[i]=0;opened.add(i);}
          }
        }
        localNav.opened=opened;
      }
      for(const d of blocked){
        const f=roomDoorFrame(d),r=radius;
        for(let y=Math.max(0,Math.floor((f.y-r)/NAV_CELL));y<=Math.min(base.ch-1,Math.floor((f.y+f.h+r)/NAV_CELL));y++)
          for(let x=Math.max(0,Math.floor((f.x-r)/NAV_CELL));x<=Math.min(base.cw-1,Math.floor((f.x+f.w+r)/NAV_CELL));x++)
            localNav.b[y*base.cw+x]=1;
      }
      if(layout)roomClearanceGrids.set(layout,{base,ver:navVer,walls:wallGeomVer,grid:localNav});
    }
  }
  // 附近的搜房请求只用街区内的网格。桌后无法抵达时无需搜完整张图。
  const nearby=(x,y)=>x>=layout.x-ROOM_LOCAL_RANGE && x<=layout.x+layout.w+ROOM_LOCAL_RANGE &&
    y>=layout.y-ROOM_LOCAL_RANGE && y<=layout.y+layout.h+ROOM_LOCAL_RANGE;
  const office=layout?.template==='office';
  const tightGrid=roomUsesFineClearance(layout);
  const localClue=layout && nearby(e.x,e.y) &&
    (tightGrid ? nearby(target.x,target.y) : (!s.sweep && s.roomObj?.building===layout.building));
  if(localClue){
    const pad=100;
    localNav={...localNav,routeKey:localNav.routeKey+':near',searchBounds:{
      left:Math.floor((Math.min(layout.x,e.x,target.x)-pad)/NAV_CELL),
      right:Math.floor((Math.max(layout.x+layout.w,e.x,target.x)+pad)/NAV_CELL),
      top:Math.floor((Math.min(layout.y,e.y,target.y)-pad)/NAV_CELL),
      bottom:Math.floor((Math.max(layout.y+layout.h,e.y,target.y)+pad)/NAV_CELL)
    }};
  }
  _ROOM_SEARCH_PATH_START.x=e.x;_ROOM_SEARCH_PATH_START.y=e.y;
  _ROOM_SEARCH_PATH_OPTIONS.walkClear=walk;_ROOM_SEARCH_PATH_OPTIONS.navOverride=localNav;
  _ROOM_SEARCH_PATH_OPTIONS.bodyRadius=radius;_ROOM_SEARCH_PATH_OPTIONS.throughDoors=true;_ROOM_SEARCH_PATH_OPTIONS.routeKind="room";
  const pathTo=(x,y)=>{
    if(walk(L,e.x,e.y,x,y))return [[x,y]];
    if(spread && roomPathUsed){s.planDeferred=true;return null;}
    if(spread)roomPathUsed=true;
    _ROOM_SEARCH_PATH_GOAL.x=x;_ROOM_SEARCH_PATH_GOAL.y=y;
    const route=NavQuery.findPath(L,_ROOM_SEARCH_PATH_START,_ROOM_SEARCH_PATH_GOAL,_ROOM_SEARCH_PATH_OPTIONS);
    if(navWork.deferred && layout?.template==='big_house')s.planDeferred=true;
    return route;
  };
  const pathKey=[target.x,target.y,s.roomObj,localNav?.routeKey,navVer];
  let fallback=s.planFallback;
  if(fallback && !pathKey.every((value,i)=>value===fallback.key[i]))fallback=null;
  s.planFallback=fallback;
  const usable=path=>{
    const end=path?.at(-1);
    if(!end)return false;
    if(s.entry)return dist(end[0],end[1],target.x,target.y)<1;
    const endRoom=levelRoomAt(L,end[0],end[1]), d=dist(end[0],end[1],target.x,target.y);
    if(tightGrid && localClue && d>2 && !walk(L,end[0],end[1],target.x,target.y))return false;
    return s.roomObj ? endRoom===s.roomObj && d<=(s.sweep ? 26 : 72) : d<=26;
  };
  const retryFine=tightGrid && localClue && s.finePlanKey && pathKey.every((v,i)=>s.finePlanKey[i]===v);
  let raw=fallback||retryFine ? null : pathTo(target.x,target.y);
  if(!usable(raw)&&tightGrid&&localClue&&!fallback&&!s.planDeferred&&!navWork.deferred){
    s.finePlanKey=pathKey;
    if(spread && roomPathUsed && !retryFine){s.planDeferred=true;return false;}
    if(spread)roomPathUsed=true;
    const fine=roomFineGrid(L,layout,radius,blocked,localNav.routeKey+':fine');
    const fineOptions={walkClear:walk,navOverride:fine,bodyKey:'room-fine'};
    const targetPoint={x:target.x,y:target.y};
    // 从屋内一端开始查。桌子堵死时，搜索在室内耗尽，避免把屋外街区全扫一遍。
    if(s.roomObj?.building===layout.building && levelRoomAt(L,e.x,e.y)?.building!==layout.building &&
       walk(L,target.x,target.y,target.x,target.y)){
      const reverse=NavQuery.findPath(L,targetPoint,e,fineOptions);
      const end=reverse?.at(-1);
      raw=end&&dist(end[0],end[1],e.x,e.y)<.01
        ? [...reverse.slice(0,-1).reverse(),[target.x,target.y]] : null;
    }else raw=NavQuery.findPath(L,e,targetPoint,fineOptions);
    if(navWork.deferred)return false;
  }
  s.finePlanKey=null;
  if(!usable(raw)){
    if(s.planDeferred||navWork.deferred||s.sweep)return false;
    if(s.entry){
      s.entryFailed=layout.building;s.entry=null;s.planT=.4;
      return false;
    }
    if(!s.roomObj){
      if(office)s.planT=-1.4;
      return false;
    }
    // 声源落在箱子旁的窄缝时，屋外也能经正常路线去同房的可达落脚点。
    if(!fallback){
      const candidates=[];
      for(const d of [24,44,66,86,108])for(let i=0;i<16;i++){
        const a=i*TAU/16,x=target.x+Math.cos(a)*d,y=target.y+Math.sin(a)*d;
        if(levelRoomAt(L,x,y)!==s.roomObj||!walk(L,x,y,x,y))continue;
        candidates.push({x,y,score:d+dist(e.x,e.y,x,y)*.25});
      }
      candidates.sort((a,b)=>a.score-b.score);
      const options=candidates.slice(0,4);
      if(localClue && levelRoomAt(L,e.x,e.y)?.building!==layout.building){
        const entrance=roomSearchEntrance(L,e,layout,radius,walk);
        if(entrance)options.push({...entrance,inspection:true});
      }
      fallback=s.planFallback={key:pathKey,candidates:options,index:0};
    }
    while(fallback.index<fallback.candidates.length){
      const {x,y,inspection}=fallback.candidates[fallback.index];
      const route=pathTo(x,y), end=route?.at(-1);
      if(s.planDeferred||navWork.deferred)return false;
      fallback.index++;
      if(end && (inspection
          ? dist(end[0],end[1],x,y)<1
          : dist(end[0],end[1],x,y)<=24 && levelRoomAt(L,end[0],end[1])===s.roomObj)){
        raw=route;
        break;
      }
    }
    s.planFallback=null;
    // 没有任何可达落脚点时，给门和障碍一点变化时间再重新搜索。
    if(!raw){s.planT=-1.4;return false;}
  }
  const points=[];
  let px=e.x,py=e.y;
  for(const q of raw){
    if(!walk(L,px,py,q[0],q[1]))return false;
    const crosses=[];
    for(const d of doors){
      const f=roomDoorFrame(d), a=f.vertical?px-f.cx:py-f.cy;
      const b=f.vertical?q[0]-f.cx:q[1]-f.cy;
      if(a*b>=0||Math.abs(a-b)<.01)continue;
      const t=a/(a-b), side=f.vertical?py+(q[1]-py)*t-f.cy:px+(q[0]-px)*t-f.cx;
      if(Math.abs(side)>(f.vertical?f.h:f.w)/2)continue;
      crosses.push({d,t,sign:Math.sign(a)});
    }
    crosses.sort((a,b)=>a.t-b.t);
    let pendingDoor=null;
    for(const c of crosses){
      const [a,b]=roomSearchDoorWaypoints(c.d,-c.sign,radius);
      // 两个落脚点都可达才插入，狭窄斜门保留原来的身体半径路线。
      if(walk(L,px,py,a.x,a.y)&&walk(L,a.x,a.y,b.x,b.y)&&walk(L,b.x,b.y,q[0],q[1])){
        points.push(a,b);px=b.x;py=b.y;
      }else pendingDoor=c.d;
    }
    const pf=pendingDoor&&roomDoorFrame(pendingDoor);
    points.push({x:q[0],y:q[1],phase:pendingDoor?'cross':'search',door:pendingDoor,
      exitSide:pf?Math.sign(pf.vertical?q[0]-pf.cx:q[1]-pf.cy):0});
    px=q[0];py=q[1];
  }
  const end=points.at(-1);
  s.squeezeDestination=!s.sweep&&grandHallSqueezePoint(L,e,s.roomObj,end.x,end.y);
  s.points=points;s.index=0;s.best=Infinity;s.stall=0;s.planT=0;
  s.phase=points[0].phase;
  s.length=pathLeftLen(points.map(p=>[p.x,p.y]),0,e.x,e.y);
  if(!s.sweep)s.limit=Math.min(90,Math.max(12,s.length/Math.max(25,CFG.eSpeed*.55*eMoveK(e)*enemyMoveK(e))+12));
  return true;
}
function roomSweepNext(s){
  if(s.sweepIndex+1>=s.sweep.length)return false;
  s.sweepIndex++;s.points=null;s.scan=0;s.scanA=null;s.stall=0;s.tries=0;s.planT=.5;s.ban=null;s.phase='search';
  return true;
}
/* 扫视挑有纵深的方向。墙角与箱子仍是检查点，贴着它们的短射线不当作扫视目标。 */
function roomSearchScan(L,e,s,aim,dt){
  if(s.scanA==null){
    let best=-Infinity;
    for(let i=0;i<12;i++){
      const a=aim+i*TAU/12;
      const depth=Math.min(rayToWall(e.x,e.y,a,150,true),rayToTruck(e.x,e.y,a,150));
      const score=depth-14*Math.abs(normAng(a-aim));
      if(score>best){best=score;s.scanA=a;}
    }
  }
  let aimNow=s.scanA+Math.sin(s.scan*3.1)*.38;
  if(rayToWall(e.x,e.y,aimNow,38,true)<38)aimNow=s.scanA;
  e.ang=normAng(e.ang+clamp(normAng(aimNow-e.ang),-dt*5,dt*5));
}
function roomSearchSettled(e,s,delay){
  const sound=e.roomFootClue;
  if(delay===2&&sound&&sound.room===s.roomObj&&dist(sound.x,sound.y,s.target.x,s.target.y)<=92)
    e.roomFootSettled={...sound,until:uiT+delay};
  e.roomSearchFailure={x:s.target.x,y:s.target.y,until:uiT+delay};
  roomSearchRelease(e);e.mode=0;e.heard=false;e.lastKnown=null;
}
// 搜查可能在看见目标或受击时结束。人在窄缝里时先维持侧身宽度，离开后再恢复。
function officeSqueezeRadius(L,e){
  if(roomUsesFineClearance(e.roomSearch?.tightLayout))return e.roomSearch.walkRadius;
  const radius=e.officeSqueeze;
  if(radius===undefined)return null;
  if(bladeWalkLine(L,e.r,e.x,e.y,e.x,e.y,true,undefined,true)){
    e.officeSqueeze=undefined;
    return null;
  }
  return radius;
}
// 有后续路点、侧身能站稳但正常站姿放不下时，先走完这一段窄缝。
function officeGapWaypoint(L,e,s){
  if(!roomUsesFineClearance(s?.tightLayout))return null;
  const p=s.points?.[s.index];
  if(!p || dist(e.x,e.y,p.x,p.y)<.001 ||
     bladeWalkLine(L,e.r,e.x,e.y,e.x,e.y,true,undefined,true) ||
     !roomSearchWalk(L,e,e.x,e.y,p.x,p.y,s.ban))return null;
  return p;
}
function roomSearchRelease(e){
  if(roomUsesFineClearance(e.roomSearch?.tightLayout) && e.roomSearch.walkRadius!==undefined)
    e.officeSqueeze=e.roomSearch.walkRadius;
  e.roomSearch=null;e.path=null;e.goal=null;e.bladeNavPath=null;
  e.forceT=0;e.netT=0;e.stuckT=0;e.doorTgt=null;e.sameRoom=false;
}
/* 独立的移动所有者：只管有室内线索的可追击枪手，队友命令和普通室外战术不走这里。
   感知、开火、状态冷却仍由主循环处理。失败记录不因同一处重复脚步而重置。 */
function roomSearchTick(L,e,dt){
  if(!L.rooms||!L.rooms.length||!enemyType(e).canShoot||enemyType(e).static||
     e.controller==='companion'||!behaviorOf(e).canChase||e.bossKind)return false;
  if(eStatusHas(e,'stun')||eStatusHas(e,'hurt')||eStatusHas(e,'suppress')||e.fleeing||
     eStatusHas(e,'call')||enemyLowHp(e)||!e.lastKnown||e.mode!==1){
    if(e.roomSearch)roomSearchRelease(e);
    return false;
  }
  const here=levelRoomAt(L,e.x,e.y),there=levelRoomAt(L,e.lastKnown.x,e.lastKnown.y);
  let s=e.roomSearch;
  const gate=s&&s.points&&s.points[s.index];
  if(gate&&gate.phase==='cross'&&gate.door){
    const f=roomDoorFrame(gate.door);
    const depth=(f.vertical?e.x-f.cx:e.y-f.cy)*gate.exitSide;
    if(depth>(f.vertical?f.w:f.h)/2+(e.r||13)+10){gate.phase='search';s.phase='search';}
  }
  // 细路线的过门点可能刚到门框内，后续路点才把身体带出门洞。
  // 视线先通过时也要走完这一小段，否则切换到普通战斗移动会把人留在门槛。
  const passage=s?.passage;
  if(passage){
    const f=roomDoorFrame(passage.door);
    const depth=(f.vertical?e.x-f.cx:e.y-f.cy)*passage.exitSide;
    if(depth>=(f.vertical?f.w:f.h)/2+s.walkRadius || passage.door===s.ban)s.passage=null;
  }
  const gapWaypoint=officeGapWaypoint(L,e,s);
  // A sliver of line of sight can open before the body clears the corner.
  // Keep the verified approach while the usual perception and shooting logic runs.
  const finishingSqueeze=s?.squeezeDestination&&s.points&&s.index<s.points.length&&
    s.roomObj===there&&dist(s.target.x,s.target.y,e.lastKnown.x,e.lastKnown.y)<=80;
  const crossing=s&&(s.phase==='cross'||s.passage||gapWaypoint||finishingSqueeze);
  if((!here&&!there&&!crossing&&!s?.points)||(e.sees&&here===there&&!crossing)){
    if(s)roomSearchRelease(e);
    return false;
  }
  const failure=e.roomSearchFailure;
  if(!s&&failure&&levelRoomAt(L,failure.x,failure.y)===there&&dist(failure.x,failure.y,e.lastKnown.x,e.lastKnown.y)<80&&uiT<failure.until){
    // 同一条走不通的线索暂时释放移动权；不能站在原地等重新规划。
    e.mode=0;e.heard=false;e.lastKnown=null;
    return false;
  }
  if(!s){
    s=e.roomSearch={target:{...e.lastKnown},points:null,index:0,tries:0,age:0,stall:0,phase:'search',limit:12,planT:.5,
      roomObj:(typeof levelRoomAt==='function'?levelRoomAt(L,e.lastKnown.x,e.lastKnown.y):null)||null};
    e.path=null;e.goal=null;e.forceT=0;e.netT=0;
    // 清掉先前的架枪目标，不取消受击/逃命状态，也不永久禁用室内掩体。
    eStatusClear(e,'fear');e.hideGoal=null;e.tacticPhase=null;e.tacStage=null;
    e.tucked=false;e.holding=0;e.lookT=0;e.strafeT=0;
  }
  s.age+=dt;s.planT=(s.planT||0)+dt;s.retargetT=(s.retargetT||0)+dt;
  if(s.age>s.limit){
    if(s.navRecovery)navRecoveryPatrol(e,s,s.target.x,s.target.y);
    roomSearchSettled(e,s,3);return true;
  }
  if(s.sweep && e.sees && !gapWaypoint){roomSearchRelease(e);return false;}
  const sameEntry=s.entry && s.roomObj?.building===there?.building;
  if(!crossing&&!sameEntry&&(s.roomObj!==there||dist(s.target.x,s.target.y,e.lastKnown.x,e.lastKnown.y)>80)&&s.retargetT>.7){
    s.retargetT=0;s.target={...e.lastKnown};s.points=null;s.sweep=null;s.swept=false;s.scan=0;s.scanA=null;s.roomObj=there;s.entry=null; // 更新证据不清零失败次数和总时限。
  }
  // 门板扫动可能把人挤进旁边家具；先恢复合法身体位置，再规划。
  s.tightLayout=roomSearchLayout(L,here,s.roomObj) || (s.points ? s.tightLayout : null);
  s.walkRadius=roomSearchRadius(e,s.tightLayout);
  for(const w of collisionWalls(L,e.x,e.y,s.walkRadius))pushOutCircle(e,s.walkRadius,w);
  // 跨进房间时脚下可能还在桌子的另一侧。先跟完调查路线，再开始扫房。
  const pendingTightRoute=roomUsesFineClearance(s.tightLayout) && s.points && s.index<s.points.length &&
    !roomSearchWalk(L,e,e.x,e.y,s.target.x,s.target.y,s.ban);
  if(!s.entry && !s.swept && here && here===s.roomObj && !crossing && !e.sees && !pendingTightRoute &&
     typeof searchSweepAppend==='function' && searchSweepAppend(L,e,s)){
    s.points=null;s.planT=.5;
  }
  if(!s.points){
    const recovery=s.navRecovery;
    if(recovery&&dist(s.target.x,s.target.y,recovery.clueX,recovery.clueY)>90)s.navRecovery=null;
    let failed=false,waiting=(s.navRecovery?.pending||0)>0;
    if(s.planT>=.4&&!(s.navRecovery?.retry>0)){
      s.planT=0;
      roomSearchPlan(L,e,s,true);
      waiting=!s.points&&(s.planDeferred||navWork.deferred);
      failed=!s.points&&!waiting;
      if(waiting)s.planT=.4;
    }
    if(s.points)s.navRecovery=null;
    else if(failed||waiting||s.navRecovery){
      if(navRecoveryTick(L,e,s,dt,s.walkRadius,failed,waiting,s.target.x,s.target.y)){
        navRecoveryPatrol(e,s,s.target.x,s.target.y);roomSearchSettled(e,s,3);

      }
      return true;
    }
  }
  if(s.points){
    while(s.index<s.points.length&&roomSearchReachedWaypoint(L,e,s)){
      s.index++;s.best=Infinity;s.stall=0;
    }
    if(s.index>=s.points.length){
      if(s.entry){
        s.entry=null;s.points=null;s.target={...e.lastKnown};s.roomObj=there;s.planT=.4;
        return true;
      }
      if(e.sees){roomSearchRelease(e);return false;}
      if(s.sweep){
        const q=s.sweep[s.sweepIndex];
        s.phase='scan';s.scan=(s.scan||0)+dt;
        roomSearchScan(L,e,s,Math.atan2(q.ly-e.y,q.lx-e.x),dt);
        if(s.scan<1.4)return true;
        s.sweepVisited++;
        if(roomSweepNext(s))return true;
        if(s.sweepVisited===s.sweepCount)e.roomSearchChecked={room:s.roomObj,at:uiT};
        roomSearchSettled(e,s,2);
        return true;
      }
      s.phase='scan';s.scan=(s.scan||0)+dt;
      if(s.scan<=1.5){
        roomSearchScan(L,e,s,e.ang,dt);
        return true;
      }
      roomSearchSettled(e,s,2);
      return true;
    }
    const p=s.points[s.index];s.phase=p.phase;
    if(p.door && searchEntryFragWaitForAlly(L,e,s,p))return true;
    if(p.phase==='cross' && p.door && searchEntryFragTick(L,e,s,p,dt))return true;
    if(s.tightLayout?.template==='office' && p.phase==='cross' && p.door)s.passage=p;
    // 按剩余路长统计进度，绕家具暂时远离目标也算前进。
    let remain=dist(e.x,e.y,p.x,p.y);
    for(let i=s.index+1;i<s.points.length;i++)remain+=dist(s.points[i-1].x,s.points[i-1].y,s.points[i].x,s.points[i].y);
    if(remain<s.best-2){s.best=remain;s.stall=0;}else s.stall+=dt;
    if(!roomSearchWalk(L,e,e.x,e.y,p.x,p.y,s.ban)){
      if(roomSearchRealignDoor(L,e,s,p))return true;
      s.stall=Math.max(s.stall,1.7);
    }
    else {
      const a=Math.atan2(p.y-e.y,p.x-e.x);
      const step=Math.min(dist(e.x,e.y,p.x,p.y),CFG.eSpeed*.72*eMoveK(e)*enemyMoveK(e)*dt);
      // 等门板完全转开再穿，避免正在摆动的门把身体扫进门边家具。
      const d=p.phase==='cross'?p.door:null;
      const f=d && roomDoorFrame(d);
      // 斜穿路线的路点可能还离门很远。先靠近，只有到门框边才等门板开足。
      const nearFrame=f && Math.hypot(e.x-clamp(e.x,f.x,f.x+f.w),e.y-clamp(e.y,f.y,f.y+f.h))<=s.walkRadius+10;
      const opening=d&&!d.broken&&d.open<.95&&nearFrame;
      if(!opening)bladeMove(L,e,a,step,s.walkRadius);
      e.goal={x:p.x,y:p.y};if(!opening)e.walkAcc=(e.walkAcc||0)+step;
      if(!e.sees)e.ang=normAng(e.ang+clamp(normAng(a-e.ang),-dt*4,dt*4));
    }
  }
  if(s.stall>1.6){
    s.tries++;
    // 办公室只有一扇外门。因为拥挤短暂停住时重算走位，避免把唯一入口踢出路线。
    const p=s.points&&s.points[s.index];
    if(s.entry && s.tries===2){s.entryFailed=s.roomObj?.building;s.entry=null;}
    if(s.tries===2&&p?.door&&s.tightLayout?.template!=='office')s.ban=p.door;
    s.points=null;s.stall=0;
  }
  if(s.sweep && s.tries>2 && roomSweepNext(s))return true;
  if(s.tries>2){
    navRecoveryPatrol(e,s,s.target.x,s.target.y);
    roomSearchSettled(e,s,3);
  }
  return true;
}
/* 房间只是空间约束，不是关闭战术的开关；空旷大房间保持原交战距离。 */
function roomEngageDistance(L,e,threat,desired){
  const r=levelRoomAt(L,e.x,e.y);
  if(!r||levelRoomAt(L,threat.x,threat.y)!==r)return desired;
  const a=Math.atan2(e.y-threat.y,e.x-threat.x);
  let room=0;
  for(let d=24;d<=desired;d+=24){
    const x=e.x+Math.cos(a)*d,y=e.y+Math.sin(a)*d;
    if(!roomHasPoint(r,x,y)||!bladeWalkLine(L,e.r||13,e.x,e.y,x,y))break;
    room=d;
  }
  return Math.min(desired,Math.max(65,dist(e.x,e.y,threat.x,threat.y)+room-24));
}

/* 当前战术威胁。优先实体目标；只有声音记忆时才退到记忆点。
   这一层把“战术对谁做”从玩家对象里拆开，后续新增阵营无需再复制 AI。 */
function enemyThreatOf(e){
  return EnemyPerception.threat(e);
}

function pickAdvanceSpot(L, e, threat){
  threat = threat || enemyThreatOf(e);
  if (!L || !threat || threat === e) return null;
  const nowD = dist(e.x, e.y, threat.x, threat.y);
  let best = null, bestD = nowD - 40;
  const R = TAC.pushAdvR || 360;
  for (let i = 0; i < 12; i++){
    const a = rand(0, TAU), r = rand(90, R);
    const cx = e.x + Math.cos(a) * r, cy = e.y + Math.sin(a) * r;
    if (cx < 34 || cy < 34 || cx > L.w - 34 || cy > L.h - 34) continue;
    if (!losBlocked(threat.x, threat.y, cx, cy)) continue;   /* 得是当前目标看不见的点 */
    if (losBlocked(e.x, e.y, cx, cy)) continue;              /* 路也别被墙挡死 */
    const dd = dist(cx, cy, threat.x, threat.y);
    if (dd < bestD){ bestD = dd; best = { x: cx, y: cy }; }
  }
  return best;
}
/* 只要能看见，或者线是通的且在射程内，就该有开枪的机会 */
function enemyCanTakeShot(e, suppress, threat){
  threat = threat || enemyThreatOf(e);
  if (!e || e.dead || !threat || threat === e) return false;
  if (e.reloading > 0 || (e.ammo | 0) <= 0) return false;
  if (e.sees) return true;
  const d = dist(e.x, e.y, threat.x, threat.y);
  if (d > (TAC.anyShotR || 460)) return false;
  /* suppress：火力压制时人是拉出去「照着印象里的位置扫」，不需要真的看得见 */
  if (suppress) return true;
  return !losBlocked(e.x, e.y, threat.x, threat.y);
}
function perfT(){ return (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000; }
function humanOn(L){ L = L || cur(); return !!(L && L.rules && (L.rules.devTest || L.rules.human)); }

/* 战术分层：0 = 普通兵，1 = 老兵（职业兵/火箭筒兵/精英），2 = 精英（会包抄/喊支援）。
   为什么要分层：humanOn 是"关卡级"开关，死亡地带、4-1 一开就是全场都会，
   可"闪身枪 / 假动作 / 盲射 / 交替掩护跃进"这些是训练水平的差别，
   普通小兵也该会躲、会缩、会追，但不该打出特种部队的配合。
   判据全部来自数据（behavior 预设 or behavior 里的 canFlank/canCallBackup），不写死兵种名。 */
function tacticsTier(e){
  if (!e) return 0;
  const T = (typeof enemyType === 'function') ? enemyType(e) : (e.type && ENEMY_TYPES ? ENEMY_TYPES[e.type] : null);
  if (!T) return 0;
  /* 实例级覆盖：测试/特殊个体可以直接给本人挂 `behavior:'veteran'` 或 `tactics:true` */
  if (e.behavior === 'veteran' || e.tactics === true) return 1;
  const b = (typeof behaviorOf === 'function') ? behaviorOf(e) : (T.behavior || null);
  if (b && (b.canFlank || b.canCallBackup)) return 2;
  if (T.behavior === 'veteran') return 1;
  if (b && b.veteran === true) return 1;
  return 0;
}
/* 这个兵在这张图上该不该用"高级战术"（闪身/假动作/盲射/跃进） */
function tacticsPlus(e, L){ return humanOn(L) && tacticsTier(e) >= 1; }

/* 敌人的脚步声纹怎么画。返回 0=不画 1=听得到就画 2=只在看不见的时候画
   为什么要分两档：停电关（blind）里人眼本来就看不见远处，画声纹不会重复信息；
   4-1 这种"视野外隐身"的关，看得见的时候画声纹纯属噪音，只在 invisble 那一段才有意义。
   数据开关写在关卡 rules 里：footsteps:true 打开，footsteps:false 强行关掉；不写则沿用 blind。 */
function footstepMode(L){
  L = L || cur();
  const r = (L && L.rules) || {};
  if (r.footsteps === false) return 0;
  /* m44781：面板上手动开「视野：锥子外不可见」时，敌人本来就会隐身，
     这时候更要靠声纹判断"看不见的人在哪"。以前只有 rules.footsteps / L.blind
     才算"有隐身敌人"，于是普通关开了隐身也没声纹 —— 玩家看到的是"人会凭空消失"。 */
  const _fogUI = (typeof fogVisionOn === 'function' && fogVisionOn());
  const on = (r.footsteps === true || !!L.blind || _fogUI);
  if (!on) return 0;
  /* 1 = 一直画（停电关本来也看不见）；2 = 只在"看不见他"的时候画（锥外隐身关） */
  return L.blind ? 1 : 2;
}
function humanFear(e, L, chance, look, threat){
  if (!humanOn(L) || !e || e.dead || e.boss) return false;
  /* 职业兵不吃这一套：近失弹、同伴倒下都不会让他乱。
     他该做的还是找掩体，只是永远走"战术"那条线，不走"吓破胆"那条。 */

  if (eStatusHas(e, 'fear')) return false;
  if (arenaRandom() > chance) return false;
  threat = threat || enemyThreatOf(e);
  if (!threat || threat === e) return false;
  let spot = pickHideSpot(L, e, 170, true, threat);
  if (!spot) spot = pickHideSpot(L, e, 120, false, threat);
  if (!spot) spot = pickHideSpot(L, e, 60, false, threat);
  if (!spot) return false;
  eStatusSet(e, 'fear', HUMAN.fearDur * rand(0.8, 1.25));
  e.hideGoal = {x: spot.x, y: spot.y}; e.coverOK = 0;
  e.peekPhase = 'run'; e.peekT = 0; e.tucked = false;
  e.swayT = 0; e.swayPh = arenaRandom() * 6.283; e.feinted = false;
  e.glanceT = 0; e.glanceAt = look ? {x: look.x, y: look.y} : null;
  e.path = null; e.goal = null; e.chk = null; e.stuckT = 0;
  return true;
}
/* 同伴倒下也是通用战术事件：只影响死者同阵营，并把真正的攻击者交给找掩体逻辑。
   以前玩家击杀走这条，NPC 击杀直接删实体，A/B 互打自然永远不会慌、不会缩。 */
function humanComradeFall(dead, source){
  if (!humanOn() || !dead) return 0;
  const own = (typeof combatFaction === 'function') ? combatFaction(dead) : (dead.faction || dead.team || 'enemy');
  let n = 0;
  for (const o of enemies){
    if (!o || o === dead || o.dead || dist(o.x, o.y, dead.x, dead.y) >= HUMAN.comradeR) continue;
    if (typeof combatFaction === 'function' && combatFaction(o) !== own) continue;
    const threat = source && (typeof factionWantsFight !== 'function' || factionWantsFight(o, source))
      ? source : enemyThreatOf(o);
    if (!threat) continue;
    if (humanFear(o, cur(), HUMAN.fearP * 0.7, {x:dead.x, y:dead.y}, threat)) n++;
    voiceSay(o, 'comrade', 0.5, 3);
  }
  return n;
}
/* 一次爆炸只为每名幸存者提交一次同伴倒下反应。伤害与掉落已在原帧结算。 */
const blastComradeQueue=new Map();
let blastComradeEnemies=null;
function queueBlastComradeFalls(fallen,source){
  if(!fallen.length || !humanOn())return;
  if(blastComradeEnemies!==enemies){
    blastComradeQueue.clear();
    blastComradeEnemies=enemies;
  }
  const deaths=fallen.map(e=>({x:e.x,y:e.y,faction:combatFaction(e)}));
  const reach2=HUMAN.comradeR**2;
  for(const e of enemies){
    if(!e || e.dead || e._dying || e.hp<=0)continue;
    const faction=combatFaction(e);
    let count=0, nearest=null, best=reach2;
    for(const dead of deaths){
      if(dead.faction!==faction)continue;
      const d2=(e.x-dead.x)**2+(e.y-dead.y)**2;
      if(d2>=reach2)continue;
      count++;
      if(d2<best){best=d2;nearest=dead;}
    }
    if(count)blastComradeQueue.set(e,{look:nearest,source,count,until:timeAlive+1.5});
  }
}
function tickBlastComradeFalls(L){
  if(blastComradeEnemies!==enemies){blastComradeQueue.clear();blastComradeEnemies=null;return;}
  const start=performance.now();
  let count=0;
  for(const [e,event] of blastComradeQueue){
    blastComradeQueue.delete(e);
    if(e.dead || e._dying || e.hp<=0 || event.until<timeAlive)continue;
    const threat=event.source && factionWantsFight(e,event.source) ? event.source : enemyThreatOf(e);
    if(!threat)continue;
    const chance=1-(1-HUMAN.fearP*.7)**event.count;
    humanFear(e,L,chance,event.look,threat);
    voiceSay(e,'comrade',.5,3);
    if(++count>=3 || performance.now()-start>=1.5)break;
  }
  if(!blastComradeQueue.size)blastComradeEnemies=null;
}
/* 职业兵往你和他之间扔一颗烟：把自己藏进烟里，逼你换角度。
   和玩家共用 grenades 数组 —— 飞行、落地、遮挡视线全部沿用现成那套，
   只是多带了自己的半径和时长（g.r / g.life）。 */
function enemyThrowSmoke(e, target){
  target = target || enemyThreatOf(e);
  const T = enemyType(e);
  if (!T.smokeP) return false;
  if ((e.smokeCd || 0) > 0) return false;
  if (!target || target.hp <= 0) return false;
  const d = dist(e.x, e.y, target.x, target.y);
  if (d > (T.smokeDist || 220)) return false;
  const a = Math.atan2(target.y - e.y, target.x - e.x);
  const dd = Math.max(70, Math.min(d * 0.70, T.smokeDist || 220));
  const L = cur();
  const raw = {x: e.x + Math.cos(a) * dd, y: e.y + Math.sin(a) * dd};
  const at = (L && L.walls) ? safeSpot(L, raw, 12) : raw;
  /* 和玩家那颗完全同一套参数（半径/持续都走 CFG），只是多带一个 byEnemy 标记：
     它只挡玩家的眼睛，不挡自己人。 */
  grenades.push({ x0:e.x, y0:e.y, x:e.x, y:e.y, x1:at.x, y1:at.y,
                  t:0, dur:(T.smokeDur || 0.55), byEnemy:combatFaction(e)!=='player' });
  e.smokeCd = (T.smokeCd || 9.0);
  e.fireCd = Math.max(e.fireCd || 0, 0.55);   /* 抬手扔这一下，枪口先压下去 */
  sfxThrow();
  voiceSay(e, 'tac', 1, 2);
  return true;
}

/* ---------- 人机射速的「难度上限」（数值在 data/ai.js 的 DataROF_CAP） ----------
   以前这个上限是死亡地带里写死的一个常数（ARENA_REF_ROF），想让硬核更凶就只能改那个数，
   一改连普通档一起变，而且别的模式（新档位、活动关、BOSS 战）根本调不到。
   现在改成「按模式取一条倍率」：新增模式只要让 enemyRofTierKey() 能返回那个键名，
   再在 DataROF_CAP.modeKeys / weaponK 里加一条，逻辑一行都不用动。 */
function enemyRofTierKey(){
  /* dzLvl 只在真正进了死亡地带才非空（game/50-deathzone.js 里进出时赋值），
     dzTier 的默认值本身就是 'core'，所以不能只看 dzTier —— 那会让普通关也变成硬核。 */
  const L = (typeof dzLvl !== 'undefined') ? dzLvl : null;
  if (!L) return (typeof ar !== 'undefined' && ar) ? 'arena' : 'default';
  const tier = (typeof dzTier === 'string') ? dzTier : 'normal';
  return (tier === 'core') ? 'hardcore' : 'dz';
}
function enemyRofCap(tierKey, wid){
  const D = (typeof DataROF_CAP !== 'undefined') ? DataROF_CAP : null;
  const base = (D && isFinite(D.default)) ? D.default : 3.6;
  if (!D) return base;
  const key = (tierKey && D.modeKeys && D.modeKeys[tierKey] !== undefined) ? tierKey : 'default';
  const modeK = (D.modeKeys[key] === undefined) ? 1 : D.modeKeys[key];
  let cap = base * modeK;
  const wk = D.weaponK && D.weaponK[key];
  if (wk && wid && wk[wid] !== undefined) cap *= wk[wid];
  const floor = (isFinite(D.floor) ? D.floor : 0.6) * base;
  return Math.max(floor, cap);
}

/* 建筑交战的速度倍率：敌人盯上对面炮塔/棱堡时，用 DataStructFight 里的数值，
   不要在 enemyStructureEngage 里再写死。 */
function structFightSpdK(e){
  if (typeof DataStructFight !== 'object' || !DataStructFight || DataStructFight.on === false) return 1;
  return DataStructFight.spdK || 1;
}
/* 行军倍率兜底：行军态本来被压到 0.52，打建筑时至少拉到 marchK */
function structFightMarchK(e, marchK){
  const k = (typeof marchK === 'number' && marchK > 0) ? marchK : 1;
  if (typeof DataStructFight !== 'object' || !DataStructFight || DataStructFight.on === false) return k;
  return Math.max(k, DataStructFight.marchK || 1);
}

/* 火箭筒兵的「空炸引信」是否生效（数值在 data/ai.js 的 DataRPG.airburst）。
   开着时弹丸进爆炸圈会自己把弹着点往前挪，玩家体感是「落点突然变了」；
   所以默认只在军团对抗（moba）里开，死亡地带/正式关一律按解算点老老实实炸。 */
function rpgAirburstOn(){
  const A = (typeof DataRPG !== 'undefined' && DataRPG && DataRPG.airburst) ? DataRPG.airburst : null;
  if (!A) return true;                                  /* 没有数据时保持旧行为，别让弹道突然变样 */
  if (A.on === true) return true;
  if (typeof mobaOn === 'function' && mobaOn()) return A.moba !== false;
  return false;
}

/* ---- 3-4 专用：刀手砍完原地定住，给玩家逃跑窗口 ----
   只有关卡规则里写了 knifeLock 才生效（目前只有 3-4 雨雾街头），其它关读到 false。 */
function knifeLockOn(){
  const L = (typeof cur === 'function') ? cur() : null;
  if (!L || !L.rules || !L.rules.knifeLock) return false;
  return !(typeof DataKnifeLock !== 'undefined' && DataKnifeLock.on === false);
}
/* 伤害命中后按 DataKnifeLock 取原有命中档的时长。 */
function knifeLockSec(){
  if (typeof DataKnifeLock === 'undefined') return 0;
  const key = (typeof diffName === 'string' && diffName) ? diffName : 'normal';
  const missT = (DataKnifeLock.miss && DataKnifeLock.miss[key]);
  const extraT = (DataKnifeLock.extra && DataKnifeLock.extra[key]);
  return (missT === undefined ? 2.6 : missT) + (extraT === undefined ? 3.0 : extraT);
}


/* ---------- 爆点：只在娱乐模式开 ----------
   devOnly 的关卡 = 选关列表里"娱乐模式"那几张（测试区靶场/空地/大场地、斗蛐蛐长廊）。
   正式战役关卡一定关（startLevel 会清 dzLvl、也没有 devOnly）；割草(arena)与军团对抗(moba)的关卡数据同样带 devOnly:true，所以它们也会开爆点。 */
function calloutOn(){
  if (typeof DataCallout === 'undefined' || !DataCallout || DataCallout.on === false) return false;
  const L = (typeof cur === 'function') ? cur() : null;
  /* 娱乐模式（选关列表里的测试区/长廊）：devOnly */
  if (L && L.devOnly === true) return true;
  /* 死亡地带：用户 m04633 要求也开，先试压力（dzLvl 只在死亡地带里非空） */
  if (typeof dzLvl !== 'undefined' && dzLvl) return true;
  return false;
}
/* 这一次能喊多远：基准半径 × 当前天气折扣（数据全在 DataCallout 里） */
function calloutRadius(){
  const D = (typeof DataCallout !== 'undefined') ? DataCallout : null;
  if (!D) return 820;
  let k = 1;
  try {
    const w = (typeof weather === 'string') ? weather : 'clear';
    const wm = D.weatherK || {};
    if (wm[w] !== undefined) k = wm[w];
  } catch (err) { k = 1; }
  return (D.radius || 820) * k;
}
