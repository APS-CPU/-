/* ================= 战利品木箱：搜刮 / 打爆（第 18 轮） =================
   数据全在 data/lootcrate.js（距离、读条时长、掉落表），covers.js 里只是登记了类型。
   这里只写「能不能搜、搜到一半什么时候断、打开了怎么变」。
   状态机：
     closed  = w.opened 假 → 能搜；也能被打
     打到 0 血 → openLootCrate(w, true)：掉落 + 变成 opened + 血改成 openHp（还能当掩体）
     opened  = w.opened 真 → 不能搜；还能挡人挡子弹；再打到 0 血就正常碎掉，不再掉东西 */
/* 摇品质。bias 0 = 地上随便一件，1 = 空投/军械箱那种"值得翻"的容器 */
function rollQuality(bias){
  bias = Math.max(0, Math.min(1, bias || 0));
  let tw = 0;
  const w = QUALITY_W.map((v, i) => { const x = v * (1 + bias * i * 0.55); tw += x; return x; });
  let r = Math.random() * tw;
  for (let i = 0; i < w.length; i++){ r -= w[i]; if (r <= 0) return i; }
  return 0;
}
/* 只给一件掉落物定一次品质（懒生成：第一次画到 / 第一次被捡时摇） */
function qualityRollFor(l, bias){
  if (!l) return 0;
  /* 金条是死价，不参与品质浮动（不然地上光晕会变紫/金、估值也会跟着涨） */
  if (l.kind === 'rare'){ l.q = 0; return 0; }
  if (l.q === undefined || l.q === null) l.q = rollQuality(bias || 0);
  return l.q;
}

let crateSearch = null;          /* {w, t, dur, hp0}：同一时间只搜一个箱子 */

/* 玩家脚下到这块箱子的距离（按矩形算，不是中心点，贴角也能搜） */
function distToRect(px, py, w){
  const dx = Math.max(w.x - px, 0, px - (w.x + w.w));
  const dy = Math.max(w.y - py, 0, py - (w.y + w.h));
  return Math.sqrt(dx * dx + dy * dy);
}

/* 找最近的可搜箱子；没有就返回 null */
/* ---- 门：靠近 / 开关 / 挨打 / 碎掉 ----
   门不在 L.walls 里，走的是 doors 这一套：
   · 挡人：pushOutCircle / 寻路 obstacles / navBlockedAt 都认 doorSolid
   · 挡视线：losBlocked 与 rayToWall 都认 doorSolid
   · 不挡子弹：子弹只遍历 L.walls，所以本来就能穿过去；
     穿过去的那一帧会顺手扣门血（见子弹循环里的 doorHitAlongShot） */
function doorNear(){
  if (!player || !doors.length) return null;
  let best = null, bd = doorCfg.range;
  for (const d of doors){
    if (d.broken) continue;
    const dd = distToRect(player.x, player.y, d);
    if (dd <= bd){ bd = dd; best = d; }
  }
  return best;
}

/* 玩家站在门框里就别让他关门（会把自己夹在门里） */
function playerInDoor(d){
  if (!player) return false;
  const r = player.r || 11;
  return player.x > d.x - r && player.x < d.x + d.w + r &&
         player.y > d.y - r && player.y < d.y + d.h + r;
}

/* ---- 锁门与"开锁"（钥匙道具的接口） ----
   数据层：关卡 doors[] 里写 `isLocked:true`，可选 `keyId:'red'`（现在只当提示文字用）。
   玩家没钥匙时按 E 只会得到「门锁着」的反馈；解锁后本局永久有效（换关/重开才复位）。
   钥匙道具那边只需要调用 unlockNearestLocked() 或者 unlockDoor(d)，不用碰别的字段。 */
function unlockDoor(d, quiet){
  if (!d || d.broken) return false;
  if (!d.isLocked || d.unlocked) return false;
  d.unlocked = true;
  try { staticInvalidate(); } catch (err) {}   /* 挂锁画在墙层里的话要重烘一次 */
  if (!quiet){
    setMsg('锁开了', 1.4);
    if (typeof sfxDoor === 'function')
      sfxDoor(true, (d.fx != null ? d.fx : d.x) + (d.fw || d.w) / 2,
                     (d.fy != null ? d.fy : d.y) + (d.fh || d.h) / 2);
  }
  return true;
}

/* 找玩家身边最近的一扇锁着的门（默认 54px，和搜刮的手差不多长） */
function lockedDoorNear(range){
  if (!player || !doors || !doors.length) return null;
  const R = range || 54;
  let best = null, bestD = R;
  for (const d of doors){
    if (!d || d.broken || !d.isLocked || d.unlocked) continue;
    const fx = d.fx != null ? d.fx : d.x, fy = d.fy != null ? d.fy : d.y;
    const fw = d.fw || d.w, fh = d.fh || d.h;
    const dd = distToRect(player.x, player.y, { x: fx, y: fy, w: fw, h: fh });
    if (dd < bestD){ bestD = dd; best = d; }
  }
  return best;
}

/* 钥匙道具的入口：把身边最近那扇锁门打开，返回是否真的开了 */
function unlockNearestLocked(range){
  const d = lockedDoorNear(range);
  if (!d) return false;
  return unlockDoor(d);
}

/* 开门时调。**现在钥匙是无限用的**（不删格子也不扣数），
   以后要做"一次性钥匙"只需要把下面那行 return true 改成真正的删除逻辑。 */
function useOneKey(){
  if (!player) return false;
  if (keyCount() <= 0) return false;
  return true;
}
function useOneKeyLegacy(){
  if (!player) return false;
  if (typeof bagGridOn === 'function' && bagGridOn()){
    const k = bagOfKind('key')[0];
    if (!k) return false;
    bagRemoveItem(k);
    bagRebuild();
    return true;
  }
  if ((player.keys | 0) > 0){ player.keys = (player.keys | 0) - 1; return true; }
  return false;
}

/* 手里有没有万能钥匙：网格背包版本读背包，老关卡读影子计数 */
function keyCount(){
  if (!player) return 0;
  if (typeof bagGridOn === 'function' && bagGridOn()) return bagCountOf('key');
  return player.keys | 0;
}
