/* 大风天气（weather:'wind'） ---------------------------------------------
   和雨/雷暴独立的一层：
     · 移动：顺风跑得更快、逆风被顶住（只作用在玩家身上，敌人照旧 —— 玩家才有"风"这个体感）
     · 画面：屏幕空间的风线 + 飘尘 + 几片叶子，密度随阵风变化，朝风向斜着刮过去
     · 声音：滤波噪声做出来的风噪，跟着阵风起伏（走 duckBus，耳鸣照样能压住它）
   开发模式按 C 切天气就会轮到大风。
   ------------------------------------------------------------------------ */
var WIND = {
  on: false,
  ang: 0.35,        /* 风的去向（弧度）：0 = 向右 */
  base: 1,          /* 基础风力 0~1 */
  gust: 1,          /* 阵风系数 0.55~1.15*/
  k: 1,             /* 风力档位 0~1.1：微风 0.34 / 大风 1 / 狂风暴雨 1.1（m20556） */
  t: 0,
  lines: [],
  dust: [],
  leaves: [],
  audio: null,
  fade: 0,          /* 风场速度、移动加成和风噪的缓起缓停 */
  vis: null,        /* 天气过渡给出的画面透明度，null 时沿用风场自己的淡入淡出 */
  visualStrength: 1,
  surge: 0,         /* 一次阵风的强度 1→0（每隔几秒来一下，那一下才有"被风刮"的感觉）*/
  push: 0.34,       /* 这一档天气的风力倍率：顺风也就快多少、逆风就被顶多少 */
  surgeT: 0,
  nextSurge: 3.5,
  sheets: []        /* 贴地飞过去的沙尘带 */
};
const WIND_SPEED = 520;      /* 所有风线共用的基准速度（px/s），阵风时一起加速 */
const WIND_PUSH = 0.34;    /* 顺风 +34% / 逆风 -34% */
const WIND_LINES = 76, WIND_DUST = 46, WIND_LEAVES = 16;

function windVisibility(){ return WIND.vis ?? WIND.fade; }
function windActive(){
  return typeof state !== 'undefined' && state === 'play' && windVisibility() > 0;
}
function windVec(){ return { x: Math.cos(WIND.ang), y: Math.sin(WIND.ang) }; }

function windEnsureField(){
  if (WIND.lines.length) return;
  const W0 = (typeof W === 'number' ? W : 1280), H0 = (typeof H === 'number' ? H : 800);
  for (let i = 0; i < WIND_LINES; i++)
    WIND.lines.push({ x: rand(-200, W0 + 200), y: rand(-200, H0 + 200), len: rand(90, 320), a: rand(0.05, 0.12), w: rand(1.1, 2.5), aj: rand(-0.055, 0.055) });
  for (let i = 0; i < WIND_DUST; i++)
    WIND.dust.push({ x: rand(-200, W0 + 200), y: rand(-200, H0 + 200), r: rand(1.0, 2.4), a: rand(0.07, 0.18) });
  for (let i = 0; i < 6; i++)
    WIND.sheets.push({ x: rand(-400, W0 + 400), y: rand(H0 * 0.30, H0 + 120), len: rand(300, 700), r: rand(12, 30), a: rand(0.02, 0.05) });
  for (let i = 0; i < WIND_LEAVES; i++)
    WIND.leaves.push({ x: rand(-200, W0 + 200), y: rand(-200, H0 + 200), rot: rand(0, TAU), spin: rand(-3, 3), s: rand(3.2, 6.0), a: rand(0.26, 0.46) });
}

/* 开关大风（weatherSet 里调） */
/* 只调风力，不重掷方向（过渡里每帧都会调，不能碰 WIND.ang） */
function windPushSet(pushK, kK){
  if (!WIND) return;
  WIND.push = WIND_PUSH * (pushK > 0 ? pushK : 1);
  if (kK > 0) WIND.k = kK;
}

function windVisualSet(visibility, strength){
  if (!WIND) return;
  WIND.vis = clamp(visibility, 0, 1);
  WIND.visualStrength = strength;
}

function windDirectionSet(angle){
  if (WIND) WIND.ang = angle;
}

function windSet(on, pushK, kK){
  if (!WIND) return;   /* 打包成单文件时函数声明会提升，可能在 WIND 初始化之前被调到 */
  WIND.on = !!on;
  WIND.vis = null;
  WIND.push = WIND_PUSH * (pushK > 0 ? pushK : 1);
  WIND.k = (kK > 0 ? kK : 1);
  WIND.visualStrength = WIND.k;
  if (WIND.on){
    WIND.base = 1;
    WIND.t = 0;
    windEnsureField();
  }
  /* m20556：关风不再硬切 —— 交给 windTick 里的 fade 自然落下去，音量和画面一起淡出 */
}

/* 每帧：推进阵风 + 移动风线（屏幕空间） */
function windTick(dt){
  if (!WIND || (!WIND.on && WIND.fade <= 0)) return;
  const tgt = WIND.on ? 1 : 0;
  /* m22299：4.5/s 太快（0.2 秒就到位），切天气时风是"啪"一下出现/消失。
     1.1/s ≈ 2 秒到位，肉眼能看出是慢慢起来的。 */
  WIND.fade += (tgt - WIND.fade) * Math.min(1, dt * 1.1);
  if (WIND.fade < 0.01 && !WIND.on){ WIND.fade = 0; return; }

  WIND.t += dt;
  /* 两个不同周期的正弦叠出"一阵一阵"的阵风 */
  /* 基本是一股稳定的风：只留很轻的呼吸感，真正的"一阵"由下面的 surge 负责，
     免得整片风线像节拍器一样一快一慢 */
  const g = 1;   /* 风力恒定：之前那一套呼吸/阵风会让整片风线一快一慢，像循环播放 */
  WIND.gust = clamp(g, 0.5, 1.15);
  /* 风线朝向与位移使用同一风向，随天气过渡更新。 */

  /* 阵风：每 4~9 秒来一下，1 秒左右衰减掉 */
  WIND.surgeT += dt;
  if (WIND.surgeT > WIND.nextSurge){
    WIND.surgeT = 0;
    WIND.nextSurge = 4 + Math.random() * 5;
    WIND.surge = 1;
  }
  WIND.surge = Math.max(0, WIND.surge - dt * 1.05);

  const k = WIND.fade;   /* 速度只跟淡入淡出有关，不再随风阵起伏 */
  const v = windVec();
  const W0 = (typeof W === 'number' ? W : 1280), H0 = (typeof H === 'number' ? H : 800);

  /* 所有东西跟着同一股风走：速度统一，只有位置不同。
     出界不从对侧"回绕"（那样会看出规律的节点），而是从迎风边随机位重新进来。 */
  const spd = WIND_SPEED * k;
  const M = 260;
  const outX = (x, pad) => (v.x >= 0 ? x > W0 + pad : x < -pad);
  const outY = (y, pad) => (v.y >= 0 ? y > H0 + pad : y < -pad);
  for (const L of WIND.lines){
    L.x += v.x * spd * dt;
    L.y += v.y * spd * dt;
    if (outX(L.x, M + L.len)){ L.x = v.x >= 0 ? -M - L.len : W0 + M + L.len; L.y = rand(-M, H0 + M); L.a = rand(0.05, 0.12); }
    else if (outY(L.y, M + L.len)){ L.y = v.y >= 0 ? -M - L.len : H0 + M + L.len; L.x = rand(-M, W0 + M); L.a = rand(0.05, 0.12); }
  }
  for (const d of WIND.dust){
    d.x += v.x * spd * 1.05 * dt;
    d.y += v.y * spd * 1.05 * dt;
    if (outX(d.x, 30)){ d.x = v.x >= 0 ? -30 : W0 + 30; d.y = rand(-30, H0 + 30); }
    else if (outY(d.y, 30)){ d.y = v.y >= 0 ? -30 : H0 + 30; d.x = rand(-30, W0 + 30); }
  }
  for (const sh of WIND.sheets){
    sh.x += v.x * spd * 1.00 * dt;
    sh.y += v.y * spd * 1.00 * dt * 0.30;
    if (outX(sh.x, sh.len + 80)){ sh.x = v.x >= 0 ? -sh.len - 80 : W0 + sh.len + 80; sh.y = rand(H0 * 0.30, H0 + 120); }
  }
  for (const lf of WIND.leaves){
    lf.x += v.x * spd * 0.90 * dt;
    lf.y += v.y * spd * 0.90 * dt + Math.sin(WIND.t * 2.2 + lf.rot) * 26 * dt;
    lf.rot += lf.spin * dt * (0.6 + k * 0.6);
    if (outX(lf.x, 24)){ lf.x = v.x >= 0 ? -24 : W0 + 24; lf.y = rand(-24, H0 + 24); }
    else if (outY(lf.y, 24)){ lf.y = v.y >= 0 ? -24 : H0 + 24; lf.x = rand(-24, W0 + 24); }
  }
  windAudioLevel(WIND.fade * (WIND.vis ?? 1) * WIND.gust * (1 + 0.7 * WIND.surge) * (0.30 + 0.70 * Math.min(1.2, WIND.k)));
}

/* 移动倍率：dirX/dirY 是归一化的移动方向；顺风 >1，逆风 <1 */
function windMoveK(dirX, dirY){
  if (!WIND || !WIND.on || WIND.fade <= 0.02) return 1;
  const v = windVec();
  const dot = dirX * v.x + dirY * v.y;            /* -1 正顶风 … +1 正顺风 */
  const k = 1 + (WIND.push || WIND_PUSH) * dot * WIND.gust * WIND.fade;
  return clamp(k, 0.55, 1.45);
}

/* 预烘软贴图：风线两头淡出（不会有硬线头），沙尘带是一坨模糊椭圆。
   每帧只 drawImage，不画硬描边 —— 之前那种清晰细线看起来像 UI，不像风。 */
var WIND_SPRITE = null, WIND_SHEET = null;
function windMakeSprites(){
  if (WIND_SPRITE || typeof document === 'undefined') return;
  const mk = (w, h, fn) => { const c = document.createElement('canvas'); c.width = w; c.height = h; fn(c.getContext('2d'), w, h); return c; };
  WIND_SPRITE = mk(256, 24, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, w, 0);
    gr.addColorStop(0.00, 'rgba(224,236,248,0)');
    gr.addColorStop(0.30, 'rgba(224,236,248,0.35)');
    gr.addColorStop(0.72, 'rgba(240,248,255,0.85)');
    gr.addColorStop(1.00, 'rgba(240,248,255,0)');
    g.fillStyle = gr;
    /* 上下两片：中间亮、边缘淡，模拟一束被打散的气流 */
    g.beginPath(); g.ellipse(w / 2, h / 2, w / 2, h * 0.30, 0, 0, TAU); g.fill();
    g.globalAlpha = 0.45;
    g.beginPath(); g.ellipse(w / 2, h / 2, w / 2, h * 0.46, 0, 0, TAU); g.fill();
  });
  WIND_SHEET = mk(256, 64, (g, w, h) => {
    const gr = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
    gr.addColorStop(0, 'rgba(200,190,170,0.55)');
    gr.addColorStop(0.55, 'rgba(200,190,170,0.22)');
    gr.addColorStop(1, 'rgba(200,190,170,0)');
    g.fillStyle = gr;
    g.save(); g.translate(w / 2, h / 2); g.scale(1, h / w); g.beginPath(); g.arc(0, 0, w / 2, 0, TAU); g.fill(); g.restore();
  });
}

function drawWindFx(){
  if (!WIND) return;
  const a0 = windVisibility();
  if (a0 <= 0) return;
  windMakeSprites();
  if (!WIND_SPRITE) return;
  const v = windVec();
  /* 微风的风线与沙尘带更淡。档位改变时，用透明度过渡整个风场。 */
  const strength = clamp(WIND.visualStrength, 0, 1.2);
  const streakAlpha = a0 * strength * strength;
  ctx.save();
  ctx.lineCap = 'round';
  if (streakAlpha > 0){
    for (const sh of WIND.sheets){
      ctx.globalAlpha = sh.a * streakAlpha * (0.8 + 0.2 * WIND.gust + 0.5 * WIND.surge);
      ctx.save();
      ctx.translate(sh.x - v.x * sh.len * 0.5, sh.y - v.y * sh.len * 0.5);
      ctx.rotate(WIND.ang);
      ctx.drawImage(WIND_SHEET, -sh.len * 0.5, -sh.r * 0.5, sh.len, sh.r);
      ctx.restore();
    }
    for (const L of WIND.lines){
      ctx.globalAlpha = L.a * streakAlpha * (0.85 + 0.15 * WIND.gust) * (1 + 0.55 * WIND.surge);
      const hh = 7 * L.w;
      ctx.save();
      ctx.translate(L.x, L.y);
      ctx.rotate(WIND.ang + (L.aj || 0));
      ctx.drawImage(WIND_SPRITE, -L.len, -hh / 2, L.len, hh);
      ctx.restore();
    }
  }
  /* 飘尘：小圆点，比风线快一点 */
  ctx.fillStyle = 'rgba(226,234,244,0.9)';
  for (const d of WIND.dust){
    ctx.globalAlpha = d.a * a0;
    ctx.beginPath();
    ctx.arc(d.x, d.y, d.r, 0, TAU);
    ctx.fill();
  }
  /* 几片被卷起来的叶子：小三角，自己也在转 */
  ctx.fillStyle = 'rgba(120,132,86,0.9)';
  for (const lf of WIND.leaves){
    ctx.globalAlpha = lf.a * a0;
    ctx.save();
    ctx.translate(lf.x, lf.y);
    ctx.rotate(lf.rot);
    ctx.beginPath();
    ctx.moveTo(-lf.s, 0); ctx.lineTo(0, -lf.s * 0.55); ctx.lineTo(lf.s, 0); ctx.lineTo(0, lf.s * 0.55);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }
  ctx.restore();
}

/* ---------------- 风噪：分四层，只有强风才"狂" ----------------
   m37811：原来只有一条布朗噪声 → 高通 → 低通 → 一个增益，强弱只是"声音大小"，
   所以狂风暴雨听着还是闷闷的一股呼。现在拆成四层 + 声像扫动：
     body  低处压着的隆隆（布朗噪声 + 低通 200~800Hz）—— 这一层给风"体重"
     air   中频在扫（白噪声 + 带通 Q4，中心频率被 0.08Hz 的 LFO 拖着走）—— "呼——"
     howl  更高一点的呜咽（第二个带通 Q6.5，0.15Hz LFO，扫得更宽）—— "呜——"
     whine 只在风雷 / 狂风暴雨才慢慢开进来的窄尖啸（Q14）—— 从耳边割过去的"咻"
   air 与 howl 各挂一个 StereoPanner，被两个不同速度的 LFO 反向推 →
   风会从一边扫到另一边，这才是"从耳边拼命刮过去"的感觉。
   再叠 6.4Hz 的快速抖动（呼呼呼的"喘"）和阵风瞬间的一记 whoosh。
   总音量也不在 k=1 处封顶了（旧代码 clamp 到 1，所以狂风暴雨和大风一样响）。 */
const WIND_MIX = { body: 0.55, air: 0.30, howl: 0.15, whine: 0.10, master: 0.150 };

function windAudioLevel(k){
  const A = WIND && WIND.audio;
  if (!A || !A.gain) return;
  try {
    const ac = A.ac, now = ac.currentTime;
    const s = Math.max(0, Math.min(2, k));
    const w = Math.min(1.2, (WIND && WIND.k) || 1);          /* 档位：微风 .34 / 风雷 .88 / 大风 1 / 狂风暴雨 1.1 */
    const wk = (typeof weather === 'string') ? weather : '';
    const storm = (wk === 'squall') ? 1.32 : (wk === 'gale' ? 1.10 : 1);
    const surge = (WIND && WIND.surge) || 0;
    const vk = (typeof ambVolK === 'function') ? ambVolK() : 1;
    /* 强档留出 1.75 倍余量：k 到 1 之后还能继续变响、变尖、变躁 */
    const loud = Math.min(1.75, s * (0.55 + 0.45 * w) * storm * (1 + 0.5 * surge));
    A.gain.gain.setTargetAtTime(WIND_MIX.master * loud * vk, now, 0.10);

    /* 低处：风越大低通推得越高，隆隆变"厚"，不会一直闷在 400Hz */
    if (A.lpBody) A.lpBody.frequency.setTargetAtTime(Math.min(1100, 190 + 430 * w * (0.78 + 0.3 * surge)), now, 0.18);
    if (A.hpBody) A.hpBody.frequency.setTargetAtTime(55 + 45 * w, now, 0.22);

    /* 中频扫动：风越大扫得越高、摆幅越大 */
    if (A.bpAir){
      A.bpAir.frequency.setTargetAtTime(360 + 560 * w, now, 0.25);
      if (A.bpAirDepth) A.bpAirDepth.gain.setTargetAtTime(190 + 330 * w, now, 0.30);
    }
    if (A.bpHowl){
      A.bpHowl.frequency.setTargetAtTime(820 + 760 * w, now, 0.25);
      if (A.bpHowlDepth) A.bpHowlDepth.gain.setTargetAtTime(250 + 430 * w, now, 0.30);
    }
    /* 尖啸：只在大风以上慢慢开进来，微风时完全听不见 */
    if (A.whineGain) A.whineGain.gain.setTargetAtTime(
      WIND_MIX.whine * Math.max(0, (w - 0.70) / 0.40) * Math.min(1, loud) * (0.55 + 0.45 * storm), now, 0.30);
    if (A.bpWhine) A.bpWhine.frequency.setTargetAtTime(1700 + 1100 * w, now, 0.30);

    /* 声像扫动幅度：微风几乎不摆，狂风暴雨能摆到耳朵两侧 */
    const pd = 0.10 + 0.78 * Math.min(1, w / 1.05);
    if (A.panDepthA) A.panDepthA.gain.setTargetAtTime(pd, now, 0.40);
    if (A.panDepthB) A.panDepthB.gain.setTargetAtTime(-pd, now, 0.40);
    if (A.panDepthC) A.panDepthC.gain.setTargetAtTime(0.12 + 0.42 * Math.min(1, w / 1.05), now, 0.50);

    /* 阵风起势的那一帧补一记 whoosh（只在风雷/狂风暴雨这种强档） */
    if (surge > 0.85 && (A.lastSurge || 0) < 0.4 && w >= 0.75 && loud > 0.25)
      windAudioWhoosh(Math.min(1, 0.55 + 0.45 * w) * vk);
    A.lastSurge = surge;
  } catch(e){}
}

/* 阵风瞬间的一记"哇——"：一段快速上扬又落下的噪声，左右随机偏一侧 */
function windAudioWhoosh(strength){
  const A = WIND && WIND.audio;
  if (!A || !A.aux) return;
  try{
    const ac = A.ac, now = ac.currentTime;
    const len = Math.floor(ac.sampleRate * 0.75);
    const buf = ac.createBuffer(1, len, ac.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++){ const t = i / len; d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 1.3); }
    const src = ac.createBufferSource(); src.buffer = buf;
    const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 2.0;
    bp.frequency.setValueAtTime(360, now);
    bp.frequency.exponentialRampToValueAtTime(1450, now + 0.26);
    bp.frequency.exponentialRampToValueAtTime(620, now + 0.70);
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(0.150 * Math.max(0.2, Math.min(1.2, strength)), now + 0.10);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.70);
    src.connect(bp); bp.connect(g);
    const pan = ac.createStereoPanner ? ac.createStereoPanner() : null;
    if (pan){ pan.pan.value = (Math.random() * 2 - 1) * 0.85; g.connect(pan); pan.connect(A.aux); }
    else g.connect(A.aux);
    src.start(now); src.stop(now + 0.78);
  }catch(e){}
}

function windAudioStart(){
  if (!WIND || WIND.audio || typeof actx === 'undefined' || !actx) return WIND && WIND.audio;
  try {
    const ac = actx, sr = ac.sampleRate;
    const mkNoise = function(kind, sec){
      const len = Math.floor(sr * sec);
      const buf = ac.createBuffer(1, len, sr);
      const d = buf.getChannelData(0);
      if (kind === 'brown'){ let last = 0; for (let i = 0; i < len; i++){ const wn = Math.random() * 2 - 1; last = (last + 0.02 * wn) / 1.02; d[i] = last * 3.2; } }
      else { for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1; }
      return buf;
    };
    const mkOsc = function(rate){ const o = ac.createOscillator(); o.type = 'sine'; o.frequency.value = rate; o.start(0); return o; };
    const bus = (typeof duckBus === 'function' && duckBus()) || ac.destination;

    /* ---- 低处隆隆 ---- */
    const srcBody = ac.createBufferSource(); srcBody.buffer = mkNoise('brown', 2.0); srcBody.loop = true;
    const hpBody = ac.createBiquadFilter(); hpBody.type = 'highpass'; hpBody.frequency.value = 70;
    const lpBody = ac.createBiquadFilter(); lpBody.type = 'lowpass'; lpBody.frequency.value = 420; lpBody.Q.value = 0.7;
    const bodyGain = ac.createGain(); bodyGain.gain.value = WIND_MIX.body;
    srcBody.connect(hpBody); hpBody.connect(lpBody); lpBody.connect(bodyGain);

    /* ---- 中频 / 呜咽 / 尖啸：共用一条白噪声 ---- */
    const srcAir = ac.createBufferSource(); srcAir.buffer = mkNoise('white', 2.5); srcAir.loop = true;
    const hpAir = ac.createBiquadFilter(); hpAir.type = 'highpass'; hpAir.frequency.value = 180;
    srcAir.connect(hpAir);

    const bpAir = ac.createBiquadFilter(); bpAir.type = 'bandpass'; bpAir.frequency.value = 620; bpAir.Q.value = 4.0;
    const airGain = ac.createGain(); airGain.gain.value = WIND_MIX.air;
    hpAir.connect(bpAir); bpAir.connect(airGain);

    const bpHowl = ac.createBiquadFilter(); bpHowl.type = 'bandpass'; bpHowl.frequency.value = 1150; bpHowl.Q.value = 6.5;
    const howlGain = ac.createGain(); howlGain.gain.value = WIND_MIX.howl;
    hpAir.connect(bpHowl); bpHowl.connect(howlGain);

    const bpWhine = ac.createBiquadFilter(); bpWhine.type = 'bandpass'; bpWhine.frequency.value = 2100; bpWhine.Q.value = 14;
    const whineGain = ac.createGain(); whineGain.gain.value = 0;
    hpAir.connect(bpWhine); bpWhine.connect(whineGain);

    /* ---- 声像：air+whine 走左/右一路，howl 走另一路，两个 LFO 反向推 ---- */
    const pan1 = ac.createStereoPanner ? ac.createStereoPanner() : null;
    const pan2 = ac.createStereoPanner ? ac.createStereoPanner() : null;
    const pan3 = ac.createStereoPanner ? ac.createStereoPanner() : null;
    const pre = ac.createGain(); pre.gain.value = 1;
    const hook = function(node, pan){ if (pan){ node.connect(pan); pan.connect(pre); } else node.connect(pre); };
    hook(airGain, pan1); hook(whineGain, pan1); hook(howlGain, pan2); hook(bodyGain, pan3);

    /* ---- 调制（全部走音频速率，不占 JS 每帧） ---- */
    const bpAirDepth = ac.createGain(); bpAirDepth.gain.value = 190;
    mkOsc(0.081).connect(bpAirDepth); bpAirDepth.connect(bpAir.frequency);
    const bpHowlDepth = ac.createGain(); bpHowlDepth.gain.value = 250;
    mkOsc(0.146).connect(bpHowlDepth); bpHowlDepth.connect(bpHowl.frequency);
    const panDepthA = ac.createGain(); panDepthA.gain.value = 0.2;
    const panDepthB = ac.createGain(); panDepthB.gain.value = -0.2;
    const panDepthC = ac.createGain(); panDepthC.gain.value = 0.2;
    if (pan1 && pan2 && pan3){
      /* m37811：0.067/0.113Hz 太慢（15 秒才扫一趟，听着像缓慢漂移）。
         现在 0.23/0.37Hz ≈ 2.7~4.3 秒一个来回，才像"风从耳边刮过去"；
         低处那团(body)用更慢的 0.15Hz 单独摆，整片风才有"团"在移动的感觉。 */
      mkOsc(0.23).connect(panDepthA); panDepthA.connect(pan1.pan);
      mkOsc(0.37).connect(panDepthB); panDepthB.connect(pan2.pan);
      mkOsc(0.15).connect(panDepthC); panDepthC.connect(pan3.pan);
    }
    /* 6.4Hz 快速抖动：空气被一阵一阵"喘"过去的感觉 */
    const flutter = ac.createGain(); flutter.gain.value = WIND_MIX.air * 0.32;
    mkOsc(6.4).connect(flutter); flutter.connect(airGain.gain);

    /* ---- 总线：master 跟风力走；aux 是给 whoosh 用的旁路（不随 master 压） ---- */
    const gain = ac.createGain(); gain.gain.value = 0;
    pre.connect(gain); gain.connect(bus);
    const aux = ac.createGain(); aux.gain.value = 1; aux.connect(bus);

    srcBody.start(0); srcAir.start(0);
    WIND.audio = {
      ac, src: srcBody, srcAir, gain, aux, pre,
      hpBody, lpBody, bodyGain, bpAir, airGain, bpHowl, howlGain, bpWhine, whineGain,
      bpAirDepth, bpHowlDepth, panDepthA, panDepthB, panDepthC, pan1, pan2, pan3, flutter, lastSurge: 0
    };
  } catch(e){ WIND.audio = null; }
  return WIND.audio;
}
