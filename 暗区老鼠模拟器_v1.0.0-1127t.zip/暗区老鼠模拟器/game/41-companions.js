/* Companion runtime. No player substitution: every combat operation has an explicit target.
   allies never enters enemies[], wave counts, enemy rewards or alarm broadcasts. */
let allies = [];
let companionRules = {friendlyFire:false};
let companionSeq = 0, companionCommandSeq = 0;
let companionTrail = [], companionLastPlayer = null, companionHeading = 0;
let companionConeCache=new WeakMap(),companionSightCache=new WeakMap();
let companionVisualCache=new WeakMap();
let companionMouseMode=true,companionOrderMarker=null;
const COMPANION_VISION={get range(){return seeRange(cur());},get half(){return seeFov(cur())*Math.PI/360;},rays:DataCOMPANION_VISION_RAYS};
function resetCompanions(){
  allies.length=0; companionSeq=0; companionCommandSeq=0;
  companionTrail=[];companionLastPlayer=null;companionHeading=0;
  companionConeCache=new WeakMap();companionSightCache=new WeakMap();
  companionVisualCache=new WeakMap();
  companionOrderMarker=null;
  companionRules={friendlyFire:diffName==='nightmare'};
  if(typeof ui!=='undefined'&&ui.inv)ui.inv.companion=null;
}
function companionSpawn(at){
  if(!player||state!=='play'||allies.length>=4)return null;
  const slot=allies.length;
  const p=safeSpot(cur(),at||{x:player.x-55-slot*34,y:player.y+(slot%2?-35:35)},18),T=enemyType({type:'specFlank'});
  const e={id:'ally-'+(++companionSeq),faction:'player',controller:'companion',type:'specFlank',
    x:p.x,y:p.y,r:T.r||12,ang:player.aim||0,hp:T.hp||100,maxHp:T.hp||100,
    wid:'rifle',ammo:weaponCore('rifle').cap,reloading:0,fireCd:0,specShotRecovery:0,
    muzzle:0,mode:0,sees:false,wp:[],i:0,wait:0,armor:armorOf(T.armorKind||'heavy'),
    command:{seq:0,type:'follow',point:null,targetId:null},tactical:null,
    targetId:null,scanT:0,coverCd:0,complaintCd:0,avoidT:0,avoidGoal:null};
  companionPack(e).ammo[gunDef({wid:e.wid}).ammo]=90;
  allies.push(e);return e;
}
function combatId(e){if(e===player)return 'player';return e.id||(e.id='npc-'+(++companionSeq));}
function companionCommand(type,point,target,options={}){
  if(!['follow','hold','move','focus'].includes(type))return false;
  if((type==='move'||type==='focus')&&!point&&!target)return false;
  const seq=++companionCommandSeq;
  for(const e of allies){
    companionBreakPair(e);
    e.command={seq,type,point:type==='hold'?{x:e.x,y:e.y}:point?{x:point.x,y:point.y}:null,
      targetId:target?combatId(target):null};
    if(options.arrivalHold)e.command.arrivalHold=true;
    e.scanT=0;e.targetId=null;
    e.tactical=null;e.path=null;e.goal=null;e.commandStall=0;e.commandLast=null;
    e.followIdle=null;e.crouch=false;
  }
  setMsg(({follow:'队友跟随',hold:'队友守住',move:'队友前往标记',focus:'队友集火'})[type],1.5);
  return true;
}
function companionVisible(e,t){return t&&!t.dead&&t.hp>0&&dist(e.x,e.y,t.x,t.y)<720&&
  !losBlocked(e.x,e.y,t.x,t.y)&&!smokeBlocks(e.x,e.y,t.x,t.y,combatFaction(e)!=='player');}
function companionTarget(e,dt){
  e.scanT=(e.scanT||0)-dt;
  const old=enemies.find(o=>o.id===e.targetId&&!o.dead);
  if(e.scanT>0&&old)return old;
  e.scanT=.15;
  let best=null,bd=Infinity;
  const protecting=player.hp<(ar?arenaMaxHp():CFG.hp)*.35;
  const focus=e.command&&e.command.type==='focus'&&enemies.find(o=>o.id===e.command.targetId&&!o.dead);
  if(focus&&companionVisible(e,focus))best=focus;
  else for(const o of enemies){
    const d=dist(protecting?player.x:e.x,protecting?player.y:e.y,o.x,o.y);
    if(d<bd&&combatHostile(e,o)&&companionVisible(e,o)){best=o;bd=d;}
  }
  if(best){e.enemyMemory={x:best.x,y:best.y,left:2};}
  else if(old&&e.enemyMemory&&e.enemyMemory.left>0){e.enemyMemory.left-=.15;return old;}
  e.targetId=best?combatId(best):null;return best;
}
function companionEnemyTarget(e){
  const T=enemyType(e);
  if(!allies.length||e.boss||e.dummy||(!T.canShoot&&T.kind!=='blade'))return null;
  let best=null,bd=enemySees(e,concealed)?dist(e.x,e.y,player.x,player.y):Infinity;
  for(const a of allies){
    if(!combatHostile(e,a))continue;
    const d=dist(e.x,e.y,a.x,a.y),angle=Math.abs(normAng(Math.atan2(a.y-e.y,a.x-e.x)-e.ang));
    const facing=angle<((T.fov||90)*Math.PI/360)||e.combatTargetId===a.id;
    if(d<bd&&d<enemyVisionRange(e,a)&&facing&&companionVisible(e,a)){best=a;bd=d;}
  }
  return best;
}
function companionEnemyEngage(e,target,dt){
  if(enemyType(e).kind!=='blade'){companionCombat(e,target,dt);return;}
  e.sees=companionVisible(e,target);
  const reach=(e.r||12)+target.r+30;
  e.ang=Math.atan2(target.y-e.y,target.x-e.x);
  e.companionStrikeCd=Math.max(0,(e.companionStrikeCd||0)-dt);
  if(e.companionWindup>0){
    e.companionWindup=Math.max(0,e.companionWindup-dt);
    if(!e.companionWindup){
      if(e.sees&&dist(e.x,e.y,target.x,target.y)<=reach)
        companionDamage(target,gunDef({wid:e.wid||'knife'}).dmg,e,'blade',e.ang);
      e.companionStrikeCd=1.3;
    }
  }else if(e.sees&&dist(e.x,e.y,target.x,target.y)<=reach&&e.companionStrikeCd<=0)e.companionWindup=.3;
  else if(dist(e.x,e.y,target.x,target.y)>reach)companionMove(e,target,dt,CFG.eSpeed*1.3);
}
/* Reuse radius-aware locked navigation; local avoidance never edits navCache. */
function companionMove(e,p,dt,speed,turn=true){
  if(!p||dist(e.x,e.y,p.x,p.y)<8)return;
  if(e.command&&e.command.guard&&e.command.point){
    const c=e.command.point,d=dist(c.x,c.y,p.x,p.y);
    if(d>240)p={x:c.x+(p.x-c.x)*240/d,y:c.y+(p.y-c.y)*240/d};
  }
  const a=navSteer(cur(),e,p.x,p.y,dt),step=Math.min(speed*eMoveK(e)*dt,e.bladeNavDistance||0);
  if(!Number.isFinite(a)||!(step>0))return;
  const x=e.x,y=e.y;e.x+=Math.cos(a)*step;e.y+=Math.sin(a)*step;
  for(const w of cur().walls)pushOutCircle(e,e.r,w);pushOutTrucks(e);
  for(const d of doors)if(doorSolid(d))pushOutCircle(e,e.r,d);
  e.x=clamp(e.x,e.r+2,cur().w-e.r-2);e.y=clamp(e.y,e.r+2,cur().h-e.r-2);
  if(!bladeWalkLine(cur(),e.r,x,y,e.x,e.y)){e.x=x;e.y=y;}
  e.moveHeading=a;
  if(!e.sees&&turn)companionTurn(e,a,dt);
}
/* Follow is a loose activity area, not a spring tied to a fixed player distance.
   Goals and pauses are sampled only at decision boundaries, using the saved RNG. */
function companionTrailPoint(back){
  let prev=player;
  for(let i=companionTrail.length-1;i>=0;i--){
    const p=companionTrail[i],d=dist(prev.x,prev.y,p.x,p.y);
    if(d>=back&&d>0)return {x:prev.x+(p.x-prev.x)*back/d,y:prev.y+(p.y-prev.y)*back/d};
    back-=d;prev=p;
  }
  return {x:prev.x-Math.cos(companionHeading)*back,y:prev.y-Math.sin(companionHeading)*back};
}
function companionFollow(e,dt,quiet,anchor=player){
  const i=Math.max(0,allies.indexOf(e)),d=dist(e.x,e.y,anchor.x,anchor.y);
  let f=e.followIdle;
  if(!f||f.quiet!==quiet){
    f=e.followIdle={quiet,goal:null,wait:.5+arenaRandom()*1.5,clock:i*1.7,
      look:e.ang,catching:d>260,travel:0,stall:0,side:arenaRandom()<.5?-1:1,scanWait:2+arenaRandom()*3,rearLeft:0};
    e.avoidT=0;e.avoidGoal=null;e.spacing=null;
  }
  f.clock+=dt;
  const x=e.x,y=e.y;
  if(quiet){
    f.goal=null;f.catching=false;
    let p=companionTrailPoint(48+i*30);
    if(!bladeWalkLine(cur(),e.r,p.x,p.y,p.x,p.y))p={x:player.x,y:player.y};
    // Re-evaluate the trail as the player walks; navSteer retains its corner lock.
    if(dist(e.x,e.y,p.x,p.y)>13)
      companionMove(e,p,dt,CFG.pSpeed*(ar?ar.spdMul:1)*.55*(d>110+i*30?1.15:1),false);
    if(!e.sees)companionTurn(e,(dist(x,y,e.x,e.y)>.01?e.moveHeading:companionHeading)+Math.sin(f.clock*.8)*.12,dt);
    return;
  }
  if(d>260)f.catching=true;
  if(f.catching&&d<135+i*12){f.catching=false;f.goal=null;f.wait=.8+arenaRandom()*1.2;}
  if(f.catching){
    f.goal=null;
    companionMove(e,anchor===player?companionTrailPoint(90+i*25):anchor,dt,CFG.pSpeed*(ar?ar.spdMul:1)*(d>400?1.3:1.05),false);
  }else{
    f.wait=Math.max(0,f.wait-dt);
    if(f.goal){
      f.travel+=dt;
      if(dist(f.goal.x,f.goal.y,anchor.x,anchor.y)>245||dist(e.x,e.y,f.goal.x,f.goal.y)<14||f.travel>4||f.stall>1){
        f.goal=null;f.wait=1.4+arenaRandom()*2.8;f.look=e.ang;
      }
    }
    if(!f.goal&&f.wait<=0){
      f.wait=1.5+arenaRandom()*2.5;
      f.look=companionHeading+(arenaRandom()-.5)*Math.PI*1.5;
      // Sometimes just stop and watch; teammates do not wander in synchronized loops.
      if(arenaRandom()<.75)for(let n=0;n<6;n++){
        // Continue around the perimeter rather than randomly choosing the opposite
        // side of the player (which used to trigger yield and then snap back).
        const a=Math.atan2(e.y-anchor.y,e.x-anchor.x)+(f.side||1)*(.4+arenaRandom()*.5),r=100+arenaRandom()*65;
        const p={x:anchor.x+Math.cos(a)*r,y:anchor.y+Math.sin(a)*r};
        if(dist(e.x,e.y,p.x,p.y)<30||allies.some(o=>o!==e&&dist(o.x,o.y,p.x,p.y)<42))continue;
        if(combatSegmentEntry(e.x,e.y,p.x-e.x,p.y-e.y,{x:player.x,y:player.y,r:70},0)!==null)continue;
        if(!bladeWalkLine(cur(),e.r,e.x,e.y,p.x,p.y))continue;
        f.goal=p;f.travel=0;f.stall=0;break;
      }
    }
    if(f.goal){
      companionMove(e,f.goal,dt,CFG.pSpeed*.48,false);
      f.stall=dist(x,y,e.x,e.y)>.05?0:f.stall+dt;
    }
  }
  const moving=dist(x,y,e.x,e.y)>.01;
  f.scanWait=(Number.isFinite(f.scanWait)?f.scanWait:2)-dt;
  f.rearLeft=Math.max(0,(f.rearLeft||0)-dt);
  if(f.scanWait<=0){f.rearLeft=1.8+arenaRandom()*.6;f.scanWait=5+arenaRandom()*3;}
  const look=(moving?e.moveHeading:f.look)+(f.rearLeft>0?Math.PI*(f.side||1):Math.sin(f.clock*.85)*.65);
  if(!e.sees)companionTurn(e,look,dt);
}
function companionTurn(e,a,dt){
  e.ang=normAng(e.ang+clamp(normAng(a-e.ang),-3.8*dt,3.8*dt));
}
function companionAimFire(e,target,dt){
  if(!e.sees)return;
  const a=Math.atan2(target.y-e.y,target.x-e.x);
  companionTurn(e,a,dt);
  if(!e.sees||Math.abs(normAng(a-e.ang))>.045||e.fireCd>0||e.ammo<=0||e.reloading>0)return;
  // Do not deliberately shoot through the player or another companion in Nightmare.
  if(e.controller==='companion'&&companionRules.friendlyFire){
    for(const body of [player,...allies]){
      if(body===e||body.dead)continue;
      const t=combatSegmentEntry(e.x,e.y,target.x-e.x,target.y-e.y,body,12);
      if(t!==null&&t<dist(e.x,e.y,target.x,target.y)-target.r){e.laneBlocked=true;return;}
    }
  }
  e.laneBlocked=false;e.blindShot=false;
  // Shoot along the smoothly turned barrel. enemyShoot cannot snap it to the target.
  enemyFireWeapon(e,-1,e.ang,1,target);
}
function companionBreakPair(e){
  const peer=allies.find(a=>a.id===e.partnerId);
  if(peer&&peer.partnerId===e.id){peer.partnerId=null;peer.teamRole=null;peer.teamRetry=3;
    if(peer.tactical&&peer.tactical.kind==='flank')peer.tactical=null;}
  e.partnerId=null;e.teamRole=null;e.teamRetry=3;
}
function companionTryPair(e,target){
  if(e.controller!=='companion'||!behaviorOf(e).canFlank||e.teamRetry>0||e.partnerId||e.tactical)return;
  e.teamRetry=2;
  const peer=allies.find(o=>o!==e&&!o.dead&&!o.partnerId&&!o.tactical&&!(o.teamRetry>0)&&
    behaviorOf(o).canFlank&&o.command.type!=='hold'&&o.command.type!=='move'&&
    o.hp>=o.maxHp*.35&&o.ammo>0&&o.reloading<=0&&!eStatusHas(o,'stun')&&
    dist(e.x,e.y,o.x,o.y)<420&&companionVisible(o,target));
  if(!peer)return;
  const route=flankRoute(cur(),peer,e,target.x,target.y,0);peer.teamRetry=2;
  if(!route)return;
  e.partnerId=peer.id;peer.partnerId=e.id;e.teamRole='support';peer.teamRole='flank';
  e.teamTarget=peer.teamTarget=combatId(target);e.teamTime=peer.teamTime=0;
  peer.tactical={kind:'flank',point:{x:route.x,y:route.y},time:0,side:route.side,best:Infinity,stall:0};
  e.bark='我架枪，你绕侧面！';peer.bark='收到，侧翼包抄！';e.barkT=peer.barkT=2;
}
function companionSpace(e,target,dt,minRange,maxRange,protect){
  const d=dist(e.x,e.y,target.x,target.y),retreat=d<minRange;
  if(e.spacing){
    const p=e.spacing;p.left-=dt;
    if(p.left<=0||dist(e.x,e.y,p.x,p.y)<12||(!retreat&&p.retreat)||dist(target.x,target.y,p.tx,p.ty)>100)e.spacing=null;
  }
  if(!e.spacing&&(retreat||e.laneBlocked||(!e.partnerId&&e.spaceWait<=0&&e.sees))){
    e.spaceWait=1.6;
    const base=Math.atan2(e.y-target.y,e.x-target.x),side=e.spaceSide||((allies.indexOf(e)%2)?1:-1);
    const offsets=retreat?[0,side*.65,-side*.65,side*1.2]:[side*Math.PI/2,-side*Math.PI/2];
    for(const off of offsets){
      const p={x:e.x+Math.cos(base+off)*(retreat?105:70),y:e.y+Math.sin(base+off)*(retreat?105:70)};
      if(bladeWalkLine(cur(),e.r,e.x,e.y,p.x,p.y)&&(!protect||dist(p.x,p.y,player.x,player.y)<300)){
        e.spacing={...p,left:1.4,retreat,tx:target.x,ty:target.y};e.spaceSide=side;break;
      }
    }
  }
  if(e.spacing)companionMove(e,e.spacing,dt,CFG.eSpeed*(retreat?behaviorOf(e).fleeSpdK:1.1));
  else if(d>maxRange||!e.sees){
    // Follow only the last observed position while occluded, not live coordinates through walls.
    const p=e.sees?target:e.enemyMemory;
    if(p)companionMove(e,p,dt,CFG.eSpeed*1.15);
  }
}
function companionYield(e,dt){
  const d=dist(e.x,e.y,player.x,player.y);
  const approaching=player.moving&&((e.x-player.x)*Math.cos(companionHeading)+(e.y-player.y)*Math.sin(companionHeading)>0);
  const near=d<(e.r+player.r+5)||(d<65&&approaching);
  e.avoidT=Math.max(0,(e.avoidT||0)-dt);
  if(near&&e.avoidT<=0){e.avoidT=.65;e.avoidGoal=null;}
  if(!e.avoidT)return false;
  if(!e.avoidGoal){
    if(e.followIdle){e.followIdle.goal=null;e.followIdle.wait=Math.max(e.followIdle.wait||0,2);}
    const side=e.avoidSide||((allies.indexOf(e)%2)?1:-1);
    for(const off of [side*Math.PI/2,Math.PI,-side*Math.PI/2]){
      const a=companionHeading+off,p={x:e.x+Math.cos(a)*68,y:e.y+Math.sin(a)*68};
      if(bladeWalkLine(cur(),e.r,e.x,e.y,p.x,p.y)){e.avoidGoal=p;e.avoidSide=side;break;}
    }
  }
  companionMove(e,e.avoidGoal,dt,CFG.pSpeed*1.2);return true;
}
/* Target-aware veteran tactics: lock cover, reload in cover, peek, flank and retreat fire. */
function companionCombat(e,target,dt){
  const B=behaviorOf(e),d=dist(e.x,e.y,target.x,target.y);
  e.sees=companionVisible(e,target);e.coverCd=Math.max(0,(e.coverCd||0)-dt);
  if(e.sees)e.enemyMemory={x:target.x,y:target.y,left:2};
  const low=e.hp<e.maxHp*.35,needCover=low||e.reloading>0||e.ammo<=0||eStatusHas(e,'hurt');
  const own=e.controller==='companion';
  const protect=own&&player.hp<(ar?arenaMaxHp():CFG.hp)*.35;
  e.spaceWait=Math.max(0,(e.spaceWait||0)-dt);e.teamRetry=Math.max(0,(e.teamRetry||0)-dt);
  if(e.partnerId){
    e.teamTime=(e.teamTime||0)+dt;
    const peer=allies.find(o=>o.id===e.partnerId);
    if(!peer||peer.dead||e.teamTime>5||needCover||protect||e.teamTarget!==combatId(target)||
      eStatusHas(peer,'stun')||peer.reloading>0||peer.ammo<=0)companionBreakPair(e);
  }
  if(protect&&!e.protecting){e.bark='我掩护，你先撤！';e.barkT=2.5;e.tactical=null;}
  e.protecting=protect;
  e.smokeCd=Math.max(0,(e.smokeCd||0)-dt);
  if(low&&e.sees&&e.smokeCd<=0)enemyThrowSmoke(e,target);
  if(needCover&&!e.tactical&&e.coverCd<=0){
    const p=pickHideSpot(cur(),e,120,true,target);e.coverCd=1.2;
    if(p&&dist(e.x,e.y,p.x,p.y)<500)e.tactical={kind:'cover',point:p,time:0};
  }
  if(!needCover&&!protect&&e.ammo>0&&e.sees)companionTryPair(e,target);
  if(e.tactical){
    const t=e.tactical;t.time+=dt;
    const distance=dist(e.x,e.y,t.point.x,t.point.y);
    // A valid detour can initially move away from its destination. Detect actual
    // immobility, not a temporary increase in straight-line distance.
    if(t.lastX===undefined||dist(e.x,e.y,t.lastX,t.lastY)>.15)t.stall=0;
    else t.stall=(t.stall||0)+dt;
    t.lastX=e.x;t.lastY=e.y;
    if(t.time>4||t.stall>1.2){e.tactical=null;e.coverCd=1.5;if(t.kind==='flank')companionBreakPair(e);}
    else if(distance>14)companionMove(e,t.point,dt,CFG.eSpeed*(low?B.fleeSpdK:B.coverRunSpdK));
    else if(t.kind==='cover'&&!needCover){
      let peek=null;
      for(const off of [-1,1]){
        const a=Math.atan2(target.y-e.y,target.x-e.x)+off*Math.PI/2;
        const p={x:e.x+Math.cos(a)*64,y:e.y+Math.sin(a)*64};
        if(bladeWalkLine(cur(),e.r,e.x,e.y,p.x,p.y)&&!losBlocked(p.x,p.y,target.x,target.y)){peek=p;break;}
      }
      e.tactical=peek?{kind:'peek',point:peek,time:0}:null;
    }else if(t.kind!=='cover'){e.tactical=null;if(t.kind==='flank')companionBreakPair(e);}
  }else if(protect&&dist(e.x,e.y,player.x,player.y)>180){
    const a=Math.atan2(target.y-player.y,target.x-player.x),side=allies.indexOf(e)%2?1:-1;
    const p={x:player.x+Math.cos(a+side*.9)*110,y:player.y+Math.sin(a+side*.9)*110};
    companionMove(e,bladeWalkLine(cur(),e.r,p.x,p.y,p.x,p.y)?p:player,dt,CFG.eSpeed*B.coverRunSpdK);
  }else{
    const wid=e.wid,min=wid==='shotgun'?115:wid==='rpg'?240:wid==='pistol'?150:210;
    companionSpace(e,target,dt,low?Math.max(min,250):min,protect?320:wid==='shotgun'?230:360,protect);
  }
  e.sees=companionVisible(e,target);
  companionAimFire(e,target,dt);
}
function companionTickWeapon(e,dt){
  e.fireCd=Math.max(0,(e.fireCd||0)-dt);e.specShotRecovery=Math.max(0,(e.specShotRecovery||0)-dt);
  e.muzzle=Math.max(0,(e.muzzle||0)-dt);
  const p=companionPack(e),g=p.guns[p.selected];
  if(!g){e.ammo=0;e.reloading=0;return;}
  if(e.reloading>0){
    e.reloading=Math.max(0,e.reloading-dt);
    if(!e.reloading){
      const type=gunDef(g).ammo,n=Math.min(weaponCore(e.wid).cap-e.ammo,p.ammo[type]||0);
      e.ammo+=n;p.ammo[type]=(p.ammo[type]||0)-n;
    }
  }
  if(e.ammo<=0&&e.reloading<=0){
    if(companionReserve(e)>0)e.reloading=enemyReloadTime(e);
    else{
      const other=p.guns.findIndex((g,i)=>i!==p.selected&&(g.mag>0||(p.ammo[gunDef(g).ammo]||0)>0));
      if(other>=0)companionEquip(e,other);
      else if(!(e.barkT>0)){e.bark='弹药耗尽！需要补给！';e.barkT=3;}
    }
  }
  companionSyncGun(e);
}
/* 瞭望塔报点：塔上看见谁，就把位置告诉队友（towerMark 由 game/31-watchtower.js 写）。
   优先级最低 —— 只有玩家是"跟随"命令、且自己没交上火时才吃；手动 move/hold/focus 一概让路。
   走到报点附近就原地警戒（面朝那个方向），不追着尸体转。 */
function companionTowerGo(e,dt){
  const m=e.towerMark;
  if(!m||m.t<=0)return false;
  const T=(typeof TOWER_TUNE!=='undefined')?TOWER_TUNE:{goR:90};
  e.followIdle=null;
  if(dist(e.x,e.y,m.x,m.y)>(T.goR||90)){
    companionMove(e,m,dt,CFG.pSpeed*1.12);
    if(!e.sees)companionTurn(e,e.moveHeading,dt);
    return true;
  }
  if(!e.sees)companionTurn(e,Math.atan2(m.y-e.y,m.x-e.x),dt);
  return true;
}
function updateCompanions(dt){
  if(!allies.length)return;
  if(companionLastPlayer){const dx=player.x-companionLastPlayer.x,dy=player.y-companionLastPlayer.y;
    if(Math.hypot(dx,dy)>.01)companionHeading=Math.atan2(dy,dx);}
  else companionHeading=player.aim||0;
  companionLastPlayer={x:player.x,y:player.y};
  const last=companionTrail[companionTrail.length-1];
  if(!last||dist(last.x,last.y,player.x,player.y)>10){companionTrail.push({...companionLastPlayer});if(companionTrail.length>100)companionTrail.shift();}
  for(const e of allies){
    eCdTick(e,dt);eStatusTick(e,dt);companionTickWeapon(e,dt);
    e.complaintCd=Math.max(0,(e.complaintCd||0)-dt);e.barkT=Math.max(0,(e.barkT||0)-dt);
    if(eStatusHas(e,'stun')){eStatusHold(e,'stun');continue;}
    const cmd=e.command,target=companionTarget(e,dt);
    e.sees=companionVisible(e,target);
    e.crouch=cmd.type==='follow'&&!!player.crouch;
    if(!e.crouch&&e.followIdle&&e.followIdle.quiet)e.followIdle=null;
    if(e.crouch){
      e.tactical=null;if(e.partnerId)companionBreakPair(e);
      companionFollow(e,dt,true);
      if(target)companionAimFire(e,target,dt);
      continue;
    }
    if(companionYield(e,dt)){
      if(target){e.sees=companionVisible(e,target);companionAimFire(e,target,dt);}
      continue;
    }
    // Follow has a leash; move orders retain their destination while combat interrupts travel.
    const leash=dist(e.x,e.y,player.x,player.y)>400;
    if(target&&!(cmd.type==='follow'&&leash)){
      e.followIdle=null;
      if(cmd.type==='move'){e.commandStall=0;e.commandLast=null;}
      if(cmd.type==='hold'&&cmd.guard){
        if(dist(target.x,target.y,cmd.point.x,cmd.point.y)<600)companionCombat(e,target,dt);
        else{companionMove(e,cmd.point,dt,CFG.pSpeed);companionAimFire(e,target,dt);}
      }else if(cmd.type==='hold'&&dist(e.x,e.y,cmd.point.x,cmd.point.y)>70)companionMove(e,cmd.point,dt,CFG.pSpeed);
      else if(cmd.type==='hold'){
        e.sees=companionVisible(e,target);companionAimFire(e,target,dt);
      }else companionCombat(e,target,dt);
      continue;
    }
    e.sees=false;e.tactical=null;if(e.partnerId)companionBreakPair(e);
    if(cmd.type==='focus'&&!enemies.some(o=>o.id===cmd.targetId&&!o.dead))e.command={seq:cmd.seq,type:'follow',point:null,targetId:null};
    let p=cmd.point;
    if(e.command.type==='follow'){
      if(companionTowerGo(e,dt))continue;
      companionFollow(e,dt,false,(typeof towerAnchor==='function'&&towerAnchor())||player);continue;
    }
    if(cmd.type==='hold'&&cmd.guard){companionFollow(e,dt,false,cmd.point);continue;}
    companionMove(e,p,dt,CFG.pSpeed*(leash?1.3:1.05));
    if(cmd.type==='move'){
      if(p&&dist(e.x,e.y,p.x,p.y)<18)e.command={seq:cmd.seq,type:'hold',point:{x:p.x,y:p.y},targetId:null,guard:!cmd.arrivalHold};
      const prev=e.commandLast;e.commandLast={x:e.x,y:e.y};
      e.commandStall=prev&&dist(prev.x,prev.y,e.x,e.y)<.1?(e.commandStall||0)+dt:0;
      if(e.commandStall>3){e.command={seq:cmd.seq,type:'hold',point:{x:e.x,y:e.y},targetId:null};setMsg('队友无法到达标记，原地待命',2);}
    }
  }
}
