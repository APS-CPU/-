/* 热成像 v2 的关卡使用更大的电池容量。死亡地带仓库也用同一容量。 */
const HEATCELL_STACK = 4;
const HEAT_CAP_V2 = 1000;
function thermalPower(device, capacity=heatCapNow()){
  const initial=capacity===HEAT_CAP_V2 ? Math.round(capacity*.30) : capacity;
  return { battery:Number.isFinite(device?.battery) ? clamp(device.battery,0,capacity) : initial,
           heatV2Batt:!!device?.heatV2Batt };
}
function thermalSetWorn(device, capacity=heatCapNow()){
  heatCellCancel();
  Object.assign(player,thermalPower(device,capacity));
  player.heatWorn = !!device;
  player.thermalOn = false; player.thermal = false;
  player.heatCd = 0; player.heatOffT = 0; player.batLock = false;
}
function heatCapNow(){ return thermalV2() ? HEAT_CAP_V2 : 100; }
function heatPct(v, capacity=heatCapNow()){
  return Math.round(clamp(Number.isFinite(v) ? v : 0,0,capacity)/capacity*100);
}
function thermalV2(){
  const L = (typeof cur === 'function') ? cur() : null;
  return !!(L && L.rules && L.rules.thermalV2);
}
/* 背包里一共还有几颗电池（按 n 累加，一格最多 4 颗） */
function heatCellLeft(){
  if (typeof bagGridOn === 'function' && bagGridOn()){
    let n = 0;
    for (const it of bagOfKind('heatcell')) n += Math.max(1, (it.n | 0) || 1);
    return n;
  }
  return player.heatCells | 0;
}
/* 往背包里塞电池：先补满已有的格子，再开新格子；返回实际收下几颗 */
function heatCellAdd(cnt){
  let left = Math.max(0, cnt | 0);
  if (!left) return 0;
  const want = left;
  if (typeof bagGridOn === 'function' && bagGridOn()){
    for (const c of bagOfKind('heatcell')){
      if (left <= 0) break;
      const cur = Math.max(1, (c.n | 0) || 1);
      if (cur >= HEATCELL_STACK) continue;
      const put = Math.min(HEATCELL_STACK - cur, left);
      c.n = cur + put; left -= put;
    }
    while (left > 0){
      const put = Math.min(HEATCELL_STACK, left);
      if (!bagAddCell('heatcell', { n: put })) break;
      left -= put;
    }
    bagRebuild();
    return want - left;
  }
  player.heatCells = (player.heatCells | 0) + left;
  return want;
}
/* 换一颗电池要几秒：期间画面提示，可以再点一次 / 按取消键放弃 */
const BAT_SWAP_DUR = 2.6;
/* 点格子（或把电池拖到装备栏的热成像格）：开始换电，不是立刻满电 */
function heatCellBeginSwap(it){
  if (!player.heatWorn){ setMsg('先戴上热成像再换电池', 1.8); return false; }
  if (bagGridOn()){
    it = it || bagOfKind('heatcell')[0];
    if (!it || it.k !== 'heatcell' || !bagItems().includes(it)) return false;
  }
  const hasCell = it ? (Math.max(1, (it.n | 0) || 1) > 0)
                     : ((typeof bagGridOn === 'function' && bagGridOn())
                          ? bagOfKind('heatcell').length > 0
                          : (player.heatCells | 0) > 0);
  if (!hasCell) return false;
  /* m35945：死亡地带容量 ×10，满电判定跟容量走 */
  /* m35945-fix：容量统一走 heatCapNow()（只看 rules.thermalV2；死亡地带的 L 上没有 dz 标记） */
  const _cap = heatCapNow();
  if ((player.battery || 0) >= _cap * 0.995){
    setMsg('热成像电量已经满了 · 电池留着', 1.8);
    return false;
  }
  /* 正在换电：同一格再点一下 = 取消；换另一格 = 撤掉旧的重新开 */
  if ((player.batSwapT || 0) > 0){
    const same = it && (it.uid >>> 0) === (player.batSwapUid >>> 0);
    heatCellCancel(same ? '换电池取消' : '换电池取消 · 改换这一颗');
    if (same) return false;
  }
  player.batSwapT = BAT_SWAP_DUR;
  player.batSwapUid = it ? (it.uid >>> 0) : 0;
  player.batSwapLegacy = !it;   /* 老版本（没有背包格）直接扣 player.heatCells */
  setMsg('换电池中… ' + BAT_SWAP_DUR.toFixed(1) + ' 秒（再点一次 / ' + keyLabel(BINDS.cancel) + ' 取消）', 2.2);
  beep(420, 0.06, 'square', 0.035, 900);
  logInfo('battery', '开始换电池（' + BAT_SWAP_DUR.toFixed(1) + ' 秒）');
  return true;
}
/* 取消换电（再点一次 / 按取消键 / 电池没了）——一颗都不消耗 */
function heatCellCancel(msg){
  if (!((player.batSwapT || 0) > 0)) return false;
  player.batSwapT = 0; player.batSwapUid = 0; player.batSwapLegacy = false;
  if (msg) setMsg(msg, 1.4);
  return true;
}
/* 每帧推进倒计时，到点才真正把电加上 */
function heatCellTick(dt){
  if (!((player.batSwapT || 0) > 0)) return;
  if (!player.heatWorn || (player.batSwapLegacy && !(player.heatCells > 0))){
    heatCellCancel('换电中断');
    return;
  }
  player.batSwapT = Math.max(0, player.batSwapT - dt);
  if (player.batSwapT > 0) return;
  /* 到点：先确认那颗电池还在（可能被丢 / 被抽奖押走） */
  let it = null;
  if (!player.batSwapLegacy && typeof bagOfKind === 'function' && typeof bagGridOn === 'function' && bagGridOn()){
    for (const c of bagOfKind('heatcell')) if ((c.uid >>> 0) === (player.batSwapUid >>> 0)){ it = c; break; }
    if (!it){
      player.batSwapT = 0; player.batSwapUid = 0; player.batSwapLegacy = false;
      setMsg('电池不在了 · 换电中断', 1.6);
      return;
    }
  }
  player.battery = heatCapNow();   /* 用当前容量填满（这里原来引用了一个不存在的 _cap，换电到点会抛 ReferenceError） */
  player.heatV2Batt = true;   /* 用了热成像电池 = 走新版（不回电、无冷却、有电就能开） */
  player.batLock = false;
  player.heatOffT = 0;
  if (it){
    const cur = Math.max(1, (it.n | 0) || 1);
    if (cur > 1) it.n = cur - 1;
    else bagRemoveItem(it);
    bagRebuild();
  } else if ((player.heatCells | 0) > 0){
    player.heatCells--;
  }
  player.batSwapT = 0; player.batSwapUid = 0; player.batSwapLegacy = false;
  setMsg('换上电池 · 热成像电量 100%（还剩 ' + heatCellLeft() + ' 颗）', 2.2);
  beep(660, 0.09, 'square', 0.05, 1200);
  logInfo('battery', '热成像换电池 · 100%（剩 ' + heatCellLeft() + ' 颗）');
}
/* 兼容旧调用名：还是"开始换电" */
function bagUseHeatCell(it){ return heatCellBeginSwap(it); }

function toggleDoor(d){
  if (!d || d.broken){ setMsg('门已经碎了', 1.2); return false; }
  if (d.isLocked && !d.unlocked){
    /* 有万能钥匙：当场开锁并推门；钥匙现在是**无限用**的（不消耗） */
    if (keyCount() > 0){
      useOneKey();
      unlockDoor(d, true);                 /* 解锁本局永久有效 */
      d.want = 1; d.snd = false;           /* 直接推开，音效这一帧补 */
      setMsg(keyCount() > 0 ? '万能钥匙 · 锁开了（无限开）'
                            : '万能钥匙 · 锁开了（钥匙用掉了）', 1.8);
      sfxDoor(true);
      logInfo('door', '万能钥匙开锁（消耗 1 把）');
      return true;
    }
    setMsg('门锁着 · 需要万能钥匙', 1.8);
    return false;
  }
  if (d.want){
    if (playerInDoor(d)){ setMsg('站在门里 · 关不了', 1.2); return false; }
    d.want = 0;
    setMsg('关门', 1.0);
  } else {
    d.want = 1;
    setMsg('开门', 1.0);
  }
  d.snd = d.open > 0.5;          /* 让下一帧的开关音按真实状态补一次 */
  /* 开关音按门框中心做声像（toggleDoor 里没有 doorUpdate 那两个 cx/cy，这里自己算） */
  sfxDoor(d.want === 1,
          (d.fx != null ? d.fx : d.x) + (d.fw || d.w) / 2,
          (d.fy != null ? d.fy : d.y) + (d.fh || d.h) / 2);
  return true;
}

/* 沿弹道找第一扇**门板**（开着关着都算）：返回穿门点。
   门板会转，所以不能拿 AABB 去撞 —— 把射线转进门板局部坐标，再和
   [-th/2, th/2] × [0, len] 求交，任何开合角度都准。开着的时候子弹一样会撞上门板。 */
function doorAlongRay(x, y, ang, maxLen){
  if (!doors.length) return null;
  const dx = Math.cos(ang), dy = Math.sin(ang);
  let best = null;
  for (const d of doors){
    if (d.broken) continue;
    if (!d.swing){                                          /* 老滑门：整块矩形在就挡，滑开就通 */
      if (!doorSolid(d)) continue;
      const t = rayEnter(x, y, dx, dy, d, maxLen);
      if (t < 0 || t > maxLen) continue;
      if (!best || t < best.t) best = { d: d, t: t, x: x + dx * t, y: y + dy * t };
      continue;
    }
    const th = d.th || 18, len = d.len || (d.fh - 2);
    if (len <= 2) continue;
    const a = (d.open || 0) * Math.PI / 2;                 /* 门板转过的角度 */
    const ca = Math.cos(a), sa = Math.sin(a);
    const hx = d.hx != null ? d.hx : d.fx + d.fw * 0.5;
    const hy = d.hy != null ? d.hy : d.fy + 1;
    const ox = x - hx, oy = y - hy;
    const lx = ox * ca - oy * sa, ly = ox * sa + oy * ca;  /* 世界 → 门板局部 */
    const ldx = dx * ca - dy * sa, ldy = dx * sa + dy * ca;
    let t0 = 0, t1 = maxLen;
    if (Math.abs(ldx) < 1e-9){ if (lx < -th / 2 || lx > th / 2) continue; }
    else {
      let a0 = (-th / 2 - lx) / ldx, a1 = (th / 2 - lx) / ldx;
      if (a0 > a1){ const s = a0; a0 = a1; a1 = s; }
      if (a0 > t0) t0 = a0;
      if (a1 < t1) t1 = a1;
      if (t0 > t1) continue;
    }
    if (Math.abs(ldy) < 1e-9){ if (ly < 0 || ly > len) continue; }
    else {
      let b0 = (0 - ly) / ldy, b1 = (len - ly) / ldy;
      if (b0 > b1){ const s = b0; b0 = b1; b1 = s; }
      if (b0 > t0) t0 = b0;
      if (b1 < t1) t1 = b1;
      if (t0 > t1) continue;
    }
    if (t0 < 0 || t0 > maxLen) continue;
    if (!best || t0 < best.t) best = { d: d, t: t0, x: x + dx * t0, y: y + dy * t0 };
  }
  return best;
}

/* 子弹穿门：扣血 + 火花 + 在门板上留个弹孔，但不拦子弹 */
/* 火箭弹不穿门：撞上实心门板就地引爆（开着的门照常飞过去）。
   子弹是"穿门扣血"，火箭弹是"炸门"，两套分开走，别混。 */
function rocketDoorHit(b){
  if (!doors.length) return false;
  const ang = Math.atan2(b.y - b.py, b.x - b.px);
  const len = Math.max(4, Math.hypot(b.x - b.px, b.y - b.py));
  const hit = doorAlongRay(b.px, b.py, ang, len);
  if (!hit) return false;
  rocketBlast(hit.x, hit.y, b.by);
  /* 直击：按门血量给伤害，保证"一发轰烂"（平开门 560 血，写死 240 根本打不烂） */
  const _dhp = hit.d.maxHp || 220;
  damageDoor(hit.d, Math.max(400, Math.round(_dhp * 1.4)), hit.x, hit.y, ang, false);
  return true;
}

function doorHitAlongShot(b){
  if (!doors.length) return;
  const ang = Math.atan2(b.y - b.py, b.x - b.px);
  const dist = Math.hypot(b.x - b.px, b.y - b.py);
  const hit = doorAlongRay(b.px, b.py, ang, Math.max(4, dist));
  if (hit) damageDoor(hit.d, (b.dmg || 10), hit.x, hit.y, ang, true);
}

/* 穿门的那一下：火星往两边甩 + 白闪 + 弹孔处留一圈亮边。
   （以前只是叫 impactWallFx，可门不在墙表里，wallAtPoint 查不到 → 出的是土灰，看着像"无视"） */
function doorPierceFx(x, y, ang, metal){
  const wood = !metal;
  for (let i = 0; i < (wood ? 6 : 10); i++){
    const a = ang + fxRand(-1.1, 1.1);
    spawnPart(x, y, a, fxRand(wood ? 110 : 180, wood ? 380 : 620), fxRand(0.10, 0.26),
              wood ? 'chip' : 'mspark', fxRand(1.0, 2.2));
  }
  for (let i = 0; i < 4; i++){                       /* 穿过去那一侧：碎屑跟着走 */
    const a = ang + fxRand(-0.6, 0.6);
    spawnPart(x, y, a, fxRand(90, 260), fxRand(0.16, 0.34), 'chip', fxRand(0.9, 1.8));
  }
  if (!wood) for (let i = 0; i < 5; i++){            /* 铁门：穿点再补一圈小火星 */
    const a = fxRand(0, TAU);
    spawnPart(x, y, a, fxRand(60, 200), fxRand(0.08, 0.2), 'mspark', fxRand(0.8, 1.5));
  }
  spawnPart(x, y, 0, 0, wood ? 0.07 : 0.09, 'flash', wood ? 6 : 8);
  spawnPart(x, y, 0, 0, 0.22, 'ring', wood ? 7 : 9);
  sfxDoorPierce(x, y, !wood);                        /* 木头"噗"、铁"叮"，不再用撞墙那套 */
}

function damageDoor(d, dmg, hx, hy, ang, pierce){
  if (!d || d.broken) return;
  d.hp -= dmg;
  d.hitT = 0.14;
  const px2 = hx != null ? hx : (d.x + d.w / 2);
  const py2 = hy != null ? hy : (d.y + d.h / 2);
  const a = ang != null ? ang
          : Math.atan2(py2 - (d.y + d.h / 2), px2 - (d.x + d.w / 2));
  if (pierce){
    /* 弹孔：记在世界坐标，画的时候再转回门板的局部坐标，门转孔跟着转 */
    if (!d.holes) d.holes = [];
    d.holes.push({ x: px2, y: py2, r: 0.8 + fxRand(0, 0.9), t: px2 });
    if (d.holes.length > 12) d.holes.shift();
    d.pierceT = 0.20;
    doorPierceFx(px2, py2, a, d.skin !== 'wood' && d.skin !== 'rust');
  } else {
    impactWallFx(px2, py2, a + Math.PI);
  }
  if (d.hp <= 0) breakDoor(d, a);
}

function breakDoor(d, ang){
  if (d.broken) return;
  d.broken = true; d.hp = 0; d.want = 1;
  d.open = Math.max(d.open, 0.0);        /* 开的过程交给 updateDoors，别瞬移 */
  pushDecal(d.x, d.y, d.w, d.h, 'metal');
  for (let i = 0; i < 16; i++){
    const a = (ang || 0) + fxRand(-1.2, 1.2), sp = fxRand(50, 210);
    brkChunks.push({x: d.x + d.w / 2 + fxRand(-d.w / 3, d.w / 3),
                    y: d.y + d.h / 2 + fxRand(-d.h / 3, d.h / 3),
                    vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
                    s: fxRand(1.6, 3.6), rot: fxRand(0, TAU), vr: fxRand(-12, 12),
                    t: 0, dur: fxRand(0.5, 0.9), big: false});
  }
  brkShake = Math.max(brkShake, 0.22);
  sfxCrack(true);
  setMsg('门被打烂了', 1.5);
  logInfo('door', '门被打碎');
}

/* E 键要干的活里，谁离得最近就干谁：箱子 / 门 / 地上的东西 */
/* 目标离"准星方向"有多正：1 = 正对着，0 = 在侧后方 */
function aimDotTo(o){
  if (!o || !player || !Number.isFinite(player.aim)) return 0;
  const cx = o.x + (o.w || 0) / 2, cy = o.y + (o.h || 0) / 2;
  const dx = cx - player.x, dy = cy - player.y;
  const l = Math.hypot(dx, dy) || 1;
  const dot = (Math.cos(player.aim) * dx + Math.sin(player.aim) * dy) / l;
  return dot > 0 ? dot : 0;
}
function nearestInteract(){
  if (!player) return null;
  const cand = [];
  const c = crateNear();
  if (c) cand.push({ k:'crate', o:c, d: distToRect(player.x, player.y, c) });
  const pp = (typeof pileNear === 'function') ? pileNear() : null;
  if (pp) cand.push({ k:'pile', o:pp, d: distToRect(player.x, player.y, pp) });
  const d0 = doorNear();
  if (d0) cand.push({ k:'door', o:d0, d: distToRect(player.x, player.y, d0) });
  if (!cand.length) return null;
  /* m35945：以"玩家鼠标对着的方向"为准。
     以前是"门一律优先 24px"，站着面对物资堆、旁边半米处有门时，按 E 永远开门、搜不到东西。
     现在按"距离 − 朝向加成"打分：正对着的目标等价于近 44px；门再保留 12px 的兜底偏置
     （门框常被杂物堆挤住，用户 m16699-6 的老问题不能回退）。 */
  let best = null, bs = Infinity;
  for (const it of cand){
    const dot = aimDotTo(it.o);
    const s = it.d - dot * 44 - (it.k === 'door' ? 12 : 0);
    if (s < bs){ bs = s; best = it; }
  }
  return best;
}

function crateNear(){
  if (!player || typeof LOOT_CRATE === 'undefined') return null;
  const L = cur();
  if (!L || !L.walls) return null;
  let best = null, bd = LOOT_CRATE.range;
  for (const w of L.walls){
    if (!w.loot || w.dead || w.opened) continue;
    const d = distToRect(player.x, player.y, w);
    if (d <= bd){ bd = d; best = w; }
  }
  return best;
}

/* ============================================================
   物资堆（第 28 轮）：箱子的下位变体
   ------------------------------------------------------------
   和箱子的差别有三条，别的都共用：
   1) 不在 L.walls 里 —— 不挡人、不挡子弹，走自己的 piles[]；
      所以子弹不会自己撞上它，得在弹道里补一次"擦过就掉血"（pileHitAlongShot）。
   2) 能搜好几次（2~6，每堆刷新时随机），**每搜一次必掉 1 件**；
      次数用完后还能按 E，但只给提示不掉东西。
   3) 打爆掉 0~2 件，可能一件都没有；搜光了再打爆一定不掉。
   参数全在 data/lootcrate.js 的 LOOT_CRATE.pile，颜色在 LOOT_SKIN.pile。
   ============================================================ */
let piles = [];

function pileCfg(){
  return (typeof LOOT_CRATE !== 'undefined' && LOOT_CRATE.pile) ? LOOT_CRATE.pile : null;
}

/* 这一堆能搜几次：每次刷新随机 2~6，不是固定值。
   注意这里**不能**用 fxRand —— 关卡初始化时多抽几个随机数，会把后面
   敌人巡逻/掉落那一整条 RNG 序列整体错开，别的测试的确定性就没了。
   所以撒堆子一律走 covHash（按坐标算，稳定、不吃全局序列）。 */
function rollPileUses(seed){
  const P = pileCfg();
  if (!P) return 3;
  const r = covHash((seed | 0) + 17, 7);
  return P.usesMin + Math.floor(r * ((P.usesMax - P.usesMin) + 0.999));
}

/* 一堆：从清单展开（尺寸/名字/血都走 COVER_DEF.lootpile），再挂上"还能搜几次" */
function makePile(x, y){
  const b = coverMake('lootpile', { x: x, y: y });
  b.pile = true;
  b.dead = false;
  b.maxHp = b.hp;
  b.hp0 = b.hp;
  b.seed = ((x | 0) * 7 + (y | 0) * 13) | 0;
  b.uses = rollPileUses(b.seed);
  b.uses0 = b.uses;
  b.hitT = 0;
  return b;
}

function pileNear(){
  if (!player || !piles.length) return null;
  const P = pileCfg();
  if (!P) return null;
  let best = null, bd = P.range;
  for (const p of piles){
    if (p.dead) continue;
    const d = distToRect(player.x, player.y, p);
    if (d <= bd){ bd = d; best = p; }
  }
  return best;
}

/* 随机撒：只在关卡写了 pileSpawn 的时候刷（现在只有测试区），
   落点避开墙 / 地上的东西 / 出生点 / 撤离点 / 门 / 别的堆。 */
function initPiles(L){
  piles = [];
  /* 关卡里显式写了 piles:[{x,y}] 就按坐标摆（测试区讲解排面用），不再随机撒点 */
  if (L && L.piles && L.piles.length){
    for (const p of L.piles) piles.push(makePile(p.x, p.y));
    return;
  }
  if (!L || !L.pileSpawn) return;
  const cfg = L.pileSpawn;
  const rg = Array.isArray(cfg.count) ? cfg.count : [cfg.count || 0, cfg.count || 0];
  /* 想刷几堆也用坐标哈希定，别动全局 RNG（原因见 rollPileUses 上面那段注释） */
  const wseed = ((L.w | 0) * 31 + (L.h | 0) * 17) | 0;
  const want = rg[0] + Math.floor(covHash(wseed, 23) * ((rg[1] - rg[0]) + 0.999));
  if (want <= 0) return;
  const margin = (cfg.margin != null) ? cfg.margin : 70;
  const st = L.start || { x: L.w / 2, y: L.h / 2 };
  const ex = L.extract || null;
  const cand = [];
  /* 先把墙粗栅格化一遍：6000² 的地图上 3 万个候选点 × 9 次 wallAtPoint（每次还扫全部 438 面墙）
     进关那一下要 200 多毫秒。粗格查表之后只剩真正入选的那几十个点做精确判定。
     老关卡墙少、图小，这段照旧是几毫秒。 */
  const CELL = 34;
  const cols = Math.ceil(L.w / CELL), rows = Math.ceil(L.h / CELL);
  const blk = new Uint8Array(cols * rows);
  const WPAD = 22;
  for (const w of L.walls){
    if (!w) continue;
    const x0 = Math.max(0, Math.floor((w.x - WPAD) / CELL));
    const x1 = Math.min(cols - 1, Math.floor((w.x + w.w + WPAD) / CELL));
    const y0 = Math.max(0, Math.floor((w.y - WPAD) / CELL));
    const y1 = Math.min(rows - 1, Math.floor((w.y + w.h + WPAD) / CELL));
    for (let yy = y0; yy <= y1; yy++){
      const row = yy * cols;
      for (let xx = x0; xx <= x1; xx++) blk[row + xx] = 1;
    }
  }
  const coarseBlocked = (x, y) => {
    const c = Math.floor(x / CELL), r2 = Math.floor(y / CELL);
    if (c < 0 || r2 < 0 || c >= cols || r2 >= rows) return true;
    return blk[r2 * cols + c] === 1;
  };
  for (let y = margin; y < L.h - margin; y += 34){
    for (let x = margin; x < L.w - margin; x += 34){
      const hs = ((x | 0) * 7919 + (y | 0) * 104729) | 0;
      const cx = x + (covHash(hs, 3) - 0.5) * 20, cy = y + (covHash(hs, 5) - 0.5) * 20;
      if (cx < 40 || cy < 40 || cx > L.w - 40 || cy > L.h - 40) continue;
      /* 离墙远一点：堆子要"靠墙堆"才自然，但不能压进墙里 */
      if (coarseBlocked(cx, cy)) continue;
      if (Math.hypot(cx - st.x, cy - st.y) < 110) continue;
      if (ex && cx > ex.x - 90 && cx < ex.x + ex.w + 90 && cy > ex.y - 90 && cy < ex.y + ex.h + 90) continue;
      let near = false;
      for (const l of loots) if (!l.taken && Math.hypot(l.x - cx, l.y - cy) < 62){ near = true; break; }
      if (near) continue;
      for (const d of doors) if (distToRect(cx, cy, d) < 56){ near = true; break; }
      if (near) continue;
      for (const p of piles) if (Math.hypot(p.x + p.w / 2 - cx, p.y + p.h / 2 - cy) < 130){ near = true; break; }
      if (near) continue;
      cand.push({ x: Math.round(cx), y: Math.round(cy), s: covHash(hs, 41) });
    }
  }
  /* 按哈希排个序再取前 want 个：位置每局不一样，但不用碰全局 RNG */
  cand.sort((a, b) => a.s - b.s);
  /* 精确判定只对真正入选的那几十个点做：9 个探针 × 全部墙，几十次可以忽略 */
  let _added = 0;
  for (let i = 0; i < cand.length && _added < want; i++){
    const c2 = cand[i];
    let blocked = false;
    for (const px of [c2.x - 20, c2.x, c2.x + 20]){
      for (const py of [c2.y - 18, c2.y, c2.y + 18]) if (wallAtPoint(px, py)){ blocked = true; break; }
      if (blocked) break;
    }
    if (blocked) continue;
    piles.push(makePile(c2.x, c2.y));
    _added++;
  }
}

/* ============================================================
   铁丝网（第 32 轮）：能走进去，但走不动 + 必上 I 级流血；
   子弹打不坏（穿过去），只有爆炸能炸开；炸开之后纯装饰。
   —— 它**不进 L.walls**，不挡人、不挡子弹、不参与寻路，
      和物资堆一个道理：进 nav 就会把 AI 卡死（第 31 轮门板的前车之鉴）。
   ============================================================ */
let wires = [];
let wireBleedT = 0;                 /* 玩家在网里时，离上次刷新流血还有多久 */

function wireCfg(){
  return (typeof WIRE_DEF !== 'undefined') ? WIRE_DEF : null;
}

function makeWire(o){
  const D = wireCfg();
  const rot = !!o.rot;
  const w = o.w || (rot ? D.sz[1] : D.sz[0]);
  const h = o.h || (rot ? D.sz[0] : D.sz[1]);
  return {
    x: o.x, y: o.y, w: w, h: h, rot: rot,
    hp: D.hp, maxHp: D.hp, dead: false, hitT: 0,
    seed: (((o.x | 0) * 13 + (o.y | 0) * 7) | 0)
  };
}

function initWires(L){
  wires = [];
  wireBleedT = 0;
  const D = wireCfg();
  if (!D || !L || !Array.isArray(L.wires)) return;
  for (const o of L.wires) if (o) wires.push(makeWire(o));
}

/* 点是不是在网里（pad：把网算大一点，人贴着边就算划到） */
function wireAt(x, y, pad){
  const p = pad || 0;
  for (const w of wires){
    if (w.dead) continue;
    if (x > w.x - p && x < w.x + w.w + p && y > w.y - p && y < w.y + w.h + p) return w;
  }
  return null;
}

/* 爆炸撕网：只有爆炸会走到这里（子弹不进这个函数） */
function damageWire(w, dmg, hx, hy){
  const D = wireCfg();
  if (!w || w.dead || !D) return;
  w.hp -= dmg;
  w.hitT = 0.35;
  if (w.hp > 0) return;
  w.dead = true;
  setMsg(D.breakMsg, 1.6);
  /* 断口：几颗铁屑 + 一小段灰烟，不搞大爆炸（它是被炸开的，不是自己炸） */
  for (let i = 0; i < 8; i++){
    const a = Math.random() * TAU, s = 40 + Math.random() * 90;
    spawnPart(hx || w.x + w.w / 2, hy || w.y + w.h / 2,
              Math.cos(a) * s, Math.sin(a) * s, 0.30, 'chip', 1.6, WIRE_SKIN.wire);
  }
  pushDecal(w.x, w.y, w.w, w.h, 'metal');
}

/* 炸开之后那一小段"破网"：不减速、不流血，只是看着像被扯断了。
   画成几团被压扁的圈 + 几根弯掉的铁丝，别只画几根小黑线（那样看不出是网）。 */
function drawWireBroken(w){
  const S = WIRE_SKIN;
  ctx.save();
  const horiz = !w.rot;
  const n = 5;
  for (let i = 0; i < n; i++){
    const t = (i + 0.5) / n;
    const px = horiz ? (w.x + w.w * t) : (w.x + w.w * (0.35 + covHash(w.seed + i * 17, 3) * 0.3));
    const py = horiz ? (w.y + w.h * (0.35 + covHash(w.seed + i * 19, 5) * 0.3)) : (w.y + w.h * t);
    /* 压扁的圈：被踩塌的一团 */
    const rx = 3.6 + covHash(w.seed + i * 23, 7) * 1.8;
    const ry = 1.6 + covHash(w.seed + i * 29, 11) * 0.8;
    ctx.beginPath();
    if (horiz) ctx.ellipse(px, py, rx, ry, 0, 0, TAU);
    else ctx.ellipse(px, py, ry, rx, 0, 0, TAU);
    ctx.strokeStyle = S.torn;
    ctx.lineWidth = 1.1;
    ctx.globalAlpha = 0.9;
    ctx.stroke();
    /* 一头翘起来的断丝 */
    const a = covHash(w.seed + i * 31, 13) * TAU;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px + Math.cos(a) * (3 + covHash(w.seed + i * 37, 17) * 5),
               py + Math.sin(a) * (3 + covHash(w.seed + i * 41, 19) * 5));
    ctx.strokeStyle = S.rust;
    ctx.lineWidth = 0.9;
    ctx.globalAlpha = 0.7;
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}

function drawWires(){
  if (!wires.length) return;
  const S = WIRE_SKIN;
  for (const w of wires){
    if (w.dead){ drawWireBroken(w); continue; }
    const horiz = !w.rot;
    const cx = w.x + w.w / 2, cy = w.y + w.h / 2;
    const L = horiz ? w.w : w.h;             /* 长边 */
    const T = horiz ? w.h : w.w;             /* 短边（网的宽度） */
    ctx.save();
    /* 贴地的一层暗影，让网"浮"在地上而不是画在墙上 */
    ctx.fillStyle = 'rgba(0,0,0,0.26)';
    ctx.fillRect(w.x + 1.5, w.y + 2, w.w, w.h);
    /* 两根桩子（长边两头） */
    const pw = Math.max(4, T * 0.42);
    const postAt = (t2) => {
      if (horiz){
        ctx.fillStyle = S.post;
        ctx.fillRect(w.x + t2 - pw / 2, cy - pw / 2, pw, pw);
        ctx.fillStyle = S.postHi;
        ctx.fillRect(w.x + t2 - pw / 2, cy - pw / 2, pw, Math.max(1, pw * 0.34));
      } else {
        ctx.fillStyle = S.post;
        ctx.fillRect(cx - pw / 2, w.y + t2 - pw / 2, pw, pw);
        ctx.fillStyle = S.postHi;
        ctx.fillRect(cx - pw / 2, w.y + t2 - pw / 2, Math.max(1, pw * 0.34), pw);
      }
    };
    postAt(2); postAt(L - 2);
    /* 铁丝：几条来回折的线 + 一串小圈。折线给"绷着"，小圈给"一圈圈缠着" */
    const strands = 4;
    for (let s = 0; s < strands; s++){
      const off = (s / (strands - 1) - 0.5) * (T * 0.52);
      ctx.beginPath();
      for (let i = 0; i <= 13; i++){
        const t2 = 2 + (L - 4) * (i / 13);
        const zig = (i % 2 ? 1 : -1) * (T * 0.10);
        const px = horiz ? (w.x + t2) : (cx + off + zig);
        const py = horiz ? (cy + off + zig) : (w.y + t2);
        if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.strokeStyle = (s === 2) ? S.wireHi : S.wire;
      ctx.lineWidth = (s === 2) ? 1.4 : 1;
      ctx.stroke();
    }
    /* 一圈圈的缠绕：沿长边排一串压扁的小圈，这才是铁丝网的样子 */
    const coils = Math.max(3, Math.round(L / 15));
    ctx.strokeStyle = S.wire;
    ctx.lineWidth = 1;
    ctx.globalAlpha = 0.75;
    for (let i = 0; i < coils; i++){
      const t2 = 5 + (L - 10) * ((i + 0.5) / coils);
      const rx = 3.4, ry = T * 0.34;
      ctx.beginPath();
      if (horiz) ctx.ellipse(w.x + t2, cy, rx, ry, 0, 0, TAU);
      else ctx.ellipse(cx, w.y + t2, ry, rx, 0, 0, TAU);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    /* 倒刺：沿长边均匀撒的小叉 */
    ctx.strokeStyle = S.barb;
    ctx.lineWidth = 1;
    const barbs = Math.max(4, Math.round(L / 16));
    for (let i = 0; i < barbs; i++){
      const t2 = (i + 0.5) / barbs;
      const bx = horiz ? (w.x + 3 + (w.w - 6) * t2) : (cx + (covHash(w.seed + i * 31, 3) - 0.5) * T * 0.5);
      const by = horiz ? (cy + (covHash(w.seed + i * 37, 5) - 0.5) * T * 0.5) : (w.y + 3 + (w.h - 6) * t2);
      ctx.beginPath();
      ctx.moveTo(bx - 2, by - 2); ctx.lineTo(bx + 2, by + 2);
      ctx.moveTo(bx + 2, by - 2); ctx.lineTo(bx - 2, by + 2);
      ctx.stroke();
    }
    /* 锈迹：两三处暗红的小斑，别让它像崭新的不锈钢 */
    ctx.fillStyle = S.rust;
    for (let i = 0; i < 3; i++){
      const t2 = covHash(w.seed + i * 41, 13);
      const px = horiz ? (w.x + 4 + (w.w - 8) * t2) : (cx + (covHash(w.seed + i * 43, 17) - 0.5) * T * 0.5);
      const py = horiz ? (cy + (covHash(w.seed + i * 47, 19) - 0.5) * T * 0.5) : (w.y + 4 + (w.h - 8) * t2);
      ctx.globalAlpha = 0.45;
      ctx.beginPath(); ctx.arc(px, py, 1.4, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1;
    }
    /* 挨了爆炸之后、还没断的那一下：闪白 */
    if (w.hitT > 0){
      ctx.fillStyle = 'rgba(255,240,220,' + (0.25 * (w.hitT / 0.35)).toFixed(3) + ')';
      ctx.fillRect(w.x, w.y, w.w, w.h);
    }
    ctx.restore();
  }
}

/* 每帧：谁站在网里、要流血 / 掉血 / 减速。
   减速不在移动代码里改（那样得改十几处），而是打一个 inWire 标记，
   玩家的 sp 与敌人的 eMoveK() 各乘一次 —— 两个地方，收得住。 */
function updateWires(dt){
  const D = wireCfg();
  if (!D) return;
  for (const w of wires) if (w.hitT > 0) w.hitT = Math.max(0, w.hitT - dt);
  /* ---- 玩家 ---- */
  if (player && player.hp > 0){
    const inside = wireAt(player.x, player.y, 2);
    player.inWire = !!inside;
    if (inside){
      if (!player.wasInWire){
        stBleedAdd(D.bleedLv);
        setMsg(D.enterMsg, 1.8);
        spillBlood(player.x, player.y, 5.5);
        wireBleedT = D.refreshT;
      } else {
        wireBleedT -= dt;
        if (wireBleedT <= 0){ wireBleedT = D.refreshT; stBleedAdd(D.bleedLv); }
      }
    } else {
      wireBleedT = 0;
    }
    player.wasInWire = !!inside;
  }
  /* ---- 敌人 / 猎人：没有那套流血状态，直接扣血 ---- */
  const hurt = (e) => {
    if (!e || e.dead) return;
    const inside = wireAt(e.x, e.y, 2);
    e.inWire = !!inside;
    if (!inside){ e.wasInWire = false; return; }
    if (!e.wasInWire){ e.wasInWire = true; spillBlood(e.x, e.y, 4.0); }
    e.hp -= D.enemyDps * dt;
    if (e.hp <= 0 && typeof killTestEnemy === 'function') killTestEnemy(e);
  };
  for (const e of enemies) hurt(e);
  for (const h of hunters) hurt(h);
}

/* ============================================================
   装饰物（第 36 轮）：扫把 / 饮料瓶 / 瓦罐 / 桌子 / 椅子
   ------------------------------------------------------------
   1) 清单和配色在 data/decor.js（DECOR_DEF / DECOR_SKIN），这里只管摆和画。
   2) 挡人的（桌子 / 瓦罐 / 椅子）**同时塞进 L.walls**，走的是墙那套
      碰撞与子弹判定，不用另写一套；但它们是"会变的墙"（要画伪 3D、
      椅子还能坐），所以 isDynamicWall() 认它们，静态层不烘。
   3) 不挡人的（扫把 / 瓶子）只在 decors[] 里，纯画。
   4) 椅子能坐：按 E 坐下，动一下或再按 E 起身。
   ============================================================ */
let decors = [];

function decorCfg(t){
  return (typeof DECOR_DEF !== 'undefined' && DECOR_DEF[t]) || null;
}

function makeDecor(o){
  const def = decorCfg(o.t);
  if (!def) return null;
  return {
    t: o.t, x: o.x, y: o.y,
    w: o.w || def.sz[0], h: o.h || def.sz[1],
    hi: (o.hi != null) ? o.hi : def.hi,
    solid: (o.solid != null) ? !!o.solid : !!def.solid,
    sit: !!def.sit,
    foot: (def.foot != null) ? def.foot : 1,     /* 碰撞箱只占下半截 */
    push: !!def.push && (o.push !== false),      /* 能不能被推着走 */
    topple: !!def.topple,                        /* 一推就倒（椅子）；倒了不能再坐 */
    toppled: false, pushAcc: 0,
    blastOnly: !!def.blastOnly,                  /* 只吃爆炸：子弹判定整个跳过 */
    bulletPass: !!def.bulletPass,                /* 子弹能穿过去 */
    nodecal: !!def.nodecal,                      /* 碎了不留残渣地毯 */
    mass: def.mass || 1,
    pvx: 0, pvy: 0, tilt: 0, tiltDir: 0, tiltTarget: 0,
    hp: def.hp || 0,
    mat: def.mat || 'wood',
    hitT: 0,
    seed: ((o.x * 13 + o.y * 7) | 0)
  };
}

function initDecors(L){
  decors = [];
  if (!L) return;
  const src = L.decors || [];
  for (const o of src){
    /* 花丛模板：一行 {t:'bed', kind:'rose'} 铺成一丛（第 62 轮） */
    if (o && o.t === 'bed' && typeof FLOWER_BEDS !== 'undefined' && FLOWER_BEDS[o.kind]){
      for (const it of FLOWER_BEDS[o.kind]){
        const dd = makeDecor({ t: it.t, x: o.x + (it.dx || 0), y: o.y + (it.dy || 0) });
        if (dd) decors.push(dd);
      }
      continue;
    }
    const d = makeDecor(o);
    if (d) decors.push(d);
  }
  /* 挡人的：塞进墙表，走路 / 子弹自动被挡住；有血的还要能被打碎。
     碰撞箱只取"下半截"（foot 比例）—— 上面那半是视觉上的体积，人不该被它顶住。 */
  for (const d of decors){
    if (d.solid) continue;
    /* 不挡路但有血的（瓦罐 / 垃圾堆 / 木板 / 花 / 玻璃瓶）：也要能被打碎 / 炸碎，
       给它一张不挂进墙表的"墙代理"。以前这里只给 push 的开，导致"能炸碎"的地面杂物
       根本没有 _w，rocketBlast 那一圈直接把它们跳过去了。 */
    if (d.hp > 0) d._w = decorWallOf(d);
  }
  for (const d of decors){
    if (!d.solid) continue;
    const hp0 = d.hp || 0;
    const w = decorWallOf(d);
    L.walls.push(w);
    wallGeomVer++;
    d._w = w;
  }
  try { staticInvalidate(); } catch (e){ if (typeof reportErr === 'function') reportErr('30-thermal', e); }
}

/* ============================================================
   屋顶（第 46 轮）
   ------------------------------------------------------------
   一层"盖子"：画在所有单位之后、光照之前。

   · 关卡里用 `roofs:[{x,y,w,h,mat}]` 写，进了屋就整块淡出
   · 淡出用 ROOF_FADE（数据在 data/roofs.js，用户指定 0.2 秒）
   · **不进 L.walls**：不挡人、不挡子弹、不挡视线
     （室内敌人的视野因此完全不受屋顶影响，这是需求里明确要的）
   · **不进静态图层**：它的透明度每帧都在变，烘进去就再也改不动
   ============================================================ */
let roofs = [];

function roofCfg(mat){
  const D = (typeof ROOF_DEF !== 'undefined') ? ROOF_DEF : null;
  if (!D) return null;
  return D[mat] || D.tile;
}

function makeRoof(o){
  if (!o) return null;
  const c = roofCfg(o.mat);
  if (!c) return null;
  return {
    x: o.x, y: o.y, w: o.w, h: o.h,
    mat: o.mat || 'tile',
    skin: c,
    a: 1,          /* 当前不透明度：1 = 全盖上，0 = 完全透明 */
    target: 1,     /* 目标值：有人在屋里 → 0 */
    inside: false,
    building: (o.building === undefined ? undefined : (o.building | 0)),
    seed: ((o.x * 17 + o.y * 31) | 0)
  };
}

/* ---------- 房间（一栋房子里可以有好几间：客厅 / 厨房 / 厕所…） ----------
   rooms 只描述"地板的范围"，墙还是普通的 walls，开口（门）由墙上的缺口自动认。
   房子 = 同一个 building 编号的一组房间 + 盖在它们上面的屋顶。 */
let rooms = [];

function makeRoom(o, i){
  if (!o) return null;
  return {
    x: o.x, y: o.y, w: o.w, h: o.h,
    building: (o.building === undefined ? 0 : (o.building | 0)),
    name: o.name || ('room' + i),
    id: o.id || ('r' + i)
  };
}

/* 房间查找索引：200px 一格，房间写进它盖住的每个格子。
   灰暗/热成像对每个敌人每帧都要问两次"这人在哪间房"，线性扫 400 多间太贵。 */
const ROOM_BUCKET = 200;
let roomIdx = null;
function roomIdxBuild(){
  roomIdx = new Map();
  for (const r of rooms){
    const x0 = Math.floor(r.x / ROOM_BUCKET), x1 = Math.floor((r.x + r.w) / ROOM_BUCKET);
    const y0 = Math.floor(r.y / ROOM_BUCKET), y1 = Math.floor((r.y + r.h) / ROOM_BUCKET);
    for (let gx = x0; gx <= x1; gx++) for (let gy = y0; gy <= y1; gy++){
      const k = gx + ',' + gy;
      let arr = roomIdx.get(k);
      if (!arr){ arr = []; roomIdx.set(k, arr); }
      arr.push(r);
    }
  }
}
function initRooms(L){
  rooms = [];
  const src = (L && L.rooms) || [];
  for (let i = 0; i < src.length; i++){
    const r = makeRoom(src[i], i);
    if (r) rooms.push(r);
  }
  roomIdxBuild();
}

function roomHasPoint(r, x, y){
  return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h;
}

function roomAt(x, y){
  if (roomIdx){
    const arr = roomIdx.get(Math.floor(x / ROOM_BUCKET) + ',' + Math.floor(y / ROOM_BUCKET));
    if (!arr) return null;
    for (const r of arr) if (roomHasPoint(r, x, y)) return r;
    return null;
  }
  for (const r of rooms) if (roomHasPoint(r, x, y)) return r;
  return null;
}

/* 谁在这间房里：玩家、敌人、猎人、队友 */
function roomOccupant(r){
  if (!r) return null;
  if (player && roomHasPoint(r, player.x, player.y)) return player;
  if (enemies){ for (const e of enemies){ if (!e || e.dead) continue; if (roomHasPoint(r, e.x, e.y)) return e; } }
  if (hunters){ for (const e of hunters){ if (!e || e.dead) continue; if (roomHasPoint(r, e.x, e.y)) return e; } }
  if (typeof companions !== 'undefined' && companions){ for (const e of companions){ if (!e || e.dead) continue; if (roomHasPoint(r, e.x, e.y)) return e; } }
  return null;
}

function buildingRooms(b){
  const out = [];
  for (const r of rooms) if (r.building === (b | 0)) out.push(r);
  return out;
}

function buildingOccupied(b){
  for (const r of rooms) if (r.building === (b | 0) && roomOccupant(r)) return true;
  return false;
}

/* 站在屋里：别的房间压一层灰暗（自己那间不压）。
   屋子外面不压 —— 外面的屋顶本来就是盖着的。 */
function paintRoomShade(g){
  const C = g || ctx;
  if (!rooms.length || !player) return 0;
  /* 第 60 轮：站在屋外时，所有房间都要压暗 —— 否则从外面看进去，
     屋里跟自己脚下一样亮，"屋子"就没有体量感了。 */
  const my = roomAt(player.x, player.y);
  const col = (typeof ROOM_DIM === 'string') ? ROOM_DIM : 'rgba(11,13,17,0.52)';
  let n = 0;
  /* 边界模糊一点：门洞是通的，硬切一条直线会像"看不见的墙" */
  let prevFilter = null;
  try { prevFilter = C.filter; C.filter = 'blur(18px)'; } catch(e){ prevFilter = null; }
  for (const r of rooms){
    /* 第 61 轮：除了自己站的这一间，其它房间一律压暗。
       以前这里按 building 过滤，结果"一进屋，屋外那些房子的房间全亮了"，
       观感像外面突然开灯。 */
    if (r === my) continue;
    if (r.fallback) continue;      /* 兜底房间只回答"人在不在屋里"，不参与压暗 */
    /* 只画看得见的那几间：filter 是 blur(18px)，每多画一个矩形就是一次整层模糊。
       随机图 14000² 有 470 多间房，不裁剪的话每帧白做四百多次模糊（实测掉到 28 帧）。 */
    if (typeof cullRect === 'function' && !cullRect(r.x - 16, r.y - 16, r.w + 32, r.h + 32, 60)) continue;
    C.fillStyle = col;
    /* 往外扩一圈再模糊：压暗的边缘落在墙带上，门洞那里是渐隐而不是一条直线 */
    C.fillRect(r.x - 16, r.y - 16, r.w + 32, r.h + 32);
    n++;
  }
  if (prevFilter !== null){
    try { C.filter = (prevFilter === 'none' ? 'none' : prevFilter); } catch (e){ if (typeof reportErr === 'function') reportErr('30-thermal', e); }
  }
  return n;
}

/* 第 50 轮：灰暗房间里的敌人不画身体 —— 只给个"声音"提示，进光锥才现形。
   为什么这样：灰暗只是压了一层颜色，敌人照样被画出来，等于"看一眼就知道那边有人"；
   而玩家又会被"他能看见我、我看不见他"糊弄。折中：看不见身体（不能拿他当靶子），
   但听得见动静（知道那边有活人，别把自己当隐身）。 */
function dimmedRoomAt(x, y){
  if (!rooms.length || !player) return null;
  const my = roomAt(player.x, player.y);
  const r = roomAt(x, y);
  if (!r || r.fallback || r === my) return null;
  return r;
}
function litByCone(x, y){
  if (!player) return false;
  const L = cur();
  const d = dist(player.x, player.y, x, y);
  if (d > seeRange(L)) return false;
  if (typeof smokeBlocks === 'function' && smokeBlocks(player.x, player.y, x, y)) return false;
  const aim = (typeof player.aim === 'number') ? player.aim : 0;
  const a = Math.atan2(y - player.y, x - player.x);
  const half = seeFov(L) * Math.PI / 360;
  let da = Math.atan2(Math.sin(a - aim), Math.cos(a - aim));
  if (Math.abs(da) > half) return false;
  return !losBlocked(player.x, player.y, x, y, false, true);   /* 玩家：木箱/桌子看得过去 */
}
/* 这个单位现在要不要"藏起来"（在别的房间的灰暗里、又没被光锥照到） */
function shadeCueHidden(u){
  if (!u || u.dead) return false;
  if (!dimmedRoomAt(u.x, u.y)) return false;
  if (litByCone(u.x, u.y)) return false;
  return true;
}

let shadeCueT = 0;
/* 画"那边有动静"：一圈很淡的声纹，越扩越淡。只报位置不报样子。 */
function drawShadeCues(){
  const list = enemies.concat(hunters);
  if (!list.length) return;
  shadeCueT += (typeof lastDt === 'number' && lastDt > 0) ? Math.min(lastDt, 0.1) : 0.016;
  let i = 0;
  for (const u of list){
    i++;
    if (!shadeCueHidden(u)) continue;
    if (typeof cullPt === 'function' && !cullPt(u.x, u.y, 90)) continue;
    const ph = (shadeCueT * 0.9 + i * 0.37) % 1;
    ctx.save();
    ctx.strokeStyle = 'rgba(226,214,190,0.85)';
    ctx.lineWidth = 1.1;
    ctx.globalAlpha = (1 - ph) * 0.30;
    ctx.beginPath(); ctx.arc(u.x, u.y, 3 + ph * 16, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 0.34;
    ctx.fillStyle = 'rgba(226,214,190,0.8)';
    ctx.beginPath(); ctx.arc(u.x, u.y, 1.3, 0, TAU); ctx.fill();
    ctx.restore();
  }
}

/* 直接画（测试 / 没有离屏图层时用）。正常渲染走 drawRoofs() 里的合成层，
   那样别的房间的灰暗才会跟屋顶一样被视野锥"照亮"。 */
function drawRoomShade(){ return paintRoomShade(ctx); }

function initRoofs(L){
  roofs = [];
  if (!L) return;
  const src = L.roofs || [];
  for (const o of src){
    const r = makeRoof(o);
    if (r) roofs.push(r);
  }
}

function roofHasPoint(r, x, y){
  return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h;
}

/* 谁在屋里：玩家、敌人、猎人（以及以后加的队友）。
   只要有一个在屋里，这块屋顶就该淡出 —— 不然队友被盖在下面看不见。 */
/* 屋顶矩形比墙外扩了一圈屋檐。站在墙外贴着墙根时，人其实还在屋顶矩形里，
   屋顶就开始淡出 —— 表现出来就是"屋顶边缘在羽化"。所以占位判定要往里收。 */
function roofInsideTest(r, x, y){
  const pad = Math.min(12, Math.max(6, Math.min(r.w, r.h) * 0.08));
  return x >= r.x + pad && x <= r.x + r.w - pad && y >= r.y + pad && y <= r.y + r.h - pad;
}
/* 门口的 [E] 提示：必须画在屋顶之后，否则被屋顶盖住看不见 */
function drawDoorHints(){
    if (doors.length && state === 'play'){
    let near = null, bestD = 190;
    for (const d of doors){
      const dd = dist(player.x, player.y, d.x + d.w/2, d.y + d.h/2);
      if (dd < bestD){ bestD = dd; near = d; }
    }
    if (near && !near.broken && (near.manual || doorSolid(near))){
      ctx.textAlign = 'center';
      ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
      if (near.manual){
        const canE = distToRect(player.x, player.y, near) <= doorCfg.range;
        if (canE){
          ctx.fillStyle = near.isLocked && !near.unlocked
            ? 'rgba(255,206,120,0.95)'
            : (THEME_LIGHT ? 'rgba(30,90,60,0.95)' : 'rgba(150,240,190,0.95)');
          ctx.fillText(near.isLocked && !near.unlocked
            ? (keyCount() > 0
                ? ('[' + keyLabel(BINDS.interact) + '] 用万能钥匙开锁')
                : '锁着 · 需要万能钥匙')
            : ('[' + keyLabel(BINDS.interact) + '] ' + (near.open > 0.5 ? '关门' : '开门')),
            near.x + near.w/2, near.y + near.h/2 - 26);
        }
      } else if (doorSolid(near)){
        ctx.fillStyle = THEME_LIGHT ? 'rgba(150,60,40,0.95)' : 'rgba(255,170,140,0.95)';
        ctx.fillText('没卡 · 等他们刷卡', near.x + near.w/2, near.y + near.h/2 - 26);
      }
    }
  }


}

function roofOccupant(r){
  if (!r) return null;
  if (player && roofInsideTest(r, player.x, player.y)) return player;
  if (enemies){
    for (const e of enemies){
      if (!e || e.dead) continue;
      if (roofInsideTest(r, e.x, e.y)) return e;
    }
  }
  if (hunters){
    for (const e of hunters){
      if (!e || e.dead) continue;
      if (roofInsideTest(r, e.x, e.y)) return e;
    }
  }
  if (typeof companions !== 'undefined' && companions){
    for (const e of companions){
      if (!e || e.dead) continue;
      if (roofInsideTest(r, e.x, e.y)) return e;
    }
  }
  return null;
}

function updateRoofs(dt){
  if (!roofs || !roofs.length) return;
  const fade = (typeof ROOF_FADE === 'number' && ROOF_FADE > 0) ? ROOF_FADE : 0.2;
  const step = Math.max(0, dt) / fade;
  /* 大图上一眼只能看见几栋楼，可"这栋楼里有没有人"要把全图 200 多号人筛一遍。
     离镜头两屏以外的屋顶根本不在画面上，直接按"没人"算，省掉整轮扫描。 */
  const _ccx = (typeof camX === 'number' ? camX : 0) + W / 2;
  const _ccy = (typeof camY === 'number' ? camY : 0) + H / 2;
  for (const r of roofs){
    if (r && r.w && (Math.abs(r.x + r.w / 2 - _ccx) > 2200 || Math.abs(r.y + r.h / 2 - _ccy) > 2200)){
      r.inside = false; r.target = 1;
      if (r.a < 1) r.a = Math.min(1, r.a + step);
      continue;
    }
    /* 有 rooms 的楼：整栋楼任意一间有人就淡出（不然进屋只露半张图）；
       没写 rooms 的老样机：还按屋顶矩形自己判断 */
    const house = (r.building === undefined) ? null : buildingRooms(r.building);
    const who = (house && house.length) ? (buildingOccupied(r.building) ? true : null) : roofOccupant(r);
    r.inside = !!who;
    r.target = who ? 0 : 1;
    if (r.a > r.target) r.a = Math.max(r.target, r.a - step);
    else if (r.a < r.target) r.a = Math.min(r.target, r.a + step);
  }
}

/* 屋面质感：瓦是"横排瓦楞 + 竖向错缝"，铁皮是"长条压筋"，
   水泥是"分仓缝"。全部按世界坐标算，滚动时不会跟着镜头爬。
   边缘不做任何抖动 / 描边闪动 —— 用户明确说不要 UI 感。 */
/* 玩家视野锥，世界坐标。给屋顶"挖洞"用：锥里看到的地方把屋顶剪掉，
   人站在屋外就能顺着锥一眼看到门和屋里。返回点数组（测试用）。 */
function visionConePath(g, padDeg, addToPath){
  const C = g || ctx;
  const L = cur();
  const pts = [];
  if (!player) return pts;
  const R = seeRange(L) + 40;
  const half = seeFov(L) * Math.PI / 360;
  const aim = player.aim || 0;
  const pad = (padDeg || 0) * Math.PI / 180;
  const N = 40;
  if (!addToPath) C.beginPath();
  C.moveTo(player.x, player.y);
  for (let i = 0; i <= N; i++){
    const ang = aim - half - pad + (2*half + 2*pad) * i / N;
    let len = rayToWall(player.x, player.y, ang, R, true, false, true);
    if (typeof rayToTruck === 'function'){ const t = rayToTruck(player.x, player.y, ang, R); if (t < len) len = t; }
    if (typeof raySmokeCut === 'function'){ const sc = raySmokeCut(player.x, player.y, ang, len); if (sc < len) len = sc; }
    const px = player.x + Math.cos(ang) * len, py = player.y + Math.sin(ang) * len;
    pts.push({x:px, y:py});
    C.lineTo(px, py);
  }
  C.closePath();
  return pts;
}

function drawRoofSurface(r, g){
  const C = g || ctx;
  const S = r.skin;
  const x = r.x, y = r.y, w = r.w, h = r.h;
  C.fillStyle = S.base;
  C.fillRect(x, y, w, h);

  /* 受光的上沿 + 背光的下沿：一点点体积，别做成描边 */
  const ga0 = C.globalAlpha;
  /* 受光/背光只做很薄的一条 —— 厚了整块屋顶看着像发光，边缘像羽化 */
  /* 屋顶就是一块平的瓦面：上下的"受光/背光"带整个去掉 ——
     贴着边的那几像素渐变，从屋外斜着看就是一整圈"羽化"。 */
  C.globalAlpha = ga0;

  if (r.mat === 'sheet'){
    C.strokeStyle = S.seam;
    C.lineWidth = 1;
    const gap = 18;
    C.beginPath();
    for (let px = x + gap; px < x + w; px += gap){
      C.moveTo(px + 0.5, y + 2);
      C.lineTo(px + 0.5, y + h - 2);
    }
    C.stroke();
  } else if (r.mat === 'slab'){
    C.strokeStyle = S.seam;
    C.lineWidth = 1;
    C.beginPath();
    for (let py = y + 46; py < y + h; py += 46){
      C.moveTo(x + 2, py + 0.5); C.lineTo(x + w - 2, py + 0.5);
    }
    for (let px = x + 62; px < x + w; px += 62){
      C.moveTo(px + 0.5, y + 2); C.lineTo(px + 0.5, y + h - 2);
    }
    C.stroke();
  } else {
    /* 瓦：从上往下看是一道道"瓦垄" */
    for (let px = x + 10; px < x + w - 2; px += 11){
      C.fillStyle = S.seam;
      C.fillRect(px, y + 2, 2, h - 4);
      C.fillStyle = S.hi;
      C.globalAlpha = ga0 * 0.28;
      C.fillRect(px + 2, y + 2, 1, h - 4);
      C.globalAlpha = ga0;
    }
    C.fillStyle = S.seam;
    for (let py = y + 34; py < y + h - 4; py += 34){
      C.globalAlpha = ga0 * 0.55;
      C.fillRect(x + 2, py, w - 4, 1);
      C.globalAlpha = ga0;
    }
  }
}

/* 门洞在屋顶上挖出来的那块：门口不能盖死，不然从外面根本看不出入口在哪 */
function roofGapRects(r){
  const out = [];
  for (const o of roofOpenings(r)){
    const len = o.to - o.from;
    if (o.horiz){
      const y = o.sign < 0 ? o.fixed - 11 : o.fixed - 1;
      out.push({ x: o.from - 1, y, w: len + 2, h: 12, horiz: true, sign: o.sign,
                 edge: o.fixed, from: o.from, to: o.to });
    } else {
      const x = o.sign < 0 ? o.fixed - 11 : o.fixed - 1;
      out.push({ x, y: o.from - 1, w: 12, h: len + 2, horiz: false, sign: o.sign,
                 edge: o.fixed, from: o.from, to: o.to });
    }
  }
  return out;
}

/* 一整块屋顶：屋面（门口挖空）+ 屋檐压暗 + 门槛光 */
/* 屋面本体：只画面，不画屋檐边框。
   边框要留到"视野锥擦除"之后再画，否则锥边缘的模糊会把屋顶的边糊掉 ——
   站在屋外看过去，屋顶四边就像被羽化了一样。 */
function paintRoofBody(g, r){
  const gaps = roofGapRects(r);
  g.save();
  g.globalAlpha *= r.a;
  if (gaps.length && g.clip){
    /* 矩形 - 门洞：门那一段屋顶直接开了个口，楼下看得见 */
    g.beginPath();
    g.rect(r.x, r.y, r.w, r.h);
    for (const q of gaps) g.rect(q.x, q.y, q.w, q.h);
    try { g.clip('evenodd'); } catch (e){ if (typeof reportErr === 'function') reportErr('30-thermal', e); }
  }
  drawRoofSurface(r, g);
  g.restore();
}

/* 屋檐压暗：一像素都不能糊，所以放在擦除之后硬画 */
function paintRoofRim(g, r){
  const gaps = roofGapRects(r);
  g.save();
  g.globalAlpha *= r.a;
  if (gaps.length && g.clip){
    g.beginPath();
    g.rect(r.x, r.y, r.w, r.h);
    for (const q of gaps) g.rect(q.x, q.y, q.w, q.h);
    try { g.clip('evenodd'); } catch (e){ if (typeof reportErr === 'function') reportErr('30-thermal', e); }
  }
  /* 屋檐不要外扩、也不留宽暗边 —— 屋顶就画到墙的外沿为止，边上一条 1px 收口 */
  const e = 1;
  g.fillStyle = r.skin.eave;
  g.fillRect(r.x, r.y, r.w, e);
  g.fillRect(r.x, r.y + r.h - e, r.w, e);
  g.fillRect(r.x, r.y, e, r.h);
  g.fillRect(r.x + r.w - e, r.y, e, r.h);
  g.restore();
  drawRoofOpenings(r, g, gaps);
}

/* 兼容老调用：本体 + 边框一次画完（测试沙箱走这条） */
function paintRoof(g, r){
  paintRoofBody(g, r);
  paintRoofRim(g, r);
}

let roofLayer = null, roofLayerCtx = null;

function drawRoofs(){
  if (!player) return;
  const vis = [];
  for (const r of roofs){
    if (r.a <= 0.004) continue;                       /* 全透明：一个像素都不画 */
    if (!cullRect(r.x, r.y, r.w, r.h, 40)) continue;
    vis.push(r);
  }
  const shadeOn = (typeof rooms !== 'undefined' && rooms.length && !!player);   /* 第 60 轮：站屋外也要压暗 */
  if (!vis.length && !shadeOn) return;

  /* 没有 DOM（测试沙箱）就照旧直接画，不做挖洞 */
  const canLayer = (typeof document !== 'undefined') && typeof ctx.getTransform === 'function';
  if (!canLayer){
    paintRoomShade(ctx);
    if (ROOF_VISIBLE) for (const r of vis) paintRoof(ctx, r);
    return;
  }

  if (!roofLayer || !roofLayerCtx){
    roofLayer = document.createElement('canvas');
    roofLayerCtx = roofLayer.getContext('2d');
  }
  if (roofLayer.width !== W || roofLayer.height !== H){
    roofLayer.width = W; roofLayer.height = H;
  }
  const g = roofLayerCtx;
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.clearRect(0, 0, W, H);
  let M = null;
  try { M = ctx.getTransform(); } catch(e){ M = null; }
  if (M) g.setTransform(M.a, M.b, M.c, M.d, M.e, M.f);
  paintRoomShade(g);
  if (ROOF_VISIBLE) for (const r of vis) paintRoofBody(g, r);

  /* 视野锥：把屋顶"擦"掉。destination-out + 模糊，锥边渐隐 ——
     这条模糊同时也是屋里光锥边缘的"羽化"，别设成 none。 */
  if (typeof rayToWall === 'function' && typeof seeRange === 'function'){
    g.globalCompositeOperation = 'destination-out';
    g.filter = 'blur(3px)';
    visionConePath(g, 4, false);
    g.fillStyle = 'rgba(0,0,0,0.97)';
    g.fill();
    g.filter = 'none';
    g.globalCompositeOperation = 'source-over';
  }

  /* 擦完再把屋檐硬边框压回去：屋顶的轮廓永远是清楚的 */
  g.filter = 'none';
  g.globalCompositeOperation = 'source-over';
  if (ROOF_VISIBLE) for (const r of vis) paintRoofRim(g, r);

  ctx.save();
  ctxScreen();          /* m23103：屋顶层也是全屏覆盖，跟着渲染分辨率 */
  ctx.globalAlpha = 1;
  ctx.drawImage(roofLayer, 0, 0);
  ctx.restore();
}

/* 屋顶四条边上"墙断了"的那几段 —— 就是门洞或窗洞。 */
function roofOpenings(r){
  /* 门洞只在墙被打穿/重建时才变，别每帧重扫 */
  const L0 = cur();
  const ws0 = (L0 && L0.walls) || [];
  let deadN = 0;
  for (const w of ws0) if (w.dead) deadN++;
  const key = ws0.length + ':' + deadN;
  if (r._gapKey === key && r._gaps) return r._gaps;
  r._gapKey = key;
  const out = [];
  r._gaps = out;
  /* 屋顶比墙多探出一圈屋檐，所以要在"往里几个像素"的深度上都探一遍，
     全都没墙才算开口，否则整条檐口都会被当成门。 */
  const probe = (x, y, horiz, sign) => {
    if (typeof wallAtPoint !== 'function') return true;
    for (const d of [5, 11, 17]){
      const px = horiz ? x : x + sign * d;
      const py = horiz ? y + sign * d : y;
      if (wallAtPoint(px, py)) return false;
    }
    return true;
  };
  const scan = (fixed, from, to, horiz, sign) => {
    let runStart = null;
    for (let v = from; v <= to; v += 4){
      const x = horiz ? v : fixed;
      const y = horiz ? fixed : v;
      const open = probe(x, y, horiz, sign);
      if (open && runStart === null) runStart = v;
      if ((!open || v + 4 > to) && runStart !== null){
        const end = open ? v + 4 : v;
        if (end - runStart >= 20) out.push({ horiz, fixed, from: runStart, to: end, sign });
        runStart = null;
      }
    }
  };
  scan(r.y + r.h - 6, r.x + 4, r.x + r.w - 4, true, -1);   /* 南（往里是往上） */
  scan(r.y + 6, r.x + 4, r.x + r.w - 4, true, 1);          /* 北（往里是往下） */
  scan(r.x + 6, r.y + 4, r.y + r.h - 4, false, 1);         /* 西（往里是往右） */
  scan(r.x + r.w - 6, r.y + 4, r.y + r.h - 4, false, -1);  /* 东（往里是往左） */
  return out;
}

function drawRoofOpenings(r, g, gapsArg){
  const C = g || ctx;
  const gaps = gapsArg || roofGapRects(r);
  if (!gaps.length) return;
  const ga = C.globalAlpha;
  const warm = '#c9b489';
  for (const q of gaps){
    /* 门洞底下：先铺一层比屋顶暗的"门内地面"，再在门槛上点一道暖光 */
    C.fillStyle = '#191d22';
    C.globalAlpha = Math.min(1, ga) * 0.92;
    if (q.horiz) C.fillRect(q.from - 1, q.sign < 0 ? q.edge - 11 : q.edge - 1, q.to - q.from + 2, 12);
    else C.fillRect(q.sign < 0 ? q.edge - 11 : q.edge - 1, q.from - 1, 12, q.to - q.from + 2);
    /* 门槛内侧一道暗缝（门的厚度） */
    C.fillStyle = r.skin.lo;
    C.globalAlpha = Math.min(1, ga) * 0.85;
    if (q.horiz) C.fillRect(q.from, q.edge + (q.sign < 0 ? -2 : 1), q.to - q.from, 2);
    else C.fillRect(q.edge + (q.sign < 0 ? -2 : 1), q.from, 2, q.to - q.from);
    /* 门槛上那道暖光：门里透出来的 */
    C.fillStyle = warm;
    C.globalAlpha = Math.min(1, ga) * 0.75;
    if (q.horiz) C.fillRect(q.from, q.edge + (q.sign < 0 ? -7 : 5), q.to - q.from, 2);
    else C.fillRect(q.edge + (q.sign < 0 ? -7 : 5), q.from, 2, q.to - q.from);
    /* 洒到墙外地面上的余光，越往外越淡 */
    for (let d = 0; d < 14; d++){
      C.globalAlpha = Math.min(1, ga) * (0.16 * (1 - d / 14));
      if (q.horiz) C.fillRect(q.from - 3, q.edge - q.sign * (3 + d), q.to - q.from + 6, 1);
      else C.fillRect(q.edge - q.sign * (3 + d), q.from - 3, 1, q.to - q.from + 6);
    }
  }
  C.globalAlpha = ga;
}

/* 造一个"墙对象"给某个装饰物用。solid 的会挂进 L.walls（挡人挡弹），
   不挡路的（能推的瓦罐）只留在 d._w 上，给 damageDecor 记血用。 */
function decorWallOf(d){
  const hp0 = d.hp || 0;
  const fb = decorFoot(d);
  return {
    x: fb.x, y: fb.y, w: fb.w, h: fb.h,
    decor: true, dec: d, mat: d.mat,
    brk: false, decorBrk: hp0 > 0,
    hp: hp0, hp0: hp0, maxHp: hp0,
    hits: 0, hitT: 0, dead: false,
    staticBody: true
  };
}

/* 碰撞箱：从底边往上取 foot 那一截。站得远看得见整个罐子，
   真走上去才发现挡路的只有它下面那半 —— 比"视觉多大就多大"自然。 */
function decorFoot(d){
  const f = clamp((d.foot == null ? 1 : d.foot), 0.2, 1);
  const h = d.h * f;
  return { x: d.x, y: d.y + d.h - h, w: d.w, h: h };
}

/* 子弹打装饰物用"看得见的那整块"，不是脚下那半截。
   （第 40 轮修的 bug：之前连打都按 foot 箱算，打瓦罐的肚子、打桌子的桌面全都打空，
     玩家当然觉得"完全打不碎"。） */
function decorHitBox(d){
  return { x: d.x, y: d.y, w: d.w, h: d.h };
}

/* 能推的小物件（瓦罐）：不进墙表，玩家走过去把它顶着挪。
   不是平移 —— 带惯性、有摩擦、会晃。 */
/* 玩家这一帧实际走了多快（px/秒）。
   注意：玩家移动是直接改 x/y 的，没有 vx/vy —— 想算速度只能拿上一帧的坐标比
   （第 41 轮就是这个坑：拿 player.vx 算，永远是 0，于是"怎么推都推不动"）。 */
function playerMoveSpeed(dt){
  if (!player) return 0;
  const px = player._px == null ? player.x : player._px;
  const py = player._py == null ? player.y : player._py;
  return Math.hypot(player.x - px, player.y - py) / Math.max(1e-4, dt || 1e-4);
}

function pushedDecorAt(x, y, r){
  for (const d of decors){
    if (!d.push || d.dead) continue;
    const fb = decorHitBox(d);
    if (x + r < fb.x || x - r > fb.x + fb.w) continue;
    if (y + r < fb.y || y - r > fb.y + fb.h) continue;
    return d;
  }
  return null;
}

function pushDecor(d, nx, ny, spd){
  if (!d || d.dead) return;
  d.pvx = (d.pvx || 0) + nx * spd * 0.55;
  d.pvy = (d.pvy || 0) + ny * spd * 0.55;
  /* 第 40 轮：按用户要求先**不限速**，看推起来是什么手感 */
  const s = Math.hypot(d.pvx, d.pvy), cap = 900;
  if (s > cap){ d.pvx *= cap / s; d.pvy *= cap / s; }
}

/* 每帧：推 + 摩擦 + 撞墙停下。撞墙不是硬停，而是把速度按法线弹掉一半，
   看起来像"撞了一下没推动"，而不是卡住。 */
function updatePushables(dt){
  if (!decors || !decors.length) return;
  const L = cur();
  for (const d of decors){
    if (d.hitT > 0) d.hitT = Math.max(0, d.hitT - dt);   /* 计时器对所有装饰物都要走 */
    if (!d.push || d.dead) continue;
    let vx = d.pvx || 0, vy = d.pvy || 0;
    if (!vx && !vy){ if (d.tilt) d.tilt *= Math.pow(0.0025, dt); continue; }
    const nx = d.x + vx * dt, ny = d.y + vy * dt;
    const fb = decorFoot(d);
    const box = { x: nx, y: ny + d.h - fb.h, w: fb.w, h: fb.h };
    let hit = false;
    if (L && L.walls){
      for (const w of L.walls){
        if (w.decor && w.dec === d) continue;
        if (w.dead) continue;
        if (box.x + box.w <= w.x || box.x >= w.x + w.w) continue;
        if (box.y + box.h <= w.y || box.y >= w.y + w.h) continue;
        hit = true; break;
      }
    }
    if (!hit){
      d.x = nx; d.y = ny;
      /* 椅子这种"一推就倒"的东西：被顶开一小段就倒了，倒了之后不能再坐。
         瓦罐不倒（它只会裂），所以按 topple 标记来。 */
      if (d.topple && !d.toppled){
        d.pushAcc = (d.pushAcc || 0) + Math.hypot(vx, vy) * dt;
        if (d.pushAcc > 12){
          d.toppled = true;
          if (player && player.seat === d) standUp();
          setMsg('椅子被推倒了', 1.4);
          sfxCrack(true);
          for (let i = 0; i < 5; i++){
            const _a = fxRand(0, TAU), _sp = fxRand(40, 150);
            brkChunks.push({x: d.x + d.w * 0.5, y: d.y + d.h * 0.5,
                            vx: Math.cos(_a) * _sp, vy: Math.sin(_a) * _sp,
                            s: fxRand(1.0, 2.2), rot: fxRand(0, TAU), vr: fxRand(-8, 8),
                            t: 0, dur: fxRand(0.3, 0.6), big: false});
          }
        }
      }
    } else {
      d.pvx = -vx * 0.35; d.pvy = -vy * 0.35;
      /* 撞墙掉一点血：罐子撞墙会裂 */
      if (Math.hypot(vx, vy) > 120) damageDecor(d, 4, d.x + d.w / 2, d.y + d.h / 2, 0);
    }
    /* 摩擦：速度指数衰减；同时把"摇晃"转成倾角，停下之后自己回正 */
    const damp = Math.pow(0.02, dt);
    d.pvx *= damp; d.pvy *= damp;
    if (Math.abs(d.pvx) < 2) d.pvx = 0;
    if (Math.abs(d.pvy) < 2) d.pvy = 0;
    const sp = Math.hypot(d.pvx, d.pvy);
    if (d._w){ const fb2 = decorFoot(d); d._w.x = fb2.x; d._w.y = fb2.y; d._w.w = fb2.w; d._w.h = fb2.h; }
    d.tiltTarget = clamp(sp / 260, 0, 0.30);
    d.tiltDir = Math.atan2(d.pvy, d.pvx);
    d.tilt = (d.tilt || 0) + ((d.tiltTarget || 0) - (d.tilt || 0)) * Math.min(1, dt * 9);
  }
}

/* 能坐的椅子：找玩家身边最近的一张 */
function seatNear(range){
  if (!player) return null;
  let best = null, bd = range || 46;
  for (const d of decors){
    if (!d.sit || d.toppled || d.dead) continue;
    const dd = distToRect(player.x, player.y, d);
    if (dd <= bd){ bd = dd; best = d; }
  }
  return best;
}

function sitDown(d){
  if (!d || !player || player.seat) return;
  if (d.toppled || d.dead){ setMsg('椅子倒了，坐不了', 1.2); return; }
  player.seat = d;
  player.sitting = true;
  /* 坐上去人是坐在"椅面"上，不是站在椅子前面的地板上 */
  player.seatPos = { x: d.x + d.w * 0.5, y: d.y + d.h * 0.46 };
  setMsg('坐下了 · 按 E 或按方向键起身', 1.8);
}

function standUp(){
  if (!player || !player.seat) return;
  player.seat = null;
  player.sitting = false;
  player.seatPos = null;
  setMsg('起来了', 0.9);
}

function drawDecors(){
  if (!decors.length) return;
  for (const d of decors){
    /* 第 41 轮：碎掉的别画了。以前少了这一行 —— breakDecor 把墙撤了、残渣也留了，
       可桌子照样画在那儿，玩家当然觉得"打不烂"。 */
    if (d.dead) continue;
    if (!cullRect(d.x - 40, d.y - (d.hi || 0) - 40, d.w + 80, d.h + (d.hi || 0) + 80, 80)) continue;
    drawDecor(d);
  }
}

/* 坐在椅子上时，最后再补画一次"椅背 + 前腿"：盖住人的下半身，
   看起来就是人坐在椅子上、背靠着椅背，而不是站在椅子前面的地上。 */
function drawSeatOverlay(d){
  const S = (typeof DECOR_SKIN !== 'undefined') ? DECOR_SKIN : null;
  if (!S || !d || d.t !== 'chair') return;
  const x = d.x, y = d.y, w = d.w, h = d.h;
  const hi = (d.hi || 18) * 1.06;                 /* 坐着的时候椅背略高一点，正好挡住人 */
  const by = y + h;
  const backY = by - hi;
  const seatY = by - hi * 0.58;
  const seatH = Math.max(4, hi * 0.22);
  /* 两条后腿（靠背延长下来） */
  ctx.fillStyle = S.woodLo;
  ctx.fillRect(x + w * 0.14, backY, Math.max(3, w * 0.10), hi);
  ctx.fillRect(x + w * 0.76, backY, Math.max(3, w * 0.10), hi);
  /* 椅背两道横板 */
  ctx.fillStyle = S.wood;
  ctx.fillRect(x + w * 0.10, backY, w * 0.80, Math.max(4, hi * 0.24));
  ctx.fillStyle = S.woodHi;
  ctx.fillRect(x + w * 0.10, backY, w * 0.80, Math.max(1.6, hi * 0.08));
  ctx.fillStyle = S.wood;
  ctx.fillRect(x + w * 0.10, backY + hi * 0.40, w * 0.80, Math.max(3, hi * 0.16));
  /* 座板前沿压在人身上，做出"人陷进椅子里"的那一小条 */
  ctx.fillStyle = S.wood;
  ctx.fillRect(x + w * 0.04, seatY, w * 0.92, seatH);
  ctx.fillStyle = S.woodHi;
  ctx.fillRect(x + w * 0.04, seatY, w * 0.92, Math.max(1.8, seatH * 0.30));
  ctx.fillStyle = S.woodLo;
  ctx.fillRect(x + w * 0.10, seatY + seatH, Math.max(3, w * 0.09), by - (seatY + seatH));
  ctx.fillRect(x + w * 0.81, seatY + seatH, Math.max(3, w * 0.09), by - (seatY + seatH));
  ctx.strokeStyle = 'rgba(12,10,7,0.55)'; ctx.lineWidth = 1.1;
  ctx.strokeRect(x + w * 0.04, seatY, w * 0.92, seatH);
}

/* 受击闪白：只在物件自己的轮廓上发光，绝不画矩形底框。
   做法是"离屏画一遍本体 -> source-atop 把已画的像素刷成纯白 -> 按 alpha 贴回主画布"。
   第 43 轮之前的写法是 fillRect 整块叠白，用户原话「底下带了一个非常出戏的方形底框」。 */
const DECOR_FLASH_T = 0.10;                 /* 闪白总时长（秒）：1 线性降到 0 */
let _decorNoShadow = false;                 /* 离屏那遍：不画落地影 */
let _decorFlashPass = false;                /* 离屏那遍：不再递归闪白 */
let _decorFlashCv = null, _decorFlashCtx = null;

function drawDecorFlash(d){
  if (_decorFlashPass) return;
  if (typeof document === "undefined" || !document.createElement) return;   /* 测试沙箱里没有 DOM，直接跳过 */
  const fl = (d.hitT > 0) ? clamp(d.hitT / DECOR_FLASH_T, 0, 1) : 0;
  if (fl <= 0) return;
  const hi = d.hi || 0;
  const bx = Math.floor(d.x - 3), by = Math.floor(d.y + d.h - hi - 7);
  const bw = Math.ceil(d.w + 6), bh = Math.ceil(hi + 16);
  if (bw < 3 || bh < 3) return;
  if (!_decorFlashCv){
    _decorFlashCv = document.createElement('canvas');
    _decorFlashCtx = _decorFlashCv.getContext('2d');
  }
  const cv = _decorFlashCv, oc = _decorFlashCtx;
  if (cv.width < bw || cv.height < bh){
    cv.width = Math.max(cv.width, bw);
    cv.height = Math.max(cv.height, bh);
  }
  oc.setTransform(1, 0, 0, 1, 0, 0);
  oc.clearRect(0, 0, bw, bh);
  _decorNoShadow = true; _decorFlashPass = true;
  try {
    withDrawCtx(oc, () => {
      ctx.save();
      ctx.translate(-bx, -by);
      drawDecor(d);
      ctx.restore();
    });
  } finally {
    _decorNoShadow = false; _decorFlashPass = false;
  }
  /* 只给"已经画上去的像素"刷白：source-atop 不会碰到透明区域 */
  oc.save();
  oc.globalCompositeOperation = 'source-atop';
  oc.fillStyle = '#fff6e6';
  oc.fillRect(0, 0, bw, bh);
  oc.restore();
  ctx.save();
  ctx.globalAlpha = fl;
  ctx.drawImage(cv, 0, 0, bw, bh, bx, by, bw, bh);
  ctx.restore();
}

function drawDecor(d){
  if (!d || d.dead) return;
  const S = (typeof DECOR_SKIN !== 'undefined') ? DECOR_SKIN : null;
  if (!S) return;
  const x = d.x, y = d.y, w = d.w, h = d.h, hi = d.hi || 0;
  const r1 = covHash(d.seed, 3), r2 = covHash(d.seed, 11);
  /* 统一的落地影：贴在脚底（by = 占地矩形的下沿），不是贴在矩形中心。
     离屏做闪白剪影时把影子关掉，否则会闪出一个白椭圆。 */
  if (!_decorNoShadow){
    ctx.fillStyle = S.shadow;
    ctx.beginPath();
    ctx.ellipse(x + w * 0.5, y + h * 0.94, w * 0.48, h * 0.26, 0, 0, TAU);
    ctx.fill();
  }

  const by = y + h;                     /* 脚底线：物件都从这条线往上"立"起来 */
  const r3 = covHash(d.seed, 23);

  if (d.t === 'table'){
  /* 桌子：正面看 —— 一条桌面 + 两条桌腿 + 后面一条腿露个头。
     桌面的"厚度"用一条深色板 + 一条亮边做出来。 */
    const th = Math.max(5, hi * 0.30);                 /* 桌面厚度 */
    const topY = by - hi;                              /* 桌面顶面上沿 */
    const legW = Math.max(3.5, w * 0.06);
    /* 后腿（先画，被桌面压住一点） */
    ctx.fillStyle = S.woodLo;
    ctx.fillRect(x + w * 0.66, topY + th, legW, hi - th + h * 0.06);
    /* 前腿两根 */
    ctx.fillStyle = S.woodLo;
    ctx.fillRect(x + w * 0.10, topY + th, legW, hi - th);
    ctx.fillRect(x + w * 0.90 - legW, topY + th, legW, hi - th);
    /* 桌面：亮面 + 厚度暗条 */
    ctx.fillStyle = S.wood;
    ctx.fillRect(x, topY, w, th);
    ctx.fillStyle = S.woodHi;
    ctx.fillRect(x, topY, w, Math.max(2, th * 0.36));
    ctx.fillStyle = S.woodLo;
    ctx.fillRect(x, topY + th - Math.max(2, th * 0.34), w, Math.max(2, th * 0.34));
    /* 桌面两头的木纹 */
    ctx.strokeStyle = 'rgba(20,16,11,0.35)'; ctx.lineWidth = 1;
    for (let i = 1; i <= 2; i++){
      const px = x + w * (i / 3) + (i === 1 ? r1 * 5 - 2.5 : r2 * 5 - 2.5);
      ctx.beginPath(); ctx.moveTo(px, topY + 1); ctx.lineTo(px, topY + th - 1); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(12,10,7,0.6)'; ctx.lineWidth = 1.2;
    ctx.strokeRect(x + 0.5, topY + 0.5, w - 1, th - 1);
  } else if (d.t === 'chair'){
  /* 椅子：正面看 —— 靠背（高，带两根竖档）+ 座板（横条）+ 两条前腿。
     侧面轮廓是"背高、座低"，一眼就是椅子。
     被推倒之后（d.toppled）画成躺在地上的：靠背平铺、腿朝一边翘着。 */
    if (d.toppled){
      const lieY = by - Math.max(3, hi * 0.22);
      ctx.save();
      ctx.translate(x + w * 0.5, lieY);
      ctx.rotate(-0.42);
      /* 躺下的靠背：两块横板铺在地上 */
      ctx.fillStyle = S.woodLo;
      ctx.fillRect(-w * 0.44, -4, w * 0.88, 9);
      ctx.fillStyle = S.wood;
      ctx.fillRect(-w * 0.44, -4, w * 0.88, 4.5);
      /* 翘起来的两条腿 */
      ctx.strokeStyle = S.woodHi; ctx.lineWidth = Math.max(2, w * 0.09);
      ctx.beginPath();
      ctx.moveTo(-w * 0.30, -3); ctx.lineTo(-w * 0.46, -hi * 0.55);
      ctx.moveTo(w * 0.26, -2);  ctx.lineTo(w * 0.40, -hi * 0.42);
      ctx.stroke();
      ctx.fillStyle = S.woodHi;
      ctx.fillRect(w * 0.06, -2.5, w * 0.30, 3.5);
      ctx.restore();
      return;
    }
    const backT = Math.max(4, w * 0.14);               /* 靠背厚度（看不清但占位） */
    const backY = by - hi;                              /* 靠背顶 */
    const seatY = by - hi * 0.62;                       /* 座板高度 */
    const seatH = Math.max(4, hi * 0.22);
    /* 两条后腿（靠背延长下来） */
    ctx.fillStyle = S.woodLo;
    ctx.fillRect(x + w * 0.14, backY, Math.max(3, w * 0.10), hi);
    ctx.fillRect(x + w * 0.76, backY, Math.max(3, w * 0.10), hi);
    /* 靠背横板：上下各一条，中间留空（栅栏式，看得出是椅背） */
    ctx.fillStyle = S.wood;
    ctx.fillRect(x + w * 0.10, backY, w * 0.80, Math.max(4, hi * 0.24));
    ctx.fillStyle = S.woodHi;
    ctx.fillRect(x + w * 0.10, backY, w * 0.80, Math.max(1.6, hi * 0.08));
    ctx.fillStyle = S.wood;
    ctx.fillRect(x + w * 0.10, backY + hi * 0.40, w * 0.80, Math.max(3, hi * 0.16));
    /* 座板：往前探出来一点（正面看是条横板） */
    ctx.fillStyle = S.wood;
    ctx.fillRect(x + w * 0.04, seatY, w * 0.92, seatH);
    ctx.fillStyle = S.woodHi;
    ctx.fillRect(x + w * 0.04, seatY, w * 0.92, Math.max(1.8, seatH * 0.30));
    ctx.fillStyle = S.woodLo;
    ctx.fillRect(x + w * 0.04, seatY + seatH - Math.max(1.4, seatH * 0.22), w * 0.92, Math.max(1.4, seatH * 0.22));
    /* 两条前腿 */
    ctx.fillStyle = S.woodLo;
    ctx.fillRect(x + w * 0.10, seatY + seatH, Math.max(3, w * 0.09), by - (seatY + seatH));
    ctx.fillRect(x + w * 0.81, seatY + seatH, Math.max(3, w * 0.09), by - (seatY + seatH));
    ctx.strokeStyle = 'rgba(12,10,7,0.55)'; ctx.lineWidth = 1.1;
    ctx.strokeRect(x + w * 0.04, seatY, w * 0.92, seatH);
  } else if (d.t === 'jar'){
  /* 瓦罐：正面看 —— 大肚子 + 收颈 + 罐口。底宽、肩圆、口小，这是瓦罐的辨识点 */
    ctx.save();
    /* 被推着走的时候整个罐子绕着底线晃：往哪边推就往哪边倒一点，
       停下来自己回正。这是"推着东西走"的手感，不是整块平移。 */
    const _lean = (d.tilt || 0) * 0.55 * Math.cos(d.tiltDir || 0)
                + (d.tilt ? Math.sin(uiT * 15 + (d.seed || 0)) * d.tilt * 0.10 : 0);
    if (_lean){
      ctx.translate(x + w * 0.5, by); ctx.rotate(_lean); ctx.translate(-(x + w * 0.5), -by);
    }
    const bodyH = Math.max(12, hi * 0.74);             /* 肚子高度 */
    const neckH = Math.max(4, hi * 0.26);              /* 脖子高度 */
    const bellyY = by - bodyH * 0.5;
    const bw = w * 0.46, bh = bodyH * 0.52;
    /* 罐身（椭圆肚子）+ 暗边 */
    ctx.beginPath(); ctx.ellipse(x + w * 0.5, bellyY + 1.2, bw, bh, 0, 0, TAU);
    ctx.fillStyle = S.clayLo; ctx.fill();
    ctx.beginPath(); ctx.ellipse(x + w * 0.5, bellyY, bw, bh, 0, 0, TAU);
    ctx.fillStyle = S.clay; ctx.fill();
    /* 左上的受光 */
    ctx.beginPath(); ctx.ellipse(x + w * 0.34, bellyY - bh * 0.34, bw * 0.34, bh * 0.34, -0.5, 0, TAU);
    ctx.fillStyle = S.clayHi; ctx.fill();
    /* 收颈 */
    ctx.fillStyle = S.clay;
    ctx.fillRect(x + w * 0.36, by - bodyH - neckH, w * 0.28, neckH + 2);
    ctx.fillStyle = S.clayLo;
    ctx.fillRect(x + w * 0.36, by - bodyH - neckH, Math.max(1.4, w * 0.05), neckH + 2);
    /* 罐口：一个压扁的深色椭圆 + 陶土边 */
    const moy = by - bodyH - neckH;
    ctx.beginPath(); ctx.ellipse(x + w * 0.5, moy, w * 0.19, Math.max(2.6, w * 0.08), 0, 0, TAU);
    ctx.fillStyle = S.clay; ctx.fill();
    ctx.beginPath(); ctx.ellipse(x + w * 0.5, moy, w * 0.14, Math.max(1.8, w * 0.055), 0, 0, TAU);
    ctx.fillStyle = S.clayIn; ctx.fill();
    /* 腰上一道弦纹 */
    ctx.strokeStyle = 'rgba(30,20,12,0.45)'; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(x + w * 0.5, bellyY + bh * 0.42, bw * 0.92, bh * 0.34, 0, 0.12, Math.PI - 0.12);
    ctx.stroke();
    ctx.restore();
  } else if (d.t === 'bottle'){
    /* 饮料瓶：躺在地上的小瓶 —— 瓶身 + 瓶口 + 一道反光，看得出是玻璃 */
    const cx = x + w * 0.5, cy = y + h * 0.5;
    const rx = Math.max(4.4, w * 0.46), ry = Math.max(3.6, h * 0.42);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-0.5 + (r1 - 0.5) * 0.5);
    /* 瓶身 */
    ctx.beginPath();
    ctx.ellipse(0, 0, rx, ry, 0, 0, TAU);
    ctx.fillStyle = S.glassLo; ctx.fill();
    ctx.beginPath();
    ctx.ellipse(-rx * 0.08, -ry * 0.10, rx * 0.84, ry * 0.78, 0, 0, TAU);
    ctx.fillStyle = S.glass; ctx.fill();
    /* 瓶颈 */
    ctx.fillStyle = S.glass;
    ctx.fillRect(rx * 0.72, -ry * 0.30, rx * 0.52, ry * 0.60);
    ctx.fillStyle = S.glassHi;
    ctx.fillRect(rx * 1.16, -ry * 0.34, rx * 0.16, ry * 0.68);
    /* 反光 */
    ctx.beginPath();
    ctx.ellipse(-rx * 0.36, -ry * 0.38, rx * 0.26, ry * 0.20, 0, 0, TAU);
    ctx.fillStyle = S.glassHi; ctx.fill();
    ctx.restore();
  } else if (d.t === 'broom'){
    /* 扫把：一根柄 + 一头散开的穗，斜着靠在地上 */
    const ang = -0.42 + (r1 - 0.5) * 0.3;
    const len = Math.max(w, h) * 0.92;
    const cx = x + w * 0.5, cy = y + h * 0.5;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(ang);
    /* 柄 */
    ctx.fillStyle = S.wood;
    ctx.fillRect(-len * 0.5, -1.6, len * 0.72, 3.2);
    ctx.fillStyle = S.woodHi;
    ctx.fillRect(-len * 0.5, -1.6, len * 0.72, 1.2);
    /* 箍 */
    ctx.fillStyle = S.metal;
    ctx.fillRect(len * 0.16, -2.8, 4, 5.6);
    /* 穗：从箍口散开的一大把，越往外越散（扫把最显眼的就是这一头） */
    for (let i = 0; i < 9; i++){
      const a2 = (i / 8 - 0.5) * 0.78;
      ctx.save();
      ctx.translate(len * 0.20, 0);
      ctx.rotate(a2);
      ctx.fillStyle = (i % 2) ? S.straw : S.strawHi;
      ctx.fillRect(0, -2.2, len * 0.40, 4.4);
      ctx.restore();
    }
    ctx.restore();
  } else if (d.t === 'plank' || d.t === 'plankBroken'){
    /* 地上的木板 / 破木板：几块薄板平铺，互相压着、角度各不相同。
       hi = 0，所以完全贴地；不挡人、不挡子弹，只吃爆炸。 */
    const broken = (d.t === 'plankBroken');
    const nB = broken ? 2 : 3;
    for (let i = 0; i < nB; i++){
      const q1 = covHash(d.seed + i * 17, 41), q2 = covHash(d.seed + i * 17, 47);
      const bw2 = w * (broken ? (0.34 + q1 * 0.26) : (0.46 + q1 * 0.34));
      const bh2 = Math.max(3.4, h * (0.20 + q2 * 0.12));
      const cxp = x + w * (0.12 + q1 * 0.62), cyp = y + h * (0.24 + q2 * 0.52);
      ctx.save();
      ctx.translate(cxp, cyp);
      ctx.rotate((q1 - 0.5) * (broken ? 1.5 : 0.9));
      ctx.fillStyle = (i % 2) ? S.wood : S.woodLo;
      ctx.fillRect(-bw2 * 0.5, -bh2 * 0.5, bw2, bh2);
      ctx.fillStyle = S.woodHi;
      ctx.fillRect(-bw2 * 0.5, -bh2 * 0.5, bw2, Math.max(1, bh2 * 0.28));
      if (broken){
        /* 断口：一头削掉一块，露出亮茬 */
        ctx.fillStyle = S.woodHi;
        ctx.beginPath();
        ctx.moveTo(bw2 * 0.5, -bh2 * 0.5);
        ctx.lineTo(bw2 * 0.5 + bh2 * 0.9, 0);
        ctx.lineTo(bw2 * 0.5, bh2 * 0.5);
        ctx.closePath(); ctx.fill();
      } else {
        /* 钉子 */
        ctx.fillStyle = S.metal;
        ctx.fillRect(-bw2 * 0.5 + 3, -1, 1.8, 1.8);
        ctx.fillRect(bw2 * 0.5 - 5, -1, 1.8, 1.8);
      }
      ctx.restore();
    }
    if (broken){
      /* 碎屑：两三根小木刺 */
      ctx.fillStyle = S.woodLo;
      for (let i = 0; i < 3; i++){
        const q = covHash(d.seed + 91 + i * 13, 53);
        ctx.fillRect(x + w * (0.10 + q * 0.80), y + h * (0.72 + covHash(d.seed + i, 59) * 0.22),
                     3 + q * 5, 1.6);
      }
    }
  } else if (d.t === 'flower'){
    /* 野花：非常非常小。三片花瓣 + 花芯 + 两片叶子，就这么多。 */
    const cx = x + w * 0.5, cy = y + h * 0.46;
    ctx.fillStyle = S.leaf;
    ctx.beginPath();
    ctx.ellipse(cx - 2.6, cy + 2.4, 2.6, 1.5, -0.5, 0, TAU); ctx.fill();
    ctx.beginPath();
    ctx.ellipse(cx + 2.4, cy + 2.2, 2.2, 1.3, 0.6, 0, TAU); ctx.fill();
    ctx.fillStyle = S.leafHi;
    ctx.fillRect(cx - 0.5, cy - 1, 1, 4);
    for (let i = 0; i < 4; i++){
      const a2 = i * (TAU / 4) + (r1 - 0.5) * 0.4;
      ctx.beginPath();
      ctx.ellipse(cx + Math.cos(a2) * 2.1, cy + Math.sin(a2) * 2.1, 2.0, 1.5, a2, 0, TAU);
      ctx.fillStyle = S.petal; ctx.fill();
    }
    ctx.beginPath();
    ctx.ellipse(cx, cy, 1.5, 1.5, 0, 0, TAU);
    ctx.fillStyle = S.petalCore; ctx.fill();
    ctx.beginPath();
    ctx.ellipse(cx - 0.4, cy - 0.4, 0.8, 0.8, 0, 0, TAU);
    ctx.fillStyle = S.petalHi; ctx.fill();
  } else if (d.t === 'rose' || d.t === 'lily' || d.t === 'daisy'){
    /* 玫瑰 / 百合 / 雏菊：都是"非常小"的地面花草，纯装饰、只吃爆炸。
       玫瑰是暗红旋瓣，百合是米白六瓣，雏菊是白瓣金心。 */
    const cx = x + w * 0.5, cy = y + h * 0.44;
    const sw = Math.max(3.2, w * 0.30);
    /* 叶子 / 花茎 */
    ctx.fillStyle = S.leaf;
    ctx.beginPath(); ctx.ellipse(cx - sw * 0.86, cy + sw * 0.86, sw * 0.80, sw * 0.44, -0.6, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx + sw * 0.80, cy + sw * 0.78, sw * 0.70, sw * 0.40, 0.7, 0, TAU); ctx.fill();
    ctx.fillStyle = S.leafHi;
    ctx.fillRect(cx - 0.5, cy + sw * 0.2, 1, sw * 1.1);

    if (d.t === 'rose'){
      /* 玫瑰：外圈两片大瓣 + 内圈旋芯 */
      ctx.fillStyle = S.roseDeep;
      ctx.beginPath(); ctx.ellipse(cx, cy, sw * 1.05, sw * 1.0, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = S.rose;
      ctx.beginPath(); ctx.ellipse(cx - sw * 0.16, cy - sw * 0.10, sw * 0.86, sw * 0.80, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = S.roseHi; ctx.lineWidth = 0.9;
      ctx.beginPath();
      ctx.arc(cx - sw * 0.10, cy - sw * 0.06, sw * 0.52, 0.6, 0.6 + 4.4);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx + sw * 0.12, cy + sw * 0.08, sw * 0.26, 2.2, 2.2 + 3.6);
      ctx.stroke();
      ctx.fillStyle = S.roseDeep;
      ctx.beginPath(); ctx.ellipse(cx + sw * 0.10, cy + sw * 0.06, sw * 0.16, sw * 0.14, 0, 0, TAU); ctx.fill();
    } else if (d.t === 'lily'){
      /* 百合：六片细长瓣，向外张开，中间一簇蜜色花蕊 */
      for (let i = 0; i < 6; i++){
        const a2 = i * (TAU / 6) + (r1 - 0.5) * 0.3;
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(a2);
        ctx.beginPath();
        ctx.ellipse(0, -sw * 0.95, sw * 0.34, sw * 0.78, 0, 0, TAU);
        ctx.fillStyle = S.lily; ctx.fill();
        ctx.beginPath();
        ctx.ellipse(0, -sw * 0.86, sw * 0.16, sw * 0.52, 0, 0, TAU);
        ctx.fillStyle = S.lilyHi; ctx.fill();
        ctx.restore();
      }
      ctx.fillStyle = S.lilyCore;
      for (let i = 0; i < 3; i++){
        const a2 = i * (TAU / 3) + 0.4;
        ctx.beginPath();
        ctx.ellipse(cx + Math.cos(a2) * sw * 0.26, cy + Math.sin(a2) * sw * 0.26, sw * 0.14, sw * 0.14, 0, 0, TAU);
        ctx.fill();
      }
    } else {
      /* 雏菊：八片小圆瓣 + 金心 */
      for (let i = 0; i < 8; i++){
        const a2 = i * (TAU / 8) + (r1 - 0.5) * 0.3;
        ctx.beginPath();
        ctx.ellipse(cx + Math.cos(a2) * sw * 0.78, cy + Math.sin(a2) * sw * 0.78, sw * 0.44, sw * 0.30, a2, 0, TAU);
        ctx.fillStyle = S.daisy; ctx.fill();
      }
      ctx.beginPath();
      ctx.ellipse(cx, cy, sw * 0.44, sw * 0.44, 0, 0, TAU);
      ctx.fillStyle = S.daisyCore; ctx.fill();
    }
  } else if (d.t === 'trash'){
    /* 垃圾堆：一坨贴地的杂碎。底下一圈深色，上面几件脏纸 / 破布 / 罐子。
       有 hi（6px）但不挡人，子弹直接穿过去。 */
    const cx = x + w * 0.5, by2 = y + h * 0.96;
    ctx.beginPath();
    ctx.ellipse(cx, by2 - 1, w * 0.48, h * 0.30, 0, 0, TAU);
    ctx.fillStyle = S.trashD; ctx.fill();
    const cols = [S.trashA, S.trashB, S.trashC, S.trashE, S.trashA];
    for (let i = 0; i < 7; i++){
      const q1 = covHash(d.seed + i * 23, 71), q2 = covHash(d.seed + i * 23, 73);
      const sw = 5 + q1 * 9, sh = 3 + q2 * 5;
      const sx2 = cx - w * 0.34 + q1 * w * 0.66;
      const sy2 = by2 - 2 - (hi * 0.15 + q2 * hi * 0.85);
      ctx.save();
      ctx.translate(sx2, sy2);
      ctx.rotate((q1 - 0.5) * 1.2);
      ctx.fillStyle = cols[i % cols.length];
      ctx.fillRect(-sw / 2, -sh / 2, sw, sh);
      ctx.fillStyle = 'rgba(0,0,0,0.22)';
      ctx.fillRect(-sw / 2, sh / 2 - 1.2, sw, 1.2);
      ctx.restore();
    }
  } else if (d.t === 'soda' || d.t === 'flask'){
    /* 汽水瓶（可乐那种）/ 玻璃瓶（药瓶那种）：站着的小瓶。
       可乐 = 收腰曲线瓶身 + 红色腰标 + 皇冠盖；药瓶 = 直筒 + 螺旋盖。
       能推、能打碎、子弹能穿。 */
    const cola = (d.t === 'soda');
    const S2 = S;
    const cBody = cola ? S2.soda : S2.glass;
    const cHi   = cola ? S2.sodaHi : S2.glassHi;
    const cLo   = cola ? S2.sodaLo : S2.glassLo;
    const cx = x + w * 0.5, by = y + h - 0.8;
    const hw = w * 0.40;              /* 半宽（瓶身最宽处） */
    const neckY = y + h * (cola ? 0.20 : 0.18);
    const topY  = y + h * 0.04;

    /* 落地影 */
    ctx.beginPath();
    ctx.ellipse(cx, by + 0.6, hw * 1.05, 1.5, 0, 0, TAU);
    ctx.fillStyle = S2.shadow; ctx.fill();

    /* 瓶身：可乐收腰，药瓶直筒圆肩 */
    ctx.beginPath();
    if (cola){
      ctx.moveTo(cx - hw, by);
      ctx.quadraticCurveTo(cx - hw * 0.70, by - h * 0.30, cx - hw * 0.92, by - h * 0.48);
      ctx.quadraticCurveTo(cx - hw * 1.02, neckY + h * 0.16, cx - hw * 0.34, neckY);
      ctx.lineTo(cx + hw * 0.34, neckY);
      ctx.quadraticCurveTo(cx + hw * 1.02, neckY + h * 0.16, cx + hw * 0.92, by - h * 0.48);
      ctx.quadraticCurveTo(cx + hw * 0.70, by - h * 0.30, cx + hw, by);
    } else {
      ctx.moveTo(cx - hw * 0.92, by);
      ctx.lineTo(cx - hw * 0.92, neckY + h * 0.14);
      ctx.quadraticCurveTo(cx - hw * 0.92, neckY, cx - hw * 0.42, neckY);
      ctx.lineTo(cx + hw * 0.42, neckY);
      ctx.quadraticCurveTo(cx + hw * 0.92, neckY, cx + hw * 0.92, neckY + h * 0.14);
      ctx.lineTo(cx + hw * 0.92, by);
    }
    ctx.closePath();
    ctx.fillStyle = cLo; ctx.fill();
    ctx.save();
    ctx.clip();
    /* 内部液体：上浅下深 */
    const gx = ctx.createLinearGradient(cx - hw, 0, cx + hw, 0);
    gx.addColorStop(0, cLo);
    gx.addColorStop(0.35, cBody);
    gx.addColorStop(1, cLo);
    ctx.fillStyle = gx;
    ctx.fillRect(cx - hw * 1.1, neckY, hw * 2.2, by - neckY);
    /* 高光条 */
    ctx.fillStyle = cHi;
    ctx.fillRect(cx - hw * 0.58, neckY + h * 0.08, Math.max(1.2, hw * 0.26), (by - neckY) * 0.78);
    if (cola){
      /* 红色腰标 + 一道白勾 */
      ctx.fillStyle = '#a3232c';
      ctx.fillRect(cx - hw * 1.1, by - h * 0.46, hw * 2.2, h * 0.15);
      ctx.fillStyle = 'rgba(240,236,228,0.85)';
      ctx.fillRect(cx - hw * 1.1, by - h * 0.40, hw * 2.2, Math.max(0.9, h * 0.035));
    }
    ctx.restore();

    /* 瓶颈 + 瓶盖 */
    ctx.fillStyle = cola ? cBody : 'rgba(226,236,232,0.55)';
    ctx.fillRect(cx - hw * 0.30, topY + h * 0.05, hw * 0.60, neckY - topY);
    ctx.fillStyle = cola ? '#b8551f' : S2.metal;
    ctx.fillRect(cx - hw * 0.36, topY, hw * 0.72, Math.max(2, h * 0.09));
    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.fillRect(cx - hw * 0.36, topY, hw * 0.72, Math.max(0.8, h * 0.03));
  }

  /* 椅子：坐着时给"休息中"，没坐且在自己脚边时给"按 E 坐下"的提示 */
  if (d.sit && player){
    if (player.seat === d){
      ctx.fillStyle = S.labelTxt;
      ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('休息中', x + w * 0.5, y - (hi * 0.8) - 7);
    } else if (!player.seat && distToRect(player.x, player.y, d) <= 46){
      ctx.fillStyle = S.labelTxt;
      ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('[' + keyLabel(BINDS.interact) + '] 坐下', x + w * 0.5, y - (hi * 0.8) - 7);
    }
  }

  /* 挨打的反馈：越打越多的裂缝。
     以前只有 hp 在掉、画面纹丝不动，玩家以为打不烂。
     （第 42 轮删掉了"整块叠一层白光"的写法 —— 那会画出一个明显的方框，
      像给家具套了个半透明盒子，用户原话「外面这层包裹的是什么玩意？」） */
  const _w2 = d._w;
  if (_w2 && _w2.maxHp > 0 && _w2.hp < _w2.maxHp){
    const hurt = 1 - _w2.hp / _w2.maxHp;
    ctx.strokeStyle = 'rgba(14,10,8,0.75)';
    ctx.lineWidth = 1;
    const nC = hurt > 0.62 ? 3 : (hurt > 0.30 ? 2 : 1);
    for (let i = 0; i < nC; i++){
      const q1 = covHash(d.seed + i * 31, 61), q2 = covHash(d.seed + i * 31, 67);
      const cx0 = x + w * (0.22 + q1 * 0.56), cy0 = y + h - (hi || 0) * 0.5;
      ctx.beginPath();
      ctx.moveTo(cx0, cy0 - 3);
      ctx.lineTo(cx0 + (q2 - 0.5) * 6, cy0 + 2);
      ctx.lineTo(cx0 + (q1 - 0.5) * 9, cy0 + 6);
      ctx.stroke();
    }
  }
  drawDecorFlash(d);          /* 最后一层：轮廓剪影闪白（0.1 秒线性消退） */
}


/* 搜完一次给的话。
   正式关卡里**不报剩余次数**（玩家不该看见"还能翻几次"这种后台数字），
   只在测试区 / 开发者模式下才带次数，方便调参。 */
function pileFoundMsg(p){
  const dev = (typeof CFG !== 'undefined' && CFG.dev) ||
              !!(cur() && cur().rules && cur().rules.devTest);
  if (dev) return '翻出点东西 · 这堆还能再翻 ' + p.uses + ' 次';
  return '翻出点东西';
}

/* 这一堆现在长什么样：0 = 鼓鼓一堆，1 = 搜过几次明显变少，2 = 搜空 */
function pileState(p){
  if (!p.uses) return 2;
  if (p.uses < p.uses0) return 1;
  return 0;
}

/* 从这一堆的掉落表里抽 1 件（物资堆每次必掉 1 件，不翻空） */
function dropPileOne(p, fromBreak){
  if (typeof loots === 'undefined' || !Array.isArray(loots)) return false;
  const P = pileCfg();
  const T = ((P && P.table) || []).filter(d => !d.v2 || thermalV2());
  if (!T.length) return false;
  let total = 0;
  for (const d of T) total += (d.w || 1);
  let roll = fxRand(0, total), pick = T[T.length - 1];
  for (const d of T){ roll -= (d.w || 1); if (roll <= 0){ pick = d; break; } }
  const a = fxRand(0, TAU), rad = fxRand(18, 40);
  /* fromSearch：翻出来的东西不自动收，必须玩家自己按 E（同箱子掉落） */
  const base = { x: p.x + p.w / 2 + Math.cos(a) * rad, y: p.y + p.h / 2 + Math.sin(a) * rad,
                 taken: false, cool: 0.5, fromSearch: true, newT: 3.2 };
  if (pick.kind === 'rare'){
    loots.push(Object.assign(base, { kind:'rare', item: pick.item || 'gold' }));
  } else if (pick.kind === 'med'){
    loots.push(Object.assign(base, { kind:'med', rarity: pick.rarity || 'small' }));
  } else if (pick.kind === 'ammo'){
    loots.push(Object.assign(base, { kind:'ammo', ammo: pick.ammo || 'pistol', n: pick.n || 8 }));
  } else if (pick.kind === 'armor'){
    const AD = (typeof ARMOR_DEF !== 'undefined' && ARMOR_DEF[pick.armor]) ? ARMOR_DEF[pick.armor] : null;
    const dur = AD ? AD.dur : 250;
    const rng = pick.durPct || [0.25, 0.65];
    loots.push(Object.assign(base, { kind:'armor', armor: pick.armor || 'light',
                                     hp: Math.max(1, Math.round(dur * rollDurPct(rng[0], rng[1]))),
                                     maxHp: dur }));
  } else {
    const o = Object.assign(base, { kind: pick.kind });
    if (pick.bag) o.bag = pick.bag;
    if (pick.wid) o.wid = pick.wid;
    if (pick.n)   o.n   = pick.n;
    if (pick.mag) o.mag = pick.mag;
    if (pick.gear) o.gear = true;
    if (pick.aid) o.aid = pick.aid;
    loots.push(o);
  }
  return true;
}

/* 搜一次：必掉 1 件；次数减 1。返回是否真的掉东西了 */
function searchPileOnce(p){
  if (!p || p.dead) return false;
  if (p.uses <= 0) return false;
  p.uses--;
  dropPileOne(p, false);
  for (let i = 0; i < 5; i++){
    const a = fxRand(0, TAU), sp = fxRand(30, 120);
    brkChunks.push({x: p.x + p.w / 2 + fxRand(-10, 10), y: p.y + p.h / 2 + fxRand(-8, 8),
                    vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
                    s: fxRand(1.2, 2.6), rot: fxRand(0, TAU), vr: fxRand(-10, 10),
                    t: 0, dur: fxRand(0.35, 0.7), big: false});
  }
  sfxPick();
  return true;
}

/* 打爆：掉落 0~2 件（可能一件都没有）；已经搜光的，一定不掉 */
function breakPile(p, hx, hy){
  if (!p || p.dead) return;
  const P = pileCfg();
  p.dead = true;
  if (p.uses > 0 && P){
    const n = P.dropMin + Math.floor(fxRand(0, (P.dropMax - P.dropMin) + 0.999));
    for (let i = 0; i < n; i++) dropPileOne(p, true);
  }
  if (typeof pushDecal === 'function') pushDecal(p.x, p.y, p.w, p.h, 'wood');
  for (let i = 0; i < 12; i++){
    const a = fxRand(0, TAU), sp = fxRand(40, 200);
    brkChunks.push({x: (hx != null ? hx : p.x + p.w / 2) + fxRand(-6, 6),
                    y: (hy != null ? hy : p.y + p.h / 2) + fxRand(-6, 6),
                    vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
                    s: fxRand(1.4, 3.4), rot: fxRand(0, TAU), vr: fxRand(-12, 12),
                    t: 0, dur: fxRand(0.4, 0.9), big: false});
  }
  brkShake = Math.max(brkShake, 0.06);
  sfxCrack(true);
  setMsg(p.uses > 0 ? '物资堆被打散了' : '这堆早被翻空了', 1.4);
  logInfo('loot', '打散物资堆');
}

function damagePile(p, dmg, hx, hy){
  if (!p || p.dead) return;
  p.hp -= Math.max(1, dmg);
  p.hitT = 0.18;
  if (p.hp <= 0) breakPile(p, hx, hy);
}

/* 弹道擦过这一堆就扣血（**不拦子弹**：堆子是矮的，子弹照样飞过去） */
function pileAlongRay(x, y, ang, maxLen){
  if (!piles.length) return null;
  const dx = Math.cos(ang), dy = Math.sin(ang);
  let best = null, bt = maxLen;
  for (const p of piles){
    if (p.dead) continue;
    const t0 = rayEnter(x, y, dx, dy, p, maxLen);
    if (t0 > 0 && t0 < bt){ bt = t0; best = { p: p, t: t0, x: x + dx * t0, y: y + dy * t0 }; }
  }
  return best;
}

function pileHitAlongShot(b){
  if (!piles.length) return;
  const ang = Math.atan2(b.y - b.py, b.x - b.px);
  const dist = Math.hypot(b.x - b.px, b.y - b.py);
  const hit = pileAlongRay(b.px, b.py, ang, Math.max(4, dist));
  if (hit) damagePile(hit.p, (b.dmg || 10) * 0.5, hit.x, hit.y);   /* 散堆子，吃一半伤害 */
}

/* 能推的装饰物（瓦罐）不进墙表，所以子弹不会自己撞上去 ——
   和物资堆一个道理：在弹道里补一次"擦过就打碎它"。 */
function decorAlongRay(x, y, ang, maxLen){
  if (!decors || !decors.length) return null;
  const dx = Math.cos(ang), dy = Math.sin(ang);
  let best = null, bt = maxLen;
  for (const d of decors){
    if (d.dead || !(d.hp > 0)) continue;
    /* 只吃爆炸的东西（地上的木板 / 花）对子弹完全透明：不挡也不掉血 */
    if (d.blastOnly) continue;
    const fb = decorHitBox(d);
    const t0 = rayEnter(x, y, dx, dy, fb, maxLen);
    if (t0 > 0 && t0 < bt){ bt = t0; best = { d: d, t: t0, x: x + dx * t0, y: y + dy * t0 }; }
  }
  return best;
}

function decorHitAlongShot(b){
  const ang = Math.atan2(b.y - b.py, b.x - b.px);
  const dist = Math.hypot(b.x - b.px, b.y - b.py);
  const hit = decorAlongRay(b.px, b.py, ang, Math.max(4, dist));
  if (hit && hit.d._w) damageDecor(hit.d._w, b.dmg || 10, hit.x, hit.y, ang);
}

/* 这一箱是哪一型、按哪套参数走：没登记的箱型一律回落到通用木箱 */
function crateDef(w){
  const K = (typeof LOOT_CRATE !== 'undefined' && LOOT_CRATE.kinds) ? LOOT_CRATE.kinds : {};
  const k = (w && w.lootKind) || 'mixed';
  return K[k] || K.mixed || {};
}
function crateDur(w){
  const d = crateDef(w);
  return d.dur || (typeof LOOT_CRATE !== 'undefined' ? LOOT_CRATE.dur : 1.5);
}

function trySearchCrate(){
  if (!hasFeat('loot')) return;
  if (crateSearch){ cancelSearch('手停了 —— 搜刮中断'); return; }
  if (player.heal){ setMsg('先把药打完', 1.2); return; }
  if (playerInWall){ setMsg('人卡在墙里 —— 先出去', 1.2); return; }
  const w = crateNear();
  if (!w){ setMsg('附近没有能搜的箱子', 1.0); return; }
  /* 保险箱这一类：没有万能钥匙就开不了（以后要加密码/破译，在这里分支就行） */
  const _cd = crateDef(w);
  if (_cd.keyLock && !w.noKey){
    if (typeof keyCount === 'function' && keyCount() <= 0){
      setMsg('保险箱锁着 · 需要万能钥匙', 1.8);
      logInfo('loot', '保险箱：没有钥匙');
      return;
    }
    if (typeof useOneKey === 'function') useOneKey();
  }
  crateSearch = { w: w, t: 0, dur: crateDur(w), hp0: player.hp };
  w.searchT = 0;
  setMsg('搜刮中 · 别动、别开枪（再按 ' + keyLabel(BINDS.interact) + ' 取消）', 1.6);
  logInfo('loot', '开始搜刮' + ((w.label) || '箱子'));
}

/* 搜物资堆：读条比箱子慢一大截；搜光之后再按只会给一句提示 */
function trySearchPile(p){
  if (!hasFeat('loot')) return;
  const P = pileCfg();
  if (!P || !p || p.dead) return;
  if (crateSearch){ cancelSearch('手停了 —— 搜刮中断'); return; }
  if (player.heal){ setMsg('先把药打完', 1.2); return; }
  if (playerInWall){ setMsg('人卡在墙里 —— 先出去', 1.2); return; }
  if (p.uses <= 0){ setMsg(P.emptyMsg, 1.8); return; }
  crateSearch = { w: p, t: 0, dur: P.dur, hp0: player.hp, pile: true };
  p.searchT = 0;
  setMsg('翻找中 · 别动、别开枪（再按 ' + keyLabel(BINDS.interact) + ' 取消）', 1.6);
  logInfo('loot', '开始翻物资堆');
}

function cancelSearch(msg){
  if (!crateSearch) return;  const w = crateSearch.w;
  if (w) w.searchT = 0;
  crateSearch = null;
  setMsg(msg || '搜刮中断', 1.2);
  logInfo('loot', '搜刮中断');
}

/* 开箱：搜完 或 被打爆 都走这里。fromHit = 暴力开（浪费子弹，但一样掉东西） */
function openLootCrate(w, fromHit){
  if (!w || w.opened || w.dead) return;
  w.opened = true;
  w.searchT = 0;
  /* 变成"空箱子"：还挡人、还能再被打烂，但血量换成一档更低的 */
  const _od = crateDef(w).openHp || LOOT_CRATE.openHp;
  w.maxHp = _od;
  w.hp0 = _od;
  w.hp = _od;
  if (w.segs) w.segs = null;              /* 40×40 本来就不分段，保险起见清掉 */
  dropCrateLoot(w);
  /* 保险箱里锁着的那件东西：黑匣子不预先摆在地上，只从这一只箱子里出来 */
  if (w.blackbox && typeof loots !== 'undefined'){
    loots.push({ x: w.x + w.w / 2, y: w.y + w.h + 26, taken:false, cool:0.6, kind:'blackbox', newT:4.0 });
    if (typeof setMsg === 'function') setMsg('黑匣子在保险箱里 · 拿到就撤离', 3.2);
    if (typeof logInfo === 'function') logInfo('dz', '黑匣子已取出');
  }
  /* 盖子掀开的动静：木屑 + 一点灰 + 轻微镜头抖 */
  for (let i = 0; i < 10; i++){
    const a = fxRand(0, TAU), sp = fxRand(40, 190);
    brkChunks.push({x: w.x + w.w / 2 + fxRand(-8, 8), y: w.y + w.h / 2 + fxRand(-8, 8),
                    vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
                    s: fxRand(1.4, 3.2), rot: fxRand(0, TAU), vr: fxRand(-12, 12),
                    t: 0, dur: fxRand(0.45, 0.85), big: false});
  }
  brkShake = Math.max(brkShake, 0.08);
  /* 开箱：木头吱呀 + 盖子砸下（金属箱走金属音）。以前的 sfxCrack 很短很轻，
     玩家反馈「开箱没声音」，这里合成一记完整的，不再叠两声。 */
  if (typeof sfxCrateOpen === 'function') sfxCrateOpen(w);
  else sfxCrack(true);
  try { staticInvalidate(); } catch (err){ if (typeof reportErr === 'function') reportErr('30-thermal', err); }   /* 保险：万一还有别的地方把箱子烘进静态层 */
  if (crateSearch && crateSearch.w === w) crateSearch = null;
  setMsg(fromHit ? '箱子被打碎了 · 东西散了一地' : '搜刮完成', 1.5);
  logInfo('loot', (fromHit ? '打爆' : '搜开') + '战利品木箱');
}

/* 按权重摇一件配件（掉落用）。没配 ATTACH_LOOT 就返回第一件 */
function rollAttachId(){
  const T = (typeof ATTACH_LOOT !== 'undefined' && ATTACH_LOOT.length) ? ATTACH_LOOT : null;
  if (!T) { for (const k in ATTACH_DEF) return k; return null; }
  let total = 0;
  for (const d of T) total += (d.w || 1);
  let r = (typeof fxRand === 'function') ? fxRand(0, total) : Math.random() * total;
  for (const d of T){ r -= (d.w || 1); if (r <= 0) return d.id; }
  return T[T.length - 1].id;
}
/* 只摇"这把枪能装"的配件。没给 wid 就退化成全局池 */
function rollAttachIdFor(wid){
  const pool = [];
  let total = 0;
  for (const d of ATTACH_LOOT){
    if (!d || !attachDef(d.id)) continue;
    if (wid && !attachFits(d.id, wid)) continue;
    pool.push(d);
    total += (d.w || 1);
  }
  if (!pool.length) return null;
  let r = (typeof fxRand === 'function') ? fxRand(0, total) : Math.random() * total;
  for (const d of pool){ r -= (d.w || 1); if (r <= 0) return d.id; }
  return pool[pool.length - 1].id;
}

/* 按这一型箱子的掉落表抽 min~max 件，散在箱子周围（走原来的 loots 数组，拾取逻辑不动） */
/* 长条武器箱的掉落：50% 上下出枪 + 必定配一份对应子弹；没枪就退成子弹，小概率手雷。
   枪的型号权重、RPG 的"极小概率"、每把枪配几发子弹全在 data/lootcrate.js 的 weap 里。 */
function dropGunCrate(w, def){
  if (typeof loots === 'undefined' || !Array.isArray(loots)) return;
  const cx = w.x + w.w / 2, cy = w.y + w.h / 2;
  let slot = 0;
  const put = function(o){
    const a = (slot / 3) * TAU + fxRand(-0.6, 0.6);
    const rad = fxRand(30, 50) + slot * 5;
    slot++;
    loots.push(Object.assign({ x: cx + Math.cos(a) * rad, y: cy + Math.sin(a) * rad,
                               taken:false, cool:0.45, fromSearch:true, newT:3.2 }, o));
  };
  const rndN = function(r){
    const lo = r ? r[0] : 0, hi = r ? r[1] : 0;
    return lo + Math.floor(fxRand(0, (hi - lo) + 0.999));
  };

  /* ---- 1. 这一箱有没有枪 ---- */
  if (fxRand(0, 1) < (def.gunChance || 0)){
    /* 1a. 极小概率是火箭筒：管里是空的，只给 0~2 发火箭弹（一发一格，所以拆开掉） */
    if (def.rpg && fxRand(0, 1) < (def.rpg.chance || 0)){
      put({ kind:'gun', wid: def.rpg.wid || 'rpg', mag: 0 });
      const nr = rndN(def.rpg.n);
      for (let i = 0; i < nr; i++) put({ kind:'ammo', ammo:'rocket', n:1 });
      logInfo('loot', '武器箱：火箭筒 ×1 · 火箭弹 ×' + nr);
      return;
    }
    /* 1b. 普通枪：按权重抽一把 */
    const list = def.guns || [];
    if (list.length){
      let total = 0;
      for (const g of list) total += (g.w || 1);
      let roll = fxRand(0, total), pick = list[list.length - 1];
      for (const g of list){ roll -= (g.w || 1); if (roll <= 0){ pick = g; break; } }
      const WD = (typeof WEAPONS !== 'undefined' && WEAPONS[pick.wid]) ? WEAPONS[pick.wid] : null;
      put({ kind:'gun', wid: pick.wid, mag: WD ? WD.cap : undefined });
      /* 霰弹枪 / 突击步枪：一半概率连"配得上这把枪"的配件一起给
         （不然光有枪没管子没弹匣，配件很难凑齐）。按枪种过滤，别把霰弹收束器塞给步枪。 */
      if ((pick.wid === 'shotgun' || pick.wid === 'ar') &&
          typeof rollAttachIdFor === 'function' && fxRand(0, 1) < 0.5){
        const _aid = rollAttachIdFor(pick.wid);
        if (_aid) put({ kind:'attach', aid: _aid });
      }
      /* 配套子弹：枪吃哪种子弹就给哪种，数量在表里 */
      const ammoId = (WD && WD.ammo) || pick.ammo || 'pistol';
      put({ kind:'ammo', ammo: ammoId, n: rndN(pick.n) });
      logInfo('loot', '武器箱：' + (WD ? WD.name : pick.wid) + ' ×1 · ' +
              ((typeof ammoDef === 'function' && ammoDef(ammoId)) ? ammoDef(ammoId).label : ammoId));
      return;
    }
  }

  /* ---- 2. 没枪：子弹为主，小概率手雷 ---- */
  const T = def.noGun || [];
  if (!T.length) return;
  let total = 0;
  for (const d of T) total += (d.w || 1);
  let roll = fxRand(0, total), pick = T[T.length - 1];
  for (const d of T){ roll -= (d.w || 1); if (roll <= 0){ pick = d; break; } }
  if (pick.kind === 'nade') put({ kind:'nade' });
  else put({ kind:'ammo', ammo: pick.ammo || 'pistol', n: pick.n || 12 });
  /* 空手而归太亏：再补一小份同类子弹 */
  if (pick.kind !== 'nade' && fxRand(0, 1) < 0.45){
    put({ kind:'ammo', ammo: pick.ammo || 'pistol', n: Math.max(6, Math.round((pick.n || 12) * 0.5)) });
  }
  logInfo('loot', '武器箱：没有枪（' + (pick.kind === 'nade' ? '手雷' : '子弹') + '）');
}

function dropCrateLoot(w){
  if (typeof loots === 'undefined' || !Array.isArray(loots)) return;
  const def = crateDef(w);
  /* 空投：必给件 + 概率火箭筒，走自己的撒点（同心圆，间距够大，鼠标点得到） */
  if (def.airDrop){ dropAirCrate(w); return; }
  /* 长条武器箱：不是"抽几件"，而是"先判有没有枪" —— 走专属逻辑 */
  if (def.gunChance != null){ dropGunCrate(w, def); return; }
  const T = (def.table || ((typeof LOOT_CRATE !== 'undefined' && LOOT_CRATE.table) ? LOOT_CRATE.table : []))
    .filter(d => !d.v2 || thermalV2());     /* v2 专属掉落：老关卡直接不参与抽取 */
  if (!T.length) return;
  let total = 0;
  for (const d of T) total += (d.w || 1);
  const mn = (def.min != null) ? def.min : LOOT_CRATE.min;
  const mx = (def.max != null) ? def.max : LOOT_CRATE.max;
  const n = mn + Math.floor(fxRand(0, (mx - mn) + 0.999));
  for (let i = 0; i < n; i++){
    let roll = fxRand(0, total), pick = T[T.length - 1];
    for (const d of T){ roll -= (d.w || 1); if (roll <= 0){ pick = d; break; } }
    const a = (i / Math.max(1, n)) * TAU + fxRand(-0.5, 0.5);
    const rad = fxRand(26, 46);
    const lx = w.x + w.w / 2 + Math.cos(a) * rad;
    const ly = w.y + w.h / 2 + Math.sin(a) * rad;
    /* fromSearch：这箱子里刚翻出来的东西，**不许自动进背包** ——
       必须玩家自己按 E（或点它）才收，不然还没看清是什么就被吞了。 */
    const base = { x: lx, y: ly, taken: false, cool: 0.45, fromSearch: true, newT: 3.2 };
    if (pick.kind === 'med') loots.push(Object.assign(base, { kind:'med', rarity: pick.rarity || 'small' }));
    else if (pick.kind === 'ammo') loots.push(Object.assign(base, { kind:'ammo', ammo: pick.ammo || 'pistol', n: pick.n || 12 }));
    else if (pick.kind === 'armor'){
      const AD = (typeof ARMOR_DEF !== 'undefined' && ARMOR_DEF[pick.armor]) ? ARMOR_DEF[pick.armor] : null;
      const dur = AD ? AD.dur : 250;
      const rng = pick.durPct || [0.35, 0.90];
      loots.push(Object.assign(base, { kind:'armor', armor: pick.armor || 'light',
                                       hp: Math.max(1, Math.round(dur * rollDurPct(rng[0], rng[1]))),
                                       maxHp: dur }));
    } else {
      /* 背包 / 手雷 / 钥匙 / 枪 这些新东西：字段照抄，拾取逻辑各管各的 */
      const o = Object.assign(base, { kind: pick.kind });
      if (pick.bag) o.bag = pick.bag;
      if (pick.wid) o.wid = pick.wid;
      if (pick.n)   o.n   = pick.n;
      if (pick.mag) o.mag = pick.mag;
      if (pick.gear) o.gear = true;
      if (pick.aid) o.aid = pick.aid;
      loots.push(o);
    }
  }
}

/* 每帧推进读条；移动 / 挨打 都会断（开枪在 tryShoot 里断） */
function updateCrateSearch(dt){
  if (!crateSearch) return;
  const w = crateSearch.w;
  if (!w || w.dead){ crateSearch = null; return; }
  if (!crateSearch.pile && w.opened){ crateSearch = null; return; }
  /* 只有「离开搜索范围」才打断：挨打、走动、开枪都不打断（玩家自己定）。
     想停只能走开，或者再按一次 E 主动取消。 */
  const _rg = crateSearch.pile ? (pileCfg() ? pileCfg().range : 52) : LOOT_CRATE.range;
  if (distToRect(player.x, player.y, w) > _rg + 6){ cancelSearch('走远了 —— 搜刮中断'); return; }
  crateSearch.t += dt;
  w.searchT = Math.min(1, crateSearch.t / crateSearch.dur);
  if (typeof sfxCrateRustle === 'function') sfxCrateRustle();
  if (crateSearch.t >= crateSearch.dur){
    if (crateSearch.pile){
      /* 物资堆：每搜一次必掉 1 件；次数归零时给一句"没东西了" */
      const p = w;
      const P = pileCfg();
      searchPileOnce(p);
      crateSearch = null;
      p.searchT = 0;
      if (p.uses <= 0 && P) setMsg(P.emptyMsg, 1.8);
      else setMsg(pileFoundMsg(p), 1.6);
    } else openLootCrate(w, false);
  }
}

/* 屏幕中下那条读条：和打药一个位置，玩家不用重新学 */
function drawCrateBar(){
  if (!crateSearch) return;
  const p = clamp(crateSearch.t / crateSearch.dur, 0, 1);
  const bw = 240, bh = 12;
  const bx = Math.round(W/2 - bw/2), by = Math.round(H/2 + 64);
  ctx.save();
  ctx.fillStyle = 'rgba(8,12,18,0.72)';
  roundRect(bx - 3, by - 3, bw + 6, bh + 6, 5); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.14)';
  roundRect(bx, by, bw, bh, 4); ctx.fill();
  ctx.fillStyle = '#e8c579';
  roundRect(bx, by, Math.max(2, bw * p), bh, 4); ctx.fill();
  ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(246,236,214,0.96)';
  ctx.fillText('搜刮中 ' + Math.round(p * 100) + '%', bx + bw/2, by - 7);
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(226,214,186,0.85)';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillText('走开会中断 · 按 ' + keyLabel(BINDS.interact) + ' 取消', bx + bw/2 - 78, by + bh + 15);
  ctx.restore();
}

/* 每局开始：把可破坏的墙装回 L.walls，血量和裂纹一并重置 */
function initBreakables(L){
  crateSearch = null;                 /* 换关 / 重开：搜刮读条一律清掉 */
  /* 第 52 轮：先把 placed 里的房间模板摆上（只跑一次），后面所有初始化都当它们本来就写在关卡里 */
  if (typeof placeRooms === 'function') placeRooms(L);
  /* 死亡地带的保险箱挪到 allWalls 建好之后再摆（见下）：
     早摆的时候房间墙还没并进 L.walls，dzPlaceSafes 的 hit() 看不见它们，
     于是 8/12 只箱子会摞在墙上。实测"同一份逻辑晚一点摆 = 0 重叠"。 */
  /* 死亡地带：门口别站东西。掩体是沿路撒的，撒的时候门还没展开，
     所以等 placeRooms 铺完再回头清一遍：压在门洞中段上的小掩体直接撤掉。 */
  if (L.rules && L.rules.dz && !L._doorClearDone){
    L._doorClearDone = 1;
    const doorMids = [];
    for (const d of (L.doors || [])){
      /* 门洞 + 门两侧各 46px 的"进出一小段"：玩家要能走到门口，家具堵在门口一样是死门 */
      const pad = 46;
      const horiz = d.w >= d.h;                 /* 横着的门（宽门）→ 左右各留一条通道 */
      doorMids.push({ x: d.x - (horiz ? pad : 10), y: d.y - (horiz ? 10 : pad),
                      w: d.w + (horiz ? pad * 2 : 20), h: d.h + (horiz ? 20 : pad * 2) });
    }
    const dead = new Set();
    const blockOne = (b) => {
      for (const m of doorMids){
        const ox = Math.min(m.x + m.w, b.x + b.w) - Math.max(m.x, b.x);
        const oy = Math.min(m.y + m.h, b.y + b.h) - Math.max(m.y, b.y);
        if (ox > 2 && oy > 2) return true;
      }
      return false;
    };
    for (const b of (L.brk || [])){
      if (b.rocketTurret) continue;
      if (!b.t) continue;                           /* 只搬掩体（crate/panel 这些带 t 的），承重墙改出来的可拆墙不动 */
      if (blockOne(b)) dead.add(b);
    }
    /* 家具（写字桌/瓦罐/柜子）堵在门口同样出不去：这些在 L.walls 里带 decor 标记 */
    for (const w of (L.walls || [])){
      if (!w.decor || w.rocketTurret) continue;
      if (blockOne(w)) dead.add(w);
    }
    if (dead.size){
      L.brk = L.brk.filter(b => !dead.has(b));
      L.walls = L.walls.filter(w => !dead.has(w));
    }
  }
  /* 死亡地带：把一部分薄外墙改成可拆的（rules.breach）。
     房子多了光找门太慢，打墙进屋才有破坏的爽感；只转薄墙，承重的大块墙不动。 */
  if (L.rules && L.rules.breach && !L._breachDone){
    L._breachDone = 1;
    const keep = [];
    for (const w of L.walls){
      const thin = (w.w <= 56 && w.h >= 60 && w.h <= 520) || (w.h <= 56 && w.w >= 60 && w.w <= 520);
      const ok = thin && !w.brk && !w.decor && !w.loot && !w.glass && !w.rocketTurret && !w.t && !w.door;
      /* 2/3 转成可拆墙：死亡地带主打"打墙进屋"，只拆三分之一房子都进不去 */
      if (ok && (((w.x * 7 + w.y * 13) | 0) % 3 !== 2)){
        (L.brk || (L.brk = [])).push({ x: w.x, y: w.y, w: w.w, h: w.h });
      } else keep.push(w);
    }
    L.walls = keep;
    /* 兜底：每栋摆出来的楼至少留两面能砸的外墙。
       门要是被另一栋楼/家具挤住，至少还能打墙进去 —— 不然这栋楼就是死的。 */
    const _foot = L._dzFoot || [];
    for (const f of _foot){
      let need = 4;
      /* 先按"薄墙"找；找不够就放宽到任意厚度的外墙 —— 有栋楼一层薄墙都没有，
         不兜这一步它就是一栋完全打不进去的铁屋（用户实测遇到过）。 */
      for (let pass = 0; pass < 2 && need > 0; pass++){
        for (let i = L.walls.length - 1; i >= 0 && need > 0; i--){
          const w = L.walls[i];
          const thin = (w.w <= 56 && w.h >= 60 && w.h <= 520) || (w.h <= 56 && w.w >= 60 && w.w <= 520);
          if (pass === 0 && !thin) continue;
          if (w.brk || w.decor || w.loot || w.glass || w.rocketTurret || w.t || w.door) continue;
          if (w.w > 900 || w.h > 900) continue;         /* 别把整面外框墙当成一间房的门 */
          const onEdge = Math.abs(w.x - f.x) < 4 || Math.abs(w.y - f.y) < 4 ||
                         Math.abs(w.x + w.w - (f.x + f.w)) < 4 ||
                         Math.abs(w.y + w.h - (f.y + f.h)) < 4;
          if (!onEdge) continue;
          L.brk.push({ x: w.x, y: w.y, w: w.w, h: w.h });
          L.walls.splice(i, 1);
          need--;
        }
      }
    }
  }
  /* 死亡地带：南门里侧这条通道不许有楼。
     出过一次野房被环形外挪推到门口，北墙横在两个射口前面，炮塔打出去全是自己人的墙。 */
  if (L.rules && L.rules.dz && !L._gateClearDone){
    L._gateClearDone = 1;
    const gate = { x: 2740, y: 2130, w: 560, h: 210 };
    L.walls = L.walls.filter(w => w.rocketTurret ||
      !(w.x < gate.x + gate.w && gate.x < w.x + w.w && w.y < gate.y + gate.h && gate.y < w.y + w.h));
    /* 门口这栋楼既然被拆了，就别再算"摆到位的楼"：否则"每栋楼两面可拆墙"那条检查会指着一栋不存在的楼 */
    if (L._dzFoot) L._dzFoot = L._dzFoot.filter(f =>
      !(f.x < gate.x + gate.w && gate.x < f.x + f.w && f.y < gate.y + gate.h && gate.y < f.y + f.h));
  }
  decals = [];                        /* 残留物只留本局，换关清空 */
  /* 物资堆：只有写了 pileSpawn 的关卡才刷（现在只有测试区），每局位置随机 */
  if (typeof initPiles === 'function') initPiles(L);
  /* 铁丝网：关卡里写了 wires:[] 才有；它不进 L.walls，只是地上的一片"扎人的地" */
  if (typeof initWires === 'function') initWires(L);
  /* 装饰物：写字桌/瓦罐/椅子这些挡人的会塞进 L.walls，
     必须赶在下面 allWalls 缓存之前铺，否则寻路看不见它们 */
  if (typeof initDecors === 'function') initDecors(L);
  /* 屋顶：只是"盖子"，不进 L.walls，所以放在装饰物之后、缓存墙表之前都无所谓；
     放这儿是为了跟其他环境物件排在一起，一眼能找到 */
  if (typeof initRooms === 'function') initRooms(L);
  if (typeof initRoofs === 'function') initRoofs(L);
  /* 第 12 轮：墙 / 掩体开始走类型清单（data/covers.js 的 COVER_DEF）。
     带 t 的条目按预设展开成完整矩形；不带 t 的老数据一个字段都不动。
     只展开一次（_c 标记），重复进同一关不会越滚越大。 */
  for (let i = 0; i < L.walls.length; i++){
    const w = L.walls[i];
    if (w.t && !w._c){ const m = coverMake(w.t, w); m._c = 1; L.walls[i] = m; }
  }
  /* 关卡自带一批小掩体（data/coverLayout.js）：第一次进这关时铺进去，
     之后重开沿用同一批对象，位置不会每局乱跳。 */
  if (!L._covDone && typeof COVER_LAYOUT !== 'undefined'){
    L._covDone = 1;
    for (let g = 0; g < COVER_LAYOUT.length; g++){
      if (COVER_LAYOUT[g].name !== L.name) continue;
      const items = COVER_LAYOUT[g].items;
      for (let k = 0; k < items.length; k++) L.walls.push(coverMake(items[k].t, items[k]));
      break;
    }
    navCache = null;                    /* 网格得按新墙重建一次 */
  }
  if (!L.allWalls) L.allWalls = L.walls.filter(function(w){ return !w.brk; }).slice();
  L.walls = L.allWalls.slice();

  /* 保险箱：等墙都并进 L.walls 之后再摆，摆完同时补进 allWalls，
     否则下一局 reset() 用 L.allWalls.slice() 重建 walls 时箱子会凭空消失。 */
  if (L.rules && L.rules.dz && typeof dzPlaceSafes === 'function'){
    L._safesDone = 1;
    const _before = L.walls.length;
    L.dzSafeCount = dzPlaceSafes(L, 12).length;
    for (let _i = _before; _i < L.walls.length; _i++) L.allWalls.push(L.walls[_i]);
  }
  /* 关卡对象是"一局接一局复用"的（cur() 直接返回 LEVELS[i]，不克隆），
     所以墙上的"这一局才有的状态"必须在这里手动归零 —— 否则上一局开过的保险箱
     重开还是开着的。（可破坏的墙每局会重建，不存在这个问题。） */
  for (const w of L.walls){
    if (w.loot){ w.opened = false; w.searchT = 0; }
    if (!w.brk){ w.hitT = 0; w.dead = false; }
  }
  brkChunks = []; brkDust = []; brkShake = 0;
  const list = L.brk || [];
  for (let i = 0; i < list.length; i++){
    const b = list[i];
    const bd = b.t ? coverMake(b.t, b) : b;      /* 写 t 的按清单补尺寸/材质 */
    const w = {
      x: bd.x, y: bd.y, w: bd.w, h: bd.h, brk: true, mat: bd.mat || 'stone',
      cov: bd.cov, ch: bd.ch, sight: bd.sight || 'high',   /* 第 58 轮：这个字段一丢，木箱就会重新挡玩家视野 */
      loot: !!bd.loot, lootKind: bd.lootKind || null, opened: false, searchT: 0,     /* 战利品木箱：这几个字段不能被展开时丢掉 */
      maxHp: bd.hp || BRK_HP, hp: bd.hp || BRK_HP,
      seed: 11 + i * 37 + (b.x | 0) * 3 + (b.y | 0) * 7,
      hitT: 0, dead: false, cracks: null
    };
    makeCracks(w);          /* 裂纹形状开局就定死，别等到画的时候再摇 */
    makeSegs(w);            /* 够长的墙切成几段：打哪段碎哪段 */
    L.walls.push(w);
  }
  /* 玻璃：一条数据一块，不走裂纹那套 */
  const gl = L.glass || [];
  for (let i = 0; i < gl.length; i++){
    const g = gl[i];
    const gd = g.t ? coverMake(g.t, g) : g;
    L.walls.push({x: gd.x, y: gd.y, w: gd.w, h: gd.h, cov: gd.cov,
                  brk: true, glass: true,
                  maxHp: 1, hp: 1, hitT: 0, dead: false, sndT: 0, cracks: null});
    navPatchRect(L, g.x, g.y, g.w, g.h);   /* 有玻璃就把那一块刷成墙，别的别动 */
  }
}

/* 准星旁的命中标记：打中一瞬蹦出来、随即收回。这是"确认打到了"最快的一条信号 */
/* 刀光：一道扫过去的弧，0.2 秒就没了，纯视觉 */
function drawMeleeStamina(){
  /* 头顶那条弧形体力条：拿刀才显示；越低越红、越低越闪 */
  if (!player || !player.gun || player.gun.kind !== 'melee') return;
  const _max = player.meleeStaMax || 100;
  const _r = clamp((player.meleeSta || 0) / _max, 0, 1);
  const sx = player.x - cam.x, sy = player.y - cam.y - (player.r + 16);
  const R = 15, a0 = Math.PI * 0.78, a1 = Math.PI * 2.22;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.strokeStyle = 'rgba(8,12,18,0.60)'; ctx.lineWidth = 5.4;
  ctx.beginPath(); ctx.arc(sx, sy, R, a0, a1); ctx.stroke();
  const _hue = Math.round(130 * _r);                 /* 0 = 红，130 = 绿，中间自然过渡 */
  const _blink = (_r <= 0.28) ? (0.5 + 0.5 * Math.abs(Math.sin((timeAlive || 0) * 9))) : 1;
  ctx.globalAlpha = _blink;
  ctx.strokeStyle = 'hsl(' + _hue + ',85%,' + (_r <= 0.28 ? 68 : 58) + '%)';
  ctx.lineWidth = 3.6;
  ctx.shadowColor = ctx.strokeStyle; ctx.shadowBlur = 6;
  if (_r > 0.002){
    ctx.beginPath(); ctx.arc(sx, sy, R, a0, a0 + (a1 - a0) * _r); ctx.stroke();
  }
  ctx.restore();
}

function drawMeleeArc(){
  drawMeleeStamina();
  /* 突进拖尾：一串越来越淡的重影，让人看得出“冲出去了” */
  for (const _tr of meleeTrail){
    const _k = _tr.t / _tr.dur;
    const _px = _tr.x - cam.x, _py = _tr.y - cam.y;
    ctx.save();
    /* 一小段拖影条 + 一个越来越淡的重影圆，看起来就是“冲出去了” */
    ctx.globalAlpha = (1 - _k) * 0.60;
    ctx.strokeStyle = 'rgba(186,222,255,0.95)';
    ctx.lineWidth = player.r * 1.5 * (1 - _k);
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(_px, _py);
    ctx.lineTo(_px - Math.cos(_tr.a) * 26 * (1 - _k), _py - Math.sin(_tr.a) * 26 * (1 - _k));
    ctx.stroke();
    ctx.globalAlpha = (1 - _k) * 0.55;
    ctx.fillStyle = 'rgba(196,230,255,0.95)';
    ctx.beginPath();
    ctx.arc(_px, _py, player.r * (1.05 - 0.45*_k), 0, TAU);
    ctx.fill();
    ctx.restore();
  }
  if (meleeT <= 0) return;
  const k = 1 - meleeT / 0.20;
  const sx = player.x - cam.x, sy = player.y - cam.y;
  /* 弯刀：挥出去的那一下带一道残影（刀身形状的鬼影），越早越淡 */
  if (player.gun && (player.gun.wid === 'dao' || player.gun.wid === 'knife')){
    const _n = player.gun.wid === 'dao' ? 4 : 3;
    for (let i = 0; i < _n; i++){
      const kk = Math.min(1, k + i * 0.15);
      const aa = meleeA - 1.5 + kk * 2.1;
      ctx.save();
      ctx.translate(sx + Math.cos(aa) * 22, sy + Math.sin(aa) * 22);
      ctx.rotate(aa);
      ctx.globalAlpha = (1 - k) * 0.46 * (1 - i * 0.18);
      ctx.fillStyle = player.gun.wid === 'dao' ? 'rgba(220,240,255,0.9)' : 'rgba(226,240,255,0.75)';
      ctx.beginPath();
      ctx.moveTo(-8.0, -3.0);
      ctx.quadraticCurveTo(7.0, -7.0, 25.0, -0.9);
      ctx.quadraticCurveTo(8.5, 2.5, -8.0, 4.3);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }
  ctx.save();
  ctx.globalAlpha = (1 - k) * 0.75;
  ctx.strokeStyle = 'rgba(226,240,255,0.9)';
  ctx.lineWidth = 3.2;
  ctx.lineCap = 'round';
  const a0 = meleeA - 0.75 + k * 1.5;
  ctx.beginPath();
  ctx.arc(sx, sy, 62, a0 - 0.55, a0 + 0.55);
  ctx.stroke();
  ctx.restore();
}

function drawHitMark(){
  drawMeleeArc();
  if (!hitMarks.length) return;
  ctx.save();
  ctx.lineCap = 'round';
  for (const m of hitMarks){
    const k = m.t / m.dur, a = 1 - k;
    /* 一出来就很大、往外张，比一个固定的叉子有力得多 */
    const r0 = 5 + k*10, r1 = r0 + (m.kill ? 16 : (m.crit ? 14 : 9));
    ctx.globalAlpha = a;
    ctx.strokeStyle = m.kill ? 'rgba(255,116,64,0.98)'
                    : (m.crit ? 'rgba(255,214,90,0.98)' : 'rgba(255,255,255,0.98)');
    ctx.lineWidth = m.kill ? 4.2 : (m.crit ? 3.8 : 3.0);
    /* 原来这里是 shadowBlur=10~16 做光晕，命中一多（霰弹、连发）就是
       一次几百像素的高斯模糊。改成「底层宽而淡 + 上层亮」两遍描边，
       观感接近，代价只有多一遍 stroke。 */
    const glowCol = m.kill ? 'rgba(255,80,30,0.35)'
                  : (m.crit ? 'rgba(255,190,40,0.32)' : 'rgba(255,255,255,0.26)');
    for (let i=0;i<4;i++){
      const ang = -Math.PI/4 + i*Math.PI/2;
      ctx.beginPath();
      ctx.moveTo(mouse.x + Math.cos(ang)*r0, mouse.y + Math.sin(ang)*r0);
      ctx.lineTo(mouse.x + Math.cos(ang)*r1, mouse.y + Math.sin(ang)*r1);
      ctx.strokeStyle = glowCol;
      ctx.lineWidth = (m.kill ? 13 : (m.crit ? 12 : 10));
      ctx.stroke();
      ctx.strokeStyle = m.kill ? 'rgba(255,116,64,0.98)'
                      : (m.crit ? 'rgba(255,214,90,0.98)' : 'rgba(255,255,255,0.98)');
      ctx.lineWidth = m.kill ? 4.2 : (m.crit ? 3.8 : 3.0);
      ctx.stroke();
    }
  }
  ctx.restore();
}
let invHover = -1;      /* 背包里鼠标停在哪一格 */
let invHoverIt = null;  /* 鼠标停在哪件物资上（R 旋转用它） */
/* 武器表：一把枪的脾气全写在这。
   手枪 —— 一把一把点，稳。
   霰弹枪 —— 一枪 8 颗弹丸，贴脸能一枪打死，代价是后坐力会把你整个人往后推半米。
   突击步枪 —— 按住左键连发，单发不疼，但压得住、打得远。 */
/* ---------------- 弹药：一种子弹一条数据 ----------------
   加一种新子弹 = 在 AMMO 里加一条，再让某把枪 ammo 指过来，其它地方都不用动。
   box = 地上一个弹药箱给多少发；pal/dark 是画图标用的颜色。 */
/* AMMO 已移到 data/items.js */

function ammoDef(t){
  if (t === 'smoke') return {label:'烟雾', short:'烟', box:1, pal:'#c9d4e2', dark:'#2b3644'}; return AMMO[t] || AMMO.pistol; }
function ammoOf(g){
  if (!(player && player.ammo && g)) return 0;
  if (ar) return 9999;                       /* 战斗，爽！！不打子弹仗 */
  return player.ammo[(g.ammo || 'pistol')] || 0;
}
function addAmmo(t, n){
  /* ver3：子弹也是背包里的一件件东西，塞不进去就是塞不进去 */
  if (bagGridOn()){
    bagAddAmmo(t, n);
    return (player.ammo && player.ammo[t]) || 0;
  }
  if (!player.ammo) player.ammo = {};
  /* 备弹上限 = 基础 × 背包倍率，满了就不再往上堆（不然"背包大小"就没意义了） */
  const cap = (typeof ammoCapOf === 'function') ? ammoCapOf(t) : 9999;
  player.ammo[t] = Math.min(cap, (player.ammo[t] || 0) + n);
  return player.ammo[t];
}
function startingAmmo(wids){
  const o = {};
  for (const k of AMMO_ORDER) o[k] = 0;
  /* 只给手里真有的那几种枪配子弹：只带手枪的关卡不会白送一包霰弹 */
  const list = (wids && wids.length) ? wids : WEAPON_ORDER;
  for (const w of list){
    if (!WEAPONS[w] || !WEAPONS[w].ammo) continue;   /* 刀不吃子弹 */
    o[WEAPONS[w].ammo] = Math.max(o[WEAPONS[w].ammo], WEAPONS[w].reserve);
  }
  return o;
}

/* WEAPONS 已移到 data/items.js */
const GUN_DEF = WEAPONS.pistol;          /* 老代码还按这个名字读默认值 */
/* WEAPON_ORDER 已移到 data/items.js（唯一出处）—— 加新枪去那里补 id */

function gunDef(g){ return (g && WEAPONS[g.wid]) || WEAPONS.pistol; }

/* ---- 武器基础物理参数收口（m27992）----
   敌我战斗逻辑仍是两套（伤害/命中各自吃难度）；这里只管"这把枪物理上是什么"：
   弹匣多大、射速基准、换弹多久、端起来多慢、一发几颗弹丸。
   任何字段缺失或类型不对 → 回退 WEAPON_CORE_DEF 的默认值 + 报警，绝不让 undefined 流进公式。 */
let weaponCoreWarnCount = 0;
const _WC_WARNED = Object.create(null);
function weaponCore(wid){
  const key = wid || 'pistol';
  let W = (typeof WEAPONS !== 'undefined' && WEAPONS[key]) || null;
  if (!W && typeof WEAPONS !== 'undefined' && WEAPONS.pistol){
    W = WEAPONS.pistol;                    /* 不认识的枪按手枪算，和 gunDef 的兜底保持一致 */
    weaponCoreWarnCount++;
    if (!_WC_WARNED[key + '.unknown']){
      _WC_WARNED[key + '.unknown'] = 1;
      console.warn('[weapon] 未知武器 ' + key + '，按手枪处理');
    }
  }
  const N = (W && W.npc) ? W.npc : {};
  const D = (typeof WEAPON_CORE_DEF !== 'undefined') ? WEAPON_CORE_DEF : null;
  const raw = {
    cap:       W ? W.cap : undefined,
    rof:       W ? W.rof : undefined,
    reloadDur: W ? W.reloadDur : undefined,
    moveK:     W ? W.moveK : undefined,
    npcRof:    N.rof,    npcDmg: N.dmg,
    npcSpread: N.spread, npcSpd: N.spd,
    pellets:   N.pellets,
    kind:      W ? W.kind : undefined
  };
  const out = { wid: key };
  for (const k in raw){
    const spec = (D && D[k]) ? D[k] : { type:'num', def: 1 };
    const v = raw[k];
    const ok = (spec.type === 'str')
      ? (typeof v === 'string' && v.length > 0)
      : (typeof v === 'number' && isFinite(v));
    if (ok){ out[k] = v; continue; }
    out[k] = spec.def;
    if (!spec.req) continue;          /* 可省字段：静默取默认值，不算数据 bug */
    weaponCoreWarnCount++;
    const wkey = key + '.' + k;
    if (!_WC_WARNED[wkey]){
      _WC_WARNED[wkey] = 1;
      console.warn('[weapon] ' + wkey + ' 缺失或类型不对，已回退 ' + JSON.stringify(spec.def));
    }
  }
  out.rocket = !!(W && W.rocket);
  out.single = isSingleShotWeapon(W);
  out.melee  = (out.kind === 'melee');
  out.throw  = (out.kind === 'throw');
  return out;
}

/* 敌人这一侧"从武器 + 难度"推出来的数（玩家侧永远读 WEAPONS[wid]，不经过这里） */
function npcStatsOf(wid, diff){
  const c = weaponCore(wid);
  const dd = diff || (typeof diffName === 'string' ? diffName : 'normal');
  const C = (typeof CFG !== 'undefined' && CFG) ? CFG : {};
  const k = (typeof RPG_RELOAD_K !== 'undefined' && RPG_RELOAD_K[dd]) || 1;
  return {
    wid: c.wid,
    cap: c.cap, rof: c.rof, reloadDur: c.reloadDur, moveK: c.moveK,
    pellets: c.pellets, kind: c.kind,
    rocket: c.rocket, single: c.single, melee: c.melee, throw: c.throw,
    dmg:       Math.max(0, (C.eDmg || 0) * c.npcDmg),
    spreadDeg: Math.max(0, (C.spread || 0) * c.npcSpread),
    bulletSpd: Math.max(1, (C.bulletSpd || 1200) * c.npcSpd),
    fireGap:   1 / Math.max(0.05, Math.min(3.6, (C.fireRate || 1) * c.npcRof)),
    reloadTime: c.rocket ? Math.max(0.2, c.reloadDur * k) : Math.max(0.05, C.reload || 1)
  };
}
function makeGun(wid, mag){
  const d = WEAPONS[wid] || WEAPONS.pistol;
  return {wid:d.wid, name:d.name, ammo:d.ammo, kind:d.kind,
          mag:(mag === undefined ? d.cap : mag), cap:d.cap,
          cap0:d.cap, reloadDur0:d.reloadDur,
          dmg:d.dmg, cd:0, rof:d.rof, reloading:0, reloadDur:d.reloadDur,
          pellets:d.pellets, spread:d.spread, recoil:d.recoil, kick:d.kick, auto:d.auto,
          rocket:d.rocket, flare:d.flare, tool:d.tool, moveK:d.moveK};
}

/* ---------------- 枪的"实例 key" ----------------
   以前 player.guns 直接按型号存（player.guns.rpg），一个型号只能有一把。
   现在第一把仍然用型号当 key（老存档、'smoke' 这些都不受影响），
   第二把起存成 'rpg#2'、'rpg#3'…… 型号（model）只用来查 WEAPONS / 分类 / 画图标。 */
function gunModel(key){
  const k = (key === null || key === undefined) ? '' : String(key);
  const i = k.indexOf('#');
  return i < 0 ? k : k.slice(0, i);
}
function gunNewKey(wid){
  const G = (player && player.guns) || {};
  if (!G[wid]) return wid;
  for (let i = 2; i < 99; i++){ const k = wid + '#' + i; if (!G[k]) return k; }
  return wid + '#99';
}
function gunKeyOf(g){
  const G = (player && player.guns) || {};
  for (const k in G){ if (G[k] === g) return k; }
  return (g && g.wid) || null;
}
function gunCountModel(wid){
  const G = (player && player.guns) || {};
  let n = 0;
  for (const k in G){ if (gunModel(k) === wid) n++; }
  return n;
}
/* MED_DEF/AMMO_BOX 已移到 data/items.js */


/* ---------------- 地上能捡的东西：一张表 ----------------
   以后加一种新物资 = 往这儿加一条（怎么收 take、怎么画 draw、背包里怎么写 info），
   拾取循环、渲染、背包都不用动。take 返回 false = 这个场合收不了，当普通物资。 */
function drawLootSmoke(x, y){
  /* 地上那颗烟雾弹：和手里拿的、背包里的共用 drawSmokeCanister，形状统一 */
  drawSmokeCanister(x, y, 1, 0, false);
}

/* =========================================================================
   防弹衣
   -------------------------------------------------------------------------
   三层数值在 data/items.js 的 ARMOR_DEF 里，这里只做三件事：
     1. armorDef(kind)      把 kind 换成配置
     2. equipArmor(kind)    穿上（同款或更好的才换，破烂的不捡）
     3. absorbArmor(dmg)    唯一入口：先让甲吃，剩下的才落到血上
   所有玩家掉血都必须走 absorbArmor，否则甲就白穿了。
   ========================================================================= */
function armorDef(kind){
  if (typeof ARMOR_DEF === 'undefined') return null;
  return ARMOR_DEF[kind] || null;
}
/* 两个 #rrggbb 按比例混一色：t=0 取 a，t=1 取 b。用来把鲜艳的甲色压进夜色里。 */
function mixHex(a, b, t){
  const pa = parseInt(String(a).replace('#',''), 16), pb = parseInt(String(b).replace('#',''), 16);
  if (isNaN(pa) || isNaN(pb)) return a;
  const ch = (sh) => Math.round(((pa >> sh) & 255) * (1 - t) + ((pb >> sh) & 255) * t);
  const hex2 = (n) => ('0' + clamp(n, 0, 255).toString(16)).slice(-2);
  return '#' + hex2(ch(16)) + hex2(ch(8)) + hex2(ch(0));
}
function armorPct(){
  const a = player && player.armor;
  return (a && a.maxHp > 0) ? clamp(a.hp / a.maxHp, 0, 1) : 0;
}
function equipArmor(kind){
  const A = armorDef(kind);
  if (!A) return false;
  const cur = player.armor;
  /* 已经有更好的就别换：破烂不捡，免得不小心把精锐换成轻型 */
  if (cur && cur.kind === kind) return false;
  player.armor = { kind: kind, label: A.label, hp: A.dur, maxHp: A.dur, reduce: A.reduce };
  sfxPick();
  setMsg('穿上 ' + A.label + ' · 减伤 ' + Math.round(A.reduce * 100) + '% · 耐久 ' + A.dur, 2.0);
  logInfo('item', '穿上 ' + A.label + '（减伤 ' + Math.round(A.reduce*100) + '%，耐久 ' + A.dur + '）');
  return true;
}
/* 护甲碎裂：一声闷裂 + 一圈红光 */
function breakArmorFx(){
  const a = player.armor;
  const lx = player.x, ly = player.y;
  player.armor = null;
  armorBreakT = 1.0;
  hitFlash = Math.max(hitFlash, 0.75);
  camShake = Math.max(camShake, 0.55);
  /* 玻璃渣一样的高频裂声 + 一记低频闷响 */
  noiseBurst(0.34, 4200, 0.22, 0.9);
  noiseBurst(0.24, 1600, 0.34, 1.4);
  beep(120, 0.26, 'sawtooth', 0.16, 46);
  for (let i = 0; i < 14; i++){
    spawnPart(lx, ly, fxRand(0, TAU), fxRand(60, 260), fxRand(0.18, 0.42), 'mspark', fxRand(1.2, 2.4));
  }
  spawnPart(lx, ly, 0, 0, 0.22, 'ring', 16);
  setMsg('防弹衣碎了！', 1.6);
  logWarn('item', '防弹衣碎了（' + (a ? a.label : '') + '）');
}
/* 返回真正落到血上的伤害；甲先扛 */
function absorbArmor(dmg, src){
  const a = player && player.armor;
  if (!a) return dmg;
  const r = armorSoak(a, dmg, src);
  if (r.broke) breakArmorFx();
  return r.hp;
}
/* 测试用：一键穿精锐 */
function giveEliteArmor(){
  player.armor = null;
  const ok = equipArmor('elite');
  if (ok) setMsg('测试：精锐防弹衣已上身 · 减伤 50% / 耐久 250', 2.4);
  return ok;
}

/* ---------------- 背包（只决定"能装多少"，不决定颜色） ---------------- */
function bagDef(kind){
  if (kind === 'none') return BAG_NONE;
  if (typeof BAG_DEF === 'undefined') return null;
  return BAG_DEF[kind] || BAG_DEF[BAG_DEFAULT] || null;
}
function bagSlots(){
  const B = (player && player.bag) ? bagDef(player.bag.kind) : bagDef(BAG_DEFAULT);
  return B ? B.slots : 6;
}
/* 随身占格：ver2 是"一件一格"的糊涂账（药 / 手雷 / 烟雾各算一格，子弹另算）；
   ver3 直接数占了多少格 —— 子弹也算，甲一次吃 9 格 */
function bagUsed(){
  if (!player) return 0;
  if (bagGridOn()){
    let n = 0;
    for (const it of bagItems()) n += (it.w || 1) * (it.h || 1);
    return n;
  }
  const m = player.meds || {};
  return (m.small || 0) + (m.big || 0) + (player.grenades || 0) + ((player.guns && player.guns.smoke) ? player.guns.smoke.mag : 0);
}
function bagHasRoom(n){
  n = (n === undefined) ? 1 : n;
  if (bagGridOn()){ const g = bagGridSize(); return bagUsed() + n <= g.cap; }
  return bagUsed() + n <= bagSlots();
}
function equipBag(kind){
  const B = bagDef(kind);
  if (!B) return false;
  const cur = player.bag;
  if (cur && cur.kind === kind) return false;
  player.bag = { kind: kind, label: B.label, slots: B.slots, ammoK: B.ammoK };
  /* ver3：格子形状变了，装不下的东西得重新码一遍（放不下的掉地上，不许凭空消失） */
  if (typeof bagRefit === 'function') bagRefit();
  /* 换包之后备弹上限可能变小，超出的部分直接削掉（不许靠换小包变出子弹） */
  if (player.ammo){
    for (const t of (typeof AMMO_ORDER !== 'undefined' ? AMMO_ORDER : ['pistol','shotgun','rifle'])){
      const cap = ammoCapOf(t);
      if (player.ammo[t] > cap) player.ammo[t] = cap;
    }
  }
  sfxPick();
  setMsg('背上 ' + B.label + ' · 随身 ' + B.slots + ' 格 · 备弹 ×' + B.ammoK.toFixed(1), 2.0);
  logInfo('item', '背上 ' + B.label + '（' + B.slots + ' 格，备弹 ×' + B.ammoK + '）');
  return true;
}
/* 某口径的备弹上限：基础 × 背包倍率（ver2）；ver3 没有上限这一说 —— 装不下就是格子满了 */
function ammoCapOf(t){
  if (bagGridOn()) return 999999;
  const base = (typeof AMMO_CAP_BASE !== 'undefined' && AMMO_CAP_BASE[t]) ? AMMO_CAP_BASE[t] : 120;
  const B = (player && player.bag) ? bagDef(player.bag.kind) : bagDef(BAG_DEFAULT);
  return Math.round(base * (B ? B.ammoK : 1));
}
/* 测试用：一键换最大的包 */
function giveBigBag(){
  player.bag = null;
  const ok = equipBag('big');
  if (ok) setMsg('测试：远征背包已背上 · 16 格 · 备弹 ×1.9', 2.4);
  return ok;
}
