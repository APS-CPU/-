/* 爆炸滤镜（手雷 / 绊雷 / 火箭炸到人）
   ---------------------------------------------------------------------------
   用户要的：被炸之后"看花"——画面浮动、残留、缓不过来。
   按距离分三档，形态不一样（不是同一段动画拉长剪短）：

     近 (k>=0.6)  震懵：隧道视野 + 7 张径向残影 + 白闪 + 大晃 + 明显发糊
     中 (k>=0.25) 挨了一下：边缘红圈 + 4 张统一拖影 + 轻晃 + 轻微发糊
     远 (k<0.25)  震了一下：不给残影，只有四边暖色一闪 + 2~3px 抖两下

   残影是"半分辨率快照"，只在这几秒内采样；一切都在后期层画，
   成本 ≈ 一次全屏渐变 + 几张 drawImage。 */

var blastTint = 0;          /* 0..1 当前滤镜强度（暖色/暗角） */
var blastTintDecay = 1.6;   /* 每秒衰减 */
var blastWaves = [];        /* { x, y, r, r0, age, life, k, warm } 世界坐标 */
var blastFilterKick = 0;    /* 短暂的"抖一下" */

var blastK = 0;             /* 这一炸的强度 0..1（决定档位与形态） */
var blastTier = 0;          /* 0 远 / 1 中 / 2 近 */
var blastVision = 0;        /* 隧道视野 / 边缘圈的独立计时 1 → 0 */
var blastVisionLife = 1;    /* 它要多久退干净（越近越久） */
var blastFlash = 0;         /* 近档的白闪 */
var blastGX = 0, blastGY = 0;   /* 炸点（世界坐标），残影按这个方向推开 */

function blastTierOf(k){
  return k >= 0.6 ? 2 : (k >= 0.25 ? 1 : 0);
}

/* 炸到了：x,y 是炸点（世界坐标），k 是 0..1 的远近系数（越靠中心越大） */
/* opt（可选）：{ d, radius, lenK, shakeK }
   手雷按自己算好的 k 传进来就行；火箭筒的爆炸半径是手雷的两倍，
   直接搬 k 会永远落在"中档"（rocketK 圈边还有 0.38），所以火箭传原始距离，
   由这里按它自己的半径归一化，再乘它自己的时长/抖动系数。 */
function blastFilterStart(x, y, k, opt){
  opt = opt || {};
  const lenK = opt.lenK || 1;
  const shakeK = opt.shakeK || 1;
  if (typeof opt.d === 'number' && opt.radius > 0){
    k = 1 - Math.max(0, Math.min(1, opt.d / opt.radius));   /* 按自己的爆炸半径归一化 */
  }
  k = Math.max(0, Math.min(1, k || 0));
  const tier = blastTierOf(k);
  blastK = Math.max(blastK, k);
  blastTier = Math.max(blastTier, tier);
  blastGX = x; blastGY = y;

  if (tier === 0){
    /* 远：只闪一下，不给残影 */
    blastTint = Math.max(blastTint, 0.20 + 0.10 * k);
    blastTintDecay = 1.15 / lenK;
    blastFilterKick = Math.max(blastFilterKick, 0.35);
    blastVision = Math.max(blastVision, 1);
    blastVisionLife = 0.55 * lenK;
  } else if (tier === 1){
    blastTint = Math.max(blastTint, 0.34 + 0.30 * k);
    blastTintDecay = (0.62 + 0.30 * (1 - k)) / lenK;
    blastFilterKick = Math.max(blastFilterKick, 0.6 + 0.3 * k);
    blastVision = Math.max(blastVision, 1);
    blastVisionLife = (1.35 + 0.9 * k) * lenK;
  } else {
    blastTint = Math.max(blastTint, 0.48 + 0.30 * k);
    blastTintDecay = (0.34 + 0.22 * (1 - k)) / lenK;       /* 贴脸能压 2~3 秒 */
    blastFilterKick = Math.max(blastFilterKick, 0.9);
    blastVision = Math.max(blastVision, 1);
    blastVisionLife = (2.1 + 1.3 * k) * lenK;             /* 隧道视野缓得最久 */
    blastFlash = Math.max(blastFlash, 0.45 + 0.55 * k);
  }

  /* 镜头也被推了一把（沿用现成的 camShake 管线，HUD 不跟着抖） */
  if (typeof camShake !== 'undefined'){
    camShake = Math.max(camShake, ((tier === 0 ? 0.5 : (tier === 1 ? 1.4 : 2.6)) + 2.0 * k) * shakeK);
  }

  /* 波：近档一圈大的 + 一圈慢的，远档一圈小的 */
  const n = tier === 0 ? 1 : 2;
  for (let i = 0; i < n; i++){
    blastWaves.push({
      x: x, y: y, r: 18 + i * 26, r0: 18 + i * 26,
      age: -i * 0.06, life: (tier === 0 ? 0.45 : 0.75 + 0.35 * (1 - k)), k: k, warm: i === 0
    });
  }
  if (blastWaves.length > 10) blastWaves.splice(0, blastWaves.length - 10);

  /* 残影段：远档不产生，近档最久最浓 */
  if (ghostFade <= 0) ghostLife = 0;
  if (tier > 0){
    GHOST_MAX = tier === 2 ? 5 : 3;
    ghostLife = Math.max(ghostLife, (tier === 2 ? (2.1 + 2.3 * k) : (1.0 + 1.6 * k)) * lenK);
    ghostFade = Math.max(ghostFade, 1);
    ghostStrength = Math.max(ghostStrength, tier === 2 ? (0.75 + 0.25 * k) : (0.45 + 0.3 * k));
  }
}

/* ---- 视觉残留（余像）：前几帧的画面拖在后面慢慢淡掉 ----
   快照只有半分辨率；远近决定张数（7 / 4 / 0）和错位幅度。 */
var ghostCvs = [];
var ghostT = 0;          /* 距离上次快照过了多久 */
var ghostFade = 0;       /* 1 → 0 的整段淡出（独立于 tint，保证最后是渐隐） */
var ghostStrength = 0;   /* 这一炸的残留浓度 */
var ghostLife = 0;       /* 这一次要缓多久（秒），从 0 起算 */
var ghostIdx = 0;
var GHOST_MAX = 5;

function ghostCapture(){
  if (typeof cv === 'undefined' || !cv) return;
  let g = ghostCvs[ghostIdx];
  if (!g){
    g = document.createElement('canvas');
    ghostCvs[ghostIdx] = g;
  }
  const gw = Math.max(2, Math.round(cv.width / 2));
  const gh = Math.max(2, Math.round(cv.height / 2));
  if (g.width !== gw || g.height !== gh){ g.width = gw; g.height = gh; }
  const c2 = g.getContext('2d');
  c2.setTransform(1, 0, 0, 1, 0, 0);
  c2.globalCompositeOperation = 'source-over';
  c2.globalAlpha = 1;
  c2.drawImage(cv, 0, 0, gw, gh);
  ghostIdx = (ghostIdx + 1) % Math.max(1, GHOST_MAX);
  ghostT = 0;
}
/* 只在这里决定"要不要抓这一帧"；真正的抓取在世界层画完之后（渲染阶段） */
function ghostTryCapture(){
  if (ghostFade <= 0.08) return;
  if (blastTier <= 0) return;                 /* 远档没有残影 */
  const gap = blastTier === 2 ? 0.05 : 0.075;
  if (ghostT < gap) return;
  ghostCapture();
}
function ghostReset(){
  ghostCvs.length = 0;
  ghostIdx = 0;
  ghostT = 0;
}
/* 画在"糊"之后、"红屏"之前：这样模糊不会盖掉残留 */
function drawBlastGhosts(){
  if (ghostFade <= 0.02 || !ghostCvs.length) return;
  const k = ghostFade * (0.55 + 0.45 * ghostStrength);
  /* 近档：残影按"从炸点向外"的方向推开；中档：统一方向轻拖 */
  const sx0 = blastGX - cam.x, sy0 = blastGY - cam.y;
  let dx = W / 2 - sx0, dy = H / 2 - sy0;
  const dl = Math.hypot(dx, dy) || 1;
  dx /= dl; dy /= dl;
  const sway = 1 - 0.45 * blastK;             /* 越近越"慢动作"：晃得更缓 */
  ctx.save();
  /* 用加法混合：残影只叠亮的地方，不会把整屏越叠越黑（隧道视野那一层本来就是黑） */
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < ghostCvs.length; i++){
    const g = ghostCvs[i];
    if (!g) continue;
    const age = (i + 1) / ghostCvs.length;
    const _fadeTail = ghostFade * ghostFade * (3 - 2 * ghostFade);
    const tier = Math.max(1, blastTier);
    const aMax = tier === 2 ? 0.34 : 0.22;
    const a = Math.min(aMax, k * aMax) * (1 - age * 0.20) * (0.32 + 0.68 * _fadeTail);
    if (a <= 0.01) continue;
    /* 重影：越老的一帧越"放大一点 + 偏一点点"，不是把整屏往外推成一圈 */
    const grow = tier === 2 ? (0.010 + 0.020 * age) : (0.006 + 0.010 * age);
    const push = tier === 2 ? (6 + 10 * age) : (4 + 6 * age);
    let ox = dx * push, oy = dy * push;
    ox += Math.sin(uiT * 3.1 * sway + i) * (tier === 2 ? 2.5 : 1.5);
    oy += Math.cos(uiT * 2.6 * sway + i * 1.7) * (tier === 2 ? 2.0 : 1.2);
    const gw2 = W * (1 + grow), gh2 = H * (1 + grow);
    ctx.globalAlpha = a;
    ctx.drawImage(g, ox - (gw2 - W) / 2, oy - (gh2 - H) / 2, gw2, gh2);
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}

function updateBlastFilter(dt){
  if (blastTint > 0){
    blastTint = Math.max(0, blastTint - blastTintDecay * dt);
  }
  if (blastVision > 0){
    blastVision = Math.max(0, blastVision - dt / Math.max(0.3, blastVisionLife));
  }
  if (blastFlash > 0) blastFlash = Math.max(0, blastFlash - dt * 5.5);
  if (blastFilterKick > 0) blastFilterKick = Math.max(0, blastFilterKick - dt * 2.2);
  if (ghostFade > 0){
    ghostT += dt;
    ghostFade = Math.max(0, ghostFade - dt / Math.max(0.4, ghostLife));
    if (ghostFade <= 0) ghostReset();
  } else if (ghostCvs.length){
    ghostReset();
  }
  if (blastTint <= 0 && blastVision <= 0 && blastFlash <= 0 && ghostFade <= 0){
    blastK = 0; blastTier = 0;
  }
  if (blastWaves.length){
    for (const w of blastWaves){
      w.age += dt;
      w.r += (140 + 260 * (1 - w.k)) * dt * (1 - Math.min(1, w.age / w.life) * 0.55);
    }
    for (let i = blastWaves.length - 1; i >= 0; i--){
      if (blastWaves[i].age > blastWaves[i].life) blastWaves.splice(i, 1);
    }
  }
}

/* 四边的暖色一闪（远档的全部表现 + 近档的补充） */
function _blastEdgeFlash(a, red){
  if (a <= 0.004) return;
  const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.34,
                                     W / 2, H / 2, Math.max(W, H) * 0.62);
  g.addColorStop(0, 'rgba(255,150,80,0)');
  g.addColorStop(1, red ? 'rgba(210,60,26,' + a.toFixed(3) + ')' : 'rgba(255,176,96,' + a.toFixed(3) + ')');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

function drawBlastFilter(){
  const tint = blastTint;
  if (tint <= 0.004 && !blastWaves.length && blastVision <= 0.004 && blastFlash <= 0.004) return;
  ctx.save();

  /* 近档：白闪（爆炸那一瞬间的过曝） */
  if (blastFlash > 0.004){
    ctx.fillStyle = 'rgba(255,236,208,' + (blastFlash * 0.42).toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
  }

  /* 1) 全局暖色：中间清、四角压暗 */
  if (tint > 0.004){
    const pulse = 0.9 + 0.1 * Math.sin(uiT * 11.0);
    const a = Math.min(0.60, tint * 0.60) * pulse;
    const cx = W / 2 + Math.sin(uiT * 7.3) * 3.5;
    const cy = H / 2 + Math.cos(uiT * 6.1) * 2.8;
    const g = ctx.createRadialGradient(cx, cy, Math.min(W, H) * 0.16, cx, cy, Math.max(W, H) * 0.78);
    g.addColorStop(0,    'rgba(255,176,96,0)');
    g.addColorStop(0.45, 'rgba(226,96,48,' + (a * 0.30).toFixed(3) + ')');
    g.addColorStop(1,    'rgba(146,38,16,' + (a * 0.88).toFixed(3) + ')');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    const g2 = ctx.createRadialGradient(cx, cy - H * 0.08, 0, cx, cy - H * 0.08, Math.max(W, H) * 0.5);
    g2.addColorStop(0, 'rgba(255,206,140,' + (a * 0.20).toFixed(3) + ')');
    g2.addColorStop(1, 'rgba(255,150,80,0)');
    ctx.fillStyle = g2;
    ctx.fillRect(0, 0, W, H);
  }

  /* 2) 视觉被压缩：近档 = 隧道视野（中间能看，四周压黑发红），中档 = 边缘一圈红，远档 = 四边一闪 */
  if (blastVision > 0.004){
    if (blastTier === 2){
      const v = blastVision;
      const R = Math.min(W, H) * (0.30 + 0.30 * v);        /* 视野越收越小 */
      const g = ctx.createRadialGradient(W / 2, H / 2, R * 0.62, W / 2, H / 2, R * 1.55);
      g.addColorStop(0,    'rgba(0,0,0,0)');
      g.addColorStop(0.55, 'rgba(46,8,2,' + (0.34 * v).toFixed(3) + ')');
      g.addColorStop(0.82, 'rgba(24,4,2,' + (0.74 * v).toFixed(3) + ')');
      g.addColorStop(1,    'rgba(8,1,0,' + (0.92 * v).toFixed(3) + ')');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      /* 不再画硬边圆环（像 UI），改成中心一圈极淡的暖光，边界自然糊掉 */
      const gw = ctx.createRadialGradient(W / 2, H / 2, R * 0.3, W / 2, H / 2, R * 1.05);
      gw.addColorStop(0, 'rgba(255,164,96,' + (0.10 * v).toFixed(3) + ')');
      gw.addColorStop(1, 'rgba(255,120,70,0)');
      ctx.fillStyle = gw;
      ctx.fillRect(0, 0, W, H);
    } else if (blastTier === 1){
      _blastEdgeFlash(0.55 * blastVision, true);
      ctx.fillStyle = 'rgba(28,6,2,' + (0.16 * blastVision).toFixed(3) + ')';
      ctx.fillRect(0, 0, W, H);
    } else {
      _blastEdgeFlash(0.42 * blastVision, true);
    }
  }

  /* 3) 炸点的余光：一团慢慢散开的暖光（不画圆环，圆环会像 UI 的靶子） */
  for (const w of blastWaves){
    if (w.age < 0) continue;
    const t = Math.min(1, w.age / w.life);
    const fade = (1 - t) * (1 - t) * (0.30 + 0.26 * w.k);
    if (fade <= 0.01) continue;
    const sx = w.x - cam.x, sy = w.y - cam.y;
    const rr = w.r * 1.25;
    if (sx < -rr || sx > W + rr || sy < -rr || sy > H + rr) continue;
    const gg = ctx.createRadialGradient(sx, sy, 0, sx, sy, rr);
    gg.addColorStop(0, 'rgba(255,214,150,' + fade.toFixed(3) + ')');
    gg.addColorStop(0.45, 'rgba(255,140,70,' + (fade * 0.42).toFixed(3) + ')');
    gg.addColorStop(1, 'rgba(255,120,60,0)');
    ctx.fillStyle = gg;
    ctx.beginPath(); ctx.arc(sx, sy, rr, 0, TAU); ctx.fill();
  }
  ctx.restore();
}
