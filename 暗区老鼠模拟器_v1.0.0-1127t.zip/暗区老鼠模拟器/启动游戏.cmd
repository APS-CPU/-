@echo off
setlocal
cd /d "%~dp0"
if not exist "index.html" goto NOHTML
if not exist "game" goto NOHTML
start "" "index.html"
exit /b 0

:NOHTML
echo.
echo  [X] Cannot find index.html in this folder:
echo      %~dp0
echo.
echo  Most likely you double-clicked this file from INSIDE the .zip archive.
echo  Windows extracts only this .cmd to a temp folder, so index.html is missing.
echo.
echo  Please do:
echo     1) Right-click the .zip file  -^>  "Extract All..."
echo     2) Open the extracted folder
echo     3) Double-click "index.html"  (or this file again)
echo.
echo  The game cannot run directly from inside a zip file.
echo  See README.md for details.
echo.
pause
exit /b 1
