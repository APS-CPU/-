/* 装饰物 —— 纯布景清单（第 36 轮新增）
   规则和掩体一样：**这里只写清单和配色，不写绘制**。
   绘制在 `_game\暗区老鼠模拟器.html` 的 `drawDecor()` 里。

   sz   : 占地矩形 [宽, 高]（俯视看到的那块地）
   hi   : 伪 3D 立起来的高度（像素）。0 = 完全贴地；桌子/瓦罐/椅子靠它"立"起来
   solid: 挡不挡人、挡不挡子弹。false 的东西只是画上去的，不进 L.walls
   sit  : 能不能坐（只有椅子）
   hp   : 血量。>0 的才打得碎（桌/椅/瓦罐）；0 的子弹直接穿过去
   mat  : 碎了以后留什么残渣（wood / clay）

   颜色都放 DECOR_SKIN，绘制里一个色号都不许写死。

   第 37 轮补的两条：
   foot : 碰撞箱占视觉高度的比例（从底边往上算）。0.55 = 只有下半截挡人，
          上半截是"看起来大"的部分，走过去不会被上半个罐子顶住。
   push : 能不能被推着走。能推的不进 L.walls（不挡路不挡弹），
          玩家走过去会把它顶着挪，带惯性和摇晃，不是平移。 */
/*    第 62 轮补的三条（地面杂物）：
   blastOnly : 只吃爆炸。子弹既不挡也不掉血（子弹判定整个跳过它）
   bulletPass: 子弹能穿过去。不再进墙表，也不接"子弹命中"那套；
               但爆炸照样能打碎它（垃圾堆 / 玻璃瓶）
   nodecal   : 碎了不留残渣地毯（花这种小东西留渣反而脏） */
const DECOR_DEF = {
  broom:  { label: '扫把', sz: [46, 14], hi: 0,  solid: false, sit: false, hp: 0,  mat: 'wood' },
  bottle: { label: '饮料瓶', sz: [15, 15], hi: 0, solid: false, sit: false, hp: 0,  mat: 'wood' },
  jar:    { label: '瓦罐', sz: [26, 26], hi: 22, solid: false, sit: false, hp: 40, mat: 'clay',
            foot: 0.5, push: true, mass: 1 },
  table:  { label: '桌子', sz: [78, 46], hi: 22, solid: true,  sit: false, hp: 110, mat: 'wood', foot: 0.62 },
  chair:  { label: '椅子', sz: [26, 26], hi: 18, solid: false, sit: true, hp: 70, mat: 'wood',
            foot: 0.70, push: true, mass: 2, topple: true },

  /* —— 地面杂物（第 62 轮）—— */
  plank:       { label: '木板',   sz: [56, 24], hi: 0, solid: false, hp: 22, mat: 'wood',
                 blastOnly: true },
  plankBroken: { label: '破木板', sz: [46, 20], hi: 0, solid: false, hp: 16, mat: 'wood',
                 blastOnly: true },
  flower:      { label: '野花',   sz: [11, 11], hi: 0, solid: false, hp: 6,  mat: 'plant',
                 blastOnly: true, nodecal: true },
  rose:        { label: '红玫瑰', sz: [12, 12], hi: 0, solid: false, hp: 7,  mat: 'plant',
                 blastOnly: true, nodecal: true },
  lily:        { label: '百合',   sz: [13, 15], hi: 0, solid: false, hp: 8,  mat: 'plant',
                 blastOnly: true, nodecal: true },
  daisy:       { label: '小雏菊', sz: [11, 11], hi: 0, solid: false, hp: 6,  mat: 'plant',
                 blastOnly: true, nodecal: true },
  trash:       { label: '垃圾堆', sz: [42, 30], hi: 6, solid: false, hp: 50, mat: 'junk',
                 bulletPass: true },
  soda:        { label: '汽水瓶', sz: [11, 15], hi: 0, solid: false, hp: 12, mat: 'glass',
                 push: true, mass: 0.6, bulletPass: true },
  flask:       { label: '玻璃瓶', sz: [10, 14], hi: 0, solid: false, hp: 10, mat: 'glass',
                 push: true, mass: 0.5, bulletPass: true },
};


/* ============================================================
   花丛模板（第 62 轮）
   ------------------------------------------------------------
   关卡里写一行 {t:'bed', kind:'rose', x:..., y:...}，
   initDecors 会按这里的相对坐标铺成一丛，随便哪张图都能调。

   · 相对坐标以"丛的左上角"为原点，单位是像素
   · 想加新的丛：只在这里加一条，关卡那边立刻就能用
   ============================================================ */
const FLOWER_BEDS = {
  /* —— 单一品种 —— */
  rose: [
    { t:'rose', dx:  0, dy:  0 }, { t:'rose', dx: 15, dy:  7 },
    { t:'rose', dx:-13, dy:  9 }, { t:'rose', dx: -4, dy:-11 },
    { t:'rose', dx: 12, dy: -9 }, { t:'rose', dx: -18, dy: -4 }
  ],
  lily: [
    { t:'lily', dx:  0, dy:  0 }, { t:'lily', dx: 17, dy:  6 },
    { t:'lily', dx:-16, dy:  8 }, { t:'lily', dx:  3, dy:-13 }
  ],
  daisy: [
    { t:'daisy', dx:  0, dy:  0 }, { t:'daisy', dx: 13, dy:  5 },
    { t:'daisy', dx:-12, dy:  6 }, { t:'daisy', dx:  5, dy:-10 },
    { t:'daisy', dx:-20, dy: -3 }, { t:'daisy', dx: 20, dy: -6 },
    { t:'daisy', dx:  2, dy: 12 }
  ],

  /* —— 混种：不同花掺在一起（相邻一列一定是不同品种）—— */
  mixed: [                       /* 玫瑰 + 百合：花坛 */
    { t:'rose',  dx:  0, dy:  0 }, { t:'lily',  dx: 17, dy:  4 },
    { t:'lily',  dx:-15, dy:  9 }, { t:'rose',  dx:  7, dy:-11 },
    { t:'rose',  dx:-21, dy: -6 }, { t:'lily',  dx: 25, dy:-10 },
    { t:'lily',  dx:  0, dy: 14 }, { t:'rose',  dx:-9,  dy: 17 }
  ],
  roseLily: [                    /* 玫瑰 + 百合 + 雏菊：一整块混栽 */
    { t:'rose',  dx:  0, dy: -14 }, { t:'lily',  dx: 18, dy: -10 },
    { t:'daisy', dx:-16, dy: -6 }, { t:'lily',  dx:  4, dy:  2 },
    { t:'rose',  dx: 22, dy:  6 }, { t:'daisy', dx:-12, dy: 10 },
    { t:'rose',  dx:-2,  dy: 18 }, { t:'lily',  dx: 20, dy: 20 }
  ],
  roseDaisy: [                   /* 玫瑰 + 雏菊：红花配白星 */
    { t:'rose',  dx:  0, dy:  0 }, { t:'daisy', dx: 14, dy:  6 },
    { t:'daisy', dx:-13, dy:  7 }, { t:'rose',  dx:  4, dy:-11 },
    { t:'daisy', dx:-20, dy: -4 }, { t:'rose',  dx: 20, dy: -7 },
    { t:'rose',  dx:-16, dy: 15 }, { t:'daisy', dx: 16, dy: 14 },
    { t:'daisy', dx:  0, dy: 17 }
  ],
  lilyDaisy: [                   /* 百合 + 雏菊：清白相间 */
    { t:'lily',  dx:  0, dy:  0 }, { t:'daisy', dx: 14, dy:  7 },
    { t:'daisy', dx:-14, dy:  5 }, { t:'lily',  dx:  3, dy:-11 },
    { t:'lily',  dx: 20, dy: -8 }, { t:'daisy', dx:-19, dy:-9 },
    { t:'daisy', dx:  0, dy: 14 }, { t:'lily',  dx:-9,  dy: 17 }
  ],

  /* —— 花丛（更小、更密、带野草） —— */
  wild: [                        /* 野花野草：全是小雏菊和野花，最不起眼 */
    { t:'flower', dx:  0, dy:  0 }, { t:'daisy', dx: 12, dy:  5 },
    { t:'flower', dx:-12, dy:  6 }, { t:'flower', dx:  4, dy:-9 },
    { t:'daisy',  dx: 17, dy: -6 }, { t:'flower', dx:-18, dy: -4 },
    { t:'flower', dx:  2, dy: 12 }
  ],
  bouquet: [                     /* 大花坛：外圈雏菊点缀，内圈玫瑰百合 */
    { t:'rose',  dx:  0, dy:  0 }, { t:'lily',  dx: 16, dy: -4 },
    { t:'rose',  dx:-16, dy: -3 }, { t:'lily',  dx:  6, dy:-15 },
    { t:'rose',  dx:-8,  dy: 13 }, { t:'lily',  dx: 22, dy:  9 },
    { t:'daisy', dx:-26, dy: 10 }, { t:'daisy', dx: 28, dy: -2 },
    { t:'daisy', dx:-22, dy:-16 }, { t:'daisy', dx: 14, dy: 18 },
    { t:'daisy', dx: -2, dy:-26 }, { t:'daisy', dx: 34, dy: 16 }
  ]
};

const DECOR_SKIN = {
  /* 木头（扫把柄、桌子、椅子） */
  wood:      '#5a4a33',
  woodHi:    '#6d5a3f',
  woodLo:    '#3e3222',
  /* 铁（扫把箍、椅子腿、桌腿） */
  metal:     '#4a5158',
  metalHi:   '#6b747c',
  /* 瓦罐：土黄陶 */
  clay:      '#8a6a4a',
  clayHi:    '#a5825c',
  clayLo:    '#5e4630',
  clayIn:    '#2a2018',
  /* 瓶子：绿玻璃 */
  glass:     'rgba(86,132,104,0.78)',
  glassHi:   'rgba(190,224,200,0.55)',
  glassLo:   'rgba(30,52,40,0.65)',
  /* 扫把穗 */
  straw:     '#7c6b40',
  strawHi:   '#9c8850',
  /* 汽水瓶：琥珀玻璃（可乐那种） */
  soda:      'rgba(122,72,34,0.80)',
  sodaHi:    'rgba(226,168,116,0.55)',
  sodaLo:    'rgba(48,26,12,0.70)',
  /* 野花：小黄花瓣 + 深芯 + 草叶 */
  petal:     '#c9b25c',
  petalHi:   '#e2cf84',
  petalCore: '#8a6a24',
  leaf:      '#42512f',
  leafHi:    '#55663c',
  /* 垃圾堆：脏纸 / 破布 / 暗铁 */
  trashA:    '#6a6355',
  trashB:    '#4d4a42',
  trashC:    '#7b7160',
  trashD:    '#3a3833',
  trashE:    '#8a7a5c',
  /* 红玫瑰：暗红花瓣 + 亮边 + 深芯 + 叶 */
  rose:      '#8c2a2c',
  roseHi:    '#c4544c',
  roseDeep:  '#571a1e',
  /* 百合：米白花瓣 + 亮边 + 蜜色花蕊 */
  lily:      '#d9d3c2',
  lilyHi:    '#f2eee2',
  lilyCore:  '#c19a3a',
  /* 小雏菊：白瓣 + 金心 */
  daisy:     '#e3ddcc',
  daisyCore: '#c8a63a',
  /* 通用 */
  shadow:    'rgba(0,0,0,0.30)',
  labelTxt:  'rgba(226,240,255,0.92)'
};
