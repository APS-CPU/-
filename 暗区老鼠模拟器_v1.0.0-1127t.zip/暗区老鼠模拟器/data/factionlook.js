/* 阵营外观表（A 势力 / B 势力 / 中立）
 *
 * 为什么单独立一个数据文件：
 *   以前颜色写死在 game/18-truck.js 的 _ftint()，识别标记又散在 44-sfxcombat.js 里，
 *   改一个颜色要翻两个文件，还容易只改一半。用户反馈"打起来两边都是红的、分不清"，
 *   根因是"看见玩家就把身体刷红"和"阵营弧被看见就隐藏"，那两个规则在这里一起定义。
 *
 * 字段：
 *   label   显示名（调试面板/图鉴用）
 *   body    身体主色
 *   light   高光/受击提亮色
 *   dark    暗部
 *   mark    识别标记形状：'chevron'（A，尖角向上）/ 'ring'（B，圆环）/ 'none'
 *   arc     脚下阵营弧颜色（null = 不画）
 *   alert   发现玩家时的提醒色（不再覆盖身体色，只用来画提示环）
 */
const FACTION_LOOK = {
  enemy: {
    label: 'A 势力',
    body:  '#5f8fd8',
    light: '#c8e0ff',
    dark:  '#27405f',
    mark:  'chevron',
    arc:   'rgba(95,143,216,0.85)',
    alert: 'rgba(255,88,72,0.95)'
  },
  bandit: {
    label: 'B 势力',
    body:  '#d89a4a',
    light: '#ffe3b4',
    dark:  '#5e3d18',
    mark:  'ring',
    arc:   'rgba(216,154,74,0.85)',
    alert: 'rgba(255,120,60,0.95)'
  },
  neutral: {
    label: '中立',
    body:  '#9aa4ae',
    light: '#dde3e8',
    dark:  '#3d4349',
    mark:  'none',
    arc:   null,
    alert: 'rgba(255,120,60,0.95)'
  },
  player: {
    label: '玩家',
    body:  '#6fb3e0',
    light: '#d6efff',
    dark:  '#274a63',
    mark:  'none',
    arc:   null,
    alert: 'rgba(255,120,60,0.95)'
  }
};

/* 未知阵营一律按中立画，绝不因为少写一条数据就崩 */
function factionLook(f){
  return FACTION_LOOK[f] || FACTION_LOOK.neutral;
}
