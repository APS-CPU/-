/* ============================================================
   敌人状态数据流（ESTATUS_DEF）
   ------------------------------------------------------------
   目的：敌人"现在处于什么状态"只有一个入口。
   加一个新状态 = 在 ESTATUS_DEF 里加一段，不用再去 AI 里手写判断、
   不用再记得在十几个分支里乘系数、不用再手抄一长串"要清掉的字段"。

   每条配置：
     label   给玩家/HUD 看的名字
     field   状态计时存在敌人对象的哪个字段（沿用 stunT 这种老名字，
             老存档、老测试、绘制代码都不用改）
     col     HUD / 头顶小标用的颜色
     eff     {
               spdK    乘在移动速度上的倍率（1 = 不影响）
               noFire  扣不动扳机
               noSee   看不见人
               noMech  禁用一切"手上的活"（找掩体、探头、架枪、技能…）
             }
     clear   挂上的那一刻、以及"还挂着"的每一帧，强制压回这些值
             —— 这一条替代了原来在 AI 循环里手抄的 20 多个字段
     raise   挂上时把这些冷却至少拉高到多少（防止刚晕完立刻开枪）
     onEnd   到期瞬间补的动作

   结算只用四个函数：eStatusSet / eStatusHas / eStatusTick / eMoveK。
   ============================================================ */
var ESTATUS_DEF = {
  stun: {
    label: '眩晕',
    field: 'stunT',
    col: 'rgba(255,214,104,0.98)',
    eff: { spdK: 0.18, noFire: true, noSee: true, noMech: true },
    clear: {
      sees: false,
      fearT: 0, tucked: false, hideGoal: null, peekPhase: null, peekT: 0, hideT: 0, shakeOff: false,
      holding: 0, holdBackT: 0, pushing: 0, followT: 0, tacticPhase: null, tacStage: null,
      blindShot: false, windup: 0, slashT: 0, chargeT: 0, lungeT: 0, slideT: 0,
      callT: 0, callBark: false, callDone: false, backupRushT: 0,
      fleeing: 0, fleeGoal: null, fleeT: 0
    },
    raise: { suppressCd: 0.4, fireCd: 0.3 },
    onEnd: { stunMax: 0, sees: false, recoverT: 0.35 }
  },
  fear: {
    label: '恐惧',
    field: 'fearT',
    col: 'rgba(255,168,116,0.96)',
    /* 恐惧本身不改速度、不封扳机 —— 它只是"缩进掩体"这条行为线的开关。
       倍率交给 e.spdK 与 behaviorOf，别在这里再乘一次，否则逃跑会变龟速。 */
    eff: {},
    /* 到期要不要真的解除，取决于"玩家是不是还端着枪"：这是逻辑不是数据，
       所以这里只写钩子名，函数体在 暗区老鼠模拟器.html 的 STATUS_TICK_FNS 里。 */
    tick: 'fear',
    onEnd: {
      tucked: false, hideGoal: null, coverOK: 0,
      peekPhase: null, peekT: 0, hideT: 0, shakeOff: false
    }
  },
  /* 被打压制：挨了一枪之后朝子弹来的方向乱打一气。
     它不禁速度、不禁开火（反而是"乱开火"），所以 eff 是空的，
     只作为一个"正在压制"的开关存在；盲扫的具体节奏仍在主文件里。 */
  suppress: {
    label: '压制',
    field: 'suppressT',
    col: 'rgba(255,196,92,0.96)',
    eff: {},
    tick: 'suppress',
    onEnd: {}
  },
  /* 受击硬直：身上闪一下、喊一声、不乱跑。纯视觉 + 短暂行为锁，不加倍率。 */
  hurt: {
    label: '受击',
    field: 'hurtT',
    col: 'rgba(255,120,110,0.92)',
    eff: {}
  },

  /* 紧急呼叫支援的前摇硬直：站着喊 3 秒，喊完才广播。
     不禁看不见（他还得盯着玩家），但扣不动扳机、也不许做别的战术动作。
     中断方式：被打晕 —— stun.clear 里会把 callT 归零（见下）。 */
  call: {
    label: '呼叫支援',
    field: 'callT',
    col: 'rgba(255,140,228,0.98)',
    eff: { spdK: 0, noMech: true },
    tick: 'call',
    clear: {
      tucked: false, hideGoal: null, peekPhase: null, peekT: 0, hideT: 0,
      holding: 0, holdBackT: 0, pushing: 0, followT: 0,
      tacticPhase: null, tacStage: null, blindShot: false, windup: 0,
      fleeing: 0, fleeGoal: null, fleeT: 0, fearT: 0
    },
    onEnd: { callBark: false, callDone: false }
  },
  /* 敌人侧没有 blind / bleed：
     blindShot 是"朝记忆位置盲射"的行为布尔，blindCd 是它的冷却（已登记），
     流血只有玩家有（stBleedT / stBleedLv，走玩家自己的状态面板）。 */
};

/* ------------------------------------------------------------
   冷却登记表
   ------------------------------------------------------------
   凡是在敌人/载具对象上写 `xxxCd = 值` 的键，必须登记在这里。
   为什么：撞车的 ramCd 曾经"只写不减"，一个敌人被撞过一次就整辈子
   免疫撞伤 —— 因为写它的地方和减它的地方不是同一处，谁也想不到去补。
   现在递减只有 eCdTick 一个出口：
     mode: 'tick'   → 由 eCdTick 每帧统一递减（新代码默认用这个）
     mode: 'manual' → 现有逻辑自己在特定分支里减（比如 fireCd 要区分
                      ownCooldown 的行为预设），逐步迁到 'tick'
   _tests/_tStatusDef.js 会扫源码强制"每个 Cd 赋值都在表里"。
   ------------------------------------------------------------ */
var E_CD_DEF = {
  coverCd:    { mode: 'manual', note: '显式目标战术的掩体搜索冷却' },
  specCoverCd:{ mode: 'manual', note: '听到动静去抢掩体的冷却，enemyTick 里跟 fireCd 一起手减' },
  throwCd:    { mode: 'manual', owner: 'enemy', note: '精英投雷的冷却（15s），enemyThrowTick 里自己减' },
  complaintCd:{ mode: 'manual', note: '队友误伤抱怨冷却' },
  companionStrikeCd:{ mode: 'manual', note: '刀手攻击队友的挥砍间隔' },
  ramCd:      { mode: 'tick',   note: '撞击节拍：同一面墙/同一个人的连续撞击不重复结算' },
  backupCd:   { mode: 'tick',   note: '紧急呼叫支援的 30 秒冷却' },
  pushCd:     { mode: 'manual', note: '压出冷却，由 AI 压出分支自己减' },
  suppressCd: { mode: 'manual', note: '压制射击冷却' },
  blindCd:    { mode: 'manual', note: '盲射冷却' },
  spotCd:     { mode: 'manual', note: '发现目标的反应冷却' },
  smokeCd:    { mode: 'manual', note: '扔烟冷却' },
  calloutCd:  { mode: 'manual', note: '爆点通报的冷却（enemyCalloutTick 自己减）' },
  fleeCd:     { mode: 'manual', note: '逃跑冷却' },
  dashCd:     { mode: 'manual', note: '冲刺冷却' },
  bladeCd:    { mode: 'manual', note: '近战挥砍冷却' },
  chargeCd:   { mode: 'manual', note: '冲锋冷却' },
  slideCd:    { mode: 'manual', note: '滑步冷却' },
  spawnCd:    { mode: 'manual', note: '巢母产兵冷却' },
  fuseCd:     { mode: 'manual', note: '自爆引信冷却' },
  bossCd:     { mode: 'manual', note: 'BOSS 技能冷却' },
  alarmCd:    { mode: 'manual', note: '摄像头报警冷却' },
  voiceCd:    { mode: 'manual', note: '喊话冷却' },
  hitCd:      { mode: 'manual', note: '受击反馈冷却' },
  fireCd:     { mode: 'manual', note: '开火冷却：ownCooldown 的行为预设自己减，别人不许碰' },

  /* ---- 别的系统（玩家 / BOSS / 割草模式）也在用的冷却 ----
     它们不在敌人身上，eCdTick 不会碰；登记在这里是为了"全项目只有一张表"，
     以后谁想加冷却，先来这里写一行，就不会再出现"只写不减"。 */
  heatCd:     { mode: 'manual', owner: 'player', note: '热成像耗尽后的冷却，玩家系统自己减' },
  leashCd:    { mode: 'manual', owner: 'boss',   note: 'BOSS 脱战后回点位的冷却' },
  boostCd:    { mode: 'manual', owner: 'boss',   note: 'BOSS 冲锋冷却' },
  banCd:      { mode: 'manual', owner: 'arena',  note: '巢母封卡的间隔（每次封卡后自己缩短）' },
  callCd:     { mode: 'manual', owner: 'arena',  note: '割草模式 BOSS 呼叫援兵的冷却' },
  lastCd:     { mode: 'manual', owner: 'arena',  note: '背水一战的触发冷却' },
  throwCd:    { mode: 'manual', owner: 'player', note: '手雷扔完的后摇（0.55s），updateNades 里自己减' }
};
