/* 枪械配件（attachment）数据表 ---------------------------------------------
   以后配件多了只在这里加一条，别的地方不用动：
     slot  装哪个槽（现在只有 'muzzle' 枪口）
     fits  能装哪几把枪（wid 列表；写 'any' 表示不挑枪）
     mods  乘算系数（不写的就是 1）：
             spreadK 散布倍率（小于 1 = 弹丸更集中）
             dmgK    单发伤害倍率
             recoilK 后坐力倍率
             magCap  弹匣容量（绝对值，写多少就是多少；同一个槽只有一件生效）
             reloadK 换弹时长倍率（小于 1 = 换得更快）
   ------------------------------------------------------------------------- */
var ATTACH_SLOTS = ['muzzle', 'mag'];
var ATTACH_SLOT_NAME = { muzzle:'枪口', mag:'弹匣' };
/* 一个槽只能装一件；同一把枪可以有多件不同槽的配件 */
var ATTACH_DEF = {
  choke_std: {
    id:'choke_std', slot:'muzzle', fits:['shotgun'], name:'标准收束器', icon:'choke', nat:26,
    desc:'枪口缩口 · 弹丸散布 ×0.85', mods:{ spreadK:0.85 }
  },
  choke_tight: {
    id:'choke_tight', slot:'muzzle', fits:['shotgun'], name:'紧束收束器', icon:'choke', nat:26,
    desc:'缩得更狠 · 弹丸散布 ×0.68', mods:{ spreadK:0.68 }
  },
  choke_long: {
    id:'choke_long', slot:'muzzle', fits:['shotgun'], name:'长管收束器', icon:'choke', nat:26,
    desc:'最集中 · 散布 ×0.52，但单颗伤害 ×0.92', mods:{ spreadK:0.52, dmgK:0.92 }
  },
  /* ---- 突击步枪弹匣（同一个 'mag' 槽：扩容 和 快速 只能二选一） ---- */
  mag_ext1: {
    id:'mag_ext1', slot:'mag', fits:['ar'], name:'扩容弹匣 I', icon:'mag', nat:22,
    desc:'弹匣 30 发', notes:['弹匣槽和「扩容 / 快速」互斥，一次只能装一个', '换弹匣时如果弹匣里的子弹超过新容量，多出来的会掉在你脚边'], mods:{ magCap:30 }
  },
  mag_ext2: {
    id:'mag_ext2', slot:'mag', fits:['ar'], name:'扩容弹匣 II', icon:'mag', nat:22,
    desc:'弹匣 35 发', notes:['弹匣槽和「扩容 / 快速」互斥，一次只能装一个', '换弹匣时如果弹匣里的子弹超过新容量，多出来的会掉在你脚边'], mods:{ magCap:35 }
  },
  mag_ext3: {
    id:'mag_ext3', slot:'mag', fits:['ar'], name:'扩容弹匣 III', icon:'mag', nat:22,
    desc:'弹匣 40 发 · 换弹略慢 6%', notes:['弹匣槽和「扩容 / 快速」互斥，一次只能装一个', '换弹匣时如果弹匣里的子弹超过新容量，多出来的会掉在你脚边'], mods:{ magCap:40, reloadK:1.06 }
  },
  mag_fast1: {
    id:'mag_fast1', slot:'mag', fits:['ar'], name:'快速弹匣 I', icon:'mag', nat:22,
    desc:'换弹快 18% · 弹匣 25 发不变', notes:['弹匣槽和「扩容 / 快速」互斥，一次只能装一个', '换弹匣时如果弹匣里的子弹超过新容量，多出来的会掉在你脚边'], mods:{ reloadK:0.82 }
  },
  mag_fast2: {
    id:'mag_fast2', slot:'mag', fits:['ar'], name:'快速弹匣 II', icon:'mag', nat:22,
    desc:'换弹快 28% · 弹匣 25 发不变', notes:['弹匣槽和「扩容 / 快速」互斥，一次只能装一个', '换弹匣时如果弹匣里的子弹超过新容量，多出来的会掉在你脚边'], mods:{ reloadK:0.72 }
  },
  mag_fast3: {
    id:'mag_fast3', slot:'mag', fits:['ar'], name:'快速弹匣 III', icon:'mag', nat:22,
    desc:'换弹快 40% · 弹匣 25 发不变', notes:['弹匣槽和「扩容 / 快速」互斥，一次只能装一个', '换弹匣时如果弹匣里的子弹超过新容量，多出来的会掉在你脚边'], mods:{ reloadK:0.60 }
  }
};
/* 掉落表用：按顺序给权重，权重高的常见 */
var ATTACH_LOOT = [
  { id:'choke_std',   w:6 },
  { id:'choke_tight', w:3 },
  { id:'choke_long',  w:1 },
  { id:'mag_ext1',    w:4 },
  { id:'mag_ext2',    w:2 },
  { id:'mag_ext3',    w:1 },
  { id:'mag_fast1',   w:4 },
  { id:'mag_fast2',   w:2 },
  { id:'mag_fast3',   w:1 }
];
function attachDef(id){ return (ATTACH_DEF && ATTACH_DEF[id]) || null; }
/* ---- 数据流出口：加新配件只改上面那张表 ---- */
/* 每种 mod 怎么翻译成人话。加新数值类型只在这里加一行，卡片/提示自动跟上 */
var ATTACH_MOD_TEXT = {
  spreadK: function(v){ return '弹丸散布 ×' + v.toFixed(2) + (v < 1 ? '（更集中）' : '（更散）'); },
  dmgK:    function(v){ return '单发伤害 ×' + v.toFixed(2) + (v < 1 ? '（代价）' : '（更强）'); },
  recoilK: function(v){ return '后坐力 ×' + v.toFixed(2) + (v < 1 ? '（更稳）' : '（更抖）'); },
  magCap:  function(v){ return '弹匣容量：' + v + ' 发'; },
  reloadK: function(v){
    const pc = Math.round(Math.abs(1 - v) * 100);
    return v < 1 ? ('换弹速度：快 ' + pc + '%') : ('换弹速度：慢 ' + pc + '%（代价）');
  }
};
/* 把一件配件的 mods 翻译成卡片上的若干行 */
function attachLines(d){
  const out = [];
  if (!d || !d.mods) return out;
  for (const k in d.mods){
    const f = ATTACH_MOD_TEXT[k];
    if (f){ const t = f(d.mods[k]); if (t) out.push(t); }
    else out.push(k + ' ×' + d.mods[k]);
  }
  return out;
}
/* 图标用哪套画法 / 它画出来的"自然尺寸"（背包缩放用），都写在表里 */
function attachIconKind(id){ const d = attachDef(id); return (d && d.icon) || 'choke'; }
function attachNat(id){ const d = attachDef(id); return (d && d.nat) || 24; }
function attachSlotName(slot){ return (ATTACH_SLOT_NAME && ATTACH_SLOT_NAME[slot]) || '配件'; }
function attachList(){ const out = []; for (const k in ATTACH_DEF) out.push(ATTACH_DEF[k]); return out; }
/* 这把枪能不能装这件配件 */
function attachFits(id, wid){
  const d = attachDef(id);
  if (!d) return false;
  if (!wid) return false;
  const f = d.fits || [];
  if (f.indexOf('any') >= 0) return true;
  return f.indexOf(wid) >= 0;
}
/* 这把枪现在哪些槽能装东西（给界面画小格用） */
function attachSlotsFor(wid){
  const out = [];
  if (typeof attachFits !== 'function' || !ATTACH_DEF) return out;
  for (const sl of ATTACH_SLOTS){
    let ok = false;
    for (const id in ATTACH_DEF){ if (ATTACH_DEF[id].slot === sl && attachFits(id, wid)){ ok = true; break; } }
    if (ok) out.push(sl);
  }
  return out;
}
