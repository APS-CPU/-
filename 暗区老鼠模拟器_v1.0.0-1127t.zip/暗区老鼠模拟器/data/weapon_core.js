/* 武器"基础物理参数"的唯一出处（m27992）
   为什么单独一张表：玩家读 WEAPONS[wid]，敌人读 CFG × npc{}，两边都要拿 cap / rof / reloadDur / moveK。
   以前这些字段缺了不报错，只会算出发散值 —— "火箭筒开局 8 发"就是这么来的（CFG.mag 8 把 cap 1 盖掉了）。
   这里声明"每把枪必须有什么、缺了用什么兜底"，主文件 weaponCore() 照着校验并报警。 */
var WEAPON_CORE_DEF = {
  /* req:true = 必须手写，缺了就是数据 bug，会报警计数；
     没有 req 的字段省略等于取默认值（比如 moveK 不写就是 1，不吵人）。 */
  cap:       { type:'num', def: 1,    min: 0,    req: true },   /* 弹匣容量；近战/投掷为 0 或 1 */
  rof:       { type:'num', def: 0.5,  min: 0.02, req: true },   /* 秒/发（玩家侧直接用它算冷却） */
  reloadDur: { type:'num', def: 1.5,  min: 0,    req: true },   /* 一次完整换弹的秒数 */
  moveK:     { type:'num', def: 1,    min: 0.1  },   /* 端这把枪时的移速系数 */
  npcRof:    { type:'num', def: 1,    min: 0.1  },   /* npc.rof：敌人射速倍率（还乘难度 CFG.fireRate） */
  npcDmg:    { type:'num', def: 1,    min: 0    },   /* npc.dmg：敌人伤害倍率（还乘难度 CFG.eDmg） */
  npcSpread: { type:'num', def: 1,    min: 0    },   /* npc.spread：敌人散布倍率（还乘难度 CFG.spread） */
  npcSpd:    { type:'num', def: 1,    min: 0.1  },   /* npc.spd：敌人弹速倍率 */
  pellets:   { type:'num', def: 1,    min: 0    },   /* 一发几颗弹丸 */
  kind:      { type:'str', def: 'gun'               } /* gun / melee / throw */
};
