/* =========================================================================
   暗区老鼠模拟器 · 数据文件：弹药 / 武器 / 药品
   -------------------------------------------------------------------------
   这里只放配置（数值、名字、参数），不放任何逻辑。
   加一把新枪 = 在 WEAPONS 里加一条数据，然后把它写进 WEAPON_ORDER。
   加一种新弹药 = 在 AMMO 里加一条，并把 id 写进 AMMO_ORDER。
   改伤害/射速/弹匣 = 直接改这里的数字。
   逻辑（gunDef / makeGun / ammoOf / startingAmmo ...）仍然在主文件里。
   ========================================================================= */

const AMMO = {
  /* box = 一个弹药箱给几发，也等于打死后从尸体上掉几发：正好一个弹匣 */
  pistol: {id:'pistol',  label:'手枪弹', short:'手枪', box:12, pal:'#ffd24a', dark:'#6b4c0c'},
  shotgun:{id:'shotgun', label:'霰弹',   short:'霰弹', box:6,  pal:'#ff9a4a', dark:'#6b3308'},
  rifle:  {id:'rifle',   label:'冲锋枪弹', short:'冲锋', box:30, pal:'#9ad0ff', dark:'#123c56'},
  /* 突击步枪弹：比冲锋枪弹稀少，一盒 25 发正好一个弹匣 */
  ar:     {id:'ar',      label:'步枪弹',   short:'步枪', box:25, pal:'#c8f47a', dark:'#2f4a10'},
  /* 火箭弹：一发一装，盒子里就 1 发 —— 占 2×1 格，不能叠 */
  rocket: {id:'rocket',  label:'火箭弹',   short:'火箭', box:1,  pal:'#ff8a4a', dark:'#5c1d08'},
  /* 红色信号弹：一发一装，捡到就是 1 颗，专门喂信号枪 */
  flare:  {id:'flare',   label:'信号弹',   short:'信号', box:1,  pal:'#ff5d6c', dark:'#5c1018'}
};
const AMMO_ORDER = ['pistol', 'shotgun', 'rifle', 'ar', 'rocket', 'flare'];

/* RPG 火箭弹的共享物理/爆炸参数。
   这里只描述一枚火箭弹本身；火箭兵的听声、选落点、换弹和找掩体仍归 data/ai.js。 */
const ROCKET_DEF = {
  speed: 1000,
  blastRadius: 320,
  damageCenter: 150,
  damageEdge: 30,
  damageFalloffPower: 2.2,
  vehicleDamageK: 8.0,
  projectileLife: 2.6,
  projectileRadius: 5,
  noiseFire: 3.4,
  noiseBlast: 4.6
};

/* 碎片手雷的共享实体/爆炸参数。
   玩家操作后摇、碎片特效预算和敌人投掷决策不属于实体本身，继续由各自模块管理。 */
const FRAG_GRENADE_DEF = {
  fuse: 3.0,
  blastRadius: 170,
  damageCenter: 260,
  damageEdge: 60,
  damageFalloffPower: 1.7,
  throwSpeed: 470,
  projectileRadius: 5.2,
  bounceRetention: 0.55,
  tangentFriction: 0.90,
  stopSpeed: 42,
  physicsSubstep: 8,
  noiseBlast: 3.0,
  glassBreakSpeed: 320,
  glassSpeedRetention: 0.78
};

const WEAPONS = {
  /* ammo   这把枪吃哪种子弹（只要弹药种类对，换枪不会串）
     npc    AI 拿这把枪时怎么打：dmg 伤害倍率 / pellets 一次几发 / spread 散布倍率 / rof 射速倍率 / spd 弹速倍率 */
  pistol: {wid:'pistol', name:'手枪',     dmg:46, cap:12, rof:0.16,  reloadDur:1.05,
           pellets:1, spread:0.010, recoil:7,  kick:0.10, auto:false, reserve:24, ammo:'pistol',
           npc:{dmg:1, pellets:1, spread:1, rof:1, spd:1},
           sfx:{gain:0.32, lp:2600, tone:180, tail:0.14}},
  /* 信号枪：红色涂装，一发一装，打出去的不是子弹而是"叫空投"的信号弹。
     cap/reserve 用口径控制，dmg 不参与结算（tryShoot 里直接走 fireFlare） */
  flare:  {wid:'flare',  name:'信号枪',    dmg:0,  cap:1,  rof:0.9,   reloadDur:1.7,
           pellets:0, spread:0, recoil:14, kick:0.22, auto:false, reserve:6, ammo:'flare', flare:true,
           npc:{dmg:0, pellets:0, spread:1, rof:1.6, spd:1},
           sfx:{gain:0.38, lp:1700, tone:420, tail:0.48}},
  /* 望远镜：不吐子弹的工具，占副武器栏（跟手枪/信号枪一栏）。
     按住左键"举起来"：画面放大、视野光锥收窄、视距拉远，松手自己放下。
     没有弹匣也不吃子弹，cap:0 —— 千万别给它写 pellets，否则会走 hitscan 打空气。 */
  bino:   {wid:'bino',   name:'望远镜',    dmg:0,  cap:0,  rof:0.25,  reloadDur:0,
           pellets:0, spread:0, recoil:0, kick:0.02, auto:false, reserve:0, ammo:null, tool:true,
           npc:{dmg:0, pellets:0, spread:1, rof:1, spd:1},
           sfx:{gain:0.20, lp:2200, tone:300, tail:0.10}},
  shotgun:{wid:'shotgun', name:'霰弹枪',  dmg:14, cap:6,  rof:0.85,  reloadDur:2.6,
           pellets:8, spread:0.150, recoil:52, kick:0.62, auto:true,  reserve:18, ammo:'shotgun',
           arenaRof: 0.46, shellReload:true, shellDur:0.62,
           npc:{dmg:0.5, pellets:4, spread:2.4, rof:0.9, spd:0.85},
           sfx:{gain:0.55, lp:1500, tone:96,  tail:0.34}},
  rifle:  {wid:'rifle',   name:'Uzi冲锋枪', dmg:24, cap:30, rof:0.095, reloadDur:2.2,
           pellets:1, spread:0.030, recoil:4,  kick:0.18, auto:true,  reserve:90, ammo:'rifle',
           npc:{dmg:0.7, pellets:1, spread:1.5, rof:2.8, spd:1.15},
           sfx:{gain:0.30, lp:3000, tone:210, tail:0.11}},
  /* 近战位：不吐子弹，左键一刀扇面砍过去。Q 切到它 */
  knife:  {wid:'knife', name:'战术刀', kind:'melee', dmg:84, cap:0, rof:0.46, reloadDur:0,
           pellets:0, spread:0, recoil:0, kick:0.05, auto:true, reserve:0, ammo:null,
           reach:80, arc:1.30,
           npc:{dmg:1, pellets:0, spread:1, rof:1, spd:1},
           sfx:{gain:0.26, lp:5200, tone:640, tail:0.09}},
  /* 近战二号：弯刀。刀身有弧度、刀尖收窄，伤害比战术刀高一点、挥得慢一点 */
  dao:    {wid:'dao',   name:'弯刀', kind:'melee', dmg:108, cap:0, rof:0.58, reloadDur:0,
           pellets:0, spread:0, recoil:0, kick:0.06, auto:true, reserve:0, ammo:null,
           reach:96, arc:1.42,
           npc:{dmg:1.1, pellets:0, spread:1, rof:0.9, spd:1},
           sfx:{gain:0.30, lp:5000, tone:720, tail:0.10}},
  /* 火箭筒：一发一装（弹匣 1），走得慢、换弹慢；子弹是飞出去的弹丸，撞到东西才炸 */
  rpg:    {wid:'rpg',   name:'火箭筒',  dmg:95, cap:1, rof:1.7, reloadDur:3.4,
           pellets:1, spread:0.004, recoil:58, kick:0.95, auto:false, reserve:0, ammo:'rocket',
           rocket:true, soundAreaFire:true, soundAreaDelay:0.65, soundRepathDist:180, moveK:0.72,
           npc:{dmg:1, pellets:1, spread:1, rof:0.5, spd:0.8},
           sfx:{gain:0.62, lp:1200, tone:70, tail:0.52}},
  /* 突击步枪：和 Uzi 分工明确 ——
     Uzi（rifle）：射速快、弹匣大、后坐小，适合贴脸泼水压枪；
     AR（ar）    ：单发重、散布小、弹速快，适合中远距离点射点名；
                   代价是换弹慢、后坐力大（会被推着走）、拿在手上跑不快。 */
  ar:     {wid:'ar',      name:'AR15', dmg:36, cap:25, rof:0.125, reloadDur:2.45,
           pellets:1, spread:0.014, recoil:13, kick:0.30, auto:true, reserve:75, ammo:'ar',
           moveK:0.94,
           npc:{dmg:0.9, pellets:1, spread:1.3, rof:1.7, spd:1.3},
           sfx:{gain:0.42, lp:2400, tone:150, tail:0.20}},
  /* 投掷位：跟枪一样用 Q 切过来，左键扔。没有弹匣/换弹，只有"还剩几颗" */
  smoke:  {wid:'smoke',   name:'烟雾弹',   kind:'throw', dmg:0, cap:1, rof:0.9, reloadDur:0,
           pellets:0, spread:0, recoil:0, kick:0.05, auto:false, reserve:0, ammo:'smoke',
           npc:{dmg:0, pellets:0, spread:1, rof:1, spd:1},
           sfx:{gain:0.22, lp:1800, tone:130, tail:0.12}}
};

/* =========================================================================
   烟雾弹：两套皮肤
   - player：你自己扔的，冷白灰，一眼能认出来是「我的烟」
   - enemy ：敌人扔的，暖褐 + 暗红罐体，靠近时还能看见红点
   只放颜色和文案，绘制/判定仍在主文件（s.byEnemy 决定用哪套）
   ========================================================================= */
var SMOKE_DEF = {
  player: {
    label: '烟雾弹',
    core: '#e6edf4', mid: '#c3ccd6', rim: '#8e9aa6',
    canister: '#cfd8e2', band: 'rgba(255,255,255,0.45)',
    tCore: '#d8f0ff', tMid: '#9fc8e8', tRim: '#20303c'
  },
  enemy: {
    label: '敌制烟雾弹',
    core: '#c2a79c', mid: '#8d6f68', rim: '#3a2b28',
    canister: '#8d3f38', band: 'rgba(255,214,196,0.55)',
    tCore: '#ffd7c8', tMid: '#d08a72', tRim: '#2a1410'
  }
};

const MED_DEF = {  small:{label:'小药', amt:30, dur:2.0, tier:'普通', bg:'rgba(86,168,104,0.92)',  fg:'#eafff0'},
  /* 大号医疗包 = "绿药包"：绿的（深一档的医疗色），不是紫色 ——
     紫色在我们的品质色表里代表"稀有"，用它当箱子底色会让人以为加了个稀有词缀。 */
  big:  {label:'绿药包', amt:70, dur:3.2, tier:'大号', bg:'rgba(30,104,88,0.97)', fg:'#eafff0',
         cross:'rgba(232,74,62,0.98)'   /* 红十字：一眼和亮绿小药分开 */}
};
const AMMO_BOX = 15;

/* ============================ 品质（等级）============================
   同一件东西可以出不同品质：普通 / 精良 / 稀有 / 史诗。
   品质只做三件事：
     ① 地上的光晕颜色（远处就能看出这堆里有没有好货）
     ② 捡到时的名字前缀（"稀有·重型防弹衣"）
     ③ 一点点数值浮动 —— 系数围绕 1.0 上下摆，史诗也不会变成另一件东西，
        只是"这一件更扎实"（甲耐久 x1.2、枪伤 x1.2、药回血 x1.2）。
   背包格数【不跟着变】：BAG_SHAPE 是按 id 写死的一整套网格，动它会崩背包。 */
const QUALITY_DEF = [
  { id:0, key:'common', label:'普通', col:'#fff4d6', rgb:'255,244,214', k:0.90 },
  { id:1, key:'fine',   label:'精良', col:'#7fc4ff', rgb:'127,196,255', k:1.00 },
  { id:2, key:'rare',   label:'稀有', col:'#c08bff', rgb:'192,139,255', k:1.10 },
  { id:3, key:'epic',   label:'史诗', col:'#ffc94a', rgb:'255,201,74',  k:1.20 }
];
/* 掉落权重：普通 50 / 精良 30 / 稀有 15 / 史诗 5 */
const QUALITY_W = [50, 30, 15, 5];
function qualityQ(q){ q = (q | 0); return q < 0 ? 0 : (q > 3 ? 3 : q); }
function qualityDef(q){ return QUALITY_DEF[qualityQ(q)]; }
function qualityK(q){ return qualityDef(q).k; }
function qualityLabel(q){ return qualityDef(q).label; }
function qualityCol(q){ return qualityDef(q).col; }
/* 名字前缀：普通不加前缀（满屏"普通·小药"太吵），其余加"精良·"这种 */
function qualityPrefix(q){ const d = qualityDef(q); return d.id > 0 ? d.label + '·' : ''; }

/* =========================================================================
   防弹衣
   -------------------------------------------------------------------------
   reduce  减伤比例：这一下伤害里有多少被甲吃掉（不吃进血）
   dur     耐久：甲一共能替你扛多少点"原始伤害"，扛完就碎
   pal/fg  图标与 HUD 用的颜色
   掉率    drop 是关卡物资点刷到时给它的权重（见 ARMOR_ORDER），
           目前只有测试区会摆，正式关还没接
   ========================================================================= */
const ARMOR_DEF = {
  light:  {id:'light',  label:'轻型防弹衣', short:'轻型', tier:'普通',
           reduce:0.25, dur:80,  pal:'#8ea3b8', fg:'#e6eef6', drop:0.55,
           brief:'减伤 25% · 耐久 80'},
  heavy:  {id:'heavy',  label:'重型防弹衣', short:'重型', tier:'稀有',
           reduce:0.35, dur:150, pal:'#3f6fd8', fg:'#cfe0ff', drop:0.32,
           brief:'减伤 35% · 耐久 150'},
  elite:  {id:'elite',  label:'精锐防弹衣', short:'精锐', tier:'史诗',
           reduce:0.50, dur:250, pal:'#d9b02e', fg:'#fff3bf', drop:0.13,
           brief:'减伤 50% · 耐久 250'}
};
/* 每种伤害甲挡多少：bladeK / blastK 是「再乘一个系数」，1 = 照常挡，0 = 完全不防
   以后要做「这甲不防刀」，只把 bladeK 改成 0，玩家和敌人会一起变，不用改主文件 */
const ARMOR_K_DEF = { bladeK: 1, blastK: 1 };
for (const _ak in ARMOR_DEF){
  if (ARMOR_DEF[_ak].bladeK === undefined) ARMOR_DEF[_ak].bladeK = ARMOR_K_DEF.bladeK;
  if (ARMOR_DEF[_ak].blastK === undefined) ARMOR_DEF[_ak].blastK = ARMOR_K_DEF.blastK;
}
const ARMOR_ORDER = ['light', 'heavy', 'elite'];

/* =========================================================================
   背包
   -------------------------------------------------------------------------
   三档，不按颜色分等级，只按"能装多少东西"分：
     slots  随身格数：小药 / 绿药包 / 手雷 / 烟雾 每件占 1 格
     ammoK  备弹上限倍率：各口径备弹上限 = 基础值 × ammoK
     look   图标画法（三种大小不一样的包型，颜色都一样）
   ========================================================================= */
const BAG_DEF = {
  small: {id:'small', label:'小背包',   tier:'普通', slots:10,  ammoK:1.0, look:'pouch',
          brief:'随身 10 格 · 备弹 ×1.0'},
  mid:   {id:'mid',   label:'战术背包', tier:'稀有', slots:20, ammoK:1.4, look:'pack',
          brief:'随身 20 格 · 备弹 ×1.4'},
  big:   {id:'big',   label:'远征背包', tier:'史诗', slots:36, ammoK:1.9, look:'rucksack',
          brief:'随身 36 格 · 备弹 ×1.9'}
};
const BAG_ORDER = ['small', 'mid', 'big'];
const BAG_DEFAULT = 'small';
/* 各口径的备弹基础上限（再乘背包倍率） */
const AMMO_CAP_BASE = { pistol: 120, shotgun: 60, rifle: 180 };

/* 按 Q / 滚轮轮换武器的顺序 —— 唯一的出处。
   加新枪时把它的 id 补进来；最后一个永远是手雷位（smoke）。 */
const WEAPON_ORDER = ['pistol', 'flare', 'bino', 'shotgun', 'rifle', 'ar', 'knife', 'dao', 'rpg', 'smoke'];
if (typeof window !== 'undefined') window.WEAPON_ORDER = WEAPON_ORDER;
