/* =========================================================================
   暗区老鼠模拟器 · 数据文件：敌人类型
   -------------------------------------------------------------------------
   只放配置（数值、名字、参数），不放任何逻辑。
   改完保存、刷新页面即可生效，不需要动主文件。
   ========================================================================= */

/* =========================================================================
   行为特征（behavior）
   -------------------------------------------------------------------------
   敌人 AI 里所有"这个兵种会怎么打"的差别，都写在这里，主文件只读不判断类型。
   一个兵种只要在 ENEMY_TYPES 里写一句 behavior:'veteran' 就套下面这套预设，
   想微调就在自己的条目里写 behavior:{...}，会与预设逐字段合并（浅合并）。

   加新兵种时优先"挑一个预设 + 改几个字段"，不要再往主文件里塞 if。
   ========================================================================= */
const BEHAVIOR_DEF = {
  /* 普通人机：会怕、会缩、会乱打 */
  normal: {
    label: '普通兵',

    /* --- 这三个是"性格"层面的粗旋钮，新兵种调这三个就够了 --- */
    aggression: 1.00,        /* 交战欲望：越大越愿意在你换弹时从更远处压出来（乘在 TAC.pushR 上） */
    canChase: true,          /* 会不会追人（你退远了它跟过来） */
    canFlank: false,         /* 协同架枪/侧翼包抄：必须显式开启，普通兵不运行这层逻辑 */
    canCallBackup: false,    /* 紧急呼叫支援：血少 / 看见你时喊人，同样必须显式开启 */
    coverStrategy: 'nearest',/* 找掩体的口味：nearest=就近躲，advance=往更靠前/更贴脸的位置躲 */
    aimError: 1.00,          /* 枪法散布倍率：>1 更飘，<1 更准（乘在 enemyShoot 的散布上） */

    /* --- 挨打 / 撤退 --- */
    flinchOnHit: true,       /* 被子弹擦到时下意识缩回掩体（打断开枪） */
    fleeSpdK: 1.15,          /* 残血逃跑的速度倍率 */
    fleeFire: false,         /* 普通兵残血转身逃跑，不具备边撤边打能力 */
    retreatFire: false,      /* 一边退一边有节奏地单发还击（职业兵那套） */

    /* --- 反应 --- */
    instantAim: false,       /* 一发现你 / 听见枪声就立刻端枪（spotT、fireCd 直接压到 spotClamp） */
    instantAimClamp: 0.10,   /* instantAim 时压到的上限（秒） */
    ownCooldown: false,      /* fireCd 是否由自己的每帧 tick 统一递减（true 则各分支不再各自递减） */
    seekCoverOnNoise: false, /* 听见枪声先找掩体，而不是直接冲过去 */
    ignoreStepsInCombat: false, /* 交战中忽略脚步声（不被打断当前战术动作） */

    /* --- 跑动姿态 --- */
    corpseGlance: true,      /* 跑过尸体时回头看 */
    sway: 1.00,              /* 慌乱跑动时左右摇的幅度（0 = 走直线） */
    straightToCover: false,  /* 换掩体时直接朝目标点走（不扭麻花） */
    coverRunSpdK: 1.05,      /* 跑向掩体时的速度倍率 */
    useRunBoost: true,       /* 主动压出 / 追人时是否吃 TAC.runBoost */
    recoilStops: true,       /* 后坐力大到一定程度会站住（不然只看得到枪在抖） */
    heardStrafe: true,       /* 只听见没看见时，横移找射界 */
    dropTacticR: 0,          /* 距离小于它且看得见时放弃战术阶段（0 = 不放弃） */
    shotRecover: null        /* 开枪后强制冷却下限 {shotgun:秒, other:秒}；null = 不强制 */
  },

  /* 职业兵/正规军：算计，不慌忙 */
  veteran: {
    label: '正规军',
    aggression: 1.00,
    canChase: true,
    canFlank: false,
    canCallBackup: false,    /* 加给具体兵种（协同精英 / 突击兵），预设本身不开 */
    coverStrategy: 'advance',
    aimError: 1.00,

    flinchOnHit: false,      /* 不缩手：该打继续打 */
    fleeSpdK: 1.55,          /* 撤退比普通兵快 */
    fleeFire: false,         /* 不边跑边乱打 */
    retreatFire: true,       /* 用"退着单发还击"那套 */

    instantAim: true,
    instantAimClamp: 0.10,
    ownCooldown: true,       /* 冷却自管，状态切换不能取消 */
    seekCoverOnNoise: true,
    ignoreStepsInCombat: true,

    corpseGlance: false,     /* 不回头看尸体 */
    sway: 0,                 /* 跑起来是直线 */
    straightToCover: true,
    coverRunSpdK: 1.10,
    useRunBoost: false,      /* 本来就快，再吃 runBoost 就飞了 */
    recoilStops: false,
    heardStrafe: false,
    dropTacticR: 220,        /* 贴到 220 内且看得见，就别再玩"盲射"那套 */
    shotRecover: { shotgun: 0.85, other: 0.22 }   /* 打完这一枪，下一枪最少隔这么久 */
  },

  /* 假人：站着不动的靶子。真正让它"不动不打"的是主文件里的 updateDummies()
     （每帧给它刷新无限眩晕 + 满血），这里只是一份"什么都不做"的配置。 */
  dummy: {
    label: '假人',
    aggression: 0,           /* 不主动压上 */
    canChase: false,         /* 不追人 */
    canFlank: false,
    canCallBackup: false,
    coverStrategy: 'nearest',
    aimError: 1.00,
    flinchOnHit: false,      /* 挨打不缩手（反正也不会开枪） */
    fleeSpdK: 0.2,
    fleeFire: false,
    retreatFire: false,
    instantAim: false,
    instantAimClamp: 0.10,
    ownCooldown: false,
    seekCoverOnNoise: false, /* 听见枪声不去找掩体 */
    ignoreStepsInCombat: true,
    corpseGlance: false,
    sway: 0,
    straightToCover: false,
    coverRunSpdK: 0.2,
    useRunBoost: false,
    recoilStops: true,
    heardStrafe: false,
    dropTacticR: 0,
    shotRecover: null
  }
};

/* ---------------------------------------------------------------
   防呆：字段清单与类型
   ---------------------------------------------------------------
   加预设时最容易犯的错是"漏一个字段"—— 后果不是报错，而是
   `behaviorOf(e).canChase` 变成 undefined，`undefined > 0` 恒 false，
   于是这个兵种悄悄变傻，而且很难查。
   所以：所有预设必须用同一套键；behaviorOf() 发现缺失/类型不对时
   回退到 normal 的值，并在控制台报一次警。
   --------------------------------------------------------------- */
const BEH_KEYS = Object.keys(BEHAVIOR_DEF.normal);

const BEH_TYPE = {
  label: 'str',
  aggression: 'num', canChase: 'bool', canFlank: 'bool', canCallBackup: 'bool', coverStrategy: 'str', aimError: 'num',
  flinchOnHit: 'bool', fleeSpdK: 'num', fleeFire: 'bool', retreatFire: 'bool',
  instantAim: 'bool', instantAimClamp: 'num', ownCooldown: 'bool',
  seekCoverOnNoise: 'bool', ignoreStepsInCombat: 'bool',
  corpseGlance: 'bool', sway: 'num', straightToCover: 'bool',
  coverRunSpdK: 'num', useRunBoost: 'bool', recoilStops: 'bool',
  heardStrafe: 'bool', dropTacticR: 'num', shotRecover: 'obj?'
};

const ROCKET_TURRET_DEF = Object.freeze({
  spectatorRange: 900, /* 观战模式索敌半径 */
  hp: 3000, baseHalf: 36, placeClearance: 48, initialCooldown: 1.2,
  attackCooldown: 3.2, directDamage: 100, lowHealthRatio: 0.35,
  friendlyClear: 130,   /* m45306：弹着点周围这个半径内有自己人就不开炮（炮弹不分敌我） */
});

/* m45698：机枪棱堡 —— 和火箭炮塔同族，但打的是连发子弹、血量按"据点"给。
   和炮塔的分工（有意为之）：
     · 炮塔 = 单发大伤害、穿墙、3.2s 装填 → "一炮定生死"
     · 棱堡 = 持续小伤害、不穿墙、200 发弹链 + 3.5s 换弹 → "火力压制"
   它只认阵营（combatFaction），所以 A 打 B、B 打 C 都自然成立。 */
const MG_SENTRY_DEF = Object.freeze({
  hp: 5000,             /* m45703：用户拍板 5000（比炮塔 3000 更硬，因为它不穿墙、射程短） */
  baseHalf: 30,         /* 占地：2×2 格左右，比炮塔（36）矮一圈 */
  placeClearance: 44,
  initialCooldown: 1.5, /* 刚摆下去别立刻开火 */
  range: 520,           /* 比炮塔（900）近得多，逼它挨近才咬人 */
  rof: 0.11,            /* ≈9 发/秒（m45955：用户要"再快一点"，0.14 → 0.11） */
  burst: 0.9,           /* 连发 0.9s / 歇 0.55s，否则像激光 */
  pause: 0.55,
  dmg: 9,
  spread: 0.075,        /* m45955：散度稍微加大（0.05 → 0.075），远距离不再像激光 */
  lockT: 1.6,           /* m45955：被视野外的人打了，朝来袭方向盲打这么久（之后恢复找人） */
  spd: 1100,
  mag: 200,             /* 弹链 */
  reloadT: 3.5,         /* 换弹窗口 = 玩家的进攻机会（枪口抬起、不打人） */
  turnSpd: 5.0,
  aimTol: 0.12,
  friendlyClear: 90,    /* 子弹也不分敌我，身前这个半径有同伙就压枪 */
});

const ENEMY_TYPES = {
  /* 训练假人：血量写成天文数字，主文件每帧还会把血补满，所以打不死。
     不会动、不会打、不会跑 —— 只会站在那儿挨打，然后把伤害数字报给你。 */
  dummy:{label:'假人', kind:'dummy', brief:'固定靶：不动、不打、打不死，用来测武器伤害',
    r:14, visionMul:0, hearMul:0, stepLoud:0, fov:0, canShoot:false, onCatch:'none',
    stepGap:0, stepHear:0, hp:999999, maxHp:999999, dummy:true,
    voice:null, barkChance:0, weaponPool:[], drops:[], spawn:'slot', behavior:'dummy'},
  dummyArmor:{label:'假人（三级甲）', kind:'dummy', brief:'固定靶：穿着三级防弹衣，用来测穿甲后的实伤',
    r:14, visionMul:0, hearMul:0, stepLoud:0, fov:0, canShoot:false, onCatch:'none',
    stepGap:0, stepHear:0, hp:999999, maxHp:999999, dummy:true, armorKind:'elite',
    voice:null, barkChance:0, weaponPool:[], drops:[], spawn:'slot', behavior:'dummy'},
  rocketTurret:{label:'火箭炮塔',kind:'turret',static:true,canShoot:false,onCatch:'none',r:ROCKET_TURRET_DEF.baseHalf,drops:[],spawn:'testOnly',behavior:'normal'},
  /* weaponPool：这种敌人可能拿的枪（正式关卡只取第一条，靶场里随机取 —— 见 assignWeapon）
     drops：打死后掉什么。p 是概率，kind 对应 LOOT_KINDS；弹药类不用写种类，
            掉的是它自己那把枪吃的那种子弹。想加掉落就往数组里加一条。 */
  grunt: {
    label: '人机', kind: 'gunner', behavior: 'normal',
    brief: '拿枪的普通人形，会开枪。听到动静会过来看。',
    r: 12, visionMul: 1, hearMul: 1, stepLoud: 1, fov: 58,
    canShoot: true, onCatch: 'damage',
    stepGap: 0.34, stepHear: 1,
    weaponPool: ['pistol', 'rifle', 'shotgun', 'ar'],
    drops: [{kind:'ammo', p:0.85}, {kind:'med', p:0.30, rarity:'small'}],
    spawn: 'slot'
  },
  /* 掷弹兵：普通步枪兵的体格与枪法，多一手"你躲太久了就扔雷"。
     它由生成概率刷出来（GRENADIER.p），不是独立的关卡兵种 —— 见下面的 GRENADIER 表。 */
  grenadier: {
    label: '掷弹兵', kind: 'gunner', behavior: 'normal',
    brief: '体格普通的步枪兵，但会扔雷：你缩在掩体后面太久，它就摸过来往你身后扔一颗。',
    r: 12, visionMul: 1, hearMul: 1, stepLoud: 1, fov: 58,
    canShoot: true, onCatch: 'damage',
    stepGap: 0.34, stepHear: 1,
    weaponPool: ['pistol', 'rifle', 'shotgun', 'ar'],
    drops: [{kind:'ammo', p:0.85}, {kind:'med', p:0.30, rarity:'small'}, {kind:'nade', p:0.22}],
    canThrow: true,          /* ★ 有这一行才会掏雷；enemyCanThrow 第一行就查它 */
    spawn: 'slot'
  },
  sentinel: {
    /* 第四关电闸刷出来的"多一个人"：不开枪，只是个会走会看的岗哨 */
    label: '哨兵', kind: 'gunner', behavior: 'normal',
    brief: '不开枪，只是会走会看的岗哨，挡路、报点。',
    r: 12, visionMul: 1, hearMul: 1, stepLoud: 1, fov: 58,
    canShoot: false, onCatch: 'damage',
    stepGap: 0.34, stepHear: 1,
    weaponPool: ['pistol'],
    drops: [{kind:'ammo', p:0.55}],
    spawn: 'slot'
  },
  hunter: {
    label: '猎手', kind: 'hunter', behavior: 'normal',
    brief: '不开枪，但跑得比你快，扑到就是秒杀。',
    r: 14, visionMul: 1.25, hearMul: 0.9, stepLoud: 0.62, fov: 68,
    canShoot: false, onCatch: 'kill',
    patrolSpd: 78,
    burstSpd: 286, burstSpdOut: 302,
    restSpd: 126, restSpdOut: 118,
    burstDur: 0.92, restDur: 1.34, restDurOut: 1.05,
    stepGap: 1.35, stepHear: 0.62,
    searchDur: 4.6, lostGrace: 3.2, leash: false,
    weaponPool: ['shotgun'],
    drops: [{kind:'ammo', p:0.7}, {kind:'med', p:0.22, rarity:'small'}],
    spawn: 'hunter'
  },
  camera: {
    /* 固定不动的摄像头：不会开枪，看见就拉警报把人叫过来，并且给被叫的人加速。
       没有耳朵（hearMul 0），静步也不减它的视距（crouchBlind）—— 它只认眼睛。 */
    label: '摄像头', kind: 'camera', behavior: 'normal',
    brief: '钉在墙上不动的摄像头，扇形视野。看见你就拉警报叫人。',
    r: 11, visionMul: 1.15, hearMul: 0, stepLoud: 0,
    canShoot: false, onCatch: 'none',
    fov: 70, crouchBlind: true, static: true,
    alarm: true, alarmR: 900, boostMul: 1.45, boostDur: 4.0, alarmCd: 3.2,
    stepGap: 0, stepHear: 0,
    drops: [],
    spawn: 'camera'
  },
  drone: {
    /* 无人机：在天上飞，巡航不看墙（fly），只认眼睛。
       看见就像摄像头那样拉警报；飞在天上，越墙也飞得过去——你没枪，只能躲。
       速度是它的全部：你从它视野里穿过去，来不及躲它就看见了。 */
    label: '无人机', kind: 'drone', behavior: 'normal',
    brief: '会飞的无人机，能飞过墙但看不穿墙，被盯上会一直报你的点。',
    r: 11, visionMul: 1.0, hearMul: 0, stepLoud: 0,
    canShoot: false, onCatch: 'none',
    fov: 62, crouchBlind: true, static: false, fly: true,
    alarm: true, alarmR: 760, boostMul: 1.35, boostDur: 3.6, alarmCd: 4.0,
    droneSpd: 235, droneTurn: 2.6,
    stepGap: 0, stepHear: 0,
    drops: [],
    spawn: 'drone'
  },
  blade: {
    /* 雨夜的刀手：不开枪，只往你身上贴。
       关键在"他什么时候看得见你"——闪电亮起来的那一下他才看得见（见主文件里的黑暗闸门）。 */
    label: '刀手', kind: 'blade', behavior: 'normal',
    brief: '拿刀的近战，砍你会让眼前糊掉。',
    r: 12, visionMul: 0.95, hearMul: 1.15, stepLoud: 1.15, fov: 76,
    canShoot: false, onCatch: 'damage',
    bladeDmg: 1.6, bladeReach: 40, bladeCd: 0.85,
    /* 长刀版（wid='dao'）：够得着更远、砍得更疼 */
    daoReachBonus: 14, daoDmgMul: 1.35,
    /* 贴脸之后的前突 / 后摇：以前写死在 AI 里，现在按类型配 */
    lungeSpd: 520, lungeDur: 0.16, lungeRecover: 0.30,
    stepGap: 0.30, stepHear: 1,
    weaponPool: ['knife'],
    drops: [{kind:'med', p:0.45, rarity:'small'}],
    spawn: 'slot'
  },
  guard: {
    /* 守点的猎手：不追出自己那片，跟丢得快 */
    label: '守点猎手', kind: 'hunter', behavior: 'normal',
    brief: '猎手的看守版：只在自己那片地转悠，跟丢了很快放弃，但守门守闸很烦。',
    r: 14, visionMul: 1.25, hearMul: 0.9, stepLoud: 0.62, fov: 68,
    canShoot: false, onCatch: 'kill',
    patrolSpd: 78,
    burstSpd: 286, burstSpdOut: 302,
    restSpd: 126, restSpdOut: 118,
    burstDur: 0.92, restDur: 1.34, restDurOut: 1.05,
    stepGap: 1.35, stepHear: 0.62,
    searchDur: 3.4, lostGrace: 1.6, leash: true,
    leashR: 860, leashBreak: 900,
    weaponPool: ['rifle', 'pistol', 'ar'],
    drops: [{kind:'ammo', p:0.75}, {kind:'med', p:0.20, rarity:'small'}],
    spawn: 'hunter'
  },

  /* 职业兵：正规军下来的那种老手。
     跟他打的感觉应该是"被算计"，不是"被吓到"——
     他不发抖，受击优先加速找掩体，残血撤退时仍会还击：
       ① 往你脚边扔烟，把你们之间的视线切掉；
       ② 贴到墙角，露半个身子点一枪，立刻缩回去；
       ③ 换角度，再来一次。
     反应速度靠 quickK 统一缩（<1 更快），机制本身沿用普通兵那套，不另写一份。 */
  spec: {
    label: '职业兵', kind: 'gunner', behavior: 'veteran',
    brief: '穿三级甲的老手：会往你脚下扔烟、贴墙点一枪就缩回去；不发抖，但会躲子弹、会找掩体、也会逃，反应极快。',
    r: 13, visionMul: 1.45, hearMul: 1.30, stepLoud: 0.70, fov: 76,
    canShoot: true, onCatch: 'damage',
    stepGap: 0.30, stepHear: 1,

    /* --- 属性：血量与普通兵完全一致，防护全在那件三级甲上 ---
       这里刻意不写 hp：由关卡统一给（L.enemyHp，默认 100），想改全体血量动一处即可。
       精英硬不硬只取决于 armorKind，不再靠悄悄加血条。 */
    armorKind: 'elite',   /* 真穿一件三级甲：耐久/减伤/碎甲都走 ARMOR_DEF，和玩家同源（见 absorbEnemyArmor） */
    armorTint: '#d9b02e',   /* 三级甲的外环色，和掉落的 elite 甲同色 */

    /* --- 反应速度：1 = 普通人机，<1 更快（tuck/peek/scareT/blindCd 全部乘它） --- */
    quickK: 0.38,
    calm: true,                  /* 只是不发抖：恐惧那一套（躲子弹/找掩体/被压制）全都保留 */

    /* --- 会扔雷：只有带 canThrow 的精英会这一招（普通兵永远没有） ---
       触发/前摇/落点/冷却全在 DataTHROW 里，这里只负责"准不准扔"。 */
    canThrow: true,

    /* --- 会扔烟：冷却 9s、只在 210 内扔、烟半径 150 持续 12s --- */
    smokeP: 0.55, smokeCd: 9.0, smokeDist: 210, smokeDur: 0.55, smokeR: 150, smokeLife: 12,

    /* --- 说话：词少，全是术语 --- */
    voice: 'tac', barkChance: 0.30,

    weaponPool: ['rifle', 'shotgun', 'ar'],
    weaponRand: true,          /* 精英：整池随机（于是"职业兵有概率拿突击步枪"） */
    drops: [
      { kind: 'armor', armor: 'elite', p: 1.00, durPct: [0.25, 0.80] },
      { kind: 'smoke', p: 0.55, n: 1 },
      { kind: 'ammo', p: 0.70 },
      { kind: 'med', p: 0.25, rarity: 'small' }
    ],
    spawn: 'slot'
  },

  /* 火箭筒兵：整套模型/行为直接沿用职业兵（veteran），只把枪换成 rpg ——
     "设计一个新敌人"其实是"换个武器再配几个数字"。反应比职业兵再慢一档
     （quickK 0.85），因为他扛的是大家伙，抬手要时间。 */
  rocketman: {
    label: '火箭筒兵', kind: 'gunner', behavior: 'veteran',
    brief: '职业兵换了火箭筒：穿三级甲、会找掩体、不发抖；抬手慢，但一发就能把掩体和你一起掀了。',
    r: 13, visionMul: 1.45, hearMul: 1.30, stepLoud: 0.70, fov: 76,
    canShoot: true, onCatch: 'damage',
    stepGap: 0.30, stepHear: 1,

    /* 血量同样跟普通兵一致（不写 hp，走关卡 L.enemyHp）；硬在三级甲和火箭筒上 */
    armorKind: 'elite',
    armorTint: '#d9b02e',

    /* 扛着火箭筒：反应慢一档，抬手也慢 */
    quickK: 0.85,
    calm: true,

    /* 不扔烟（烟是他的敌人，火箭筒才需要视野） */
    smokeP: 0, smokeCd: 9.0, smokeDist: 0, smokeDur: 0.55, smokeR: 0, smokeLife: 0,

    voice: 'tac', barkChance: 0.22,

    /* 只用火箭筒。enemyShoot 里看到 gunDef().rocket 就走火箭弹分支 */
    weaponPool: ['rpg'],
    drops: [
      /* 他那根火箭筒会掉在脚边（弹匣里还剩几发就带几发） */
      { kind: 'gun', wid: 'rpg', p: 1.00 },
      { kind: 'armor', armor: 'elite', p: 1.00, durPct: [0.25, 0.80] },
      { kind: 'ammo', p: 0.85 },
      { kind: 'med', p: 0.25, rarity: 'small' }
    ],
    spawn: 'slot'
  },


  /* 运兵车（truck）与它的三个变体全部搬到了 data/vehicles.js 的 VEHICLES 表，
     这里不再定义任何车辆数值 —— 改血量请去那里改。 */
};

/* 测试场手动投放专用；不加入任何关卡、增援或割草随机刷怪表。
   m38055：配置拉满 —— 这一个是"最强人机"的样板，所有 AI 机制都开着：
   包抄 + 呼叫支援 + 扔雷 + 扔烟 + 闪身枪 + 架角 + 进屋搜查 + 交替掩护跃进（humanOn 通用）
   + 残血撤退还击（retreatFire/fleeFire）+ 挨枪压上。 */
ENEMY_TYPES.flankElite = {
  ...ENEMY_TYPES.spec,
  label: '协同精英',
  brief: '满配样板：三级甲、扔雷扔烟、两人协同包抄、残血会喊支援也会撤着打；反应极快。',
  behavior: {
    ...BEHAVIOR_DEF.veteran,
    canFlank: true, canCallBackup: true,
    aggression: 1.15,            /* 更愿意在你换弹时压出来 */
    aimError: 0.82,              /* 枪法更准 */
    fleeFire: true,              /* 残血跑的时候也会回头打 */
    fleeSpdK: 1.40,
    heardStrafe: true,           /* 只听见声音也会横移找射界 */
    shotRecover: { shotgun: 0.70, other: 0.16 }
  },
  /* 血量不再单独加（原 200），与普通兵一致，全部交给三级甲去扛 */
  quickK: 0.26,                  /* 反应比职业兵还快一档 */
  visionMul: 1.60, hearMul: 1.45,
  smokeP: 0.80, smokeCd: 6.5, smokeDist: 240, smokeR: 165, smokeLife: 14,
  canThrow: true,
  weaponPool: ['rifle', 'ar', 'shotgun'], weaponRand: true,
  drops: [
    { kind: 'armor', armor: 'elite', p: 1.00, durPct: [0.35, 0.90] },
    { kind: 'smoke', p: 0.70, n: 1 },
    { kind: 'ammo', p: 0.85 },
    { kind: 'med', p: 0.40, rarity: 'small' }
  ],
  spawn: 'testOnly'
};

/* 运兵车卸下来的那四个：职业兵（三级甲/扔烟/贴墙点一枪就缩）+ 协同包抄。
   和测试场的 flankElite 是同一套行为，只是名字和掉落保持职业兵的样子，
   免得正式关里跳出"测试专用"。嫌凶就把 truck.deployMix 换成 'spec'。 */
ENEMY_TYPES.specFlank = {
  ...ENEMY_TYPES.spec,
  label: '突击兵',
  brief: '职业兵里的突击手：会扔烟、会贴墙点射，下车就会自己分「架枪 / 绕侧」，两个人的火力会夹住你。',
  behavior: {...BEHAVIOR_DEF.veteran, canFlank:true, canCallBackup:true},
  spawn: 'event'
};

/* ---------------- 通用发甲（m32947） ----------------
   谁的兵种都能穿甲，BOSS 除外。默认 on:false —— 也就是说现在除了职业兵那种"类型自带三级甲"
   的（armorKind 写在类型上）以外，谁都还没穿，随时把 on 改 true 就全面投放。
   摇法：按 table[e.type] 的顺序逐条掷，掷中即停（所以 light 0.30 + heavy 0.12 ≈ 实际 30% 一级、约 8% 二级）。
   想给别的兵种加：table 里加一行 `guard: [{kind:'light', p:0.25}]` 就行，不用改代码。
   想临时指定某一只：`e.armorKind = 'heavy'; e.armor = undefined;`（下一帧 ensureEnemyArmor 会给它穿上）。 */
var ARMOR_ROLL = {
  on: false,
  table: {
    grunt:    [{ kind: 'light', p: 0.30 }, { kind: 'heavy', p: 0.12 }],
    hunter:   [{ kind: 'light', p: 0.30 }, { kind: 'heavy', p: 0.12 }],
    guard:    [{ kind: 'light', p: 0.30 }, { kind: 'heavy', p: 0.12 }],
    sentinel: [{ kind: 'light', p: 0.30 }]
  }
};

/* 掷弹兵：把一部分普通步枪兵替换成"会扔雷的普通兵"。
   规则（跟用户定的）：
   - 只在你明确允许的地方生效 —— `L.rules.grenadierP` 写了就用它，没写就只有测试区（rules.devTest）用默认值；
   - 战斗爽（ar）与所有老关卡一律概率 0 —— 不写 rules.grenadierP 的老关卡，一个都不会刷；
   - 只替换 grunt（哨兵/职业兵/刀手/BOSS 都不动）。
   想全面开：在关卡 rules 里写 `grenadierP: 0.2` 即可；想彻底关：`grenadierP: 0`。 */
var GRENADIER = {
  on: true,
  p: 0.20,            /* 测试区默认概率（rules.devTest 时用） */
  type: 'grenadier',
  from: ['grunt']     /* 只有这些兵种会被替换 */
};


/* 背包掉落：普通兵极小概率掉三级包，职业兵/突击兵大概率掉。
   不进 drops 表，单独一次掷骰 —— 这样调概率只改这一处，不用动十几个兵种的数据。
   on:false 一键关；tier 改 'mid'/'small' 就换包；p.normal / p.elite 是概率；elite 列了谁是精锐。 */
var BAG_DROP = {
  on: true,
  /* 三级包（远征 36 格）只在精锐身上、而且概率不高；二级包（战术 20 格）精锐常有、普通兵很少 */
  pBig: { normal: 0.00, elite: 0.25 },
  pMid: { normal: 0.05, elite: 0.35 },
  elite: ['spec', 'specFlank']
};
