/* M1.1：现有权威数据的观察型注册表。
   这里只登记原对象引用和 owner，不复制、不合并、不冻结业务数据，也不切换旧消费者。 */
var GameData = (function(root){
  'use strict';
  var records = Object.create(null);
  var order = [];
  var duplicates = [];

  function add(id, owner, getter, shape, requiredIds, itemFields){
    if (records[id]){ duplicates.push(id); return; }
    var value;
    try { value = getter(); } catch (err) { value = undefined; }
    var rec = {
      id: id,
      owner: owner,
      shape: shape || 'table',
      requiredIds: Object.freeze((requiredIds || []).slice()),
      itemFields: Object.freeze((itemFields || []).slice()),
      value: value
    };
    Object.freeze(rec);
    records[id] = rec;
    order.push(id);
  }

  /* 核心玩法数据。大型 base64 媒体、音频缓存和运行时数组故意不登记。 */
  add('ammo',             'data/items.js',               function(){ return typeof AMMO !== 'undefined' ? AMMO : root.AMMO; }, 'table', ['pistol','shotgun','rifle'], ['id','label']);
  add('weapons',          'data/items.js',               function(){ return typeof WEAPONS !== 'undefined' ? WEAPONS : root.WEAPONS; }, 'table', ['pistol','shotgun','rifle','rpg'], ['wid','name']);
  add('rocketProjectile', 'data/items.js',               function(){ return typeof ROCKET_DEF !== 'undefined' ? ROCKET_DEF : root.ROCKET_DEF; }, 'table', ['speed','blastRadius','damageCenter','damageEdge','damageFalloffPower','vehicleDamageK','projectileLife','projectileRadius','noiseFire','noiseBlast']);
  add('fragGrenade',      'data/items.js',               function(){ return typeof FRAG_GRENADE_DEF !== 'undefined' ? FRAG_GRENADE_DEF : root.FRAG_GRENADE_DEF; }, 'table', ['fuse','blastRadius','damageCenter','damageEdge','damageFalloffPower','throwSpeed','projectileRadius','bounceRetention','tangentFriction','stopSpeed','physicsSubstep','noiseBlast']);
  add('armor',            'data/items.js',               function(){ return typeof ARMOR_DEF !== 'undefined' ? ARMOR_DEF : root.ARMOR_DEF; }, 'table', ['light','heavy','elite']);
  add('bags',             'data/items.js',               function(){ return typeof BAG_DEF !== 'undefined' ? BAG_DEF : root.BAG_DEF; }, 'table', ['small','mid','big']);
  add('attachments',      'data/attachments.js',         function(){ return typeof ATTACH_DEF !== 'undefined' ? ATTACH_DEF : root.ATTACH_DEF; }, 'table');
  add('weaponCore',       'data/weapon_core.js',         function(){ return typeof WEAPON_CORE_DEF !== 'undefined' ? WEAPON_CORE_DEF : root.WEAPON_CORE_DEF; }, 'table', ['cap','rof','reloadDur']);
  add('enemyBehaviors',   'data/enemies.js',             function(){ return typeof BEHAVIOR_DEF !== 'undefined' ? BEHAVIOR_DEF : root.BEHAVIOR_DEF; }, 'table', ['normal']);
  add('enemies',          'data/enemies.js',             function(){ return typeof ENEMY_TYPES !== 'undefined' ? ENEMY_TYPES : root.ENEMY_TYPES; }, 'table', ['dummy','grunt'], ['label','kind']);
  add('rocketTurret',     'data/enemies.js',             function(){ return ROCKET_TURRET_DEF; }, 'table', ['hp','baseHalf','placeClearance','initialCooldown','attackCooldown']);
  add('vehicles',         'data/vehicles.js',            function(){ return root.VEHICLES; }, 'table', ['truck','truck_apc','truck_pickup','truck_civil'], ['label','hp']);
  add('enemyStatus',      'data/status.js',              function(){ return typeof ESTATUS_DEF !== 'undefined' ? ESTATUS_DEF : root.ESTATUS_DEF; }, 'table');
  add('aiFlank',          'data/ai.js',                  function(){ return typeof DataFLANK !== 'undefined' ? DataFLANK : root.DataFLANK; }, 'table');
  add('aiRocket',         'data/ai.js',                  function(){ return typeof DataRPG !== 'undefined' ? DataRPG : root.DataRPG; }, 'table');
  add('factionLook',      'data/factionlook.js',          function(){ return typeof FACTION_LOOK !== 'undefined' ? FACTION_LOOK : root.FACTION_LOOK; }, 'table', ['enemy','bandit']);
  add('aiRofCap',         'data/ai.js',                  function(){ return DataROF_CAP; }, 'table', ['default','modeKeys']);
  add('sfxFoot', 'data/ai.js', function(){ return typeof DataSfxFoot !== 'undefined' ? DataSfxFoot : root.DataSfxFoot; }, 'table', ['life','maxAlive']);
add('aiStructFight', 'data/ai.js', function(){ return DataStructFight; }, 'table', ['on', 'spdK', 'holdR']);
/* 3-4 专用：刀手砍完的僵直时长（按难度档） */
add('callout', 'data/ai.js', function(){ return DataCallout; }, 'table', ['on','radius','weatherK','delay']);
add('aiKnifeLock', 'data/ai.js', function(){ return DataKnifeLock; }, 'table', ['on', 'miss', 'extra']);
  add('aiHuman',          'data/ai.js',                  function(){ return typeof DataHUMAN !== 'undefined' ? DataHUMAN : root.DataHUMAN; }, 'table');
  add('aiEngage',         'data/ai.js',                  function(){ return typeof DataENGAGE !== 'undefined' ? DataENGAGE : root.DataENGAGE; }, 'table');
  add('navBudget',        'data/ai.js',                  function(){ return DataNAV_BUDGET; }, 'table');
  add('aiLod',            'data/ai.js',                  function(){ return DataAI_LOD; }, 'table');
  add('factionPerf',      'data/ai.js',                  function(){ return DataFACTION_PERF; }, 'table');
  add('bossKits',         'data/bosses.js',              function(){ return typeof BOSS_KIT !== 'undefined' ? BOSS_KIT : root.BOSS_KIT; }, 'table');
  add('levels',           'data/levels.js',              function(){ return typeof LEVELS !== 'undefined' ? LEVELS : root.LEVELS; }, 'list', [], ['name','w','h']);
  add('covers',           'data/covers.js',              function(){ return typeof COVER_DEF !== 'undefined' ? COVER_DEF : root.COVER_DEF; }, 'table');
  add('breakableWall',    'data/covers.js',              function(){ return typeof BREAKABLE_WALL_DEF !== 'undefined' ? BREAKABLE_WALL_DEF : root.BREAKABLE_WALL_DEF; }, 'table', ['hp','segmentPx','maxSegments']);
  add('lootCrates',       'data/lootcrate.js',           function(){ return typeof LOOT_CRATE !== 'undefined' ? LOOT_CRATE : root.LOOT_CRATE; }, 'table');
  add('gachaValues',      'data/gacha.js',               function(){ return typeof GACHA_VAL !== 'undefined' ? GACHA_VAL : root.GACHA_VAL; }, 'table');
  add('lootKinds',        'data/lootkinds.js',           function(){ return typeof LOOT_KIND_DEF !== 'undefined' ? LOOT_KIND_DEF : root.LOOT_KIND_DEF; }, 'table', ['ammo','gun','med'], ['label']);
  add('bindings',         'data/bindings.js',            function(){ return typeof DataBINDINGS !== 'undefined' ? DataBINDINGS : root.DataBINDINGS; }, 'list');
  add('coverLayout',      'data/coverLayout.js',         function(){ return typeof COVER_LAYOUT !== 'undefined' ? COVER_LAYOUT : root.COVER_LAYOUT; }, 'list');
  add('debris',           'data/debris.js',              function(){ return typeof DEBRIS_DEF !== 'undefined' ? DEBRIS_DEF : root.DEBRIS_DEF; }, 'table');
  add('wire',             'data/wire.js',                function(){ return typeof WIRE_DEF !== 'undefined' ? WIRE_DEF : root.WIRE_DEF; }, 'table');
  add('decor',            'data/decor.js',               function(){ return typeof DECOR_DEF !== 'undefined' ? DECOR_DEF : root.DECOR_DEF; }, 'table');
  add('roofs',            'data/roofs.js',               function(){ return typeof ROOF_DEF !== 'undefined' ? ROOF_DEF : root.ROOF_DEF; }, 'table');
  add('roomTemplates',    'data/roomTemplates.js',       function(){ return typeof ROOM_TEMPLATES !== 'undefined' ? ROOM_TEMPLATES : root.ROOM_TEMPLATES; }, 'table');
  add('ui',               'data/ui_config.js',           function(){ return typeof UI_CFG !== 'undefined' ? UI_CFG : root.UI_CFG; }, 'table');
  add('arenaSlotUi',      'data/ui_config.js',           function(){ return DataARENA_SLOT_UI; }, 'table', ['text','palette','layout']);
  add('factions',         'data/factions.js',            function(){ return typeof FACTION_DEF !== 'undefined' ? FACTION_DEF : root.FACTION_DEF; }, 'table', ['player','enemy','bandit','neutral'], ['label','hostiles']);
  add('factionHate',      'data/factions.js',            function(){ return typeof FACTION_HATE_DEF !== 'undefined' ? FACTION_HATE_DEF : root.FACTION_HATE_DEF; }, 'table');
  add('companionPack',    'data/companion_inventory.js', function(){ return typeof COMPANION_PACK !== 'undefined' ? COMPANION_PACK : root.COMPANION_PACK; }, 'table');

  function validate(){
    var errors = [];
    var warnings = [];
    for (var i = 0; i < duplicates.length; i++) errors.push({ code:'duplicate-id', id:duplicates[i] });
    for (var oi = 0; oi < order.length; oi++){
      var id = order[oi], rec = records[id], value = rec.value;
      if (!rec.owner) errors.push({ code:'missing-owner', id:id });
      if (value == null){ errors.push({ code:'missing-value', id:id, owner:rec.owner }); continue; }
      var shapeOk = rec.shape === 'list' ? Array.isArray(value) : (typeof value === 'object' && !Array.isArray(value));
      if (!shapeOk){ errors.push({ code:'wrong-shape', id:id, expected:rec.shape }); continue; }
      for (var ri = 0; ri < rec.requiredIds.length; ri++){
        var req = rec.requiredIds[ri];
        if (!Object.prototype.hasOwnProperty.call(value, req)) errors.push({ code:'missing-id', id:id, key:req });
      }
      if (rec.itemFields.length){
        var keys = Array.isArray(value) ? value.map(function(_, n){ return n; }) : Object.keys(value);
        for (var ki = 0; ki < keys.length; ki++){
          var item = value[keys[ki]];
          if (!item || typeof item !== 'object') continue;
          for (var fi = 0; fi < rec.itemFields.length; fi++){
            var field = rec.itemFields[fi];
            if (!Object.prototype.hasOwnProperty.call(item, field)) errors.push({ code:'missing-field', id:id, key:String(keys[ki]), field:field });
          }
        }
      }
    }
    return { ok: errors.length === 0, errors: errors, warnings: warnings, checked: order.length };
  }

  var api = {
    version: 1,
    get: function(id){ return records[id] && records[id].value; },
    has: function(id){ return !!records[id]; },
    ids: function(){ return order.slice(); },
    describe: function(id){ return records[id]; },
    list: function(){ return order.map(function(id){ return records[id]; }); },
    validate: validate
  };
  Object.freeze(api);
  return api;
})(typeof globalThis !== 'undefined' ? globalThis : window);

if (typeof window !== 'undefined') window.GameData = GameData;
