/* 队友共享视野配置。运行时由 game/41-companions.js 管理。 */
const DataCOMPANION_VISION_RAYS=24;
