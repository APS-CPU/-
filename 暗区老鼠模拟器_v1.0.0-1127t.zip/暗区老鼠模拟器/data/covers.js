/* ============================================================================
   掩体 / 墙 —— 类型清单（第 12 轮新增）
   ----------------------------------------------------------------------------
   这里只回答一个问题：「这块东西是什么」。
   尺寸、材质、高度档、能不能打碎 —— 全是配置。
   怎么画、怎么挡人、怎么挡视线、打中出什么粒子，全在主文件里按字段分派。
   （数据里不写画法、不写判定，和 data/items.js 一个规矩。）

   关卡里两种写法都能用，老的永远合法：

     {x:900,y:380,w:110,h:110}                  // 老写法：水泥墙，满高，打不烂
     {t:'crate',  x:640, y:520}                 // 新写法：尺寸/材质/状态全从这张表来
     {t:'crate2', x:760, y:900, w:56, h:56}     // 临时覆盖尺寸也行

   字段说明：
     tag  'wall'  承重墙 / 房间隔断（大、长、不能动）
          'shelf' 货架、货堆（长条，铁皮）
          'prop'  场地物件（挡板、立柱）
          'cover' 战术掩体（小而多，专门给人打枪用的）
     mat  'stone' 水泥 | 'metal' 铁皮 | 'wood' 木头
          —— 决定配色、弹着点粒子（土灰 / 火花）、命中音
     h    'high' 满高 | 'low' 矮（留着头顶）
          ⚠ 现在全部按 high 算：'low' 只记在数据里、还没有接进视线判定。
            原因见 交接_掩体系统.md §7：矮掩体如果「看得过去但子弹打不穿」，
            就成了「看着能打却打不到」，违反第 3 条铁律，要改必须连子弹一起改。
     st   'solid' 打不烂 | 'brk' 打得烂（要配 hp） | 'glass' 一枪碎
     label 中文名，只给人看（编辑器 / 以后的图鉴）
     sz   [w,h] 预设尺寸；关卡不写 w/h 时用它
     hp   可破坏时的血量（不写就用全局 BRK_HP）
   ============================================================================ */

/* 可破坏墙的权威基础参数（M1.2）。
   只搬运原来 game/26-breakwall.js 的三个常量；公式和运行时状态仍留在 game/。 */
const BREAKABLE_WALL_DEF = {
  hp: 340,          /* 默认整墙总血量 */
  segmentPx: 66,   /* 长边每约多少像素切一段 */
  maxSegments: 12  /* 单墙最多分段数 */
};
if (typeof window !== 'undefined') window.BREAKABLE_WALL_DEF = BREAKABLE_WALL_DEF;

const COVER_DEF = {
  /* —— 承重 / 隔断：大件，本来就在关卡里，写在这只是为了让编辑器能认出来 —— */
  wall:   { tag:'wall',  mat:'stone', h:'high', st:'solid', label:'水泥隔墙' },
  shelf:  { tag:'shelf', mat:'metal', h:'high', st:'solid', label:'货架',     sz:[560,30] },
  panel:  { tag:'prop',  mat:'metal', h:'high', st:'solid', label:'铁挡板',   sz:[26,220] },
  pillar: { tag:'prop',  mat:'stone', h:'high', st:'solid', label:'水泥立柱', sz:[90,90]  },

  /* —— 战术掩体：第 17 轮只留木箱 / 小木箱 ——
     袋堆、隔离墩、油桶、水泥墩、轮胎堆的画法和清单条目都删了（用户：只留能打碎的木箱）。
     以后要加新掩体，在这里加一条，再去主文件 drawCover 加一个同名分支。 */
  crate:   { tag:'cover', mat:'wood',  h:'high', st:'brk', sight:'low', label:'木箱',     sz:[70,70], hp:220 },
  crate2:  { tag:'cover', mat:'wood',  h:'high', st:'brk', sight:'low', label:'小木箱',   sz:[52,52], hp:150 },

  /* 战利品木箱（第 18 轮）：能按交互键搜刮，也能一枪打爆；打开之后还是掩体，
     再打烂才彻底没有。loot:true 是给主文件看的开关，具体参数在 data/lootcrate.js。
     第 27 轮按主题分出四种：箱子越大/越值钱，开得越慢（dur 在 lootcrate.js）。 */
  lootcrate:{ tag:'cover', mat:'wood', h:'high', sight:'low', st:'brk',  label:'通用物资箱', sz:[40,40], hp:160, loot:true, lootKind:'mixed' },
  crateMed: { tag:'cover', mat:'wood', h:'high', sight:'low', st:'brk',  label:'医疗箱',   sz:[36,30], hp:140, loot:true, lootKind:'med'  },
  crateAmmo:{ tag:'cover', mat:'wood', h:'high', sight:'low', st:'brk',  label:'弹药箱',   sz:[44,30], hp:150, loot:true, lootKind:'ammo' },
  crateGear:{ tag:'cover', mat:'metal', h:'high', sight:'low', st:'brk', label:'军械箱',   sz:[46,34], hp:210, loot:true, lootKind:'gear' },
  crateJunk:{ tag:'cover', mat:'wood', h:'high', sight:'low', st:'brk',  label:'杂物箱',   sz:[40,36], hp:120, loot:true, lootKind:'junk' },
/* 长条武器箱：又长又矮的军械箱，专门装枪 —— 开得最慢、出枪概率最高。
   尺寸 96×30 是为了"一眼看出它不是普通箱子"。 */
crateWeap:{ tag:'cover', mat:'metal', h:'high', sight:'low', st:'brk', label:'长条武器箱', sz:[96,30], hp:190, loot:true, lootKind:'weap' },
/* 空投箱：信号枪叫下来的，120×44 长方铁箱，红箍白标识（红烟落地才生成） */
  /* 配件箱（第 73 轮）：小铁盒，只出 1 件配件。可打爆（hp 比木箱低），
     比武器箱更少见 —— 用户要"专门开配件的容器，但不能只有它能出配件"。 */
  crateAttach:{ tag:'cover', mat:'metal', h:'high', sight:'low', st:'brk', label:'配件箱', sz:[30,26], hp:95, loot:true, lootKind:'attach' },
crateAir: { tag:'cover', mat:'metal', h:'high', sight:'low', st:'brk', label:'空投箱', sz:[120,44], hp:260, loot:true, lootKind:'air' },

  /* 报废汽车（第 62 轮）：用户要「无血量、不可打掉、遮挡视野」的硬掩体。
     st:'solid' → 永远不会进 L.brk，damageWall 根本不认它，所以打不烂；
     sight 不写 = 'high' → 挡玩家也挡敌人视线（箱子那种腰高的才写 'low'）；
     h:'high' 满高，子弹也拦。尺寸 132×78 是"横着拦路像一辆车"的比例 ——
     第 62 轮第一版用 128×60，用户说"太扁了"，所以把车宽（俯视看是高度）加厚。 */
  wreckcar: { tag:'cover', mat:'metal', h:'high', st:'solid', label:'报废汽车', sz:[132,78] },
  /* 只剩后半截的（用户要"断一半的"）：尺寸也跟着短，AABB 跟画出来的东西对齐
     —— 铁律第 3 条「看到多大就挡多大」，半辆车不能占整辆车的框。 */
  wreckcarHalf: { tag:'cover', mat:'metal', h:'high', st:'solid', label:'半截汽车', sz:[72,78], skin:'half' },

  /* 瞭望塔（第 65 轮）：站上去视野变远、变窄，发现敌人就实时报给队友。
     · st:'solid' + 无 hp → 打不烂（是个建筑，不是掩体）；
     · sight 默认 'high' → 塔身照样挡视线挡子弹，所以塔基是一块实心方块；
     · 交互不是"走过去"，是走到旁边按 E **爬上去**（见 game/31-watchtower.js），
       爬上去之后人在平台中心，可以原地转视角，按 E 下来。
     尺寸 104×104：底下四根柱子 + 中间一块站人的平台，站上去以后视野覆盖大半个场地。 */
  /* 保险箱：不写 hp → 打不烂；lootKind 让 crateDef() 认成箱子；
     keyLock 让 trySearchCrate() 先查钥匙。sight:'low' = 齐腰高，不挡视野但挡子弹。 */
  safe: { tag:'cover', mat:'metal', h:'low', st:'solid', label:'保险箱', sz:[46,42],
          loot:true, lootKind:'safe', sight:'low' },

  watchtower: { tag:'cover', mat:'wood', h:'high', st:'solid', label:'瞭望塔', sz:[104,104], hi:64 },
  /* 瞭望塔 · 第一版（平的）：玩法相同，只是画法不同 —— 用户 m11210「第一版也挺好看」，留着当另一款。 */
  watchtowerOld: { tag:'cover', mat:'wood', h:'high', st:'solid', label:'瞭望塔（平顶）', sz:[104,104] },

  /* 物资堆（第 28 轮）：箱子的下位变体。**不进 L.walls**，走单独的 piles[] —— 不挡人、
     不挡子弹，纯粹是"能搜、能打散"的一堆东西。noBlock 是给生成器/测试看的标记。
     第 29 轮：46×38 → **80×46**（更扁更宽），因为用户说"太小了，平摊一点占的地方多一点"。 */
  lootpile: { tag:'cover', mat:'wood', h:'low',  st:'brk',  label:'物资堆',   sz:[80,46], hp:110, loot:true, lootKind:'pile', noBlock:true },

  /* —— 门 / 玻璃 —— */
  /* 铁门（第 20 轮）：不是 L.walls 里的墙，而是关卡 doors:[] 里的可开关门。
     子弹穿得过去但会啃它血；关上挡人挡视线；按 E 开关（无读条）。
     isLocked / keyId 是给以后的钥匙道具预留的（现在门默认不锁）。 */
  door:   { tag:'door',  mat:'metal', h:'high', st:'brk',   label:'铁门', sz:[26,120], hp:220, door:true, range:64 },
  /* 平开门（第 21 轮）：一整块门板绕左边那根轴转 90 度，不是往两边缩。
     比例 1:2.6（46×120），比老滑门粗，看着才像门；
     开了之后门板横过来、碰撞体也跟着变横（挡的是横在门口的那一条）。 */
  doorSwing:{ tag:'door', mat:'metal', h:'high', st:'brk', label:'平开门', sz:[30,44], hp:560, door:true, swing:true, range:64, skin:'wall' },
  glass:  { tag:'door',  mat:'glass', h:'high', st:'glass', label:'玻璃' }
};

/* 门的配色（第 24 轮）：门得跟环境融在一起，不能老是那块暖木色。
   关卡里写 {t:'doorSwing', skin:'rust'} 就能换，不写就用 'wall'（跟墙同色系）。
   只放颜色，别在这里写绘制逻辑 —— 怎么画在主文件的 drawSwing 里。 */
const DOOR_SKIN = {
  wall:  { label:'跟墙同色', frame:'#2f353c', leaf:'#3d444c', hi:'rgba(196,214,230,0.10)', lo:'rgba(8,10,14,0.45)' },
  steel: { label:'冷灰钢',   frame:'#3c444d', leaf:'#556069', hi:'rgba(214,230,244,0.14)', lo:'rgba(10,14,18,0.42)' },
  wood:  { label:'旧木门',   frame:'#4a3b28', leaf:'#846d4c', hi:'rgba(236,226,200,0.14)', lo:'rgba(14,11,8,0.42)' },
  rust:  { label:'锈铁门',   frame:'#43302a', leaf:'#6b4636', hi:'rgba(240,206,178,0.12)', lo:'rgba(16,10,8,0.44)' }
};

/* 报废汽车的 8 款（第 62 轮）：6 个配色 + 两种残法（缺头 / 断一半）。
   和 DOOR_SKIN 一个规矩：这里只有颜色和形态开关，怎么画在 game/27-debris.js 的 drawCover 里。
   配色全部压在低饱和上（跟墙、木箱、地面同一档），别用鲜色，否则夜关里一眼假。 */
const CAR_SKIN = {
  rust:   { label:'锈棕',   body:'#5a4e42', roof:'#6a5e50', edge:'#17130f', rust:'rgba(126,76,38,0.34)' },
  blue:   { label:'深蓝',   body:'#3f4b5b', roof:'#4b586a', edge:'#12161c', rust:'rgba(112,78,44,0.30)' },
  white:  { label:'褪色白', body:'#87837a', roof:'#98948a', edge:'#2c2925', rust:'rgba(124,86,50,0.30)' },
  olive:  { label:'军绿',   body:'#4a5140', roof:'#565f4a', edge:'#191d16', rust:'rgba(116,78,42,0.32)' },
  wine:   { label:'暗红',   body:'#5c3a36', roof:'#6b4642', edge:'#1e1211', rust:'rgba(122,72,40,0.30)' },
  burnt:  { label:'烧黑',   body:'#2c2823', roof:'#37322b', edge:'#0c0a08', rust:'rgba(150,146,136,0.20)', burnt:true },
  nohead: { label:'缺头',   body:'#565044', roof:'#655e50', edge:'#17130f', rust:'rgba(126,76,38,0.34)', noHead:true },
  half:   { label:'断一半', body:'#6a5f4c', roof:'#7a6e58', edge:'#241d15', rust:'rgba(124,78,40,0.34)', half:true }
};

/* 一条数据 → 一块能进 L.walls 的矩形。写在这里、只写一次：
   主文件只调它，不再各自拼字段。缺字段就按 COVER_DEF 补默认值。 */
function coverMake(t, o){
  const d = COVER_DEF[t] || COVER_DEF.wall;
  const sz = d.sz || [90, 90];
  return {
    x: o.x, y: o.y,
    w: (o.w != null ? o.w : sz[0]),
    h: (o.h != null ? o.h : sz[1]),
    mat: o.mat || d.mat,
    tag: d.tag,
    ch: d.h,                  /* 高度档，先存着，不参与判定 */
    sight: d.sight || 'high', /* 挡不挡视线：'low' 挡敌人、不挡玩家（木箱这种腰高的） */
    st: d.st,
    cov: t,                   /* 画法用的类型名（绘制时按它分派） */
    label: d.label,
    hp: (o.hp != null ? o.hp : d.hp),
    loot: !!d.loot,           /* 战利品木箱：能搜刮（参数见 data/lootcrate.js） */
    lootKind: d.lootKind || (d.loot ? 'mixed' : null),   /* 哪一型箱子：决定了掉落表和开箱时间 */
    locker: !!d.locker,       /* 军械箱那种"要撬/上锁"的，先留字段（本轮不启用） */
    noBlock: !!d.noBlock,     /* 物资堆：不进 L.walls，不挡人不挡子弹 */
    door: !!d.door,           /* 门：走 L.doors 那套开关/挡人逻辑 */
    hi: d.hi || 0,            /* 画面上"往上方长出多少像素"（伪 3D 的高，只有画法用，碰撞仍是 w×h） */
    skin: o.skin || d.skin || 'wall'   /* 门的配色（见 DOOR_SKIN） */
  };
}

/* 瞭望塔的数值（第 65 轮）。全在这里，改一个数就够，别散到绘制代码里。
   visionK / fovK 是**乘在玩家原有视距与视角上**的：
     视距 460 → 1058（翻倍还多），视角 110° → 55°，就是"看得远但窄"。
   spotT 是报出一个敌人后标记留多久；pingT 是同一批队友被提醒的最小间隔。 */
const TOWER_TUNE = {
  visionK: 2.3,      /* 视距倍率 */
  fovK: 0.50,        /* 视角倍率（半角也跟着缩一半） */
  climbR: 74,        /* 离塔多近能爬（从塔中心算） */
  spotT: 1.6,        /* 敌人头顶的播报标记维持多久 */
  pingT: 2.6,        /* 队友被同一批情报刷新的最小间隔（防止每帧狂刷） */
  pingR: 1400,       /* 播报半径：塔上看得见的，隔多远都能报给队友 */
  maxSpot: 12,       /* 一次最多报几个，防止满屏标记 */
  markT: 4.5,        /* 队友记着这个报点多久（到期就回去跟着你） */
  goR: 90,           /* 队友走到离报点多近算"到位"，到位就原地警戒 */
  guardR: 260        /* 人上塔时，队友围着塔多近待着（视野窄，需要人守塔底） */
};
