/* =========================================================================
   暗区老鼠模拟器 · 数据文件：BOSS 能力（ability）表
   -------------------------------------------------------------------------
   只放配置，不放逻辑。逻辑在 arenaBossTick 里那一个通用执行器：
     · ABILITY_DEF[能力名]  = 这个能力「是什么、怎么讲给玩家听、默认参数」
     · BOSS_KIT[敌人名]     = 这只 boss「会哪几个能力、血量倍率、残血后怎么变」

   加一只新 boss：在 BOSS_KIT 里加一条，abilities 里填已有能力名即可。
   给小兵挂能力：给它加 abilities:[...] 字段（通用执行器一样认）。
   想调数值：只改 ABILITY_DEF 里的 params，别处不用动。
   残血变招：phases 里写 { below:0.5, abilities:[...], cdK:0.6 }，血量低于比例就换招。
   ========================================================================= */

const ABILITY_DEF = {
  blast: {
    label: '自爆',
    brief: '贴上来点着火，引信走完就在脚下炸。炸完自己会僵一会儿，然后接着点。冲过来的时候打它，能把它顶回去、还能拖长引信。',
    /* knockPush / fuseDelay / fuseDelayMax：冲过来的时候可以拿枪把它顶回去 ——
       每打中一下往后推 knockPush 像素、引信往后拖 fuseDelay 秒，但总共最多拖 fuseDelayMax 秒，
       所以火力够能拖住它，拖不死它。 */
    params: { fuse: 0.85, radius: 170, dmgMul: 4.2, minFall: 0.30, recover: 2.4, chaseLimit: 3.2, fireAt: 210,
              knockPush: 10, fuseDelay: 0.09, fuseDelayMax: 0.6 },
  },
  charge: {
    label: '冲锋',
    brief: '蓄力后直线撞过来，落点会算你现在的速度（提前量）。一冲就是两段，第二段中途再瞄一次。',
    params: { wind: 0.55, dash: 0.5, speed: 720, dmgMul: 2.8, cd: 7.5, burst: 2, lead: 0.30, minD: 150, maxD: 660,
              kb: 1500, stun: 0.62, stunBlur: 0.74, stunBlind: 0.50, stunAlpha: 0.42,
              /* 窄地形：出手在 ±0.61rad(35°) 里挑能跑最远的方向，撞墙沿墙滑 */
              pickCone: 0.61, shortMin: 210, slideK: 0.78, slideMin: 120 },
  },
  summ: {
    label: '召唤',
    brief: '自己不怎么上，隔几秒放小兵出来。放出来的小兵直接朝你冲，越残血放得越勤。',
    params: { cd: [2.1, 1.35], count: [1, 3], doubleChance: 0.58, boost: 10, alert: 6,
              maxMinions: 8 },
              /* maxMinions：小兵自己的名额（不占全局效），满了就停止召唤 */
  },
  shove: {
    label: '盾撞',
    brief: '两片盾绕身转。蓄力后整块撞过来，冲刺时无视墙，撞到地图边界会反弹，撞满五次才停下——那才是你的输出窗口。',
    params: { wind: 0.7, dash: 1.5, speed: 620, dmgMul: 4.2, cd: 2.6, wallCd: 1.5,
              kb: 900, stun: 0.30,
              pickCone: 0.61, shortMin: 180, slideK: 0.72, slideMin: 110 },
  },
};

/* 残血阶段：hp 低于 below 就换成这套（不写 abilities 就沿用原来的） */
const BOSS_KIT = {
  charger: { label: '疯狗', tag: '近战 · 自爆', abilities: ['blast'], hpMul: 0.82, scorch: true },
  warlord: { label: '督军', tag: '远程 · 冲锋', abilities: ['charge'], hpMul: 1.0,
             phases: [{ below: 0.5, cdK: 0.55 }] },
  spawner: { label: '巢母', tag: '召唤',     abilities: ['summ'],   hpMul: 1.28,
             phases: [{ below: 0.6, cdK: 0.72 }] },
  shield:  { label: '盾卫', tag: '近战 · 盾', abilities: ['shove'],  hpMul: 1.20,
             phases: [{ below: 0.35, cdK: 0.7, dmgK: 1.15 }] },
};


/* ---------------- BOSS 自己的成长曲线 ----------------
   小兵是"难度 × 波次"两个乘法一起上，BOSS 套同一条曲线会在前几波就把人秒了。
   所以 BOSS 单独一条：开局压到 6 成，第 8 波左右回到 1.0，之后才继续线性涨。
   想调手感只动这里的数字，不用碰逻辑。 */
const BOSS_SCALE = {
  hpBase: 820, hpPerWave: 240, hpTier: 0.25,   /* 血量沿用老公式（血厚不是问题，秒人才是） */
  powStart: 0.58, powPerWave: 0.055, powTier: 0.10,  /* 伤害系数 */
  blastCapK: 0.42,   /* 自爆一次最多打掉玩家最大生命的 42% */
  dashCapK: 0.30     /* 冲撞/盾撞一次最多 30% */
};
function bossPowerK(wave, tb){
  const w = Math.max(1, wave | 0);
  const base = BOSS_SCALE.powStart + BOSS_SCALE.powPerWave * (w - 1);
  return Math.max(0.35, base) * (1 + BOSS_SCALE.powTier * (tb || 0));
}
function bossHpFor(wave, tb, hpK){
  const w = Math.max(1, wave | 0);
  const base = BOSS_SCALE.hpBase + w * BOSS_SCALE.hpPerWave;
  return Math.round(base * (1 + BOSS_SCALE.hpTier * (tb || 0)) * (hpK || 1));
}
