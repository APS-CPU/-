/* ============================================================================
   抽奖商人 · 奖品与估价表（单一口径）
   ----------------------------------------------------------------------------
   以前这两张表写在 game/61-gacha.js 里（逻辑文件），改个奖品价值得翻代码。
   现在全部在这里：
     GACHA_VAL     押注估值 —— 你押进去的东西值多少钱（按"件"算，药品按品质）
     GACHA_PRIZES  奖品清单 —— 右栏那 10 个奖品，value 是它的标价
   ----------------------------------------------------------------------------
   怎么改
     · 改某个奖品的价值 → GACHA_PRIZES 里那条的 value
     · 改奖品给多少东西 → 同一条的 give（k:'med' 是药、k:'ammo' 是子弹、k:'gun' 是枪…）
     · 上新奖品 → 往 GACHA_PRIZES 末尾加一条，id 不能和现成的重复
     · 限量奖品 → 写 stock（扔完/送完就没了）；不写就是无限
     · 改"你押的东西值多少" → GACHA_VAL（稀有度倍率在 game/61-gacha.js 的
       gachaValueOf() 里，属于逻辑，别搬）
   ----------------------------------------------------------------------------
   GACHA_VAL 的字段含义
     med {small,big}  小药 / 大药（"大药"= r:1 的那档）
     ammo/nade/smoke  按发/颗算
     attach           配件（倍率在逻辑里按品质调）
     thermal/heatcell 热成像 / 电池
     key/flare        钥匙 / 信号枪
     armor/bag/shield 护甲 / 背包 / 盾（同样按品质倍率）
   ============================================================================ */

const GACHA_VAL = {
  med: { small: 10, big: 30 },
  ammo: 14, nade: 26, smoke: 18, attach: 70,
  thermal: 160, heatcell: 150, key: 150, flare: 40,   /* m36378：电池估值 45→150（死亡地带一颗=充 10 倍电量） */
  armor: 110, bag: 130, shield: 95,
  rare: 450        /* 金条：抽奖商人收购价 */
};

const GACHA_PRIZES = [
  { id:'rpg',      label:'火箭筒',        desc:'能打烂运兵车',  value: 900, give:{ k:'gun', wid:'rpg' } },
  { id:'elite',    label:'精锐防弹衣',    desc:'减伤 50%',      value: 700, give:{ k:'armor', kind:'elite' } },
  { id:'bigbag',   label:'远征背包',      desc:'36 格',         value: 780, give:{ k:'bag', kind:'big' } },
  { id:'thermal',  label:'热成像',        desc:'穿雾看热源',    value: 900, give:{ k:'thermal' } },
  { id:'meds',     label:'绿药包 ×5',    desc:'回血 70 一包（品质另算）',  value: 220, give:{ k:'med', r:1, q:2, n:5 } },
  { id:'rockets',  label:'火箭弹 ×4',     desc:'给火箭筒吃',    value: 320, give:{ k:'ammo', t:'rocket', n:4 } },
  { id:'choke',    label:'长管收束器',    desc:'霰弹更集中',    value: 260, give:{ k:'attach', aid:'choke_long' } },
  /* m36378：热成像大加强（死亡地带容量 ×10），电池改成**只给一颗**、售价大幅上调 135 → 340 */
  { id:'heatcell', label:'热成像电池', desc:'一格充满 · 只给一颗', value: 340, give:{ k:'heatcell', n:1 } },
  { id:'nade',     label:'手榴弹 ×2',     desc:'限量 · 扔完就没了', value: 120, give:{ k:'nade', n:2 }, stock: 2 },
  /* gold:true = 商品镶金边（重要到不换就打不下去的那一件，别轻易删这个标记） */
  { id:'intel',    label:'情报',          desc:'黑匣子区域', value: 480, give:{ k:'intel' }, stock: 1, gold: true }
];

if (typeof window !== 'undefined'){
  window.GACHA_VAL = GACHA_VAL;
  window.GACHA_PRIZES = GACHA_PRIZES;
}
