/* ============================================================================
   战利品木箱 —— 搜刮参数、分箱型的掉落表、箱体配色（第 18 轮新增，第 27 轮分型）
   ----------------------------------------------------------------------------
   这里只放「搜多久、多远、掉什么、什么颜色」这些数值；怎么搜、怎么画、怎么被打爆，
   全在主文件里（和 data/covers.js 一个规矩：数据不写行为）。

   掉落是「先抽 min~max 件，每件按权重抽一样」：
     权重 w 越大越常见；durPct 是防弹衣耐久的百分比区间。
   ============================================================================ */

const LOOT_CRATE = {
  range: 50,        /* 玩家离箱子多近才能按交互键（像素） */
  dur: 1.5,         /* 搜刮读条时间（秒）—— 没写 dur 的箱型用这个 */
  openHp: 70,       /* 打开之后的"破木箱"还剩多少血：还能被打烂，但不再搜 */
  min: 2, max: 3,   /* 一次掉几件—— 没写 min/max 的箱型用这个 */

  /* 默认掉落表（kind 为 mixed 的通用木箱用它）：
     kind 和地上的战利品完全一致（med / ammo / armor），
     所以掉出来之后不用任何特殊处理，走原来的拾取逻辑。 */
  table: [
    { kind:'med',   rarity:'small', w:5 },
    { kind:'med',   rarity:'big',   w:2 },
    { kind:'ammo',  ammo:'pistol',  n:24, w:4 },
    { kind:'ammo',  ammo:'rifle',   n:30, w:3 },
    { kind:'ammo',  ammo:'shotgun', n:6,  w:2 },
    { kind:'armor', armor:'light',  durPct:[0.55, 0.9], w:3 },
    { kind:'armor', armor:'heavy',  durPct:[0.35, 0.7], w:1 },
    { kind:'ammo',  ammo:'ar',      n:25, w:2 },          /* 步枪弹 */
    { kind:'nade',  w:3 },                                 /* 手雷 */
    { kind:'armor', armor:'elite',  durPct:[0.30, 0.85], w:1 },
    { kind:'bag',   bag:'small',    w:1 },
    { kind:'key',   w:1 },                                 /* 万能钥匙（一次性） */
    { kind:'rope',  w:1 },                                 /* 绳子（配手雷做绊雷） */
    { kind:'tripwire', w:0.5 },                             /* 现成的绊雷（能摸到，但比绳子少一半） */
    /* 配件散货：别的箱子也能低概率摸到（用户第 73 轮：不能只有配件箱能出配件） */
    { kind:'attach', aid:'choke_std', w:0.5, gear:true },
    { kind:'attach', aid:'mag_ext1',  w:0.5, gear:true }
  ],

  /* 分箱型：每型一套自己的掉落表 / 开箱时间 / 件数。缺省字段回落到上面。 */
  kinds: {
    mixed: { label:'通用物资箱' },

    /* 医疗箱：药为主，几乎不出枪弹，偶尔一件轻甲 */
    med: {
      label: '医疗箱', dur: 1.2, min: 2, max: 3,
      table: [
        { kind:'med',   rarity:'small', w:7 },
        { kind:'med',   rarity:'big',   w:4 },
        { kind:'ammo',  ammo:'pistol',  n:12, w:1 },
        { kind:'armor', armor:'light',  durPct:[0.5, 0.85], w:1 }
      ]
    },

    /* 弹药箱：只出弹药，量大；顺带一点点零件（用子弹 kind 表示） */
    ammo: {
      label: '弹药箱', dur: 1.4, min: 3, max: 4,
      table: [
        { kind:'ammo', ammo:'pistol',  n:36, w:5 },
        { kind:'ammo', ammo:'rifle',   n:45, w:4 },
        { kind:'ammo', ammo:'shotgun', n:10, w:3 },
        { kind:'ammo', ammo:'ar',      n:30, w:4 }
      ]
    },

    /* 军械箱：最值钱，开得最慢，出甲和药，附加一点步枪弹 */
    gear: {
      label: '军械箱', dur: 2.2, min: 2, max: 3,
      table: [
        { kind:'armor', armor:'heavy',  durPct:[0.5, 0.9], w:5 },
        { kind:'armor', armor:'light',  durPct:[0.6, 0.95], w:3 },
        { kind:'med',   rarity:'big',   w:2 },
        { kind:'ammo',  ammo:'rifle',   n:20, w:2 },
        { kind:'ammo',  ammo:'ar',      n:25, w:3 },
        { kind:'armor', armor:'elite',  durPct:[0.55, 0.95], w:2 },
        { kind:'nade',  w:3 },
        { kind:'key',   w:2 },
        { kind:'bag',   bag:'mid',      w:1 },
        { kind:'gun',   wid:'ar',       w:1 },
        { kind:'gun',   wid:'rifle',    w:1 },
        /* 望远镜：装备类，约 7% 一箱 */
        { kind:'gun',   wid:'bino',     w:2 },
        /* 稀有装备：热成像 / 防弹盾牌。权重压到 0.6 / 0.5（约 2% 一件、6% 一箱），
           而且 gear:true —— 不算物资、只算"装备"。 */
        { kind:'thermal', w:0.6, gear:true },
        { kind:'shield',  w:0.5, gear:true },
        /* 枪口配件（收束器）：三款不同效果，权重越紧越少见 */
        { kind:'attach', aid:'choke_std',   w:2.2, gear:true },
        { kind:'attach', aid:'choke_tight', w:1.2, gear:true },
        { kind:'attach', aid:'choke_long',  w:0.6, gear:true },
        /* 突击步枪弹匣（扩容 / 快速，同一槽二选一） */
        { kind:'attach', aid:'mag_ext1',   w:1.8, gear:true },
        { kind:'attach', aid:'mag_ext2',   w:0.8, gear:true },
        { kind:'attach', aid:'mag_fast1',  w:1.8, gear:true },
        { kind:'attach', aid:'mag_fast2',  w:0.8, gear:true },
        /* 绊雷：军械箱里也能摸到成品，权重压低（约 3% 一件、8% 一箱） */
        { kind:'tripwire', w:0.7 },
        { kind:'rope',     w:0.8 },
        /* 热成像电池：v2 关卡专属（v2:true 让老关卡抽不到），约 8% 一箱 */
        { kind:'heatcell', n:1, w:0.9, v2:true }
      ]
    },

    /* 保险箱（第 70 轮）：开不动、砸不烂，只能用万能钥匙。
       里面"大概率有好东西"——所以表里全是甲、药、枪、钥匙、装备，
       没有一条是"垃圾"；件数 3~4 件，开箱 2.6 秒（比军械箱还慢）。
       以后要加"密码 / 破译"那一套，先把 keyLock 换成 lockKind 就行。 */
    safe: {
      label: '保险箱', dur: 2.6, min: 3, max: 4, keyLock: true, openHp: 60,
      table: [
        { kind:'armor', armor:'heavy',  durPct:[0.65, 0.98], w:6 },
        { kind:'armor', armor:'elite',  durPct:[0.60, 0.98], w:4 },
        { kind:'med',   rarity:'big',   w:5 },
        { kind:'gun',   wid:'ar',       w:4 },
        { kind:'gun',   wid:'rifle',    w:4 },
        { kind:'gun',   wid:'shotgun',  w:2 },
        { kind:'ammo',  ammo:'ar',      n:40, w:4 },
        { kind:'ammo',  ammo:'rifle',   n:36, w:4 },
        { kind:'nade',  w:3 },
        { kind:'key',   w:3 },
        { kind:'bag',   bag:'big',      w:2 },
        { kind:'thermal', w:1.4, gear:true },
        { kind:'shield',  w:1.0, gear:true },
        /* 稀有重火力：概率压到很低，但保险箱里确实翻得到（用户 m11840 点名要的几样） */
        { kind:'gun',   wid:'rpg',      mag:0, w:0.5 },
        { kind:'ammo',  ammo:'rocket',  n:1,   w:1.2 },
        { kind:'gun',   wid:'flare',    w:1.2 },
        { kind:'ammo',  ammo:'flare',   n:1,   w:1.2 },
        { kind:'attach', aid:'choke_tight', w:1.2, gear:true },
        { kind:'attach', aid:'mag_ext2',   w:1.1, gear:true },
        { kind:'attach', aid:'mag_ext3',   w:0.5, gear:true },
        { kind:'attach', aid:'mag_fast2',  w:1.1, gear:true },
        { kind:'attach', aid:'mag_fast3',  w:0.5, gear:true },
        /* 金条：保险箱里翻得到，但只是"比物资堆高一点点"——权重压到 0.7（≈1.4% 一件 / ≈5% 一箱） */
        { kind:'rare',  item:'gold',   w:0.7 }
      ]
    },

    /* 空投箱：信号枪叫下来的，走主文件 dropAirCrate() 的专属掉落，
       这里的 table 只是占位（万一有人复用），真正给什么不靠它。 */
    air: {
      label: '空投箱', dur: 2.8, airDrop: true, min: 0, max: 0, table: []
    },

    /* 长条武器箱：专门出枪的箱子。
       掷一次"有没有枪"（gunChance）；有枪就从 guns 里按权重抽一把，并**必定**配一份对应子弹；
       抽到 RPG 的概率单独压到 4%（"极小概率"），而且只给 0~2 发火箭弹。
       没抽到枪就退成子弹，小概率给手雷 —— 不会空手。 */
    /* 配件箱（第 73 轮）：只出 1 件，全是配件；越紧的收束器/越高的弹匣越少见 */
    attach: {
      label: '配件箱', dur: 1.8, min: 1, max: 1,
      table: [
        { kind:'attach', aid:'choke_std',   w:6 },
        { kind:'attach', aid:'mag_ext1',    w:5 },
        { kind:'attach', aid:'mag_fast1',   w:5 },
        { kind:'attach', aid:'choke_tight', w:3 },
        { kind:'attach', aid:'mag_ext2',    w:3 },
        { kind:'attach', aid:'mag_fast2',   w:3 },
        { kind:'attach', aid:'choke_long',  w:1 },
        { kind:'attach', aid:'mag_ext3',    w:1 },
        { kind:'attach', aid:'mag_fast3',   w:1 }
      ]
    },

    weap: {
      label: '长条武器箱', dur: 2.4,
      gunChance: 0.55,
      guns: [
        { wid:'rifle',   w:30, n:[30, 45] },
        { wid:'ar',      w:30, n:[25, 40] },
        { wid:'shotgun', w:20, n:[6, 10] },
        { wid:'pistol',  w:20, n:[24, 36] },
        { wid:'flare',   w:10, n:[1, 1] }
      ],
      rpg: { wid:'rpg', chance:0.04, n:[0, 2] },
      /* 没开出枪时的退路：子弹为主，手雷少见 */
      noGun: [
        { kind:'ammo', ammo:'rifle',   n:30, w:6 },
        { kind:'ammo', ammo:'ar',      n:25, w:6 },
        { kind:'ammo', ammo:'shotgun', n:8,  w:4 },
        { kind:'ammo', ammo:'pistol',  n:24, w:4 },
        { kind:'nade', w:2 }
      ]
    },

    /* 杂物箱：开得快、掉得多但都是小东西 */
    junk: {
      label: '杂物箱', dur: 0.9, min: 3, max: 4,
      table: [
        { kind:'med',   rarity:'small', w:6 },
        { kind:'ammo',  ammo:'pistol',  n:10, w:5 },
        { kind:'ammo',  ammo:'shotgun', n:3,  w:2 },
        { kind:'ammo',  ammo:'ar',      n:10, w:2 },
        { kind:'armor', armor:'light',  durPct:[0.35, 0.6], w:1 },
        { kind:'nade',  w:1 },
        { kind:'key',   w:1 },
        { kind:'heatcell', n:1, w:0.3, v2:true }
      ]
    }
  },

  /* 物资堆（第 28 轮）：箱子的下位变体 —— 少、乱、杂，偶尔出宝贝。
     不是 L.walls 里的掩体（不挡人不挡子弹），单独一个 piles[] 数组。
     和箱子共用同一套三层结构：数值在这、颜色在 LOOT_SKIN.pile、类型在 COVER_DEF.lootpile。 */
  pile: {
    range: 52,          /* 站多近能搜（比箱子宽松一点，堆子矮、看着大） */
    dur: 3.4,           /* 读条：明显比最慢的箱子（军械箱 2.2s）还慢一大截 */
    hp: 90,             /* 打两枪就散 */
    usesMin: 2, usesMax: 6,   /* 这一堆能搜几次：每次刷新随机 */
    dropMin: 0, dropMax: 2,   /* 打爆时掉 0~2 件（可能一件都没有） */
    emptyMsg: '这里已经没有什么有价值的东西了',
    /* 每次搜必掉 1 件（不翻空），什么类型都会出；稀有物品权重压到最低 */
    table: [
      { kind:'med',   rarity:'small', w:6 },
      { kind:'ammo',  ammo:'pistol',  n:8,  w:6 },
      { kind:'ammo',  ammo:'shotgun', n:2,  w:3 },
      { kind:'ammo',  ammo:'rifle',   n:6,  w:2 },
      { kind:'armor', armor:'light',  durPct:[0.25, 0.55], w:2 },
      { kind:'ammo',  ammo:'ar',      n:6,  w:1 },
      { kind:'nade',  w:1 },
      { kind:'key',   w:1 },
      { kind:'med',   rarity:'big',   w:1 },
      { kind:'heatcell', n:1, w:0.2, v2:true },  /* 热成像电池（v2 关卡专属，权重最低一档） */
      /* 装备类也会在堆里翻到（都是 gear:true —— 不记物资，只算装备），权重压到最低一档 */
      { kind:'gun',    wid:'bino', w:0.6 },      /* 望远镜 */
      { kind:'thermal', w:0.15, gear:true },     /* 热成像 */
      { kind:'shield',  w:0.15, gear:true },     /* 防弹盾牌 */
      { kind:'bag',   bag:'mid',     w:0.5 },   /* 战术背包（20 格）：堆里翻得到，但很少 */
      { kind:'rare',  item:'gold',    w:1 }      /* 万一有宝贝 */
    ]
  }
};

/* 箱体配色：闭合态的板面/铁箍、打开态露出来的内衬。纯颜色，不放逻辑。 */
const LOOT_SKIN = {
  mixed: { body:'#3a3126', band:'#454b52', bandHi:'rgba(206,222,238,0.16)', mark:null,
           wall:'#4a3f2e', cloth:'#2a231b' },
  med:   { body:'#4a4640', band:'#8d939a', bandHi:'rgba(236,242,248,0.22)', mark:'cross',
           wall:'#55524b', cloth:'#2d2b27' },
  ammo:  { body:'#3d4231', band:'#6b6a4a', bandHi:'rgba(226,222,176,0.18)', mark:'stripe',
           wall:'#4a4f3a', cloth:'#2b2c22' },
  gear:  { body:'#33392f', band:'#7d8272', bandHi:'rgba(226,236,214,0.20)', mark:'bolt',
           wall:'#3f453a', cloth:'#232620' },
  junk:  { body:'#463d33', band:'#6e655a', bandHi:'rgba(226,216,200,0.16)', mark:'tape',
           wall:'#52483c', cloth:'#2b2620' },
  /* 长条武器箱：冷调枪钢 + 一条浅米色长标识（形状见主文件的 mark === 'rifle'） */
  weap:  { body:'#2f3336', band:'#9aa3ab', bandHi:'rgba(232,240,248,0.24)', mark:'rifle',
           wall:'#3a3f43', cloth:'#20242a' },
  /* 空投箱：军绿铁箱 + 一道鲜红箍（和信号枪同一套颜色，一眼认出是空投） */
  air:   { body:'#3a3f38', band:'#e2565f', bandHi:'rgba(255,214,218,0.30)', mark:'flare',
           wall:'#2c322b', cloth:'#1c211b' },

  /* 物资堆：不用板面/铁箍，按"品类"给几组颜色 —— 一堆破烂里必须有亮色，
     全土色看着就像土疙瘩，所以玻璃/塑料/纸/铁皮各有一组。 */
  pile:  { body:'#3b352c', band:'#565046', bandHi:'rgba(222,214,198,0.14)', mark:null,
           wall:'#463f34', cloth:'#282219',
           junk:    ['#4a4034', '#5a5042', '#39322a', '#6b6152', '#33302a', '#54493c'],
           wood:    ['#6b563f', '#5b4a36', '#7a6248', '#4a3b2b'],
           carton:  ['#8a6f4c', '#9c7f57', '#7a6244', '#ab8d63'],
           metal:   ['#6a7078', '#565c64', '#7b828a', '#8d949c'],
           glass:   ['rgba(150,205,190,0.62)', 'rgba(140,180,215,0.58)',
                     'rgba(205,230,210,0.55)', 'rgba(220,238,244,0.50)',
                     'rgba(176,150,205,0.55)'],
           plastic: ['#a8543c', '#3f6b8a', '#b8903a', '#4d7a52', '#8a4a6b', '#c46a3c'],
           paper:   ['#c9c2ae', '#b8b0a0', '#d8d2c0'] }
,
  /* 配件箱：小铁盒，比武器箱亮一点点的枪钢色 + 一条窄钢箍 */
  attach:{ body:'#343a3f', band:'#8f9aa4', bandHi:'rgba(232,240,248,0.22)', mark:'bolt',
           wall:'#3d4348', cloth:'#22262b' },
  /* 保险箱：冷灰蓝钢壳，比木箱低饱和，跟铁门/车是同一档 */
  safe: { body:'#39424a', bodyHi:'#4c5761', bodyLo:'#212831', rim:'#8d9aa4' }};
