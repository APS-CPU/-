// data/audio.js —— \u97f3\u9891\u6ce8\u518c\u8868\uff08\u7b2c 14 \u8f6e\uff09
// \u7528\u6cd5\uff1a\u628a\u540c\u540d\u6587\u4ef6\u4e22\u8fdb _game/assets/audio/<\u5206\u7c7b>/\uff0c\u6e38\u620f\u4f1a\u81ea\u52a8\u7528\u5b83\uff1b
// \u6ca1\u653e\u5c31\u7ee7\u7eed\u7528\u539f\u6765\u90a3\u5957 WebAudio \u5408\u6210\u97f3\uff0c\u4e0d\u4f1a\u53d8\u54d1\u3002
const AUDIO_DIR = 'assets/audio/';

const AUDIO_FILE = {
  /* gun */
  'gun.pistol':   'gun/pistol.mp3',
  'gun.shotgun':  'gun/shotgun.mp3',
  'gun.rifle':    'gun/rifle.mp3',
  'gun.uzi':     'gun/uzi.mp3',
  'gun.shotgun.load':  'gun/shotgun_load.mp3',
  'gun.shotgun.pump':  'gun/shotgun_pump.mp3',
  'gun.uzi.reload':    'gun/uzi_reload.mp3',
  'gun.pistol.reload': 'gun/pistol_reload.mp3',
  'gun.dry':      'gun/dry.mp3',
  'gun.reload':   'gun/reload.mp3',
  'gun.switch':   'gun/switch.mp3',
  /* 敌人的枪声：比玩家闷、比玩家沉；l/c/r 已经把声像写进去了 */
  'gun.enemy.pistol.l':  'gun/enemy_pistol_l.mp3',
  'gun.enemy.pistol.c':  'gun/enemy_pistol_c.mp3',
  'gun.enemy.pistol.r':  'gun/enemy_pistol_r.mp3',
  'gun.enemy.rifle.l':   'gun/enemy_rifle_l.mp3',
  'gun.enemy.rifle.c':   'gun/enemy_rifle_c.mp3',
  'gun.enemy.rifle.r':   'gun/enemy_rifle_r.mp3',
  'gun.enemy.shotgun.l': 'gun/enemy_shotgun_l.mp3',
  'gun.enemy.shotgun.c': 'gun/enemy_shotgun_c.mp3',
  'gun.enemy.shotgun.r': 'gun/enemy_shotgun_r.mp3',
  /* hit */
  'hit.flesh':    'hit/flesh.mp3',
  'hit.crit':     'hit/crit.mp3',
  'hit.wall':     'hit/wall.mp3',
  'hit.kill':     'hit/kill.mp3',
  /* chain */
  'chain.pull':   'chain/pull.mp3',
  'chain.clank':  'chain/clank.mp3',
  'chain.lock':   'chain/lock.mp3',
  'chain.stamp':  'chain/stamp.mp3',
  'chain.drag':   'chain/drag.mp3',
  'chain.whoosh': 'chain/whoosh.mp3',
  /* boss */
  'boss.wave':    'boss/waveclear.mp3',
  'boss.slam':    'boss/slam.mp3',
  /* ui */
  'ui.click':     'ui/click.mp3',
  'ui.pick':      'ui/pick.mp3',
  'ui.levelup':   'ui/levelup.mp3',
  /* 赌卡：第一次把「老实抽卡」举起来时放，配合卡牌四周渗出的红光 */
  'card.honest':  'ui/honest_card.mp3'
};

/* 运兵车实录音（m24105）：一个 mp3 里两段，前段=漂移进场，后段=开走。
   不用切文件，靠 a/b 两个时间点截取。要换素材就重测这两个点。
   实测（Edge 解码读到的是 48000Hz 重采样版）：
     总长 12.565s；进场段 0.00~3.40；3.46~6.04 是静音；开走段 6.05~12.55。 */
const TRUCK_SFX = {
  file: 'truck/drift.mp3',
  drift: { a: 0.00, b: 3.40 },
  leave: { a: 6.05, b: 12.55 }
};

const AUDIO_POOL_N = 5;

/* \u67aa\u58f0\u6700\u5c0f\u95f4\u9694\uff1a\u9ad8\u5c04\u901f\u4e0b\u5bc6\u4e00\u70b9\u5c31\u53d8\u6210\u4e00\u56e2\u8f70\u9e23 */
const GUN_MIN_GAP = 0.04;

/* \u8fd9\u51e0\u58f0\u6bcf\u6b21\u64ad\u90fd\u7ed9 \u00b1% \u7684\u968f\u673a\u504f\u79fb\uff0c\u514d\u5f97\u50cf\u590d\u8bfb\u673a */
const AUDIO_PITCH = {
  'gun.pistol': 1, 'gun.uzi': 1, 'gun.shotgun': 1
};
const AUDIO_PITCH_AMT = 0.05;

/* 敌人枪声：不给每个小兵建自己的播放器，全场共用这几个槽位 */
const ENEMY_POOL_N = 4;
const ENEMY_MAX_PER_WIN = 2;      /* 同一瞬间最多 2 声，防爆音 */
const ENEMY_GUN_WIN = 0.09;       /* 窗口长度（秒） */
const MAX_CONCURRENT = 10;        /* cap simultaneous HTML Audio elements */
