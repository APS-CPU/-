/* ============================================================================
   车型总表 · 单一口径（车辆的一切数值都在这个文件里）
   ----------------------------------------------------------------------------
   以前车辆的数据是散的：基准款写在 data/enemies.js 的 ENEMY_TYPES.truck 里，
   另外三款在 data/vehicles.js 里"继承 + 覆盖"，改个血量要翻两个文件。
   现在反过来：**这张 VEHICLES 表是唯一来源**，data/enemies.js 里不再定义车辆。

      VEHICLES.truck        运兵车      基准款（4 个突击兵 · 车顶机枪）
      VEHICLES.truck_apc    装甲运兵车  慢、厚、只放 3 个人、机枪更重
      VEHICLES.truck_pickup 武装皮卡    轻、快、脆、只放 2 个人、机枪更急
      VEHICLES.truck_civil  民用皮卡    没机枪、不载兵，谁都能开走

   想改什么就直接改数字：
     · 血量            hp（护甲 armor 会再吃掉一部分，实打耐久 ≈ hp / (1-armor)）
     · 撞人            hitDmg / hitStun / hitKb / hitCd
     · 漂移进场        driftSpd / driftDur / driftMode / driftSway / driftSlip ...
     · 停车放人        deployCount / deployMix / deploySpread / deployGap
     · 开走与急刹      leaveDelay / leaveAccel / leaveMaxSpd / brakeSpd / brakeDur
     · 车顶机枪        mg { on, rof, dmg, range, spread, heat* }
     · 殉爆            boomR / boomDmg / boomKillCrew / boomWall
     · 打瘫            paralyzeDmg / paralyzeP
     · 外观            veh（'truck'|'apc'|'pickup'）/ bw / bh / wheelX / skin

   派生款只写"跟基准不一样"的字段，其余自动继承 truck —— 所以改 truck 的
   hp 会连带影响另外三款（除非那一款自己写了 hp）。想单独改就写在该款里。

   注意：game/ 下面的文件一律只读这张表，不许再出现车辆数值字面量。
   ============================================================================ */
var VEHICLE_DEFS = null;
function vehicleDef(kind){
  return (VEHICLE_DEFS && VEHICLE_DEFS[kind]) || null;
}

(function(){
  const VEHICLES = {
  truck: {
    label: '运兵车', kind: 'truck', behavior: 'normal',
    brief: '从外面漂移进来放四个人，然后开走；打爆它才变废铁。',
    r: 40, bodyHL: 46, bodyHW: 20, visionMul: 0, hearMul: 0, stepLoud: 0, fov: 0,
    canShoot: false, onCatch: 'damage',
    hp: 2650,
    armor: 0.40,              /* 车体：每次伤害先扣掉这么多比例。
                                 m44859：玩家仍嫌"太容易被打爆"，血 1500→2650（实打耐久 2500→4417）。
                                 m44463：玩家嫌"车太容易被打爆"，血 900→1500、护甲 0.35→0.40
                                 （实打耐久约 1385→2500，翻 1.8 倍）。护甲没敢再往上抬：
                                 0.62 那版太厚，手枪一发只进 17 点，血条一次挪 1px，
                                 看着就是「打了不掉血」。 */

    /* 进场漂移 */
    driftSpd: 480, driftDur: 2.20, driftSway: 46, driftSlip: 0.85,
    /* 漂移姿势（基准款）：中等横滑 + 一次明显甩尾，先猛后缓地压进来。
       三款车的差异就在这几个数上，改这里等于改"这辆车怎么进场"。 */
    driftMode: 'truck',     /* 基准款：横向来回摆 + 同向甩尾 */
    driftWave: 1.70, driftSlipWave: 1.90, driftEase: 2.30, driftPhase: 0.50,
    /* 86 = 这一款原来的滑动距离（旧的写死值）。改小会让停车点提前，
       下车点跟着挪、有两个人正好落进车尾死角（_tTruckAI 当场逮到）。 */
    brakeSlide: 86, brakeTilt: 0.10, slamShake: 0.55,
    brakeDur: 0.62,

    /* 停车放人 */
    deployCount: 4, deploySpread: 64, deployGap: 0.26, doorDur: 0.40, deployHold: 0.55,
    /* 从车上下来的是谁：按顺序取，不够就从头再来。
       现在是四个职业兵（穿三级甲、会扔烟、贴墙一枪就缩）。嫌凶就改成
       ['spec','spec','grunt','grunt']，想退回纯步枪兵就全写 'grunt'。 */
    deployMix: ['specFlank', 'specFlank', 'specFlank', 'specFlank'],
    /* 下车之后的巡逻线：从车斗往玩家方向推进几个点。
       给 1 个点他们走到那儿就杵着不动（就是这个 bug 的成因），
       所以默认铺 3 个点，最后一个落在"车程 deployAdvance"处。 */
    deployWp: 3,
    deployAdvance: 0.62,
    deployJitter: 0.42,

    /* 开走：leaveChance 目前不生效（卸完兵一律开走），leaveDelay 是净停顿时长 */
    leaveChance: 0.55, leaveDelay: 2.40, leaveAccel: 900, leaveMaxSpd: 1150,
    /* 急刹阶段的速度（以前代码里写死 260，三款车一样，现在按车型给） */
    brakeSpd: 260,
    /* 玩家亲自驾驶时的操控手感（m0：以前四款车共用一个全局 TRUCK_DRIVE，
       开起来一模一样；现在每款车在这里给一套，mk() 会把没写的字段从基准款继承）。
       accel 起步加速度、maxFwd/maxRev 前进与倒车极速、drag 松油门滑行衰减、
       turn 转向角速度、brake 刹车减速度、revAccel 倒车加速度。 */
    drive: { accel: 248, maxFwd: 430, maxRev: 222, drag: 2.05, turn: 1.70, brake: 880, revAccel: 200 },

    /* 撞人：漂移进场 / 急刹 / 开走这三段都有碰撞体积（停稳以后靠 solid 挡路，不撞人）。
       hitDmg 是基准伤害，实际按当时车速在 0.55~1.35 倍之间浮动。 */
    hitDmg: 62, hitStun: 0.75, hitKb: 2400, hitCd: 0.9,

    /* 瘫痪：单次伤害（未减甲的原值）超过 paralyzeDmg 就有 paralyzeP 的概率瘫在原地。
       瘫了之后不动、不卸兵、不开走，车身上一直冒火花和烟；还能继续打，打空血才算废铁。
       门槛 130 = 只有火箭弹够得着（贴脸 150×8 倍倍率、减甲后 780，900 血的车剩 120，
       正好"打不爆但打得瘫"）；手枪 46、冲锋枪 24、霰弹每颗 14 都够不着，
       连手枪暴击（46×2=92）也压不到线上 —— 之前门槛是 90，手枪一暴击就 92，
       于是"打几枪车就瘫了"，这里是被暴击撬开的门缝，留档别再降回去。
       近战砍车另有 ×0.55 的折扣（弯刀 108 → 实进 36~59），所以刀也砍不瘫车。 */
    paralyzeDmg: 130, paralyzeP: 0.45, sparkGap: 0.07, smokeGap: 0.16,

    /* 顶置机枪：平时纯装饰。只在「正在卸兵」或「刚被玩家打过 mg.rage 秒」时转过来扫射。
       伤害故意压低（3），压迫感靠射速（0.055s 一发 ≈ 18 发/秒）和散布的密度。
       想关掉就 mg.on:false；想调强度只动 rof / range / dmg 这三个。 */
    mg: {
      on: true,
      range: 460,        /* 索敌半径（px）：超出就不转也不打 */
      rof: 0.090,        /* m45062：0.055→0.090（≈11 发/秒，慢 1.6 倍） */
      dmg: 7.5,          /* m45062：3→7.5（大幅上调；玩家护甲照常吃） */
      spd: 980,          /* 弹速 */
      spread: 0.085,     /* 散布（弧度，±） */
      turnSpd: 7.5,      /* 炮塔转速（弧度/秒） */
      aimTol: 0.22,      /* 对准到这个误差以内才扣扳机 */
      /* ——— 过载（heat）：枪管不是无限连发的 ———
         连打会持续涨，涨满就锁死，必须等它凉下来才能再打；
         停火之后也不是立刻降，先静一会儿，再慢慢掉。 */
      heatMax: 1.0,          /* 过载上限：到 1 就锁死 */
      heatPerShot: 0.0075,   /* m45062：0.0067→0.0075（≈133 发打满；射速慢了，按连打十几秒算） */
      heatCoolDelay: 0.55,   /* 停火多久之后才开始降（秒） */
      heatCool: 0.30,        /* 平时降温速度（每秒） */
      heatLockCool: 0.15,    /* 过载锁死期间的降温速度（每秒）——慢，所以要"很长一段时间" */
      heatReset: 0.05,       /* 降到这个值以下才算解除过载 */
      noMag: true,           /* 无限弹链：没有弹匣也没有装填，唯一限制就是过载 */
      rage: 4.5,         /* 挨打之后继续扫多久（秒） */
      burst: 0.90,       /* m45062：0.55→0.90（慢射速下一梭更长） */
      pause: 0.6,        /* 两梭之间停多久 */
      life: 0.55,        /* 子弹存活（秒）—— 射程与"看不清弹道"的副产品 */
      /* ——— 下面四项只在你亲自上车接管时用，AI 开火完全不读 ——— */
      mag: 150,          /* 一条弹链多少发，打空自动装填 */
      reloadDur: 2.6,    /* 装填时长（秒） */
      pmTurn: 13,        /* 玩家手操时的转塔速度（比 AI 快，手瞄要跟得上鼠标） */
      pmSpread: 0.05     /* 玩家手操时的散布：比 AI 的 0.085 略准，但不至于指哪打哪 */
    },

    /* 殉爆：车血空时炸一次，车里的人跟车一起没
       boomR  = 爆炸半径（像素），圈内敌人一律炸死，圈边上的你按比例吃伤害
       boomDmg= 车外人吃到的最大伤害（圈心 260，边缘打到 35%）
       boomKillCrew: false 可以退回老行为（先卸兵、再把你甩出去） */
    boomR: 210,
    boomDmg: 260,
    boomKillCrew: true, boomWall: true,
    wreckSmoke: 1,
    drops: [{ kind: 'ammo', p: 0.90 }, { kind: 'med', p: 0.55, rarity: 'big' }],
    spawn: 'event'
  },
  };

  const B = VEHICLES.truck;

  /* 浅合并：只有第二层（mg / skin）需要合，其它都是标量 */
  const mk = (o) => {
    const out = Object.assign({}, B, o);
    out.kind = 'truck';
    out.mg = Object.assign({}, B.mg || {}, o.mg || {});
    /* 驾驶手感也是二级合并：派生款只写和运兵车不一样的那几项 */
    out.drive = Object.assign({}, B.drive || {}, o.drive || {});
    out.skin = Object.assign({
      body: '#4a535f', plate: '#5d6874', edge: '#8b98a6', roof: '#3c444e',
      wreckBody: '#3a3f46', wreckPlate: '#474c53', wreckEdge: '#22262b'
    }, B.skin || {}, o.skin || {});
    return out;
  };

  VEHICLES.truck_apc = mk({
    label: '装甲运兵车', veh: 'apc',
    brief: '比运兵车慢，但壳厚得多；只放三个职业兵，车顶一挺重机枪。',
    /* 外观：宽一点、长一点，四排轮子 */
    bw: 58, bh: 30, wheelX: [-34, -12, 12, 34],
    skin: {
      body: '#3b4249', plate: '#4d555e', edge: '#727f8c', roof: '#333a41',
      wreckBody: '#2e3339', wreckPlate: '#383d43', wreckEdge: '#1d2125'
    },
    /* 数值：厚、慢、撞人疼 */
    hp: 3600, armor: 0.56,   /* m44463：1600/0.52 → 2200/0.56；m44859：再 → 3600/0.56（实打耐久 5000→8182） */
    driftSpd: 380, driftDur: 2.60, brakeDur: 0.80, leaveDelay: 2.80,
    /* 漂移姿势（m42690）：原来用 'arc' 单方向斜插、不回摆，用户觉得"没有运兵车
       那种漂移味、停的时候还像卡了一下"。arc 的滑移在 p>0.70 处有阶跃（已在
       game/18-truck.js 改成平滑 ramp），这里再把款式换成基准甩尾，
       幅度比运兵车小一档 —— 重车该甩，但别甩得像皮卡。 */
    driftMode: 'truck',
    driftSway: 64, driftSlip: 0.62, driftEase: 2.40,
    brakeSlide: 10, brakeTilt: 0.045, slamShake: 1.05,
    /* 开走/急刹这两段的速度以前是写死的，三款车一模一样 —— 现在按车型给 */
    brakeSpd: 190, leaveAccel: 560, leaveMaxSpd: 820,
    /* 重车：起步慢、极速低、转向笨，但刹车沉得住 */
    drive: { accel: 226, maxFwd: 470, maxRev: 200, drag: 2.15, turn: 1.28, brake: 770, revAccel: 168 },
    deployCount: 3, deployMix: ['spec', 'spec', 'spec'],
    hitDmg: 96, hitStun: 0.95, paralyzeDmg: 210,
    /* m42690：装甲运兵车也装车顶机枪（比运兵车那挺重一档：慢一点、打得疼一点、
       射程远一点、热容量大一点）。truckMgDef 只有在 mg.on === false 时才隐藏，
       所以这里给对象就等于"装了"。 */
    mg: { rof: 0.090, dmg: 6.5, range: 460, spread: 0.10,   /* m45062：0.056/2.4 → 0.090/6.5 */
          heatPerShot: 0.010, heatCool: 0.40, heatLockCool: 0.22 }
  });

  VEHICLES.truck_pickup = mk({
    label: '武装皮卡', veh: 'pickup',
    brief: '薄皮快车：只放两个人，车顶机枪打得比运兵车更急。',
    /* 外观：小一号，四轮，敞篷车斗 */
    bw: 44, bh: 22, wheelX: [-26, 22],
    skin: {
      body: '#5c5547', plate: '#6d6555', edge: '#948b78', roof: '#4a4438',
      wreckBody: '#433d33', wreckPlate: '#4f4839', wreckEdge: '#26221b'
    },
    /* 数值：脆、快、但机枪更烦人 */
    hp: 1900, armor: 0.22,    /* m44463：420/0.15 → 780/0.22；m44859：再 → 1900/0.22（实打耐久 1000→2436，火箭要 3 发） */
    driftSpd: 560, driftDur: 1.80, brakeDur: 0.50, leaveDelay: 1.60,
    /* 漂移姿势：轻车拉手刹过弯 —— 横向摆两下，而且车头**反打**
       （车头朝弯外、车身往弯里滑），刹车后还会往前溜一小段。 */
    driftMode: 'slide',
    driftSway: 74, driftSlip: 0.72, driftWave: 1.85, driftSlipWave: 1.85,
    driftEase: 1.70, driftPhase: 0.35,
    brakeSlide: 52, brakeTilt: 0.16, slamShake: 0.30,
    brakeSpd: 330, leaveAccel: 1150, leaveMaxSpd: 1500,
    /* 轻车：起步窜、极速高、转向贼，但滑行衰减小（松油门能溜很远） */
    drive: { accel: 336, maxFwd: 545, maxRev: 272, drag: 1.70, turn: 2.05, brake: 960, revAccel: 250 },
    deployCount: 2, deployMix: ['grunt', 'grunt'],
    hitDmg: 44, paralyzeDmg: 140,   /* m20234：手枪暴击 92 也不该把武装皮卡打瘫 */
    /* rof 是"每隔几秒一发"，所以**更小**才是更快 */
    /* 过载也跟运兵车不一样：枪管更细 → 打到约 105 发就红，但凉得快 */
    mg: { rof: 0.085, dmg: 6, range: 420, spread: 0.11,   /* m45062：0.048/2 → 0.085/6 */
          heatPerShot: 0.011, heatCool: 0.42, heatLockCool: 0.24 }
  });

  /* 民用皮卡：绿色涂装、**车顶没有机枪**、不拉兵，谁都能开走。
     现实里那种"皮实耐用的工具车"——壳比武装皮卡还薄，但能开、能撞、能当掩体。 */
  VEHICLES.truck_civil = mk({
    label: '民用皮卡', veh: 'pickup',
    brief: '绿色民用皮卡：没有车顶机枪、不载兵，停在那儿就能开走。',
    bw: 46, bh: 16, wheelX: [-28, 26],
    skin: {
      body: '#2f4530', plate: '#39533a', edge: '#5a7457', roof: '#283a29',
      wreckBody: '#24311f', wreckPlate: '#2b3a28', wreckEdge: '#161f14'
    },
    hp: 880, armor: 0.14,    /* m44463：300/0.08 → 560/0.14；m44859：再 → 880/0.14（实打耐久 651→1023） */
    driftSpd: 470, driftDur: 1.60, brakeDur: 0.45, leaveDelay: 1.40,
    /* 漂移姿势：民用款就是"老实停车" —— 几乎没有横移，也不甩尾 */
    driftMode: 'plain',
    driftSway: 12, driftSlip: 0.16, driftEase: 2.40,
    brakeSlide: 16, brakeTilt: 0.06, slamShake: 0.35,
    brakeSpd: 300, leaveAccel: 900, leaveMaxSpd: 1250,
    /* 民用皮卡：比运兵车轻快一点、比武装皮卡收敛一点，转向偏软（工具车） */
    drive: { accel: 300, maxFwd: 500, maxRev: 248, drag: 1.82, turn: 1.88, brake: 845, revAccel: 225 },
    deployCount: 0, deployMix: [],
    hitDmg: 34, hitStun: 0.55, paralyzeDmg: 170,   /* m20234：手枪暴击只有 92，民用皮卡不该被打瘫 */
    mg: { on: false }        /* 民用款：没有任何车载武器 */
  });

  VEHICLE_DEFS = VEHICLES;
  /* 把表交给 ENEMY_TYPES：旧消费者继续工作；新消费者逐个迁移到 vehicleDef。 */
  /* game/ 里所有 ENEMY_TYPES[kind] / isTruck() 的调用点
     都照旧工作，只是数据来源换成了这里的 VEHICLES。 */
  for (const _k in VEHICLES) ENEMY_TYPES[_k] = VEHICLES[_k];
  /* 控制台/测试用：window.VEHICLES 能看到全部车型 */
  if (typeof window !== 'undefined') window.VEHICLES = VEHICLES;

})();
