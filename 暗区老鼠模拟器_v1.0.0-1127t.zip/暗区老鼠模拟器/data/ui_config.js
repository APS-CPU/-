/* ============================================================================
 * data/ui_config.js — 界面样式表（纯数据，不含任何游戏逻辑）
 * ----------------------------------------------------------------------------
 * 目标：所有"长什么样"的东西都住在这里。UI 绘制函数只允许从这里取值，
 *       不允许再写死 rgba(...)、字号、"背包" 这种字面量。
 *
 * 结构：
 *   UI_CFG.palette.dark / .light   两套主题色（键名一一对应）
 *   UI_CFG.metric                  尺寸、圆角、线宽、间距
 *   UI_CFG.font                    字号/字重（配 style() 拼成 ctx.font）
 *   UI_CFG.text                    所有会出现在界面上的文案（含模板片段）
 *   UI_CFG.hint                    各界面底部的操作提示
 *
 * 新增界面时：在这里补一节 palette/metric/text，然后写一个渲染函数，
 * 把它的开合状态挂到主文件的 UI_STATE 上即可，不要碰游戏逻辑。
 * ========================================================================== */
(function () {
  var FAMILY = '"Microsoft YaHei",sans-serif';

  var UI_CFG = {
    v: 1,

    /* ---------------------------------------------------------------- 颜色 */
    palette: {
      dark: {
        ink:        'rgba(238,226,210,0.95)',
        dim:        'rgba(186,160,132,0.92)',
        panel:      'rgba(38,26,18,0.97)',
        panelTop:   'rgba(46,33,23,0.99)',
        panelBot:   'rgba(34,24,17,0.99)',
        panelEdge:  'rgba(150,112,72,0.55)',
        line:       'rgba(196,152,104,0.28)',
        stitch:     'rgba(232,196,142,0.32)',
        slotBg:     'rgba(24,17,12,0.55)',
        slotIcon:   'rgba(12,9,6,0.45)',
        cell:       'rgba(120,86,54,0.26)',
        pocket:     'rgba(96,68,42,0.34)',
        cellEdge:   'rgba(173,133,88,0.22)',
        card:       'rgba(70,49,33,0.95)',
        cardHot:    'rgba(38,58,78,0.95)',
        infoBg:     'rgba(18,25,32,0.85)',
        hot:        'rgba(150,205,235,0.95)',
        hotBg:      'rgba(46,74,102,0.9)',
        bagHot:     'rgba(52,76,46,0.92)',
        bagHotLine: 'rgba(190,222,150,0.95)',
        heatHot:    'rgba(104,64,26,0.92)',
        heatOn:     'rgba(84,52,24,0.5)',
        heatLine:   'rgba(226,158,84,0.75)',
        thermal:    'rgba(255,186,110,0.98)',
        gunIcon:    '#aab6c4',
        gunIconEdge:'rgba(0,0,0,0.5)',
        barTrack:   'rgba(10,16,22,0.6)',
        barBad:     'rgba(236,140,110,0.95)',
        num:        'rgba(240,246,252,0.98)',
        numStroke:  'rgba(6,10,14,0.85)',
        armorBarBg: 'rgba(8,13,19,0.78)',
        armorBarTx: 'rgba(244,250,255,0.98)',
        emptySlot:  'rgba(255,255,255,0.055)',
        dimmed:     'rgba(8,6,4,0.55)',
        brass:      'rgba(226,178,74,0.85)',
        brassLine:  'rgba(226,178,74,0.55)',
        okFill:     'rgba(120,200,140,0.22)',
        okLine:     'rgba(140,220,160,0.9)',
        softFill:   'rgba(232,190,96,0.22)',
        softLine:   'rgba(244,206,110,0.95)',
        badFill:    'rgba(226,96,74,0.22)',
        badLine:    'rgba(240,120,96,0.9)'
      },
      light: {
        ink:        'rgba(38,26,18,0.95)',
        dim:        'rgba(96,74,52,0.9)',
        panel:      'rgba(246,236,222,0.98)',
        panelTop:   'rgba(246,232,212,0.99)',
        panelBot:   'rgba(232,214,190,0.99)',
        panelEdge:  'rgba(120,90,58,0.75)',
        line:       'rgba(126,96,64,0.55)',
        stitch:     'rgba(232,196,142,0.32)',
        slotBg:     'rgba(226,206,178,0.7)',
        slotIcon:   'rgba(12,9,6,0.45)',
        cell:       'rgba(214,186,150,0.5)',
        pocket:     'rgba(198,168,130,0.55)',
        cellEdge:   'rgba(150,118,84,0.34)',
        card:       'rgba(228,206,176,0.9)',
        cardHot:    'rgba(206,222,236,0.95)',
        infoBg:     'rgba(238,235,228,0.8)',
        hot:        'rgba(150,205,235,0.95)',
        hotBg:      'rgba(190,214,236,0.85)',
        bagHot:     'rgba(206,226,190,0.9)',
        bagHotLine: 'rgba(190,222,150,0.95)',
        heatHot:    'rgba(252,226,180,0.92)',
        heatOn:     'rgba(236,214,182,0.72)',
        heatLine:   'rgba(226,158,84,0.75)',
        thermal:    'rgba(255,186,110,0.98)',
        gunIcon:    '#aab6c4',
        gunIconEdge:'rgba(0,0,0,0.5)',
        barTrack:   'rgba(10,16,22,0.6)',
        barBad:     'rgba(236,140,110,0.95)',
        num:        'rgba(26,36,46,0.95)',
        numStroke:  'rgba(6,10,14,0.85)',
        armorBarBg: 'rgba(8,13,19,0.78)',
        armorBarTx: 'rgba(244,250,255,0.98)',
        emptySlot:  'rgba(214,210,200,0.6)',
        dimmed:     'rgba(8,6,4,0.55)',
        brass:      'rgba(180,132,40,0.9)',
        brassLine:  'rgba(180,132,40,0.55)',
        okFill:     'rgba(120,200,140,0.22)',
        okLine:     'rgba(140,220,160,0.9)',
        softFill:   'rgba(232,190,96,0.22)',
        softLine:   'rgba(244,206,110,0.95)',
        badFill:    'rgba(226,96,74,0.22)',
        badLine:    'rgba(240,120,96,0.9)'
      }
    },

    /* ---------------------------------------------------------------- 尺寸 */
    metric: {
      panelPad: 22,
      slotW: 214,           /* 左列装备栏宽度 */
      infoW: 220,           /* 右侧说明栏宽度 */
      gap: 4,
      cellBig: 56,
      cellSmall: 40,
      minCell: 24,
      slotNeed: 726,        /* 左列至少需要的高度（含四行武器栏） */
      headerH: 58,
      panelRadius: 12,
      slotRadius: 8,
      cardRadius: 5,
      cellRadius: 4,
      barH: 8,
      barR: 4,
      iconW: 74,
      padX: 12,
      armorH: 96,
      bagH: 84,
      shieldH: 80,
      heatH: 82,
      weaponH: 44,
      slotGap: 6,
      lineW: { panel: 1.8, stitch: 1.2, slot: 1.2, hot: 2, card: 1, cardHot: 1.8, cell: 1 },
      dash: { stitch: [5, 4], pocket: [6, 5] }
    },

    /* ---------------------------------------------------------------- 字号 */
    font: {
      family: FAMILY,
      size: {
        title: 18, sub: 12, cap: 13,
        slotLabel: 10, slotName: 15, slotStat: 14, slotLine: 11, tiny: 10,
        itemNum: 11, armorBar: 11,
        infoTitle: 15, infoTag: 12, infoLine: 12, infoEmpty: 12.5,
        hint: 11.5, footer: 12, empty: 11, weapon: 13
      },
      weight: {
        title: 'bold', cap: 'bold', slotName: 'bold', slotStat: 'bold',
        itemNum: 'bold', armorBar: 'bold', infoTitle: 'bold', weapon: 'bold'
      }
    },

    /* ---------------------------------------------------------------- 文案 */
    text: {
      bagTitle: '背包',
      armor: '防弹衣', armorDrop: '松手穿上', armorEmpty: '没穿', armorEmptyMark: '—',
      armorReduce: '减伤 ',
      bag: '背包', bagDrop: '松手换上', bagEmpty: '空', bagEmptyMark: '—',
      bagCarry: '随身 ',
      shield: '防弹盾牌', shieldOn: '盾牌', shieldDrop: '松手丢掉',
      shieldEmpty: '没拿', shieldUp: '举着', shieldDown: '收着',
      heat: '热成像', heatDrop: '松手戴上', heatEmpty: '没戴', heatHint: '拖进来戴上',
      heatOn: '使用中', heatCd: '冷却中', heatWorn: '已戴上', heatBattery: '电量 ',
      heatSwapping: '正在换电池', heatRemaining: '还剩 ',
      weapon: '主武器', fist: '空手',
      weaponBar: '武器栏', gun1: '主武器 1', gun2: '主武器 2', gun3: '副武器', gun4: '近战',
    gunEmpty: '空', gunUsing: '正在用', gunDragHint: '拖动可换位',
      gunMainTip: '长枪 / 火箭筒', gunSideTip: '手枪 / 信号枪', gunMeleeTip: '刀',
      cells: ' 格', onlyPocket: ' · 只有口袋 ', pocketLabel: '口袋 ', pocketPlus: ' + 口袋 ',
      shapeUnlimited: '（不设上限）',
      hintLine1: '拖到面板外 = 丢地上',
      hintLine2: '拖护甲/背包/盾牌/热成像出去 = 丢地上',
      hintLine3: '点药格子 = 直接用',
      infoEmpty: ['鼠标停到格子上', '看这件东西的说明', '按住拖动可以挪位置', '拖到面板外就丢掉']
    },

    /* ------------------------------------------------------------ 底部提示 */
    hint: {
      bag: ' 关闭 · 拖动换位置 · R 旋转 · 拖到面板外丢地上 · 拖到护甲框换甲'
    },

    /* -------------------------------------------------- 小工具（排版用） */
    style: function (size, weight) {
      return (weight ? weight + ' ' : '') + size + 'px ' + FAMILY;
    },

    /* 一次性把"字号表 + 字重表"拼成可直接赋给 ctx.font 的字符串表 */
    fonts: function () {
      var out = {}, sz = this.font.size, wt = this.font.weight;
      for (var k in sz) out[k] = this.style(sz[k], wt[k]);
      return out;
    }
  };

  window.UI_CFG = UI_CFG;
})();

/* 割草模式存档选择页的固定文案和颜色。布局随 Canvas 尺寸计算。 */
const DataARENA_SLOT_UI = Object.freeze({
  layout: Object.freeze({
    save: Object.freeze({ right: 18, top: 14, width: 140, height: 38 }),
    card: Object.freeze({ width: 310, height: 300, gap: 24, top: 222, radius: 14, inset: 24 }),
    cardAction: Object.freeze({ top: 237, height: 42, loadWidth: 130, deleteX: 166, deleteWidth: 120 }),
    confirm: Object.freeze({ width: 500, height: 248, radius: 14, actionTop: 166, actionWidth: 195, actionHeight: 46, actionGap: 30 }),
    back: Object.freeze({ top: 614, width: 220, height: 46 }),
  }),
  text: Object.freeze({
    waveLead: '第 ',
    waveTail: ' 波',
    difficultyLead: '难度：',
    scoreLead: '分数：',
    savedAtLead: '存档时间：',
    load: '读取',
    delete: '删除',
    overwrite: '覆盖',
    slotLead: '存档位 ',
    question: '？',
    loadDetail: '从保存时的战斗进度继续。',
    deleteDetail: '删除后无法恢复，空位可以开始新局。',
    overwriteDetail: '当前战斗进度将替换这个位子原来的存档。',
    entryTitle: '战斗，爽！！ · 选择存档',
    manualTitle: '手动保存 · 选择存档位',
    entryDetail: '空位开始新一局 · 已有存档可读取 · 难度在开局前选择',
    manualDetail: '选择要保存的位置；已有存档可以覆盖',
    emptyEntry: '可开始一局新的战斗',
    emptyManual: '可保存当前完整进度',
    newRun: '开始新一局',
    saveHere: '保存到此位',
    manualSave: '手动保存',
    back: '返回',
    cancel: '取消',
    fullTail: ' 个存档位已满。要开新局，请先删除一个存档。',
    autosaveLead: '每 ',
    autosaveTail: ' 波自动保存仍使用本局开局时选择的存档位。',
    emptySlot: '空存档位',
  }),
  palette: Object.freeze({
    entry: '#0b1119',
    manual: 'rgba(4,8,13,0.94)',
    title: '#ffd9a0',
    intro: 'rgba(215,230,244,0.76)',
    cardHot: '#1a2b3b',
    card: '#111d29',
    edgeHot: '#8ef0c8',
    edge: '#40566a',
    slotTitle: '#dceaf6',
    wave: '#ffdda2',
    meta: '#c2d6e8',
    time: '#9fb5c8',
    emptyTitle: '#9eb2c4',
    emptyDetail: '#8297a9',
    footer: '#becddd',
    error: '#ffb19e',
    confirmationShade: 'rgba(0,0,0,0.76)',
    confirmation: '#142131',
    confirmationEdge: '#5e7a96',
    confirmationTitle: '#ffe0af',
    confirmationDetail: '#c4d5e6',
  })
});
