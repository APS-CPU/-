/* ============================================================================
   阵营关系与动态仇恨
   ----------------------------------------------------------------------------
   这里只保存“关系是什么”和“仇恨保存多久”。命中、听觉、索敌分别通过
   game/52-factions.js 的窄接口接入，新增势力时不用去枪、刀、手雷里散写判断。
   ============================================================================ */
var FACTION_DEF = {
  player:  { label: '玩家',   hostiles: ['enemy'] },
  enemy:   { label: 'A 势力', hostiles: ['player', 'bandit'] },
  bandit:  { label: 'B 势力', hostiles: ['enemy'] },
  neutral: { label: '中立',   hostiles: [] }
};

/* 玩家攻击中立势力后的数值规则。一次真实落血就能越过 threshold；重复攻击会
   继续增加 value 并刷新时间。shareR 是受击者通知同伴的范围，joinR 是玩家带着
   仇恨走近尚未知情成员时，对方允许加入战斗的范围。 */
var FACTION_HATE_DEF = {
  hitGain: 12,
  damageK: 0.45,
  threshold: 1,
  max: 100,
  duration: 40,
  shareR: 680,
  joinR: 560
};
