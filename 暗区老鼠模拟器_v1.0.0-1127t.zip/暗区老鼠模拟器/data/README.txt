暗区老鼠模拟器 · 数据文件总表
================================

这个目录只放"配置 / 数据"，不放逻辑。
改完保存 → 回游戏按 F5 刷新就生效（改了 .js 记得连版本戳一起刷，见文末）。

规矩（别破坏）
  · data 目录必须和 暗区老鼠模拟器.html 同目录。
  · 这里全是普通 <script>（不是 ESM），文件名 = 加载顺序的一部分，
    在 html 里靠前 = 先加载；**新加文件要同时改 html**。
  · 一个数值只允许有一处出处。别在 game/ 里再写一份同样的数字。

------------------------------------------------------------------
一、你会经常改的（按"想改什么"找）
------------------------------------------------------------------

  改血量 / 护甲 / 撞人伤害 / 漂移 / 放人 / 机枪 / 殉爆  →  vehicles.js（VEHICLES）
        truck           基准运兵车（其它三款"继承 + 覆盖"，只写差异）
        truck_apc       装甲运兵车
        truck_pickup    皮卡
        truck_civil     民用皮卡（没机枪）
      ★ 这张表是车辆数值的唯一来源，data/enemies.js 里已不再定义任何车辆。

  改武器伤害 / 射速 / 弹匣 / 后坐力 / 弹药口径      →  items.js（WEAPONS / AMMO）
  改药品效果（回血量、持续时间、稀有度）            →  items.js（MED_DEF）
  改敌人类型（视野、听觉、护甲、命中率）            →  enemies.js（ENEMY_TYPES）
  改抽奖商人：奖品清单、标价、限量                →  gacha.js（GACHA_PRIZES / GACHA_VAL）
  改物品名字、加新物资种类                       →  lootkinds.js（LOOT_KIND_DEF）
  改关卡（尺寸、房间、物资数量、难度规则）        →  levels.js（LEVELS）
  改人机"真人感"（反应时间、听觉误差、压制）      →  ai.js（DataHUMAN / DataHIDE / DataENGAGE）
  改 BOSS 招式与血量                              →  bosses.js（ABILITY_DEF / BOSS_KIT / BOSS_SCALE）
  改输入按键                                      →  bindings.js
  改界面配色/字号                                 →  ui_config.js

------------------------------------------------------------------
二、全部文件（32 个）
------------------------------------------------------------------

  ── 数值表 ──────────────────────────────────────────
  items.js            武器、弹药、药品（WEAPONS / AMMO / AMMO_ORDER / MED_DEF / AMMO_BOX）
  enemies.js          敌人类型（ENEMY_TYPES）—— 注意：已不含车辆
  vehicles.js         车辆总表（VEHICLES = truck / truck_apc / truck_pickup / truck_civil）
  gacha.js            抽奖商人：奖品表 + 押注估值（GACHA_VAL / GACHA_PRIZES）
  lootkinds.js        物资种类：名字 / 分类 / 一句话说明（LOOT_KIND_DEF）—— 名字的唯一出处
  bosses.js           BOSS 招式与数值（ABILITY_DEF / BOSS_KIT / BOSS_SCALE）
  ai.js               人机行为参数（DataHUMAN / DataHIDE / DataENGAGE）
  weapon_core.js      武器"基础物理参数"的唯一出处（WEAPON_CORE_DEF）
  attachments.js      枪械配件（ATTACH_SLOTS / ATTACH_SLOT_NAME / ATTACH_DEF）
  status.js           敌人状态数据流（ESTATUS_DEF / E_CD_DEF）
  factions.js         阵营与仇恨（FACTION_DEF / FACTION_HATE_DEF / GRUDGE_T*）
  bindings.js         输入绑定总表（F8 审计面板读它）
  ui_config.js        UI 配置（data/ui_* 段）

  ── 关卡与场景 ──────────────────────────────────────
  levels.js           全部关卡（LEVELS）
  roomTemplates.js    房间模板（CRATE_CAP / ROOM_TEMPLATES / ROOM_TEMPLATE_IDS）
  lootcrate.js        战利品箱（LOOT_CRATE / LOOT_SKIN）
  covers.js           掩体定义（COVER_DEF / DOOR_SKIN / CAR_SKIN）
  coverLayout.js      掩体的摆放：每关一组"类型 + 坐标"（COVER_LAYOUT）
  decor.js            装饰物，纯布景、不进碰撞（DECOR_DEF / FLOWER_BEDS / DECOR_SKIN）
  debris.js           破碎残留物，纯视觉（DEBRIS_DEF）
  roofs.js            屋顶清单 + 配色（ROOF_DEF / ROOF_FADE / ROOF_VISIBLE）
  wire.js             铁丝网（WIRE_DEF / WIRE_SKIN）

  ── 队友 ───────────────────────────────────────────
  companions.js       队友共享视野射线数（DataCOMPANION_VISION_RAYS）；运行逻辑见 game/41-companions.js
  companion_inventory.js  队友物资（有限、实例化、随 actor 一起存档）

  ── 文案与音频（基本都是 base64 内联，file:// 下只能这么带）──
  voice.js            敌人台词库（VOICE / VOICE_RED）
  death_msgs.js       玩家死法文案（DEATH_MSG / DEATH_KILLER_FALLBACK）
  audio.js            音效路径表（AUDIO_FILE）
  media.js            通用嵌入式音频
  rain.js             雨声 + 雷声
  blade.js            近战挥刀 / 砍中
  rocket_sfx.js       火箭筒
  nade_boom.js        手雷爆炸
  tinnitus.js         耳鸣

------------------------------------------------------------------
三、常见改法
------------------------------------------------------------------

加一把新枪
  1. items.js 的 WEAPONS 里加一条（照 pistol 抄，改 dmg / cap / rof / ...）
  2. 同文件 AMMO 里加对应口径，并把 id 写进 AMMO_ORDER
  3. 最后把 id 写进 items.js 里的 WEAPON_ORDER（按 Q 轮换的顺序，现在已经和 WEAPONS 放在同一个文件里）。

改一辆车的血量
  只改 vehicles.js 里 VEHICLES.truck.hp。
  想只改某一种车（比如只改装甲车），就在 VEHICLES.truck_apc 里写 hp: N ——
  派生款"自己写了就用自己的，没写就继承基准"。

加一个新奖品（抽奖商人）
  1. gacha.js 的 GACHA_PRIZES 里加一条 { id, label, desc, value, give, stock? }
  2. id 不能和现有的重复（有测试盯着）
  3. stock 是限量；不写 = 不限量
  4. 千万不要在 game/61-gacha.js 里再写数据 —— 那里只剩"怎么算/怎么发"的逻辑

改地图上的箱子 / 掩体 / 布景
  · 箱子里装什么     → lootcrate.js
  · 掩体长什么样     → covers.js；摆在哪个关卡 → coverLayout.js
  · 纯装饰、不挡路   → decor.js（不进 L.walls）
  · 打碎后的残留物   → debris.js（纯视觉）

------------------------------------------------------------------
四、容易被误改的地方
------------------------------------------------------------------

  · data 里的表大多是"浅合并"用的基准对象：改基准会连带影响只写差异的派生项。
  · 有些数组是共享引用（比如 deployMix），要改内容请整个替换，不要 push。
  · 加新文件必须回 暗区老鼠模拟器.html 里加 <script src="data/xxx.js">，
    位置决定加载顺序；排在用它的逻辑文件之前。
  · 改完 .js 后如果游戏没变化，多半是浏览器缓存 —— 用 _work/_stampver.cjs 刷新版本戳，
    或者 Ctrl+F5。

------------------------------------------------------------------
五、想找"某个数字在哪"的快捷方式
------------------------------------------------------------------

  · 车辆：data/vehicles.js
  · 抽奖：data/gacha.js
  · 物品名字：data/lootkinds.js
  · 枪 / 子弹 / 药：data/items.js
  · 敌人：data/enemies.js
  · 火箭炮塔：data/enemies.js 的 ROCKET_TURRET_DEF，测试区和死亡地带共用
  · 关卡布局：data/levels.js + data/roomTemplates.js + data/coverLayout.js
  · 割草存档页：data/ui_config.js 的 DataARENA_SLOT_UI，展示见 game/47-arena-slots-ui.js
  · 音效路径与并发额度：data/audio.js，播放池见 game/05-audio.js
  · 其余逻辑（怎么算、怎么画、怎么跑）在 game/*.js，不在这个目录。
