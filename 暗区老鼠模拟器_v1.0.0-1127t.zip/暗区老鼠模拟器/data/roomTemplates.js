/* ============================================================
   房间模板（第 52 轮）：把"四面墙 + 门洞 + 隔断 + 屋顶 + 房间
   + 家具 + 战利品箱"这一整套打包成一个名字，地图里只写一行。

   用法（写在关卡的 placed 里）：
     placed:[
       {t:'small_house', x:400, y:300},              朝南开门
       {t:'small_house', x:1200, y:300, rot:90},     转 90°，门朝西
     ]

   约定（第 53 轮补充）：
   1) 所有坐标都是"以房间左上角为原点"的局部坐标，摆到地图上才加 x/y 并按 rot 旋转。
   2) 生成的东西全都进关卡原有的同名数组（walls / doors / roofs / rooms / decors），
      所以屋顶淡出、房间压暗、门开关、寻路、拆墙分段一行都不用改。
   3) 老地图没有 placed → 什么都不加。
   4) **门洞必须够宽**：寻路给每堵墙四周留 13px，门洞净宽小于 26px 的人机就走不过去。
      所以外墙门 width ≥ 60、隔断门 ≥ 52，而且**隔断不要顶在开门那一面的墙上**
      （否则隔断的 13px 会把门口整条通道封死）——模板里统一留门厅。
   5) rooms 里带 locked:true 的，通向它的那扇隔断门会变成锁门：玩家要用钥匙，
      人机不会进（寻路把锁着的门当墙），里面的箱子多。
   ============================================================ */

/* ---------- 小工具：隔断 ----------
   _rpart(axis, pos, t, a1, a2, g1, g2, opt)：一道隔断，沿 axis 方向铺在 pos 上，
   a1..g1、g2..a2 是墙，g1..g2 是门洞（opt.door !== false 时补一扇门）。
   返回 {walls:[], door:null|{...}}，全是局部坐标。 */
function _rpart(axis, pos, t, a1, a2, g1, g2, opt){
  const walls = [], o = opt || {};
  /* 参数守卫：坐标只要有一个不是有限数，就退回"这一段墙全都不要"。
     以前漏传一个 a1 会造出 x=[object Object] / h=NaN 的空气墙，
     画不出来、但会挡路找不着原因。 */
  if (![axis, pos, t, a1, a2].every(v => v === 'h' || v === 'v' ? true : Number.isFinite(v))){
    return { walls, door: null, bad: true };
  }
  if (o.door !== false && !(Number.isFinite(g1) && Number.isFinite(g2))){
    return { walls, door: null, bad: true };
  }
  const seg = (s, e) => {
    if (e - s < 1) return;
    walls.push(axis === 'v'
      ? { x: pos, y: s, w: t, h: e - s }
      : { x: s, y: pos, w: e - s, h: t });
  };
  if (o.door === false){ seg(a1, a2); return { walls, door: null }; }
  seg(a1, g1); seg(g2, a2);
  let door = null;
  if (o.door !== false && g2 - g1 >= 30){
    door = axis === 'v'
      ? { x: pos, y: g1, w: t, h: g2 - g1 }
      : { x: g1, y: pos, w: g2 - g1, h: t };
    door.skin = o.skin || 'wood';
    if (o.locked){ door.locked = true; door.isLocked = true; }   /* isLocked 才是运行时认的字段，locked 只是模板自读的 */
    if (o.keyId) door.keyId = o.keyId;
  }
  return { walls, door };
}

/* 窗户（第 73 轮）：模板里写 windows:[{side:'north', at:0.35, w:96}]，
   at 是"在这面墙上从 0 到 1 的位置"，w 是宽度（局部像素）。
   build 时这一段外墙会被拆掉、换成玻璃（L.glass），所以墙还是连贯的，只是有玻璃。 */

/* 一所房子最多摆几个箱子 —— 只在这里定，模板不再各写各的 */
const CRATE_CAP = { normal: 2, locked: 4 };

const ROOM_TEMPLATES = {
  /* ---- 1. 一室一厅的小民居（基准） ---- */
  small_house: {
    label: '小民居', w: 260, h: 220, t: 16, mat: 'wall',
    door: { side: 'east', at: 0.5, width: 60 },
    roof: { mat: 'tile', overhang: 0 },
    parts: [ _rpart('v', 124, 12, 16, 204, 80, 132) ],
    rooms: [
      { x: 16, y: 16, w: 108, h: 188, name: '客厅' },
      { x: 136, y: 16, w: 108, h: 188, name: '厨房' }
    ],
    props: [ ['table', 40, 40], ['chair', 44, 92], ['jar', 22, 170], ['broom', 96, 176] ],
    crates: [ ['mixed', 150, 30], ['junk', 214, 30] ]
  },

  /* ---- 2. 单间（工地临时房） ---- */
  studio: {
    label: '单间', w: 200, h: 180, t: 12, mat: 'wall',
    door: { side: 'south', at: 0.5, width: 64 },
    roof: { mat: 'sheet', overhang: 0 },
    parts: [],
    rooms: [ { x: 12, y: 12, w: 176, h: 156, name: '单间' } ],
    props: [ ['bottle', 40, 130], ['broom', 160, 34], ['jar', 26, 26] ],
    crates: [ ['junk', 150, 24], ['ammo', 150, 118] ]
  },

  /* ---- 3. 两室（中间一条走廊） ---- */
  two_room: {
    label: '两室', w: 300, h: 240, t: 16, mat: 'wall',
    door: { side: 'south', at: 0.5, width: 64 },
    roof: { mat: 'tile', overhang: 0 },
    parts: [
      _rpart('v', 108, 12, 16, 190, 70, 122),
      _rpart('v', 196, 12, 16, 190, 70, 122)
    ],
    rooms: [
      { x: 16, y: 16, w: 92, h: 208, name: '卧室' },
      { x: 120, y: 16, w: 76, h: 208, name: '走廊' },
      { x: 208, y: 16, w: 76, h: 208, name: '里屋' }
    ],
    props: [ ['table', 34, 40], ['chair', 38, 96], ['jar', 150, 180], ['bottle', 60, 190] ],
    crates: [ ['gear', 220, 40], ['mixed', 220, 150] ]
  },

  /* ---- 4. 厨房（里屋上锁当储物间） ---- */
  kitchen_house: {
    label: '厨房民居', w: 280, h: 220, t: 16, mat: 'wall',
    door: { side: 'west', at: 0.5, width: 60 },
    roof: { mat: 'tile', overhang: 0 },
    parts: [ _rpart('v', 168, 16, 204, 60, 112, { locked: true, keyId: '储物间' }) ],
    rooms: [
      { x: 16, y: 16, w: 136, h: 188, name: '厨房' },
      { x: 180, y: 16, w: 84, h: 188, name: '储物间', locked: true }
    ],
    props: [ ['table', 40, 40], ['jar', 24, 170], ['jar', 60, 170], ['chair', 100, 120] ],
    crates: [ ['med', 190, 30], ['ammo', 234, 30], ['gear', 190, 96], ['mixed', 234, 96], ['junk', 212, 160] ]
  },

  /* ---- 5. 带卫生间的民居 ---- */
  bathroom_house: {
    label: '带厕所的民居', w: 260, h: 260, t: 16, mat: 'wall',
    door: { side: 'south', at: 0.28, width: 60 },
    roof: { mat: 'tile', overhang: 0 },
    parts: [
      _rpart('v', 150, 16, 16, 244, 90, 142),
      _rpart('h', 172, 16, 150, 244, 192, 244)
    ],
    rooms: [
      { x: 16, y: 16, w: 118, h: 228, name: '客厅' },
      { x: 166, y: 16, w: 78, h: 140, name: '卧室' },
      { x: 166, y: 188, w: 78, h: 56, name: '卫生间' }
    ],
    props: [ ['table', 40, 60], ['chair', 44, 116], ['jar', 22, 220], ['bottle', 190, 210] ],
    crates: [ ['med', 180, 30], ['junk', 220, 120], ['mixed', 30, 120] ]
  },

  /* ---- 6. 小仓库（大、空、铁皮顶） ---- */
  warehouse: {
    label: '小仓库', w: 380, h: 280, t: 20, mat: 'wall',
    door: { side: 'south', at: 0.26, width: 72 },
    roof: { mat: 'sheet', overhang: 0 },
    parts: [],
    rooms: [ { x: 20, y: 20, w: 340, h: 240, name: '库房' } ],
    props: [ ['broom', 60, 60], ['bottle', 320, 220], ['jar', 300, 60] ],
    crates: [ ['gear', 40, 40], ['mixed', 90, 40], ['ammo', 40, 90], ['junk', 330, 200], ['med', 280, 200] ]
  },

  /* ---- 7. 小卖部（后半仓上锁） ---- */
  shop: {
    label: '小卖部', w: 320, h: 220, t: 16, mat: 'wall',
    door: { side: 'south', at: 0.5, width: 64 },
    roof: { mat: 'tile', overhang: 0 },
    parts: [ _rpart('v', 188, 16, 204, 80, 132, { locked: true, keyId: '后仓' }) ],
    rooms: [
      { x: 16, y: 16, w: 156, h: 188, name: '铺面' },
      { x: 200, y: 16, w: 104, h: 188, name: '后仓', locked: true }
    ],
    props: [ ['table', 40, 40], ['chair', 90, 40], ['jar', 24, 170], ['bottle', 150, 170] ],
    crates: [ ['mixed', 214, 30], ['ammo', 272, 30], ['gear', 214, 100], ['med', 272, 100], ['junk', 240, 160] ]
  },

  /* ---- 8. 小诊所（药房上锁） ---- */
  clinic: {
    label: '小诊所', w: 360, h: 240, t: 16, mat: 'wall',
    door: { side: 'west', at: 0.4, width: 64 },
    roof: { mat: 'slab', overhang: 0 },
    parts: [
      _rpart('v', 140, 16, 16, 224, 84, 136),
      _rpart('v', 252, 16, 224, 84, 136, { locked: true, keyId: '药房' })
    ],
    rooms: [
      { x: 16, y: 16, w: 108, h: 208, name: '挂号厅' },
      { x: 156, y: 16, w: 80, h: 208, name: '诊室' },
      { x: 268, y: 16, w: 76, h: 208, name: '药房', locked: true }
    ],
    props: [ ['table', 40, 40], ['chair', 44, 96], ['bottle', 100, 190], ['broom', 176, 190] ],
    crates: [ ['med', 280, 30], ['med', 324, 30], ['gear', 280, 100], ['med', 324, 100], ['mixed', 302, 170] ]
  },

  /* ---- 9. 办公室（三间格子） ---- */
  office: {
    label: '办公室', w: 340, h: 200, t: 14, mat: 'wall',
    door: { side: 'south', at: 0.5, width: 64 },
    roof: { mat: 'slab', overhang: 0 },
    parts: [
      _rpart('v', 110, 14, 14, 186, 70, 116),
      _rpart('v', 220, 14, 14, 186, 70, 116)
    ],
    rooms: [
      { x: 14, y: 14, w: 82, h: 172, name: '办公室' },
      { x: 124, y: 14, w: 82, h: 172, name: '会议室' },
      { x: 234, y: 14, w: 92, h: 172, name: '经理室' }
    ],
    props: [ ['table', 30, 36], ['chair', 34, 84], ['table', 140, 130], ['bottle', 60, 160] ],
    crates: [ ['mixed', 276, 28], ['junk', 300, 140] ]
  },

  /* ---- 10. 营房（尽头的军械室上锁） ---- */
  barracks: {
    label: '营房', w: 400, h: 220, t: 16, mat: 'wall',
    door: { side: 'south', at: 0.18, width: 64 },
    roof: { mat: 'sheet', overhang: 0 },
    parts: [ _rpart('v', 292, 16, 204, 80, 132, { locked: true, keyId: '军械' }) ],
    rooms: [
      { x: 16, y: 16, w: 260, h: 188, name: '营房' },
      { x: 308, y: 16, w: 76, h: 188, name: '军械室', locked: true }
    ],
    props: [ ['table', 40, 40], ['chair', 44, 96], ['bottle', 120, 170], ['broom', 250, 40] ],
    crates: [ ['ammo', 320, 30], ['ammo', 360, 30], ['gear', 320, 100], ['ammo', 360, 100], ['mixed', 340, 160] ]
  },

  /* ---- 11. 公寓一层：外走廊 + 三户，最里那户锁着 ---- */
  apartment: {
    label: '公寓一层', w: 460, h: 200, t: 16, mat: 'wall',
    door: { side: 'south', at: 0.5, width: 64 },
    roof: { mat: 'slab', overhang: 0 },
    parts: [
      _rpart('h', 120, 16, 16, 40, 0, 0, { door: false }),
      _rpart('h', 120, 16, 40, 92, 40, 92),
      _rpart('h', 120, 16, 92, 176, 0, 0, { door: false }),
      _rpart('h', 120, 16, 176, 228, 176, 228),
      _rpart('h', 120, 16, 228, 312, 0, 0, { door: false }),
      _rpart('h', 120, 16, 312, 364, 312, 364, { locked: true, keyId: '三号房' }),
      _rpart('h', 120, 16, 364, 444, 380, 432),
      _rpart('v', 132, 16, 16, 120, 0, 0, { door: false }),
      _rpart('v', 268, 16, 16, 120, 0, 0, { door: false }),
      _rpart('v', 368, 16, 16, 120, 0, 0, { door: false })
    ],
    rooms: [
      { x: 16, y: 136, w: 428, h: 48, name: '走廊' },
      { x: 16, y: 16, w: 116, h: 104, name: '一号房' },
      { x: 132, y: 16, w: 136, h: 104, name: '二号房' },
      { x: 268, y: 16, w: 104, h: 104, name: '三号房', locked: true },
      { x: 368, y: 16, w: 76, h: 104, name: '四号房' }
    ],
    props: [ ['bottle', 60, 160], ['broom', 200, 160], ['jar', 30, 40] ],
    crates: [ ['med', 292, 24], ['gear', 330, 24], ['ammo', 292, 70], ['mixed', 330, 70], ['junk', 24, 24] ]
  },

  /* ---- 12. 储藏室（窄长，全是箱子） ---- */
  storage: {
    label: '储藏室', w: 180, h: 320, t: 14, mat: 'wall',
    door: { side: 'north', at: 0.5, width: 64 },
    roof: { mat: 'sheet', overhang: 0 },
    parts: [],
    rooms: [ { x: 14, y: 14, w: 152, h: 292, name: '储藏室' } ],
    props: [ ['broom', 24, 280], ['jar', 30, 60] ],
    crates: [ ['mixed', 30, 40], ['junk', 110, 40], ['ammo', 30, 120], ['gear', 110, 120],
              ['med', 30, 200], ['mixed', 110, 200] ]
  },

  /* ---- 13. 工坊（料间 + 工位 + 车间） ---- */
  workshop: {
    label: '工坊', w: 300, h: 240, t: 16, mat: 'wall',
    door: { side: 'south', at: 0.5, width: 64 },
    roof: { mat: 'sheet', overhang: 0 },
    parts: [
      _rpart('h', 148, 16, 16, 224, 100, 152),
      _rpart('v', 120, 16, 16, 86, 24, 76)
    ],
    rooms: [
      { x: 16, y: 16, w: 92, h: 120, name: '料间' },
      { x: 132, y: 16, w: 152, h: 120, name: '工位' },
      { x: 16, y: 160, w: 268, h: 64, name: '车间' }
    ],
    props: [ ['table', 150, 30], ['chair', 154, 80], ['jar', 30, 40], ['bottle', 250, 180] ],
    crates: [ ['gear', 260, 30], ['junk', 30, 190], ['mixed', 90, 190] ]
  },

  /* ---- 14. 安全屋（门厅 + 上锁的内库） ---- */
  safehouse: {
    label: '安全屋', w: 300, h: 260, t: 20, mat: 'wall',
    door: { side: 'west', at: 0.5, width: 64 },
    roof: { mat: 'slab', overhang: 0 },
    parts: [ _rpart('v', 96, 20, 240, 100, 152, { locked: true, keyId: '内库' }) ],
    rooms: [
      { x: 20, y: 20, w: 56, h: 220, name: '门厅' },
      { x: 116, y: 20, w: 164, h: 220, name: '内库', locked: true }
    ],
    props: [ ['bottle', 40, 200], ['broom', 40, 40] ],
    crates: [ ['gear', 130, 30], ['gear', 190, 30], ['ammo', 130, 90], ['ammo', 190, 90],
              ['mixed', 130, 150], ['med', 190, 150], ['junk', 240, 210] ]
  },

  /* ---- 15. 大屋（客厅 + 两间卧室 + 上锁的储藏间，最大的模板） ---- */
  big_house: {
    label: '大屋', w: 480, h: 300, t: 16, mat: 'wall',
    door: { side: 'south', at: 0.5, width: 72 },
    roof: { mat: 'tile', overhang: 0 },
    parts: [
      _rpart('v', 180, 16, 16, 284, 120, 176),
      _rpart('v', 320, 16, 284, 130, 186, { locked: true, keyId: '储藏间' })
    ],
    rooms: [
      { x: 16, y: 16, w: 148, h: 268, name: '客厅' },
      { x: 196, y: 16, w: 108, h: 118, name: '卧室' },
      { x: 196, y: 166, w: 108, h: 118, name: '卧室二' },
      { x: 336, y: 16, w: 128, h: 268, name: '储藏间', locked: true }
    ],
    props: [ ['table', 40, 40], ['chair', 44, 96], ['chair', 100, 40], ['jar', 24, 250],
             ['bottle', 160, 250], ['broom', 210, 250] ],
    crates: [ ['gear', 350, 30], ['ammo', 400, 30], ['med', 350, 100], ['mixed', 400, 100],
              ['ammo', 350, 170], ['junk', 400, 170], ['mixed', 380, 240], ['junk', 60, 150] ]
  },

  /* ================= 第 73 轮：大房子（都要窗户） =================
     用户要"多做一些比较大、特别大的模板房子，最好有窗户（玻璃）"，
     并且把武器箱、配件箱放进去（数量要少）。
     这三张是新的"大"档：560×400 起跳，全是多年级房间 + 内廊。 */

  /* ---- 16. 大礼堂（前厅 + 两间侧厅 + 上锁的后库） ---- */
  grand_hall: {
    label: '大礼堂', w: 560, h: 400, t: 18, mat: 'wall',
    scale: 1,
    door: { side: 'south', at: 0.5, width: 76 },
    roof: { mat: 'tile', overhang: 0 },
    windows: [
      { side: 'north', at: 0.16, w: 110 },
      { side: 'north', at: 0.68, w: 110 },
      { side: 'west',  at: 0.34, w: 96 },
      { side: 'east',  at: 0.34, w: 96 },
      { side: 'east',  at: 0.72, w: 72 }
    ],
    parts: [
      _rpart('v', 210, 18, 18, 382, 140, 196),
      _rpart('v', 372, 18, 18, 382, 250, 306, { locked: true, keyId: '后库' })
    ],
    rooms: [
      { x: 18, y: 18, w: 192, h: 364, name: '前厅' },
      { x: 228, y: 18, w: 144, h: 364, name: '侧厅' },
      { x: 390, y: 18, w: 152, h: 364, name: '后库', locked: true }
    ],
    props: [ ['table', 40, 40], ['chair', 44, 104], ['chair', 120, 40], ['jar', 26, 330],
             ['bottle', 250, 330], ['broom', 300, 40], ['table', 250, 150] ],
    crates: [ ['weap', 430, 40], ['attach', 430, 110], ['gear', 430, 180], ['ammo', 430, 250],
              ['med', 430, 310], ['mixed', 60, 220], ['mixed', 150, 300] ],
    maxCrates: 7
  },

  /* ---- 17. 庄园主楼（回字形：中庭走廊 + 四间房 + 上锁的主卧） ---- */
  manor: {
    label: '庄园主楼', w: 680, h: 460, t: 20, mat: 'wall',
    scale: 1,
    door: { side: 'south', at: 0.5, width: 80 },
    roof: { mat: 'tile', overhang: 0 },
    windows: [
      { side: 'north', at: 0.12, w: 120 },
      { side: 'north', at: 0.56, w: 120 },
      { side: 'west',  at: 0.22, w: 100 },
      { side: 'west',  at: 0.66, w: 100 },
      { side: 'east',  at: 0.22, w: 100 },
      { side: 'east',  at: 0.66, w: 100 }
    ],
    parts: [
      _rpart('h', 150, 20, 20, 260, 96, 152),
      _rpart('h', 150, 20, 320, 440, 356, 412),
      _rpart('v', 260, 20, 170, 440, 250, 306),
      _rpart('v', 440, 20, 170, 440, 300, 356, { locked: true, keyId: '主卧' })
    ],
    rooms: [
      { x: 20, y: 20, w: 240, h: 130, name: '客厅' },
      { x: 20, y: 170, w: 240, h: 270, name: '餐厅' },
      { x: 280, y: 20, w: 160, h: 130, name: '书房' },
      { x: 280, y: 170, w: 160, h: 270, name: '中廊' },
      { x: 460, y: 20, w: 200, h: 420, name: '主卧', locked: true }
    ],
    props: [ ['table', 50, 50], ['chair', 54, 110], ['chair', 140, 50], ['jar', 30, 390],
             ['bottle', 300, 60], ['broom', 300, 390], ['table', 490, 250], ['chair', 494, 310] ],
    crates: [ ['weap', 500, 40], ['attach', 570, 40], ['gear', 500, 110], ['med', 570, 110],
              ['gear', 500, 180], ['mixed', 60, 250], ['ammo', 60, 320], ['junk', 180, 390] ],
    maxCrates: 8
  },

  /* ---- 18. 大型库房（两排货架 + 尽头办公室，高窗） ---- */
  depot: {
    label: '大型库房', w: 600, h: 440, t: 18, mat: 'metal',
    scale: 1,
    door: { side: 'west', at: 0.5, width: 80 },
    roof: { mat: 'sheet', overhang: 0 },
    windows: [
      { side: 'north', at: 0.20, w: 120 },
      { side: 'north', at: 0.62, w: 120 },
      { side: 'east',  at: 0.30, w: 110 },
      { side: 'south', at: 0.30, w: 120 }
    ],
    parts: [
      _rpart('v', 430, 18, 18, 422, 180, 236, { locked: true, keyId: '办公室' })
    ],
    rooms: [
      { x: 18, y: 18, w: 412, h: 404, name: '货场' },
      { x: 448, y: 18, w: 134, h: 404, name: '办公室', locked: true }
    ],
    props: [ ['table', 480, 60], ['chair', 484, 120], ['jar', 40, 380], ['broom', 120, 380],
             ['bottle', 200, 380], ['table', 300, 60] ],
    crates: [ ['weap', 470, 300], ['attach', 540, 300], ['gear', 470, 360], ['ammo', 540, 360],
              ['ammo', 40, 60], ['mixed', 120, 60], ['junk', 200, 60] ],
    maxCrates: 7
  }
};

/* 模板名清单（测试与关卡编辑器用） */
const ROOM_TEMPLATE_IDS = Object.keys(ROOM_TEMPLATES);

