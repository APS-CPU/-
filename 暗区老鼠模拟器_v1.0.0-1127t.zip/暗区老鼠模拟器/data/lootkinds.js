/* ============================================================================
   物资种类总表 · 名字的唯一出处
   ----------------------------------------------------------------------------
   以前"这个 kind 叫什么"写在 game/32-baggrid.js 的 LOOT_KINDS 里，和它的
   take()/draw() 缠在一起；想改个名字得在两千多行的绘制代码里翻。
   现在名字、分类、一句话说明都在这里；LOOT_KINDS 只留"捡起来做什么、长什么样"。

   加一种新物资：
     1) 这里加一条 { label, group, brief }
     2) game/32-baggrid.js 的 LOOT_KINDS 里加 { take, draw }（名字会自动盖上去）
     3) 需要掉落的话，去 data/enemies.js / data/vehicles.js 的 drops 里写 kind
   ============================================================================ */

const LOOT_KIND_DEF = {
  /* —— 死亡地带的剧情物 —— */
  intel:    { label:'情报',       group:'dz',   brief:'抽奖商人换来的，地图上标出黑匣子范围' },
  blackbox: { label:'黑匣子',     group:'dz',   brief:'拿到它，撤离点才亮' },

  /* —— 装备 —— */
  shield:   { label:'防弹盾牌',   group:'gear', brief:'扛在身前的铁板' },
  attach:   { label:'枪械配件',   group:'gear', brief:'长管收束器 / 弹匣扩容之类' },
  key:      { label:'万能钥匙',   group:'gear', brief:'开上锁的门（无限次，不消耗）' },
  heatcell: { label:'热成像电池', group:'gear', brief:'给热成像充电' },
  thermal:  { label:'热成像',     group:'gear', brief:'穿上能看到热源' },
  armor:    { label:'防弹衣',     group:'gear', brief:'轻甲 / 重甲 / 精锐甲' },
  bag:      { label:'背包',       group:'gear', brief:'决定随身格数与备弹倍率' },

  /* —— 消耗品 —— */
  nade:     { label:'手雷',       group:'cons', brief:'扔出去炸一片' },
  smoke:    { label:'烟雾弹',     group:'cons', brief:'扔出去挡视线' },
  med:      { label:'药',         group:'cons', brief:'小药 / 大药 / 绿药包' },
  ammo:     { label:'弹药',       group:'cons', brief:'按发算，箱子给一个弹匣' },
  gun:      { label:'枪',         group:'cons', brief:'捡起来直接换手上的枪' },

  /* —— 值钱的东西 —— */
  rare:     { label:'金条',       group:'loot', brief:'物资 +3' },

  /* —— 陷阱（game/66-tripwire.js 运行期挂上来的） —— */
  rope:     { label:'绳子',       group:'trap', brief:'和手雷拖到一起 = 绊雷' },
  tripwire: { label:'绊雷',       group:'trap', brief:'A 点 → B 点拉一根线' }
};

if (typeof window !== 'undefined') window.LOOT_KIND_DEF = LOOT_KIND_DEF;
