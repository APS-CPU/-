/* Companion possessions are finite, instance based and serialized with the actor.
   e.ammo is the active magazine; pack.guns holds the other magazines, never a refill. */
const COMPANION_PACK = {guns:3, ammo:600};
