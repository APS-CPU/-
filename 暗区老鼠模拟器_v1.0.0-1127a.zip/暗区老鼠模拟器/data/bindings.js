/* data/bindings.js — 输入绑定总表（唯一事实来源，供 F8 审计面板用）
 *
 * 目的：把"谁抢了这个键"从靠猜变成一张表 + 一个检查器。
 * 每条：id 唯一；key 为 KeyboardEvent.code、'mouse0/1/2' 或 [按住键, 触发键]；
 *       grp 是"作用域"，同 key 同 grp 的两条 = 真的可能同时生效；
 *       prio 必须在同 key 同 grp 内唯一（大的先吃），否则审计报红。
 * grp:'custom' 的行额外带 bindAction / order；它们是设置页可改动作的
 * 权威定义，运行时由这些行兼容构造 BIND_DEF / BIND_NAME / BIND_ORDER。
 * when 只用于面板展示（给人看的人话），不参与判定。
 *
 * 规则：新增按键 = 往这张表加一行。忘了加 prio / 撞了同 grp 的键，F8 立刻红给你看。
 */
const DataBINDINGS = [
  /* —— 设置页可自定义动作（只描述配置，不是额外事件监听器） —— */
  { id:'cfg.up',              key:'KeyW',      label:'前进',                         grp:'custom', prio:10, when:'设置页', bindAction:'up',              order:0 },
  { id:'cfg.down',            key:'KeyS',      label:'后退',                         grp:'custom', prio:10, when:'设置页', bindAction:'down',            order:1 },
  { id:'cfg.left',            key:'KeyA',      label:'左移',                         grp:'custom', prio:10, when:'设置页', bindAction:'left',            order:2 },
  { id:'cfg.right',           key:'KeyD',      label:'右移',                         grp:'custom', prio:10, when:'设置页', bindAction:'right',           order:3 },
  { id:'cfg.crouch',          key:'ShiftLeft', label:'静步 / 蹲',                    grp:'custom', prio:10, when:'设置页', bindAction:'crouch',          order:4 },
  { id:'cfg.reload',          key:'KeyR',      label:'换弹',                         grp:'custom', prio:10, when:'设置页', bindAction:'reload',          order:5 },
  { id:'cfg.swap',            key:'KeyF',      label:'换枪',                         grp:'custom', prio:10, when:'设置页', bindAction:'swap',            order:6 },
  { id:'cfg.medSmall',        key:'Digit1',    label:'小药',                         grp:'custom', prio:10, when:'设置页', bindAction:'medSmall',        order:7 },
  { id:'cfg.medBig',          key:'Digit2',    label:'绿药包',                       grp:'custom', prio:10, when:'设置页', bindAction:'medBig',          order:8 },
  { id:'cfg.throwToggle',     key:'Digit3',    label:'投掷物 / 枪 切换',              grp:'custom', prio:10, when:'设置页', bindAction:'throwToggle',     order:9 },
  { id:'cfg.throwSwap',       key:'KeyQ',      label:'换手上的那一个',            grp:'custom', prio:10, when:'设置页', bindAction:'throwSwap',       order:10 },
  { id:'cfg.interact',        key:'KeyE',      label:'搜刮 / 交互',                   grp:'custom', prio:10, when:'设置页', bindAction:'interact',        order:11 },
  { id:'cfg.cancel',          key:'KeyX',      label:'打断吃药',                     grp:'custom', prio:10, when:'设置页', bindAction:'cancel',          order:12 },
  { id:'cfg.drop',            key:'KeyG',      label:'丢枪',                         grp:'custom', prio:10, when:'设置页', bindAction:'drop',            order:13 },
  { id:'cfg.bag',             key:'Tab',       label:'背包',                         grp:'custom', prio:10, when:'设置页', bindAction:'bag',             order:14 },
  { id:'cfg.map',             key:'KeyM',      label:'地图',                         grp:'custom', prio:10, when:'设置页', bindAction:'map',             order:15 },
  { id:'cfg.panel',           key:'KeyO',      label:'参数面板',                     grp:'custom', prio:10, when:'设置页', bindAction:'panel',           order:16 },
  { id:'cfg.commandMode',     key:'KeyH',      label:'切换鼠标指挥',                 grp:'custom', prio:10, when:'设置页', bindAction:'commandMode',     order:17 },
  { id:'cfg.commandModifier', key:'AltLeft',   label:'队友指令修饰键（按住＋左键）', grp:'custom', prio:10, when:'设置页', bindAction:'commandModifier', order:18 },
  { id:'cfg.thermal',         key:'Space',     label:'热成像开关',                   grp:'custom', prio:20, when:'设置页', bindAction:'thermal',         order:19 },
  { id:'cfg.pause',           key:'Escape',    label:'暂停 / 返回',                  grp:'custom', prio:20, when:'设置页', bindAction:'pause',           order:20 },
  { id:'cfg.codex',           key:'F1',        label:'图鉴',                         grp:'custom', prio:20, when:'设置页', bindAction:'codex',           order:21 },
  { id:'cfg.perf',            key:'F3',        label:'帧时间面板',                   grp:'custom', prio:20, when:'设置页', bindAction:'perf',            order:22 },
  { id:'cfg.hideHud',         key:'F9',        label:'隐藏界面（截图用）',            grp:'custom', prio:20, when:'设置页', bindAction:'hideHud',         order:23 },
  { id:'cfg.shield',          key:'KeyG',      label:'举盾 / 收盾（死亡地带）',       grp:'custom', prio:20, when:'设置页', bindAction:'shield',          order:24 },
  { id:'cfg.shieldDrop',      key:'KeyQ',      label:'丢盾（死亡地带）',              grp:'custom', prio:20, when:'设置页', bindAction:'shieldDrop',      order:25 },
  { id:'cfg.truckSeat',       key:'KeyT',      label:'上车 / 下车',                  grp:'custom', prio:20, when:'设置页', bindAction:'truckSeat',       order:26, bindSection:'载具操作' },
  { id:'cfg.cargoQuickMove',     key:['Shift', 'mouse0'], label:'整堆装车 / 取回（可扫过）', grp:'custom', prio:30, when:'背包与货斗', bindAction:'cargoQuickMove', order:27, bindSection:'载具操作', bindScope:'cargo', pair:true },
  { id:'cfg.inventoryTakeOne',  key:'mouse2',           label:'拿起一个',            grp:'custom', prio:20, when:'背包或货斗', bindAction:'inventoryTakeOne', order:28, bindSection:'载具操作', bindScope:'inventory' },
  { id:'cfg.inventoryTakeHalf', key:['Shift', 'mouse2'], label:'拿起半堆',            grp:'custom', prio:20, when:'背包或货斗', bindAction:'inventoryTakeHalf', order:29, bindSection:'载具操作', bindScope:'inventory', pair:true },
  { id:'cfg.inventoryPlace',    key:'mouse0',           label:'放下手上物资',         grp:'custom', prio:10, when:'背包或货斗', bindAction:'inventoryPlace', order:30, bindSection:'载具操作', bindScope:'inventory' },

  /* —— 鼠标 —— */
  { id: 'm.order',  key: 'mouse1', label: '指挥：选中/取消选中', grp: 'dev',  prio: 20, when: 'CFG.dev && devOrd.on' },
  { id: 'm.place',  key: 'mouse0', label: '投放兵种/载具',        grp: 'dev',  prio: 30, when: 'devPlaceKind' },
  { id: 'm.order2', key: 'mouse0', label: '指挥：点目标点',        grp: 'dev',  prio: 20, when: 'devOrd.pick' },
  { id: 'm.shoot',  key: 'mouse0', label: '开枪',                 grp: 'play', prio: 10, when: 'state==="play"' },
  { id: 'm.inv',    key: 'mouse0', label: '背包拖放',             grp: 'ui',   prio: 30, when: 'ui.inv.open' },
  { id: 'm.cancel', key: 'mouse2', label: '取消/关闭',            grp: '*',    prio: 50, when: '到处都在用' },

  /* —— 局内 —— */
  { id: 'k.pause',  key: 'Escape',  label: '暂停/返回',   grp: 'play', prio: 40, when: 'state==="play"' },
  { id: 'k.map',    key: 'KeyM',    label: '地图',        grp: 'play', prio: 30, when: 'state==="play"' },
  { id: 'k.bag',    key: 'Tab',     label: '背包',        grp: 'play', prio: 30, when: 'state==="play"' },
  { id: 'k.reload', key: 'KeyR',    label: '换弹',        grp: 'play', prio: 20, when: 'state==="play" && !_uiBlocked' },
  { id: 'k.swap',   key: 'KeyF',    label: '换枪',        grp: 'play', prio: 20, when: 'state==="play"' },
  { id: 'k.med',    key: 'KeyX',    label: '用药',        grp: 'play', prio: 20, when: 'state==="play"' },
  { id: 'k.shield', key: 'KeyG',    label: '举/收盾',     grp: 'play', prio: 20, when: 'state==="play"' },
  { id: 'k.dropSh', key: 'KeyQ',    label: '丢盾',        grp: 'play', prio: 20, when: 'state==="play" && !_uiBlocked' },
  { id: 'k.therm',  key: 'Space',   label: '热成像',      grp: 'play', prio: 20, when: 'state==="play"' },
  { id: 'k.xray',   key: 'KeyU',    label: '透视',        grp: 'play', prio: 10, when: 'CFG.dev' },
  { id: 'k.codex',  key: 'F1',      label: '图鉴',        grp: 'play', prio: 20, when: 'state==="play"' },
  { id: 'k.params', key: 'KeyO',    label: '参数面板',    grp: '*',    prio: 20, when: '任何界面' },
  { id: 'k.perf',   key: 'F3',      label: '性能面板',    grp: '*',    prio: 20, when: '任何界面' },
  { id: 'k.hide',   key: 'F9',      label: '隐藏 HUD',    grp: '*',    prio: 20, when: '任何界面' },
  { id: 'k.diff',   key: 'KeyB',    label: '切难度',      grp: 'play', prio: 15, when: 'isTestZone() || 割草 || 观战' },

  /* —— 开发者：投放 / 刷物资 —— */
  { id: 'k.panel',  key: 'KeyJ',    label: '投放人机面板', grp: 'dev', prio: 30, when: 'CFG.dev' },
  { id: 'k.items',  key: 'KeyV',    label: '刷物资面板',   grp: 'dev', prio: 30, when: 'CFG.dev' },
  { id: 'k.nade',   key: 'KeyK',    label: '处决/清假人',  grp: 'dev', prio: 20, when: 'CFG.dev' },
  { id: 'k.dummy',  key: 'KeyN',    label: '刷假人',       grp: 'dev', prio: 20, when: 'CFG.dev' },
  { id: 'k.dz',     key: 'KeyZ',    label: '死亡地带/战斗爽', grp: 'dev', prio: 20, when: 'CFG.dev' },
  { id: 'k.order',  key: 'KeyF7',   label: '指挥层开关',   grp: 'dev', prio: 30, when: 'CFG.dev' },
  { id: 'k.rot',    key: 'BracketLeft',  label: '投放转向 / 到达秒数 -', grp: 'dev', prio: 20, when: 'devPlaceKind || devOrd.on' },
  { id: 'k.rot2',   key: 'BracketRight', label: '投放转向 / 到达秒数 +', grp: 'dev', prio: 20, when: 'devPlaceKind || devOrd.on' },

  /* —— 死亡 / 回放 —— */
  { id: 'k.deadR',  key: 'KeyR',   label: '死亡页重来',   grp: 'dead', prio: 20, when: 'state==="dead"' },
  { id: 'k.deadV',  key: 'KeyV',   label: '看回放',       grp: 'dead', prio: 20, when: 'state==="dead"' },
  { id: 'k.grEsc',  key: 'Escape', label: '退出回放',     grp: 'greplay', prio: 20, when: 'state==="greplay"' },
  { id: 'k.grPlay', key: 'Space',  label: '播放/暂停',    grp: 'greplay', prio: 20, when: 'state==="greplay"' },

  /* —— 街机厅 / 选图 —— */
  { id: 'k.arcEsc', key: 'Escape', label: '退出街机厅',   grp: 'arcade', prio: 20, when: 'state==="arcade"' },
  { id: 'k.arcD',   key: 'KeyD',   label: '进死亡地带',   grp: 'arcade', prio: 20, when: 'state==="arcade"' },
  { id: 'k.arcC',   key: 'KeyC',   label: '切经典/随机',  grp: 'arcade', prio: 20, when: 'state==="arcade"' },
  { id: 'k.dzEsc',  key: 'Escape', label: '返回选图',     grp: 'dzpick', prio: 20, when: 'state==="dzpick"' },

  /* —— 菜单/选关 —— */
  { id: 'k.menuL', key: 'ArrowLeft',  label: '上一章/上一页', grp: 'menu', prio: 20, when: '选关/图鉴' },
  { id: 'k.menuR', key: 'ArrowRight', label: '下一章/下一页', grp: 'menu', prio: 20, when: '选关/图鉴' },
  { id: 'k.codexEsc', key: 'Escape',  label: '关图鉴',    grp: 'menu', prio: 20, when: 'codexOpen' },

  /* —— 移动 —— */
  { id: 'k.up',    key: 'KeyW', label: '上', grp: 'move', prio: 10, when: 'state==="play" && !_uiBlocked' },
  { id: 'k.down',  key: 'KeyS', label: '下', grp: 'move', prio: 10, when: 'state==="play" && !_uiBlocked' },
  { id: 'k.left',  key: 'KeyA', label: '左', grp: 'move', prio: 10, when: 'state==="play" && !_uiBlocked' },
  { id: 'k.right', key: 'KeyD', label: '右', grp: 'move', prio: 10, when: 'state==="play" && !_uiBlocked' }
];
