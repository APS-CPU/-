/* ================= 关卡进度：解锁链 + 难度锁 + 全难度标记 =================
   用户 m33914：
     · 第一章前三关默认解锁，后面的关卡要"打赢前一关（任意难度）"才开
     · 困难/噩梦逐关上锁：本关普通通关 → 本关困难；本关困难通关 → 本关噩梦
       （原文"完成前关卡的普通难度"，按"先过这一关的普通"实现；要改成
        "必须过上一关的普通"只动 diffNeed() 一处即可）
     · 四档全通 → 这一关盖一个「全难度」章
   进度存 localStorage，一局结束落盘；清空全部数据会一起清掉。 */
(function(){
  const KEY = 'after5_progress_v1';
  const DIFFS = ['easy', 'normal', 'hard', 'nightmare'];
  const FREE_LEVELS = 3;              /* 前三关（索引 0/1/2）默认解锁 */
  let P = { v: 1, lv: {}, dz: {} };
  let loaded = false;

  function load(){
    if (loaded) return;
    loaded = true;
    try{
      const raw = localStorage.getItem(KEY);
      if (raw){
        const o = JSON.parse(raw);
        if (o && typeof o === 'object' && o.lv && typeof o.lv === 'object'){
          P = { v: 1, lv: o.lv, dz: (o.dz && typeof o.dz === 'object') ? o.dz : {} };
        }
      }
    }catch(e){ P = { v: 1, lv: {}, dz: {} }; }
  }
  function save(){
    try{ localStorage.setItem(KEY, JSON.stringify(P)); }catch(e){}
  }
  function row(i){ load(); return P.lv[i] || null; }

  /* 记一次通关 */
  function progWin(i, diff){
    if (!Number.isInteger(i) || i < 0) return;
    /* 2026-11-24：开发者面板会把 diffName 改成 'custom'，以前这里直接回落成 'normal'，
       于是"开着面板打赢困难"记成了普通难度、章没点亮（用户报的就是这个）。
       现在先回落成"真正选的档位" presetName，只有它也不认时才退到 normal。 */
    if (diff === 'custom'){
      /* 先按当前参数反推：没动过任何滑块时 CFG 就等于某一档的预设值，直接认出来最准 */
      const _guess = (typeof presetMatch === 'function') ? presetMatch() : '';
      const _p = (DIFFS.indexOf(_guess) >= 0) ? _guess
                                  : ((typeof presetName === 'string') ? presetName : 'normal');
      diff = (DIFFS.indexOf(_p) >= 0) ? _p : 'normal';
    }
    if (DIFFS.indexOf(diff) < 0) diff = 'normal';
    load();
    const r = P.lv[i] || (P.lv[i] = {});
    if (r[diff]){                     /* 已经记过就别重复写盘 */
      if (typeof logInfo === 'function') logInfo('progress', '通关记录 · 第 ' + (i+1) + ' 关 · ' + diff + ' 之前已记录，跳过');
      return;
    }
    r[diff] = 1;
    save();
    if (typeof logInfo === 'function') logInfo('progress', '通关记录 · 第 ' + (i+1) + ' 关 · ' + diff + ' 已记录' + (diff === 'custom' ? '（按参数反推）' : ''));
  }
  /* m34362：难度是往上包的 —— 打通了更高的档，更低的档自然也算通过。
     例：困难通关 → 简单/普通一律算过（省得玩家补打一遍低难度才能点亮勋章）。 */
  function progHasWin(i, diff){
    const r = row(i); if (!r) return false;
    const need = DIFFS.indexOf(diff); if (need < 0) return false;
    for (const d of DIFFS){
      if (DIFFS.indexOf(d) >= need && r[d]) return true;
    }
    return false;
  }
  function progAnyWin(i){ const r = row(i); return !!(r && Object.keys(r).length); }
  /* 四档全通 = 这一关彻底打完 */
  function progFullClear(i){ return DIFFS.every(d => progHasWin(i, d)); }

  /* 关卡是否解锁：前三关白给，之后的看前一关有没有任意难度通关记录 */
  function progLevelUnlocked(i){
    if (!Number.isInteger(i) || i < 0) return false;
    if (i < FREE_LEVELS) return true;
    const prev = prevPlayableLevel(i);
    if (prev < 0) return true;
    return progAnyWin(prev);
  }
  /* 这一关还差什么才解锁（给 UI 写提示用） */
  function progLevelNeed(i){
    if (progLevelUnlocked(i)) return '';
    const prev = prevPlayableLevel(i);
    if (prev < 0) return '';
    return '先通关 ' + levelLabelOf(prev) + '（任意难度）';
  }
  /* m34766：从第三章开始，困难不再要求先打普通（玩家不想为了困难把每关都重打一遍） */
  const HARD_FREE_CH = 3;
  function levelChapterOf(i){
    if (typeof LEVELS === 'undefined' || !LEVELS || !LEVELS[i]) return 1;
    return LEVELS[i].chapter || 1;
  }
  /* m35241：把"第 11 关"这种全局序号换成"章-序"编号（1-1 / 2-5 / 3-2），玩家看得懂 */
  /* 玩家真正能玩的关卡：排除开发者图（测试区 / 娱乐·斗蛐蛐长廊） */
  function isPlayableLevel(L){
    return !!(L && !L.devOnly && !/^(娱乐|测试区)/.test(L.name || ''));
  }
  /* 编号用：剧情关（有 chapter）且可玩；3-4 带 fun 标记但仍是剧情关 */
  function isStoryLevel(L){ return isPlayableLevel(L) && !!L.chapter; }
  /* 解锁链用：往前找上一张可玩关卡（跳过测试区这类开发者图） */
  function prevPlayableLevel(i){
    if (typeof LEVELS === 'undefined' || !LEVELS) return -1;
    for (let k = i - 1; k >= 0; k--){ if (isPlayableLevel(LEVELS[k])) return k; }
    return -1;
  }
  function levelLabelOf(i){
    if (typeof LEVELS === 'undefined' || !LEVELS || !LEVELS[i]) return String(i + 1);
    if (!isStoryLevel(LEVELS[i])) return LEVELS[i].name || String(i + 1);
    const ch = LEVELS[i].chapter;
    let n = 0;
    for (let k = 0; k <= i; k++){
      const Lk = LEVELS[k];
      if (!isStoryLevel(Lk) || Lk.chapter !== ch) continue;
      n++;
    }
    return ch + '-' + n;
  }
  /* 难度是否解锁：普通白给；困难看本关普通（第三章起直接放行）；噩梦看本关困难 */
  function progDiffUnlocked(i, diff){
    if (diff === 'easy' || diff === 'normal') return true;
    if (diff === 'hard') return levelChapterOf(i) >= HARD_FREE_CH ? true : progHasWin(i, 'normal');
    if (diff === 'nightmare') return progHasWin(i, 'hard');
    return true;
  }
  function progDiffNeed(i, diff){
    if (diff === 'hard') return levelChapterOf(i) >= HARD_FREE_CH ? '' : '先通关这一关的「普通」难度';
    if (diff === 'nightmare') return '先通关这一关的「困难」难度';
    return '';
  }
  /* 这一关四档各自的状态，UI 一次读全 */
  function progLevelState(i){
    return {
      unlocked: progLevelUnlocked(i),
      full: progFullClear(i),
      any: progAnyWin(i),
      normal: progHasWin(i, 'normal'),
      hard: progHasWin(i, 'hard'),
      nightmare: progHasWin(i, 'nightmare'),
      easy: progHasWin(i, 'easy')
    };
  }
  /* 开发者/测试图不受任何限制 */
  function progLevelFree(L){ return !!(L && L.devOnly); }

  /* ---------------- 死亡地带难度解锁链（m33967） ----------------
     困难默认能玩；在困难里成功撤离一次 → 解锁噩梦；
     在噩梦里成功撤离一次 → 解锁硬核。死亡 / 主动放弃不算。 */
  const DZ_LABEL = { hard: '困难', nightmare: '噩梦', core: '硬核' };
  const DZ_NEXT = { hard: 'nightmare', nightmare: 'core', core: '' };
  function progDzDone(t){ load(); return !!(P.dz && P.dz[t]); }
  function progDzUnlocked(t){
    if (t === 'hard') return true;
    if (t === 'nightmare') return progDzDone('hard');
    if (t === 'core') return progDzDone('nightmare');
    return true;
  }
  function progDzNeed(t){
    if (t === 'nightmare') return '先在「困难」里成功撤离一次，才能玩噩梦';
    if (t === 'core') return '先在「噩梦」里成功撤离一次，才能玩硬核';
    return '';
  }
  /* 撤离成功时调：记一笔，返回这次新解锁的难度名（没有就返回空串） */
  function progDzWin(t){
    if (!DZ_LABEL[t]) return '';
    load();
    if (!P.dz) P.dz = {};
    const first = !P.dz[t];
    if (first) P.dz[t] = 1;
    if (first) save();
    const nx = DZ_NEXT[t];
    if (first && nx && progDzUnlocked(nx)){
      window.dzUnlockToast = DZ_LABEL[nx];
      return DZ_LABEL[nx];
    }
    return '';
  }
  /* m34024：势力对抗（原军团推塔）做好后放在娱乐模式当"画饼"，
     条件是「在困难里成功撤离过一次」—— 玩家看得见、点不动。 */
  function progFactionTease(){ return progDzDone('hard'); }
  window.progFactionTease = progFactionTease;
  window.progDzDone = progDzDone;
  window.progDzUnlocked = progDzUnlocked;
  window.progDzNeed = progDzNeed;
  window.progDzWin = progDzWin;
  if (typeof window.dzUnlockToast !== 'string') window.dzUnlockToast = '';

  /* 存档里的难度如果已经不可用（比如清了进度），退回困难 */
  if (typeof dzTier === 'string' && !progDzUnlocked(dzTier)) dzTier = 'hard';
  window.progWin = progWin;
  window.progHasWin = progHasWin;
  window.progAnyWin = progAnyWin;
  window.progFullClear = progFullClear;
  window.progLevelUnlocked = progLevelUnlocked;
  window.progLevelNeed = progLevelNeed;
  window.levelLabelOf = levelLabelOf;
  window.progDiffUnlocked = progDiffUnlocked;
  window.progDiffNeed = progDiffNeed;
  window.progLevelState = progLevelState;
  window.progLevelFree = progLevelFree;
  window.progReload = function(){ loaded = false; P = { v: 1, lv: {}, dz: {} }; load(); };
})();
