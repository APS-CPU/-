/* 大风天气（weather:'wind'） ---------------------------------------------
   和雨/雷暴独立的一层：
     · 移动：顺风跑得更快、逆风被顶住（只作用在玩家身上，敌人照旧 —— 玩家才有"风"这个体感）
     · 画面：屏幕空间的风线 + 飘尘 + 几片叶子，密度随阵风变化，朝风向斜着刮过去
     · 声音：滤波噪声做出来的风噪，跟着阵风起伏（走 duckBus，耳鸣照样能压住它）
   开发模式按 C 切天气就会轮到大风。
   ------------------------------------------------------------------------ */
var WIND = {
  on: false,
  ang: 0.35,        /* 风的去向（弧度）：0 = 向右 */
  base: 1,          /* 基础风力 0~1 */
  gust: 1,          /* 阵风系数 0.55~1.15*/
  k: 1,             /* 风力档位 0~1.1：微风 0.34 / 大风 1 / 狂风暴雨 1.1（m20556） */
  t: 0,
  lines: [],
  dust: [],
  leaves: [],
  audio: null,
  fade: 0,          /* 风场速度、移动加成和风噪的缓起缓停 */
  vis: null,        /* 天气过渡给出的画面透明度，null 时沿用风场自己的淡入淡出 */
  visualStrength: 1,
  surge: 0,         /* 一次阵风的强度 1→0（每隔几秒来一下，那一下才有"被风刮"的感觉）*/
  push: 0.34,       /* 这一档天气的风力倍率：顺风也就快多少、逆风就被顶多少 */
  surgeT: 0,
  nextSurge: 3.5,
  sheets: []        /* 贴地飞过去的沙尘带 */
};
const WIND_SPEED = 520;      /* 所有风线共用的基准速度（px/s），阵风时一起加速 */
const WIND_PUSH = 0.34;    /* 顺风 +34% / 逆风 -34% */
const WIND_LINES = 76, WIND_DUST = 46, WIND_LEAVES = 16;

function windVisibility(){ return WIND.vis ?? WIND.fade; }
function windActive(){
  return typeof state !== 'undefined' && state === 'play' && windVisibility() > 0;
}
function windVec(){ return { x: Math.cos(WIND.ang), y: Math.sin(WIND.ang) }; }

function windEnsureField(){
  if (WIND.lines.length) return;
  const W0 = (typeof W === 'number' ? W : 1280), H0 = (typeof H === 'number' ? H : 800);
  for (let i = 0; i < WIND_LINES; i++)
    WIND.lines.push({ x: rand(-200, W0 + 200), y: rand(-200, H0 + 200), len: rand(90, 320), a: rand(0.05, 0.12), w: rand(1.1, 2.5), aj: rand(-0.055, 0.055) });
  for (let i = 0; i < WIND_DUST; i++)
    WIND.dust.push({ x: rand(-200, W0 + 200), y: rand(-200, H0 + 200), r: rand(1.0, 2.4), a: rand(0.07, 0.18) });
  for (let i = 0; i < 6; i++)
    WIND.sheets.push({ x: rand(-400, W0 + 400), y: rand(H0 * 0.30, H0 + 120), len: rand(300, 700), r: rand(12, 30), a: rand(0.02, 0.05) });
  for (let i = 0; i < WIND_LEAVES; i++)
    WIND.leaves.push({ x: rand(-200, W0 + 200), y: rand(-200, H0 + 200), rot: rand(0, TAU), spin: rand(-3, 3), s: rand(3.2, 6.0), a: rand(0.26, 0.46) });
}

/* 开关大风（weatherSet 里调） */
/* 只调风力，不重掷方向（过渡里每帧都会调，不能碰 WIND.ang） */
function windPushSet(pushK, kK){
  if (!WIND) return;
  WIND.push = WIND_PUSH * (pushK > 0 ? pushK : 1);
  if (kK > 0) WIND.k = kK;
}

function windVisualSet(visibility, strength){
  if (!WIND) return;
  WIND.vis = clamp(visibility, 0, 1);
  WIND.visualStrength = strength;
}

function windDirectionSet(angle){
  if (WIND) WIND.ang = angle;
}

function windSet(on, pushK, kK){
  if (!WIND) return;   /* 打包成单文件时函数声明会提升，可能在 WIND 初始化之前被调到 */
  WIND.on = !!on;
  WIND.vis = null;
  WIND.push = WIND_PUSH * (pushK > 0 ? pushK : 1);
  WIND.k = (kK > 0 ? kK : 1);
  WIND.visualStrength = WIND.k;
  if (WIND.on){
    WIND.base = 1;
    WIND.t = 0;
    windEnsureField();
  }
  /* m20556：关风不再硬切 —— 交给 windTick 里的 fade 自然落下去，音量和画面一起淡出 */
}

/* 每帧：推进阵风 + 移动风线（屏幕空间） */
function windTick(dt){
  if (!WIND || (!WIND.on && WIND.fade <= 0)) return;
  const tgt = WIND.on ? 1 : 0;
  /* m22299：4.5/s 太快（0.2 秒就到位），切天气时风是"啪"一下出现/消失。
     1.1/s ≈ 2 秒到位，肉眼能看出是慢慢起来的。 */
  WIND.fade += (tgt - WIND.fade) * Math.min(1, dt * 1.1);
  if (WIND.fade < 0.01 && !WIND.on){ WIND.fade = 0; return; }

  WIND.t += dt;
  /* 两个不同周期的正弦叠出"一阵一阵"的阵风 */
  /* 基本是一股稳定的风：只留很轻的呼吸感，真正的"一阵"由下面的 surge 负责，
     免得整片风线像节拍器一样一快一慢 */
  const g = 1;   /* 风力恒定：之前那一套呼吸/阵风会让整片风线一快一慢，像循环播放 */
  WIND.gust = clamp(g, 0.5, 1.15);
  /* 风线朝向与位移使用同一风向，随天气过渡更新。 */

  /* 阵风：每 4~9 秒来一下，1 秒左右衰减掉 */
  WIND.surgeT += dt;
  if (WIND.surgeT > WIND.nextSurge){
    WIND.surgeT = 0;
    WIND.nextSurge = 4 + Math.random() * 5;
    WIND.surge = 1;
  }
  WIND.surge = Math.max(0, WIND.surge - dt * 1.05);

  const k = WIND.fade;   /* 速度只跟淡入淡出有关，不再随风阵起伏 */
  const v = windVec();
  const W0 = (typeof W === 'number' ? W : 1280), H0 = (typeof H === 'number' ? H : 800);

  /* 所有东西跟着同一股风走：速度统一，只有位置不同。
     出界不从对侧"回绕"（那样会看出规律的节点），而是从迎风边随机位重新进来。 */
  const spd = WIND_SPEED * k;
  const M = 260;
  const outX = (x, pad) => (v.x >= 0 ? x > W0 + pad : x < -pad);
  const outY = (y, pad) => (v.y >= 0 ? y > H0 + pad : y < -pad);
  for (const L of WIND.lines){
    L.x += v.x * spd * dt;
    L.y += v.y * spd * dt;
    if (outX(L.x, M + L.len)){ L.x = v.x >= 0 ? -M - L.len : W0 + M + L.len; L.y = rand(-M, H0 + M); L.a = rand(0.05, 0.12); }
    else if (outY(L.y, M + L.len)){ L.y = v.y >= 0 ? -M - L.len : H0 + M + L.len; L.x = rand(-M, W0 + M); L.a = rand(0.05, 0.12); }
  }
  for (const d of WIND.dust){
    d.x += v.x * spd * 1.05 * dt;
    d.y += v.y * spd * 1.05 * dt;
    if (outX(d.x, 30)){ d.x = v.x >= 0 ? -30 : W0 + 30; d.y = rand(-30, H0 + 30); }
    else if (outY(d.y, 30)){ d.y = v.y >= 0 ? -30 : H0 + 30; d.x = rand(-30, W0 + 30); }
  }
  for (const sh of WIND.sheets){
    sh.x += v.x * spd * 1.00 * dt;
    sh.y += v.y * spd * 1.00 * dt * 0.30;
    if (outX(sh.x, sh.len + 80)){ sh.x = v.x >= 0 ? -sh.len - 80 : W0 + sh.len + 80; sh.y = rand(H0 * 0.30, H0 + 120); }
  }
  for (const lf of WIND.leaves){
    lf.x += v.x * spd * 0.90 * dt;
    lf.y += v.y * spd * 0.90 * dt + Math.sin(WIND.t * 2.2 + lf.rot) * 26 * dt;
    lf.rot += lf.spin * dt * (0.6 + k * 0.6);
    if (outX(lf.x, 24)){ lf.x = v.x >= 0 ? -24 : W0 + 24; lf.y = rand(-24, H0 + 24); }
    else if (outY(lf.y, 24)){ lf.y = v.y >= 0 ? -24 : H0 + 24; lf.x = rand(-24, W0 + 24); }
  }
  windAudioLevel(WIND.fade * (WIND.vis ?? 1) * WIND.gust * (1 + 0.7 * WIND.surge) * (0.30 + 0.70 * Math.min(1.2, WIND.k)));
}

/* 移动倍率：dirX/dirY 是归一化的移动方向；顺风 >1，逆风 <1 */
function windMoveK(dirX, dirY){
  if (!WIND || !WIND.on || WIND.fade <= 0.02) return 1;
  const v = windVec();
  const dot = dirX * v.x + dirY * v.y;            /* -1 正顶风 … +1 正顺风 */
  const k = 1 + (WIND.push || WIND_PUSH) * dot * WIND.gust * WIND.fade;
  return clamp(k, 0.55, 1.45);
}

/* 预烘软贴图：风线两头淡出（不会有硬线头），沙尘带是一坨模糊椭圆。
   每帧只 drawImage，不画硬描边 —— 之前那种清晰细线看起来像 UI，不像风。 */
var WIND_SPRITE = null, WIND_SHEET = null;
function windMakeSprites(){
  if (WIND_SPRITE || typeof document === 'undefined') return;
  const mk = (w, h, fn) => { const c = document.createElement('canvas'); c.width = w; c.height = h; fn(c.getContext('2d'), w, h); return c; };
  WIND_SPRITE = mk(256, 24, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, w, 0);
    gr.addColorStop(0.00, 'rgba(224,236,248,0)');
    gr.addColorStop(0.30, 'rgba(224,236,248,0.35)');
    gr.addColorStop(0.72, 'rgba(240,248,255,0.85)');
    gr.addColorStop(1.00, 'rgba(240,248,255,0)');
    g.fillStyle = gr;
    /* 上下两片：中间亮、边缘淡，模拟一束被打散的气流 */
    g.beginPath(); g.ellipse(w / 2, h / 2, w / 2, h * 0.30, 0, 0, TAU); g.fill();
    g.globalAlpha = 0.45;
    g.beginPath(); g.ellipse(w / 2, h / 2, w / 2, h * 0.46, 0, 0, TAU); g.fill();
  });
  WIND_SHEET = mk(256, 64, (g, w, h) => {
    const gr = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
    gr.addColorStop(0, 'rgba(200,190,170,0.55)');
    gr.addColorStop(0.55, 'rgba(200,190,170,0.22)');
    gr.addColorStop(1, 'rgba(200,190,170,0)');
    g.fillStyle = gr;
    g.save(); g.translate(w / 2, h / 2); g.scale(1, h / w); g.beginPath(); g.arc(0, 0, w / 2, 0, TAU); g.fill(); g.restore();
  });
}

function drawWindFx(){
  if (!WIND) return;
  const a0 = windVisibility();
  if (a0 <= 0) return;
  windMakeSprites();
  if (!WIND_SPRITE) return;
  const v = windVec();
  /* 微风的风线与沙尘带更淡。档位改变时，用透明度过渡整个风场。 */
  const strength = clamp(WIND.visualStrength, 0, 1.2);
  const streakAlpha = a0 * strength * strength;
  ctx.save();
  ctx.lineCap = 'round';
  if (streakAlpha > 0){
    for (const sh of WIND.sheets){
      ctx.globalAlpha = sh.a * streakAlpha * (0.8 + 0.2 * WIND.gust + 0.5 * WIND.surge);
      ctx.save();
      ctx.translate(sh.x - v.x * sh.len * 0.5, sh.y - v.y * sh.len * 0.5);
      ctx.rotate(WIND.ang);
      ctx.drawImage(WIND_SHEET, -sh.len * 0.5, -sh.r * 0.5, sh.len, sh.r);
      ctx.restore();
    }
    for (const L of WIND.lines){
      ctx.globalAlpha = L.a * streakAlpha * (0.85 + 0.15 * WIND.gust) * (1 + 0.55 * WIND.surge);
      const hh = 7 * L.w;
      ctx.save();
      ctx.translate(L.x, L.y);
      ctx.rotate(WIND.ang + (L.aj || 0));
      ctx.drawImage(WIND_SPRITE, -L.len, -hh / 2, L.len, hh);
      ctx.restore();
    }
  }
  /* 飘尘：小圆点，比风线快一点 */
  ctx.fillStyle = 'rgba(226,234,244,0.9)';
  for (const d of WIND.dust){
    ctx.globalAlpha = d.a * a0;
    ctx.beginPath();
    ctx.arc(d.x, d.y, d.r, 0, TAU);
    ctx.fill();
  }
  /* 几片被卷起来的叶子：小三角，自己也在转 */
  ctx.fillStyle = 'rgba(120,132,86,0.9)';
  for (const lf of WIND.leaves){
    ctx.globalAlpha = lf.a * a0;
    ctx.save();
    ctx.translate(lf.x, lf.y);
    ctx.rotate(lf.rot);
    ctx.beginPath();
    ctx.moveTo(-lf.s, 0); ctx.lineTo(0, -lf.s * 0.55); ctx.lineTo(lf.s, 0); ctx.lineTo(0, lf.s * 0.55);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }
  ctx.restore();
}

/* ---------------- 风噪（滤波噪声，跟着阵风起伏） ---------------- */
function windAudioLevel(k){
  const A = WIND && WIND.audio;
  if (!A || !A.gain) return;
  try {
    const want = Math.max(0, Math.min(1, k)) * 0.085 * ((typeof ambVolK === 'function') ? ambVolK() : 1);
    A.gain.gain.setTargetAtTime(want, A.ac.currentTime, 0.12);
    /* m20641：音色跟着风力走 —— 微风是闷在低处的呼呼，狂风是带一点尖的呼啸。
       以前只有音量变、音高不变，所以"微风和大风只是小声/大声的区别"。 */
    if (A.lp){
      const kk = Math.min(1.2, (WIND && WIND.k) || 1);
      const gust = (WIND && WIND.gust) || 1;
      const cut = 420 + 900 * kk * (0.72 + 0.34 * gust) + 260 * ((WIND && WIND.surge) || 0);
      A.lp.frequency.setTargetAtTime(Math.max(200, Math.min(2600, cut)), A.ac.currentTime, 0.18);
    }
    if (A.hp){
      const kk2 = Math.min(1.2, (WIND && WIND.k) || 1);
      A.hp.frequency.setTargetAtTime(120 + 90 * kk2, A.ac.currentTime, 0.25);
    }
  } catch(e){}
}
function windAudioStart(){
  if (!WIND || WIND.audio || typeof actx === 'undefined' || !actx) return WIND && WIND.audio;
  try {
    const len = Math.floor(actx.sampleRate * 2.0);
    const buf = actx.createBuffer(1, len, actx.sampleRate);
    const d = buf.getChannelData(0);
    /* 布朗噪声：比白噪声更像风 */
    let last = 0;
    for (let i = 0; i < len; i++){
      const wn = Math.random() * 2 - 1;
      last = (last + 0.02 * wn) / 1.02;
      d[i] = last * 3.2;
    }
    const src = actx.createBufferSource();
    src.buffer = buf; src.loop = true;
    const lp = actx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 760; lp.Q.value = 0.6;
    const hp = actx.createBiquadFilter();
    hp.type = 'highpass'; hp.frequency.value = 150;
    const gain = actx.createGain(); gain.gain.value = 0;
    src.connect(hp); hp.connect(lp); lp.connect(gain);
    gain.connect((typeof duckBus === 'function' && duckBus()) || actx.destination);
    src.start(0);
    WIND.audio = { src, gain, lp, hp, ac: actx };
  } catch(e){ WIND.audio = null; }
  return WIND.audio;
}
