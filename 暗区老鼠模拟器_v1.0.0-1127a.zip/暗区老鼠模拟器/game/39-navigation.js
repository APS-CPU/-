/* ---------------- 寻路：网格 BFS + 拉直 ---------------- */
const NAV_CELL = 10;
/* 墙外多少 px 算墙：13 会把 26px 以下的缝整条封死（人过不去、门也过不去）。
   降到 10 之后，比身体略窄的缝也会给出路径，真挤不过去时由 pushOutCircle + 贴墙滑行兜底。 */
const NAV_PAD = 13;
let navCache = null;

/* ---- 大图专用：分档 AI 更新（rules.lod） ----
   近处完整更新，中距离累计 0.1 秒思考一次；2200px 外跳过常规感知/战术，
   无线索者休眠，有线索者按缓存路径移动，重新规划共用每帧预算。
   接近玩家或队友至 1800px 内恢复；受击、蓄力、自爆等紧急状态立即唤醒。
   阈值滞回避免边界反复切换，每只敌人独立累积冷却时间。
   只对写了 rules.lod 的关卡生效。 */
const LOD_SLEEP_R = DataAI_LOD.sleepDistance, LOD_WAKE_R = DataAI_LOD.wakeDistance;
let lodFrame=0;
const navWork={calls:0,nodes:0,localRoutes:0,deferred:false,limited:false,gridMs:0,timed:false};
const NAV_GRID_FRAME_MS=3;
function resetNavigationWork(limited,timed=false){
  navWork.calls=0;navWork.nodes=0;navWork.localRoutes=0;
  navWork.gridMs=0;navWork.deferred=false;navWork.limited=limited;navWork.timed=timed;
}
const NAV_WORK_CALLS=DataNAV_BUDGET.searchCallsPerFrame,NAV_WORK_NODES=DataNAV_BUDGET.searchNodesPerFrame;
let navJob=null;
const navReady=new Map();
function advanceNavigationWork(L){
  if(!navJob)return;
  if(navJob.L!==L||navJob.ver!==navVer||navJob.nav!==navFor(L)||timeAlive-navJob.started>1.2){navJob=null;return;}
  const job=navJob;
  const path=findPath(...job.args);
  if(!navWork.deferred){
    navReady.set(job.key,{L,ver:navVer,path,until:timeAlive+2});
    if(navReady.size>32)navReady.delete(navReady.keys().next().value);
  }
}
const wallBroadCache=new WeakMap(), EMPTY_WALLS=[];
/* 移动/安全点只查附近静态墙。64px 预扩张让一次查询覆盖身体半径，保持原碰撞算法。 */
function collisionWalls(L,x,y,r=24){
  if(!L.rules||!L.rules.lod||r>64)return L.walls;
  let c=wallBroadCache.get(L);
  if(!c||c.walls!==L.walls||c.count!==L.walls.length||c.version!==navVer){
    c={walls:L.walls,count:L.walls.length,version:navVer,cells:new Map()};
    for(const w of L.walls){
      for(let cy=Math.floor((w.y-64)/256);cy<=Math.floor((w.y+w.h+64)/256);cy++)
        for(let cx=Math.floor((w.x-64)/256);cx<=Math.floor((w.x+w.w+64)/256);cx++){
          const key=cx+','+cy;let bucket=c.cells.get(key);
          if(!bucket)c.cells.set(key,bucket=[]);bucket.push(w);
        }
    }
    wallBroadCache.set(L,c);
  }
  return c.cells.get(Math.floor(x/256)+','+Math.floor(y/256))||EMPTY_WALLS;
}
function lodClock(e,dt){
  eCdTick(e,dt);eStatusTick(e,dt);
  if(behaviorOf(e).ownCooldown){
    e.fireCd=Math.max(0,(e.fireCd||0)-dt);
    e.specShotRecovery=Math.max(0,(e.specShotRecovery||0)-dt);
    e.specCoverCd=Math.max(0,(e.specCoverCd||0)-dt);
  }
  if(e.reloading>0){e.reloading=Math.max(0,e.reloading-dt);if(!e.reloading)e.ammo=weaponCore(e.wid).cap;}
  e.alertT=Math.max(0,(e.alertT||0)-dt);
}
/* 远处有记忆的敌人仍按路线前进，只是不再每帧做视野、掩体、包抄决策。
   不用数组下标取模递时：每只都有自己的累积器，插入/删除敌人也不会让它永远漏 tick。 */
function lodEnemyStep(L,e,frameDt,index){
  if(!L.rules||!L.rules.lod||e._dying)return frameDt;
  const r=e._lodTier===2?LOD_WAKE_R:LOD_SLEEP_R;
  let d2=(e.x-player.x)**2+(e.y-player.y)**2;
  for(const a of allies)if(a&&!a.dead&&a.hp>0)d2=Math.min(d2,(e.x-a.x)**2+(e.y-a.y)**2);
  /* 已经开始的动作不能被 LOD 截断。尤其是投雷：throwT 既是头顶进度条，
     也是“站定直到撒手”的动作锁；若在这里降频/休眠，敌人和进度条会一起僵住。 */
  const urgent=e.sees||(e._lodUrgentUntil||0)>timeAlive||e.fuse>0||e.windup>0||e.lungeT>0||e.throwT>0||e.fleeing||e.nadeDodgeThreat;
  if(d2>r*r&&!urgent){
    if(e._lodTier!==2){
      if(e.flank)flankEnd(e,'distance');
      if(e.roomSearch)roomSearchRelease(e);
      e._lodTier=2;e._lodAcc=(e._lodAcc||0)+(e._lodThink||0)+frameDt;e._lodThink=0;
      lodClock(e,e._lodAcc);e._lodAcc=0;
    }else{
      e._lodAcc=(e._lodAcc||0)+frameDt;
      if(e._lodAcc>=DataAI_LOD.sleepingClockInterval){lodClock(e,e._lodAcc);e._lodAcc=0;}
    }
    e.sees=false;
    e._lodSleep=(!e.lastKnown&&!(e.alertT>0))?1:0;
    if(e._lodSleep||enemyType(e).static||eStatusHas(e,'stun'))return 0;
    const target=e.lastKnown;
    if(!target)return 0;
    if(dist(e.x,e.y,target.x,target.y)<24){e.lastKnown=null;e.mode=0;e.path=null;return 0;}
    if((e._lodRouteAt||0)<=timeAlive){
      e._lodRouteAt=timeAlive+.35+(index%7)*.02;
      const p=e.path&&e.path[e.pi||0];
      if(!p||!e._lodGoal||dist(e._lodGoal.x,e._lodGoal.y,target.x,target.y)>160||
         !bladeWalkLine(L,e.r,e.x,e.y,p[0],p[1])){
        const walk=(map,x1,y1,x2,y2)=>roomSearchWalk(map,e,x1,y1,x2,y2);
        const path=findPath(L,e.x,e.y,target.x,target.y,walk);
        if(navWork.deferred)e._lodRouteAt=timeAlive;
        else{e.path=path;e.pi=0;e._lodGoal={x:target.x,y:target.y};}
      }
    }
    const p=e.path&&e.path[e.pi||0];
    if(p){
      const distance=dist(e.x,e.y,p[0],p[1]);
      if(distance<1){e.pi=(e.pi||0)+1;return 0;}
      const a=Math.atan2(p[1]-e.y,p[0]-e.x);
      const step=Math.min(distance,CFG.eSpeed*.72*eMoveK(e)*enemyMoveK(e)*frameDt);
      bladeMove(L,e,a,step);e.ang=a;
    }
    return 0;
  }
  if(e._lodTier===2){
    lodClock(e,e._lodAcc||0);e._lodAcc=0;e._lodSleep=0;e._lodTier=0;
    e.path=null;e.goal=null;e._lodRouteAt=0;
  }
  // 中距离低频思考；可视范围、受击、近身战斗仍每帧更新。
  const fullR=Math.max(1000,enemyVisionRange(e)+200);
  if(d2>fullR*fullR&&!urgent){
    e._lodTier=1;e._lodThink=(e._lodThink||0)+frameDt;
    if(e._lodThink<DataAI_LOD.midRangeThinkInterval)return 0;
    const dt=e._lodThink;e._lodThink=0;return dt;
  }
  const dt=frameDt+(e._lodThink||0);e._lodThink=0;e._lodTier=0;return dt;
}

function buildNav(L){
  const cw = Math.ceil(L.w / NAV_CELL), ch = Math.ceil(L.h / NAV_CELL);
  const b = new Uint8Array(cw * ch);
  const pad = NAV_PAD;
  /* Rasterize walls into the grid instead of testing every cell against every
     wall: the old nested loop was O(cells * walls) and cost ~225 ms on 4-1. */
  for (const w of L.walls){
    const x0 = Math.max(0, Math.floor((w.x - pad) / NAV_CELL));
    const x1 = Math.min(cw - 1, Math.floor((w.x + w.w + pad) / NAV_CELL));
    const y0 = Math.max(0, Math.floor((w.y - pad) / NAV_CELL));
    const y1 = Math.min(ch - 1, Math.floor((w.y + w.h + pad) / NAV_CELL));
    for (let cy = y0; cy <= y1; cy++){
      for (let cx = x0; cx <= x1; cx++){
        const px = cx*NAV_CELL + NAV_CELL/2, py = cy*NAV_CELL + NAV_CELL/2;
        if (px > w.x-pad && px < w.x+w.w+pad && py > w.y-pad && py < w.y+w.h+pad){
          b[cy*cw + cx] = 1;
        }
      }
    }
  }
  /* 岛图：陆地之外（海面）整格标死 —— 岛边不是墙，靠这张图挡住寻路 */
  if (typeof dzIsland !== 'undefined' && dzIsland && L && L.rules && L.rules.dz){
    for (let cy = 0; cy < ch; cy++){
      for (let cx = 0; cx < cw; cx++){
        const px = cx*NAV_CELL + NAV_CELL/2, py = cy*NAV_CELL + NAV_CELL/2;
        if (!dzOnLand(px, py, 6)) b[cy*cw + cx] = 1;
      }
    }
  }
  /* 只写边界格，内部不需要随全图再走一遍。右、下边界按实际地图尺寸计算。 */
  const minBorder = Math.ceil((18 - NAV_CELL/2) / NAV_CELL);
  const rightBorder = clamp(Math.floor((L.w - 18 - NAV_CELL/2) / NAV_CELL) + 1, 0, cw);
  const bottomBorder = clamp(Math.floor((L.h - 18 - NAV_CELL/2) / NAV_CELL) + 1, 0, ch);
  const topRows = Math.min(minBorder, ch);
  b.fill(1, 0, topRows * cw);
  b.fill(1, bottomBorder * cw);
  for (let row = topRows; row < bottomBorder; row++){
    const start = row * cw;
    b.fill(1, start, start + Math.min(minBorder, cw));
    b.fill(1, start + rightBorder, start + cw);
  }
  const nav={cw,ch,b,L,wallList:L.walls,wallCount:L.walls.length,truckBounds:new WeakMap()};
  for(const t of trucks){
    if(!t.solid||t.tstate==='gone')continue;
    const box=truckRect(t);
    writeNavRegion(nav,box.x,box.y,box.w,box.h);
    nav.truckBounds.set(t,box);
  }
  return nav;
}
function navFor(L){
  const missedPatch=navCache?.L===L&&(navCache.wallList!==L.walls||navCache.wallCount!==L.walls.length);
  if (!navCache || navCache.L !== L || missedPatch){
    // 编辑器/测试也可以直接替换墙表。没有收到补丁时，宁可重建一次，不能沿用旧图。
    if(missedPatch)navVer++;
    segBegin('寻路重建');                    /* 全图光栅化：大图上一秒的卡顿都出在这 */
    try { navCache = buildNav(L); } finally { segEnd(); }
  }
  return navCache;
}
/* 开场前把导航网格先建好：不然第一只敌人开始寻路时，
   那 5ms（上一代代码是 125ms）会直接落在一个游戏帧里。
   放在 reset() 里调，下载/切关/重来都会预先建好。 */
function prewarmNav(L){
  if (!L) return;
  try { navFor(L); } catch (e){ if (typeof reportErr === 'function') reportErr('39-navigation', e); }
}

/* ---------- 动态障碍：局部补丁 + 版本号 ----------
   以前只要墙碎了或玻璃生成，就 navCache = null，下一帧整张网重建。
   4-1 是 81000 格、全量重建 2.3ms —— 而这 2ms 是白送的（实测局部补丁 < 0.001ms）。
   现在改成只重刷变动区域那几行几列，然后把 navVer 加一。
   敌人身上记着"我这条路是按哪一版网格算的"（e.navVer），版本不对才重算，
   并且每帧最多放 3 个 —— 否则一次补丁会让 56 个人同帧重算（短距 11ms、中距 36ms）。
   运兵车这种"停稳的实体"也走同一套；正在漂移的车不碰网格，只靠 pushOutTrucks 推挤。 */
let navVer = 0;
let navRepathBudget = 0;               /* 每帧还允许几个敌人因为版本变了而重算 */
const NAV_REPATH_PER_FRAME = DataNAV_BUDGET.staleRepathsPerFrame;

/* 一个点算不算被挡住：墙（含 pad 13）+ 地图边界 + 停稳/报废的车 */
function navBlockedAt(L, px, py, ws = L.walls){
  const pad = NAV_PAD;
  if (px < 18 || py < 18 || px > L.w - 18 || py > L.h - 18) return 1;
  if(typeof dzIsland!=="undefined"&&dzIsland&&L.rules?.dz&&!dzOnLand(px,py,6))return 1;
  for (let i = 0; i < ws.length; i++){
    const w = ws[i];
    if (px > w.x - pad && px < w.x + w.w + pad && py > w.y - pad && py < w.y + w.h + pad) return 1;
  }
  if (typeof trucks !== 'undefined' && trucks.length){
    for (let i = 0; i < trucks.length; i++){
      const t = trucks[i];
      if (!t.solid || t.tstate === 'gone') continue;
      /* 按车身（旋转矩形）判定：用 t.r 正方形的话，车一斜就又宽又短，
         挡住的格子跟看到的不一样，AI 会从车头车尾穿过去。 */
      const _c = Math.cos(t.ang || 0), _sn = Math.sin(t.ang || 0);
      const _dx = px - t.x, _dy = py - t.y;
      const _lx =  _dx * _c + _dy * _sn;
      const _ly = -_dx * _sn + _dy * _c;
      const gx=Math.max(0,Math.abs(_lx)-TRUCK_BODY.HL),gy=Math.max(0,Math.abs(_ly)-TRUCK_BODY.HW);
      if(gx*gx+gy*gy<pad*pad)return 1;
    }
  }
  return 0;
}

/* M2.2 寻路查询门面（第一步只代理“点是否被挡”）。
   契约：
   - L 与 point 都只读；point 使用世界像素 {x,y}。
   - 返回值暂时严格保留旧 navBlockedAt 的 0/1，而不是改成布尔值。
   - radius / actorType 是后续按实体区分通行规则的预留参数；当前旧算法没有
     这两个维度，所以有意不参与判定，避免 facade 建立阶段改变寻路结果。
   - findPath 没有 bodyRadius 时沿用网格入口；有半径时校验整条线段，
     需要时才使用有区域与查询上限的局部连续路线。 */
var NavQuery = Object.freeze({
  version: 1,
  isBlocked: function(L, point, radius, actorType){
    return navBlockedAt(L, point.x, point.y);
  },
  findPath: function(L, start, goal, options){
    if(options?.bodyRadius>0)return findBodyPath(L,start,goal,options);
    return findPath(L, start.x, start.y, goal.x, goal.y,
      options && options.walkClear, options && options.navOverride);
  },
  invalidateRegion: function(L, rect){
    rayWallCache.delete(L);
    return navPatchRect(L, rect.x, rect.y, rect.w, rect.h);
  },
  resolveMovement: function(L, actor, desiredMove){
    return moveHeading(L, actor, desiredMove.angle, desiredMove.dt, desiredMove.step);
  }
});

/* 只重刷 [x,y,w,h]（外扩 pad）覆盖到的格子。返回重刷的格子数，测试里断言用 */
function navPatchRect(L,x,y,w,h){
  const nav=navCache;
  if(!nav||nav.L!==L)return 0;
  const cells=writeNavRegion(nav,x,y,w,h);
  nav.wallList=L.walls;nav.wallCount=L.walls.length;
  navVer++;
  return cells;
}
function writeNavRegion(nav,x,y,w,h){
  const L=nav.L,pad=NAV_PAD;
  const x0=Math.max(0,Math.floor((x-pad)/NAV_CELL)),x1=Math.min(nav.cw-1,Math.floor((x+w+pad)/NAV_CELL));
  const y0=Math.max(0,Math.floor((y-pad)/NAV_CELL)),y1=Math.min(nav.ch-1,Math.floor((y+h+pad)/NAV_CELL));
  if(x1<x0||y1<y0)return 0;
  /* 一次收集补丁区域里的墙，随后每格只扫这组候选。
     直接读墙表的当前坐标，覆盖刚拆除、加入或移动的障碍。 */
  const left=(x0+.5)*NAV_CELL,right=(x1+.5)*NAV_CELL;
  const top=(y0+.5)*NAV_CELL,bottom=(y1+.5)*NAV_CELL;
  const walls=L.rules?.lod
    ? L.walls.filter(wall=>wall.x-pad<right&&wall.x+wall.w+pad>left&&wall.y-pad<bottom&&wall.y+wall.h+pad>top)
    : L.walls;
  let count=0;
  for(let iy=y0;iy<=y1;iy++)for(let ix=x0;ix<=x1;ix++){
    nav.b[iy*nav.cw+ix]=navBlockedAt(L,(ix+.5)*NAV_CELL,(iy+.5)*NAV_CELL,walls);
    count++;
  }
  return count;
}
/* 车移动、掉头、变残骸或离场时旧脚印也要一并撤掉。 */
function navPatchTruck(t){
  const nav=navCache;
  if(!t||!nav||!nav.L)return 0;
  const previous=nav.truckBounds.get(t),box=truckRect(t);
  const same=previous&&previous.x===box.x&&previous.y===box.y&&previous.w===box.w&&previous.h===box.h;
  let cells=previous&&!same?writeNavRegion(nav,previous.x,previous.y,previous.w,previous.h):0;
  cells+=writeNavRegion(nav,box.x,box.y,box.w,box.h);
  if(t.solid&&t.tstate!=='gone')nav.truckBounds.set(t,box);
  else nav.truckBounds.delete(t);
  navVer++;
  return cells;
}
/* 找最近的空网格（被墙盖住时用） */
function nearestFreeCell(nav, cx, cy){
  const {cw, ch, b} = nav;
  cx = Math.max(0, Math.min(cw-1, cx)); cy = Math.max(0, Math.min(ch-1, cy));
  if (!b[cy*cw+cx]) return cy*cw + cx;
  for (let r = 1; r <= 12; r++){
    for (let dy = -r; dy <= r; dy++){
      for (let dx = -r; dx <= r; dx++){
        if (Math.abs(dx) !== r && Math.abs(dy) !== r) continue;
        const x = cx+dx, y = cy+dy;
        if (x < 0 || y < 0 || x >= cw || y >= ch) continue;
        if (!b[y*cw+x]) return y*cw + x;
      }
    }
  }
  return -1;
}
/* 两点之间有没有墙（按步长采样，pad 已含人机半径） */
function clearWalkLine(L, x1, y1, x2, y2){
  if(!navTrucksClear(13,x1,y1,x2,y2))return false;
  const d = Math.hypot(x2-x1, y2-y1);
  const step = 10, n = Math.max(1, Math.ceil(d/step));
  for (let i = 1; i <= n; i++){
    const t = i/n, px = x1 + (x2-x1)*t, py = y1 + (y2-y1)*t;
    if (px < 18 || py < 18 || px > L.w-18 || py > L.h-18) return false;
    for (const w of collisionWalls(L,px,py,14)){
      if (px > w.x-14 && px < w.x+w.w+14 && py > w.y-14 && py < w.y+w.h+14) return false;
    }
  }
  return true;
}

function clearLine(L, x1, y1, x2, y2){
  const d = Math.hypot(x2-x1, y2-y1);
  const step = 10, n = Math.max(1, Math.ceil(d/step));
  for (let i = 1; i <= n; i++){
    const t = i/n, px = x1 + (x2-x1)*t, py = y1 + (y2-y1)*t;
    if (px < 18 || py < 18 || px > L.w-18 || py > L.h-18) return false;
    for (const w of collisionWalls(L,px,py,14)){
      if (w.glass) continue;
      if (px > w.x-14 && px < w.x+w.w+14 && py > w.y-14 && py < w.y+w.h+14) return false;
    }
  }
  return true;
}
/* 返回世界坐标点数组；走不到返回 null */
let PF_BUF = null, PF_ROOM_BUF = null;

/* ---- A* 用的二叉堆 ----
   以前这里是纯 BFS：没有启发式，等于把整片可达区域全展开一遍。
   4-1 这种长走廊看不出来（目标就在旁边），但地图一大（比如 5 万像素 =
   一张 1250×1250 的格子图），一次寻路就可能扫几十万格。
   八向移动的代价：直走 1、斜走 √2，启发式用 octile（同一套代价模型，
   所以 h 是可采纳且一致的，第一次弹出某格时它的 g 就是最优）。 */
const PF_SQ2 = Math.SQRT2;
function _pfPush(B, i, f){
  const H = B.hi, F = B.hf;
  let k = ++B.hn;
  while (k > 1){
    const p = k >> 1;
    if (F[p] <= f) break;
    H[k] = H[p]; F[k] = F[p]; k = p;
  }
  H[k] = i; F[k] = f;
}
function _pfPop(B){
  const H = B.hi, F = B.hf;
  const top = H[1];
  const lastI = H[B.hn], lastF = F[B.hn];
  B.hn--;
  if (B.hn > 0){
    let k = 1;
    for (;;){
      let c = k << 1;
      if (c > B.hn) break;
      if (c + 1 <= B.hn && F[c+1] < F[c]) c++;
      if (F[c] >= lastF) break;
      H[k] = H[c]; F[k] = F[c]; k = c;
    }
    H[k] = lastI; F[k] = lastF;
  }
  return top;
}

function findPath(L, sx, sy, tx, ty, walkClear, navOverride, bodyKey){
  segBegin('网格寻路');
  const start=navWork.timed?performance.now():0;
  try { return searchGridPath(L,sx,sy,tx,ty,walkClear,navOverride,bodyKey,start); }
  finally { if(navWork.timed)navWork.gridMs+=performance.now()-start;segEnd(); }
}

function searchGridPath(L,sx,sy,tx,ty,walkClear=clearWalkLine,navOverride=null,bodyKey="",started=performance.now()){
  navWork.deferred=false;
  const limited=navWork.limited&&(navWork.timed||!!L.rules?.lod);
  const key=[sx.toFixed(2),sy.toFixed(2),tx.toFixed(2),ty.toFixed(2),navVer,navOverride?navOverride.routeKey||'override':'base',bodyKey].join(':');
  const ready=limited&&navReady.get(key);
  if(ready&&ready.L===L&&ready.ver===navVer&&ready.until>=timeAlive){navReady.delete(key);return ready.path;}
  if(!limited)navJob=null;
  if(navJob&&(navJob.L!==L||navJob.ver!==navVer||navJob.nav!==navFor(L)))navJob=null;
  if(limited&&navJob&&navJob.key!==key){
    /* 单槽 A*：正在算的那条路占着槽位时，别人只能等。以前是"一等等到 6 秒超时"——
       进屋后一群敌人同时换目标，旧任务永远完不成、新任务永远排不上，整片人就僵在原地。
       现在：旧任务超过 0.35 秒就让路给新人，谁也别想独占。 */
    if(timeAlive-navJob.started>0.35){navJob=null;}
    else {navWork.deferred=true;return null;}
  }
  const resume=limited&&navJob&&navJob.key===key;
  if(limited&&(navWork.calls>=NAV_WORK_CALLS||navWork.nodes>=NAV_WORK_NODES||navWork.gridMs>=NAV_GRID_FRAME_MS)){
    navWork.deferred=true;return null;
  }
  if(limited)navWork.calls++;
  const nodeCap=limited?Math.min(DataNAV_BUDGET.searchNodesPerCall,NAV_WORK_NODES-navWork.nodes):Infinity;
  const nav = navOverride || navFor(L), cw = nav.cw, ch = nav.ch, b = nav.b;
  const cell=nav.cell||NAV_CELL, ox=nav.ox||0, oy=nav.oy||0;
  const cellX=i=>ox+(i+.5)*cell, cellY=i=>oy+(i+.5)*cell;
  const ccx = v => Math.max(0, Math.min(cw-1, Math.floor((v-ox)/cell)));
  const ccy = v => Math.max(0, Math.min(ch-1, Math.floor((v-oy)/cell)));
  let s=resume?navJob.s:nearestFreeCell(nav,ccx(sx),ccy(sy));
  if(!resume){
  /* 起点格子必须在墙的同一侧——否则人机会朝着隔墙的格子走，被 pushOut 顶回来，来回抽 */
  if (s >= 0){
    const scx = s % cw, scy = (s/cw)|0;
    const sxx = cellX(scx), syy = cellY(scy);
    if (!walkClear(L, sx, sy, sxx, syy)){
      /* Ring search around the start cell. The old version scanned every
         cell of the level and ran walkClear on each; on the long levels
         that was a single 600-1800 ms frame whenever an enemy hugged a
         wall. Stop at the first ring that yields a clear cell. */
      let best = -1, bestD = 1e9;
      for (let rr = 1; rr <= 8 && best < 0; rr++){
        for (let dy2 = -rr; dy2 <= rr; dy2++){
          for (let dx2 = -rr; dx2 <= rr; dx2++){
            if (Math.abs(dx2) !== rr && Math.abs(dy2) !== rr) continue;
            const cx2 = scx + dx2, cy2 = scy + dy2;
            if (cx2 < 0 || cy2 < 0 || cx2 >= cw || cy2 >= ch) continue;
            const idx = cy2*cw + cx2;
            if (b[idx]) continue;
            const wx = cellX(cx2), wy = cellY(cy2);
            if (!walkClear(L, sx, sy, wx, wy)) continue;
            const dd = Math.hypot(wx-sx, wy-sy);
            if (dd < bestD){ bestD = dd; best = idx; }
          }
        }
      }
      if (best >= 0) s = best;
      else if (walkClear !== clearWalkLine) return null;
    }
  }
  }
  let t=resume?navJob.t:nearestFreeCell(nav,ccx(tx),ccy(ty));
  if (s < 0 || t < 0) return null;
  if (s === t) return [[tx, ty]];

  /* 寻路缓冲复用：每个敌人每 0.8 秒规划一次，之前每次都 new 三块 N 大小的数组，
     人多的时候就是在给 GC 喂垃圾。这里按格子数缓存一份，每次清零。
     seen 现在是三态：0=没碰过、1=在堆里、2=已弹出（定案）。 */
  const N = cw*ch;
  let buffer=nav.cell ? PF_ROOM_BUF : PF_BUF;
  if (!buffer || buffer.n !== N){
    buffer = {
      n: N,
      prev: new Int32Array(N),
      seen: new Uint8Array(N),
      g: new Float32Array(N),
      hi: new Int32Array(N + 4),
      hf: new Float32Array(N + 4),
      hn: 0,
      steps: 0
    };
    if(nav.cell)PF_ROOM_BUF=buffer;
    else PF_BUF=buffer;
  }
  const {prev,seen,g}=buffer;
  if(!resume){seen.fill(0);buffer.hn=0;}
  buffer.steps = 0;

  const tcx = t % cw, tcy = (t/cw)|0;
  /* octile 距离：格子数为单位，和直走 1 / 斜走 √2 的代价完全对应。
     末尾那个 1e-6 是"平局打破"：开阔地上会有成片格子的 f 完全相等，
     不加权重时 A* 会把这些等价的格子全展开（实测 4-1 一次能弹 4 万个），
     加上一个远小于代价最小差值（√2-1 ≈ 0.414）的微量后，同价钱里优先
     挑离目标近的，路还是那条最优路，但展开量掉一个数量级。 */
  const hOf = (i) => {
    const dx = Math.abs((i % cw) - tcx), dy = Math.abs(((i/cw)|0) - tcy);
    return (dx > dy ? dx + (PF_SQ2 - 1)*dy : dy + (PF_SQ2 - 1)*dx) * (1 + 1e-6);
  };
  const NB = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
  const CAP = buffer.hi.length - 1;
  const bounds=nav.searchBounds;

  if(!resume){g[s]=0;seen[s]=1;prev[s]=-1;_pfPush(buffer,s,hOf(s));}
  let found=-1;
  while (buffer.hn > 0){
    const cur = _pfPop(buffer);
    if (seen[cur] === 2) continue;          /* 堆里可能留着旧价钱的副本 */
    seen[cur] = 2;
    buffer.steps++;
    if(limited)navWork.nodes++;
    if (cur === t){ found = cur; break; }
    const cx = cur % cw, cy = (cur/cw)|0;
    const gcur = g[cur];
    for (let k = 0; k < 8; k++){
      const nx = cx + NB[k][0], ny = cy + NB[k][1];
      if (nx < 0 || ny < 0 || nx >= cw || ny >= ch) continue;
      if(bounds && (nx<bounds.left || nx>bounds.right || ny<bounds.top || ny>bounds.bottom))continue;
      const ni = ny*cw + nx;
      if (seen[ni] === 2 || b[ni]) continue;
      // 室内补开的窄格，每一条连边都按圆形身体复核。
      const precise=nav.preciseEdges && (nav.preciseEdges[cur]||nav.preciseEdges[ni]);
      if((precise||nav.opened?.has(cur)||nav.opened?.has(ni)) &&
         !walkClear(L,cellX(cx),cellY(cy),cellX(nx),cellY(ny)))continue;
      /* 斜着走时不许切墙角 */
      if (NB[k][0] && NB[k][1]){
        if ((b[cy*cw+nx] || b[ny*cw+cx]) &&
          (!bodyKey || (!precise && !walkClear(L,cellX(cx),cellY(cy),cellX(nx),cellY(ny)))))continue;
      }
      const ng = gcur + ((NB[k][0] && NB[k][1]) ? PF_SQ2 : 1);
      if (seen[ni] === 1 && ng >= g[ni]) continue;   /* 不是更便宜的路，别插队 */
      prev[ni] = cur; g[ni] = ng; seen[ni] = 1;
      /* 堆满只是可能丢一次"更便宜的重排"，路本身不会断（它已经在堆里了） */
      if (buffer.hn < CAP) _pfPush(buffer,ni, ng + hOf(ni));
    }
    if(buffer.steps>=nodeCap || (navWork.timed && limited && (buffer.steps & 31)===0 &&
        navWork.gridMs+performance.now()-started>=NAV_GRID_FRAME_MS)){
      // 保留前沿和父节点，下帧接着搜；不把未完成搜索误判成无路，也不返回会折返的半截路线。
      if(!navJob)navJob={key,L,ver:navVer,nav:navFor(L),s,t,started:timeAlive,args:[L,sx,sy,tx,ty,walkClear,navOverride,bodyKey]};
      navWork.deferred=true;return null;
    }
  }
  navJob=null;
  if (found < 0) return null;

  const raw = [];
  for (let c = found; c !== -1; c = prev[c]){
    const cx = c % cw, cy = (c/cw)|0;
    raw.push([cellX(cx), cellY(cy)]);
  }
  raw.reverse();
  if (walkClear !== clearWalkLine){
    const tail=raw[raw.length-1];
    if (found===t&&walkClear(L,tail[0],tail[1],tx,ty)) raw.push([tx,ty]);
    raw.unshift([sx,sy]);  /* 首段也必须从身体实际位置验证。 */
  } else if(found===t)raw[raw.length-1] = [tx, ty];

  /* 拉直时也得看网格：停稳的车、废铁这些"后加的障碍"不在 L.walls 里，
     只用 walkClear 会把绕过车的折线又拉回一条直线，补丁等于白打。
     半格采样，代价可以忽略。 */
  const navSegClear = (x1, y1, x2, y2) => {
    const dd = Math.hypot(x2 - x1, y2 - y1);
    const nn = Math.max(1, Math.ceil(dd / (cell * 0.5)));
    for (let k = 1; k < nn; k++){
      const px2 = x1 + (x2 - x1) * k / nn, py2 = y1 + (y2 - y1) * k / nn;
      const cx2 = ccx(px2);
      const cy2 = ccy(py2);
      if (b[cy2 * cw + cx2]) return false;
    }
    return true;
  };

  /* 拉直：能直着到就跳过中间点 */
  const out = [];
  let i = 0;
  const LOOKAHEAD = 40;   /* was raw.length-1: O(n^2) walkClear on long paths */
  while (i < raw.length){
    let j = Math.min(raw.length - 1, i + LOOKAHEAD);
    while (j > i + 1 && !(walkClear(L, raw[i][0], raw[i][1], raw[j][0], raw[j][1]) &&
                          (bodyKey || navSegClear(raw[i][0], raw[i][1], raw[j][0], raw[j][1])))) j--;
    out.push(raw[j]);
    if (j === raw.length - 1) break;
    i = j;
  }
  return out.length ? out : null;
}
/* 沿着路径走；没路径或贴太近墙时退回绕行逻辑 */
/* 刀手绕路锁：锁住完整路点序列，玩家的小幅移动和看向玩家都不换边。
   只有直路已通、路走完、地形变化或持续没有进展时才重新规划。 */
/* 圆形身体沿整条线段扫过墙体；与 pushOutCircle 用相同半径，
   贴墙仍能沿墙走，转角也不会被采样间距或额外安全边距误判。 */
function navSweptCircleHitsRect(x1,y1,x2,y2,r,box){
  const left=box.x,top=box.y,right=left+box.w,bottom=top+box.h;
  if(Math.max(x1,x2)<left-r||Math.min(x1,x2)>right+r||
     Math.max(y1,y2)<top-r||Math.min(y1,y2)>bottom+r)return false;
  if(segHitsRect(x1,y1,x2,y2,box))return true;
  const r2=r*r;
  let ax=x1-clamp(x1,left,right),ay=y1-clamp(y1,top,bottom);
  if(ax*ax+ay*ay<r2)return true;
  ax=x2-clamp(x2,left,right);ay=y2-clamp(y2,top,bottom);
  if(ax*ax+ay*ay<r2)return true;
  const dx=x2-x1,dy=y2-y1,length2=dx*dx+dy*dy;
  if(!length2)return false;
  for(let i=0;i<4;i++){
    const x=i&1?right:left,y=i&2?bottom:top;
    const t=clamp(((x-x1)*dx+(y-y1)*dy)/length2,0,1);
    const a=x1+dx*t-x,b=y1+dy*t-y;
    if(a*a+b*b<r2)return true;
  }
  return false;
}
function navTrucksClear(radius,x1,y1,x2,y2,candidates=trucks){
  if(!candidates.length)return true;
  const r=Math.max(0,radius-.0001), reach=TRUCK_BODY.HL+TRUCK_BODY.HW+r;
  const left=Math.min(x1,x2)-reach,right=Math.max(x1,x2)+reach;
  const top=Math.min(y1,y2)-reach,bottom=Math.max(y1,y2)+reach;
  for(const t of candidates){
    if(!t.solid||t.tstate==='gone'||t.x<left||t.x>right||t.y<top||t.y>bottom)continue;
    const c=Math.cos(t.ang||0),sn=Math.sin(t.ang||0);
    const ax=x1-t.x,ay=y1-t.y,bx=x2-t.x,by=y2-t.y;
    if(navSweptCircleHitsRect(ax*c+ay*sn,-ax*sn+ay*c,bx*c+by*sn,-bx*sn+by*c,r,TRUCK_LOCAL_BODY))return false;
  }
  return true;
}
function navDoorPassable(d,throughDoors){
  return throughDoors && !(d.isLocked&&!d.unlocked&&!d.broken);
}
function bladeWalkLine(L, radius, x1, y1, x2, y2, throughDoors, candidates, indexed=false){
  const r=Math.max(0,radius-.0001);
  const left = Math.min(x1,x2), top = Math.min(y1,y2);
  const right = Math.max(x1,x2), bottom = Math.max(y1,y2);
  if(left<radius+2||top<radius+2||right>L.w-radius-2||bottom>L.h-radius-2)return false;
  const walls=candidates ? candidates.walls : (indexed || L.rules?.lod
    ? wallBoxCandidates(L,left-r,top-r,right+r,bottom+r)
    : L.walls);
  for(const w of walls)if(!w.dead&&navSweptCircleHitsRect(x1,y1,x2,y2,r,w))return false;
  if(!navTrucksClear(radius,x1,y1,x2,y2,candidates?.trucks))return false;
  const nearbyDoors=candidates ? candidates.doors : doorBoxCandidates(left-r,top-r,right+r,bottom+r);
  for(const d of nearbyDoors)
    if(!navDoorPassable(d,throughDoors)&&doorSolid(d)&&navSweptCircleHitsRect(x1,y1,x2,y2,r,d))return false;
  if(typeof dzIsland!=='undefined'&&dzIsland&&L.rules?.dz){
    const n=Math.max(1,Math.ceil(Math.hypot(x2-x1,y2-y1)/5));
    for(let i=0;i<=n;i++)if(!dzOnLand(x1+(x2-x1)*i/n,y1+(y2-y1)*i/n,0))return false;
  }
  return true;
}

/* 从当前位置顺着剩余路点估算路径长度。 */
/* 局部可见图。用实际障碍的圆角外缘生候选点，而不是继续缩网格：
   旋转车之间只剩一个身位时，路点也不必落在世界网格上。 */
const clearancePaths=new WeakSet();
function findClearancePath(L,sx,sy,tx,ty,opts,walk){
  segBegin('局部绕障');
  try { return searchClearancePath(L,sx,sy,tx,ty,opts,walk); }
  finally { segEnd(); }
}

function searchClearancePath(L,sx,sy,tx,ty,opts,walk){
  const D=DataNAV_BUDGET,r=opts.bodyRadius,base=dist(sx,sy,tx,ty);
  if(base>D.clearanceJoinRange||!walk(L,tx,ty,tx,ty))return null;
  const checkLimit=base>D.localRouteRange?D.clearanceJoinChecks:D.localRouteChecks;
  if(navWork.limited){
    if(navWork.localRoutes>=D.localRoutesPerFrame)return null;
    navWork.localRoutes++;
  }
  const margin=Math.min(165,70+r+base*.3);
  const left=Math.min(sx,tx)-margin,right=Math.max(sx,tx)+margin;
  const top=Math.min(sy,ty)-margin,bottom=Math.max(sy,ty)+margin;
  const obs=[],dx=tx-sx,dy=ty-sy,n=dx*dx+dy*dy;
  function add(box,t){
    if(box.x>right||box.y>bottom||box.x+box.w<left||box.y+box.h<top)return;
    const x=box.x+box.w*.5,y=box.y+box.h*.5;
    const u=n?clamp(((x-sx)*dx+(y-sy)*dy)/n,0,1):0;
    const score=dist(x,y,sx+dx*u,sy+dy*u)-Math.max(box.w,box.h)*.5;
    if(obs.length===D.localRouteObstacles&&score>=obs[obs.length-1].score)return;
    obs.push({box,t,score});
    obs.sort((a,b)=>a.score-b.score);
    if(obs.length>D.localRouteObstacles)obs.pop();
  }
  for(const w of L.walls)if(!w.dead)add(w,null);
  for(const t of trucks)if(t.solid&&t.tstate!=='gone')add(truckRect(t),t);
  for(const d of doors)if(doorSolid(d)&&!navDoorPassable(d,opts.throughDoors))add(d,null);
  if(!obs.length)return null;
  // All graph edges lie inside this box. Reuse its obstacle candidates for
  // this synchronous search, including obstacles outside the scored shortlist.
  if(L.rules?.lod&&!opts.walkClear){
    const near=box=>box.x<=right+r&&box.x+box.w>=left-r&&box.y<=bottom+r&&box.y+box.h>=top-r;
    const reach=TRUCK_BODY.HL+TRUCK_BODY.HW+r;
    const candidates={
      walls:wallBoxCandidates(L,left-r,top-r,right+r,bottom+r).filter(w=>!w.dead&&near(w)),
      doors:doorBoxCandidates(left-r,top-r,right+r,bottom+r).filter(d=>doorSolid(d)&&near(d)),
      trucks:trucks.filter(t=>t.solid&&t.tstate!=='gone'&&t.x>=left-reach&&t.x<=right+reach&&
                             t.y>=top-reach&&t.y<=bottom+reach)
    };
    const throughDoors=opts.throughDoors;
    walk=(map,x,y,gx,gy)=>bladeWalkLine(map,r,x,y,gx,gy,throughDoors,candidates);
  }
  const nodes=[[sx,sy],[tx,ty]];
  let checks=0;
  // 以车身的局部轴生成法线点。圆角外缘采样留少量余量以便连接，平边则保留极窄的通道。
  for(const {box,t} of obs){
    const body=t?TRUCK_LOCAL_BODY:box,angle=t?t.ang||0:0;
    const c=Math.cos(angle),sn=Math.sin(angle);
    for(let corner=0;corner<4;corner++){
      const rightSide=corner===0||corner===3,lowerSide=corner<2;
      const x=body.x+(rightSide?body.w:0),y=body.y+(lowerSide?body.h:0);
      for(let k=0;k<=4;k++){
        const a=(corner+k/4)*Math.PI/2;
        const d=k===0||k===4?r+.035:(r+.035)/Math.cos(Math.PI/16);
        const qx=x+Math.cos(a)*d,qy=y+Math.sin(a)*d;
        const px=t?t.x+qx*c-qy*sn:qx,py=t?t.y+qx*sn+qy*c:qy;
        if(px<left||px>right||py<top||py>bottom)continue;
        if(walk(L,px,py,px,py))nodes.push([px,py]);
      }
    }
  }
  const count=nodes.length,g=new Float64Array(count),h=new Float64Array(count);
  const prev=new Int16Array(count),closed=new Uint8Array(count);
  g.fill(Infinity);g[0]=0;prev.fill(-1);
  for(let i=0;i<count;i++)h[i]=dist(nodes[i][0],nodes[i][1],tx,ty);
  while(checks<checkLimit){
    let u=-1,score=Infinity;
    for(let i=0;i<count;i++)if(!closed[i]&&g[i]+h[i]<score){score=g[i]+h[i];u=i;}
    if(u<0)return null;
    if(u===1){
      const route=[];
      for(let p=1;p>0;p=prev[p])route.push(nodes[p]);
      route.reverse();clearancePaths.add(route);
      return route;
    }
    closed[u]=1;
    const [x,y]=nodes[u];
    for(let i=1;i<count&&checks<checkLimit;i++){
      if(closed[i])continue;
      const [px,py]=nodes[i],cost=g[u]+dist(x,y,px,py);
      if(cost>=g[i])continue;
      checks++;
      if(walk(L,x,y,px,py)){g[i]=cost;prev[i]=u;}
    }
  }
  return null;
}
function findBodyPath(L,start,goal,options){
  const sx=start.x,sy=start.y,tx=goal.x,ty=goal.y;
  const {bodyRadius,throughDoors}=options;
  const walk=options.walkClear||((map,x,y,gx,gy)=>
    bladeWalkLine(map,bodyRadius,x,y,gx,gy,throughDoors));
  navWork.deferred=false;
  if(walk(L,sx,sy,tx,ty))return [[tx,ty]];
  const key=(options.routeKind||'body')+':'+options.bodyRadius+':'+!!options.throughDoors;
  const coarse=findPath(L,sx,sy,tx,ty,walk,options.navOverride,key);
  if(navWork.deferred){
    const fine=findClearancePath(L,sx,sy,tx,ty,options,walk);
    if(fine){navWork.deferred=false;return fine;}
    return null;
  }
  let safe=coarse,px=sx,py=sy;
  for(const p of coarse||[]){
    if(!walk(L,px,py,p[0],p[1])){safe=null;break;}
    px=p[0];py=p[1];
  }
  const direct=dist(sx,sy,tx,ty),len=pathLeftLen(safe,0,sx,sy);
  if(!safe||dist(px,py,tx,ty)>2||len>Math.max(direct*1.23,direct+28)){
    const range=safe&&dist(px,py,tx,ty)<=2?DataNAV_BUDGET.localRouteRange:DataNAV_BUDGET.clearanceJoinRange;
    if(direct<=range){
      if(navWork.limited&&navWork.localRoutes>=DataNAV_BUDGET.localRoutesPerFrame&&!safe){
        navWork.deferred=true;return null;
      }
      const fine=findClearancePath(L,sx,sy,tx,ty,options,walk);
      if(fine&&(!safe||dist(px,py,tx,ty)>2||pathLeftLen(fine,0,sx,sy)<len))return fine;
    }
  }
  return safe;
}

function pathLeftLen(path, pi, x, y){
  if (!path || !path.length) return 1e9;
  let total = 0, px = x, py = y;
  for (let i = Math.max(0, pi | 0); i < path.length; i++){
    total += Math.hypot(path[i][0] - px, path[i][1] - py);
    px = path[i][0]; py = path[i][1];
  }
  return total;
}

function bladeNavSteer(L, e, tx, ty, dt){
  e.navBodyMotion=true;
  const radius=officeSqueezeRadius(L,e)??e.r;
  const walk = (map,x1,y1,x2,y2) => bladeWalkLine(map,radius,x1,y1,x2,y2);
  /* B 计划第一步：关门不让走就绕远；真绕不过去，就把关门当成「会自己开」再算一次 */
  const walkDoors = (map,x1,y1,x2,y2) => bladeWalkLine(map,radius,x1,y1,x2,y2,true);
  if (!walk(L,tx,ty,tx,ty)){
    const safe=safeSpot(L,{x:clamp(tx,e.r+2,L.w-e.r-2),y:clamp(ty,e.r+2,L.h-e.r-2)},e.r+2);
    tx=safe.x; ty=safe.y;
  }
  e.bladeNavDistance = dist(e.x,e.y,tx,ty);
  if (walk(L,e.x,e.y,tx,ty)){
    e.path = null; e.bladeNavPath = null; e.bladeNavStall = 0; e.pathViaDoor=false;
    e.goal = {x:tx,y:ty};
    return Math.atan2(ty-e.y,tx-e.x);
  }
  const nav = navFor(L);
  for (let attempt=0;attempt<2;attempt++){
    const heardRoute=!!(e.heard&&!e.sees&&e.mode===1);
    /* 听声调查已经选好路线后，拐角处短暂停滞先尝试跳到下一段；
       不要 0.9 秒一到就把整条路线推翻，改从房子的另一边绕。 */
    if(heardRoute&&e.path&&e.pi<e.path.length-1&&(e.bladeNavStall||0)>1.15){
      const skip=e.path[e.pi+1];
      if(skip&&walk(L,e.x,e.y,skip[0],skip[1])){
        e.pi++;e.bladeNavPoint=null;e.bladeNavStall=0;
      }
    }
    const next = e.path && e.path[e.pi];
    const routeWalk=e.pathViaDoor?walkDoors:walk;
    let blocked=!!(next&&!routeWalk(L,e.x,e.y,next[0],next[1]));
    const topologyChanged=e.bladeNavVer!==navVer;
    if(!blocked&&next&&topologyChanged){
      for(let i=e.pi+1;i<Math.min(e.path.length,e.pi+6);i++){
        const a=e.path[i-1],b=e.path[i];
        if(!routeWalk(L,a[0],a[1],b[0],b[1])){blocked=true;break;}
      }
    }
    if(blocked){
      e.path=null;e.bladeNavPath=null;e.pi=0;e._pathRetryAt=0;e.bladeNavDistance=0;
    }
    const refresh=!!(next&&!blocked&&topologyChanged&&navRepathBudget>0);
    if(refresh)navRepathBudget--;
    const stallLimit=heardRoute?2.6:0.9;
    if (refresh || blocked || !e.path || e.path !== e.bladeNavPath || e.pi >= e.path.length || e.bladeNavGrid !== nav || (e.bladeNavStall || 0)>stallLimit){
      if(e.bladeNavVer===navVer&&(e._pathRetryAt||0)>timeAlive){e.bladeNavDistance=0;return e.ang;}
      _NAV_STEER_START.x=e.x; _NAV_STEER_START.y=e.y;
      _NAV_STEER_GOAL.x=tx; _NAV_STEER_GOAL.y=ty;
      _BLADE_PATH_OPTIONS.bodyRadius=radius;_BLADE_PATH_OPTIONS.throughDoors=false;
      let _np = NavQuery.findPath(L,_NAV_STEER_START,_NAV_STEER_GOAL,_BLADE_PATH_OPTIONS);
      if(navWork.deferred){e.bladeNavDistance=0;return e.ang;}
      let viaDoor = false;
      const _dc = (typeof DataCHASE === 'object' && DataCHASE) ? DataCHASE : null;
      if ((!_np || !_np.length) && (!_dc || _dc.doorRetry !== false)){
        _BLADE_PATH_OPTIONS.throughDoors=true;
        const _dp = NavQuery.findPath(L,_NAV_STEER_START,_NAV_STEER_GOAL,_BLADE_PATH_OPTIONS);
        if(navWork.deferred){e.bladeNavDistance=0;return e.ang;}
        if (_dp && _dp.length){ _np = _dp; viaDoor = true; }
      }
      /* 换向迟滞：旧路还在、新路第一步跟当前朝向几乎相反（=要掉头绕另一头），
         而且新路并没有明显更短，就继续走旧路。没有这一条时，目标每抖一下
         就可能从墙这头绕改成从那头绕，看起来就是在墙根来回抽。 */
      let _adopt = true;
      if (_np && _np.length && e.path && e.path.length && e.pi < e.path.length){
        const _qa = Math.atan2(_np[0][1]-e.y, _np[0][0]-e.x);
        const _old=e.path[e.pi];
        const _oldA=Math.atan2(_old[1]-e.y,_old[0]-e.x);
        /* 调查脚步时以旧路线方向为锁，而不是枪口朝向；枪口会朝声音转，不能拿它决定绕哪边。 */
        const _refA=heardRoute?_oldA:e.ang;
        const _turnCos=Math.cos(_qa-_refA);
        if (_turnCos < (heardRoute?0.15:-0.35)){
          const _oldLen = pathLeftLen(e.path, e.pi, e.x, e.y);
          const _newLen = pathLeftLen(_np, 0, e.x, e.y);
          if (!(_newLen < _oldLen * (heardRoute?0.62:0.75))) _adopt = false;
        }
      }
      if(_adopt&&(_np||!refresh)){e.path=_np;e.pi=0;e.pathViaDoor=viaDoor;}
      e.bladeNavVer=navVer;
      e._pathRetryAt=(_np||e.path)?0:timeAlive+.35;
      e.bladeNavPath=e.path; e.bladeNavGrid=nav;
      e.goal={x:tx,y:ty}; e.bladeNavPoint=null; e.bladeNavStall=0;
    }
    if (!e.path || !e.path.length) break;
    while (e.pi<e.path.length){
      const p=e.path[e.pi], next=e.path[e.pi+1], d=dist(e.x,e.y,p[0],p[1]);
      if (d<0.25 || (d<26 && next && walk(L,e.x,e.y,next[0],next[1]))){e.pi++;continue}
      break;
    }
    if (e.pi>=e.path.length){e.path=null;continue}
    const p=e.path[e.pi], d=dist(e.x,e.y,p[0],p[1]);
    if(!(e.pathViaDoor?walkDoors:walk)(L,e.x,e.y,p[0],p[1])){
      e.path=null;e.bladeNavPath=null;e._pathRetryAt=0;e.bladeNavDistance=0;
      continue;
    }
    if (e.bladeNavPoint!==p){e.bladeNavPoint=p;e.bladeNavBest=d;e.bladeNavStall=0}
    else if (d<e.bladeNavBest-1){e.bladeNavBest=d;e.bladeNavStall=0}
    else e.bladeNavStall+=dt;
    e.bladeNavDistance = d;  /* 最后一步不能越过路点后再反向走回来。 */
    /* 不跳到玻璃对面的玩家，也不按面朝方向否决已经选好的绕路。 */
    return Math.atan2(p[1]-e.y,p[0]-e.x);
  }
  const a=steerAngle(L,e,Math.atan2(ty-e.y,tx-e.x),dt);
  const step=Math.min(e.bladeNavDistance,Math.max(2,e.r*.5));
  if(!walk(L,e.x,e.y,e.x+Math.cos(a)*step,e.y+Math.sin(a)*step))e.bladeNavDistance=0;
  return a;
}

const _NAV_STEER_START = {x:0,y:0}, _NAV_STEER_GOAL = {x:0,y:0};
const _BLADE_PATH_OPTIONS = {bodyRadius:0,throughDoors:false};
function navSteer(L, e, tx, ty, dt){
  // 持枪敌人与刀手共用按身体半径检查、锁定路点的绕障路线；枪口朝向不参与选路。
  if (enemyType(e).kind === 'blade' || enemyType(e).canShoot) return bladeNavSteer(L, e, tx, ty, dt);
  e.navT = (e.navT || 0) - dt;
  const goalMoved = !e.goal || dist(e.goal.x, e.goal.y, tx, ty) > 44;
  /* 网格版本变了（墙碎了 / 车停稳了 / 废铁没了）说明旧路可能撞上新障碍。
     这种重算不跟 navT 走，但要排队：每帧最多放 NAV_REPATH_PER_FRAME 个，
     不然一次补丁会让全场 56 个人同一帧全部重算（短距 11ms、中距 36ms）。 */
  const stale = (e.navVer !== navVer) && navRepathBudget > 0;
  if (!e.path || goalMoved || e.navT <= 0 || (e.stuckT || 0) > 0.5 || stale){
    if (!e.path || goalMoved || e.navT <= 0 || (e.stuckT || 0) > 0.5) { /* 常规重算，不占预算 */ }
    else navRepathBudget--;                /* 这是"网格变了"引起来的，占一个名额 */
    const had = !!e.path;
    _NAV_STEER_START.x = e.x; _NAV_STEER_START.y = e.y;
    _NAV_STEER_GOAL.x = tx; _NAV_STEER_GOAL.y = ty;
    const np = NavQuery.findPath(L, _NAV_STEER_START, _NAV_STEER_GOAL);
    if(!navWork.deferred){
    /* 换路之前先看一眼：如果旧路还有得走、目标没变，
       而新路的第一步跟旧路方向几乎相反（绕墙的两头），就别换——
       否则每 0.8 秒重算一次、每次都从另一头绕，就是人机在墙根左右晃。 */
    let adopt = true;
    if (np && had && np.length){
      /* 用“它现在的朝向”做归一化的参考，而不是旧路第一个点——
         目标每隔几十毫米变一次时旧路会被换掉，参考就不稳了。
         朝向是 lerp 出来的，稳定，能真正“让它先拐过这个弯”。 */
      const qa = Math.atan2(np[0][1]-e.y, np[0][0]-e.x);
      if (Math.cos(qa - e.ang) < -0.35) adopt = false;
    }
    if (adopt){ e.path = np; e.pi = 0; }
    e.goal = {x:tx, y:ty}; e.navT = 0.8;
    e.navVer = navVer;                     /* 这条是按当前这版网格算出来的了 */
    if (had && !e.path) logWarn('nav', '人机#' + ((enemies.indexOf(e)|0)+1) + ' 找不到路 · 目标 ' + Math.round(tx) + ',' + Math.round(ty));
    } // 排队期间保留旧路和重试状态，不把延后误当寻路失败。
  }
  let aim = null;
  if (e.path && e.pi < e.path.length){
    /* advance a waypoint only when we are really on it, or when the leg
       after it is directly visible (then cutting the corner is harmless).
       The old 20px radius let the enemy "reach" a corner 20px early and then
       aim straight through the wall - that is what made it slide back and forth. */
    while (e.pi < e.path.length){
      const _wp = e.path[e.pi];
      const _wd2 = dist(e.x, e.y, _wp[0], _wp[1]);
      const _nx = e.path[e.pi + 1];
      const _okNext = _nx ? clearWalkLine(L, e.x, e.y, _nx[0], _nx[1]) : true;
      if (_wd2 < 10 || (_wd2 < 26 && _okNext)){ e.pi++; e.wpRef = null; continue; }
      break;
    }
    if (e.pi < e.path.length) aim = e.path[e.pi];
  }
  /* waypoint stall guard: if we are not getting closer to the current
     waypoint for a while (it is unreachable, e.g. behind a wall corner),
     skip it instead of sliding back and forth forever. */
  if (aim){
    const _wd = dist(e.x, e.y, aim[0], aim[1]);
    if (e.wpRef !== aim){ e.wpRef = aim; e.wpBest = _wd; e.wpStall = 0; }
    else {
      if (_wd < e.wpBest - 1.5){ e.wpBest = _wd; e.wpStall = 0; }
      else e.wpStall += dt;
      if (e.wpStall > 1.1 && _wd > 24 && e.pi < e.path.length - 1){
        e.pi++; e.wpRef = null; e.wpStall = 0;
        aim = e.path[e.pi];
      }
    }
  }
  if (!e.path){
    /* 完全没有路：先把自己从死角里挪出去，别再对着墙推 */
    const esc = escapeDir(L, e);
    if (esc !== null) return esc;
  }
  if (!aim){
    if (e.path){ e.navT = 0; }              /* 路径用完了 → 下一帧重算，别直接撞 */
    return steerAngle(L, e, Math.atan2(ty-e.y, tx-e.x), dt);
  }
  let want = Math.atan2(aim[1]-e.y, aim[0]-e.x);
  /* 前面 26px 内有没有墙。
     关键：快走到这个点时，"到点距离"本身就小于 26px，这时候不能再要求"前方 26px 畅通"，
     否则每个路径点都会被判成"被挡住"，人就会在点旁边推墙、永远差最后几像素到不了。
     所以前瞻距离要按"还剩多远"收缩。 */
  const ahead = () => {
    const ad = dist(e.x, e.y, aim[0], aim[1]);
    return Math.min(26, Math.max(9, ad - 4));
  };
  let guard = 0;
  /* 这里必须用临时游标：不能直接推 e.pi。
     原来每帧都把路径指针往前挤，挤到头之后 aim 变 null，
     就回到“直接朝目标走”→顶墙→重算路径→再挤，人就在墙根上下左右抽。 */
  let cur2 = e.pi;
  let safeWant = want;
  while (guard++ < 4 && freeLen(L, e.x, e.y, want, ahead(), 6) < ahead()){
    /* 停在最后一个路径点上：不能把指针推过头，
       否则 aim 变 null、回到“直接朝目标”，就会与路径方向来回抢。 */
    if (cur2 >= e.path.length - 1) break;
    cur2++;
    aim = e.path[cur2];
    want = Math.atan2(aim[1]-e.y, aim[0]-e.x);
    safeWant = want;
  }
  /* 路径看到头了就沿着最后一个可用方向走，
     不要回到“直接朝目标”——那个方向往往就是墙里，
     每帧在“跟路径”和“撞墙”之间来回切就是人机左右晃。 */
  if (!aim) return steerAngle(L, e, safeWant, dt);
  if (freeLen(L, e.x, e.y, want, ahead(), 6) < ahead()) return steerAngle(L, e, want, dt);
  e.avoid = 0; e.avoidT = 0;
  return want;
}

/* 网格认为他站的这一格"不可走"（离墙太近），而四周也找不到能直连的空格：
   这种情况光调方向是没用的，只能真的把他挪出来一点。
   限制在 46px 以内、逐步检查不撞墙，玩家几乎看不出来。 */
function unstickHunter(L, b){
  const nav = navFor(L);
  const cx = Math.floor(b.x / NAV_CELL), cy = Math.floor(b.y / NAV_CELL);
  const inside = (cx >= 0 && cy >= 0 && cx < nav.cw && cy < nav.ch);
  if (!inside) return false;
  if (nav.b[cy*nav.cw + cx] === 0) return false;       /* 这格本来就能走，不用挪 */
  let best = null, bestD = 1e9;
  for (let r = 1; r <= 12; r++){
    for (let dy = -r; dy <= r; dy++){
      for (let dx = -r; dx <= r; dx++){
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const nx = cx + dx, ny = cy + dy;
        if (nx < 0 || ny < 0 || nx >= nav.cw || ny >= nav.ch) continue;
        if (nav.b[ny*nav.cw + nx] !== 0) continue;
        const wx = (nx + 0.5) * NAV_CELL, wy = (ny + 0.5) * NAV_CELL;
        const d = dist(b.x, b.y, wx, wy);
        if (d < bestD && clearLine(L, b.x, b.y, wx, wy)){ bestD = d; best = {x: wx, y: wy}; }
      }
    }
    if (best) break;
  }
  if (!best) return false;
  const a = Math.atan2(best.y - b.y, best.x - b.x);
  const step = Math.min(bestD, 46);
  let x = b.x, y = b.y;
  for (let t = 6; t <= step + 0.01; t += 6){
    const nx = b.x + Math.cos(a)*t, ny = b.y + Math.sin(a)*t;
    if (ptInWall(L, nx, ny, 15)) break;
    x = nx; y = ny;
  }
  if (x === b.x && y === b.y) return false;
  b.x = x; b.y = y;
  return true;
}

/* 被塞进死角时用的逃生方向：从所在格向外找最近的一个"可走格"，
   朝它的格子中心走。找不到（12 格外都没路）就返回 null。
   这比"朝目标硬推墙"强得多——硬推只会贴着墙来回蹭。 */
function escapeDir(L, e){
  const nav = navFor(L);
  const cx = Math.floor(e.x / NAV_CELL), cy = Math.floor(e.y / NAV_CELL);
  if (cx < 0 || cy < 0 || cx >= nav.cw || cy >= nav.ch) return null;
  if (nav.b[cy*nav.cw + cx] === 0) return null;      /* 自己这格就能走，不需要逃 */
  for (let r = 1; r <= 12; r++){
    let best = null, bestD = 1e9;
    for (let dy = -r; dy <= r; dy++){
      for (let dx = -r; dx <= r; dx++){
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const nx = cx + dx, ny = cy + dy;
        if (nx < 0 || ny < 0 || nx >= nav.cw || ny >= nav.ch) continue;
        if (nav.b[ny*nav.cw + nx] !== 0) continue;
        const wx = (nx + 0.5) * NAV_CELL, wy = (ny + 0.5) * NAV_CELL;
        const d = dist(e.x, e.y, wx, wy);
        if (d < bestD){ bestD = d; best = {x: wx, y: wy}; }
      }
    }
    if (best) return Math.atan2(best.y - e.y, best.x - e.x);
  }
  return null;
}

/* 从 (x,y) 沿 a 方向能走多远（碰墙或出界就返回） */
function freeLen(L, x, y, a, maxLen, pad){
  if (maxLen < 12) return maxLen;
  const dx = Math.cos(a), dy = Math.sin(a);
  const probeLen = Math.min(maxLen, L.w + L.h + 12);
  const endX = x + dx * probeLen, endY = y + dy * probeLen;
  const walls = wallBoxCandidates(L, Math.min(x,endX)-pad, Math.min(y,endY)-pad,
    Math.max(x,endX)+pad, Math.max(y,endY)+pad);
  for (let d = 12; d <= maxLen; d += 8){
    const px = x + dx*d, py = y + dy*d;
    if (px < 14 || py < 14 || px > L.w-14 || py > L.h-14) return d;
    for (const w of walls){
      if (px > w.x-pad && px < w.x+w.w+pad && py > w.y-pad && py < w.y+w.h+pad) return d;
    }
  }
  return maxLen;
}
/* 撞墙绕行：一旦选定往哪边绕，就锁住这一侧 1.1 秒，不许逐帧换边（换边就是"抽搐"的根） */
/* ---------------- 走路手感：转向限速 + 拐角弧线（第 236 轮，m28492） ----------------
   寻路本身是 8 向的、也做了拉直，问题不在"路径只有上下左右"，
   而在"拿到方向就立刻按这个方向位移" —— 于是每个路点都是一次硬折角。
   这里把"想去的方向"变成"身体这一帧真的转得过去的方向"。 */
function moveDef(){
  if (typeof DataMOVE === 'object' && DataMOVE) return DataMOVE;
  return { turnSpd: 7.2, turnRef: 1.3, turnSlow: 0.55, minSpdK: 0.45,
           cornerR: 74, cornerBlend: 0.4, wallProbe: 1.35 };
}

/* 拐角抄弧线：离当前路点够近时，把瞄准点往下一段挪一点，
   人就会提前拐进弧线，而不是走到点上再折 90 度。 */
function cornerAim(e, D){
  if (!e.path || e.pi === undefined || e.pi >= e.path.length) return null;
  const p = e.path[e.pi], n = e.path[e.pi + 1];
  if (!p || !n) return null;
  const d = dist(e.x, e.y, p[0], p[1]);
  const R = D.cornerR || 74;
  if (d > R) return null;
  const t = (1 - d / R) * (D.cornerBlend || 0);
  return [p[0] + (n[0] - p[0]) * t, p[1] + (n[1] - p[1]) * t];
}

/* 返回 { a, k }：a 是这一帧真正走的方向，k 是速度倍率。
   急转时 k 变小，于是拐角会自己出现"减速—转向—加速"的节奏。 */
function moveHeading(L, e, a, dt, step){
  const D = moveDef();
  if (D.on === false) return { a: a, k: 1 };   /* 总开关：关掉就完全走老逻辑 */
  const tight=e.path&&clearancePaths.has(e.path);
  const ca = tight ? null : cornerAim(e, D);
  let want = a;
  if (ca){
    const caA = Math.atan2(ca[1] - e.y, ca[0] - e.x);
    const probe = Math.max(6, (step || 12) * (D.wallProbe || 1.35));
    if (freeLen(L, e.x, e.y, caA, probe, Math.max(8, e.r)) >= Math.min(probe, 24)) want = caA;
  }
  /* 初值必须就是"想去的方向"：拿 e.ang 打底的话，刚生成或刚换目标时会先朝错的方向走半秒 */
  if (!Number.isFinite(e.moveA)) e.moveA = want;
  let err = normAng(want - e.moveA);
  const errAbs = Math.abs(err);
  const mx = Math.max(0.5, D.turnSpd || 7.2) * dt;
  if (errAbs > mx) err = err > 0 ? mx : -mx;
  e.moveA = normAng(e.moveA + err);
  e.moveErr = errAbs;
  const slow = Math.min(1, errAbs / Math.max(0.2, D.turnRef || 1.3));
  /* 冲刺豁免：往掩体跑、负伤撤退这两种是豁出去了，转得急也不减速（方向照样受角速度限制）。 */
  const _rush = (e.peekPhase === 'run') || ((e.fleeing || 0) > 0);
  const k = _rush ? 1 : Math.max(D.minSpdK || 0.45, 1 - (D.turnSlow || 0.55) * slow);
  if(e.navBodyMotion&&step>0){
    // 细路线从贴边安全点经过，平滑转向不得把身体带离路线。
    if(tight||!bladeWalkLine(L,e.r,e.x,e.y,e.x+Math.cos(e.moveA)*step,e.y+Math.sin(e.moveA)*step,e.pathViaDoor))
      return {a,k};
    return {a:e.moveA,k};
  }
  /* 平滑后的方向要是前面没路（贴着墙），这一帧退回原始方向，交给贴墙滑行处理 */
  const need = Math.min(24, Math.max(8, (step || 12) * 1.1));
  if (freeLen(L, e.x, e.y, e.moveA, need, Math.max(8, e.r)) < need) return { a: a, k: k };
  return { a: e.moveA, k: k };
}

function steerAngle(L, e, want, dt){
  const pad = Math.max(8, e.r), open = Math.max(34, e.r + 24), scan = 110;   /* pad 必须 ≥ 半径，否则会以为墙边还有余量、一直往上撞 */
  const straight = freeLen(L, e.x, e.y, want, scan, pad);
  const release = e.avoid ? open + 40 : open;     /* 已经在绕了，就得多留点余量才回直线 */
  if (straight >= release){ e.avoid = 0; e.avoidT = 0; return want; }

  e.avoidT = Math.max(0, (e.avoidT || 0) - dt);
  /* 正对一堵长墙时，左右两侧的候选是完全对称的：这一帧选左、下一帧选右，
     表现就是贴着墙原地上下晃、一步也不往前。所以这里给「选哪边」加记忆：
     上次选的那一侧在 2.2 秒内还走得通，就继续用它，除非另一侧明显更开阔。 */
  const SIDE_MEM = 2.2, SIDE_TIE = 8;
  const memFresh = e.avoidSide && (uiT - (e.avoidSideAt || -99)) < SIDE_MEM;
  const degs = [28, 52, 76, 100, 124];

  const probe = (side) => {
    let bestA = null, bestScore = -1e9;
    for (const deg of degs){
      const a = want + side*deg*Math.PI/180;
      const f = freeLen(L, e.x, e.y, a, scan, pad);
      if (f < open) continue;
      const score = f - deg*0.22;
      if (score > bestScore){ bestScore = score; bestA = a; }
    }
    return { a: bestA, score: bestScore };
  };

  /* 正在绕的那一侧优先；它抖了再退回两侧比 */
  let p1, pn;
  if (e.avoid && e.avoidT > 0){
    const only = probe(e.avoid);
    if (only.a !== null){
      e.avoidSide = e.avoid; e.avoidSideAt = uiT;
      e.avoidT = Math.max(e.avoidT, 0.9);
      return only.a;
    }
    e.avoid = 0; e.avoidT = 0;
  }
  p1 = probe(1); pn = probe(-1);
  let pick = null, pickSide = 0;
  if (p1.a !== null && pn.a !== null){
    if (memFresh && Math.abs(p1.score - pn.score) < SIDE_TIE){
      pick = (e.avoidSide > 0) ? p1 : pn; pickSide = e.avoidSide;
    } else if (p1.score >= pn.score){ pick = p1; pickSide = 1; }
    else { pick = pn; pickSide = -1; }
  } else if (p1.a !== null){ pick = p1; pickSide = 1; }
  else if (pn.a !== null){ pick = pn; pickSide = -1; }

  if (!pick){
    e.avoid = 0; e.avoidT = 0;
    return want + Math.PI*0.7;
  }
  e.avoid = pickSide; e.avoidT = 1.6;
  e.avoidSide = pickSide; e.avoidSideAt = uiT;
  return pick.a;
}
