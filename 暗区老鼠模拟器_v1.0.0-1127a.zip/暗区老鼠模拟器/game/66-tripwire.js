/* 绳子 / 绊雷 ---------------------------------------------------------
   绳子：单独无用，1×1，一件一格（不叠）。
   合成：把「手雷」拖到「绳子」上、或者把「绳子」拖到「手雷」上 → 变成「绊雷」。
         一次只消耗那一件绳子和那一颗手雷（三根绳子拖到一颗雷上只会用掉一根）。
   解开：绊雷上点右键 → 变回 1 根绳子 + 1 颗手雷（无损）。
   布设：左键点背包里的绊雷 = 开始布设 → 在脚下放 A 端 → 走到另一边点左键放 B 端，
         两点之间拉一根绳子（最长 160px）。右键 / Esc 取消，东西不消耗。
   触发：敌人踩到绳段 → A 端手雷点着 0.5 秒 → 用 nadeBlast() 爆炸（伤害/画面/声音与手雷完全一致）。
   玩家自己踩不炸（用户 m16007 明确要求）。
   --------------------------------------------------------------------- */
var TRIP_MAX_LEN = 300;     /* 两点最远距离 */
var TRIP_BAND    = 8;       /* 绳段感应半宽（敌人半径另算） */
var TRIP_FUSE    = 0.5;     /* 触发后的爆炸倒计时 */
var TRIP_SAFE    = 0.35;
var TRIP_DISARM_T = 0.7;    /* 右键按住多久才拆开（秒） */
var tripDisarm = null;      /* { it, t } 正在长按拆的那颗 */    /* 刚布好这段时间不判定（防止刚放下就被踩） */
var trips = [];             /* { ax, ay, bx, by, fuse, cool, owner }（by 是 B 点的 y，owner 才是放雷的人） */

/* ---------- 图标 ---------- */
function drawRopeIcon(x, y, s){
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  ctx.lineCap = 'round';
  /* 亚麻灰褐：不抢眼，跟铁皮、木箱、暗地面都能待在一起 */
  const _out = 'rgba(38,33,26,0.85)';
  const _main = 'rgba(158,146,120,0.98)';
  const _hi = 'rgba(182,170,142,0.95)';
  const _dark = 'rgba(104,94,74,0.95)';
  /* 先铺一圈暗底，任何底色上都读得出来 */
  ctx.strokeStyle = _out; ctx.lineWidth = 3.4;
  ctx.beginPath(); ctx.arc(0, 0, 6.2, 0, Math.PI * 2); ctx.stroke();
  ctx.strokeStyle = _main; ctx.lineWidth = 2.0;
  ctx.beginPath(); ctx.arc(0, 0, 6.2, 0, Math.PI * 2); ctx.stroke();
  ctx.strokeStyle = _dark; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(0, 0, 3.4, 0.4, Math.PI * 1.7); ctx.stroke();
  /* 两股绳头甩出去 */
  ctx.strokeStyle = _out; ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.moveTo(5.2, -3.4); ctx.quadraticCurveTo(10.5, -6.2, 13.0, -2.2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-5.0, 4.2); ctx.quadraticCurveTo(-10.2, 7.6, -12.6, 3.6); ctx.stroke();
  ctx.strokeStyle = _hi; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(5.2, -3.4); ctx.quadraticCurveTo(10.5, -6.2, 13.0, -2.2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-5.0, 4.2); ctx.quadraticCurveTo(-10.2, 7.6, -12.6, 3.6); ctx.stroke();
  ctx.restore();
}
function drawTripwireIcon(x, y, s){
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  /* 底下那圈绳 */
  ctx.strokeStyle = 'rgba(38,33,26,0.85)'; ctx.lineWidth = 3.0;
  ctx.beginPath(); ctx.ellipse(0, 6.4, 9.6, 3.4, 0, 0, Math.PI * 2); ctx.stroke();
  ctx.strokeStyle = 'rgba(158,146,120,0.98)'; ctx.lineWidth = 1.7;
  ctx.beginPath(); ctx.ellipse(0, 6.4, 9.6, 3.4, 0, 0, Math.PI * 2); ctx.stroke();
  ctx.strokeStyle = 'rgba(104,94,74,0.95)'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.ellipse(0, 6.4, 5.6, 1.9, 0, 0, Math.PI * 2); ctx.stroke();
  /* 绑在绳子上的手雷 */
  ctx.fillStyle = 'rgb(74,86,60)';
  ctx.beginPath(); ctx.ellipse(0, -1.2, 5.4, 6.4, 0, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = 'rgba(28,34,24,0.9)'; ctx.lineWidth = 1.1; ctx.stroke();
  /* 交叉绑带 */
  ctx.strokeStyle = 'rgba(176,164,136,0.95)'; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(-4.4, -3.6); ctx.lineTo(4.2, 1.6); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-4.2, 1.8); ctx.lineTo(4.4, -3.8); ctx.stroke();
  /* 拉环 + 引信头 */
  ctx.strokeStyle = 'rgb(200,206,190)'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.arc(0, -8.2, 2.1, 0, Math.PI * 2); ctx.stroke();
  ctx.fillStyle = 'rgb(160,168,150)';
  ctx.fillRect(-1.4, -10.6, 2.8, 2.2);
  ctx.restore();
}

/* ---------- 道具 ---------- */
/* 绳子可以叠：优先塞进已有那堆，没有才新占一格（绊雷才是不可叠的） */
function bagRopeCell(){
  const arr = bagItems();
  for (const it of arr){ if (it && it.k === 'rope') return it; }
  return null;
}
function bagRopeCount(){
  let n = 0;
  for (const it of bagItems()){ if (it && it.k === 'rope') n += (it.n || 1); }
  return n;
}
function bagAddRope(){
  const it = bagRopeCell();
  if (it){ it.n = (it.n || 1) + 1; bagRebuild(); return it; }
  const c = bagAddCell('rope', { n:1 });
  if (c) bagRebuild();
  return c;
}
function bagTakeOneRope(){
  const it = bagRopeCell();
  if (!it) return false;
  const n = it.n || 1;
  if (n > 1) it.n = n - 1; else bagRemoveItem(it);
  bagRebuild();
  return true;
}

LOOT_KINDS.rope = {
  take(l){
    if (!bagGridOn()){
      player.ropes = (player.ropes || 0) + 1;
      sfxPick(); setMsg('捡到绳子 · 和手雷拖到一起 = 绊雷', 2.4);
      return true;
    }
    if (!bagAddRope()){ setMsg('背包放不下绳子（要 1×1 空格）', 1.7); return false; }
    sfxPick();
    setMsg('捡到绳子 ×' + bagRopeCount() + ' · 拖到手雷上 = 做成绊雷', 2.6);
    return true;
  },
  draw(x, y){ drawRopeIcon(x, y, 1.25); }
};
LOOT_KINDS.tripwire = {
  take(l){
    if (!bagGridOn()){
      sfxPick(); setMsg('捡到绊雷', 2.0);
      return true;
    }
    if (!bagAddCell('tripwire', {})){ setMsg('背包放不下绊雷（要 1×1 空格，不能叠放）', 1.9); return false; }
    bagRebuild(); sfxPick();
    setMsg('捡到绊雷 · 点格子开始布设（A 点 → B 点，最长 ' + TRIP_MAX_LEN + '）', 2.8);
    return true;
  },
  draw(x, y){ drawTripwireIcon(x, y, 1.2); }
};
if (typeof BAG_NAT !== 'undefined'){ BAG_NAT.rope = 26; BAG_NAT.tripwire = 26; }

/* 背包里鼠标底下是哪一件（拖拽合成用；尺子跟 invGridGeom 走） */
/* 命中哪个格子里的东西 —— 注意 invGridGeom.items 里放的是
   { it: 背包物品, x, y, w, h } 这样的"格子记录"，不是物品本身。
   以前这里直接 return r，于是调用方拿到的是格子、r.k 是 undefined，
   "绳子拖到雷上"永远判不成，只能退化成换位置。 */
function bagItemAtPoint(mx, my){
  const G = (typeof invGridGeom !== 'undefined') ? invGridGeom : null;
  if (!G || !G.items) return null;
  for (const r of G.items){
    if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) return r.it || r;
  }
  return null;
}

/* ---------- 合成 / 解开 ---------- */
function bagCraftTripwire(dragIt, targetIt){
  if (!dragIt || !targetIt) return false;
  const _rope = dragIt.k === 'rope' ? dragIt : (targetIt.k === 'rope' ? targetIt : null);
  const _nade = dragIt.k === 'nade' ? dragIt : (targetIt.k === 'nade' ? targetIt : null);
  if (!_rope || !_nade) return false;
  if (!bagRemoveItem(_nade)) return false;
  if (!bagTakeOneRope()){ bagItems().push(_nade); return false; }   /* 回滚 */
  const it = bagAddCell('tripwire', {});
  if (!it){ bagItems().push(_nade, _rope); bagRebuild(); return false; }
  bagRebuild(); sfxPick();
  setMsg('绳子 + 手雷 = 绊雷 · 点格子开始布设（点右键解开）', 3.0);
  logInfo('item', '合成绊雷');
  return true;
}
function bagDisarmTripwire(it){
  if (!it || it.k !== 'tripwire') return false;
  if (!bagRemoveItem(it)) return false;
  const a = bagAddRope(), b = bagAddCell('nade', {});
  if (!a || !b){
    /* 放不下就整体回滚，不能吞东西 */
    if (a) bagRemoveItem(a);
    if (b) bagRemoveItem(b);
    bagItems().push(it); bagRebuild();
    setMsg('背包没空间放回绳子和手雷', 1.9);
    return false;
  }
  bagRebuild(); sfxPick();
  setMsg('解开绊雷 · 得到绳子 + 手雷', 2.4);
  return true;
}

/* ---------- 布设 ---------- */
function tripCancel(){
  if (!player || !player.tripPhase) return false;
  /* 绳子和手雷要到"放 B 点"才真正从背包里扣走（见 tripClick），
     所以中途取消只要清状态，东西本来就在背包里，不会吞。 */
  player.tripPhase = null;
  player.tripA = null;
  player.tripItem = null;
  setMsg('取消布设 · 绳子和手雷还在背包里', 1.8);
  return true;
}
function tripStartPlace(it){
  if (!it || it.k !== 'tripwire') return false;
  if (state !== 'play' || !player || player.hp <= 0) return false;
  player.tripPhase = 'a';
  player.tripItem = it;
  player.tripA = null;
  if (typeof ui !== 'undefined' && ui && ui.inv) ui.inv.open = false;
  player.hand = null;
  setMsg('布设绊雷：走到 A 点按左键（右键 / Esc 取消）', 3.0);
  return true;
}
/* 这段绳子会不会穿墙：沿线段取样，碰到墙就判死（绳子是实物，不能穿墙） */
function tripBlockedByWall(ax, ay, bx, by){
  const L = cur();
  if (!L || !L.walls) return false;
  const d = Math.hypot(bx - ax, by - ay);
  if (d < 0.001) return false;
  const n = Math.max(2, Math.ceil(d / 7));
  for (let i = 0; i <= n; i++){
    const t = i / n;
    const x = ax + (bx - ax) * t, y = ay + (by - ay) * t;
    for (const w of L.walls){
      if (w.dead) continue;
      if (x >= w.x && x <= w.x + w.w && y >= w.y && y <= w.y + w.h) return true;
    }
  }
  return false;
}

/* ---- 右键长按拆绊雷（防止手一抖把绊雷拆了 / 防止和"只换位置"抢手势） ---- */
function tripDisarmStart(it){
  if (!it || it.k !== 'tripwire') return false;
  const G = (typeof invGridGeom !== 'undefined') ? invGridGeom : null;
  let cell = null;
  if (G && G.items) for (const r of G.items){ if ((r.it || r) === it){ cell = r; break; } }
  tripDisarm = { it: it, t: 0, cell: cell };
  if (typeof sfxSwitch === 'function') sfxSwitch();
  return true;
}
function tripDisarmCancel(){ tripDisarm = null; }
function tripDisarmTick(dt){
  if (!tripDisarm) return;
  /* 中途松手 / 关背包 / 那件东西没了 → 直接放弃，什么都不发生 */
  if (typeof ui !== 'undefined' && ui.inv && !ui.inv.open){ tripDisarm = null; return; }
  const it = tripDisarm.it;
  if (!it || !bagItems().includes(it)){ tripDisarm = null; return; }
  tripDisarm.t += (dt || 0);
  if (tripDisarm.t < TRIP_DISARM_T) return;
  const ok = (typeof bagDisarmTripwire === 'function') ? bagDisarmTripwire(it) : false;
  tripDisarm = null;
  if (ok) setMsg('拆开绊雷 · 拿回绳子 + 手雷', 1.8);
}
/* 背包里那颗绊雷上画进度环 */
function drawTripDisarm(){
  if (!tripDisarm || !tripDisarm.cell) return;
  const r = tripDisarm.cell;
  const k = Math.max(0, Math.min(1, tripDisarm.t / TRIP_DISARM_T));
  const cx = r.x + r.w / 2, cy = r.y + r.h / 2, rad = Math.min(r.w, r.h) * 0.46;
  ctx.save();
  ctx.lineWidth = 3;
  ctx.strokeStyle = 'rgba(20,16,12,0.75)';
  ctx.beginPath(); ctx.arc(cx, cy, rad, 0, Math.PI * 2); ctx.stroke();
  ctx.strokeStyle = 'rgba(232,190,120,0.98)';
  ctx.beginPath(); ctx.arc(cx, cy, rad, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * k); ctx.stroke();
  ctx.fillStyle = 'rgba(232,190,120,0.95)';
  ctx.font = '600 11px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(k >= 1 ? '拆开' : '按住…', cx, cy + rad + 14);
  ctx.textAlign = 'left';
  ctx.restore();
}

function tripClick(){
  if (!player || !player.tripPhase) return false;
  const it = player.tripItem;
  if (!it || !bagItems().includes(it)){ player.tripPhase = null; return false; }
  if (player.tripPhase === 'a'){
    player.tripA = { x:player.x, y:player.y };
    player.tripPhase = 'b';
    setMsg('A 点已放好 · 走到另一边按左键放 B 点（最长 ' + TRIP_MAX_LEN + '）· 右键 / Esc 取消', 3.6);
    sfxSwitch();
    return true;
  }
  /* B 点 */
  const A = player.tripA;
  if (!A){ player.tripPhase = 'a'; return true; }
  const d = Math.hypot(player.x - A.x, player.y - A.y);
  if (d < 26){ setMsg('太近了 · 再走远一点', 1.6); return true; }
  if (d > TRIP_MAX_LEN){ setMsg('绳子不够长（' + Math.round(d) + ' > ' + TRIP_MAX_LEN + '）', 2.0); return true; }
  if (tripBlockedByWall(A.x, A.y, player.x, player.y)){ setMsg('绳子不能穿墙 · 换个位置', 2.0); return true; }
  const sp = { x:player.x, y:player.y };
  if (!bagRemoveItem(it)){ player.tripPhase = null; return false; }
  trips.push({ ax:A.x, ay:A.y, bx:sp.x, by:sp.y, fuse:-1, cool:TRIP_SAFE, owner:player });
  player.tripPhase = null; player.tripA = null; player.tripItem = null;
  bagRebuild(); sfxSwitch();
  setMsg('绊雷布好了 · 敌人踩到绳子就炸', 2.6);
  logInfo('item', '布设绊雷');
  return true;
}

/* 点到线段距离 */
function tripSegDist(px, py, ax, ay, bx, by){
  const dx = bx - ax, dy = by - ay;
  const L2 = dx * dx + dy * dy;
  if (L2 < 0.0001) return Math.hypot(px - ax, py - ay);
  let t = ((px - ax) * dx + (py - ay) * dy) / L2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + dx * t), py - (ay + dy * t));
}

/* 爆炸/子弹能不能引爆绊雷上的那颗手雷：命中判定用棍顶那颗雷的位置 */
function tripFuseNear(px, py, r){
  if (!trips.length) return 0;
  let n = 0;
  for (const T of trips){
    if (T.fuse >= 0) continue;
    const d = Math.hypot(px - T.ax, py - (T.ay - 15));
    if (d <= (r || 26) + 9){ T.fuse = TRIP_FUSE; n++; }
  }
  return n;
}
/* 子弹是否打中手雷（每帧扫一遍，绊雷通常只有一两根） */
function tripBulletCheck(){
  if (!trips.length || typeof bullets === 'undefined' || !bullets.length) return;
  for (const b of bullets){
    if (b.dead) continue;
    /* 子弹一帧能飞十几像素，只比"当前点"会直接穿过去 —— 按上一帧到这一帧的线段算距离 */
    const x1 = (typeof b.px === 'number') ? b.px : b.x;
    const y1 = (typeof b.py === 'number') ? b.py : b.y;
    const dx = b.x - x1, dy = b.y - y1;
    const n = dx * dx + dy * dy;
    for (const T of trips){
      if (T.fuse >= 0) continue;
      const gx = T.ax, gy = T.ay - 15;
      const t = n ? Math.max(0, Math.min(1, ((gx - x1) * dx + (gy - y1) * dy) / n)) : 0;
      const hx = x1 + dx * t, hy = y1 + dy * t;
      if (Math.hypot(hx - gx, hy - gy) <= 9){
        T.fuse = TRIP_FUSE;
        /* 打中绊雷 = 拽掉拉环：用真录音的手雷拉环声 */
        if (!(typeof sfxNadePin === 'function' && sfxNadePin()) && typeof sfxSwitch === 'function') sfxSwitch();
      }
    }
  }
}

function updateTrips(dt){
  tripDisarmTick(dt);
  tripBulletCheck();
  if (!trips.length || !dt || dt <= 0) return;
  for (let i = trips.length - 1; i >= 0; i--){
    const T = trips[i];
    if (T.cool > 0) T.cool -= dt;
    if (T.fuse >= 0){
      T.fuse -= dt;
      if (T.fuse <= 0){
        trips.splice(i, 1);
        nadeBlast(T.ax, T.ay, T.owner || player);
      }
      continue;
    }
    if (T.cool > 0) continue;
    for (const e of enemies){
      if (!e || e.dead || e.hp <= 0) continue;
      const er = (e.r || 10) * 0.55;
      if (tripSegDist(e.x, e.y, T.ax, T.ay, T.bx, T.by) <= TRIP_BAND + er){
        T.fuse = TRIP_FUSE;
        /* 绊到线 = 拽掉拉环（不是"咔哒"），之后照常 0.5 秒爆炸 */
        if (!(typeof sfxNadePin === 'function' && sfxNadePin()) && typeof sfxSwitch === 'function') sfxSwitch();
        break;
      }
    }
  }
}

function drawTrips(){
  if (!trips.length && !(player && player.tripPhase)) return;
  /* 已布好的 */
  for (const T of trips){
    if (typeof cullPt === 'function' && !cullPt((T.ax + T.bx) / 2, (T.ay + T.by) / 2, 220)) continue;
    const armed = T.fuse >= 0;
    /* A 端是一根插在地上的细棍，手雷绑在棍顶；绳子从棍顶绷直拉到 B 端 */
    const STICK_H = 15;
    const topX = T.ax, topY = T.ay - STICK_H;
    ctx.save();
    ctx.lineCap = 'round';
    /* 绷紧的绳子：两点直线，不垂 */
    ctx.strokeStyle = 'rgba(18,14,10,0.85)'; ctx.lineWidth = 3.2;
    ctx.beginPath(); ctx.moveTo(topX, topY); ctx.lineTo(T.bx, T.by); ctx.stroke();
    ctx.strokeStyle = armed ? 'rgba(255,138,96,0.98)' : 'rgba(196,184,156,0.95)';
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(topX, topY); ctx.lineTo(T.bx, T.by); ctx.stroke();
    /* 地上的一小片影 */
    ctx.fillStyle = 'rgba(0,0,0,0.34)';
    ctx.beginPath(); ctx.ellipse(T.ax, T.ay + 4, 6.0, 2.6, 0, 0, TAU); ctx.fill();
    /* 细棍：一根很细的深褐小棍，斜插进地里 */
    ctx.strokeStyle = 'rgba(74,56,36,0.98)'; ctx.lineWidth = 2.2;
    ctx.beginPath(); ctx.moveTo(T.ax + 2.6, T.ay + 4); ctx.lineTo(topX, topY + 2); ctx.stroke();
    ctx.strokeStyle = 'rgba(146,116,78,0.95)'; ctx.lineWidth = 1.0;
    ctx.beginPath(); ctx.moveTo(T.ax + 2.2, T.ay + 3); ctx.lineTo(topX + 0.4, topY + 2); ctx.stroke();
    /* 绑带：手雷和棍子交叉绑在一起 */
    ctx.strokeStyle = 'rgba(206,186,140,0.95)'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(topX - 4.5, topY + 6); ctx.lineTo(topX + 4.5, topY + 1); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(topX - 4.5, topY + 1); ctx.lineTo(topX + 4.5, topY + 6); ctx.stroke();
    /* B 端小桩 */
    ctx.fillStyle = 'rgba(150,130,98,0.98)';
    ctx.beginPath(); ctx.arc(T.bx, T.by, 4.0, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(38,30,20,0.9)'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = 'rgba(226,202,150,0.9)';
    ctx.beginPath(); ctx.arc(T.bx - 1, T.by - 1, 1.4, 0, TAU); ctx.fill();
    /* 手雷绑在棍顶（比人矮一截，正好在膝盖高度） */
    drawNadeModel(topX, topY + 7, 0.82, 0, armed);
    if (armed){
      const k = 1 - Math.max(0, T.fuse) / TRIP_FUSE;
      ctx.globalAlpha = 0.35 + 0.5 * Math.abs(Math.sin(k * 22));
      ctx.fillStyle = 'rgba(255,140,60,1)';
      ctx.beginPath(); ctx.arc(topX + 3.0, topY + 1.6, 2.2, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1;
    }
    ctx.restore();
  }
  /* 布设预览 */
  if (player && player.tripPhase){
    const A = player.tripA;
    /* 线画到"玩家身上"而不是鼠标上 —— B 点本来就是按玩家站位算的，
       画到鼠标会让人以为可以拖着线走。 */
    const tx = player.x, ty = player.y;
    if (player.tripPhase === 'b' && A){
      const d = Math.hypot(tx - A.x, ty - A.y);
      const _wall = tripBlockedByWall(A.x, A.y, tx, ty);
      const ok = d >= 26 && d <= TRIP_MAX_LEN && !_wall;
      ctx.save();
      ctx.setLineDash([7, 6]);
      ctx.strokeStyle = ok ? 'rgba(196,184,156,0.9)' : 'rgba(235,96,72,0.95)';
      ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(tx, ty); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = ok ? 'rgba(206,196,170,1)' : 'rgba(240,120,96,1)';
      ctx.font = '600 13px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(_wall ? ('穿墙 · ' + Math.round(d) + ' / ' + TRIP_MAX_LEN) : (Math.round(d) + ' / ' + TRIP_MAX_LEN), (A.x + tx) / 2, (A.y + ty) / 2 - 8);
      ctx.fillStyle = 'rgba(196,184,156,0.85)';
      ctx.font = '600 11px system-ui, sans-serif';
      ctx.fillText('右键 / Esc 取消布设', (A.x + tx) / 2, (A.y + ty) / 2 + 14);
      ctx.textAlign = 'left';
      ctx.restore();
    } else {
      /* A 点还没放：在脚下画个圈提示 */
      ctx.save();
      ctx.setLineDash([5, 5]);
      ctx.strokeStyle = 'rgba(214,190,140,0.85)'; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(player.x, player.y, 16, 0, TAU); ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }
  }
}

/* 绳子/绊雷是这里挂上来的，名字再从 data/lootkinds.js 取一次 */
if (typeof lootApplyLabels === 'function') lootApplyLabels();
