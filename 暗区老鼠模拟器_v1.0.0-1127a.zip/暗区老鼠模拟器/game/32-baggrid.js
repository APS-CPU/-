/* ================= 网格背包（机制版本 3） =================
   老版本（ver 2）里背包只是一串计数：药 ×n、烟 ×n，总数不超格数就算装得下。
   ver 3 之后背包是真正的一张格子：每件东西有自己的长宽，摆不下就是摆不下。

   规则（跟用户定的）：
     · 药 1×1（不再叠放，一颗药一格）
     · 烟雾弹 1×1
     · 子弹 1×1，一格 60 发；同口径的没装满的弹盒会先被填满
     · 防弹衣 3×3（多出来的甲可以背在身上，坏一件换一件）
     · 枪和防弹盾牌照老规矩不占背包格
     · 子弹不再有「备弹上限 × 背包倍率」：能装多少完全由格子决定
     · 关卡数据里写 rules.bagInfinite 的，那一关的包无限大（老关卡物资太多时兜底）
   数据的唯一真相是 player.bagItems；player.meds / grenades / guns.smoke.mag / ammo
   都是 bagRebuild() 从它同步出来的影子计数，老代码（HUD、换弹、扔烟）照旧读这几个数。 */
const GRID_W = { med:1, ammo:1, smoke:1, armor:3, bag:2, thermal:1, key:1, nade:1, heatcell:1, attach:1, rare:2 };
const GRID_H = { med:1, ammo:1, smoke:1, armor:3, bag:3, thermal:2, key:1, nade:1, heatcell:1, attach:1, rare:1 };
const AMMO_PER_CELL = 60;
/* 每种口径一盒能装几发：火箭弹一发一盒（占 2×1 格，不叠） */
const AMMO_CELL_CAP = { pistol:60, shotgun:60, rifle:60, rocket:1 };
function ammoCellCap(t){ return AMMO_CELL_CAP[t] || AMMO_PER_CELL; }
function ammoCellSize(t){ return (t === 'rocket') ? { w:2, h:1 } : { w:1, h:1 }; }                       /* 一格装多少发 */
const BAG_SHAPE = { none:{w:0,h:0}, small:{w:2,h:5}, mid:{w:4,h:5}, big:{w:6,h:6} };   /* 10 / 20 / 36 格 */
const POCKET_COLS = 4, POCKET_ROWS = 1;         /* 身上自带口袋：4 格，背包丢光了它也还在 */
const BAG_NONE = { kind:'none', label:'（没穿背包）', slots:0, ammoK:1, look:'none' };
const BAG_BLOCK = { blocked:true };             /* 占位表里表示"这格根本不存在" */
const BAG_INF_W = 14, BAG_INF_H = 14;           /* 无限背包的绘制上限，别画到屏幕外 */
let _bagUid = 1;

function bagGridOn(){ return (typeof hasFeat === 'function') && hasFeat('bagGrid'); }
function bagInfinite(){
  const L = (typeof cur === 'function') ? cur() : null;
  return !!(L && L.rules && L.rules.bagInfinite);
}
function bagGridSize(){
  const kind = (player && player.bag && player.bag.kind) || 'none';
  const s = BAG_SHAPE[kind] || BAG_SHAPE.none;
  let bw = s.w, bh = s.h;
  const inf = bagInfinite() && bw > 0;
  if (inf){ bw = Math.max(BAG_INF_W, bw); bh = Math.max(BAG_INF_H, bh); }
  /* 布局：上面是背包区域（bw × bh），最下面一行是随身口袋（POCKET_COLS 格）。
     没穿背包时 bw/bh = 0，只剩口袋那 4 格。 */
  return { w: Math.max(bw, POCKET_COLS), h: bh + POCKET_ROWS, bw:bw, bh:bh,
           pw:POCKET_COLS, ph:POCKET_ROWS, cap: bw * bh + POCKET_COLS * POCKET_ROWS, inf:inf };
}
/* 某个坐标是不是真实存在的格子（没包的时候背包区是空的，只有口袋） */
function bagCellOk(x, y, g){
  g = g || bagGridSize();
  if (x < 0 || y < 0 || x >= g.w || y >= g.h) return false;
  if (y < g.bh) return x < g.bw;
  return y < g.bh + g.ph && x < g.pw;
}
function bagItems(){
  if (!player) return [];
  if (!Array.isArray(player.bagItems)) player.bagItems = [];
  /* 兜底：任何一条弹药没记口径就按手枪弹补上（否则它既不算进 HUD，也不会跟同类并盒） */
  for (const _it of player.bagItems){ if (_it && _it.k === 'ammo' && !_it.t) _it.t = 'pistol'; }
  return player.bagItems;
}
/* 占位表：occ[y][x] = 那格被哪件东西占着（null = 空）。except 用来算"把它自己挪走之后"。 */
function bagOcc(except){
  const g = bagGridSize();
  const occ = [];
  for (let y = 0; y < g.h; y++){
    const row = [];
    for (let x = 0; x < g.w; x++) row.push(bagCellOk(x, y, g) ? null : BAG_BLOCK);
    occ.push(row);
  }
  for (const it of bagItems()){
    if (it === except) continue;
    for (let j = 0; j < it.h; j++) for (let i = 0; i < it.w; i++){
      const xx = it.x + i, yy = it.y + j;
      if (yy >= 0 && yy < g.h && xx >= 0 && xx < g.w) occ[yy][xx] = it;
    }
  }
  return occ;
}
function bagFreeAt(occ, w, h, x, y){
  const g = bagGridSize();
  if (x < 0 || y < 0 || x + w > g.w || y + h > g.h) return false;
  /* 一件东西要么整个落在背包区，要么整个落在口袋行，不能横跨那条分界 */
  const inBag = (y + h <= g.bh && x + w <= g.bw);
  const inPocket = (y >= g.bh && y + h <= g.bh + g.ph && x + w <= g.pw);
  if (!inBag && !inPocket) return false;
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++){
    if (!bagCellOk(x + i, y + j, g)) return false;
    if (occ[y+j][x+i]) return false;
  }
  return true;
}
/* 从左上角开始找第一个放得下的地方 */
function bagSpot(w, h, except){
  const g = bagGridSize();
  const occ = bagOcc(except);
  for (let y = 0; y + h <= g.h; y++) for (let x = 0; x + w <= g.w; x++) if (bagFreeAt(occ, w, h, x, y)) return { x:x, y:y };
  return null;
}
function bagAddCell(k, extra){
  /* extra.w / extra.h 可以覆盖默认尺寸；弹药按口径自动定尺寸 —— 火箭弹是 2×1 的盒子，
     不这样兜底的话，调用方忘了传 w/h 就会把一发火箭弹塞进 1×1。 */
  let dw = GRID_W[k] || 1, dh = GRID_H[k] || 1;
  if (k === 'ammo'){
    const sz = ammoCellSize((extra && extra.t) || 'pistol');
    dw = sz.w; dh = sz.h;
  }
  const w = (extra && extra.w) || dw, h = (extra && extra.h) || dh;
  const baseRot = !!(extra && extra.w && extra.h && extra.rot);
  const explicit = extra && Number.isInteger(extra.x) && Number.isInteger(extra.y)
    ? { x:extra.x, y:extra.y } : null;
  const occ = explicit ? bagOcc(null) : null;
  // 拖回格子和读档可提供首选落点，但坐标和宽高必须通过同一次占格校验。
  const fits = (iw,ih) => explicit && bagFreeAt(occ,iw,ih,explicit.x,explicit.y);
  let iw=w, ih=h, turned=false;
  let spot=fits(w,h) ? explicit : null;
  if(!spot && w!==h && fits(h,w)){spot=explicit;iw=h;ih=w;turned=true;}
  if(!spot)spot=bagSpot(w,h,null);
  if(!spot && w!==h){
    spot=bagSpot(h,w,null);
    if(spot){iw=h;ih=w;turned=true;}
  }
  if(!spot)return null;
  // 先复制弹种、数量等元数据，最后写入校验过的占格，避免 extra.w/h 把旋转覆盖掉。
  const it={...extra,uid:_bagUid++,k,x:spot.x,y:spot.y,w:iw,h:ih};
  if(baseRot!==turned)it.rot=1;else delete it.rot;
  if(turned || !(extra && extra.w && extra.h))delete it.rotManual;
  bagItems().push(it);
  return it;
}
function bagRemoveItem(it){
  const arr = bagItems();
  const i = arr.indexOf(it);
  if (i < 0) return false;
  arr.splice(i, 1);
  return true;
}
function bagOfKind(k){ return bagItems().filter(i => i.k === k); }
function bagCountOf(k){ return bagOfKind(k).length; }

/* 影子计数：背包里有什么，HUD / 换弹 / 扔烟就读什么 */
/* med 的档位：可能是 'big' / 'small'，也可能是数字 1 / 0（抽奖奖品用数字） */
function medR(r){ return (r === 1 || r === 'big') ? 'big' : 'small'; }

function bagRebuild(){
  if (!player || !bagGridOn()) return;
  const meds = { small:0, big:0 };
  const ammo = { pistol:0, shotgun:0, rifle:0 };
  let sm = 0, keys = 0, nd = 0;
  for (const it of bagItems()){
    if (it.k === 'med'){ const _r = medR(it.r); meds[_r] = (meds[_r] || 0) + 1; }
    else if (it.k === 'smoke') sm++;
    else if (it.k === 'nade') nd++;
    else if (it.k === 'key') keys++;
    else if (it.k === 'ammo') ammo[it.t] = (ammo[it.t] || 0) + (it.n || 0);
  }
  player.meds = meds;
  player.grenades = sm;
  player.keys = keys;
  player.nades = nd;
  if (player.guns && player.guns.smoke) player.guns.smoke.mag = sm;
  player.ammo = ammo;
}

/* ---- 往里放 ---- */
function bagAddMed(r, q, du){
  if (!bagGridOn()) return false;
  /* du：剩余耐久 0~100（原来是"已打几段"，改成耐久后能按血量差精确计量） */
  const _du = Math.max(1, Math.min(100, (du === undefined || du === null) ? 100 : du));
  if (!bagAddCell('med', { r:medR(r), q: (q === undefined ? 0 : q), du: _du })) return false;
  bagRebuild(); return true;
}
function bagAddSmoke(n){
  if (!bagGridOn()) return false;
  let left = Math.max(1, n || 1);
  let added = 0;
  while (left-- > 0){ if (!bagAddCell('smoke', {})) break; added++; }
  if (added) bagRebuild();
  return added > 0;
}
function bagAddArmor(kind, hp, maxHp, q){
  if (!bagGridOn()) return null;
  const A = (typeof armorDef === 'function') ? armorDef(kind) : null;
  const it = bagAddCell('armor', {
    ak: kind || 'light',
    hp: (hp === undefined ? (A ? A.dur : 100) : hp),
    maxHp: (maxHp === undefined ? (A ? A.dur : 100) : maxHp),
    q: (q === undefined ? 0 : q)
  });
  if (it) bagRebuild();
  return it;
}
/* 子弹：先把同口径没装满的弹盒填满，再开新盒。返回真正塞进去的发数。 */
function bagAddAmmo(t, n){
  if (!bagGridOn()) return 0;
  t = t || 'pistol';                  /* 没写口径的一律当手枪弹，绝不能让子弹变成"不算数的孤儿" */
  n = Math.max(0, n | 0);
  let left = n;
  const cap = ammoCellCap(t), sz = ammoCellSize(t);
  for (const it of bagItems()){
    if (left <= 0) break;
    if (it.k !== 'ammo' || it.t !== t) continue;
    const room = cap - (it.n || 0);
    if (room <= 0) continue;
    const add = Math.min(room, left);
    it.n = (it.n || 0) + add; left -= add;
  }
  while (left > 0){
    const add = Math.min(cap, left);
    if (!bagAddCell('ammo', { t:t, n:add, w:sz.w, h:sz.h })) break;
    left -= add;
  }
  if (left !== n) bagRebuild();
  bagCompactAmmo();
  return n - left;
}
/* 同口径的子弹自动并盒：先把前面的盒子填满 60，剩下的空盒子删掉。
   换弹会从盒子里扣，扣完容易剩下一堆 20、35 之类的小半盒，看着像"没堆叠"。 */
function bagCompactAmmo(){
  if (!bagGridOn()) return 0;
  const byT = {};
  for (const it of bagItems()){
    if (it.k !== 'ammo' || it.manualStack) continue;  /* 玩家手动分开的弹盒保留各自的位置 */
    if (!it.t) it.t = 'pistol';          /* 漏了口径的弹盒按手枪弹归档，否则既不算进 HUD 也不会并盒 */
    (byT[it.t] || (byT[it.t] = [])).push(it);
  }
  let moved = 0;
  for (const t in byT){
    if (t === 'rocket') continue;        /* 火箭弹一发一盒，没有"半盒"可并 */
    const arr = byT[t];
    const _cap = ammoCellCap(t);
    for (let i = 0; i < arr.length; i++){
      const a = arr[i];
      if (!a || bagItems().indexOf(a) < 0) continue;
      let room = _cap - (a.n || 0);
      for (let j = i + 1; j < arr.length && room > 0; j++){
        const b = arr[j];
        if (!b || bagItems().indexOf(b) < 0) continue;
        const take = Math.min(room, b.n || 0);
        if (take <= 0) continue;
        a.n = (a.n || 0) + take; b.n = (b.n || 0) - take; room -= take; moved += take;
        if ((b.n || 0) <= 0) bagRemoveItem(b);
      }
    }
  }
  if (moved) bagRebuild();
  return moved;
}

/* ---- 往外拿 ---- */
/* 这颗药还剩多少耐久（0~100）：新数据是 du，老数据可能只有 part（打过几段） */
function medDuOf(it){
  if (!it) return 100;
  if (it.du != null) return Math.max(1, Math.min(100, it.du));
  if (it.part != null) return Math.max(1, Math.min(100, Math.round(100 * (1 - (it.part || 0) / 3))));
  return 100;
}
function bagTakeMed(r){
  if (!bagGridOn()) return false;
  const it = bagOfKind('med').find(i => medR(i.r) === medR(r));
  if (!it) return false;
  bagRemoveItem(it); bagRebuild(); return it;    /* 返回那一颗：用药时按它的品质算回血量 */
}
function bagTakeSmoke(){
  if (!bagGridOn()) return false;
  const it = bagOfKind('smoke')[0];
  if (!it) return false;
  bagRemoveItem(it); bagRebuild(); return true;
}
function bagTakeNade(){
  if (!bagGridOn()) return false;
  const it = bagOfKind('nade')[0];
  if (!it) return false;
  bagRemoveItem(it); bagRebuild(); return true;
}
function bagTakeAmmo(t, n){
  if (!bagGridOn()) return 0;
  n = Math.max(0, n | 0);
  let left = n;
  /* 先掏没装满的那盒，再掏满盒（跟现实里先拆半盒一样） */
  const boxes = bagOfKind('ammo').filter(i => i.t === t).sort((a, b) => (a.n || 0) - (b.n || 0));
  for (const it of boxes){
    if (left <= 0) break;
    const take = Math.min(it.n || 0, left);
    it.n = (it.n || 0) - take; left -= take;
    if (it.n <= 0) bagRemoveItem(it);
  }
  if (left !== n) bagRebuild();
  bagCompactAmmo();
  return n - left;
}
/* 换弹、逐发装填都走这里：ver2 直接改计数，ver3 从格子里拿 */
function spendAmmo(t, n){
  if (bagGridOn()) return bagTakeAmmo(t, n);
  if (!player.ammo) return 0;
  const cur = player.ammo[t] || 0;
  const take = Math.min(cur, Math.max(0, n | 0));
  player.ammo[t] = cur - take;
  return take;
}

/* ---- 丢到地上 ---- */
/* 把格子里的某件东西变成地上一件可捡的东西（不负责从背包里删） */
function bagLootFromItem(it){
  if (!player || !it) return null;
  const a = (typeof rand === 'function' ? rand(0, Math.PI*2) : Math.PI*0.5);
  const l = {
    x: player.x + Math.cos(a) * 22,
    y: player.y + Math.sin(a) * 22,
    taken:false, cool:0.9, killDrop:false, kind:it.k, dropped:true,
    autoT: 5      /* 自己丢的东西 5 秒内不自动捡回来，够玩家走开 */
  };
  if (it.q !== undefined) l.q = it.q;
  if (it.k === 'med'){ l.rarity = it.r || 'small'; l.du = medDuOf(it); }   /* 丢出去也要带着剩余耐久 */
  else if (it.k === 'ammo'){ l.ammo = it.t; l.n = it.n || 0; }
  else if (it.k === 'heatcell') l.n = it.n || 1;
  else if (it.k === 'thermal') Object.assign(l, thermalPower(it));
  else if (it.k === 'smoke') l.n = 1;
  else if (it.k === 'armor'){ l.armor = it.ak || 'light'; l.hp = it.hp; l.maxHp = it.maxHp; }
  else if (it.k === 'bag') l.bag = it.bk || it.bag || 'small';
  else if (it.k === 'key') l.gear = true;           /* 钥匙不算物资 */
  else if (it.k === 'attach'){ l.aid = it.aid; l.gear = true; }
  else if (it.k === 'rare') l.item = 'gold';
  if (typeof loots !== 'undefined' && loots){
    const _sp = (typeof lootSpot === 'function') ? lootSpot(l.x, l.y) : l;
    l.x = _sp.x; l.y = _sp.y;
    loots.push(l);
  }
  return l;
}
function bagDropItem(it){
  if (!player || !it) return false;
  if (!bagRemoveItem(it)) return false;
  bagLootFromItem(it);
  bagRebuild();
  return true;
}

/* 重新码包：换到更小的包 / 换包型之后，把东西按顺序重新塞进去，
   实在塞不下的掉在脚边（宁可掉地上，也不能像老版本那样凭空没了） */
function bagWearBag(it, take = bagRemoveItem){
  if (!it || it.k !== 'bag') return false;
  const kind = it.bk || 'small';
  const B = bagDef(kind);
  if (!B) return false;
  const oldKind = (player.bag && player.bag.kind) || 'small';
  if (oldKind === kind){ setMsg('身上就是这个背包', 1.2); return false; }
  const oldB = bagDef(oldKind) || bagDef('small');
  if (!take(it)) return false;
  equipBag(kind);                       /* 里面会按新包大小重新码放，塞不下的掉地上 */
  let note = '';
  const w = GRID_W.bag, h = GRID_H.bag;
  const spot = bagSpot(w, h, null);
  if (spot){
    bagItems().push({ uid:_bagUid++, k:'bag', bk:oldKind, x:spot.x, y:spot.y, w:w, h:h });
  } else {
    bagLootFromItem({ k:'bag', bk:oldKind });
    note = ' · ' + oldB.label + ' 放不下，丢在脚边';
  }
  bagRebuild();
  sfxPick();
  setMsg('换上 ' + B.label + '（' + B.slots + ' 格）' + note, 2.2);
  logInfo('item', '换背包 ' + B.label);
  return true;
}
function bagRefit(){
  if (!player || !bagGridOn()) return 0;
  const items = bagItems().slice();
  player.bagItems = [];
  let dropped = 0;
  for (const it of items){
    const spot = bagSpot(it.w, it.h, null);
    if (!spot){ bagLootFromItem(it); dropped++; continue; }
    it.x = spot.x; it.y = spot.y;
    player.bagItems.push(it);
  }
  bagRebuild();
  bagCompactAmmo();
  return dropped;
}

/* 开局：把这一关的随身物资摊进格子（药 / 烟 / 甲 / 子弹） */
function bagInitFromLoadout(){
  if (!bagGridOn()) return 0;
  if (!Array.isArray(player.bagItems)) player.bagItems = [];
  const meds = player.meds || {};
  const ammo = player.ammo || {};
  let smokes = player.grenades || 0;
  const spill = [];                       /* 装不下的：落在脚边，不能凭空消失 */
  player.bagItems = [];
  for (let i = 0; i < (meds.small || 0); i++) if (!bagAddCell('med', { r:'small' })) spill.push({ k:'med', r:'small' });
  for (let i = 0; i < (meds.big || 0); i++) if (!bagAddCell('med', { r:'big' })) spill.push({ k:'med', r:'big' });
  while (smokes-- > 0) if (!bagAddCell('smoke', {})) spill.push({ k:'smoke' });
  for (const t of (typeof AMMO_ORDER !== 'undefined' ? AMMO_ORDER : ['pistol','shotgun','rifle'])){
    let left = ammo[t] || 0;
    while (left > 0){
      const add = Math.min(AMMO_PER_CELL, left);
      if (!bagAddCell('ammo', { t:t, n:add })){ spill.push({ k:'ammo', t:t, n:left }); break; }
      left -= add;
    }
  }
  bagRebuild();
  for (const it of spill){
    const l = bagLootFromItem({ k:it.k, r:it.r, t:it.t, n:it.n });
    if (l){ l.x = player.x + rand(-26, 26); l.y = player.y + rand(-26, 26); }
  }
  if (spill.length) setMsg('背包塞不下，' + spill.length + ' 件物资掉在脚边', 2.4);
  return spill.length;
}

/* 防弹衣外观：一件真正的马甲（两肩 + 胸板 + 腰侧带），不是一圈光 */
/* 一件防弹衣的「皮肤」：玩家和敌人共用同一份绘制，别让两边长成两种东西。
   ring = 外圈细线（穿没穿一眼能看出来），plate = 胸前插板 + 两个胳膊洞，
   breakRing = 刚从身上碎掉那一瞬间的红圈。 */
function armorBodyTint(kind){
  const A = armorDef(kind) || ARMOR_DEF.light;
  return mixHex(A.pal, PAL.P33, 0.80);      /* 身体只留一层很淡的甲色 */
}
function drawArmorRing(x, y, r, kind, pct){
  const A = armorDef(kind) || ARMOR_DEF.light;
  ctx.save();
  ctx.globalAlpha = 0.40 * (0.55 + 0.45 * clamp(pct === undefined ? 1 : pct, 0, 1));
  ctx.strokeStyle = mixHex(A.pal, '#0e1318', 0.74);   /* 甲色压到夜色里，别像发光贴纸 */
  ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(x, y, r + 2.0, 0, TAU); ctx.stroke();
  ctx.restore();
}
function drawArmorPlate(x, y, r, ang, kind, pct){
  const A = armorDef(kind) || ARMOR_DEF.light;
  const _a = clamp(pct === undefined ? 1 : pct, 0, 1);
  /* 内侧一圈暗线，给身体一点「厚度」 */
  ctx.save();
  ctx.strokeStyle = 'rgba(10,15,20,0.55)'; ctx.lineWidth = 1.1;
  ctx.beginPath(); ctx.arc(x, y, r - 0.9, 0, TAU); ctx.stroke();
  ctx.restore();
  /* 胸前插板：压一块暗面 + 一条亮缝，像马甲上的插板槽而不是白方块 */
  ctx.save();
  ctx.globalAlpha = 0.55 + 0.45 * _a;
  ctx.translate(x, y); ctx.rotate(ang || 0);
  ctx.fillStyle = 'rgba(10,16,22,0.30)';
  roundRect(-r * 0.50, -r * 0.42, r * 1.00, r * 0.92, r * 0.24); ctx.fill();
  ctx.strokeStyle = 'rgba(226,238,248,0.16)'; ctx.lineWidth = 1;
  roundRect(-r * 0.50, -r * 0.42, r * 1.00, r * 0.92, r * 0.24); ctx.stroke();
  ctx.strokeStyle = 'rgba(8,13,18,0.45)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(-r * 0.34, r * 0.06); ctx.lineTo(r * 0.34, r * 0.06); ctx.stroke();
  ctx.restore();
  /* 两个胳膊洞（左右两侧的暗色缺口） */
  ctx.save();
  ctx.globalAlpha = 0.9;
  ctx.translate(x, y); ctx.rotate(ang || 0);
  ctx.fillStyle = 'rgba(9,13,17,0.42)';
  roundRect(-r * 0.30, -r * 0.98, r * 0.60, r * 0.30, r * 0.12); ctx.fill();
  roundRect(-r * 0.30,  r * 0.68, r * 0.60, r * 0.30, r * 0.12); ctx.fill();
  ctx.restore();
}
function drawArmorBreakRing(x, y, r, t){
  ctx.save();
  ctx.strokeStyle = 'rgba(232,58,40,' + (0.9 * t).toFixed(2) + ')';
  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(x, y, r + 4 + (1 - t) * 14, 0, TAU); ctx.stroke();
  ctx.restore();
}
function drawVestShape(x, y, s, pal, fg, alpha){
  ctx.save();
  ctx.globalAlpha = alpha === undefined ? 1 : alpha;
  ctx.translate(x, y);
  ctx.scale(s, s);
  /* 两肩 */
  ctx.fillStyle = pal;
  roundRect(-8.6, -9.4, 5.4, 7.6, 2.2); ctx.fill();
  roundRect(3.2, -9.4, 5.4, 7.6, 2.2); ctx.fill();
  /* 躯干：上宽下窄的板子 */
  ctx.beginPath();
  ctx.moveTo(-7.6, -7.4);
  ctx.lineTo(7.6, -7.4);
  ctx.lineTo(6.2, 8.4);
  ctx.lineTo(-6.2, 8.4);
  ctx.closePath();
  ctx.fill();
  /* 领口内凹 */
  ctx.fillStyle = 'rgba(10,14,18,0.85)';
  ctx.beginPath();
  ctx.moveTo(-2.6, -7.4); ctx.lineTo(2.6, -7.4); ctx.lineTo(0, -3.6);
  ctx.closePath(); ctx.fill();
  /* 胸板缝 + 腰侧带 */
  ctx.strokeStyle = fg;
  ctx.lineWidth = 1.05;
  ctx.beginPath();
  ctx.moveTo(-5.4, 1.6); ctx.lineTo(5.4, 1.6);
  ctx.moveTo(-7.0, -3.4); ctx.lineTo(7.0, -3.4);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(10,14,18,0.7)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(-6.6, 5.0); ctx.lineTo(6.6, 5.0);
  ctx.stroke();
  ctx.restore();
}
/* 背包图标：三种包型，同一个配色，只差大小和兜 */
function drawBagShape(x, y, kind, alpha){
  const B = bagDef(kind) || { look:'pouch' };
  /* 三种包各自一套"布料"色，一眼能分大小 */
  const skin = (B.look === 'pouch')  ? { body:'#4f6656', lid:'#3c5044', trim:'#8fb99b', strap:'#2c3a31' }
             : (B.look === 'pack')   ? { body:'#6b5a41', lid:'#52452f', trim:'#c2ab84', strap:'#3a3023' }
             :                        { body:'#5c4a3c', lid:'#443329', trim:'#cbb1a0', strap:'#33251d' };
  const s = (B.look === 'pouch') ? 0.82 : (B.look === 'pack') ? 1.0 : 1.18;
  ctx.save();
  ctx.globalAlpha = alpha === undefined ? 1 : alpha;
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.lineJoin = 'round';

  /* 肩带：从包体两侧往外下面伸出去，这是"背包"最好认的特征 */
  ctx.fillStyle = skin.strap;
  ctx.beginPath();
  ctx.moveTo(-7.4, 2.2); ctx.lineTo(-4.4, 3.4); ctx.lineTo(-5.6, 9.6); ctx.lineTo(-9.2, 9.2);
  ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(7.4, 2.2); ctx.lineTo(4.4, 3.4); ctx.lineTo(5.6, 9.6); ctx.lineTo(9.2, 9.2);
  ctx.closePath(); ctx.fill();

  /* 包体 */
  ctx.fillStyle = skin.body;
  roundRect(-8, -8.4, 16, 16.4, 4.2); ctx.fill();
  /* 顶盖（拉链/翻盖的那块深色） */
  ctx.fillStyle = skin.lid;
  roundRect(-8, -8.4, 16, 6.2, 4.2); ctx.fill();
  /* 顶部提手 */
  ctx.strokeStyle = skin.strap; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.arc(0, -8.6, 3.2, Math.PI * 1.08, Math.PI * 1.92); ctx.stroke();
  ctx.lineCap = 'butt';
  /* 前袋 */
  ctx.fillStyle = skin.lid;
  roundRect(-5.2, 0.6, 10.4, 5.6, 2); ctx.fill();
  ctx.strokeStyle = skin.trim; ctx.lineWidth = 0.9;
  roundRect(-5.2, 0.6, 10.4, 5.6, 2); ctx.stroke();
  /* 两条扣带 + 黄铜扣 */
  ctx.fillStyle = skin.trim;
  roundRect(-6.4, -2.6, 2.2, 4.2, 1); ctx.fill();
  roundRect(4.2, -2.6, 2.2, 4.2, 1); ctx.fill();
  ctx.fillStyle = '#d9b25c';
  roundRect(-6.2, -1.2, 1.8, 1.8, 0.6); ctx.fill();
  roundRect(4.4, -1.2, 1.8, 1.8, 0.6); ctx.fill();
  /* 外轮廓 */
  ctx.strokeStyle = skin.trim; ctx.lineWidth = 1.0;
  roundRect(-8, -8.4, 16, 16.4, 4.2); ctx.stroke();
  ctx.restore();
}

/* 防弹盾牌耐久：挡一发扣"这一发伤害的一半"，600 点大约能扛 15~20 发步枪弹。
   归零直接碎掉（不在地上留残骸），所以举盾是一个会被消耗掉的选择。 */
const SHIELD_MAX_HP = 600;

/* 热成像：单目热像仪。镜头那圈橙黄是它唯一的"亮点"，
   小到 20px 也能一眼认出这是台电子设备而不是药或者弹匣。 */
/* 万能钥匙：一把铜色的老式钥匙（圆环 + 杆 + 两个齿）。
   1×1 的小格子里也要一眼能认出来，所以整体偏粗、颜色偏亮。 */
/* 热成像电池：一节方头电池（正极两个小凸点 + 中间一道电量窗 + 闪电标）。
   n 是这一格里叠了几颗，>1 时右上角画 ×N。 */
function drawHeatCellIcon(x, y, s, n){
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  /* 正极凸点 */
  ctx.fillStyle = 'rgb(196,204,214)';
  ctx.fillRect(-2.0, -8.6, 1.6, 1.8);
  ctx.fillRect(0.4, -8.6, 1.6, 1.8);
  /* 电池身 */
  ctx.fillStyle = 'rgb(54,66,78)';
  roundRect(-4.6, -6.8, 9.2, 14.6, 1.8); ctx.fill();
  ctx.strokeStyle = 'rgba(10,14,18,0.95)'; ctx.lineWidth = 1.0;
  roundRect(-4.6, -6.8, 9.2, 14.6, 1.8); ctx.stroke();
  /* 电量窗（暖黄，和热成像同一个色系） */
  ctx.fillStyle = 'rgba(255,168,72,0.95)';
  roundRect(-1.5, -4.6, 3.0, 10.2, 1.0); ctx.fill();
  /* 闪电 */
  ctx.fillStyle = 'rgba(28,20,8,0.9)';
  ctx.beginPath();
  ctx.moveTo(0.5, -3.4); ctx.lineTo(-1.1, 0.1); ctx.lineTo(0.1, 0.1);
  ctx.lineTo(-0.6, 3.4); ctx.lineTo(1.2, -0.4); ctx.lineTo(0.0, -0.4);
  ctx.closePath(); ctx.fill();
  /* 叠了几颗 */
  if (n > 1){
    ctx.fillStyle = 'rgba(255,236,200,0.96)';
    ctx.font = '600 6.5px system-ui, sans-serif';
    ctx.textAlign = 'right'; ctx.textBaseline = 'top';
    ctx.fillText('x' + n, 5.4, -8.8);
  }
  ctx.restore();
}

function drawKeyIcon(x, y, s){
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.rotate(-0.35);
  /* 杆 */
  ctx.fillStyle = 'rgb(228,180,78)';
  roundRect(-1.7, -2.6, 3.4, 13.6, 1.5); ctx.fill();
  /* 齿：一长一短，方向朝右 */
  ctx.fillStyle = 'rgb(214,164,64)';
  ctx.fillRect(1.3, 4.6, 4.8, 2.8);
  ctx.fillRect(1.3, 8.8, 3.6, 2.6);
  /* 钥匙环 */
  ctx.strokeStyle = 'rgb(228,180,78)'; ctx.lineWidth = 3.6;
  ctx.beginPath(); ctx.arc(0, -5.4, 4.8, 0, TAU); ctx.stroke();
  /* 环上的一点高光 + 一圈暗边，不然在一片深色里会显平 */
  ctx.strokeStyle = 'rgba(255,238,186,0.95)'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.arc(0, -5.4, 4.7, -2.35, -0.55); ctx.stroke();
  ctx.strokeStyle = 'rgba(120,84,20,0.85)'; ctx.lineWidth = 0.9;
  ctx.beginPath(); ctx.arc(0, -5.4, 6.5, 0, TAU); ctx.stroke();
  ctx.restore();
}

function drawThermalIcon(x, y, s){
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  /* 机身 */
  ctx.fillStyle = 'rgba(46,52,60,0.98)';
  roundRect(-7, -11, 14, 22, 4); ctx.fill();
  ctx.strokeStyle = 'rgba(12,16,20,0.92)'; ctx.lineWidth = 1.2;
  roundRect(-7, -11, 14, 22, 4); ctx.stroke();
  /* 机身上的两道分模线 */
  ctx.strokeStyle = 'rgba(96,108,122,0.55)'; ctx.lineWidth = 0.9;
  ctx.beginPath(); ctx.moveTo(-6, 1.2); ctx.lineTo(6, 1.2); ctx.stroke();
  /* 镜头 */
  ctx.fillStyle = 'rgba(16,20,24,0.95)';
  ctx.beginPath(); ctx.arc(0, -4.6, 4.8, 0, TAU); ctx.fill();
  const g1 = ctx.createRadialGradient(0, -4.6, 0.6, 0, -4.6, 4.4);
  g1.addColorStop(0, 'rgba(255,240,182,0.98)');
  g1.addColorStop(0.5, 'rgba(255,156,64,0.96)');
  g1.addColorStop(1, 'rgba(186,58,20,0.92)');
  ctx.fillStyle = g1;
  ctx.beginPath(); ctx.arc(0, -4.6, 3.5, 0, TAU); ctx.fill();
  /* 目镜 */
  ctx.fillStyle = 'rgba(28,32,38,0.98)';
  roundRect(-4.4, 2.4, 8.8, 4.8, 2); ctx.fill();
  /* 侧面挂带 */
  ctx.strokeStyle = 'rgba(122,134,148,0.85)'; ctx.lineWidth = 1.1;
  ctx.beginPath(); ctx.moveTo(-6.4, -1.0); ctx.lineTo(-7.6, 2.2); ctx.lineTo(-6.0, 5.6); ctx.stroke();
  ctx.restore();
}

/* 枪口配件的小图标：一截带缩口的枪管。
   三款要能一眼分开：标准=灰管；紧束=深色短管多一道环、口收得最死；
   长管=明显更长、带散热孔和散热片。 */
/* 配件图标：按数据表里的 icon 字段分发，加新画法只要在 ATTACH_ICON 里加一条 */
function drawMagIcon(x, y, s, d){
  {
    const m = (d && d.mods) || {};
    const ext = !!m.magCap;                       /* 扩容：容量越大匣体越长 */
    const cap = m.magCap || 0;
    const h = ext ? (cap >= 40 ? 17 : cap >= 35 ? 13 : 9) : 11;
    const w = 9;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(s, s);
    ctx.rotate(-0.16);
    /* 匣体（下宽上窄，像真弹匣） */
    ctx.fillStyle = ext ? '#5d6a78' : '#6e5a44';
    ctx.beginPath();
    ctx.moveTo(-w / 2, -h / 2);
    ctx.lineTo(w / 2, -h / 2 + 1.2);
    ctx.lineTo(w / 2 + 0.8, h / 2);
    ctx.lineTo(-w / 2 - 0.8, h / 2);
    ctx.closePath(); ctx.fill();
    /* 抱弹口 */
    ctx.fillStyle = '#c8a35a';
    ctx.fillRect(-w / 2 - 0.6, -h / 2 - 2.2, w + 1.2, 3.0);
    /* 加强筋 */
    ctx.fillStyle = 'rgba(20,26,32,0.55)';
    const _ribs = h >= 15 ? 4 : 3;
    for (let i = 0; i < _ribs; i++) ctx.fillRect(-w / 2 + 1, -h / 2 + 3.2 + i * (h - 5.4) / _ribs, w - 2, 1.1);
    if (ext){
      /* 扩容：底部一块加长块 */
      ctx.fillStyle = '#3b4653';
      ctx.fillRect(-w / 2 - 1, h / 2 - 3.0, w + 2, 4.0);
    } else {
      /* 快速：侧面一道闪电 */
      ctx.fillStyle = '#e8c46a';
      ctx.beginPath();
      ctx.moveTo(0.6, -3.4); ctx.lineTo(-2.6, 0.6); ctx.lineTo(-0.4, 0.6);
      ctx.lineTo(-1.4, 4.2); ctx.lineTo(2.4, -0.2); ctx.lineTo(0.2, -0.2);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }
}
function drawChokeIcon(x, y, s, d){
  const tight = d && d.mods && d.mods.spreadK ? clamp(d.mods.spreadK, 0.5, 1) : 1;
  const isLong = !!(d && d.mods && d.mods.dmgK);          /* 长管那款额外掉伤害 */
  const isTight = !isLong && tight <= 0.7;                /* 紧束那款 */
  const len = isLong ? 25 : (isTight ? 16 : 19);
  const body = isLong ? '#59636f' : (isTight ? '#454e59' : '#6b7686');
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.rotate(-0.18);
  /* 管身 */
  ctx.fillStyle = body;
  ctx.fillRect(-12, -4.5, len, 9);
  /* 加强环 */
  ctx.fillStyle = '#3a424c';
  ctx.fillRect(-6, -4.5, 2, 9);
  ctx.fillRect(2, -4.5, 2, 9);
  if (isTight) ctx.fillRect(-1, -4.5, 3, 9);              /* 紧束多一道 */
  if (isLong){
    /* 长管：三道散热孔 + 前段一圈散热片 */
    ctx.fillStyle = 'rgba(20,24,30,0.75)';
    for (let i = 0; i < 3; i++) ctx.fillRect(-3 + i * 4, -2.4, 2, 4.8);
    ctx.fillStyle = '#2f3740';
    ctx.fillRect(6, -6, 3, 12);
  }
  /* 缩口（越紧越细）+ 黄铜口 */
  const mw = 3.4 + tight * 4.6;
  ctx.fillStyle = isTight ? '#d8b988' : '#c8a35a';
  ctx.beginPath();
  ctx.moveTo(-12 + len, -4.5); ctx.lineTo(-12 + len + 6, -mw / 2); ctx.lineTo(-12 + len + 6, mw / 2); ctx.lineTo(-12 + len, 4.5);
  ctx.closePath(); ctx.fill();
  /* 口里那一圈（越紧看着越实心） */
  ctx.fillStyle = 'rgba(14,18,24,0.9)';
  ctx.beginPath(); ctx.ellipse(-12 + len + 5.4, 0, 0.9, mw / 2 - 0.6, 0, 0, TAU); ctx.fill();
  /* 尾部的卡箍 */
  ctx.fillStyle = '#3c444f';
  ctx.fillRect(-12, -6, 3, 12);
  ctx.strokeStyle = 'rgba(0,0,0,0.55)'; ctx.lineWidth = 1;
  ctx.strokeRect(-12, -4.5, len, 9);
  ctx.restore();
}
var ATTACH_ICON = { mag: drawMagIcon, choke: drawChokeIcon };
function drawAttachIcon(x, y, s, aid){
  const d = (typeof attachDef === 'function') ? attachDef(aid) : null;
  const kind = (typeof attachIconKind === 'function') ? attachIconKind(aid) : 'choke';
  const R = ATTACH_ICON[kind] || ATTACH_ICON.choke;
  R(x, y, s, d);
}

const LOOT_KINDS = {
  /* 情报：只有从抽奖商人手里换来，捡起来才知道黑匣子"大概在哪一片"。
     画成一份牛皮纸档案袋 + 红戳，跟黑匣子的黑方块、武器的长条都不一样。 */
  intel: {
    take(l){
      player.hasIntel = true;
      sfxPick();
      setMsg('拿到情报 · 地图上标出了黑匣子所在的区域（按 M 看）', 4.0);
      if (typeof logInfo === 'function') logInfo('dz', '拿到情报 · 黑匣子在 ' + (typeof dzBoxTag === 'string' ? dzBoxTag : '未知区域'));
      return true;
    },
    draw(x,y){
      ctx.save();
      ctx.translate(x,y);
      ctx.rotate(-0.12);
      ctx.fillStyle = '#c9a06a';
      ctx.fillRect(-8,-9,16,18);
      ctx.fillStyle = '#b08a56';
      ctx.fillRect(-8,-9,16,4);
      ctx.strokeStyle = 'rgba(30,22,14,0.85)'; ctx.lineWidth = 1.4;
      ctx.strokeRect(-8,-9,16,18);
      ctx.fillStyle = 'rgba(198,54,44,0.92)';
      ctx.beginPath(); ctx.arc(3.5,3,3.6,0,TAU); ctx.fill();
      ctx.fillStyle = 'rgba(240,220,200,0.9)';
      ctx.fillRect(-6,-3,9,1.4); ctx.fillRect(-6,0,9,1.4);
      ctx.restore();
    }
  },
  /* 死亡地带的目标物：搜到它，撤离点才亮。不是物资，捡起来不占背包。 */
  blackbox: {
    take(l){
      if (dzLvl && !dzLvl.dzBox){
        dzLvl.dzBox = true;
        dzRevealExtract(dzLvl);
        sfxPick();
        setMsg('拿到黑匣子 · 撤离点已经亮了，往地图边缘跑', 4.2);
        logWarn('dz', '拿到黑匣子 · 撤离点 ' + Math.round(dzLvl.extract.x) + ',' + Math.round(dzLvl.extract.y));
      }
      return true;
    },
    draw(x, y, l){
      /* 飞行记录仪：橙色装甲盒 + 黑色加强箍 + 白色反光条 + 提手 + 慢闪指示灯。
         它不是物资，地上给它一圈琥珀光，暗图里也能看见（不然玩家只会以为是小箱子）。 */
      const _t = (typeof uiT === 'number') ? uiT : 0;
      ctx.save();
      ctx.translate(x, y);
      /* 地面光圈 */
      const _g = 0.34 + 0.20 * Math.sin(_t * 2.4);
      const _grd = ctx.createRadialGradient(0, 0, 2, 0, 0, 20);
      _grd.addColorStop(0, 'rgba(255,168,64,' + (0.30 + _g * 0.22).toFixed(3) + ')');
      _grd.addColorStop(0.55, 'rgba(255,140,40,' + (_g * 0.30).toFixed(3) + ')');
      _grd.addColorStop(1, 'rgba(255,120,30,0)');
      ctx.fillStyle = _grd;
      ctx.beginPath(); ctx.arc(0, 0, 20, 0, TAU); ctx.fill();
      /* 提手（后面那侧） */
      ctx.strokeStyle = 'rgba(30,20,14,0.95)';
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(0, -8.6, 4.2, Math.PI * 1.08, Math.PI * 1.92);
      ctx.stroke();
      /* 盒体：橙红装甲，圆角 + 深色描边 */
      const bw = 17, bh = 12.5;
      ctx.beginPath(); ctx.roundRect(-bw / 2, -bh / 2, bw, bh, 3.2);
      const _bg = ctx.createLinearGradient(0, -bh / 2, 0, bh / 2);
      _bg.addColorStop(0, '#ff8a3d');
      _bg.addColorStop(0.55, '#e8621f');
      _bg.addColorStop(1, '#b8410f');
      ctx.fillStyle = _bg; ctx.fill();
      ctx.strokeStyle = 'rgba(28,16,10,0.92)'; ctx.lineWidth = 1.6; ctx.stroke();
      /* 两道黑色加强箍 */
      ctx.fillStyle = 'rgba(26,18,14,0.88)';
      ctx.fillRect(-bw / 2 + 2.4, -bh / 2, 2.0, bh);
      ctx.fillRect(bw / 2 - 4.4, -bh / 2, 2.0, bh);
      /* 白色反光条（上表面） */
      ctx.fillStyle = 'rgba(248,240,226,0.92)';
      ctx.fillRect(-bw / 2 + 5.6, -bh / 2 + 2.0, bw - 11.2, 2.2);
      /* 侧面格栅 */
      ctx.fillStyle = 'rgba(24,14,8,0.55)';
      for (let i = 0; i < 3; i++) ctx.fillRect(-3.2 + i * 2.6, 1.4, 1.4, 3.4);
      /* 指示灯：慢闪 */
      const _led = 0.45 + 0.55 * Math.max(0, Math.sin(_t * 4.2));
      ctx.fillStyle = 'rgba(120,255,150,' + _led.toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(-bw / 2 + 4.0, -bh / 2 + 5.8, 1.5, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(10,40,16,0.8)'; ctx.lineWidth = 0.8; ctx.stroke();
      ctx.restore();
    }
  },
  shield: {
    take(l){
      player.hasShield=true;player.shieldRaised=true;mouse.fire=false;mouse.down=false;
      /* 盾牌自己有耐久；地上那面带着剩余耐久（丢下再捡回来不会白修） */
      player.shieldMaxHp = SHIELD_MAX_HP;
      player.shieldHp = (l && typeof l.shieldHp === 'number') ? clamp(l.shieldHp, 0, SHIELD_MAX_HP) : SHIELD_MAX_HP;
      sfxPick();setMsg('拿起防弹盾牌 · 耐久 ' + Math.round(player.shieldHp) + ' / ' + SHIELD_MAX_HP +
        ' · 鼠标控制朝向 · G 收盾 / 举盾 · Q 切枪',3);
      return true;
    },
    draw(x,y){drawShieldIcon(x, y, 1.0)}
  },
  attach: {
    take(l){
      const d = attachDef(l.aid);
      if (!d) return false;
      if (!bagGridOn()){ sfxPick(); setMsg('捡到 ' + d.name + '（' + d.desc + '）', 2.4); logInfo('item', '捡起 ' + d.name); return true; }
      if (!bagAddCell('attach', { aid: d.id })){ setMsg('背包放不下配件（要 1×1 空格）', 1.7); return false; }
      bagRebuild();
      sfxPick();
      setMsg('捡到 ' + d.name + ' · 拖到武器栏那行 = 装上', 2.6);
      logInfo('item', '捡起 ' + d.name + '（进背包）');
      return true;
    },
    draw(x, y, l){ drawAttachIcon(x, y, 1.1, (l && l.aid) || null); }
  },
  nade: {
    take(l){
      /* 手雷：一颗占一格，不叠加 —— 捡一颗就是背包里多一个 1×1 */
      if (!bagGridOn()){
        player.nades = (player.nades || 0) + 1;
        if (!(typeof sfxGrenadeTake === 'function' && sfxGrenadeTake())) sfxPick();
        setMsg('捡到手雷 · 按 3 拿在手里 · 按住左键掐引信', 2.6);
        logInfo('item', '捡起手雷');
        return true;
      }
      if (!bagAddCell('nade', {})){
        setMsg('背包放不下手雷（要 1×1 空格）', 1.7);
        return false;
      }
      bagRebuild();
      if (!(typeof sfxGrenadeTake === 'function' && sfxGrenadeTake())) sfxPick();
      setMsg('捡到手雷 · 按 3 拿在手里 · 按住左键掐引信', 2.6);
      logInfo('item', '捡起手雷（进背包）');
      return true;
    },
    draw(x, y){ drawNadeModel(x, y, 1.15, 0, false); }
  },
  key: {
    take(l){
      /* 钥匙算"装备"：进包占 1×1，拿在身上就能开所有锁着的门（不消耗） */
      if (!bagGridOn()){
        player.keys = (player.keys || 0) + 1;
        setMsg('捡到万能钥匙 · 走到锁着的门边按 E 开锁', 2.6);
        logInfo('item', '捡起万能钥匙');
        return true;
      }
      if (!bagAddCell('key', {})){
        setMsg('背包放不下万能钥匙（要 1×1 空格）', 1.7);
        return false;
      }
      bagRebuild();
      setMsg('捡到万能钥匙 · 走到锁着的门边按 E 开锁', 2.6);
      logInfo('item', '捡起万能钥匙（进背包）');
      return true;
    },
    draw(x, y){ drawKeyIcon(x, y, 1.35); }
  },
  heatcell: {
    take(l){
      /* 进背包：一格最多叠 4 颗 */
      const n = Math.max(1, (l && l.n) | 0 || 1);
      const got = heatCellAdd(n);
      if (!got){
        setMsg('背包放不下热成像电池（要 1×1 空格）', 1.7);
        return false;
      }
      sfxPick();
      setMsg('捡到热成像电池 ×' + got + ' · 打开背包点一下格子就能充', 2.6);
      logInfo('item', '捡起热成像电池 ×' + got + '（现在共 ' + heatCellLeft() + ' 颗）');
      return true;
    },
    draw(x, y, l){ drawHeatCellIcon(x, y, 1.0, (l && l.n) || 1); }
  },
  thermal: {
    take(l){
      /* ver3：热成像是"一件装备"，捡起来先进包，想戴就拖到左边的热成像栏 */
      if (!bagGridOn()){
        if (player.heatWorn) return false;
        thermalSetWorn(thermalPower(l));
        sfxPick();
        setMsg('捡到热成像 · 空格开机（随时可以关）', 2.2);
        logInfo('item', '捡起热成像');
        return true;
      }
      if (!bagAddCell('thermal', thermalPower(l))){
        setMsg('背包放不下热成像（要 1×2 空格）', 1.7);
        return false;
      }
      sfxPick();
      setMsg('捡到热成像 · 打开背包拖到「热成像」栏戴上', 2.6);
      logInfo('item', '捡起热成像（进背包）');
      return true;
    },
    draw(x, y){ drawThermalIcon(x, y, 1.0); }
  },
  armor: {
    take(l){
      const k = l.armor || 'light';
      const A = armorDef(k);
      if (!A) return false;
      /* ver3：甲也是物体了 —— 身上空的就穿上，身上有就收进包里（3×3），
         等身上那件打烂了随时换，不会像以前那样"捡第二件什么都没发生" */
      if (bagGridOn()){
        const _q = qualityRollFor(l, l.qBias || 0), _qk = qualityK(_q);
        const hp = Math.min(Math.round((l.maxHp === undefined ? A.dur : l.maxHp) * _qk),
                            Math.round((l.hp === undefined ? A.dur : l.hp) * _qk));
        const maxHp = Math.round((l.maxHp === undefined ? A.dur : l.maxHp) * _qk);
        if (!player.armor){
          player.armor = { kind:k, label:A.label, hp:hp, maxHp:maxHp, reduce:A.reduce, q:_q };
          if (!(typeof sfxArmorWear === 'function' && sfxArmorWear())) sfxPick();
          setMsg('捡到 ' + qualityPrefix(_q) + A.label + ' · 减伤 ' + Math.round(A.reduce*100) + '% · 耐久 ' + Math.round(hp), 1.9);
          logInfo('item', '捡起 ' + A.label);
          return true;
        }
        /* 身上那件更好/一样好 → 收进包；比身上那件好 → 直接换上，旧的那件塞包里 */
        if (A.reduce > player.armor.reduce){
          const old = player.armor;
          player.armor = { kind:k, label:A.label, hp:hp, maxHp:maxHp, reduce:A.reduce, q:_q };
          const put = bagAddArmor(old.kind, old.hp, old.maxHp, old.q);
          if (!put) bagLootFromItem({ k:'armor', ak:old.kind, hp:old.hp, maxHp:old.maxHp, q:old.q });
          if (!(typeof sfxArmorWear === 'function' && sfxArmorWear())) sfxPick();
          setMsg('换上 ' + qualityPrefix(_q) + A.label + ' · 减伤 ' + Math.round(A.reduce*100) + '%' + (put ? ' · 旧的收进背包' : ' · 旧的放在脚边'), 2.1);
          logInfo('item', '换上 ' + A.label);
          return true;
        }
        if (!bagAddArmor(k, hp, maxHp, _q)){
          setMsg('背包放不下防弹衣（要 3×3 空格）', 1.5);
          return false;
        }
        if (!(typeof sfxArmorTake === 'function' && sfxArmorTake())) sfxPick();
        setMsg('把 ' + qualityPrefix(_q) + A.label + ' 收进背包 · 身上那件坏了就换上', 2.0);
        logInfo('item', '收进背包 ' + A.label + '（' + bagUsed() + '/' + bagGridSize().cap + ' 格）');
        return true;
      }
      const cur = player.armor;
      const _q0 = qualityRollFor(l, l.qBias || 0);
      /* 甲还半新的时候不换；碎了或者没有才捡 */
      if (cur && cur.hp > cur.maxHp * 0.25 && cur.reduce >= A.reduce) return false;
      if (!(typeof sfxArmorWear === 'function' && sfxArmorWear())) sfxPick();
      player.armor = { kind:k, label:A.label, hp:A.dur, maxHp:A.dur, reduce:A.reduce, q:_q0 };
      setMsg('捡到 ' + qualityPrefix(_q0) + A.label + ' · 减伤 ' + Math.round(A.reduce*100) + '% · 耐久 ' + A.dur, 1.9);
      logInfo('item', '捡起 ' + A.label);
      return true;
    },
    draw(x, y, l){
      const A = armorDef(l.armor || 'light') || ARMOR_DEF.light;
      /* 一件马甲：两肩 + 胸板 + 腰侧带，不是一块方砖 */
      drawVestShape(x, y + 0.5, 1.0, A.pal, A.fg, 1);
    }
  },
  bag: {
    take(l){
      const k = l.bag || 'small';
      const B = bagDef(k);
      if (!B) return false;
      /* ver3：背包也是"一件东西"，先进格子（2×3）；想穿就拖到左边的「背包」栏。
         以前是"只能捡更大的、捡到就自动穿"，玩家没法退回小包。 */
      if (bagGridOn()){
        /* 更大的包 = 直接换上（身上那个塞回格子，塞不下掉脚边）；不比身上的大就收进格子 */
        const curSlots = (player.bag && (BAG_SHAPE[player.bag.kind] || BAG_SHAPE.none)) ? BAG_SHAPE[player.bag.kind].w * BAG_SHAPE[player.bag.kind].h : 0;
        if (B.slots > curSlots){
          const oldKind = (player.bag && player.bag.kind) || 'none';
          equipBag(k);
          let put = null;
          if (oldKind !== 'none') put = bagAddCell('bag', { bk:oldKind });
          if (oldKind !== 'none' && !put) bagLootFromItem({ k:'bag', bk:oldKind });
          bagRebuild();
          sfxPick();
          setMsg('换上 ' + B.label + ' · 随身 ' + (bagGridSize().cap - POCKET_COLS * POCKET_ROWS) + ' 格' + (oldKind === 'none' ? '' : (put ? ' · 旧的收进背包' : ' · 旧的放在脚边')), 2.2);
          logInfo('item', '换上 ' + B.label);
          return true;
        }
        if (bagAddCell('bag', { bk:k })){ bagRebuild(); setMsg('把 ' + B.label + ' 收进背包 · 拖到左边的背包栏就能换上', 2.0); return true; }
        setMsg('背包放不下另一个背包（要 ' + GRID_W.bag + '×' + GRID_H.bag + ' 格）', 1.9);
        return false;
      }
      const cur = player.bag;
      /* 老机制（ver2）只有更大的才捡，别把远征包换成小口袋 */
      if (cur && (bagDef(cur.kind) || { slots:0 }).slots >= B.slots) return false;
      return equipBag(k);
    },
    draw(x, y, l){
      drawBagShape(x, y + 0.5, l.bag || 'small', 1);
    }
  },
  smoke: {
    take(l){
      if (!hasFeat('guns')) return false;
      const n = l.n || 1;
      /* ver3：一颗烟一格，不再是"武器槽里的一个数字" */
      if (bagGridOn()){
        if (!bagAddSmoke(n)){ setMsg('背包满了，烟塞不进去', 1.4); return false; }
        sfxPick();
        setMsg('捡到 烟雾弹 ×' + n + ' · 背包里 ' + player.grenades + ' 颗', 1.6);
        logInfo('loot', '捡起 烟雾弹 ×' + n + '，现在 ' + player.grenades);
        return true;
      }
      /* 枪是拿在手上的，不算占背包格（不然逃跑关一开就背不动枪） */
      const bag = player.guns || (player.guns = {});
      if (!bag.smoke) bag.smoke = makeGun('smoke', 0);
      bag.smoke.mag = Math.min(9, bag.smoke.mag + n);
      player.grenades = Math.min(9, (player.grenades || 0) + n);
      sfxPick();
      setMsg('捡到 烟雾弹 ×' + n, 1.4);
      logInfo('loot', '捡起 烟雾弹 ×' + n + '，现在 ' + bag.smoke.mag);
      return true;
    },
    draw(x, y, l){ drawLootSmoke(x, y); }
  },
  gun: {
    take(l){
      if (!hasFeat('guns')) return false;
      const _gw = l.wid || 'pistol';
      const _gc = gunClass(_gw);
      /* 同型号也能再拿一把（两把 RPG 是允许的）：实例 key 由 gunNewKey 分配 */
      /* 武器栏满了（ver3）：把手里那把同类枪换下来，旧枪丢回脚边。
         规则：副武器栏满 → 换副武器；主武器两格都满 → 优先换手里正拿着的那把主武器，
         手里拿的是副武器/烟雾时就换主武器 1。 */
      let _swap = null;
      if (bagGridOn() && gunClassFull(_gc)){
        const S = gunSlots();
        let idx = _gc === 'side' ? GUN_SIDE_SLOT : _gc === 'melee' ? GUN_MELEE_SLOT : -1;
        if (idx < 0){
          const held = player.gun && gunKeyOf(player.gun);
          if (held && S[0] === held) idx = 0;
          else if (held && S[1] === held) idx = 1;
          else idx = 0;
        }
        const oldWid = S[idx];
        const oldG = oldWid && player.guns && player.guns[oldWid];
        if (!oldG) return false;          /* 栏里其实是空的（脏数据），当普通物资收 */
        S[idx] = null;
        delete player.guns[oldWid];
        if (player.gun === oldG) player.gun = null;
        _swap = oldG;
      }
      /* 捡枪有专门的一段实录（火箭筒除外）；有实录就不放电子音，避免叠两声 */
      if (!(_gw !== 'rpg' && typeof sfxPickupGun === 'function' && sfxPickupGun())) sfxPick();
      const gn = makeGun(_gw, l.mag);
      /* 品质浮动：只动伤害，弹匣/射速/后坐力不动 —— 不然手感会随掉落乱变 */
      const _gq = qualityRollFor(l, l.qBias || 0);
      gn.q = _gq;
      if (gn.dmg > 0) gn.dmg = Math.max(1, Math.round(gn.dmg * qualityK(_gq)));
      player.gun = gn;
      const _nk = gunNewKey(_gw);
      (player.guns || (player.guns = {}))[_nk] = gn;
      autoEquipGun(_nk);
      if (_swap){
        /* 换枪不记物资：pickLoot 看到 gear 就不加计数（一换一，不该算收集） */
        l.gear = true;
        const _d = safeSpot(cur(), {x:l.x, y:l.y}, 14);
        loots.push({x:_d.x, y:_d.y, taken:false, kind:'gun', cool:1.6, q:_swap.q,
                    wid:_swap.wid, mag:_swap.mag, name:_swap.name});
        setMsg('换下 ' + _swap.name + ' · 弹匣 ' + _swap.mag + ' · 就在脚边', 1.9);
        logInfo('gun', '换枪 · 捡起 ' + gn.name + '（弹匣 ' + gn.mag + '）· 放下 ' + _swap.name + '（弹匣 ' + _swap.mag + '）');
      } else {
        setMsg('捡到 ' + qualityPrefix(_gq) + gn.name, 1.4);
        logInfo('gun', '捡起 ' + qualityPrefix(_gq) + gn.name + ' · 弹匣 ' + gn.mag);
      }
      /* 割草里新捡的枪也得按「弹匣扩容」的层数补上限，否则少捡一把枪就少 8×层 */
      if (ar) arenaSyncCaps(false);
      return true;
    },
    draw(x, y, l){
      const gw = l.wid || 'pistol';
      const gs = gw === 'rpg' ? 0.82 : gw === 'shotgun' ? 1.0 : gw === 'rifle' ? 1.05 : gw === 'ar' ? 0.92 : gw === 'flare' ? 1.15 : gw === 'bino' ? 1.1 : 1.35;
      /* 只有膛里真有弹才画弹头：丢在地上的空筒不该顶着个火箭弹 */
      drawGunModel(x, y, gs, -0.42, PAL.P2, PAL.P6, gw, { warhead: gw === 'rpg' && (l.mag || 0) > 0 });
    }
  },
  ammo: {
    take(l){
      if (!hasFeat('loot')) return false;
      const A = ammoDef(l.ammo);
      const n = l.n || A.box;
      if (bagGridOn()){
        const put = bagAddAmmo(l.ammo, n);
        if (!put){ setMsg('背包满了，' + A.label + '塞不下（一格 60 发）', 1.6); return false; }
        if (!(typeof sfxAmmoTake === 'function' && sfxAmmoTake())) sfxPick();
        setMsg(A.label + ' +' + put + '　（背包共 ' + ((player.ammo && player.ammo[l.ammo]) || 0) + '）', 1.5);
        logInfo('item', '捡到 ' + A.label + ' ×' + put + ' · 共 ' + ((player.ammo && player.ammo[l.ammo]) || 0));
        return true;
      }
      if (!(typeof sfxAmmoTake === 'function' && sfxAmmoTake())) sfxPick();
      const total = addAmmo(l.ammo, n);
      setMsg(A.label + ' +' + n + '　（共 ' + total + '）', 1.5);
      logInfo('item', '捡到 ' + A.label + ' ×' + n + ' · 共 ' + total);
      return true;
    },
    draw(x, y, l){
      const A = ammoDef(l.ammo);
      if (l.ammo === 'rocket'){ drawRocketAmmoIcon(x, y, 1.0); return; }
      ctx.save();
      /* 一个小弹药盒：盒身 + 一条深色腰线 + 顶上一排子弹头 */
      ctx.fillStyle = A.dark;
      roundRect(x - 11, y - 8, 22, 15, 2.5); ctx.fill();
      ctx.fillStyle = A.pal;
      roundRect(x - 10, y - 7, 20, 6, 2); ctx.fill();
      ctx.fillStyle = A.pal;
      for (let i = 0; i < 3; i++) ctx.fillRect(x - 7 + i*5, y + 2, 3, 4);
      ctx.restore();
    }
  },
  /* 金条：物资堆里那把"万一有宝贝"的惊喜。现在只是值钱（多算货），
     以后接经济系统时改这一个 take() 就够了 */
  /* 老关卡的物资（levels.js 里只写 {x,y}，没有 kind）。
     它以前走的是"画个方块 + 捡到就 +1 物资"的通用分支，
     后来加了 canDraw 过滤器（只画 LOOT_KINDS 里有的 kind）就被整批吞掉了。
     这里给它一个正式身份：画法还是那个方块，数值行为也还是 +1 物资。 */
  supply: {
    label: '物资',
    draw(x, y){
      const th = (typeof uiDark === 'function') ? uiDark() : false;
      const fc = th ? PAL.P85 : PAL.P0, glow = th ? PAL.P115 : PAL.P60, size = 9;
      ctx.save();
      ctx.shadowColor = glow;
      ctx.shadowBlur = 16;
      ctx.fillStyle = fc;
      ctx.fillRect(x - size, y - size, size * 2, size * 2);
      ctx.restore();
      ctx.strokeStyle = PAL.P110; ctx.lineWidth = 2;
      ctx.strokeRect(x - size, y - size, size * 2, size * 2);
    }
  },
  rare: {
    take(l){
      /* 有网格背包时进背包（能在里面看到、能押给商人、能再丢出去）；
         老关卡没有网格背包，保持原来"直接折成物资"的行为 */
      if (bagGridOn()){
        const it = bagAddCell('rare', {});
        if (!it){ setMsg('背包满了（' + bagUsed() + '/' + (bagGridSize().w * bagGridSize().h) + '）', 1.3); return false; }
        setMsg('捡到金条 · 抽奖商人收 450 · 占 2×1 格', 2.4);
        logInfo('item', '捡到金条（进背包）');
        return true;
      }
      player.loot += 2;                     /* 加上外面那 +1，一共算 3 件货 */
      setMsg('金条 —— 这回真发了（物资 +3）', 2.6);
      logInfo('item', '捡到金条 · 物资 +3');
      return true;
    },
    draw(x, y){
      drawGoldBar(x, y, 1.25);
    }
  },
  med: {
    take(l){
      if (!hasFeat('meds')) return false;
      /* 战斗，爽！！：没有背包也没时间喝，拿起来就往嘴里归 —— 但回得少 */
      if (ar){
        const full = arenaMaxHp();
        if (player.hp >= full - 0.5){
          setMsg('血是满的，先不浪费', 1.0);
          return false;
        }
        /* 战斗爽模式：没有三段读条，但药包一样有耐久 —— 一口气把这包的耐久全用掉，
           立即回"满耐久该回多少"，血多出来的部分丢弃（不凭空造出更多回血量）。 */
        const _ad0 = MED_DEF[l.rarity] || MED_DEF.small;
        const _aq = qualityRollFor(l, l.qBias || 0);
        const _afull = Math.max(1, Math.round(_ad0.amt * qualityK(_aq)));
        const _agap = Math.max(0, Math.round(full - player.hp));
        const _aheal = Math.min(_agap, _afull);
        player.hp = Math.min(full, player.hp + _aheal);
        sfxPick();
        setMsg('战斗爽 · 一口气喝完 · +' + Math.round(_aheal) + ' 血', 1.2);
        logInfo('item', '现场拿药（战斗爽一次用光耐久）+ ' + Math.round(_aheal));
        return true;
      }
      if (bagGridOn()){
        const d0 = MED_DEF[l.rarity] || MED_DEF.small;
        const _mq = qualityRollFor(l, l.qBias || 0);
        if (!bagAddMed(l.rarity, _mq)){ setMsg('背包满了（' + bagUsed() + '/' + (bagGridSize().w*bagGridSize().h) + '）', 1.3); return false; }
        sfxPick();
        setMsg('捡到 ' + qualityPrefix(_mq) + d0.label + ' · 回血 ' + Math.round(d0.amt * qualityK(_mq)) + ' · 背包 ' + bagUsed() + '/' + (bagGridSize().w*bagGridSize().h) + ' 格', 1.5);
        logInfo('item', '捡到 ' + d0.label + ' ×' + (player.meds[l.rarity] || 0));
        return true;
      }
      sfxPick();
      if (!bagHasRoom(1)){ setMsg('背包满了（' + bagUsed() + '/' + bagSlots() + '）', 1.3); return false; }
      if (!player.meds) player.meds = {small:0, big:0};
      player.meds[l.rarity] = (player.meds[l.rarity]||0) + 1;
      const d = MED_DEF[l.rarity] || MED_DEF.small;
      setMsg('捡到 ' + d.label + '（' + d.tier + '）', 1.4);
      logInfo('item', '捡到 ' + d.label + ' ×' + player.meds[l.rarity]);
      return true;
    },
    draw(x, y, l){
      /* 贴地阴影由外层统一画（见 drawLootShadow），这里别再画一层 */
      drawMedModel(x, y, 1.25, l.rarity);
    }
  }
};

/* 名字的唯一出处是 data/lootkinds.js —— 这里只放行为（take/draw）。
   lootApplyLabels() 在两处调用：这里加载完一次，game/66-tripwire.js 末尾再调一次
   （绳子/绊雷是那边运行期挂上来的）。 */
/* 这件物资"是干嘛的"一句话。名字/说明的唯一出处是 data/lootkinds.js，
   这里只做一次查表，查不到就返回空串（老存档里的未知 kind 不会炸）。 */
/* 悬停里补一句说明只对这几类做：面板分支自己没讲清楚的。
   其余（药/子弹/枪/甲/背包…）分支里已经有精确数值，再贴一句通用说明会和数字打架。 */
const LOOT_BRIEF_KINDS = { intel:1, blackbox:1, smoke:1, nade:1, thermal:1, rare:1 };

function lootBrief(k){
  if (!LOOT_BRIEF_KINDS[k]) return "";
  if (typeof LOOT_KIND_DEF === "undefined" || !LOOT_KIND_DEF) return "";
  const d = LOOT_KIND_DEF[k];
  return (d && d.brief) ? d.brief : "";
}

function lootApplyLabels(){
  if (typeof LOOT_KIND_DEF === 'undefined') return 0;
  let n = 0;
  for (const k in LOOT_KINDS){
    const d = LOOT_KIND_DEF[k];
    if (d && d.label && LOOT_KINDS[k].label !== d.label){ LOOT_KINDS[k].label = d.label; n++; }
  }
  return n;
}
lootApplyLabels();

function isTestZone(){ return !!(cur().rules && cur().rules.devTest); }

/* ---- 机制版本 ----
   每一关自己声明它用哪一套机制。老关卡没写 ver，就永远是 1，
   后来加的东西一律不会自动漏进老关卡——想给某一关升级，只改那一关数据里的 ver。
   （加新机制时：在下面表里加一行，新版本号给个 2 以上的数，然后只改想升级的关卡） */
const FEAT_VER = {
  guns:      2,   /* 玩家手里能有枪：弹匣 / 换枪 / 弹药分口径 / 后坐力 */
  meds:      2,   /* 小药 / 绿药包 + 背包 */
  loot:      2,   /* 打死的人会掉东西 */
  breakWall: 2,   /* 可破坏的墙 */
  aiFlee:    2,   /* 敌人伤重了会跑、会躲起来打药 */
  bagGrid:   3    /* 网格背包：东西按真实大小占格子，子弹 60 发一格，甲 3×3 */
};
function levelVer(L){ return (L && L.ver) || 1; }
function hasFeatL(L, name){ return levelVer(L) >= (FEAT_VER[name] || 99); }
function hasFeat(name){ return hasFeatL(cur(), name); }

/* 哪一档难度在哪些关卡里说得通。
   噩梦是照"你有枪、能还手"设计的：人多、跑得比你快、子弹更狠。
   第一章第二章（ver 1）你是空手的，把同一套数值丢进去不是难，是不讲理 ——
   所以那种关卡里这一档直接不出现，免得玩家以为选了会更有挑战，其实是必死。 */
function diffAllowed(name, L){
  if (name !== 'nightmare') return true;
  return hasFeatL(L || cur(), 'guns');
}
function diffListFor(L){
  return DIFF_ORDER.filter(k => diffAllowed(k, L || cur()));
}

/* m45899：机枪棱堡的专属声音 —— 低频"咚咚"+ 短尾，不和任何人的枪重合。
   没有 actx 时退回录音池（不然浏览器没解锁音频就彻底没声）。 */
function sfxMgSentry(x, y){
  if (typeof actx === 'undefined' || !actx){ sndPlay('gun.enemy.shotgun.c', 0.40); return; }
  const px = (typeof player !== 'undefined' && player) ? player.x : x;
  const pan = Math.max(-0.8, Math.min(0.8, ((x - px) / ((typeof W === 'number' ? W : 1280) * 0.5)) * 0.8));
  const _gvk = (typeof CFG !== 'undefined' && CFG.gunVol != null) ? Math.max(0, Math.min(1, CFG.gunVol / 100)) : 0.7;
  try {
    const t0 = actx.currentTime;
    const out = duckBus();
    const gain = actx.createGain();
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(0.34 * _gvk, t0 + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.15);
    const osc = actx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(124, t0);
    osc.frequency.exponentialRampToValueAtTime(54, t0 + 0.11);
    const lp = actx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 880; lp.Q.value = 0.7;
    osc.connect(lp); lp.connect(gain);
    if (typeof actx.createStereoPanner === 'function'){
      const p = actx.createStereoPanner(); p.pan.value = pan;
      gain.connect(p); p.connect(out);
    } else gain.connect(out);
    osc.start(t0); osc.stop(t0 + 0.17);
  } catch (e){ if (typeof reportErr === 'function') reportErr('32-baggrid', e); }
}
function sfxGunShot(g, opt){
  if (!actx) return;
  /* 实录的 Uzi：有真录音就放真录音（没文件时 sndPlay 返回 false，自动回落合成音） */
  if (g){
    const _wid = g.wid;
    /* AR15 用实录枪声（没解出文件就自动回落下面的合成音） */
    if (_wid === 'ar' && typeof sfxAr15Fire === 'function' && sfxAr15Fire(player.x, player.y)) return;
    const fallback = () => sfxSyntheticGunShot(g, opt);
    if (_wid === 'rifle'  && sndPlay('gun.uzi', 0.5, undefined, fallback)) return;
    if (_wid === 'pistol' && sndPlay('gun.pistol', 0.55, undefined, fallback)) return;
    if (_wid === 'shotgun' && sndPlay('gun.shotgun', 0.6, undefined, fallback)) return;
  }
  sfxSyntheticGunShot(g, opt);
}
function sfxSyntheticGunShot(g, opt){
  if (!actx) return;
  /* m44200：从 WEAPONS 里拿一份**拷贝**——以前直接改 `gunDef(g).sfx.gain`，
     每开一枪就乘一次 gunVol，几十枪之后音量就塌了。 */
  const _base = (gunDef(g) && gunDef(g).sfx) || { gain:0.32, lp:2600, tone:180, tail:0.14 };
  const sd = { gain:_base.gain, lp:_base.lp, tone:_base.tone, tail:_base.tail };
  const _gvk = (typeof CFG !== 'undefined' && CFG.gunVol != null) ? Math.max(0, Math.min(1, CFG.gunVol / 100)) : 0.7;
  sd.gain = (sd.gain || 0.3) * _gvk;   /* 武器音量滑条也管合成音 */
  /* m44200：给"别人开这一枪"用 —— opt.gainK 按距离衰减，opt.pan 做左右声像。
     敌人火箭筒现在就是拿玩家的枪 + 这两个参数，保证同一个武器只有一种声音。 */
  if (opt && isFinite(opt.gainK)) sd.gain *= Math.max(0, Math.min(1.5, opt.gainK));
  if (!(sd.gain > 0)) return;
  try {
    let _out = duckBus();
    if (opt && isFinite(opt.pan) && actx.createStereoPanner){
      const _pn = actx.createStereoPanner();
      _pn.pan.value = Math.max(-1, Math.min(1, opt.pan));
      _pn.connect(duckBus());
      _out = _pn;
    }
    if (g?.wid === 'rpg' && combatSamplePlay('rpg', sd.gain / _base.gain, _out)) return;
    ensureNoise();
    if (noiseBuf) synthGunShot(actx, _out, noiseBuf, sd);
  } catch (e){ if (typeof reportErr === 'function') reportErr('32-baggrid', e); }
}
function synthGunShot(ctx, out, noise, sd){
  const t0 = ctx.currentTime;
  const src = ctx.createBufferSource(); src.buffer = noise;
  const lp = ctx.createBiquadFilter(); lp.type = 'lowpass';
  lp.frequency.setValueAtTime(sd.lp, t0);
  lp.frequency.exponentialRampToValueAtTime(320, t0 + sd.tail * 0.85);
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(sd.gain, t0);
  gain.gain.exponentialRampToValueAtTime(sd.gain * 0.002, t0 + sd.tail);
  src.connect(lp); lp.connect(gain); gain.connect(out);
  src.start(t0); src.stop(t0 + sd.tail + 0.02);
  const osc = ctx.createOscillator(), tone = ctx.createGain();
  osc.type = 'square'; osc.frequency.setValueAtTime(sd.tone, t0);
  osc.frequency.exponentialRampToValueAtTime(sd.tone * 0.33, t0 + sd.tail * 0.7);
  tone.gain.setValueAtTime(sd.gain * 0.38, t0);
  tone.gain.exponentialRampToValueAtTime(sd.gain * 0.002, t0 + sd.tail * 0.85);
  osc.connect(tone); tone.connect(out);
  osc.start(t0); osc.stop(t0 + sd.tail);
}
function sfxClickGun(on){
  if (!actx) return;
  try {
    const t0 = actx.currentTime;
    const src = actx.createBufferSource(); src.buffer = noiseBuf;
    const lp = actx.createBiquadFilter(); lp.type='lowpass';
    lp.frequency.value = on ? 2200 : 1200;
    const g = actx.createGain();
    g.gain.setValueAtTime(0.16, t0); g.gain.exponentialRampToValueAtTime(0.001, t0+0.08);
    src.connect(lp); lp.connect(g); g.connect(duckBus());
    src.start(t0); src.stop(t0+0.09);
  } catch (e){ if (typeof reportErr === 'function') reportErr('32-baggrid', e); }
}

/* 金条：伪 3D 金锭 —— 上窄下宽的梯形正面 + 收窄的斜顶面 + 右侧暗斜面 + 压印 + 投影。
   刻意不是"上下同宽的方砖"：金锭两侧是收进去的斜边，这是它最好认的特征。
   自然尺寸约 26×20，调用方用 sc 控制大小。 */
function drawGoldBar(x, y, sc){
  const k = sc || 1;
  ctx.save();
  ctx.translate(x, y); ctx.scale(k, k);

  const W = 24, TW = 16.5, H = 9, D = 7;   /* 底宽 / 顶宽 / 高 / 进深 */
  const hw = W / 2, htw = TW / 2, hh = H / 2;
  const dx = D * 0.62, dy = -D * 0.72;     /* 顶面向右上后方斜出去的量 */

  /* 落在"地"上的投影 */
  ctx.fillStyle = 'rgba(0,0,0,0.34)';
  ctx.beginPath();
  ctx.ellipse(2, hh + 3.2, hw * 0.92, 2.6, 0, 0, Math.PI * 2);
  ctx.fill();

  /* 正面：上窄下宽的梯形（竖向渐变，上亮下暗） */
  const fg = ctx.createLinearGradient(0, -hh, 0, hh);
  fg.addColorStop(0, '#ffeaa8');
  fg.addColorStop(0.30, '#f4d063');
  fg.addColorStop(0.74, '#d8aa33');
  fg.addColorStop(1, '#a97d18');
  ctx.fillStyle = fg;
  ctx.beginPath();
  ctx.moveTo(-hw, hh);
  ctx.lineTo(hw, hh);
  ctx.lineTo(htw, -hh);
  ctx.lineTo(-htw, -hh);
  ctx.closePath(); ctx.fill();

  /* 顶面：同样收窄的平行四边形，最亮 */
  const tg = ctx.createLinearGradient(-htw, -hh + dy, htw + dx, -hh);
  tg.addColorStop(0, '#fff8d8');
  tg.addColorStop(0.55, '#ffe89e');
  tg.addColorStop(1, '#efc451');
  ctx.fillStyle = tg;
  ctx.beginPath();
  ctx.moveTo(-htw, -hh);
  ctx.lineTo(-htw + dx, -hh + dy);
  ctx.lineTo(htw + dx, -hh + dy);
  ctx.lineTo(htw, -hh);
  ctx.closePath(); ctx.fill();

  /* 右侧斜面：暗一档，把厚度交代清楚 */
  const sg = ctx.createLinearGradient(hw, hh, htw + dx, -hh + dy);
  sg.addColorStop(0, '#c2951f');
  sg.addColorStop(1, '#8a650f');
  ctx.fillStyle = sg;
  ctx.beginPath();
  ctx.moveTo(hw, hh);
  ctx.lineTo(htw, -hh);
  ctx.lineTo(htw + dx, -hh + dy);
  ctx.lineTo(hw + dx, hh + dy);
  ctx.closePath(); ctx.fill();

  /* 棱线：顶面与正面交界一条亮线，两侧斜边一条深缝 */
  ctx.strokeStyle = 'rgba(255,250,220,0.85)'; ctx.lineWidth = 0.9;
  ctx.beginPath(); ctx.moveTo(-htw, -hh); ctx.lineTo(htw, -hh); ctx.stroke();
  ctx.strokeStyle = 'rgba(108,74,8,0.5)'; ctx.lineWidth = 0.7;
  ctx.beginPath();
  ctx.moveTo(-hw, hh); ctx.lineTo(-htw, -hh);
  ctx.moveTo(hw, hh); ctx.lineTo(htw, -hh);
  ctx.stroke();

  /* 左上斜高光（金属反射） */
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(-hw, hh); ctx.lineTo(hw, hh); ctx.lineTo(htw, -hh); ctx.lineTo(-htw, -hh);
  ctx.closePath(); ctx.clip();
  ctx.fillStyle = 'rgba(255,255,238,0.40)';
  ctx.beginPath();
  ctx.moveTo(-hw + 2.2, -hh + 0.8);
  ctx.lineTo(-hw + 7.4, -hh + 0.8);
  ctx.lineTo(-hw + 3.2, hh - 0.8);
  ctx.lineTo(-hw + 1.0, hh - 0.8);
  ctx.closePath(); ctx.fill();
  ctx.restore();

  /* 两道压印（铸纹），下宽上窄跟着梯形收 */
  ctx.strokeStyle = 'rgba(120,84,12,0.5)'; ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.moveTo(-hw + 5.6, -0.8); ctx.lineTo(hw - 4.4, -0.8);
  ctx.moveTo(-hw + 6.6, 2.6); ctx.lineTo(hw - 5.6, 2.6);
  ctx.stroke();

  ctx.restore();
}

/* 枪的俯视剪影：地上、背包格子、玩家手里用同一套画法。
   kind 决定长什么样 —— 手枪短、霰弹枪两根管子、步枪带弹匣和护木。
   三把枪共用同一套"朝向 +x"的坐标，所以换枪不用改画法。 */
/* 火箭弹图标：短粗的“毒刺”造型，背包 / 地上 / 说明卡共用这一份。
   自然尺寸约 20×26（和 BAG_NAT.ammo=26 一个量级），朝上。 */
function drawRocketAmmoIcon(x, y, sc){
  const k = sc || 1;
  ctx.save();
  ctx.translate(x, y); ctx.scale(k, k);
  const edge = 'rgba(12,16,20,0.55)';
  ctx.lineWidth = 1.0; ctx.strokeStyle = edge;

  /* 尾翼：上下各一片梯形，往后张开（朝右是机头） */
  ctx.fillStyle = '#79828d';
  ctx.beginPath(); ctx.moveTo(-5.0, -2.6); ctx.lineTo(-11.2, -7.4); ctx.lineTo(-5.0, -7.4); ctx.closePath();
  ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-5.0, 2.6); ctx.lineTo(-11.2, 7.4); ctx.lineTo(-5.0, 7.4); ctx.closePath();
  ctx.fill(); ctx.stroke();

  /* 弹体：细长圆柱（横向渐变，上亮下暗） */
  const bg = ctx.createLinearGradient(0, -4.6, 0, 4.6);
  bg.addColorStop(0, '#e2e9ef'); bg.addColorStop(0.42, '#c3ccd5');
  bg.addColorStop(0.78, '#9aa4ae'); bg.addColorStop(1, '#7b858f');
  ctx.fillStyle = bg;
  roundRect(-6.0, -4.6, 16.5, 9.2, 3.4); ctx.fill(); ctx.stroke();

  /* 两道卡箍 */
  ctx.fillStyle = 'rgba(58,66,74,0.9)';
  ctx.fillRect(-2.0, -4.6, 1.9, 9.2);
  ctx.fillRect(3.2, -4.6, 1.9, 9.2);

  /* 弹头：暗橙色的尖三角，朝右 */
  const ng = ctx.createLinearGradient(0, -4.6, 0, 4.6);
  ng.addColorStop(0, '#e8703a'); ng.addColorStop(0.5, '#c8501f'); ng.addColorStop(1, '#8a3416');
  ctx.fillStyle = ng;
  ctx.beginPath(); ctx.moveTo(9.8, -4.6); ctx.lineTo(16.4, 0); ctx.lineTo(9.8, 4.6); ctx.closePath();
  ctx.fill(); ctx.stroke();
  /* 弹头高光 */
  ctx.fillStyle = 'rgba(255,222,192,0.6)';
  ctx.beginPath(); ctx.moveTo(10.6, -3.0); ctx.lineTo(14.4, -0.5); ctx.lineTo(10.6, -0.5); ctx.closePath(); ctx.fill();

  /* 喷口：最左边一块深色方块 */
  ctx.fillStyle = '#343b43';
  roundRect(-9.4, -3.9, 3.4, 7.8, 1.2); ctx.fill(); ctx.stroke();
  ctx.restore();
}

function drawGunModel(cx, cy, s, ang, col, edge, kind, opt){
  ctx.save();
  ctx.translate(cx, cy); ctx.rotate(ang); ctx.scale(s, s);
  const ec = edge || 'rgba(0,0,0,0.45)';
  ctx.fillStyle = col; ctx.strokeStyle = ec; ctx.lineWidth = 1.1;

  if (kind === 'flare'){
    /* 信号枪：粗短红管 + 喇叭口 + 木色握把，前端一颗红色信号弹 */
    ctx.fillStyle = '#a3282f';
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(-13, -4.6, 26, 9.2, 3); else ctx.rect(-13, -4.6, 26, 9.2);
    ctx.fill(); ctx.stroke();
    /* 喇叭口 */
    ctx.fillStyle = '#7d1c22';
    ctx.beginPath();
    ctx.moveTo(11, -6.6); ctx.lineTo(17, -8.4); ctx.lineTo(17, 8.4); ctx.lineTo(11, 6.6);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    /* 弹头（红） */
    ctx.fillStyle = '#ff5d6c';
    ctx.beginPath(); ctx.ellipse(16, 0, 2.6, 5.2, 0, 0, TAU); ctx.fill();
    /* 握把 */
    ctx.fillStyle = '#6b4a2c';
    ctx.beginPath();
    ctx.moveTo(-9, 4.2); ctx.lineTo(-3, 4.2); ctx.lineTo(-5.5, 13); ctx.lineTo(-11, 13);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    /* 扳机护圈 */
    ctx.strokeStyle = 'rgba(30,10,12,0.7)'; ctx.lineWidth = 1.1;
    ctx.beginPath(); ctx.arc(-2.5, 7.6, 3.6, 0, Math.PI); ctx.stroke();
    ctx.restore();
    return;
  }
  if (kind === 'bino'){
    /* 望远镜：两根并排镜筒 + 中间铰链 + 前端镜片。平放在地上也一眼认得出不是枪 */
    const _bg = ctx.createLinearGradient(0, -9, 0, 9);
    _bg.addColorStop(0, '#5c6a7e'); _bg.addColorStop(0.5, '#3d4757'); _bg.addColorStop(1, '#262d37');
    for (const by of [-4.8, 4.8]){
      ctx.fillStyle = _bg;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(-14, by - 4.2, 31, 8.4, 2.8); else ctx.rect(-14, by - 4.2, 31, 8.4);
      ctx.fill(); ctx.stroke();
      /* 目镜 */
      ctx.fillStyle = '#20262e';
      ctx.beginPath(); ctx.ellipse(-14.4, by, 1.9, 3.5, 0, 0, TAU); ctx.fill();
      /* 前口径 + 镜片 */
      ctx.fillStyle = '#11161c';
      ctx.beginPath(); ctx.ellipse(17.4, by, 2.7, 4.5, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(126,206,232,0.9)';
      ctx.beginPath(); ctx.ellipse(18.3, by, 1.5, 3.1, 0, 0, TAU); ctx.fill();
      /* 筒身防滑纹 */
      ctx.strokeStyle = 'rgba(150,168,188,0.32)'; ctx.lineWidth = 0.8;
      for (const gx of [-9, -5, -1]){ ctx.beginPath(); ctx.moveTo(gx, by - 3.6); ctx.lineTo(gx, by + 3.6); ctx.stroke(); }
      ctx.strokeStyle = ec; ctx.lineWidth = 1.1;
    }
    /* 中轴（调焦桥） */
    ctx.fillStyle = '#3a434f';
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(-7, -2.6, 13, 5.2, 1.8); else ctx.rect(-7, -2.6, 13, 5.2);
    ctx.fill(); ctx.stroke();
    ctx.restore();
    return;
  }
  if (kind === 'rpg'){
    /* 火箭筒：军绿粗筒 + 尾部喇叭 + 收窄的筒口（装上弹才有弹头） */
    const _og = ctx.createLinearGradient(0, -7, 0, 7);
    _og.addColorStop(0, '#77854f'); _og.addColorStop(0.42, '#5a6a3c');
    _og.addColorStop(1, '#303a22');
    /* 尾部喇叭口 */
    ctx.fillStyle = '#3d472c';
    ctx.beginPath();
    ctx.moveTo(-31, -8.6); ctx.lineTo(-20, -5.6); ctx.lineTo(-20, 5.6); ctx.lineTo(-31, 8.6);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = 'rgba(16,20,12,0.55)';
    ctx.beginPath(); ctx.ellipse(-30, 0, 2.4, 8.2, 0, 0, Math.PI*2); ctx.fill();
    /* 筒身 */
    ctx.fillStyle = _og;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(-21, -6.4, 40, 12.8, 3.6); else ctx.rect(-21, -6.4, 40, 12.8);
    ctx.fill(); ctx.stroke();
    /* 两道加强箍 */
    ctx.strokeStyle = 'rgba(20,26,14,0.5)'; ctx.lineWidth = 1.5;
    for (const bx of [-10, 3]){ ctx.beginPath(); ctx.moveTo(bx, -6.4); ctx.lineTo(bx, 6.4); ctx.stroke(); }
    ctx.strokeStyle = ec; ctx.lineWidth = 1.1;
    /* 前端收窄的筒口 */
    ctx.fillStyle = '#2c3520';
    ctx.beginPath(); ctx.moveTo(19, -6.4); ctx.lineTo(25, -3.4); ctx.lineTo(25, 3.4); ctx.lineTo(19, 6.4);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    /* 装填了才画弹头 */
    if (opt && opt.warhead){
      ctx.fillStyle = '#c65a26';
      ctx.beginPath(); ctx.moveTo(24, -3.8); ctx.lineTo(33, 0); ctx.lineTo(24, 3.8); ctx.closePath();
      ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(255,214,168,0.5)';
      ctx.beginPath(); ctx.moveTo(25, -1.6); ctx.lineTo(29.4, 0); ctx.lineTo(25, 0.6); ctx.closePath(); ctx.fill();
    }
    /* 握把 */
    ctx.fillStyle = '#29321f';
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(-6, 5.4, 8.4, 8.6, 2.2); else ctx.rect(-6, 5.4, 8.4, 8.6);
    ctx.fill(); ctx.stroke();
    /* 机械瞄具：前后两块方块 + 一条瞄准线 */
    ctx.fillStyle = 'rgba(222,232,206,0.82)';
    ctx.fillRect(9, -9.4, 3.6, 3.2);
    ctx.fillRect(-17, -8.6, 2.8, 2.6);
    ctx.strokeStyle = 'rgba(222,232,206,0.5)'; ctx.lineWidth = 0.9;
    ctx.beginPath(); ctx.moveTo(-17, -7.6); ctx.lineTo(12.4, -7.6); ctx.stroke();
    ctx.strokeStyle = ec; ctx.lineWidth = 1.1;
  } else if (kind === 'knife'){
    /* 战术刀：直刃、对称，跟弯刀区分得很明显 */
    ctx.fillStyle = '#232c38';
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(-24, -1.8, 15, 3.6, 1.6); else ctx.rect(-24, -1.8, 15, 3.6);
    ctx.fill(); ctx.stroke();
    ctx.strokeStyle = 'rgba(146,166,186,0.5)'; ctx.lineWidth = 0.9;
    for (let i = 0; i < 4; i++){
      const hx = -23 + i * 3.6;
      ctx.beginPath(); ctx.moveTo(hx, -1.9); ctx.lineTo(hx + 2.2, 1.9); ctx.stroke();
    }
    ctx.strokeStyle = ec; ctx.lineWidth = 1.1;
    ctx.fillStyle = '#8b96a4';
    ctx.beginPath(); ctx.arc(-7.4, 0, 3.9, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-6.0, -2.6); ctx.lineTo(18.0, -1.5); ctx.lineTo(20.4, 0); ctx.lineTo(18.0, 1.5); ctx.lineTo(-6.0, 2.6);
    ctx.closePath();
    const _kg = ctx.createLinearGradient(0, -2.6, 0, 2.6);
    _kg.addColorStop(0, '#dbe6f2'); _kg.addColorStop(1, '#98a6b6');
    ctx.fillStyle = _kg; ctx.fill(); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(-5.0, 2.0); ctx.lineTo(19.6, 0.4); ctx.stroke();
  } else if (kind === 'dao'){
    /* 弯刀：刀身是多边形（不是矩形）。背侧深灰、刃側亮银白，刀尖收成一个点。
       跟枪共用同一套“朝 +x”的坐标，所以换刀不用改别的地方。 */
    /* 刀柄：细长一根，末端圆角 */
    ctx.fillStyle = '#232c38';
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(-31, -1.9, 20, 3.8, 1.7);
    else ctx.rect(-31, -1.9, 20, 3.8);
    ctx.fill(); ctx.stroke();
    /* 缠绳：几条斜线 */
    ctx.strokeStyle = 'rgba(146,166,186,0.55)'; ctx.lineWidth = 0.9;
    for (let i = 0; i < 5; i++){
      const hx = -29.5 + i * 3.9;
      ctx.beginPath(); ctx.moveTo(hx, -2.0); ctx.lineTo(hx + 2.5, 2.0); ctx.stroke();
    }
    ctx.strokeStyle = ec; ctx.lineWidth = 1.1;
    /* 护手：一个小圆片，把刀身和刀柄隔开 */
    ctx.fillStyle = '#8b96a4';
    ctx.beginPath(); ctx.arc(-9.6, 0, 4.3, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    /* 刀身：外弧 = 刀背，内弧 = 刃口，到右端收成尖 */
    ctx.beginPath();
    ctx.moveTo(-8.0, -4.6);
    ctx.quadraticCurveTo(6.5, -11.2, 27.8, -3.8);
    ctx.quadraticCurveTo(8.5, 2.2, -8.0, 5.8);
    ctx.closePath();
    const _bg = ctx.createLinearGradient(0, -11, 0, 7);
    _bg.addColorStop(0, '#39424d');
    _bg.addColorStop(0.42, '#5d6975');
    _bg.addColorStop(0.78, '#c3cfdc');
    _bg.addColorStop(1, '#f4f9ff');
    ctx.fillStyle = _bg;
    ctx.fill(); ctx.stroke();
    /* 刀背一条深灰厚边 */
    ctx.strokeStyle = 'rgba(44,52,63,0.98)'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-7.4, -4.2);
    ctx.quadraticCurveTo(6.4, -10.4, 27.0, -3.8);
    ctx.stroke();
    /* 刃口一条亮线（反光） */
    ctx.strokeStyle = 'rgba(255,255,255,0.95)'; ctx.lineWidth = 1.5;
    ctx.shadowColor = 'rgba(198,228,255,0.75)'; ctx.shadowBlur = 4;
    ctx.beginPath();
    ctx.moveTo(-7.2, 5.4);
    ctx.quadraticCurveTo(9.0, 2.0, 27.0, -3.6);
    ctx.stroke();
    ctx.shadowBlur = 0; ctx.lineCap = 'butt';
  } else if (kind === 'smoke'){
    /* 烟雾弹：细长罐体 + 白箍 + 前盖 + 尾部拉环（之前是扁胖方块，比例不对） */
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(-9.5, -4.6, 17, 9.2, 3.0) : ctx.rect(-9.5, -4.6, 17, 9.2);
    ctx.fill(); ctx.stroke();
    /* 中间的白箍 */
    ctx.fillStyle = 'rgba(255,255,255,0.40)';
    ctx.fillRect(-2.6, -4.6, 3.6, 9.2);
    /* 前盖 */
    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.fillRect(7.5, -3.1, 3.2, 6.2); ctx.strokeRect(7.5, -3.1, 3.2, 6.2);
    /* 尾部拉环 */
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(-12.4, 0, 3.0, 0, Math.PI*2); ctx.stroke();
    ctx.strokeStyle = ec; ctx.lineWidth = 1.1;
  } else if (kind === 'shotgun'){
    /* 枪托 */
    ctx.beginPath();
    ctx.moveTo(-27, -3.0); ctx.lineTo(-14, -5.0); ctx.lineTo(-14, 5.0); ctx.lineTo(-27, 3.2);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    /* 机匣：比枪管高，方方正正一块 */
    ctx.fillRect(-14, -5.4, 12, 10.8); ctx.strokeRect(-14, -5.4, 12, 10.8);
    /* 上下两根管子：霰弹枪最好认的就是这个 */
    ctx.fillRect(-2, -5.4, 30, 3.6); ctx.strokeRect(-2, -5.4, 30, 3.6);
    ctx.fillRect(-1, -0.8, 25, 3.8); ctx.strokeRect(-1, -0.8, 25, 3.8);
    /* 泵动握把 */
    ctx.fillRect(6, 3.0, 11, 5.6); ctx.strokeRect(6, 3.0, 11, 5.6);
    /* 扳机护圈 */
    ctx.beginPath(); ctx.arc(-2, 6.6, 4.0, -0.5, Math.PI*0.98); ctx.stroke();
    /* 准星 */
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.fillRect(26, -7.0, 2.4, 1.8);
  } else if (kind === 'ar'){
    /* 突击步枪：长枪管 + 直弹匣 + 上导轨小瞄具，整体比 Uzi 长一截、细一档 */
    /* 枪托：末端加一块托底板 */
    ctx.beginPath();
    ctx.moveTo(-31, -2.6); ctx.lineTo(-19, -4.4); ctx.lineTo(-19, 4.4); ctx.lineTo(-31, 2.6);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillRect(-33.0, -3.2, 2.2, 6.4); ctx.strokeRect(-33.0, -3.2, 2.2, 6.4);
    /* 机匣 */
    ctx.fillRect(-19, -4.6, 15, 9.2); ctx.strokeRect(-19, -4.6, 15, 9.2);
    /* 握把 */
    ctx.beginPath();
    ctx.moveTo(-10, 4.4); ctx.lineTo(-4.6, 4.4); ctx.lineTo(-7.4, 12.4); ctx.lineTo(-13.6, 12.4);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    /* 直弹匣（不是 Uzi 那种粗胖的） */
    ctx.beginPath();
    ctx.moveTo(-1.6, 4.2); ctx.lineTo(3.6, 4.2); ctx.lineTo(5.6, 13.2); ctx.lineTo(-1.0, 13.2);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    /* 护木 + 散热孔 */
    ctx.fillRect(2, -4.2, 16, 8.4); ctx.strokeRect(2, -4.2, 16, 8.4);
    ctx.strokeStyle = 'rgba(0,0,0,0.30)'; ctx.lineWidth = 1.0;
    for (let k = 0; k < 3; k++){
      ctx.beginPath(); ctx.moveTo(5 + k*4.4, -2.4); ctx.lineTo(5 + k*4.4, 2.4); ctx.stroke();
    }
    /* 上导轨 + 小瞄具 */
    ctx.strokeStyle = ec;
    ctx.fillRect(-2, -7.6, 12, 2.4); ctx.strokeRect(-2, -7.6, 12, 2.4);
    ctx.fillRect(1.4, -10.2, 5.2, 2.8); ctx.strokeRect(1.4, -10.2, 5.2, 2.8);
    /* 枪管 + 消焰器 */
    ctx.fillRect(18, -2.2, 14, 3.4); ctx.strokeRect(18, -2.2, 14, 3.4);
    ctx.fillRect(31, -3.0, 3.2, 5.0); ctx.strokeRect(31, -3.0, 3.2, 5.0);
    /* 准星 */
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.fillRect(28, -5.2, 2.0, 1.8);
  } else if (kind === 'rifle'){
    /* 枪托 */
    ctx.beginPath();
    ctx.moveTo(-27, -3.0); ctx.lineTo(-16, -4.8); ctx.lineTo(-16, 4.8); ctx.lineTo(-27, 3.0);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    /* 机匣 */
    ctx.fillRect(-16, -5.2, 13, 10.4); ctx.strokeRect(-16, -5.2, 13, 10.4);
    /* 弹匣：斜着插下去 */
    ctx.beginPath();
    ctx.moveTo(-9.5, 4.6); ctx.lineTo(-3.0, 4.6); ctx.lineTo(-1.2, 13.8); ctx.lineTo(-9.8, 13.8);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    /* 护木 */
    ctx.fillRect(-3, -4.8, 18, 9.6); ctx.strokeRect(-3, -4.8, 18, 9.6);
    /* 枪管 */
    ctx.fillRect(15, -2.6, 15, 4.0); ctx.strokeRect(15, -2.6, 15, 4.0);
    /* 提把 / 照门：让轮廓不只是一根棍 */
    ctx.fillRect(6, -7.4, 8, 2.8); ctx.strokeRect(6, -7.4, 8, 2.8);
    /* 护木散热槽 */
    ctx.strokeStyle = 'rgba(0,0,0,0.30)'; ctx.lineWidth = 1.0;
    for (let k = 0; k < 3; k++){
      ctx.beginPath(); ctx.moveTo(1 + k*4.4, -2.6); ctx.lineTo(1 + k*4.4, 2.6); ctx.stroke();
    }
    /* 准星 */
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.fillRect(27, -4.8, 2.0, 1.8);
  } else {
  /* 套筒 */
  ctx.beginPath();
  ctx.moveTo(-13, -5); ctx.lineTo(12, -5); ctx.lineTo(14, -2); ctx.lineTo(14, 2); ctx.lineTo(-13, 2);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  /* 套筒上的防滑纹 */
  ctx.strokeStyle = 'rgba(0,0,0,0.22)'; ctx.lineWidth = 0.9;
  for (let k = 0; k < 4; k++){
    ctx.beginPath(); ctx.moveTo(-11 + k*2.2, -4.2); ctx.lineTo(-11 + k*2.2, 1.2); ctx.stroke();
  }
  /* 握把：比套筒宽，往下收一点 */
  ctx.strokeStyle = ec; ctx.lineWidth = 1.1;
  ctx.beginPath();
  ctx.moveTo(-12, 2); ctx.lineTo(-3.5, 2); ctx.lineTo(-6.5, 13); ctx.lineTo(-15.5, 13);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  /* 扳机护圈 */
  ctx.strokeStyle = ec; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.arc(-3.5, 5.5, 4.2, -0.5, Math.PI*0.95); ctx.stroke();
  /* 准星 + 枪口 */
  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  ctx.fillRect(9, -6.4, 2.2, 1.6);
  ctx.fillRect(-12, -6.4, 2.2, 1.6);
  }
  ctx.restore();
}

/* 医疗包：地上 / 背包格 / HUD 三处共用同一套画法。箱子要有箱子的样子，不是一块颜色 */
function drawMedModel(cx, cy, s, rarity, opt){
  const o = opt || {};
  const d = MED_DEF[rarity] || MED_DEF.small;
  const big = (rarity === 'big');
  const W = big ? 12.6 : 11, H = big ? 13 : 11.4;
  const R = 3.4, edge = 'rgba(12,16,20,0.55)';
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);

  /* 落地阴影：只在地上画，HUD 和格子里贴着底边不需要 */
  if (o.shadow){
    ctx.save();
    ctx.translate(0, H + 1.2); ctx.scale(1, 0.3);
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    ctx.beginPath(); ctx.arc(0, 0, W*0.86, 0, Math.PI*2); ctx.fill();
    ctx.restore();
  }

  /* 提手：稀有的轮廓特征，站着不动也能和小药分开 */
  if (big){
    ctx.strokeStyle = edge; ctx.lineWidth = 3.2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(0, -H + 2.2, 4.4, Math.PI*1.08, Math.PI*1.92); ctx.stroke();
    ctx.strokeStyle = 'rgba(232,238,244,0.8)'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(0, -H + 2.2, 4.4, Math.PI*1.08, Math.PI*1.92); ctx.stroke();
    ctx.lineCap = 'butt';
  }

  /* 箱体 */
  ctx.fillStyle = d.bg;
  roundRect(-W, -H, W*2, H*2, R); ctx.fill();
  ctx.strokeStyle = edge; ctx.lineWidth = 1.1;
  roundRect(-W, -H, W*2, H*2, R); ctx.stroke();

  /* 盖子：上面那块提亮，做出"俯视看到顶面"的厚度 */
  ctx.fillStyle = 'rgba(255,255,255,0.24)';
  roundRect(-W + 1.3, -H + 1.3, W*2 - 2.6, H*0.92, R*0.7); ctx.fill();

  /* 盖缝 */
  const seamY = -H + 1.3 + H*0.92;
  ctx.strokeStyle = 'rgba(12,16,20,0.32)'; ctx.lineWidth = 1.1;
  ctx.beginPath(); ctx.moveTo(-W + 1.6, seamY); ctx.lineTo(W - 1.6, seamY); ctx.stroke();

  /* 白十字：先垫一圈深色，压在任何底色上都读得出来 */
  const crossY = -H + 1.3 + H*0.46;
  const arm = W*0.44, th = W*0.30;
  ctx.fillStyle = 'rgba(10,14,18,0.30)';
  ctx.fillRect(-arm - 0.7, crossY - th/2 - 0.7, arm*2 + 1.4, th + 1.4);
  ctx.fillRect(-th/2 - 0.7, crossY - arm - 0.7, th + 1.4, arm*2 + 1.4);
  ctx.fillStyle = d.cross || 'rgba(250,253,255,0.97)';
  ctx.fillRect(-arm, crossY - th/2, arm*2, th);
  ctx.fillRect(-th/2, crossY - arm, th, arm*2);

  /* 锁扣 / 缝线：区分两种药，也让箱子有"能打开"的样子 */
  if (big){
    ctx.fillStyle = 'rgba(206,214,222,0.95)';
    roundRect(-3.1, seamY - 1.1, 6.2, 4.4, 1.2); ctx.fill();
    ctx.strokeStyle = 'rgba(10,14,18,0.45)'; ctx.lineWidth = 0.9;
    roundRect(-3.1, seamY - 1.1, 6.2, 4.4, 1.2); ctx.stroke();
    ctx.fillStyle = 'rgba(10,14,18,0.35)';
    ctx.fillRect(-1.9, seamY + 0.5, 3.8, 1.2);
  } else {
    ctx.strokeStyle = 'rgba(10,14,18,0.22)'; ctx.lineWidth = 0.9;
    ctx.setLineDash([2.2, 2.2]);
    roundRect(-W + 2.6, -H + 2.6, W*2 - 5.2, H*2 - 5.2, R*0.6); ctx.stroke();
    ctx.setLineDash([]);
  }

  /* 下缘暗边：箱子是立着的，不是贴在地上的一片纸 */
  ctx.fillStyle = 'rgba(10,14,18,0.16)';
  roundRect(-W + 1.3, H - H*0.26, W*2 - 2.6, H*0.26 - 1.2, R*0.6); ctx.fill();

  ctx.restore();
}

/* 发这一关允许带的装备。带哪几把枪完全由关卡数据里的 weapons 决定，
   没写就只有手枪 —— 以后想给某关加一把枪，改那一行的数组就行。 */
function grantLoadout(L){
  /* weapons:[] 是“这关不发枪”，蠁子也不发（纯逃跑关） */
  const wl = (L && Array.isArray(L.weapons)) ? L.weapons : ['pistol'];
  player.guns = {};
  for (const w of wl){
    if (!WEAPONS[w]) continue;
    /* 战斗，爽！！：火箭筒开局一发都没有 —— 弹药拿卡换，见 arenaRocketMax() */
    player.guns[w] = makeGun(w, (ar && w === 'rpg') ? 0 : undefined);
  }
  player.wid = player.guns[wl[0]] ? wl[0] : Object.keys(player.guns)[0];
  player.gun = player.guns[player.wid] || null;
  player.ammo = startingAmmo(Object.keys(player.guns).map(gunModel));
  /* 关卡可以单独指定开局备弹（只影响写了 startAmmo 的关） */
  if (L && L.startAmmo) for (const _ak in L.startAmmo) player.ammo[_ak] = L.startAmmo[_ak];
  player.meds = {small: (L && L.startMeds != null) ? L.startMeds : 1, big: (L && L.startMedsBig != null) ? L.startMedsBig : 0};
  /* 投掷位永远给一个槽，没货就显示 0 —— Q 的顺序才稳定 */
  const sm0 = (L && L.startSmokes != null) ? L.startSmokes : 2;
  player.guns.smoke = makeGun('smoke', sm0);
  player.grenades = sm0;
  /* ver3：开局发的枪只把前两把拿在手上，多出来的留在包里不给用（目前没有关卡发 3 把） */
  player.slots = [null, null, null, null];
  if (bagGridOn()){
    const _real = wl.filter(w => WEAPONS[w] && w !== 'smoke');
    /* 按类别装：长枪最多两把（主武器 1/2），手枪/信号枪一把（副武器），刀一把（近战） */
    let _mainN = 0, _sideN = 0, _meleeN = 0;
    for (const _w of _real){
      const _cls = gunClass(_w);
      if (_cls === 'side'){
        if (_sideN < 1 && !player.slots[GUN_SIDE_SLOT]){ player.slots[GUN_SIDE_SLOT] = _w; _sideN++; }
      } else if (_cls === 'melee'){
        if (_meleeN < 1 && !player.slots[GUN_MELEE_SLOT]){ player.slots[GUN_MELEE_SLOT] = _w; _meleeN++; }
      } else if (_mainN < 2 && !player.slots[_mainN]) {
        player.slots[_mainN] = _w; _mainN++;
      }
    }
    if (!player.slots.some(w => w && player.guns[w])) player.slots = [null, null, null, null];
  }
  /* ver3：把这一关开局给的药 / 烟 / 子弹摊进格子 —— 装不下的会掉在地上，
     所以 4-1 那种"开局 39 格 > 36 格"的老关卡要么写 rules.bagInfinite，要么发少点 */
  player.bagItems = [];
  if (bagGridOn()) bagInitFromLoadout();
  player.heal = null;
  player.kickX = 0; player.kickY = 0;
  /* 这一关的敌人要有血，才谈得上"打伤" */
  for (const e of enemies){
    if (enemyType(e).static || enemyType(e).fly) continue;
    if (e.maxHp === undefined) e.maxHp = (L && L.enemyHp) || 100;
    if (e.hp === undefined) e.hp = e.maxHp;
  }
}

function resetTestZone(){
  const L = cur();
  grantLoadout(L);
  poolClearView(dmgNums);
  poolClearView(hurtNums);
  poolClearView(fxParts); hitMarks = []; rocketTrail = []; hitStopT = 0; punchT = 0;
  if (typeof rocketFxClear === 'function') rocketFxClear();   /* 别让上一局的残留特效跟着进来 */
  splats = []; bloodMarks = []; scorchMarks = []; blastRings = []; fxFlash = 0; slowT = 0; zoomP = 0; critFlash = 0;
  player.kickX = 0; player.kickY = 0;
  ui.inv.open = false;
  for (const e of enemies){
    if (enemyType(e).static || enemyType(e).fly) continue;
    e.hp = 100; e.maxHp = 100;
  }
  logInfo('test', '测试区就绪 · 手枪/霰弹枪/AR15（F 换枪）· 小药 ×1');
  setMsg('测试区 · 看不见的地方没有人影（视距 ' + Math.round(CFG.pVision) +
         ' · 视角 ' + Math.round(CFG.pFov) + '°）', 3.4);
}

/* 后坐力推人：沿着弹道的反方向把玩家自己往后顶。
   一小步一小步试，撞到墙就停在墙边 —— 所以贴墙开枪不会被推穿墙，也不会滑出去。 */
function pushPlayerBack(dist){
  const L = cur();
  if (!L || !L.walls) return;
  const sx = -Math.cos(player.aim), sy = -Math.sin(player.aim);
  let left = dist;
  while (left > 0.5){
    const step = Math.min(3.5, left);
    const nx = player.x + sx*step, ny = player.y + sy*step;
    const probe = {x:nx, y:ny};
    for (const w of L.walls) pushOutCircle(probe, player.r, w);
    for (const d of doors) if (doorSolid(d)) pushOutCircle(probe, player.r, d);
    if (Math.hypot(probe.x - nx, probe.y - ny) > 0.6) break;   /* 贴墙了，推不动 */
    player.x = clamp(probe.x, 16, L.w-16);
    player.y = clamp(probe.y, 16, L.h-16);
    left -= step;
  }
}

/* ---------------- 近战：刀 ----------------
   判定是瞬时的，屏幕上那道弧只是画给你看的。
   站在最里面的人吃满伤害，擦到边上的只剩六成。 */
let meleeT = 0, meleeA = 0;
let meleeTrail = [];   /* 突进时的拖尾重影 */

/* 近战音效：两个源文件各自含多段（挥刀 4 段 / 砍中 3 段），
   进来之后按能量过渡找切点，弹出来一组片段再随机抽。 */
let bladeSwingBuf = null, bladeHitBuf = null;
let bladeSwingSeeds = [], bladeHitSeeds = [];
let bladeDecoded = false;
function bladeSplit(buf, want, tag){
  const sr = buf.sampleRate, ch = buf.getChannelData(0);
  const win = Math.max(1, Math.round(sr * 0.02));      /* 20ms 一个窗 */
  const n = Math.floor(ch.length / win);
  const rms = new Float32Array(n);
  let peak = 0;
  for (let i = 0; i < n; i++){
    let e = 0;
    for (let k = 0; k < win; k++){ const v = ch[i*win + k] || 0; e += v*v; }
    rms[i] = Math.sqrt(e / win);
    if (rms[i] > peak) peak = rms[i];
  }
  if (!(peak > 0)) return [];
  const wantN = Math.max(1, want | 0);
  const thr = peak * 0.18;
  if (wantN === 1) return [{a: 0, d: Math.min(0.9, buf.duration)}];
  /* 文件是几段拼起来的，每段长度差不多：
     先按数量均分，再把刀口往附近最安静的那个窗口上对齐。 */
  const picked = [];
  const slot = n / wantN;
  for (let k = 1; k < wantN; k++){
    const target = Math.round(n * k / wantN);
    const span = Math.max(2, Math.round(slot * 0.42));
    let best = target, bv = Infinity;
    const lo = Math.max(1, target - span), hi = Math.min(n - 2, target + span);
    for (let i2 = lo; i2 <= hi; i2++){
      if (rms[i2] < bv){ bv = rms[i2]; best = i2; }
    }
    picked.push({i: best, v: bv});
  }
  picked.sort((x, y) => x.i - y.i);
  const bounds = [0].concat(picked.map(p => p.i), [n]);
  const segs = [];
  for (let k = 0; k + 1 < bounds.length; k++){
    let a = bounds[k], b = bounds[k+1];
    while (a < b && rms[a] < thr * 0.7) a++;
    while (b > a && rms[b-1] < thr * 0.7) b--;
    if (b - a < 2) continue;
    const t0 = a * win / sr, t1 = Math.min(buf.duration, b * win / sr);
    segs.push({a: t0, d: Math.max(0.04, Math.min(1.0, t1 - t0))});
  }
  return segs.slice(0, wantN);
}

function bladeDecode(){
  if (bladeDecoded || !actx) return;
  bladeDecoded = true;
  if (window.BLADE_SWING_SRC){
    b64ToBuf(window.BLADE_SWING_SRC, b => {
      bladeSwingBuf = b;
      bladeSwingSeeds = bladeSplit(b, 4, 'swing');
    }, () => {});
  }
  if (window.BLADE_HIT_SRC){
    b64ToBuf(window.BLADE_HIT_SRC, b => {
      bladeHitBuf = b;
      bladeHitSeeds = bladeSplit(b, 3, 'hit');
    }, () => {});
  }
}
function playBladeSeed(buf, seeds, vol, rate){
  if (!actx || !buf || !seeds.length) return false;
  const sd = seeds[Math.floor(Math.random() * seeds.length)];
  const src = actx.createBufferSource();
  src.buffer = buf;
  src.playbackRate.value = rate * (0.94 + Math.random() * 0.12);
  const g = actx.createGain();
  g.gain.value = vol;
  src.connect(g); g.connect(duckBus());
  src.start(actx.currentTime, sd.a, sd.d);
  src.onended = () => { try{ src.disconnect(); g.disconnect(); }catch (e){ if (typeof reportErr === 'function') reportErr('32-baggrid', e); } };
  return true;
}
function sfxBladeSwing(){
  if (playBladeSeed(bladeSwingBuf, bladeSwingSeeds, 0.42, 1.0)) return;
  beep(760, 0.09, 'sawtooth', 0.05, 260);
  noiseBurst(0.12, 2600, 0.10, 1.4);
}
function sfxBladeHit(){
  if (playBladeSeed(bladeHitBuf, bladeHitSeeds, 0.62, 1.0)) return;
  beep(180, 0.12, 'square', 0.09, 90);
  noiseBurst(0.10, 900, 0.16, 0.8);
}

function meleeSwing(g){
  /* 正常武器都会自带 reach/arc；兼容旧档或测试残缺对象时，也从战术刀权威定义兜底。 */
  const _meleeBase = WEAPONS.knife;
  const reach = g.reach || _meleeBase.reach, half = (g.arc || _meleeBase.arc) / 2;
  const ax = player.x, ay = player.y, a = player.aim;
  /* 体力：没体力挥不动；体力越低砍得越轻，所以不能把冲刺当赶路用 */
  const _staMax = player.meleeStaMax || 100;
  const _cost = (g.wid === 'dao') ? 20 : 16;
  if ((player.meleeSta || 0) < _cost){
    setMsg('体力不够 · 挥不动了', 1.2);
    beep(150, 0.10, 'square', 0.045, 120);
    return;
  }
  const _staK = 0.62 + 0.38 * clamp((player.meleeSta || 0) / _staMax, 0, 1);
  player.meleeSta = Math.max(0, (player.meleeSta || 0) - _cost);
  player.meleeStaDelay = 1.0;
  meleeT = 0.20; meleeA = a;
  /* 没有前摇：出手的同一帧人就蹲出去；落手后 0.22 秒走不动，那下停顿就是手感 */
  player.lungeT = 0.13; player.lungeA = a;
  player.recoverT = 0.22;
  player.lungeSpeed = (g.wid === 'dao') ? 560 : 500;
  meleeTrail.length = 0;
  sfxBladeSwing();
  let n = 0;
  for (const e of enemies.slice()){
    if (e.dead) continue;
    const dx = e.x - ax, dy = e.y - ay, d = Math.hypot(dx, dy);
    if (d > reach + (e.r || 12)) continue;
    if (Math.abs(normAng(Math.atan2(dy, dx) - a)) > half) continue;
    if (losBlocked(ax, ay, e.x, e.y)) continue;
    const k = 1 - 0.40 * clamp(d / reach, 0, 1);
    const _raw = oneShotOn() ? 999999 : Math.round(g.dmg * k * _staK);
    const dmg = absorbEnemyArmor(e, _raw, 'blade');
    e.hp = (e.hp === undefined ? 100 : e.hp) - dmg;
    if(typeof factionNoteDamage==='function')factionNoteDamage(e,player,dmg,'blade');
    const killed = e.hp <= 0;
    registerHit(e, Math.atan2(dy, dx), dmg, killed, false);
    spawnDamageNum(e.x, e.y-30, dmg, killed, false);
    dummyRecord(e, dmg, false);
    /* 刀砍在肉上的一下：血、火星、刀光、定格 */
    impactFx(e.x, e.y, Math.atan2(dy, dx), true, 26, false);
    slashFx.push({x: e.x, y: e.y, a: Math.atan2(dy, dx), t: 0, dur: 0.22});
    if (killed) killTestEnemy(e);
    else alertByHit(e, Math.atan2(dy, dx));
    if (n === 0) sfxBladeHit();
    n++;
  }
  gunNoise(0.35);                 /* 刀几乎没声：只够贴隔壁的人听见 */
  /* 车壳：刀砍不动载具（不掉血），但要有火星 + 金属声，
     不然玩家会以为这一刀"空了"。 */
  for (const t of trucks){
    if (!t || t.tstate === 'gone') continue;
    const rc = truckRect(t);
    const nx = clamp(ax, rc.x, rc.x + rc.w), ny = clamp(ay, rc.y, rc.y + rc.h);
    const td = Math.hypot(nx - ax, ny - ay);
    if (td > reach + 8) continue;
    if (Math.abs(normAng(Math.atan2(ny - ay, nx - ax) - a)) > half) continue;
    /* m19444：刀砍在车壳上只崩火星、打不掉血 —— 伤害走枪/爆炸那套，别用刀拆车。 */
    truckSparks(nx, ny, Math.atan2(ny - ay, nx - ax));
    if (n === 0) sfxBladeHit();
    n++;
  }
  if (n){ camShake = Math.max(camShake, 0.34); hitStopT = Math.max(hitStopT, 0.05); }
}

/* 玩家手持道具：沿用盾卫原来的蓝色小盾造型，不改敌人模型或减伤规则。 */
function playerShieldUp(){return !!(player && player.hasShield && player.shieldRaised && player.hp>0)}
function togglePlayerShield(){
  player.shieldRaised=!player.shieldRaised;mouse.fire=false;mouse.down=false;
  setMsg(player.shieldRaised?'举盾 · 正面挡弹 · G 收起 / F 换枪':'盾牌已收起 · G 再次举盾',1.8);
}
/* Q：手上有盾就丢在脚边（带着剩余耐久），没盾就捡起脚边那面。
   以前这里只在测试区生效，而且拿着盾按 Q 反而提示"已拿起"，正式关里根本丢不掉。 */
function shieldLootNear(){
  let best = null, bd = 1e9;
  for (const l of loots){
    if (l.taken || l.kind !== 'shield') continue;
    const d = dist(player.x, player.y, l.x, l.y);
    if (d < 46 && d < bd){ bd = d; best = l; }
  }
  return best;
}
function dropPlayerShield(){
  if (state !== 'play' || !player || player.hp <= 0) return false;
  if (player.hasShield){
    const hp = (typeof player.shieldHp === 'number') ? player.shieldHp : SHIELD_MAX_HP;
    /* 丢在朝向前方一点，别和身体叠在一起 */
    const a = (player.aim || 0) + fxRand(-0.25, 0.25);
    loots.push({ kind:'shield', x: player.x + Math.cos(a) * 26, y: player.y + Math.sin(a) * 26,
                 cool: 0.7, taken:false, killDrop:true, shieldHp: hp });
    player.hasShield = false; player.shieldRaised = false;
    mouse.fire = false; mouse.down = false;
    setMsg('防弹盾牌丢在脚边 · 耐久 ' + Math.round(hp) + ' / ' + SHIELD_MAX_HP + ' · 按 Q 再捡起来', 2.4);
    sfxPick();
    return true;
  }
  const l = shieldLootNear();
  if (l){
    if (LOOT_KINDS.shield.take(l)){ l.taken = true; return true; }
    return false;
  }
  setMsg('手上没有盾牌，脚边也没有可捡的盾', 1.6);
  return false;
}
/* 盾牌被子弹打穿：耐久归零就碎 */
function breakPlayerShield(){
  const x = player.x + Math.cos(player.aim || 0) * 16;
  const y = player.y + Math.sin(player.aim || 0) * 16;
  for (let i = 0; i < 12; i++)
    spawnPart(x, y, fxRand(0, TAU), fxRand(60, 240), fxRand(0.18, 0.42), 'mspark', 1.5);
  trimFx();
  player.hasShield = false; player.shieldRaised = false;
  player.shieldHp = 0; mouse.fire = false; mouse.down = false;
  camShake = Math.max(camShake, 0.45);
  sfxMetalHit(x, y);
  setMsg('盾牌被打穿了 · 600 点耐久耗光', 2.6);
  logWarn('shield', '防弹盾牌耐久归零，碎了');
}
function drawPlayerShieldModel(x,y,r,a,hit){
  /* 俯视举盾 = 身前一块半圆的钢板，整片罩住正面（-1.2..1.2 rad）。
     试过的都失败了：顺着瞄准方向的窄长条像刀片/手机，扇形弧带像铁链，
     盾形轮廓（上宽下尖）在俯视下像铲子。俯视时装"一整片挡在身前"最好认。 */
  ctx.save();
  ctx.translate(x,y); ctx.rotate(a);
  const RI = r + 1.6;          /* 内缘贴着身体 */
  const RO = r + 13.0;         /* 外缘 */
  const SP = 1.20;             /* 半张角 */
  const plate = function(){
    ctx.beginPath();
    ctx.arc(0, 0, RO, -SP, SP);
    ctx.arc(0, 0, RI, SP, -SP, true);
    ctx.closePath();
  };
  /* 1. 地面阴影：往身后错一点，读成"立起来压在地上的" */
  ctx.save();
  ctx.translate(0.8, 2.6);
  ctx.globalAlpha *= 0.32;
  ctx.fillStyle = '#000';
  plate(); ctx.fill();
  ctx.restore();
  /* 2. 板面：从内缘到外缘的渐变，内外都压暗、中段最亮 */
  const g = ctx.createRadialGradient(0, 0, RI, 0, 0, RO);
  g.addColorStop(0.00, '#5b6670');
  g.addColorStop(0.35, '#b9c6d0');
  g.addColorStop(0.72, '#d6e0e8');
  g.addColorStop(1.00, '#6a7681');
  ctx.fillStyle = g;
  plate(); ctx.fill();
  /* 3. 包边 */
  ctx.strokeStyle = '#20272e'; ctx.lineWidth = 1.8; ctx.lineJoin = 'round';
  plate(); ctx.stroke();
  /* 4. 外缘高光 + 内缘暗边，把"厚度"读出来 */
  ctx.strokeStyle = 'rgba(240,248,253,0.8)'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.arc(0, 0, RO - 1.5, -SP + 0.06, SP - 0.06); ctx.stroke();
  ctx.strokeStyle = 'rgba(22,30,38,0.45)'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.arc(0, 0, RI + 1.2, -SP + 0.1, SP - 0.1); ctx.stroke();
  /* 5. 观察窗（横一道）+ 三颗铆钉 */
  ctx.fillStyle = 'rgba(20,28,36,0.55)';
  roundRect(RI + 3.6, -3.2, 5.0, 6.4, 1.8); ctx.fill();
  ctx.fillStyle = '#39434d';
  for (const ang of [-0.82, 0, 0.82]){
    ctx.beginPath();
    ctx.arc(Math.cos(ang) * (r + 7.4), Math.sin(ang) * (r + 7.4), 1.5, 0, TAU);
    ctx.fill();
  }
  /* 6. 命中白闪 */
  if (hit > 0){
    ctx.globalAlpha *= hit * 0.85;
    ctx.fillStyle = '#eef7ff';
    plate(); ctx.fill();
  }
  ctx.restore();
}
/* 地上/界面里的独立小盾牌图标：居中、上宽下尖的整块盾面。
   drawPlayerShieldModel 是"玩家贴着身体举着"的半个弧，从 x0 一路伸到 xo，
   拿去当地上图标会偏到右边、又窄又长（看起来像个竖椭圆），所以这里另画一个。 */
function drawShieldIcon(cx, cy, s){
  s = s || 1;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  const w = 9.6, top = -11.4, bot = 12.6;
  const face = function(k){
    const ww = w - k, tt = top + k, bb = bot - k * 1.3;
    const hh = bb - tt;
    ctx.beginPath();
    ctx.moveTo(-ww + 2.6, tt);
    ctx.lineTo(ww - 2.6, tt);
    ctx.quadraticCurveTo(ww, tt, ww, tt + 2.4);
    ctx.lineTo(ww, tt + hh * 0.46);
    ctx.quadraticCurveTo(ww, bb - hh * 0.24, ww * 0.54, bb - hh * 0.10);
    ctx.quadraticCurveTo(0, bb + 1.4, -ww * 0.54, bb - hh * 0.10);
    ctx.quadraticCurveTo(-ww, bb - hh * 0.24, -ww, tt + hh * 0.46);
    ctx.lineTo(-ww, tt + 2.4);
    ctx.quadraticCurveTo(-ww, tt, -ww + 2.6, tt);
    ctx.closePath();
  };
  /* 1. 深色包边 */
  ctx.fillStyle = '#2b343c';
  face(-1.5); ctx.fill();
  /* 2. 钢面：横向明暗（左暗 → 高光 → 右灰），和举盾那套保持一致 */
  const g = ctx.createLinearGradient(-w, 0, w, 0);
  g.addColorStop(0.00, '#6b7883');
  g.addColorStop(0.34, '#b3c0cb');
  g.addColorStop(0.52, '#eef4fa');
  g.addColorStop(0.70, '#9dabb7');
  g.addColorStop(1.00, '#5d6a75');
  ctx.fillStyle = g;
  face(0); ctx.fill();
  /* 3. 观察窗 + 中缝护条 */
  ctx.fillStyle = 'rgba(20,28,35,0.62)';
  roundRect(-4.6, top + 4.2, 9.2, 3.6, 1.3); ctx.fill();
  ctx.fillStyle = 'rgba(26,35,43,0.34)';
  ctx.fillRect(-1.5, top + 9.4, 3.0, (bot - top) * 0.52);
  /* 4. 铆钉 */
  ctx.fillStyle = '#333d46';
  for (const yy of [top + 9.6, top + 16.4, bot - 3.2]){
    ctx.beginPath(); ctx.arc(0, yy, 1.05, 0, TAU); ctx.fill();
  }
  ctx.restore();
}
function drawHeldPlayerShield(){
  if(!playerShieldUp())return;
  const age=uiT-(player.shieldHitAt===undefined?-1:player.shieldHitAt);
  const hit=age>=0&&age<.24?1-age/.24:0;
  const a=player.aim||0,kick=hit*Math.sin(age*80)*1.5;
  drawPlayerShieldModel(player.x-Math.cos(a)*kick,player.y-Math.sin(a)*kick,player.r,a,hit);
}
function playerShieldBulletHit(b){
  if(!playerShieldUp())return null;
  const a=player.aim||0,incoming=Math.atan2(b.vy,b.vx)+Math.PI;
  if(Math.abs(normAng(incoming-a))>Math.PI/3+1e-9)return null;
  // 用整段飞行轨迹与盾前扇形相交，低帧率高速弹也不会一步跨过盾。
  const ox=b.px-player.x,oy=b.py-player.y,dx=b.x-b.px,dy=b.y-b.py,R=player.r+12;
  const A=dx*dx+dy*dy,C=ox*ox+oy*oy-R*R;
  if(A<1e-10)return null;
  let t=0;
  if(C>0){const B=2*(ox*dx+oy*dy),disc=B*B-4*A*C;if(disc<0)return null;t=(-B-Math.sqrt(disc))/(2*A)}
  if(t<0||t>1)return null;
  const x=b.px+dx*t,y=b.py+dy*t;
  if(Math.hypot(x-player.x,y-player.y)<player.r || Math.abs(normAng(Math.atan2(y-player.y,x-player.x)-a))>Math.PI/3+1e-9)return null;
  return {x,y};
}
function playerShieldImpact(b,hit){
  if(player.shieldHitAt!==undefined&&uiT-player.shieldHitAt>=0&&uiT-player.shieldHitAt<.035)return;
  player.shieldHitAt=uiT;const a=Math.atan2(b.vy,b.vx);
  for(let i=0;i<6;i++)spawnPart(hit.x,hit.y,a+Math.PI+fxRand(-.8,.8),fxRand(180,420),fxRand(.1,.24),'mspark',1.6);
  sfxMetalHit(hit.x,hit.y);trimFx();
  /* 耐久：挡一发扣这一发伤害的一半（步枪一发 30 → 15 点，600 点扛 40 发；
     霰弹每颗弹丸都算一次，贴脸挨一枪掉得飞快） */
  if (player.hasShield){
    if (typeof player.shieldMaxHp !== 'number') player.shieldMaxHp = SHIELD_MAX_HP;
    if (typeof player.shieldHp !== 'number') player.shieldHp = player.shieldMaxHp;
    const cost = Math.max(1, (b.dmg || 10) * 0.5);
    player.shieldHp = Math.max(0, player.shieldHp - cost);
    if (player.shieldHp <= 0){ breakPlayerShield(); return; }
    if (player.shieldHp < player.shieldMaxHp * 0.25 && !player.shieldLowWarned){
      player.shieldLowWarned = true;
      setMsg('盾牌耐久只剩 ' + Math.round(player.shieldHp) + ' · 快撑不住了', 1.8);
    }
    if (player.shieldHp > player.shieldMaxHp * 0.35) player.shieldLowWarned = false;
  }
}

/* ---------------- 火箭筒 ----------------
   一发飞出去的弹丸（不是射线）：撞到东西才炸。
   · 撞玻璃：引信不响，玻璃碎、弹继续飞
   · 撞可破坏墙：炸，墙吃一大坨伤害（专门用来拆掩体）
   · 撞死墙（不可破坏）：炸，但不穿墙伤人
   · 打中人/敌人：以接触点为中心炸
   爆炸伤害越靠近中心越高（和疯狗同一条曲线），护甲掉耐额外放大。 */
/* 兼容旧消费者的只读别名；权威数值统一在 data/items.js 的 ROCKET_DEF。 */
const ROCKET_SPD = ROCKET_DEF.speed;
const ROCKET_LIFE = ROCKET_DEF.projectileLife;
const ROCKET_BODY_R = ROCKET_DEF.projectileRadius;
/* 载具是铁疙瘩：火箭弹本来就是反装甲的，对运兵车单独给个倍率。
   车 900 血、车体减伤 35%，不给倍率的话一发只进 98，十发都打不烂一辆车。 */
const ROCKET_DMG_VEHICLE = ROCKET_DEF.vehicleDamageK;
/* 火箭筒的"动静"比枪大得多：发射是一记闷响 + 一大团尾焰，爆炸更是整层楼都听得见。
   这里是 hearR 的倍数（默认 hearR 340 → 普通枪声 2.2≈750px / 发射 3.4≈1150px / 爆炸 4.6≈1560px）。 */
const ROCKET_NOISE_FIRE  = ROCKET_DEF.noiseFire;
const ROCKET_NOISE_BLAST = ROCKET_DEF.noiseBlast;
/* 【火箭筒扩容】的第二发：同一发弹药、0.12 秒后自己出膛。
   隔一点时间是故意的 —— 齐射两发在同一帧结算，等于凭空把中心伤害翻成 300，
   那是变相暴击；错开之后两发各自按距离算，观感上才像"连装两管"。 */
const ROCKET_BURST_GAP = 0.12;
/* 战斗，爽！！专属的伤害倍率。
   故事关里 150 中心伤害是"一炮换半个掩体 + 打掉两个小兵"的量级，是对的；
   割草里小兵几百血、BOSS 几千到一万多血，同一发炮就变成挠痒。
   所以只在这个模式里放大：基础 ×6，并且随波次线性再长（每波 +6%），
   追得上"波次越高血越厚"的曲线，但永远是一发换一发、得拿卡位换。 */
const ROCKET_ARENA_K = 6;
const ROCKET_ARENA_WAVE_K = 0.06;
function arenaRocketDmgK(){
  if (!ar) return 1;
  const w = Math.max(1, ar.wave | 0);
  return ROCKET_ARENA_K * (1 + ROCKET_ARENA_WAVE_K * (w - 1)) * (ar.dmgMul || 1);
}
/* 割草里火箭筒的换弹时间砍半：弹匣只有 1 发，3.4 秒装一发意味着"开完就站着看"，
   爽不起来。故事关不动 —— 那里的 3.4 秒是跟敌人数量配套的。 */
const ARENA_ROCKET_RELOAD_K = 0.5;
/* 割草地上最多留几件战利品。
   以前是 40 件且永不消失：满血时药包捡不走，一波几十只死下来整张图都是药；
   再加上捡走的东西从来不清出数组，打久了单是遍历就白扔掉不少帧时间。
   20 件封顶就够吃了 —— 不做过期消失，东西躺多久都在，看得见就不会觉得被吞。
   故事关不受这条影响。 */
const ARENA_LOOT_MAX = 20;
