/* ============================ BOSS 能力通用执行器 ============================
   这里只有"怎么做"，"做多少"都在 data/bosses.js。
   加能力 = 在 ABILITY_DEF 里写参数 + 在这张表里写一个函数。
   ============================================================================ */
function bossPhaseOf(e, kit){
  if (!kit || !kit.phases) return null;
  const f = e.maxHp > 0 ? (e.hp / e.maxHp) : 1;
  let hit = null;
  for (const p of kit.phases) if (f <= p.below) hit = p;
  return hit;
}
function bossDmgOf(e, mul, ph, capK){
  let d = CFG.eDmg * mul * (e.dmgK || 1) * (ph && ph.dmgK ? ph.dmgK : 1) * (1 - ((ar && ar.armor) || 0));
  /* 天花板：不管难度多高，一发最多打掉玩家最大生命的一个比例。
     自爆给 42%，冲撞/盾撞 30% —— 噩梦前几波也不会一刀带走。 */
  const maxHp = (ar && typeof arenaMaxHp === 'function') ? arenaMaxHp() : CFG.hp;
  const cap = maxHp * (capK || BOSS_SCALE.dashCapK);
  if (d > cap) d = cap;
  return d;
}

/* 冲刺类技能的两个小工具（督军 charge / 盾卫 shove 共用）
   ——窄地形里硬锁玩家方向，一出手就顶墙，技能等于白给。
   出手前在 ±cone 里挑"能跑最远"的方向；撞墙就沿墙面滑，不是愣在那儿。 */
function dashPickDir(x, y, want, cone, maxLen){
  const n = 7;
  let bestA = want, bestF = -1;
  for (let i = 0; i < n; i++){
    const a = want + (i / (n - 1) - 0.5) * 2 * cone;
    const f = rayToWall(x, y, a, maxLen);
    /* 离目标方向越近的给一点加权，别为了绕路冲得莫名其妙 */
    const w = 1 - 0.22 * Math.abs(i / (n - 1) - 0.5) * 2;
    if (f * w > bestF){ bestF = f * w; bestA = a; }
  }
  return { ang: bestA, free: bestF };
}
function dashSlideDir(x, y, dir){
  const a = dir + Math.PI / 2, b = dir - Math.PI / 2;
  const fa = rayToWall(x, y, a, 520), fb = rayToWall(x, y, b, 520);
  return fa >= fb ? a : b;
}

const ABIL_RUN = {
  /* 自爆：点火 → 炸 → 后摇 → 再点 */
  blast(e, dt, c, ph, d, kit){
    const R = c.radius;
    if (e.boomRecover > 0){
      e.boomRecover -= dt;
      e.spdK = 0.5;
      if (e.boomRecover <= 0){ e.fuseCd = 0.45; e.chaseT = 0; }
      return;
    }
    if (e.fuse > 0){
      e.fuse -= dt;
      e.spdK = 2.05;
      if ((e.fuse * 12 | 0) !== ((e.fuse + dt) * 12 | 0)) beep(520, 0.035, 'square', 0.05, 300);
      if (e.fuse > 0) return;
      const fall = Math.max(c.minFall, 1 - 0.62 * clamp(d / R, 0, 1));
      if (d < R && !player.god){
        const dmg = guardDamage(bossDmgOf(e, c.dmgMul, ph, BOSS_SCALE.blastCapK) * fall);
        player.hp -= absorbArmor(dmg, 'blast'); hurtNum(dmg);
        if (player.hp <= 0) markDeath('blast', e, dmg, Math.atan2(player.y - e.y, player.x - e.x));
        player.flash = 1; hitFlash = 1; camShake = Math.max(camShake, 1.2);
        /* m36675：被疯狗炸到也糊一下（跟督军撞人同一套观感），
           但它没有僵直，所以走 blurFastT 快退通道 —— 糊得重、散得快 */
        visionBlur = Math.max(visionBlur, 0.82);
        visionBlind = Math.max(visionBlind, 0.46);
        blindAlphaK = 0.40;
        visionBlurHold = 0;
        blurFastT = Math.max(blurFastT, 0.55);
        stOnHurt(dmg, 'blast');
        hurtDir(Math.atan2(player.y - e.y, player.x - e.x), dmg);
        logWarn('hurt', '被' + (kit.label || '它') + '炸到 · -' + Math.round(dmg) + ' HP');
      }
      bossBlastFx(e.x, e.y, R);
      beep(64, 0.5, 'sawtooth', 0.26, 30);
      noiseBurst(0.55, 560, 1.0, 1.15);
      setMsg(d < R ? '被炸到了' : '它原地炸了', 1.1);
      for (const o of enemies.slice()){
        if (o === e || o.dead) continue;
        if (dist(o.x, o.y, e.x, e.y) < R){ o.hp -= 18; if (o.hp <= 0) killTestEnemy(o); }
      }
      if (kit.scorch) scorchMarks.push({ x: e.x, y: e.y, r: R * 0.62, t: 0 });
      e.boomRecover = c.recover;
      e.fuse = 0; e.fuseCd = 99;
      logWarn('boss', (kit.label || '疯狗') + '自爆 · 后摇 ' + c.recover + ' 秒');
      return;
    }
    e.fuseCd = (e.fuseCd || 0) - dt;
    e.chaseT = (e.chaseT || 0) + dt;
    if (e.fuseCd <= 0 && (e.sees || e.mode === 1) && (d < c.fireAt || e.chaseT > c.chaseLimit)){
      e.fuse = c.fuse; e.fuse0 = c.fuse; e.chaseT = 0;
      setMsg((kit.label || '疯狗') + '点火了 · 跑', 1.2);
      beep(320, 0.10, 'square', 0.10, 200);
      logWarn('boss', (kit.label || '疯狗') + '点火 · 距离 ' + Math.round(d));
    }
  },

  /* 冲锋：预判 + 连段 */
  charge(e, dt, c, ph, d){
    if (e._pvx === undefined){ e._pvx = 0; e._pvy = 0; }
    const sdt = Math.max(dt, 0.008);
    const vx = clamp((player.x - (e._lx === undefined ? player.x : e._lx)) / sdt, -420, 420);
    const vy = clamp((player.y - (e._ly === undefined ? player.y : e._ly)) / sdt, -420, 420);
    e._lx = player.x; e._ly = player.y;
    e._pvx = e._pvx * 0.7 + vx * 0.3; e._pvy = e._pvy * 0.7 + vy * 0.3;
    const aimX = player.x + e._pvx * c.lead;
    const aimY = player.y + e._pvy * c.lead;
    const cd = c.cd * (ph && ph.cdK ? ph.cdK : 1);

    e.bossCd = (e.bossCd === undefined ? 5.0 : e.bossCd) - dt;
    if (e.wDashT > 0){
      e.wDashT -= dt;
      const step = c.speed * (e._slide ? (c.slideK || 0.78) : 1) * dt;
      const nx = e.x + Math.cos(e.wDashDir) * step;
      const ny = e.y + Math.sin(e.wDashDir) * step;
      const hitWall = cur().walls.some(w => nx > w.x - e.r && nx < w.x + w.w + e.r &&
                                         ny > w.y - e.r && ny < w.y + w.h + e.r);
      const hitP = dist(nx, ny, player.x, player.y) < e.r + player.r + 6;
      /* 撞墙：第一次改成贴着墙滑，不在这儿停住（窄走廊也能冲起来） */
      if (hitWall && !hitP && !e._slide){
        const _sd = dashSlideDir(e.x, e.y, e.wDashDir);
        if (rayToWall(e.x, e.y, _sd, (c.slideMin || 120) + e.r) > (c.slideMin || 120) * 0.5){
          e._slide = true; e.wDashDir = _sd;
          camShake = Math.max(camShake, 0.55);
          impactWallFx(e.x + Math.cos(_sd) * e.r, e.y + Math.sin(_sd) * e.r, _sd);
          noiseBurst(0.22, 900, 0.35, 1.4);
          return;
        }
      }
      if (hitWall || hitP || e.wDashT <= 0){
        e.wDashT = 0;
        e._slide = false;
        const more = (e.wBurst || 0) > 1;
        if (more){ e.wBurst--; e.wWind = 0.16; }
        else { e.wBurst = 0; e.bossCd = cd; }
        if (hitWall){ camShake = Math.max(camShake, 0.7); impactWallFx(nx, ny, e.wDashDir); beep(80,0.3,'sawtooth',0.14,40); }
        if (hitP){
          if (!player.god){
            const dmg = guardDamage(bossDmgOf(e, c.dmgMul, ph));
            player.hp -= absorbArmor(dmg, 'blast'); hurtNum(dmg); player.flash = 1; hitFlash = 1;
            if (player.hp <= 0) markDeath('dash', e, dmg, e.wDashDir);
            stOnHurt(dmg, 'blast');
            hurtDir(e.wDashDir, dmg);
            /* 撞飞 + 眩晕：往后甩一段，这半秒不能动也不能开枪 */
            const _kb = (c.kb || 2100), _stun = (c.stun || 0.62);
            player.kickX = Math.cos(e.wDashDir) * _kb;
            player.kickY = Math.sin(e.wDashDir) * _kb;
            player.stunT = Math.max(player.stunT || 0, _stun);
            /* 复用重击的视觉，但糊得快退得也快、红屏更淡 */
            visionBlur = Math.max(visionBlur, (c.stunBlur || 0.74));
            visionBlind = Math.max(visionBlind, (c.stunBlind || 0.50));
            blindAlphaK = (c.stunAlpha || 0.42);
            camShake = Math.max(camShake, 1.9);
            hitStopT = Math.max(hitStopT, 0.13);
            bossBlastFx(player.x, player.y, 46);
            slamBurst(player.x, player.y, e.wDashDir + Math.PI, 11);
            sfxSlam(true);
            sfxThud();
            /* 撞上去要有反作用力：督军自己也被顶回去一点 */
            e.x -= Math.cos(e.wDashDir) * 26;
            e.y -= Math.sin(e.wDashDir) * 26;
            logWarn('hurt', '被督军撞飞 · -' + Math.round(dmg) + ' HP · 眩晕 ' + _stun.toFixed(2) + 's');
          }
          setMsg('被督军撞飞了 · 站不稳', 1.3);
        }
      } else {
        e.x = nx; e.y = ny; e.ang = e.wDashDir; e.shieldAng = e.wDashDir;
      }
      return;
    }
    if (e.wWind > 0){
      e.wWind -= dt;
      if (e.wWind > 0) return;
      const _want = Math.atan2(aimY - e.y, aimX - e.x);
      const _pk = dashPickDir(e.x, e.y, _want, c.pickCone || 1.05, c.speed * c.dash + e.r);
      e.wDashDir = _pk.ang;
      /* 前方太短就短冲，别一路顶到墙上（长度留一点余量好接着滑） */
      const _reach = Math.max(0, _pk.free - e.r - 10);
      e.wDashT = (_reach < (c.shortMin || 210))
        ? clamp(_reach / c.speed + 0.12, 0.16, c.dash)
        : c.dash;
      e._slide = false;
      e.shieldAng = e.wDashDir;
      beep(140, 0.18, 'square', 0.10, 80);
      return;
    }
    if (e.bossCd <= 0 && d > c.minD && d < c.maxD && (e.sees || e.mode === 1)){
      e.wWind = c.wind; e.bossCd = cd; e.wBurst = c.burst;
      setMsg('督军要冲了 · 别走直线', 1.3);
      beep(240, 0.12, 'square', 0.09, 150);
    }
  },

  /* 召唤：自己不上，让别人上 */
  summ(e, dt, c, ph){
    e.spawnCd = (e.spawnCd === undefined ? c.cd[0] * 0.8 : e.spawnCd) - dt;
    if (e.spawnCd > 0) return;
    const lowHp = ph && ph.cdK;
    e.spawnCd = lowHp ? c.cd[1] : c.cd[0];
    const capMin = c.maxMinions || SUMM_MINION_MAX;
    const alive = arenaMinionCount();
    if (alive >= capMin){
      /* 小兵已经满名额：先停手，隔一小会儿再看一眼 */
      e.spawnCd = 1.2;
      return;
    }
    const n = Math.min(arenaRandom() < c.doubleChance ? c.count[1] : c.count[0], capMin - alive);
    let made = 0;
    for (let i = 0; i < n; i++){
      if (arenaMinionCount() >= capMin) break;
      const a = rand(0, TAU);
      const sp = safeSpot(cur(), {x: e.x + Math.cos(a)*44, y: e.y + Math.sin(a)*44}, 14);
      spawnArenaEnemy(sp.x, sp.y, a + Math.PI);
      const nn = enemies[enemies.length-1];
      if (nn){ nn.boostT = c.boost; nn.mode = 1; nn.alertT = c.alert; nn.minionTint = e.bossTint || '#c8a8ff'; nn.noXp = true; nn.isMinion = true; }
      made++;
    }
    if (made){
      logInfo('arena', '巢母放出 ' + made + ' 只小兵');
      beep(180, 0.12, 'triangle', 0.06, 120);
    }
  },

  /* 盾撞：正面挡子弹的那块盾会跟着你转，撞墙自己会愣住 */
  shove(e, dt, c, ph, d){
    /* 双盾：两片盾沿固定角速度绕身转（相隔 180°），不再是"正面一块" */
    e.shieldOrbit = (((e.shieldOrbit === undefined) ? (e.shieldAng || 0) : e.shieldOrbit) + 1.9 * dt) % (Math.PI * 2);
    if (!(e.dashT > 0)){
      const want = Math.atan2(player.y - e.y, player.x - e.x);
      const curA = (e.shieldAng === undefined) ? want : e.shieldAng;
      const df = Math.atan2(Math.sin(want - curA), Math.cos(want - curA));
      const mx = 0.5 * dt;
      e.shieldAng = curA + Math.max(-mx, Math.min(mx, df));
    }
    if (e.dashT > 0){
      e.dashT -= dt;
      /* 冲刺速度：按难度动态加成（困难 0 / 噩梦 +1 / 硬核 +2），再叠"越撞越急" */
      const _tb = (typeof arenaTierBonus === 'function') ? arenaTierBonus() : 0;
      const _spd = c.speed * (1 + 0.28 * _tb) * (e._dashSpdK || 1);
      const step = _spd * dt;
      const L = cur();
      const nx = e.x + Math.cos(e.dashDir) * step;
      const ny = e.y + Math.sin(e.dashDir) * step;
      const hitP = dist(nx, ny, player.x, player.y) < e.r + player.r + 4;
      /* 全穿：建筑一律无视，只被地图边界挡 */
      const bx = (nx < e.r) || (nx > L.w - e.r);
      const by = (ny < e.r) || (ny > L.h - e.r);
      if (hitP){
        if (!player.god){
          const dmg = guardDamage(bossDmgOf(e, c.dmgMul, ph));
          player.hp -= absorbArmor(dmg, 'blast'); hurtNum(dmg);
          if (player.hp <= 0) markDeath('shield', e, dmg, e.dashDir);
          player.flash = 1; hitFlash = 1;
          const _skb = (c.kb || 900), _sstun = (c.stun || 0.30);
          player.kickX = Math.cos(e.dashDir) * _skb;
          player.kickY = Math.sin(e.dashDir) * _skb;
          player.stunT = Math.max(player.stunT || 0, _sstun);
          camShake = Math.max(camShake, 1.3);
          hitStopT = Math.max(hitStopT, 0.08);
          slamBurst(player.x, player.y, e.dashDir + Math.PI, 7);
          sfxSlam(false);
          stOnHurt(dmg, 'blast');
          logWarn('hurt', '被盾卫撞上 · -' + Math.round(dmg) + ' HP');
          fxFlash = Math.max(fxFlash, 0.5);
        }
        setMsg('被盾卫撞上了', 1.4);
        e._slide = false; e.dashT = 0; e.dashCd = c.wallCd;
        e.dashHits = 0; e._dashSpdK = 1;
        return;
      }
      if (bx || by){
        /* 撞地图边界：镜像反弹，撞满 5 次才停；每次弹回来都更急一点 */
        e.dashHits = (e.dashHits || 0) + 1;
        camShake = Math.max(camShake, 0.7);
        noiseBurst(0.30, 640, 0.6, 1.5);
        beep(70, 0.30, 'sawtooth', 0.14, 40);
        impactWallFx(clamp(nx, e.r, L.w - e.r), clamp(ny, e.r, L.h - e.r), e.dashDir);
        if (bx) e.dashDir = Math.PI - e.dashDir;
        if (by) e.dashDir = -e.dashDir;
        e._dashSpdK = Math.min(1.9, (e._dashSpdK || 1) + 0.12);   /* 越撞越急 */
        e.x = clamp(nx, e.r, L.w - e.r);
        e.y = clamp(ny, e.r, L.h - e.r);
        e.dashT = Math.max(e.dashT, 0.8);                          /* 别撞两次就超时 */
        if (e.dashHits >= 5){
          e.dashT = 0; e.dashCd = c.wallCd; e.dashHits = 0; e._dashSpdK = 1;
          setMsg('盾卫撞了五次边界 · 停下了', 1.6);
        } else {
          setMsg('盾卫撞在边界上 · ' + e.dashHits + '/5', 1.0);
        }
        return;
      }
      if (e.dashT <= 0){
        e._slide = false; e.dashT = 0; e.dashCd = c.wallCd;
        e.dashHits = 0; e._dashSpdK = 1;
        return;
      }
      e._slide = false;
      e.x = nx; e.y = ny; e.ang = e.dashDir; e.shieldAng = e.dashDir;
    }
    if (e.dashWind > 0){
      e.dashWind -= dt;
      if (e.dashWind > 0) return;
      const _sw = Math.atan2(player.y - e.y, player.x - e.x);
      const _sp = dashPickDir(e.x, e.y, _sw, c.pickCone || 0.90, c.speed * c.dash + e.r);
      e.dashDir = _sp.ang;
      /* 全穿：不再因为"前面有墙"缩短冲刺（以前会让它贴着墙原地冲），一律给足时间跑完 5 次反弹 */
      e.dashT = (c.dash || 1.5) * 2.2;
      e.dashHits = 0;
      e._dashSpdK = 1;
      e._slide = false;
      e.shieldAng = e.dashDir;
      beep(150, 0.16, 'square', 0.08, 90);
      return;
    }
    e.dashCd = (e.dashCd === undefined ? c.cd : e.dashCd) - dt;
    if (e.dashCd <= 0 && d < 620 && (e.sees || e.mode === 1)){
      e.dashWind = c.wind;
      setMsg('盾卫在蓄力 · 别站在正面', 1.2);
    }
  },
};

function arenaBossTick(dt){
  /* 没有 ar（普通关卡 / 测试区）时，只要场上有 BOSS 也得让它动 */
  if (!ar && !enemies.some(e => e.bossKind)) return;
  for (const e of enemies.slice()){
    if (!e.bossKind || e.dead) continue;
    const kit = (typeof BOSS_KIT !== 'undefined') ? BOSS_KIT[e.bossKind] : null;
    if (!kit) continue;
    const d = dist(e.x, e.y, player.x, player.y);
    const ph = bossPhaseOf(e, kit);
    const list = (ph && ph.abilities) ? ph.abilities : kit.abilities;
    for (const ab of list){
      const cfg = ABILITY_DEF[ab] && ABILITY_DEF[ab].params;
      const fn = ABIL_RUN[ab];
      if (cfg && fn) fn(e, dt, cfg, ph, d, kit);
    }
  }
}


function arenaUpdate(dt){
  if (!ar) return;
  ar.time += dt;
  /* 把固定出生点表摊到开波前的多帧里，避免第一只敌人出现时同步扫描整张地图。 */
  if (typeof arenaSpawnPtsWarm === 'function') arenaSpawnPtsWarm(cur(), 24);
  /* 疯狗自爆：站定烧一会儿，炸完才真正结算（选卡界面因此排在动画后面） */
  for (const e of enemies.slice()){
    if (!e._dying) continue;
    e.deathT += dt;
    if (e.deathT >= CHARGER_DEATH_T){
      e._dying = false; e._dyingDone = true;
      impactFx(e.x, e.y, 0, true, 40);
      impactFx(e.x, e.y, 0, true, 40);
      scorchMarks.push({ x: e.x, y: e.y, r: 40, t: 0 });
      fxFlash = Math.max(fxFlash, 0.55);
      camShake = Math.max(camShake, 1.6);
      punchT = Math.max(punchT, 0.26); punchAmp = 18;
      sfxSlam(true);
      killTestEnemy(e);
    }
  }
  if (ar.banAnim){
    const _ba = ar.banAnim;
    if (_ba.hold > 0) _ba.hold -= dt; else _ba.t += dt;   /* 砸锁那 0.05 秒是真的停住 */
    banAnimCues();
    if (ar.banAnim && ar.banAnim.t >= ar.banAnim.dur) ar.banAnim = null;
  }
  /* 卡住的傻子：有些人生成在角落/夹在两堵墙中间，寻路来回抖却一米不走，
     站在屏幕外一直占着名额。2.5 秒没挪窝、且离你很远，就当它走丢了，换个地方重新进场。 */
  for (const e of enemies){
    if (e.boss || e._dying) continue;
    if (!e._stk){ e._stk = {x: e.x, y: e.y, t: 0}; continue; }
    e._stk.t += dt;
    if (e._stk.t < 2.5) continue;
    const _moved = Math.hypot(e.x - e._stk.x, e.y - e._stk.y);
    const _far = dist(e.x, e.y, player.x, player.y) > 240;
    if (_moved < 8 && _far){
      const L2 = cur();
      const a2 = rand(0, TAU), r2 = rand(520, 760);
      const p2 = safeSpot(L2, {x: player.x + Math.cos(a2) * r2, y: player.y + Math.sin(a2) * r2}, 14);
      e.x = p2.x; e.y = p2.y;
      e.path = null; e.goal = null; e.pi = 0;
      /* 2026-11-26：这里原来直接 `e.wp = null`，把"走丢重进场"的兵变成没有巡逻线的雕像
         （死亡地带里那一个 wp 为空的火箭筒兵就是这么来的，`_tDzFix` 的「每个敌人都有巡逻线」因此红）。
         改成围绕新落点重建一条 4 点巡逻线；本来就没有巡逻线的单位（MOBA 路线兵等）保持原样。 */
      if (e.wp && e.wp.length){
        const _wp = [[p2.x, p2.y]];
        for (let _k = 0; _k < 3; _k++){
          const _a = rand(0, TAU), _rr = rand(130, 380);
          const _c = (typeof safeSpot === 'function')
            ? safeSpot(L2, { x: p2.x + Math.cos(_a) * _rr, y: p2.y + Math.sin(_a) * _rr }, 18)
            : { x: p2.x + Math.cos(_a) * _rr, y: p2.y + Math.sin(_a) * _rr };
          _wp.push([_c.x, _c.y]);
        }
        e.wp = _wp; e.i = 0; e.wait = 0;
      }
      e.mode = 1; e.lastKnown = {x: player.x, y: player.y};
    }
    e._stk = {x: e.x, y: e.y, t: 0};
  }
  /* 巢母在场就一张张封你的牌；它一死立刻全解锁 */
  if (ar.banIdx && ar.banIdx.length && !spawnerAlive()) spawnerBanClear();
  else spawnerBanTick(dt);
  /* 自动打药：血掉到 55% 以下就自己嗑，不用你按，也不会减速/被打断。
     优先用绿药包（差得多的时候），否则小药，两种都没有就只能靠自己了。 */
  if (ar.reg) player.hp = Math.min(arenaMaxHp(), player.hp + ar.reg * dt);
  if (ar.callCd > 0) ar.callCd = Math.max(0, ar.callCd - dt);
  if (ar.burstT > 0) ar.burstT = Math.max(0, ar.burstT - dt);
  if (ar.evT > 0){
    ar.evT = Math.max(0, ar.evT - dt);
    if (ar.evT === 0){
      if (ar.evKind) setMsg('事件结束 · ' + arenaEventName(ar.evKind), 1.6);
      ar.evKind = '';
    }
  }
  /* 孤注一掷：血只有 1 点的这段倒计时，到点回半血收工 */
  if (ar.dealT > 0){
    ar.dealT = Math.max(0, ar.dealT - dt);
    if (ar.dealT === 0){
      player.hp = Math.min(arenaMaxHp(), player.hp + Math.round(arenaMaxHp() * 0.5));
      setMsg('孤注一掷结束 · 回了半血', 2.2);
      beep(420, 0.18, 'triangle', 0.06, 700);
    }
  }
  /* 生命垂危：血量触底那一下直接回满，带冷却 */
  if (ar.lastCd > 0) ar.lastCd = Math.max(0, ar.lastCd - dt);
  if (ar.lastStand && player.hp > 0 && player.hp < arenaMaxHp() * 0.25 && !(ar.lastCd > 0)){
    player.hp = arenaMaxHp();
    ar.lastCd = 60;
    setMsg('生命垂危！体力回满 · 60 秒后才能再用', 2.6);
    camShake = Math.max(camShake, 0.6);
    fxFlash = Math.max(fxFlash, 0.5);
    sfxWaveClear();
  }
  if (!arenaDealOn() && !player.heal && !playerInWall && player.hp < arenaMaxHp() * 0.55){
    const md = player.meds || {};
    const miss = arenaMaxHp() - player.hp;
    if (miss > 60 && (md.big || 0) > 0) useMed('big');
    else if ((md.small || 0) > 0) useMed('small');
    else if ((md.big || 0) > 0) useMed('big');
  }

  /* 互相推开一点：不加这个，四面八方来的人最后会挤成一个点，看不出包围感 */
  const EL = cur();
  for (let i = 0; i < enemies.length; i++){
    const a = enemies[i];
    for (let j = i + 1; j < enemies.length; j++){
      const b = enemies[j];
      const dx = b.x - a.x, dy = b.y - a.y;
      const d2 = dx*dx + dy*dy;
      const want = (a.r + b.r) * 1.5;
      if (d2 > want*want || d2 < 0.0001) continue;
      const d = Math.sqrt(d2);
      const push = (want - d) * 0.5;
      const nx = dx / d, ny = dy / d;
      a.x -= nx * push; a.y -= ny * push;
      b.x += nx * push; b.y += ny * push;
      pushOutCircle(EL, a, a.r);
      pushOutCircle(EL, b, b.r);
    }
  }

  arenaBossTick(dt);

  /* 【火箭筒扩容】：扳机已经扣过弹药了，这一发是白送的，到点自己出去 */
  if (ar.rwBurstT > 0){
    ar.rwBurstT -= dt;
    if (ar.rwBurstT <= 0){
      ar.rwBurstT = 0;
      if (state === 'play' && player.hp > 0) fireRocket(ar.rwBurstA || player.aim);
    }
  }

  /* 自动瞄准：替你把准星按到最近的敌人身上，扣扳机还是走 tryShoot */
  if (ar.autoT > 0){
    ar.autoT = Math.max(0, ar.autoT - dt);
    let best = null, bd = 1e9;
    for (const e of enemies){
      const d = dist(player.x, player.y, e.x, e.y);
      /* 以前只比距离：于是隔着墙锁人、子弹全打在墙上，看起来像"卡住不动"。
         现在只锁"看得见"的（losBlocked 走墙的候选表，不贵），半径也放大到 900。 */
      if (d >= 900 || d >= bd) continue;
      if (typeof losBlocked === 'function' && losBlocked(player.x, player.y, e.x, e.y)) continue;
      bd = d; best = e;
    }
    if (best){
      const a2 = Math.atan2(best.y - player.y, best.x - player.x);
      player.aim = a2;
      mouse.x = W/2 + Math.cos(a2)*200;
      mouse.y = H/2 + Math.sin(a2)*200;
      if (player.gun && player.gun.cd <= 0 && !player.heal) tryShoot();
    }
  }

  /* 战斗，爽！！里敌人不需要"找"你：它们永远知道你在哪 */
  for (const e of enemies){
    if (enemyType(e).static) continue;
    e.mode = 1;
    /* 战斗爽里的敌人一直知道玩家位置；直接改坐标，别为每个敌人每帧制造新对象。
       48 人时旧写法每秒会留下近 3000 个短命对象，恰好在连续刷怪时放大 GC 抖动。 */
    if (!e.lastKnown) e.lastKnown = { x: player.x, y: player.y };
    else { e.lastKnown.x = player.x; e.lastKnown.y = player.y; }
    if (e.alertT < 6) e.alertT = 6;
  }

  /* 经验球：靠近就吸过来。吸力是"越近越快"的指数收拢，
     最远端也有 ~3 倍身位/秒的速度，跑着捡也甩不掉它 */
  const ORB_R = 430 + (ar ? (ar.pickR | 0) : 0), ORB_PICK = 34;
  for (let i=arOrbs.length-1;i>=0;i--){
    const o = arOrbs[i];
    o.t += dt;
    const d = dist(player.x, player.y, o.x, o.y);
    if (d < ORB_PICK){ arOrbs.splice(i,1); arenaXp(o.v); continue; }
    if (d < ORB_R){
      const near = 1 - d / ORB_R;                 /* 0 在边缘，1 在脚下 */
      const k = Math.min(1, dt * (3.0 + near * 9.0));
      o.x += (player.x - o.x) * k;
      o.y += (player.y - o.y) * k;
    }
  }

  /* 清波后的喘息：三秒内不出人，给你时间拾经验球、换卡不慌 */
  if (ar.cineT > 0) ar.cineT = Math.max(0, ar.cineT - dt);
  updateCorpses(dt);
  if (ar.inter > 0){
    ar.inter = Math.max(0, ar.inter - dt);
    /* 近距特写：0.55 秒推进去，最后 1.25 秒慢慢拉回，中间保持 */
    const _in  = Math.min(1, Math.max(0, (ARENA_INTER - ar.inter) / 0.55));
    const _out = Math.min(1, Math.max(0, ar.inter / 1.25));
    const _raw = Math.min(_in, _out);
    ar.cineK = _raw * _raw * (3 - 2 * _raw);
    /* 特写的镜头曲线：先一下推到很近（撞击感），再慢慢拉回来定住 */
    const _t = ARENA_INTER - ar.inter;
    let _z;
    if (_t < 0.10) _z = 1.95;
    else if (_t < 1.55){
      const u = (_t - 0.10) / 1.45;
      _z = 1.95 - 0.60 * (u * u * (3 - 2 * u));
    } else _z = 1.35;
    ar.cineZ = _z;
    ar.cinePan = Math.min(1, _t / 0.12);        /* 0.12 秒内把镜头落到尸体上 */
    ar.cineFlash = Math.max(0, 1 - _t / 0.20);
    ar.cineLines = Math.max(0, 1 - _t / 0.34);
    if (ar.inter === 0) arenaNextWave();
    return;
  }

  /* 出兵：一波打完（或清干净）就开下一波 */

  if (ar.spawnLeft > 0){
    ar.burst -= dt;
    if (ar.burst <= 0 && arenaFoeCount() < arenaSpawnCap()){
      arenaSpawnOne();
      ar.spawnLeft--;
      /* 突破期放人比平时快一倍多，别让人干等 */
      ar.burst = ar.burstT > 0 ? 0.09 : Math.max(0.09, 0.40 - ar.wave*0.012);
    }
  } else if (enemies.length === 0){
    ar.waveT -= dt;
    if (ar.waveT <= 0){ arenaNextWave(); }
  }
}

/* ---------------- 战斗，爽！！界面 ---------------- */
/* 经验球的光晕改成贴图：以前是一颗球一次 shadowBlur=10 的高斯模糊，
   场上几十上百颗的时候这就是 GPU 上的主要开销。 */
var GLOW_ORB = null;
var GLOW_LOOT = null;
/* 掉落物光晕按品质分四张（懒建）：普通还是原来的暖白，精良偏蓝、稀有紫、史诗金 */
var LOOT_GLOW_Q = [null, null, null, null];
function drawArenaOrbs(){
  if (!GLOW_ORB){
    GLOW_ORB = glowSprite('orb', [[0,'rgba(190,246,255,0.92)'],
                                  [0.34,'rgba(120,220,255,0.46)'],
                                  [1,'rgba(90,190,255,0)']], 48);
  }
  for (const o of arOrbs){
    const k = 0.5 + 0.5*Math.sin(uiT*5 + o.bob);
    const oy = o.y - 4 - k*2;
    drawGlow(GLOW_ORB, o.x, oy, 13 + k*3, 0.62 + 0.30*k);
    ctx.fillStyle = 'rgba(160,240,255,' + (0.76 + 0.20*k).toFixed(2) + ')';
    ctx.beginPath(); ctx.arc(o.x, oy, 4.2, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.beginPath(); ctx.arc(o.x - 1.2, oy - 1.4, 1.6, 0, TAU); ctx.fill();
  }
}

/* 封卡的表现：一张牌从左边竖着飞出来，铁链横着一缠就锁死，然后整张被拖出屏幕。
   纯动画：不注册按钮、不吃输入。 */
/* 封卡那套音效：铁链一节一节的金属声，最后锁扣和印章砸下来 */
/* 金属撞击：白噪声过「低通 → 带通」，再叠几个不成整数倍的正弦。
   人耳认金属靠两件事：起音是一小段宽带噪声，余音是一串不和谐的谐振。
   之前用 square 直接蜂鸣，所以听起来像电子音。 */
function metalHit(opt){
  if (!actx) return;
  ensureNoise();
  const o = opt || {};
  const now = actx.currentTime + (o.delay || 0);
  const dur = o.dur || 0.26;
  const vol = o.vol == null ? 0.45 : o.vol;
  const cut = o.cut || 1900;
  try{
    if (noiseBuf){
      const sr = actx.createBufferSource(); sr.buffer = noiseBuf;
      const lp = actx.createBiquadFilter(); lp.type = 'lowpass';
      lp.frequency.setValueAtTime(Math.min(14000, cut * 2.6), now);
      lp.frequency.exponentialRampToValueAtTime(Math.max(180, cut * 0.30), now + dur);
      const bp = actx.createBiquadFilter(); bp.type = 'bandpass';
      bp.frequency.setValueAtTime(cut, now); bp.Q.value = o.q || 1.8;
      const g = actx.createGain();
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(vol, now + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
      sr.connect(lp); lp.connect(bp); bp.connect(g); g.connect(duckBus());
      sr.start(now); sr.stop(now + dur + 0.03);
    }
    const ps = o.partials || [523, 787, 1174, 1607];
    const pit = o.pitch || 1, ben = o.bend || 1;
    for (let i = 0; i < ps.length; i++){
      const f = ps[i] * pit;
      const osc = actx.createOscillator();
      osc.type = i === 0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(f, now);
      if (ben !== 1) osc.frequency.exponentialRampToValueAtTime(Math.max(20, f * ben), now + dur * 0.85);
      const g2 = actx.createGain();
      const d = Math.max(0.05, dur * (0.62 - i * 0.10));
      g2.gain.setValueAtTime(0.0001, now);
      g2.gain.exponentialRampToValueAtTime(Math.max(0.005, vol * (0.24 - i * 0.042)), now + 0.006);
      g2.gain.exponentialRampToValueAtTime(0.0001, now + d);
      osc.connect(g2); g2.connect(duckBus());
      osc.start(now); osc.stop(now + d + 0.03);
    }
  }catch (e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
}

/* 铁链拉紧：整段白噪声被一个往上扫的带通"抓住"，最后收到高位，像链子绷直 */
function sfxChainPull(){
  if (sndPlay('chain.pull', 0.8)) return;
  if (!actx) return;
  ensureNoise();
  const now = actx.currentTime, dur = 0.55;
  try{
    if (noiseBuf){
      const sr = actx.createBufferSource(); sr.buffer = noiseBuf;
      const bp = actx.createBiquadFilter(); bp.type = 'bandpass';
      bp.Q.value = 3.6;
      bp.frequency.setValueAtTime(300, now);
      bp.frequency.exponentialRampToValueAtTime(2500, now + dur * 0.70);
      bp.frequency.exponentialRampToValueAtTime(1400, now + dur);
      const g = actx.createGain();
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(0.15, now + 0.09);
      g.gain.setValueAtTime(0.15, now + dur * 0.66);
      g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
      sr.connect(bp); bp.connect(g); g.connect(duckBus());
      sr.start(now); sr.stop(now + dur + 0.03);
    }
    beep(760, 0.24, 'sawtooth', 0.018, 1180);
  }catch (e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
}
function sfxBanWhoosh(){
  if (sndPlay('chain.whoosh', 0.5)) return;
  noiseBurst(0.22, 680, 0.24, 0.9);
  beep(150, 0.24, 'sawtooth', 0.028, 520);
}
function sfxChainClank(i){
  if (sndPlay('chain.clank', 0.55)) return;
  /* 每一节链子撞上来的音高错开，像一串铁环真的在动 */
  metalHit({ cut: 2400 + (i % 3) * 540, dur: 0.16, vol: 0.40,
             partials: [1180 + i * 90, 1830 + i * 140, 2610 + i * 200], q: 2.8 });
}
/* 锁扣：先"咔"一声合拢，紧接着整块砸死（低频闷响 + 铁味余音） */
function sfxPadlock(){
  if (sndPlay('chain.lock', 0.85)) return;
  metalHit({ cut: 3100, dur: 0.09, vol: 0.32, partials: [1560, 2340], q: 3.6 });
  metalHit({ delay: 0.055, cut: 760, dur: 0.34, vol: 0.58,
             partials: [186, 279, 441, 612], bend: 0.60, q: 1.2 });
  beep(74, 0.28, 'sine', 0.110, 40);
}
function sfxStampSlam(){
  if (sndPlay('chain.stamp', 0.9)) return;
  metalHit({ cut: 620, dur: 0.40, vol: 0.58, partials: [148, 222, 361], bend: 0.55, q: 1.1 });
  beep(62, 0.40, 'sine', 0.125, 30);
  noiseBurst(0.13, 2600, 0.15, 2.4);
}
function sfxDragAway(){
  if (sndPlay('chain.drag', 0.6)) return;
  if (!actx) return;
  ensureNoise();
  const now = actx.currentTime, dur = 0.50;
  try{
    if (noiseBuf){
      const sr = actx.createBufferSource(); sr.buffer = noiseBuf;
      const lp = actx.createBiquadFilter(); lp.type = 'lowpass';
      lp.frequency.setValueAtTime(2400, now);
      lp.frequency.exponentialRampToValueAtTime(240, now + dur);
      const g = actx.createGain();
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(0.10, now + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
      sr.connect(lp); lp.connect(g); g.connect(duckBus());
      sr.start(now); sr.stop(now + dur + 0.03);
    }
  }catch (e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
}

/* 铁链动画的音效节拍（按百分比）：0 甩入 / 1–6 链节撞击 / 7 拉紧 / 8 锁扣 / 9 砸章 / 10 拖走 */
const BAN_CUES = [0.02, 0.115, 0.155, 0.195, 0.235, 0.275, 0.315, 0.38, 0.50, 0.75, 0.92];
function banAnimCues(){
  const a = ar && ar.banAnim;
  if (!a) return;
  if (a.cue === undefined) a.cue = 0;
  const p = a.t / a.dur;
  while (a.cue < BAN_CUES.length && p >= BAN_CUES[a.cue]){
    const k = a.cue++;
    if (k === 0) sfxBanWhoosh();
    else if (k === 7) sfxChainPull();
    else if (k === 8){ sfxPadlock(); camShake = Math.max(camShake, 0.55); a.hold = 0.05; }
    else if (k === 9){ sfxStampSlam(); camShake = Math.max(camShake, 0.85); }
    else if (k === 10) sfxDragAway();
    else { sfxChainClank(k - 1); camShake = Math.max(camShake, 0.09); }
  }
}

/* ---- 封卡的铁链：一条链子从左边甩进来，绕着这张牌缠一圈，尾巴垂到左下 ---- */
/* 一条链子：从屏幕左边甩进来，横过卡面勒一圈，再绕到卡背后收口，最后甩出屏外。
   路径顺序 = 观看顺序，前半段（尾巴 + 横过卡面那截）在卡前面，后半段在卡后面，
   于是画的时候分两次：先把后半段画在卡底下，再画卡，最后把前半段压上去。 */
function banTiePaths(){
  const cy = H / 2, bx = 40, bw = 160, bh = 210;
  const cx = bx + bw / 2;
  const L = bx, R = bx + bw, T = cy - bh / 2, B = cy + bh / 2;
  /* 横带压在副标题下面；竖带从牌名右边绕过去，不挡「快手」两个字 */
  const yH = cy + 6;
  const xV = cx + 22;
  const mk = function(pairs){
    const pts = [];
    for (let i = 0; i < pairs.length - 1; i++){
      const a0 = pairs[i], a1 = pairs[i + 1];
      const n = Math.max(1, Math.round(Math.hypot(a1[0] - a0[0], a1[1] - a0[1]) / 6));
      for (let j = 1; j <= n; j++) pts.push({ x: a0[0] + (a1[0] - a0[0]) * j / n, y: a0[1] + (a1[1] - a0[1]) * j / n });
    }
    const cum = [0];
    for (let i = 1; i < pts.length; i++){
      cum.push(cum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
    }
    return { pts: pts, cum: cum, total: cum[cum.length - 1] };
  };
  /* 两条带子不向外伸头：端头就压在卡边上，看起来是从背后绕过来的 */
  const Hp = mk([[L + 2, yH], [R - 2, yH]]);
  const Vp = mk([[xV, T + 2], [xV, B - 2]]);
  return { H: Hp, V: Vp, L: L, R: R, T: T, B: B, yH: yH, xV: xV,
           cross: { x: xV, y: yH } };
}

function banChainPointAt(path, d){
  const cum = path.cum, pts = path.pts;
  if (d <= 0) return { x: pts[0].x, y: pts[0].y, ang: 0 };
  let k = 1;
  while (k < cum.length && cum[k] < d) k++;
  if (k >= cum.length) k = cum.length - 1;
  const t = (d - cum[k - 1]) / Math.max(0.0001, cum[k] - cum[k - 1]);
  return {
    x: pts[k - 1].x + (pts[k].x - pts[k - 1].x) * t,
    y: pts[k - 1].y + (pts[k].y - pts[k - 1].y) * t,
    ang: Math.atan2(pts[k].y - pts[k - 1].y, pts[k].x - pts[k - 1].x)
  };
}

/* 从弧长 from 画到 len；只画这一段，别的层负责别的段 */
function banChainDraw(path, len, al, from){
  const SPC = 12.5;
  const f0 = from || 0;
  if (len <= f0) return;
  let d = f0, i = 0;
  while (d <= len){
    const q = banChainPointAt(path, d);
    /* 到卡边的最后 10px 把链节压扁：看起来是绕过去了，不是被切断 */
    const toStart = d, toEnd = path.total - d;
    /* 两端淡出：链子不是被切断，是化进黑暗里 */
    const fade = 0.52 + 0.48 * Math.min(1, toStart / 12, toEnd / 12);
    let k = 1;
    if (toStart < 14) k = Math.min(k, 0.24 + 0.76 * Math.max(0, toStart) / 14);
    if (toEnd < 14) k = Math.min(k, 0.24 + 0.76 * Math.max(0, toEnd) / 14);
    banChainLink(q.x, q.y, q.ang, (i % 2) === 1, al * fade, k);
    i++; d += SPC;
  }
}

function banChainLink(x, y, ang, odd, al, k){
  const f = (k === undefined || k === null) ? 1 : k;
  ctx.save();
  ctx.globalAlpha = al * (0.45 + 0.55 * f);
  ctx.translate(x, y);
  ctx.rotate(ang + (odd ? Math.PI / 2 : 0));
  ctx.beginPath(); ctx.ellipse(0, 0, 8.6 * (0.42 + 0.58 * f), 4.6 * (0.42 + 0.58 * f), 0, 0, TAU);
  ctx.strokeStyle = 'rgba(10,14,20,0.92)'; ctx.lineWidth = 5.4; ctx.stroke();
  ctx.strokeStyle = '#8ea3ba'; ctx.lineWidth = 2.8; ctx.stroke();
  ctx.strokeStyle = 'rgba(232,242,255,0.6)'; ctx.lineWidth = 0.9; ctx.stroke();
  ctx.restore();
}

/* 沿路径把链子画到 len 这么长；head=true 时给链头一点金属反光 */

/* 卡轮廓：四个与链条相交的地方向内凹一块，像被链子勒进去了 */
function banCardPath(cw, ch, r, dip, ux, uy){
  const L = -cw / 2, R = cw / 2, T = -ch / 2, B = ch / 2;
  const dx = 10;
  ctx.beginPath();
  ctx.moveTo(L + r, T);
  ctx.lineTo(ux - dx, T);
  ctx.quadraticCurveTo(ux, T + dip, ux + dx, T);
  ctx.lineTo(R - r, T);
  ctx.quadraticCurveTo(R, T, R, T + r);
  ctx.lineTo(R, uy - dx);
  ctx.quadraticCurveTo(R - dip, uy, R, uy + dx);
  ctx.lineTo(R, B - r);
  ctx.quadraticCurveTo(R, B, R - r, B);
  ctx.lineTo(ux + dx, B);
  ctx.quadraticCurveTo(ux, B - dip, ux - dx, B);
  ctx.lineTo(L + r, B);
  ctx.quadraticCurveTo(L, B, L, B - r);
  ctx.lineTo(L, uy + dx);
  ctx.quadraticCurveTo(L + dip, uy, L, uy - dx);
  ctx.lineTo(L, T + r);
  ctx.quadraticCurveTo(L, T, L + r, T);
  ctx.closePath();
}

/* 接触阴影：一条模糊的黑带子，只贴在链子正下方，让链子“浮”在卡面上 */
function banChainShadow(path, len, al){
  if (len <= 2) return;
  ctx.save();
  ctx.globalAlpha = al * 0.85;
  ctx.strokeStyle = 'rgba(0,0,0,1)';
  ctx.lineWidth = 13; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath();
  for (let d = 0; d <= len; d += 8){
    const q = banChainPointAt(path, d);
    if (d === 0) ctx.moveTo(q.x, q.y + 5.0); else ctx.lineTo(q.x, q.y + 5.0);
  }
  try { ctx.filter = 'blur(3px)'; } catch (e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
  ctx.stroke();
  try { ctx.filter = 'none'; } catch (e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
  ctx.restore();
}

function drawBanAnim(){
  const a = ar && ar.banAnim;
  if (!a) return;
  const p = clamp(a.t / a.dur, 0, 1);
  const w = 160, h = 210, bx = 40, cy = H / 2;
  /* 时间轴（dur 4.0s）：飞入 → 缠链 → 勒紧 → 砸锁(顿帧) → 挣扎 → 静 ~0.5s → 盖印 → 拖走 */
  const FLY = 0.08, CH1 = 0.34, T1 = 0.42, LK = 0.50, ST1 = 0.60, SE0 = 0.625, SLP = 0.75, END = 0.92;

  let x = bx, al = 1, tilt = 0, shk = 0, shakeAmp = 0;
  if (p < FLY){
    const k = p / FLY, e = 1 - Math.pow(1 - k, 3);
    x = -w - 30 + (bx + w + 30) * e;
    al = Math.min(1, e * 1.7);
  } else if (p > END){
    const k = (p - END) / (1 - END), e = k * k;
    x = bx - (bx + w + 60) * e;
    al = 1 - e;
    tilt = -0.20 * e;
  } else if (p > LK && p < ST1){
    /* 挣扎：三下，一下比一下弱，然后彻底不动 */
    const k = (p - LK) / (ST1 - LK);
    shk = Math.sin(k * Math.PI * 6) * 5.4 * Math.pow(1 - k, 1.4);
    tilt = Math.sin(k * Math.PI * 6) * 0.014 * Math.pow(1 - k, 1.4);
  }
  /* 砸锁那一下整屏抖，随顿帧一起收住 */
  if (p > LK && p < LK + 0.030){
    const k = (p - LK) / 0.030;
    shakeAmp = 3.6 * (1 - k);
  }

  /* 勒紧：链子缩得比卡多，于是"吃"进卡边里 */
  const sqr = clamp((p - CH1) / (T1 - CH1), 0, 1);
  const tight = (p >= T1) ? 1 : sqr;
  const chSc = 1 - 0.042 * tight;
  const cdSc = 1 - 0.016 * tight;

  const tone = a.tone || '#c8a8ff';
  const cx0 = x + w / 2;

  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  if (shakeAmp > 0.05) ctx.translate(Math.sin(p * 921) * shakeAmp, Math.cos(p * 733) * shakeAmp);

  /* 两条打包带：先飞横带，再落竖带 */
  const tie = banTiePaths();
  const pathH = tie.H, pathV = tie.V;
  const FLY2 = 0.215;
  const kH = clamp((p - FLY) / (FLY2 - FLY), 0, 1);
  const kV = clamp((p - FLY2) / (CH1 - FLY2), 0, 1);
  const lenH = pathH.total * Math.pow(kH, 1.35);
  const lenV = pathV.total * Math.pow(kV, 1.35);

  const chainXf = function(){
    ctx.translate(cx0, cy); ctx.scale(chSc, chSc); ctx.translate(-cx0, -cy);
    ctx.translate(x - bx, 0);
  };
  const inCard = function(q){
    return q.x > tie.L + 2 && q.x < tie.R - 2 && q.y > tie.T + 2 && q.y < tie.B - 2;
  };
  /* 链头亮光：只在卡外画 */
  const tieHead = function(path, d){
    if (d <= 0.5 || d >= path.total - 1) return;
    const q = banChainPointAt(path, d);
    if (inCard(q)) return;
    ctx.save(); chainXf();
    ctx.globalAlpha = al;
    ctx.fillStyle = 'rgba(236,246,255,0.92)';
    ctx.beginPath(); ctx.arc(q.x, q.y, 3.2, 0, TAU); ctx.fill();
    ctx.globalAlpha = al * 0.30;
    ctx.beginPath(); ctx.arc(q.x, q.y, 8.5, 0, TAU); ctx.fill();
    ctx.restore();
  };

  /* ---- ② 卡面 ---- */
  ctx.globalAlpha = al;
  ctx.translate(cx0 + shk, cy + tilt * 26);
  ctx.rotate(tilt);
  /* 被勒住的时候竖着瘪一点 */
  ctx.scale(cdSc * 0.998, cdSc * 0.974);
  ctx.shadowColor = 'rgba(255,80,80,' + (0.26 * (0.6 + 0.4 * Math.sin(p * 9))) + ')';
  ctx.shadowBlur = 26;
  const dip = 4.4 * tight;
  ctx.fillStyle = '#141b25';
  banCardPath(w, h, 10, dip, tie.xV - cx0, tie.yH - cy); ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = tone; ctx.globalAlpha = al * 0.75; ctx.lineWidth = 1.6;
  banCardPath(w, h, 10, dip, tie.xV - cx0, tie.yH - cy); ctx.stroke();
  ctx.globalAlpha = al;
  ctx.textAlign = 'center';
  ctx.fillStyle = tone;
  ctx.font = 'bold 19px "Microsoft YaHei",sans-serif';
  ctx.fillText(a.name, 0, -h / 2 + 44);
  ctx.fillStyle = 'rgba(148,166,190,0.92)';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText('这张被巢母扣住了', 0, -h / 2 + 68);
  ctx.setTransform(1, 0, 0, 1, 0, 0);

  /* ---- ③ 横带 ---- */
  if (kH > 0){
    ctx.save(); chainXf();
    banChainShadow(pathH, lenH, al);
    ctx.globalAlpha = al;
    banChainDraw(pathH, lenH, al, 0);
    ctx.restore();
    tieHead(pathH, lenH);
  }

  /* ---- ④ 竖带：压在横带上面（十字的哪条在上面，就这一处决定） ---- */
  if (kV > 0){
    ctx.save(); chainXf();
    banChainShadow(pathV, lenV, al);
    ctx.globalAlpha = al;
    banChainDraw(pathV, lenV, al, 0);
    ctx.restore();
    tieHead(pathV, lenV);
  }

  /* ---- ⑤ 锁：锻在两条带子的交叉点上 ---- */
  const lq = clamp((p - 0.42) / (LK - 0.42), 0, 1);
  if (lq > 0){
    const lx = cx0 + ((tie.cross.x + (x - bx)) - cx0) * chSc;
    const ly = cy + ((tie.cross.y) - cy) * chSc;
    const open = 1 - clamp((p - 0.42) / 0.055, 0, 1);        /* 两半还张着的程度 */
    const drop = clamp((p - 0.455) / 0.045, 0, 1);
    const dz = (1 - drop) * -26;                              /* 从上面砸下来 */
    const dz2 = Math.sin(drop * Math.PI) * 3;                 /* 过冲一点点 */
    /* 砸下来的那一下：锁下面墩一块接触阴影，越落越深 */
    if (drop > 0.02){
      const cs = 1 + 0.55 * (1 - drop);
      ctx.save();
      ctx.globalAlpha = al * 0.9 * Math.min(1, drop * 1.7);
      ctx.fillStyle = '#000';
      try { ctx.filter = 'blur(5px)'; } catch (e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
      ctx.beginPath();
      ctx.ellipse(lx, ly + 13, 25 * cs, 9 * cs, 0, 0, TAU); ctx.fill();
      try { ctx.filter = 'none'; } catch (e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
      ctx.restore();
    }
    ctx.save();
    ctx.globalAlpha = al;
    ctx.translate(lx, ly + dz + dz2);
    /* 锁体本身就要重：基础放大一圈，还没落下时更大 */
    const sc = 1.22 + 0.18 * (1 - drop);
    ctx.scale(sc, sc);
    ctx.shadowColor = 'rgba(0,0,0,' + (0.55 + 0.32 * drop) + ')';
    ctx.shadowBlur = 8 + 12 * drop; ctx.shadowOffsetY = 2 + 5 * drop;
    /* 合拢中的两半锁梁 */
    ctx.strokeStyle = '#dbe6f4'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(0, -8, 10, Math.PI + 0.42 * open, Math.PI * 1.5); ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, -8, 10, Math.PI * 1.5, TAU - 0.42 * open); ctx.stroke();
    /* 三明治第二层：把交叉点附近的几个链节压回锁梁上面，锁梁就像从环里穿过去了 */
    ctx.restore();
    if (drop > 0.12){
      ctx.save(); chainXf(); ctx.globalAlpha = al;
      const dH = tie.cross.x - (tie.L + 2);
      const dV = tie.cross.y - (tie.T + 2);
      for (let i = -1; i <= 1; i++){
        if (kH > 0){
          const d1 = dH + i * 12.5;
          if (d1 > 2 && d1 < lenH){
            const q1 = banChainPointAt(pathH, d1);
            banChainLink(q1.x, q1.y, q1.ang, (i % 2) !== 0, al, 1);
          }
        }
        if (kV > 0){
          const d2 = dV + i * 12.5;
          if (d2 > 2 && d2 < lenV){
            const q2 = banChainPointAt(pathV, d2);
            banChainLink(q2.x, q2.y, q2.ang, (i % 2) === 0, al, 1);
          }
        }
      }
      ctx.restore();
    }
    /* 三明治第三层：锁体压住下面那截链子 */
    ctx.save();
    ctx.globalAlpha = al;
    ctx.translate(lx, ly + dz + dz2);
    ctx.scale(sc, sc);
    ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 3;
    /* 锁体 */
    const bg = ctx.createLinearGradient(-15, -8, 15, 16);
    bg.addColorStop(0, '#b9c8d9'); bg.addColorStop(0.45, '#8a9cb2'); bg.addColorStop(1, '#5d6c80');
    ctx.fillStyle = bg;
    roundRect(-15, -7, 30, 24, 5); ctx.fill();
    ctx.strokeStyle = 'rgba(16,22,30,0.75)'; ctx.lineWidth = 1.3;
    roundRect(-15, -7, 30, 24, 5); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.20)';
    roundRect(-11, -4, 22, 4, 2); ctx.fill();
    ctx.fillStyle = '#232a36';
    ctx.beginPath(); ctx.arc(0, 4, 3.4, 0, TAU); ctx.fill();
    ctx.fillStyle = '#151a22';
    roundRect(-1.4, 4, 2.8, 7, 1.2); ctx.fill();
    /* 链子末端收进锁体：两截短链从左右扎进锁里 */
    if (drop > 0.6){
      ctx.strokeStyle = 'rgba(226,236,246,0.85)'; ctx.lineWidth = 2.2;
      ctx.beginPath(); ctx.moveTo(-16, 2); ctx.lineTo(-24, 4); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(16, 2); ctx.lineTo(24, 4); ctx.stroke();
    }
    ctx.restore();
  }

  /* ---- ⑤ 封印：亮度压下去，红字砸上来 ---- */
  if (p > SE0){
    const dark = clamp((p - SE0) / (SLP - SE0), 0, 1);
    ctx.save();
    ctx.globalAlpha = al * dark * 0.40;
    ctx.fillStyle = '#05070c';
    ctx.translate(cx0 + shk, cy + tilt * 26);
    ctx.rotate(tilt);
    roundRect(-w / 2, -h / 2, w, h, 10); ctx.fill();
    ctx.restore();

    const sq = clamp((p - SLP) / 0.045, 0, 1);
    if (sq > 0){
      const ss = (1.55 - 0.55 * sq - Math.sin(sq * Math.PI) * 0.06) * 1.17;
      ctx.save();
      ctx.globalAlpha = al * Math.min(1, sq * 1.6) * 0.95;
      ctx.translate(cx0 - 24 + shk, cy + 54 + tilt * 26);
      ctx.rotate(-0.20);
      ctx.scale(ss, ss);
      ctx.shadowColor = 'rgba(255,60,60,0.85)'; ctx.shadowBlur = 18;
      ctx.strokeStyle = '#ff5b5b'; ctx.lineWidth = 2.2;
      roundRect(-26, -21, 52, 42, 7); ctx.stroke();
      ctx.fillStyle = '#ff5b5b';
      ctx.textAlign = 'center';
      ctx.font = 'bold 26px "Microsoft YaHei",sans-serif';
      ctx.fillText('封', 0, 9);
      ctx.restore();
      if (sq < 1){
        ctx.save();
        ctx.globalAlpha = al * (1 - sq) * 0.65;
        ctx.strokeStyle = '#ff7a6a'; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx0 - 24 + shk, cy + 54, 20 + 40 * sq, 0, TAU);
        ctx.stroke();
        ctx.restore();
      }
    }
  }

  ctx.restore();
}

function drawArenaHUD(){
  if (!ar) return;
  ctx.save();
  ctx.setTransform(1,0,0,1,0,0);
  const cw = 420, cx = W/2 - cw/2, cy = 16;
  ctx.fillStyle = 'rgba(8,12,18,0.72)';
  roundRect(cx, cy, cw, 62, 10); ctx.fill();
  ctx.strokeStyle = 'rgba(150,180,210,0.35)'; ctx.lineWidth = 1.2;
  roundRect(cx, cy, cw, 62, 10); ctx.stroke();

  ctx.textAlign = 'left';
  ctx.fillStyle = '#ffd9a0';
  ctx.font = 'bold 20px "Microsoft YaHei",sans-serif';
  ctx.fillText('第 ' + ar.wave + ' 波', cx + 16, cy + 27);
  const _lvT = 'Lv.' + ar.level;
  const _lvW = ctx.measureText(_lvT).width;
  ctx.fillStyle = '#9ad0ff';
  ctx.fillText(_lvT, cx + 150, cy + 27);
  /* 跳档以后在等级后面挂个小标，让玩家知道现在打的是哪一档 */
  {
    const _up = (ar.tier | 0) > (ar.tierBase | 0);
    ctx.fillStyle = _up ? '#ff8f6a' : 'rgba(200,214,230,0.72)';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.fillText('难度 ' + (_up ? arenaTierName() : (DIFF_LABEL[diffName] || diffName)), cx + 150 + _lvW + 12, cy + 26);
  }
  ctx.fillStyle = 'rgba(226,236,246,0.72)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText('击杀 ' + ar.kills + ' · 分数 ' + ar.score, cx + cw - 16, cy + 26);
  /* 被巢母封掉的卡：直接写在右上角，别让玩家莫名其妙变弱 */
  if (ar.banIdx && ar.banIdx.length){
    ctx.textAlign = 'right';
    ctx.fillStyle = '#ff8f7a';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    const names = ar.banIdx.map(i => ar.picks[i]).filter(Boolean);
    const shown = names.slice(-3).join(' / ');
    ctx.fillText('被封 ' + names.length + ' 张 · ' + shown, cx + cw - 16, cy + 44);
    ctx.textAlign = 'left';
  }

  /* 正在生效的事件：名字 + 剩余秒数，挂在波次框下面 */
  if (ar.evT > 0 && ar.evKind){
    const _evTxt = '事件 · ' + arenaEventName(ar.evKind) + ' · 剩 ' + Math.ceil(ar.evT) + ' 秒';
    ctx.textAlign = 'center';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    const _evW = ctx.measureText(_evTxt).width;
    ctx.fillStyle = 'rgba(8,12,18,0.72)';
    roundRect(W/2 - _evW/2 - 12, cy + 68, _evW + 24, 24, 8); ctx.fill();
    ctx.fillStyle = ar.evKind === 'blackout' ? '#b8a6ff'
                  : ar.evKind === 'jam' ? '#ff9a6a'
                  : ar.evKind === 'frenzy' ? '#ff9dad' : '#ffd9a0';
    ctx.fillText(_evTxt, W/2, cy + 85);
  }

  /* 自动瞄准：卡生效期间挂了条状态，不然"锁定中"完全看不出来，玩家会以为卡没反应 */
  if (ar.autoT > 0){
    const _aTxt = '自动瞄准 · 剩 ' + (Math.ceil(ar.autoT * 10) / 10).toFixed(1) + ' 秒';
    ctx.textAlign = 'center';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    const _aW = ctx.measureText(_aTxt).width;
    const _aY = cy + ((ar.evT > 0 && ar.evKind) ? 100 : 68);
    ctx.fillStyle = 'rgba(8,12,18,0.72)';
    roundRect(W/2 - _aW/2 - 12, _aY, _aW + 24, 24, 8); ctx.fill();
    ctx.fillStyle = '#c58cff';
    ctx.fillText(_aTxt, W/2, _aY + 17);
  }

  /* 孤注一掷：血只有 1 点，得让人随时看得见还剩几秒 */
  if ((ar.dealT | 0) > 0){
    const _dTxt = '孤注一掷 · 剩 ' + Math.ceil(ar.dealT) + ' 秒 · 伤害 ×2 · 必穿 3 个';
    ctx.textAlign = 'center';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    const _dW = ctx.measureText(_dTxt).width;
    ctx.fillStyle = 'rgba(44,10,16,0.82)';
    roundRect(W/2 - _dW/2 - 12, cy + 96, _dW + 24, 24, 8); ctx.fill();
    ctx.fillStyle = '#ff7a8a';
    ctx.fillText(_dTxt, W/2, cy + 113);
  }

  /* 经验条 */
  const bx = cx + 16, bw = cw - 32, by = cy + 40;
  ctx.fillStyle = 'rgba(255,255,255,0.12)';
  roundRect(bx, by, bw, 10, 5); ctx.fill();
  const k = clamp(ar.xp / ar.xpNext, 0, 1);
  const gg = ctx.createLinearGradient(bx, 0, bx+bw, 0);
  gg.addColorStop(0, 'rgba(120,220,255,0.95)');
  gg.addColorStop(1, 'rgba(150,255,200,0.95)');
  ctx.fillStyle = gg;
  roundRect(bx, by, Math.max(2, bw*k), 10, 5); ctx.fill();
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(255,255,255,0.55)';
  ctx.font = '10px monospace';
  ctx.fillText((Math.round(ar.xp * 10) / 10) + ' / ' + ar.xpNext, W/2, by + 9);

  ctx.textAlign = 'left';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(200,214,230,0.38)';
  ctx.fillText('N 催场 ×' + (ar.calls | 0) + (ar.burstT > 0 ? '（突破中）' : '') +
               ' · Esc 暂停看加成一览', 24, H - 20);

  /* drawHUD 在割草模式里 8477 行就提前 return 了，msg 一直没人画 ——
     波次、督军下场、跳档这些提示都写在 setMsg 里，所以在这里补上 */
  if (msgT > 0 && msg){
    ctx.globalAlpha = Math.min(1, msgT*1.5);
    ctx.textAlign = 'center';
    ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
    const mw = ctx.measureText(msg).width;
    ctx.fillStyle = THEME_LIGHT ? 'rgba(250,248,242,0.86)' : 'rgba(10,14,18,0.72)';
    ctx.fillRect(W/2 - mw/2 - 12, H-74-22, mw + 24, 32);
    ctx.fillStyle = ar && (ar.tier | 0) > (ar.tierBase | 0) && (ar.tierMsgT | 0) > 0 ? '#ff9a6a' : '#e8eef6';
    ctx.fillText(msg, W/2, H-74);
    ctx.globalAlpha = 1;
  }
  ctx.restore();
}

/* 手里到底叠了什么、叠了几层：按卡名归并，暂停面板用 */
function arenaPerkRows(){
  const cnt = {};
  for (const n of ar.picks) cnt[n] = (cnt[n] || 0) + 1;
  const rows = [];
  for (const u of UPGRADES){
    const n = cnt[u.name];
    if (n) rows.push({ name: u.name, tone: u.tone, n: n, max: u.max || 99 });
  }
  return rows;
}

/* 暂停面板：Esc 打开，这时候 update 整帧被 confirmBack 拦住，游戏是真停的。
   加成一览放在这里，就是为了能安静看完 —— 打着仗开面板等于自杀。 */
/* 加成一览的滚轮：只有"面板这一帧刚画过"才响应，避免在交火中误翻 */
function arenaPauseWheel(dir){
  if (!ar || !ar.pauseView || !ar.pauseView.need) return false;
  if (typeof uiT !== 'number' || typeof ar.pauseT !== 'number') return false;
  if (uiT - ar.pauseT > 0.25 || uiT < ar.pauseT - 0.05) return false;
  ar.pauseScroll = clamp((ar.pauseScroll || 0) + (dir > 0 ? 1 : -1), 0, ar.pauseView.max);
  return true;
}

function drawArenaPause(){
  const rows = arenaPerkRows();
  const bw = 880, bh = 430;
  const bx = (W - bw) / 2, by = (H - bh) / 2;
  ctx.fillStyle = 'rgba(16,24,34,0.98)';
  roundRect(bx, by, bw, bh, 16); ctx.fill();
  ctx.strokeStyle = 'rgba(150,190,230,0.42)'; ctx.lineWidth = 1.4;
  roundRect(bx, by, bw, bh, 16); ctx.stroke();

  ctx.textAlign = 'left';
  ctx.fillStyle = '#ffe6b8';
  ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
  ctx.fillText('暂停 · 加成一览', bx + 30, by + 40);
  ctx.textAlign = 'right';
  ctx.fillStyle = 'rgba(200,214,230,0.42)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('第 ' + ar.wave + ' 波 · Lv.' + ar.level + ' · 击杀 ' + ar.kills, bx + bw - 30, by + 40);

  /* 左：已经拿到的卡。卡的种类一多（二十几种）三列也排不下，
     所以先按可视高度算每列能放几行，放不下的用滚轮上下翻。 */
  const rowH = 22, top = by + 76;
  const listBottom = by + bh - 108;
  const perCol = Math.max(1, Math.floor((listBottom - top) / rowH) + 1);
  const colW0 = 200;
  const sx = bx + 30 + 3 * colW0 - 6;           /* 右侧数值面板的分隔线 x */
  const areaW = sx - 12 - (bx + 30);
  const maxCols = Math.max(1, Math.min(3, Math.round(areaW / colW0)));
  const colW = Math.min(colW0, areaW / maxCols);
  const needScroll = Math.ceil(rows.length / maxCols) > perCol;
  const maxSc = needScroll ? (Math.ceil(rows.length / maxCols) - perCol) : 0;
  ar.pauseScroll = needScroll ? clamp(ar.pauseScroll || 0, 0, maxSc) : 0;
  ar.pauseView = { need: needScroll, max: maxSc, perCol: perCol };
  ar.pauseT = uiT;
  ctx.textAlign = 'left';
  if (!rows.length){
    ctx.fillStyle = 'rgba(220,232,244,0.55)';
    ctx.font = '14px "Microsoft YaHei",sans-serif';
    ctx.fillText('还没拿过卡', bx + 30, top);
  }
  if (needScroll){
    ctx.save();
    ctx.beginPath(); ctx.rect(bx + 20, top - 16, maxCols * colW, perCol * rowH + 10); ctx.clip();
  }
  for (let i = 0; i < rows.length; i++){
    const r = rows[i];
    const col = Math.floor(i / perCol);
    if (col >= maxCols) break;
    const cx = bx + 30 + col * colW;
    const cy = top + (i % perCol) * rowH - ar.pauseScroll * rowH;
    /* 老实抽卡这张卡特殊：名字周围一直在渗红光，把玩家的注意力拽过去 */
    ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
    /* 名字太长会压到右边的 ×N / max 上（"老实抽卡，很枯燥吧？"就压到了），长了就缩一档 */
    if (ctx.measureText(r.name).width > colW - 96) ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
    if (r.name === ER_NAME && typeof drawHonestRowGlow === 'function'){
      drawHonestRowGlow(cx - 8, cy - 15, ctx.measureText(r.name).width + 16, 22);
    }
    ctx.textAlign = 'left';
    ctx.fillStyle = r.tone;
    ctx.fillText(r.name, cx, cy);
    ctx.textAlign = 'right';
    ctx.fillStyle = 'rgba(226,236,246,0.78)';
    ctx.font = '13px monospace';
    ctx.fillText('×' + r.n + (r.max < 99 ? ' / ' + r.max : ''), cx + colW - 30, cy);
  }
  if (needScroll){
    ctx.restore();
    /* 竖向滚动条 + "滚轮上下翻" 提示 */
    const trackY = top - 16, trackH = perCol * rowH + 10;
    ctx.save();
    ctx.fillStyle = 'rgba(140,170,200,0.14)';
    roundRect(bx + maxCols * colW + 2, trackY, 4, trackH, 2); ctx.fill();
    const knobH = Math.max(26, trackH * perCol / Math.ceil(rows.length / maxCols));
    const knobY = trackY + (trackH - knobH) * (ar.pauseScroll / Math.max(1, maxSc));
    ctx.fillStyle = 'rgba(180,210,240,0.55)';
    roundRect(bx + maxCols * colW + 2, knobY, 4, knobH, 2); ctx.fill();
    ctx.restore();
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(190,206,224,0.42)';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('滚轮上下翻 · 还有 ' + (maxSc - Math.round(ar.pauseScroll)) + ' 行', bx + 30, listBottom + 22);
  }

  /* 右：折算后的实际数值（卡面写的是"每张 +多少"） */
  ctx.strokeStyle = 'rgba(150,190,230,0.18)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(sx, by + 64); ctx.lineTo(sx, by + bh - 92); ctx.stroke();
  const pct = v => Math.round((v || 0) * 100);
  const L = [
    ['伤害', '×' + ar.dmgMul.toFixed(2)],
    ['射速', '×' + (1 / ar.rofMul).toFixed(2)],
    ['移速', '×' + ar.spdMul.toFixed(2)],
    ['暴击', pct(ar.crit) + '% · 暴伤 +' + pct(ar.critDmg) + '%'],
    ['护甲', '-' + pct(ar.armor) + '%'],
    ['回血', (ar.leech || 0) + ' / 杀 · ' + (ar.reg || 0).toFixed(1) + ' / 秒'],
    ['生命', '+' + (ar.hpAdd | 0) + ' · 每波回 ' + pct(ar.waveHeal) + '%'],
    ['贴脸', pct(ar.closeDmg) + '% · 远射 ' + pct(ar.farDmg) + '%'],
    ['背水', pct(ar.rageDmg) + '% · 拾荒 ' + (ar.ammoKill || 0) + ' 发'],
    ['磁力', '+' + (ar.pickR | 0)],
    ['经验', '×' + (ar.xpMul || 1).toFixed(2)],
    ['催场', (ar.calls | 0) + ' 次'],
    ['事件', (ar.events | 0) + ' 次' + (arenaDealOn() ? ' · 孤注 ' + Math.ceil(ar.dealT) + ' 秒' : '')]
  ];
  let y = by + 88;
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  for (const it of L){
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(190,206,224,0.62)';
    ctx.fillText(it[0], sx + 20, y);
    ctx.textAlign = 'right';
    ctx.fillStyle = 'rgba(240,246,252,0.92)';
    ctx.fillText(it[1], bx + bw - 30, y);
    y += 21;
  }

  /* 鼠标停在哪张卡上，就在下面展开它的详细说明 —— 卡面只有一行简略，
     隐藏冷却、叠加上限这些容易吃亏的东西放在这里慢慢看 */
  let _hov = null;
  for (let i = 0; i < rows.length; i++){
    const hx = bx + 30 + Math.floor(i / perCol) * colW;
    const hy = top + (i % perCol) * rowH;
    if (mouse.x >= hx - 4 && mouse.x <= hx + colW - 34 &&
        mouse.y >= hy - 15 && mouse.y <= hy + 9){ _hov = rows[i]; break; }
  }
  if (_hov){
    const _u = UPGRADES.find(u => u.name === _hov.name);
    const _t = upgDetail(_u);
    const _w2 = 3 * colW - 40, _x2 = bx + 30;
    ctx.textAlign = 'left';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    const _ls = [];
    let _c2 = '';
    for (const c of _t){
      if (ctx.measureText(_c2 + c).width > _w2 - 20){ _ls.push(_c2); _c2 = c; }
      else _c2 += c;
    }
    if (_c2) _ls.push(_c2);
    const _h2 = 24 + _ls.length * 17;
    const _y2 = by + bh - 96 - _h2;          /* 贴着底部提示往上排，行数多了也不会压到按钮 */
    ctx.fillStyle = 'rgba(10,15,22,0.92)';
    roundRect(_x2, _y2, _w2, _h2, 8); ctx.fill();
    ctx.strokeStyle = 'rgba(150,190,230,0.22)'; ctx.lineWidth = 1;
    roundRect(_x2, _y2, _w2, _h2, 8); ctx.stroke();
    ctx.fillStyle = 'rgba(255,226,160,0.85)';
    ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
    ctx.fillText(_hov.name, _x2 + 12, _y2 + 18);
    ctx.fillStyle = 'rgba(206,220,236,0.88)';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    for (let k = 0; k < _ls.length; k++) ctx.fillText(_ls[k], _x2 + 12, _y2 + 36 + k * 17);
  } else {
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(190,206,224,0.34)';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('鼠标停在卡上能看详细说明（层数上限、隐藏冷却）', bx + 30, top + perCol * rowH + 24);
  }

  /* 底：继续 / 回大厅（和正式关卡的 Esc 一模一样） */
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(200,214,230,0.40)';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText('Esc 继续躲着   ·   Enter 确认回大厅', W/2, by + bh - 84);
  btn(W/2 - 180, by + bh - 66, 170, 44, '继续躲着', ()=>{
    confirmBack = false; logInfo('ui', '取消回大厅，继续本局');
  }, { primary: true, dark: true });
  btn(W/2 + 10, by + bh - 66, 170, 44, '回大厅', ()=>{
    confirmBack = false; logInfo('ui', '确认回大厅');
    goMenu();
  }, { dark: true });
}

/* 指向最近敌人的箭头：光靠屏幕找不到最后一个人很抓狂 */
function drawArenaArrow(){
  if (!ar || state !== 'play' || !enemies.length) return;
  let best = null, bd = 1e9;
  for (const e of enemies){
    const d = dist(player.x, player.y, e.x, e.y);
    if (d < bd){ bd = d; best = e; }
  }
  if (!best) return;

  ctx.save();
  ctx.setTransform(1,0,0,1,0,0);

  const px = player.x - cam.x, py = player.y - cam.y;
  const ex = best.x - cam.x, ey = best.y - cam.y;
  const ang = Math.atan2(ey - py, ex - px);
  const onScreen = ex > 40 && ex < W-40 && ey > 40 && ey < H-40;
  const solo = enemies.length === 1;

  if (onScreen && !solo){ ctx.restore(); return; }

  if (onScreen && solo){
    /* 只剩一个：直接在它头上标出来 */
    const pulse = 0.6 + 0.4*Math.sin(uiT*6);
    ctx.strokeStyle = 'rgba(255,214,120,' + (0.55 + 0.35*pulse).toFixed(2) + ')';
    ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.arc(ex, ey, 22 + pulse*6, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(255,224,150,0.95)';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('最后一个', ex, ey - 30);
    ctx.restore();
    return;
  }

  /* 不在屏幕里：在你身边画一个指向它的箭头 + 距离 */
  const ox = px + Math.cos(ang) * 44;
  const oy = py + Math.sin(ang) * 44;
  const pulse = 0.5 + 0.5*Math.sin(uiT*7);
  ctx.translate(ox, oy); ctx.rotate(ang);
  ctx.beginPath();
  ctx.moveTo(17, 0); ctx.lineTo(-8, 8.5); ctx.lineTo(-3, 0); ctx.lineTo(-8, -8.5);
  ctx.closePath();
  ctx.strokeStyle = 'rgba(20,14,6,0.55)'; ctx.lineWidth = 2.4; ctx.stroke();
  ctx.fillStyle = 'rgba(255,206,110,' + (0.6 + 0.35*pulse).toFixed(2) + ')';
  ctx.fill();
  ctx.restore();

  ctx.save(); ctx.setTransform(1,0,0,1,0,0);
  ctx.fillStyle = 'rgba(255,214,140,0.85)';
  ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(Math.round(bd) + '', px + Math.cos(ang) * 74, py + Math.sin(ang) * 74 + 4);
  ctx.restore();
}

/* 清波特写 + 三秒倒计时 */
function drawArenaCine(){
  if (!ar || state !== 'play' || !(ar.inter > 0)) return;
  ctx.save();
  ctx.setTransform(1,0,0,1,0,0);

  const dur = ARENA_INTER;
  const inK  = Math.min(1, Math.max(0, (dur - ar.inter) / 0.45));   /* 压下来 */
  const outK = Math.min(1, Math.max(0, ar.inter / 0.75));            /* 慢慢收回去 */
  const raw  = Math.min(inK, outK);
  const e    = raw * raw * (3 - 2 * raw);                            /* smoothstep，不会硬切 */
  if (e <= 0.001){ ctx.restore(); return; }

  /* 聚光：只留尸体附近一圈亮，其余压暗 */
  const hole = Math.min(W, H) * 0.30;
  const gs = ctx.createRadialGradient(W/2, H/2, hole * 0.62, W/2, H/2, hole * 2.0);
  gs.addColorStop(0, 'rgba(0,0,0,0)');
  gs.addColorStop(0.55, 'rgba(8,6,6,' + (0.40 * e).toFixed(3) + ')');
  gs.addColorStop(1, 'rgba(5,4,4,' + (0.90 * e).toFixed(3) + ')');
  ctx.fillStyle = gs; ctx.fillRect(0, 0, W, H);

  /* 冲击径向线：一瞬间吃掉视野 */
  if (ar.cineLines > 0.01){
    /* 冲击波：一圈从尸体上扩散开的暖白环，比一堆射线干净得多 */
    const k2 = 1 - ar.cineLines;
    const _cx = ar.cineX - cam.x, _cy = ar.cineY - cam.y;
    ctx.save();
    for (let q = 0; q < 2; q++){
      const rq = hole * (0.28 + k2 * 1.9 + q * 0.34);
      const aq = ar.cineLines * (q === 0 ? 0.50 : 0.26);
      ctx.strokeStyle = 'rgba(255,240,220,' + aq.toFixed(3) + ')';
      ctx.lineWidth = (q === 0 ? 3 : 1.6) * ar.cineLines + 0.6;
      ctx.beginPath(); ctx.arc(_cx, _cy, rq, 0, TAU); ctx.stroke();
    }
    ctx.restore();
  }

  /* 一闪 + 周围一圈血色 */
  if (ar.cineFlash > 0){
    ctx.fillStyle = 'rgba(255,246,235,' + (0.42 * ar.cineFlash).toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
  }
  const gr = ctx.createRadialGradient(W/2, H/2, Math.min(W, H) * 0.34, W/2, H/2, Math.max(W, H) * 0.66);
  gr.addColorStop(0, 'rgba(150,20,14,0)');
  gr.addColorStop(1, 'rgba(150,20,14,' + (0.16 * e).toFixed(3) + ')');
  ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);

  const bar = 78 * e;
  ctx.fillStyle = 'rgba(0,0,0,0.92)';
  ctx.fillRect(0, 0, W, bar);
  ctx.fillRect(0, H - bar, W, bar);

  /* 标题：带一点径向收束的感觉 */
  const cine = Math.min(1, Math.max(0, ar.cineT / 1.1));
  ctx.save();
  ctx.translate(W/2, H * 0.30);
  const sc = 1 + cine * 0.05;
  ctx.scale(sc, sc);
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(255,222,150,' + (0.96 * e).toFixed(2) + ')';
  ctx.font = 'bold 46px "Microsoft YaHei",sans-serif';
  ctx.fillText('第 ' + ar.wave + ' 波 清空', 0, 0);
  ctx.restore();

  /* 倒计时 */
  const a = 0.9 * e;
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(226,236,246,' + (a * 0.85).toFixed(2) + ')';
  ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
  ctx.fillText('下一波', W/2, H * 0.125);
  const n = Math.max(1, Math.ceil(ar.inter));
  ctx.fillStyle = 'rgba(255,214,140,' + a.toFixed(2) + ')';
  ctx.font = 'bold 54px "Microsoft YaHei",sans-serif';
  ctx.fillText(String(n), W/2, H * 0.125 + 50);
  const bw = 200, bx = W/2 - bw/2, by = H * 0.125 + 68;
  ctx.fillStyle = 'rgba(255,255,255,' + (0.14 * e).toFixed(2) + ')';
  roundRect(bx, by, bw, 6, 3); ctx.fill();
  ctx.fillStyle = 'rgba(255,206,120,' + (0.9 * e).toFixed(2) + ')';
  roundRect(bx, by, Math.max(2, bw * (ar.inter / dur)), 6, 3); ctx.fill();
  ctx.restore();
}

function drawArenaBossBar(){
  const b = arenaBossAlive();
  if (!b) return;
  const w = 460, x = W/2 - w/2, y = 96, h = 12;
  ctx.save();
  ctx.fillStyle = 'rgba(8,10,14,0.82)';
  ctx.fillRect(x - 6, y - 24, w + 12, 46);
  ctx.strokeStyle = 'rgba(226,120,80,0.55)'; ctx.lineWidth = 1;
  ctx.strokeRect(x - 6.5, y - 24.5, w + 13, 47);
  ctx.textAlign = 'left';
  ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#ffb28a';
  ctx.fillText(b.bossName || '督军', x, y - 8);
  ctx.textAlign = 'right';
  ctx.fillStyle = 'rgba(220,200,180,0.75)';
  ctx.fillText(Math.max(0, Math.ceil(b.hp)) + ' / ' + Math.ceil(b.maxHp), x + w, y - 8);
  ctx.fillStyle = 'rgba(40,26,22,0.95)';
  ctx.fillRect(x, y, w, h);
  const f = Math.max(0, Math.min(1, b.hp / Math.max(1, b.maxHp)));
  ctx.fillStyle = '#e2703c';
  ctx.fillRect(x, y, w * f, h);
  ctx.fillStyle = 'rgba(255,210,180,0.85)';
  ctx.fillRect(x, y, w * f, 3);
  if (b.bossTip){
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255,196,160,0.62)';
    ctx.font = '11px "Microsoft YaHei",sans-serif';
    ctx.fillText(b.bossTip, W/2, y + h + 15);
  }
  ctx.restore();
}

/* ---------------- 洗牌：摊开已有卡，选两张扔掉，再随机补两张 ---------------- */
/* 洗牌不洗「一次性」的卡：它们的效果当场就用掉了（无敌、自动瞄准、抽卡、孤注一掷），
   洗掉等于白扔一张；也不洗「洗牌」自己，否则补牌时又抽到它会再弹一层。 */
const ONCE_UPG = { shuffle: 1, draw2: 1, draw4: 1, god: 1, aim: 1, deal: 1, allin: 1 };
/* 把卡的颜色换算成色相（0~360），用来让同色的牌挨在一起；不是 #rrggbb 就排到最后 */
function toneHue(t){
  if (typeof t !== 'string' || t.charAt(0) !== '#' || t.length < 7) return 999;
  const r = parseInt(t.substr(1, 2), 16) / 255;
  const g = parseInt(t.substr(3, 2), 16) / 255;
  const b = parseInt(t.substr(5, 2), 16) / 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  if (d < 0.0001) return 999;
  let h;
  if (mx === r) h = ((g - b) / d) % 6;
  else if (mx === g) h = (b - r) / d + 2;
  else h = (r - g) / d + 4;
  h *= 60;
  return h < 0 ? h + 360 : h;
}

function shuffleItems(){
  const src = (ar && ar.picks) ? ar.picks : [];
  const items = [];
  for (let i = 0; i < src.length; i++){
    const u = UPGRADES.find(function(q){ return q.name === src[i]; });
    /* 只有 cat 是 stack 的卡会留在 picks 里；一次性/特殊卡本来就不进 picks，
       这里再挡一道，免得以后有卡偷偷混进牌位把洗牌的张数搞乱 */
    if (!u || (u.cat || 'stack') !== 'stack') continue;
    items.push({ pi: i, u: u });
  }
  /* 同名的排在一起：组与组的先后按你第一次拿到它的顺序，组内保持原来的先后 */
  /* 先按色相扎堆（红→橙→黄→绿→青→蓝→紫），同色里再把同名的排在一起，
     同色同名保持原来的先后。这样一眼扫过去是成块的，不是散的。 */
  items.sort(function(a, b){
    const ha = toneHue(a.u.tone), hb = toneHue(b.u.tone);
    if (Math.abs(ha - hb) > 0.001) return ha - hb;
    if (a.u.name !== b.u.name) return a.u.name < b.u.name ? -1 : 1;
    return a.pi - b.pi;
  });
  return items;
}

function openShuffle(){
  if (!ar) return;
  if (ar.shuf) return;            /* 已经开着一层了，别再叠 */
  if (ar._shufBusy) return;       /* 抽卡途中抽到「洗牌」卡：不能套娃 */
  const items = shuffleItems();
  if (items.length < 2){
    /* 兜底：正常不会发生（发卡时就跳过这张），真撞上了就不消耗直接算了 */
    setMsg('手上的牌不够洗 · 这张不算', 2.0);
    return;
  }
  ar.shuf = { sel: [], row: 0, t: 0, items: items, openedAt: (typeof performance !== 'undefined' ? performance.now() : Date.now()) };
  ar.freeze = true;
}
function closeShuffle(){
  if (!ar) return;
  ar.shuf = null;
  ar.armIdx = -1;
  /* 选完这张卡以后，把选卡流程接着走完（重新发一批卡给玩家挑） */
  arenaOffer();
}

/* ---------------- 梭哈 ----------------
   和洗牌走同一套「摊牌」界面，区别是不让点、全扔、一次换回来。
   两步都要摊给玩家看：先摊旧的（这些全没了），再摊新的（多给的那张标「新」）。 */
function openAllin(){
  if (!ar) return;
  if (ar.shuf) return;
  if (ar._shufBusy) return;
  const items = shuffleItems();
  if (!ar.picks.length){
    setMsg('手上没牌 · 梭哈不生效', 2.0);
    return;
  }
  ar.shuf = { sel: [], row: 0, t: 0, items: items, readonly: true, mode: 'allin', n: items.length,
               openedAt: (typeof performance !== 'undefined' ? performance.now() : Date.now()), armed: false };
  ar.freeze = true;
}

function allinPool(a){
  /* 能换到的卡：只换 cat 是 stack 的（一次性/特殊卡不占牌位，混进来就凑不齐"原数量 + 1"） */
  return cardPoolFor(a, 'swap');
}

function allinConfirm(force){
  if (!ar || !ar.shuf || ar.shuf.mode !== 'allin') return;
  /* 摊牌是给人看的，不是拿来点的：先给一点反应时间，再要求按两次，
     免得"想滚动看一眼"的那一下直接把牌全换掉。
     force=true 只给"已经确认过"的调用方（按钮第二次点击 / 测试）用。 */
  const _now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
  if (!force && _now - (ar.shuf.openedAt || 0) < 420) return;
  if (!force && !ar.shuf.armed){
    ar.shuf.armed = true;
    setMsg('再点一次「确认换牌」才会真的换 · 现在还能上下翻着看', 2.4);
    beep(520, 0.08, 'triangle', 0.04, 660);
    return;
  }
  /* 张数以摊出来给玩家看的那几张为准（和标题、按钮上的数字必须对得上） */
  const n = (ar.shuf.n || ar.picks.length);
  const pool = allinPool(ar);
  const names = [];
  /* 换到的卡：一共 n+1 层，允许抽到同一张的不同层（这样才可能换出高等级卡），
     但每张卡都卡在它自己的 max 上 —— 不会出现"A 满级 2 级却给了 3 张"的溢出。 */
  const cnt = Object.create(null);
  for (let i = 0; i < n + 1; i++){
    const cand = [];
    for (const u of pool){
      const cap = (u.max || 99);
      if ((cnt[u.name] || 0) < cap) cand.push(u);
    }
    if (!cand.length) break;
    /* 有一半几率往"已经抽到过的卡"上加层：这样梭哈才真能叠出高等级，
       全随机洗六张时几乎不可能出现两张同名（池子三十来张）。 */
    let pickPool = cand;
    if (cnt && arenaRandom() < 0.5){
      const again = cand.filter(function(u){ return (cnt[u.name] || 0) > 0; });
      if (again.length) pickPool = again;
    }
    const u = pickPool[Math.floor(arenaRandom() * pickPool.length)];
    cnt[u.name] = (cnt[u.name] || 0) + 1;
    names.push(u.name);
  }
  ar.shuf = null;
  ar.picks.length = 0;
  ar.banIdx = [];                  /* 旧牌全没了，巢母的封条也跟着作废 */
  for (const nm of names) ar.picks.push(nm);
  ar._shufBusy = false;
  arenaRebuildStats();
  const cards = [];
  for (let i = 0; i < names.length; i++){
    const u = UPGRADES.find(function(q){ return q.name === names[i]; });
    if (!u) continue;
    cards.push({ id: u.id, name: u.name, desc: u.desc, tone: u.tone || '#ffd24a', trade: !!u.trade,
                 max: u.max || 0, count: names.filter(function(x){ return x === u.name; }).length,
                 isNew: (i === names.length - 1) });   /* 最后那张就是多给的一张 */
  }
  ar.drawShow = {
    title: '梭哈 · 换到 ' + names.length + ' 张',
    sub: '标「新」的那张是多给你的 · 按任意键继续',
    cards: cards, t: 0, closed: !cards.length, from: 'allin'
  };
  ar.freeze = true;
  if (names.length) logInfo('upg', '梭哈 · ' + names.join(' / '));
}
function shuffleLayout(){
  const items = (ar && ar.shuf && ar.shuf.items) ? ar.shuf.items : [];
  const cols = 3, cw = 240, chh = 128, gapX = 22, gapY = 14;
  const rows = Math.ceil(items.length / cols);
  const pitch = chh + gapY;
  const bw = cols * cw + (cols - 1) * gapX;
  const bx = W/2 - bw/2;
  /* 固定视口：标题和按钮不吃卡片的地盘，卡片多了就按行滚 */
  const top = 92, bottom = 676;
  const viewH = bottom - top;
  const perPage = Math.max(1, Math.floor((viewH + gapY) / pitch));
  const maxRow = Math.max(0, rows - perPage);
  const row = clamp((ar && ar.shuf) ? (ar.shuf.row || 0) : 0, 0, maxRow);
  if (ar && ar.shuf !== undefined && ar.shuf) ar.shuf.row = row;
  const firstCard = Math.min(items.length, row * cols + 1);
  const lastCard = Math.min(items.length, (row + perPage) * cols);
  /* 一屏放得下就上下居中，放不下才从顶上开始滚 */
  const contentH = rows ? (rows * chh + (rows - 1) * gapY) : 0;
  const padTop = (maxRow <= 0) ? Math.max(0, (viewH - contentH) / 2) : 0;
  return { items, cols, cw, chh, gapX, gapY, rows, pitch, bw, bx,
           top, bottom, viewH, perPage, maxRow, row, firstCard, lastCard, padTop,
           offsetY: row * pitch };
}
function shuffleScroll(d){
  if (!ar || !ar.shuf) return;
  const L = shuffleLayout();
  if (L.maxRow <= 0) return;
  const n = clamp(L.row + d, 0, L.maxRow);
  if (n === L.row) return;
  ar.shuf.row = n;
  beep(300, 0.03, 'square', 0.02, 340);
}
function shuffleCardAt(L, i){
  const c = i % L.cols, r = Math.floor(i / L.cols);
  return { x: L.bx + c * (L.cw + L.gapX), y: L.top + L.padTop + r * L.pitch - L.offsetY };
}
function shuffleHit(mx, my){
  const L = shuffleLayout();
  if (my < L.top || my > L.bottom) return -1;
  for (let i = 0; i < L.items.length; i++){
    const p = shuffleCardAt(L, i);
    if (mx >= p.x && mx <= p.x + L.cw && my >= p.y && my <= p.y + L.chh) return i;
  }
  return -1;
}
function shuffleToggle(pos){
  const L = shuffleLayout();
  const it = L.items[pos];
  if (!it || !ar || !ar.shuf) return;
  const sel = ar.shuf.sel;
  const k = sel.indexOf(it.pi);
  if (k >= 0){ sel.splice(k, 1); beep(320, 0.05, 'square', 0.03, 260); return; }
  if (sel.length >= 2){ setMsg('最多去掉 2 张', 1.2); beep(180, 0.08, 'square', 0.04); return; }
  sel.push(it.pi);
  beep(520, 0.06, 'square', 0.035, 620);
}
function shuffleConfirm(){
  if (!ar || !ar.shuf) return;
  if (ar.shuf.sel.length !== 2){ setMsg('要点掉正好 2 张', 1.2); return; }
  const drop = ar.shuf.sel.slice().sort((a,b)=>b-a);
  /* 封卡的索引指向 ar.picks，删牌前先把它们映射到新位置，否则会封错牌 */
  if (ar.banIdx && ar.banIdx.length){
    const oldN = ar.picks.length, remap = [];
    let _nn = 0;
    for (let q = 0; q < oldN; q++) if (drop.indexOf(q) < 0) remap[q] = _nn++;
    ar.banIdx = ar.banIdx.map(q => remap[q]).filter(q => q !== undefined);
  }
  for (const i of drop) ar.picks.splice(i, 1);
  beep(660, 0.12, 'triangle', 0.05, 880);
  logInfo('upg', '洗牌 · 去掉 2 张 · 剩 ' + ar.picks.length + ' 张');
  ar.shuf = null;
  ar.armIdx = -1;   /* 保留尚未领取的 BOSS 选卡奖励 */
  ar._shufBusy = true;                    /* 补牌时又抽到「洗牌」卡，会立刻再弹一层 */
  try { drawCards(ar, 2); } finally { ar._shufBusy = false; }   /* 补两张：一样走翻牌展示 */
  /* 被扔掉的那两张的效果必须一起退掉，否则删了牌属性还留着。
     放在 drawCards 之后：先让新卡 apply 一遍，再从 picks 整体重放，结果一致但不会漏 */
  arenaRebuildStats();
  ar.drawShow.from = 'shuffle';           /* 关的时候直接放行世界，不再发一批卡 */
  ar.drawShow.t = 0;
  ar.freeze = true;
  setMsg('洗牌完成 · 现在 ' + ar.picks.length + ' 张（补了 2 张）', 2.0);
}
function drawShuffle(){
  if (!ar || !ar.shuf) return;
  const L = shuffleLayout();
  const _ro = !!ar.shuf.readonly;         /* 梭哈：把旧牌摊出来给你看，但不让你点 */
  uiButtons = [];
  ctx.save();
  ctx.fillStyle = 'rgba(4,7,11,0.97)';
  ctx.fillRect(0, 0, W, H);

  /* 标题钉在顶上，不被卡片挤走 */
  ctx.textAlign = 'center';
  ctx.fillStyle = _ro ? '#ffb0d0' : '#d9c8ff';
  ctx.font = 'bold 28px "Microsoft YaHei",sans-serif';
  ctx.shadowColor = _ro ? 'rgba(255,120,170,0.5)' : 'rgba(190,150,255,0.5)'; ctx.shadowBlur = 16;
  ctx.fillText(_ro ? ('梭哈 · 这 ' + L.items.length + ' 张全扔掉') : '洗牌 · 去掉 2 张', W/2, 44);
  ctx.shadowBlur = 0;
  ctx.fillStyle = 'rgba(220,232,244,0.62)';
  ctx.font = '14px "Microsoft YaHei",sans-serif';
  let _tip = _ro
    ? ('看一眼，按下面那个按钮就全没了 —— 马上换 ' + ((ar.shuf.n || ar.picks.length) + 1) + ' 张新的回来')
    : ('点卡片选中，再点一次取消 · 去掉的两张换成两张随机新卡（已选 ' + ar.shuf.sel.length + ' / 2）');
  if (L.maxRow > 0) _tip += ' · 滚轮 / ↑↓ 翻看';
  ctx.fillText(_tip, W/2, 72);

  /* 卡片区：超出视口的裁掉，滚出屏幕的卡也不登记按钮 */
  ctx.save();
  ctx.beginPath(); ctx.rect(0, L.top, W, L.viewH); ctx.clip();
  for (let i = 0; i < L.items.length; i++){
    const p = shuffleCardAt(L, i);
    if (p.y < L.top - 1 || p.y + L.chh > L.bottom + 1) continue;   /* 只画整行，别露半张卡 */
    const x = p.x, y = p.y;
    const it = L.items[i], u = it.u;
    const on = !_ro && ar.shuf.sel.indexOf(it.pi) >= 0;
    const hv = !_ro && mouse.x >= x && mouse.x <= x + L.cw && mouse.y >= y && mouse.y <= y + L.chh;
    ctx.fillStyle = _ro ? 'rgba(40,18,26,0.96)' : on ? 'rgba(66,32,28,0.98)' : hv ? 'rgba(30,44,60,0.98)' : 'rgba(16,24,34,0.96)';
    roundRect(x, y, L.cw, L.chh, 14); ctx.fill();
    ctx.strokeStyle = _ro ? 'rgba(255,120,160,0.38)' : on ? '#ff9a86' : hv ? u.tone : 'rgba(140,170,200,0.32)';
    ctx.lineWidth = _ro ? 1.4 : on ? 2.8 : hv ? 2.2 : 1.2;
    roundRect(x, y, L.cw, L.chh, 14); ctx.stroke();
    /* 被划掉的卡：上面盖一条斜杠，一眼看出这张要扔 / 全扔 */
    if (on || _ro){
      ctx.save();
      ctx.strokeStyle = _ro ? 'rgba(255,120,150,0.42)' : 'rgba(255,120,100,0.55)';
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(x + 16, y + L.chh - 20);
      ctx.lineTo(x + L.cw - 16, y + 20);
      ctx.stroke();
      ctx.restore();
    }
    cardBadge(u.id, x + 26, y + 26, 9, u.tone);
    ctx.fillStyle = _ro ? 'rgba(255,190,210,0.72)' : u.tone;
    ctx.font = 'bold 19px "Microsoft YaHei",sans-serif';
    ctx.fillText(u.name, x + L.cw/2, y + 44);
    ctx.fillStyle = 'rgba(226,236,246,0.82)';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    let line = '', ly = y + 68, _ln = 0;
    for (const ch2 of (u.desc || '')){
      if (ctx.measureText(line + ch2).width > L.cw - 34){
        ctx.fillText(line, x + L.cw/2, ly); line = ch2; ly += 16;
        if (++_ln >= 2) break;
      } else line += ch2;
    }
    if (line && _ln < 2) ctx.fillText(line, x + L.cw/2, ly);
    ctx.fillStyle = _ro ? 'rgba(255,160,180,0.7)' : on ? '#ff9a86' : 'rgba(200,214,230,0.62)';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.fillText(_ro ? '扔掉' : on ? '去掉' : ('[' + (i + 1) + ']'), x + L.cw/2, y + L.chh - 14);
    if (!_ro) btn(x, y, L.cw, L.chh, '', ()=>shuffleToggle(i), {dark:true, invisible:true});
  }
  ctx.restore();

  /* 右侧滚动条 + 上下翻页（只有一屏时都不画） */
  if (L.maxRow > 0){
    const sx = L.bx + L.bw + 26;
    const trackH = L.viewH;
    const thumbH = Math.max(46, trackH * Math.min(1, L.perPage / Math.max(1, L.rows)));
    const ty = L.top + (trackH - thumbH) * (L.row / L.maxRow);
    ctx.fillStyle = 'rgba(255,255,255,0.07)';
    roundRect(sx, L.top, 6, trackH, 3); ctx.fill();
    ctx.fillStyle = 'rgba(190,150,255,0.6)';
    roundRect(sx, ty, 6, thumbH, 3); ctx.fill();
    btn(sx - 22, L.top - 44, 50, 32, '▲', ()=>shuffleScroll(-1), {dark:true, dim: L.row <= 0});
    btn(sx - 22, L.bottom + 6, 50, 32, '▼', ()=>shuffleScroll(1), {dark:true, dim: L.row >= L.maxRow});
  }

  /* 已选的卡名，滚走了也记得住挑的是哪两张 */
  const _selNames = ar.shuf.sel.map(pi => ar.picks[pi]).filter(Boolean);
  ctx.textAlign = 'center';
  ctx.font = '14px "Microsoft YaHei",sans-serif';
  if (_ro){
    /* 梭哈：没有"去选"这一步，只有"换" */
    ctx.fillStyle = '#ff9a86';
    ctx.fillText('这 ' + L.items.length + ' 张全部作废 · 换 ' + ((ar.shuf.n || ar.picks.length) + 1) + ' 张新的回来（多给一张）', W/2, 698);
    btn(W/2 - 130, 714, 260, 48,
        (!ar.shuf.armed ? ('换 ' + ((ar.shuf.n || ar.picks.length) + 1) + ' 张（先看一眼）')
                        : ('确认换 ' + ((ar.shuf.n || ar.picks.length) + 1) + ' 张（再点一次）')),
        ()=>allinConfirm(!!ar.shuf.armed), { dark: true, primary: !!ar.shuf.armed });
    ctx.restore();
    flushButtons();
    return;
  }
  ctx.fillStyle = _selNames.length ? '#ff9a86' : 'rgba(200,214,230,0.5)';
  ctx.fillText(_selNames.length ? ('要去掉：' + _selNames.join(' · '))
                                : ('共 ' + L.items.length + ' 张（' + L.firstCard + '–' + L.lastCard + ' 在屏幕上 · 同色同名已排在一起），挑 2 张去掉'),
               W/2, 698);

  const okOn = ar.shuf.sel.length === 2;
  btn(W/2 - 110, 714, 220, 48, okOn ? '确认洗牌' : ('还差 ' + (2 - ar.shuf.sel.length) + ' 张'), ()=>{ if (okOn) shuffleConfirm(); }, { dark: true, primary: okOn });
  ctx.restore();
  flushButtons();       /* btn() 只是登记，真正画出来要靠这一下 */
}

function drawArenaChoices(){
  if (!ar || ar.shuf) return;
  if (!ar.freeze || !ar.choices || (ar.drawShow && !ar.drawShow.closed)) return;
  uiButtons = [];
  ctx.save();
  ctx.fillStyle = 'rgba(4,7,11,0.72)';
  ctx.fillRect(0, 0, W, H);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffe6b8';
  ctx.font = 'bold 30px "Microsoft YaHei",sans-serif';
  ctx.fillText('升到 Lv.' + ar.level + ' —— 选一个', W/2, H/2 - 150);
  ctx.fillStyle = 'rgba(220,232,244,0.55)';
  ctx.font = '14px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = ar.armIdx >= 0 ? '#ffe6b8' : 'rgba(220,232,244,0.55)';
  ctx.font = '14px "Microsoft YaHei",sans-serif';
  ctx.fillText(ar.armIdx >= 0 ? '再点一次同一张确认 · 点别的卡就换一张'
                             : '点卡片（要点两次确认），或者按 1 / 2 / 3 再按一次', W/2, H/2 - 118);

  const cw = 260, ch = 210, gap = 22;
  const total = cw*3 + gap*2;
  const x0 = W/2 - total/2, y0 = H/2 - ch/2;
  for (let i=0;i<ar.choices.length;i++){
    const u = ar.choices[i];
    const bx = x0 + i*(cw+gap);
    const hv = mouse.x >= bx && mouse.x <= bx+cw && mouse.y >= y0 && mouse.y <= y0+ch;
    const armed = ar.armIdx === i;
    if (armed && u.id === 'honest') drawHonestGlow(bx, y0, cw, ch, false);   /* 血雾垫在卡牌底下 */
    ctx.fillStyle = armed ? 'rgba(58,46,18,0.98)' : hv ? 'rgba(30,44,60,0.98)' : 'rgba(16,24,34,0.96)';
    roundRect(bx, y0, cw, ch, 14); ctx.fill();
    ctx.strokeStyle = armed ? '#ffe6b8' : hv ? u.tone : 'rgba(140,170,200,0.35)';
    ctx.lineWidth = armed ? 3.0 : hv ? 2.4 : 1.3;
    roundRect(bx, y0, cw, ch, 14); ctx.stroke();

    if (u.trade){
      ctx.fillStyle = 'rgba(255,86,72,0.20)';
      roundRect(bx + cw/2 - 34, y0 + 16, 68, 22, 11); ctx.fill();
      ctx.strokeStyle = 'rgba(255,120,104,0.85)'; ctx.lineWidth = 1.2;
      roundRect(bx + cw/2 - 34, y0 + 16, 68, 22, 11); ctx.stroke();
      ctx.fillStyle = '#ffb3a6';
      ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
      ctx.fillText('取舍', bx + cw/2, y0 + 32);
    }
    ctx.textAlign = 'center';
    cardBadge(u.id, bx + 26, y0 + (u.trade ? 30 : 26), 9, u.tone);
    ctx.fillStyle = u.tone;
    ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
    ctx.fillText(u.name, bx + cw/2, y0 + (u.trade ? 72 : 56));
    ctx.fillStyle = 'rgba(226,236,246,0.86)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    const parts = u.desc.split('');
    let line = '', ly = y0 + (u.trade ? 100 : 86), _ln = 0;
    for (const ch2 of parts){
      if (ctx.measureText(line + ch2).width > cw - 44){
        ctx.fillText(line, bx + cw/2, ly); line = ch2; ly += 19;
        if (++_ln >= 2) break;
      } else line += ch2;
    }
    if (line && _ln < 2) ctx.fillText(line, bx + cw/2, ly);

    /* 现在再拿一张会变成多少：用的是玩家当前面板，不是写死的文案 */
    const _nx = upgNext(u);
    if (_nx){
      ctx.fillStyle = 'rgba(255,226,160,0.95)';
      let _fs = 12.5;
      const _setF = v => { ctx.font = v + 'px "Microsoft YaHei",sans-serif'; };
      _setF(_fs);
      while (_fs > 9 && ctx.measureText(_nx).width > cw - 24){ _fs -= 0.5; _setF(_fs); }
      ctx.fillText(_nx, bx + cw/2, y0 + ch - 70);
    }

    /* 这张卡已经拿了几张 / 最多几张：让玩家自己判断还值不值得拿 */
    const _cnt = ar.picks.filter(n => n === u.name).length;
    const _mx = u.max || 99;
    ctx.fillStyle = _mx < 99 ? 'rgba(200,214,230,0.52)' : 'rgba(200,214,230,0.34)';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('已拿 ' + _cnt + (_mx < 99 ? ' / ' + _mx : ''), bx + cw/2, y0 + ch - 42);

    ctx.fillStyle = 'rgba(255,255,255,0.30)';
    ctx.font = 'bold 13px monospace';
    ctx.fillText('[' + (i+1) + ']' + (armed ? '  再点一次' : ''), bx + cw/2, y0 + ch - 16);

    if (armed && u.id === 'honest') drawHonestGlow(bx, y0, cw, ch, true);    /* 卡框自己发烫，压在内容上面 */
    btn(bx, y0, cw, ch, '', ()=>arenaArm(i), {dark:true});
  }

  /* 第一次点只是"举起来"，这时在下面展开这张卡的详细说明：
     隐藏冷却、层数上限、乘算还是加算都写清楚，不用去猜 */
  if (ar.armIdx >= 0 && ar.choices[ar.armIdx]){
    const _u = ar.choices[ar.armIdx];
    const _text = upgDetail(_u);
    const _dw = Math.min(W - 160, 980), _dx = W/2 - _dw/2, _dy = y0 + ch + 16;
    ctx.textAlign = 'left';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    const _dl = [];
    let _cur = '';
    for (const c of _text){
      if (ctx.measureText(_cur + c).width > _dw - 36){ _dl.push(_cur); _cur = c; }
      else _cur += c;
    }
    if (_cur) _dl.push(_cur);
    const _dh = 40 + _dl.length * 20;
    ctx.fillStyle = 'rgba(12,18,26,0.94)';
    roundRect(_dx, _dy, _dw, _dh, 10); ctx.fill();
    ctx.strokeStyle = 'rgba(255,226,160,0.38)'; ctx.lineWidth = 1;
    roundRect(_dx, _dy, _dw, _dh, 10); ctx.stroke();
    ctx.fillStyle = 'rgba(255,226,160,0.80)';
    ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
    ctx.fillText('详细 · ' + _u.name, _dx + 18, _dy + 22);
    ctx.fillStyle = 'rgba(214,228,242,0.92)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    for (let k2 = 0; k2 < _dl.length; k2++) ctx.fillText(_dl[k2], _dx + 18, _dy + 44 + k2 * 20);
  }
  ctx.restore();
  /* 卡片是自绘的，按钮只是热区：把按钮画成透明 */
  uiButtons = uiButtons.map(b => (b.invisible = true, b));
  flushTransparentButtons();
}

/* flushButtons 的透明版：只要热区，不要它自己的外框 */
function flushTransparentButtons(){
  const hv = uiHit(mouse.x, mouse.y);
  for (const b of uiButtons){
    if (!b.invisible) continue;
    if (b === hv){ /* 悬停效果由卡片自己画，这里什么也不做 */ }
  }
}

function drawArenaPick(){
  uiButtons = [];
  ctx.save();
  ctx.fillStyle = PAL.P258; ctx.fillRect(0,0,W,H);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffd9a0';
  ctx.font = 'bold 42px "Microsoft YaHei",sans-serif';
  ctx.fillText('战斗，爽！！', W/2, 150);
  ctx.fillStyle = 'rgba(220,232,244,0.6)';
  ctx.font = '16px "Microsoft YaHei",sans-serif';
  ctx.fillText('站在中间，四面八方一直来人。捡经验升级，死了就结束。', W/2, 190);

  const cw = 380, ch = 190, gap = 36;
  const x0 = W/2 - (cw*2+gap)/2, y0 = 250;
  for (let i=0;i<ARENA_MAPS.length;i++){
    const m = ARENA_MAPS[i];
    const bx = x0 + i*(cw+gap);
    const hv = mouse.x >= bx && mouse.x <= bx+cw && mouse.y >= y0 && mouse.y <= y0+ch;
    ctx.fillStyle = hv ? 'rgba(26,38,52,0.96)' : 'rgba(14,20,28,0.9)';
    roundRect(bx, y0, cw, ch, 14); ctx.fill();
    ctx.strokeStyle = hv ? '#8ef0c8' : 'rgba(120,150,180,0.35)';
    ctx.lineWidth = hv ? 2.4 : 1.3;
    roundRect(bx, y0, cw, ch, 14); ctx.stroke();
    ctx.fillStyle = '#ffd9a0';
    ctx.font = 'bold 24px "Microsoft YaHei",sans-serif';
    ctx.fillText(m.name, bx + cw/2, y0 + 78);
    ctx.fillStyle = 'rgba(220,232,244,0.66)';
    ctx.font = '15px "Microsoft YaHei",sans-serif';
    ctx.fillText(m.hint, bx + cw/2, y0 + 112);
    btn(bx, y0, cw, ch, '', ()=>arenaStartSelected(i), {dark:true, invisible:true});
  }

  /* 难度：跟正式关卡共用同一套预设，右上角这一排就是调整的地方 */
  const DW = 84, DH = 32, DG = 8;
  const DX = W - 24 - (DIFF_ORDER.length*DW + DG*(DIFF_ORDER.length-1));
  DIFF_ORDER.forEach((kn, i)=>{
    btn(DX + i*(DW+DG), 30, DW, DH, DIFF_LABEL[kn], ()=>{
      applyPreset(kn, false);
      logInfo('ui', '战斗，爽！！难度改为 ' + DIFF_LABEL[kn]);
    }, { primary: !CFG.dev && diffName === kn });
  });

  btn(W/2-110, 500, 220, 50, '返回存档位', ()=>arenaRunSlotCommand('open-entry'));
  ctx.fillStyle = 'rgba(200,214,228,0.45)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('这是一个独立的模式：正式关卡没有任何变化', W/2, 566);
  ctx.fillText('右上角是难度 · 每 10 波自动跳一档，跳满噩梦就停 · 血量和伤害另有单独调整', W/2, 592);
  ctx.fillStyle = 'rgba(200,214,228,0.34)';
  ctx.fillText('局内：N 催场（有次数限制）· Esc 暂停看加成一览 · 拿卡要点两次', W/2, 614);
  flushButtons();
  ctx.restore();
}

function drawArenaOver(){
  if (!ar) return;
  if (deathView){
    const kk = Math.min(1, Math.max(0, (deathViewT - 0.35) / 0.5));
    if (kk > 0){
      ctx.save();
      ctx.textAlign = 'center';
      ctx.font = '16px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = 'rgba(224,232,244,' + (0.62 * kk).toFixed(2) + ')';
      ctx.fillText('画面已定格 · 按任意键（或点击）看结算', W/2, H - 62);
      ctx.restore();
    }
    return;
  }
  uiButtons = [];
  ctx.save();
  /* 别盖太死：要能看见灰掉的现场和自己的尸体 */
  ctx.fillStyle = 'rgba(4,7,11,0.52)';
  ctx.fillRect(0,0,W,H);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ff9a6a';
  ctx.font = 'bold 44px "Microsoft YaHei",sans-serif';
  ctx.fillText('你倒下了', W/2, 178);

  /* 死法文案（数据流）：比标题小一号，但仍然是这一屏最惹眼的一行 */
  const _msg2 = deathMsgText || '你倒下了';
  let _fs2 = 26;
  const _mw2 = W - 240;
  ctx.font = 'bold ' + _fs2 + 'px "Microsoft YaHei",sans-serif';
  while (_fs2 > 15 && ctx.measureText(_msg2).width > _mw2){
    _fs2 -= 1;
    ctx.font = 'bold ' + _fs2 + 'px "Microsoft YaHei",sans-serif';
  }
  ctx.fillStyle = 'rgba(255,224,206,0.95)';
  ctx.fillText(_msg2, W/2, 214);

  let _k2 = '';
  if (deathHit && deathHit.by) _k2 = '凶手：' + deathKillerName(deathHit.by);
  else if (deathCause === 'bleed') _k2 = '凶手：没有——你是流血流死的';
  else _k2 = '凶手：不明';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(255,150,130,0.8)';
  ctx.fillText(_k2, W/2, 238);

  drawKillerMark();

  /* 总分：结算页的主视觉 */
  ctx.textAlign = 'center';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(200,214,228,0.55)';
  ctx.fillText('总分', W/2, 268);
  const _sc = String(ar.score | 0);
  ctx.save();
  ctx.font = 'bold 76px "Microsoft YaHei",sans-serif';
  ctx.shadowColor = 'rgba(255,196,110,0.45)';
  ctx.shadowBlur = 26;
  ctx.fillStyle = '#ffd79a';
  ctx.fillText(_sc, W/2, 340);
  ctx.restore();
  if (ar.newBest){
    ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = '#7ef0b5';
    ctx.fillText('新纪录', W/2, 366);
  } else if (ar.scoreBest > 0){
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(158,176,196,0.75)';
    ctx.fillText('最高分 ' + ar.scoreBest, W/2, 366);
  }

  const rows = [
    ['撑过', ar.wave + ' 波'],
    ['击杀', ar.kills + ' 个'],
    ['等级', 'Lv.' + ar.level],
    ['存活', ar.time.toFixed(1) + ' 秒'],
    ['难度', (ar.tier | 0) > (ar.tierBase | 0) ? ((DIFF_LABEL[diffName] || diffName) + ' → ' + arenaTierName()) : (DIFF_LABEL[diffName] || diffName)]
  ];
  let y = 402;
  ctx.font = '22px "Microsoft YaHei",sans-serif';
  for (const [k, v] of rows){
    ctx.textAlign = 'right'; ctx.fillStyle = 'rgba(200,214,228,0.6)';
    ctx.fillText(k, W/2 - 20, y);
    ctx.textAlign = 'left'; ctx.fillStyle = '#ffe6b8';
    ctx.fillText(v, W/2 + 20, y);
    y += 36;
  }
  /* 分数是怎么来的，摊开给人看 */
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(168,186,206,0.6)';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText('击杀 ' + (ar.scoreKill | 0) + ' 分 · 清波 ' + (ar.scoreWave | 0) + ' 分 · 难度倍率 ×' +
               (Math.round(arenaScoreMul() * 100) / 100), W/2, y);
  if (ar.picks.length){
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(200,214,228,0.42)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText('本局拿到的：' + ar.picks.join(' · '), W/2, y + 24);
  }

  btn(W/2-250, 584, 230, 52, '再来一局', ()=>arenaRunSlotCommand('open-entry'), {primary:true});
  btn(W/2+20, 584, 230, 52, '换个地图', ()=>arenaRunSlotCommand('open-entry'));
  btn(W/2-110, 648, 220, 40, '回主菜单', ()=>exitArena());
  flushButtons();
  ctx.restore();
}

/* ---------------- 主菜单 ---------------- */
/* ---------------- 画饼按钮（m34024） ----------------
   未完成的模式露出来给玩家看个念想：点了会抖一下、响一声、
   弹一句"敬请期待"，但绝不进游戏。 */
let _teaseT = 0;          /* 抖动剩余秒数 */
let _teaseWho = '';       /* 哪个按钮在抖（只抖那个） */
function teaseDenySfx(){
  if (typeof actx === 'undefined' || !actx) return;
  try{
    const t0 = actx.currentTime;
    for (let i = 0; i < 2; i++){
      const o = actx.createOscillator(); o.type = 'square';
      o.frequency.setValueAtTime(i === 0 ? 180 : 132, t0 + i * 0.09);
      const g = actx.createGain();
      g.gain.setValueAtTime(0.0001, t0 + i * 0.09);
      g.gain.exponentialRampToValueAtTime(0.075, t0 + i * 0.09 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + i * 0.09 + 0.085);
      o.connect(g); g.connect(typeof duckBus === 'function' ? duckBus() : actx.destination);
      o.start(t0 + i * 0.09); o.stop(t0 + i * 0.09 + 0.09);
    }
  }catch(e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
}
let _teaseMsg = '';       /* 画饼提示文字 */
let _teaseMsgT = 0;       /* 提示剩余秒数 */
function teaseTap(who, msg){
  _teaseT = 0.36; _teaseWho = who;
  _teaseMsg = msg || '敬请期待'; _teaseMsgT = 3.4;
  teaseDenySfx();
  _teaseT = 0.36; _teaseWho = who;
  teaseDenySfx();
}
function teaseShakeX(who){
  if (_teaseT <= 0 || _teaseWho !== who) return 0;
  return Math.sin(_teaseT * 130) * 7 * (_teaseT / 0.36);
}

/* ---------------- 自定义地图编辑器 ----------------
   一张网格 + 几排坐标。导出成 JSON；导入时只认数字和数组，不执行任何代码。 */
const MAP_FMT = 'dsh-map';
const MAP_VER = 1;
const GAME_VER = 'v1.0.0';
/* 构建戳：改代码就换一下，用来判断玩家浏览器里跑的是不是最新那份（排查"点不动"时全靠它） */
const BUILD_TAG = '1127a';
let customLvl = null;

const ED = {
  cols: 32, rows: 24, cell: 40, tool: 'wall',
  walls: [], glass: [], loot: [], enemies: [], cams: [],
  start: {c:1, r:22}, exit: {c:30, r:1},
  undo: [], painting: false, msg: '', msgT: 0
};

const ED_TOOLS = [
  {k:'wall',  n:'墙',     c:'#5a6068'},
  {k:'glass', n:'玻璃',   c:'#9ec4d6'},
  {k:'loot',  n:'物资',   c:'#ffd24a'},
  {k:'enemy', n:'敌人',   c:'#d2503c'},
  {k:'cam',   n:'摄像头', c:'#c08cff'},
  {k:'start', n:'起点',   c:'#58d08a'},
  {k:'exit',  n:'终点',   c:'#7ab8ff'},
  {k:'erase', n:'擦掉',   c:'#8a9099'}
];

function edReset(){
  ED.cols = 32; ED.rows = 24; ED.cell = 40; ED.tool = 'wall';
  ED.walls = []; ED.glass = []; ED.loot = []; ED.enemies = []; ED.cams = [];
  ED.start = {c:1, r:22}; ED.exit = {c:30, r:1};
  ED.undo = []; ED.painting = false; ED.msg = ''; ED.msgT = 0;
}
function edKey(c, r){ return c + ',' + r; }
function edGeom(){
  /* 格子边长按“能塞下多少”算，不跟 ED.cell 混在一起：
     ED.cell 是导出到 JSON 里的真实格子尺寸（游戏里的米），跟界面缩放无关 */
  const availW = W - 372, availH = H - 150;
  const s = Math.max(6, Math.min(44, Math.floor(Math.min(availW / ED.cols, availH / ED.rows))));
  return { s: s, ox: 26, oy: 92 };
}
function edCellFromMouse(mx, my){
  const g = edGeom();
  const c = Math.floor((mx - g.ox) / g.s), r = Math.floor((my - g.oy) / g.s);
  if (c < 0 || r < 0 || c >= ED.cols || r >= ED.rows) return null;
  return { c: c, r: r };
}
function edSnap(){
  const st = {
    w: ED.walls.slice(), g: ED.glass.slice(), l: ED.loot.map(function(e){return {c:e.c,r:e.r};}),
    e: ED.enemies.map(function(e){return {c:e.c,r:e.r};}),
    c: ED.cams.map(function(e){return {c:e.c,r:e.r};}),
    s: {c: ED.start.c, r: ED.start.r}, x: {c: ED.exit.c, r: ED.exit.r}
  };
  ED.undo.push(st);
  if (ED.undo.length > 60) ED.undo.shift();
}
function edUndo(){
  const st = ED.undo.pop();
  if (!st){ edSay('没有可撤销的了'); return; }
  ED.walls = st.w.slice(); ED.glass = st.g.slice();
  ED.loot = st.l.map(function(e){return {c:e.c,r:e.r};});
  ED.enemies = st.e.map(function(e){return {c:e.c,r:e.r};});
  ED.cams = st.c.map(function(e){return {c:e.c,r:e.r};});
  ED.start = {c: st.s.c, r: st.s.r}; ED.exit = {c: st.x.c, r: st.x.r};
}
function edSay(t){ ED.msg = t; ED.msgT = 2.6; }

function edToggleIn(list, c, r){
  const k = edKey(c, r), i = list.indexOf(k);
  if (i >= 0) list.splice(i, 1); else list.push(k);
}
function edToggleEnt(list, c, r){
  const i = list.findIndex(function(e){ return e.c === c && e.r === r; });
  if (i >= 0) list.splice(i, 1); else list.push({c: c, r: r});
}
function edClearCell(c, r){
  const k = edKey(c, r);
  let i = ED.walls.indexOf(k); if (i >= 0) ED.walls.splice(i, 1);
  i = ED.glass.indexOf(k); if (i >= 0) ED.glass.splice(i, 1);
  ['loot','enemies','cams'].forEach(function(kk){
    const a = ED[kk], j = a.findIndex(function(e){ return e.c === c && e.r === r; });
    if (j >= 0) a.splice(j, 1);
  });
}
function edPaint(c, r){
  const t = ED.tool;
  if (t === 'erase'){ edClearCell(c, r); return; }
  if (t === 'start' || t === 'exit'){
    edClearCell(c, r);
    if (t === 'start') ED.start = {c: c, r: r}; else ED.exit = {c: c, r: r};
    return;
  }
  /* 先看这一格有没有：有就拿掉，没有才放下去。
     不能“先清后放”——那样清完又放回去，点多少下都拿不掉 */
  if (t === 'wall' || t === 'glass'){
    const arr = (t === 'wall') ? ED.walls : ED.glass;
    const k = edKey(c, r), i = arr.indexOf(k);
    if (i >= 0){ arr.splice(i, 1); return; }
    edClearCell(c, r); arr.push(k); return;
  }
  if (t === 'loot' || t === 'enemy' || t === 'cam'){
    const arr2 = (t === 'loot') ? ED.loot : (t === 'enemy' ? ED.enemies : ED.cams);
    const j = arr2.findIndex(function(e){ return e.c === c && e.r === r; });
    if (j >= 0){ arr2.splice(j, 1); return; }
    edClearCell(c, r); arr2.push({c: c, r: r}); return;
  }
}

/* ---------- 导出 ---------- */
function edToObj(){
  function pairs(list){ return list.map(function(k){ const p = k.split(','); return [+p[0], +p[1]]; }); }
  function ents(list){ return list.map(function(e){ return [e.c, e.r]; }); }
  return {
    fmt: MAP_FMT, ver: MAP_VER,
    cols: ED.cols, rows: ED.rows, cell: ED.cell,
    start: [ED.start.c, ED.start.r],
    exit: [ED.exit.c, ED.exit.r],
    walls: pairs(ED.walls),
    glass: pairs(ED.glass),
    loot: ents(ED.loot),
    enemies: ents(ED.enemies),
    cams: ents(ED.cams)
  };
}
function edToJSON(){
  /* 每个坐标压成 [3, 2] 一行，否则 24x16 的图导出来要好几百行，没法看 */
  return JSON.stringify(edToObj(), null, 1)
    .replace(/\[\s*\n\s*(-?\d+),\s*\n\s*(-?\d+)\s*\n\s*\]/g, '[$1, $2]')
    .replace(/\],\s*\n\s*(?=\[)/g, '], ');
}

/* ---------- 导入（只读数据，绝不执行） ---------- */
function edReadPairs(a, cols, rows){
  if (a === undefined) return [];
  if (!Array.isArray(a)) return null;
  const out = [];
  for (let i = 0; i < a.length; i++){
    const p = a[i];
    if (!Array.isArray(p) || p.length < 2) return null;
    if (typeof p[0] !== 'number' || typeof p[1] !== 'number') return null;
    const c = Math.floor(p[0]), r = Math.floor(p[1]);
    if (c < 0 || r < 0 || c >= cols || r >= rows) continue;
    out.push(edKey(c, r));
  }
  return out;
}
function edParse(txt){
  let o;
  try { o = JSON.parse(txt); } catch(e){ return {err: '不是合法的 JSON'}; }
  if (!o || typeof o !== 'object') return {err: '内容不是一个对象'};
  if (o.fmt !== MAP_FMT) return {err: '这不像本游戏的地图（缺少 fmt:"' + MAP_FMT + '"）'};
  const v = (typeof o.ver === 'number') ? Math.floor(o.ver) : -1;
  if (v !== MAP_VER){
    return {err: '地图版本 ' + (v < 0 ? '未知' : v) + '，当前游戏只认版本 ' + MAP_VER + ' —— 这张图是旧版本导出的，请用现在的编辑器重新导出'};
  }
  const cols = Math.floor(o.cols), rows = Math.floor(o.rows);
  if (!(cols >= 8 && cols <= 60) || !(rows >= 8 && rows <= 44)) return {err: '地图尺寸不对（8~60 列，8~44 行）'};
  const cell = (typeof o.cell === 'number' && o.cell >= 20 && o.cell <= 80) ? Math.floor(o.cell) : 40;

  const walls = edReadPairs(o.walls, cols, rows); if (!walls) return {err: 'walls 格式不对（要 [[列,行],…]）'};
  const glass = edReadPairs(o.glass, cols, rows); if (!glass) return {err: 'glass 格式不对'};
  const loot  = edReadPairs(o.loot, cols, rows);  if (!loot)  return {err: 'loot 格式不对'};
  const enemies = edReadPairs(o.enemies, cols, rows); if (!enemies) return {err: 'enemies 格式不对'};
  const cams  = edReadPairs(o.cams, cols, rows);  if (!cams)  return {err: 'cams 格式不对'};

  function pair1(p, def){
    if (!Array.isArray(p) || p.length < 2) return def;
    const c = Math.floor(p[0]), r = Math.floor(p[1]);
    if (c < 0 || r < 0 || c >= cols || r >= rows) return def;
    return [c, r];
  }
  const st = pair1(o.start, [1, rows - 2]);
  const ex = pair1(o.exit, [cols - 2, 1]);

  return {ok: true, map: {
    cols: cols, rows: rows, cell: cell,
    start: {c: st[0], r: st[1]}, exit: {c: ex[0], r: ex[1]},
    walls: walls, glass: glass, loot: loot, enemies: enemies, cams: cams
  }};
}
function edApply(m){
  ED.cols = m.cols; ED.rows = m.rows; ED.cell = m.cell;
  ED.walls = m.walls.slice(); ED.glass = m.glass.slice();
  ED.loot = m.loot.map(function(k){ const p = k.split(','); return {c:+p[0], r:+p[1]}; });
  ED.enemies = m.enemies.map(function(k){ const p = k.split(','); return {c:+p[0], r:+p[1]}; });
  ED.cams = m.cams.map(function(k){ const p = k.split(','); return {c:+p[0], r:+p[1]}; });
  ED.start = {c: m.start.c, r: m.start.r};
  ED.exit = {c: m.exit.c, r: m.exit.r};
  ED.undo = [];
}

/* ---------- 地图 → 关卡对象 ---------- */
function levelFromMap(m){
  const cell = m.cell || 40, cols = m.cols, rows = m.rows;
  const L = {
    name: '自定义地图', w: cols*cell, h: rows*cell, chapter: 0, ver: 2, custom: true,
    walls: [], glass: [], loot: [], slots: [], cameras: [], drones: [], doors: [],
    weapons: ['pistol','shotgun','rifle'], startMeds: 2, startSmokes: 2,
    enemyHp: 100, healHint: true, dropGuns: true,
    rules: { mode: 'stealth', fog: false }
  };
  function runs(list, push){
    const set = {};
    for (let i = 0; i < list.length; i++) set[list[i]] = 1;
    for (let r = 0; r < rows; r++){
      let c = 0;
      while (c < cols){
        if (set[edKey(c, r)]){
          let c2 = c;
          while (c2 + 1 < cols && set[edKey(c2+1, r)]) c2++;
          push({x: c*cell, y: r*cell, w: (c2-c+1)*cell, h: cell});
          c = c2 + 1;
        } else c++;
      }
    }
  }
  runs(m.walls, function(w){ L.walls.push(w); });
  runs(m.glass, function(w){ L.glass.push(w); });
  L.loot = m.loot.map(function(k){ const p = k.split(','); return {x:+p[0]*cell + cell/2, y:+p[1]*cell + cell/2}; });
  L.slots = m.enemies.map(function(k){
    const p = k.split(','), x = +p[0]*cell + cell/2, y = +p[1]*cell + cell/2;
    return {x: x, y: y, wp: [[x, y]]};
  });
  L.cameras = m.cams.map(function(k){
    const p = k.split(',');
    return {x: +p[0]*cell + cell/2, y: +p[1]*cell + cell/2, ang: Math.PI/2};
  });
  L.rules.enemyCount = Math.max(1, L.slots.length);
  L.start = {x: m.start.c*cell + cell/2, y: m.start.r*cell + cell/2};
  L.extract = {x: m.exit.c*cell + 4, y: m.exit.r*cell + 4, w: cell - 8, h: cell - 8};
  return L;
}
function startCustom(m){
  customLvl = levelFromMap(m);
  levelIdx = 0;
  state = 'play';
  reset();
  setMsg('自定义地图 · ' + m.cols + '×' + m.rows, 2.2);
}

/* ---------- 编辑器画面 ---------- */
function drawEditor(){
  uiButtons = [];
  /* 切干净：不这么做会继承世界渲染留下的相机平移，格子直接跑出屏幕 */
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.save();
  ctx.fillStyle = PAL.P258; ctx.fillRect(0, 0, W, H);

  ctx.textAlign = 'left';
  ctx.fillStyle = PAL.P138;
  ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
  ctx.fillText('地图编辑器', 26, 44);
  ctx.fillStyle = PAL.P169;
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('左键点格子：放下当前工具（再点一次取消）。按住拖动可以连着刷。', 26, 68);

  const g = edGeom();
  const gw = ED.cols * g.s, gh = ED.rows * g.s;
  /* 底 */
  ctx.fillStyle = 'rgba(16,20,26,0.92)';
  ctx.fillRect(g.ox, g.oy, gw, gh);
  /* 网格 */
  ctx.strokeStyle = 'rgba(120,132,148,0.13)';
  ctx.lineWidth = 1;
  for (let c = 0; c <= ED.cols; c++){
    ctx.beginPath(); ctx.moveTo(g.ox + c*g.s, g.oy); ctx.lineTo(g.ox + c*g.s, g.oy + gh); ctx.stroke();
  }
  for (let r = 0; r <= ED.rows; r++){
    ctx.beginPath(); ctx.moveTo(g.ox, g.oy + r*g.s); ctx.lineTo(g.ox + gw, g.oy + r*g.s); ctx.stroke();
  }
  /* 墙 / 玻璃 */
  function cellRect(c, r){ return {x: g.ox + c*g.s, y: g.oy + r*g.s, w: g.s, h: g.s}; }
  ctx.fillStyle = 'rgba(78,84,94,0.95)';
  for (const k of ED.walls){ const p = k.split(','); const q = cellRect(+p[0], +p[1]); ctx.fillRect(q.x+1, q.y+1, q.w-2, q.h-2); }
  ctx.fillStyle = 'rgba(150,196,214,0.30)';
  for (const k of ED.glass){ const p = k.split(','); const q = cellRect(+p[0], +p[1]); ctx.fillRect(q.x+1, q.y+1, q.w-2, q.h-2); }
  /* 物资 / 敌人 / 摄像头 */
  for (const e of ED.loot){
    const q = cellRect(e.c, e.r);
    ctx.fillStyle = '#ffd24a';
    ctx.beginPath(); ctx.arc(q.x + q.w/2, q.y + q.h/2, Math.max(3, q.w*0.16), 0, TAU); ctx.fill();
  }
  for (const e of ED.enemies){
    const q = cellRect(e.c, e.r);
    ctx.fillStyle = 'rgba(210,80,60,0.9)';
    ctx.beginPath(); ctx.arc(q.x + q.w/2, q.y + q.h/2, Math.max(4, q.w*0.22), 0, TAU); ctx.fill();
  }
  for (const e of ED.cams){
    const q = cellRect(e.c, e.r), cx = q.x + q.w/2, cy = q.y + q.h/2, rr = Math.max(4, q.w*0.22);
    ctx.fillStyle = 'rgba(190,140,255,0.9)';
    ctx.beginPath(); ctx.moveTo(cx, cy - rr); ctx.lineTo(cx + rr, cy + rr*0.8); ctx.lineTo(cx - rr, cy + rr*0.8); ctx.closePath(); ctx.fill();
  }
  /* 起点 / 终点 */
  const sq = cellRect(ED.start.c, ED.start.r);
  ctx.strokeStyle = '#58d08a'; ctx.lineWidth = 2;
  ctx.strokeRect(sq.x+2, sq.y+2, sq.w-4, sq.h-4);
  const eq = cellRect(ED.exit.c, ED.exit.r);
  ctx.setLineDash([4,3]);
  ctx.strokeStyle = '#7ab8ff';
  ctx.strokeRect(eq.x+2, eq.y+2, eq.w-4, eq.h-4);
  ctx.setLineDash([]);

  /* 右侧工具条 */
  const px = W - 330, pw = 150, ph = 34;
  ctx.textAlign = 'left';
  ctx.fillStyle = PAL.P193; ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
  ctx.fillText('工具', px, 96);
  for (let i = 0; i < ED_TOOLS.length; i++){
    const t = ED_TOOLS[i];
    const bx = px + (i % 2) * (pw + 10), by = 108 + Math.floor(i/2) * (ph + 8);
    const on = ED.tool === t.k;
    btn(bx, by, pw, ph, t.n, function(){ ED.tool = t.k; }, {dark: on, primary: on});
  }
  const by0 = 108 + Math.ceil(ED_TOOLS.length/2) * (ph + 8) + 14;
  btn(px, by0, pw*2 + 10, 38, '撤销一步', edUndo);
  btn(px, by0 + 46, pw*2 + 10, 38, '清空地图', function(){
    edSnap(); ED.walls = []; ED.glass = []; ED.loot = []; ED.enemies = []; ED.cams = []; edSay('清空了，能撤销');
  });
  btn(px, by0 + 92, pw*2 + 10, 38, '导出 JSON', function(){ mapIOOpen('export'); });
  btn(px, by0 + 138, pw*2 + 10, 38, '导入地图', function(){ mapIOOpen('import'); });
  btn(px, by0 + 184, pw*2 + 10, 44, '用这张图开局', function(){
    const r = edParse(edToJSON());
    if (r.err){ edSay(r.err); return; }
    const err = edValidate(r.map);
    if (err){ edSay(err); return; }
    startCustom(r.map);
  }, {primary: true});
  btn(px, by0 + 236, pw*2 + 10, 34, '回主菜单', goMenu, {dark: true});

  /* 底部状态 */
  ctx.textAlign = 'left';
  ctx.fillStyle = PAL.P142; ctx.font = '13px "Microsoft YaHei",sans-serif';
  const info = '格子 ' + ED.cols + '×' + ED.rows + ' · 墙 ' + ED.walls.length +
               ' · 玻璃 ' + ED.glass.length + ' · 物资 ' + ED.loot.length +
               ' · 敌人 ' + ED.enemies.length + ' · 摄像头 ' + ED.cams.length;
  ctx.fillText(info, 26, H - 26);
  if (ED.msgT > 0){
    ctx.fillStyle = 'rgba(255,196,120,0.95)';
    ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
    ctx.fillText(ED.msg, 26, H - 50);
  }
  flushButtons();
  ctx.restore();
}

function edValidate(m){
  if (!m.enemies.length) return '至少放一个敌人，不然开局就结束了';
  function inWall(c, r){ return m.walls.indexOf(edKey(c, r)) >= 0; }
  if (inWall(m.start.c, m.start.r)) return '起点压在墙里了';
  if (inWall(m.exit.c, m.exit.r)) return '终点压在墙里了';
  if (m.start.c === m.exit.c && m.start.r === m.exit.r) return '起点和终点是同一格';
  return '';
}

/* ---------- 文本框 / 文件 ---------- */
function mapIOOpen(mode){
  let box = document.getElementById('mapBox');
  if (!box){
    box = document.createElement('div');
    box.id = 'mapBox';
    box.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;' +
      'background:rgba(4,6,10,0.82);z-index:60;font:14px "Microsoft YaHei",sans-serif;';
    box.innerHTML =
      '<div style="width:760px;max-width:92vw;background:#161b23;border:1px solid #2c3442;border-radius:12px;padding:18px;color:#cfd8e3;box-shadow:0 20px 60px rgba(0,0,0,0.5)">' +
        '<div id="mapBoxTitle" style="font-size:16px;font-weight:700;color:#8ef0b5;margin-bottom:10px">导出地图</div>' +
        '<textarea id="mapArea" spellcheck="false" style="width:100%;height:300px;box-sizing:border-box;background:#0f131a;' +
          'color:#c9d4e2;border:1px solid #2c3442;border-radius:8px;padding:10px;font:12px Consolas,monospace;resize:vertical"></textarea>' +
        '<div id="mapBoxMsg" style="min-height:20px;color:#ffb36a;font-size:13px;margin:8px 0"></div>' +
        '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
          '<button id="mapCopy" style="padding:8px 14px;border-radius:8px;border:1px solid #2f3a4a;background:#1d2530;color:#cfd8e3;cursor:pointer">复制文本</button>' +
          '<button id="mapDl" style="padding:8px 14px;border-radius:8px;border:1px solid #2f3a4a;background:#1d2530;color:#cfd8e3;cursor:pointer">下载 .json</button>' +
          '<button id="mapPick" style="padding:8px 14px;border-radius:8px;border:1px solid #2f3a4a;background:#1d2530;color:#cfd8e3;cursor:pointer">选文件…</button>' +
          '<button id="mapDo" style="padding:8px 14px;border-radius:8px;border:1px solid #2f7a4e;background:#1f4d33;color:#c9ffdd;cursor:pointer">导入并开局</button>' +
          '<button id="mapClose" style="margin-left:auto;padding:8px 14px;border-radius:8px;border:1px solid #2f3a4a;background:#1d2530;color:#cfd8e3;cursor:pointer">关闭</button>' +
        '</div>' +
        '<input type="file" id="mapFile" accept=".json,application/json" style="display:none">' +
      '</div>';
    document.body.appendChild(box);

    const area = document.getElementById('mapArea');
    const msg = document.getElementById('mapBoxMsg');
    document.getElementById('mapClose').onclick = function(){ box.style.display = 'none'; };
    document.getElementById('mapCopy').onclick = function(){
      area.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch (e){ if (typeof reportErr === 'function') reportErr('55-boss', e); }
      if (!ok && navigator.clipboard){ navigator.clipboard.writeText(area.value).then(function(){ msg.textContent = '复制好了'; }); return; }
      msg.textContent = ok ? '复制好了' : '复制失败，手动全选复制吧';
    };
    document.getElementById('mapDl').onclick = function(){
      try {
        const blob = new Blob([area.value], {type: 'application/json'});
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'dsh-map.json';
        a.click();
        setTimeout(function(){ URL.revokeObjectURL(a.href); }, 2000);
        msg.textContent = '已下载 dsh-map.json';
      } catch(e){ msg.textContent = '下载失败：' + e.message; }
    };
    document.getElementById('mapPick').onclick = function(){ document.getElementById('mapFile').click(); };
    document.getElementById('mapFile').onchange = function(ev){
      const f = ev.target.files && ev.target.files[0];
      if (!f) return;
      if (f.size > 400000){ msg.textContent = '文件太大了（>400KB）'; return; }
      const rd = new FileReader();
      rd.onload = function(){ area.value = String(rd.result || ''); msg.textContent = '读到了：' + f.name + '（点「导入并开局」）'; };
      rd.onerror = function(){ msg.textContent = '读文件失败'; };
      rd.readAsText(f);
    };
    document.getElementById('mapDo').onclick = function(){
      const r = edParse(area.value);
      if (r.err){ msg.textContent = r.err; return; }
      edApply(r.map);
      const err = edValidate(r.map);
      if (err){ msg.textContent = err + '（已经放进编辑器，改一下再开局）'; box.style.display = 'none'; state = 'editor'; return; }
      msg.textContent = '好了，开局';
      box.style.display = 'none';
      startCustom(r.map);
    };
  }
  const t = document.getElementById('mapBoxTitle');
  const area = document.getElementById('mapArea');
  const msg = document.getElementById('mapBoxMsg');
  msg.textContent = '';
  box.style.display = 'flex';
  if (mode === 'export'){
    t.textContent = '导出地图（复制文本或下载文件）';
    area.value = edToJSON();
    area.readOnly = true;
  } else {
    t.textContent = '导入地图（粘贴文本或选文件）';
    area.value = '';
    area.readOnly = false;
  }
}


/* 拖着刷：手按着不放就能连成一条 */
cv.addEventListener('mousemove', function(ev){
  if (state !== 'editor' || !ED.painting) return;
  var r = cv.getBoundingClientRect();
  var mx = (ev.clientX - r.left) * (W / r.width);
  var my = (ev.clientY - r.top) * (H / r.height);
  var c = edCellFromMouse(mx, my);
  if (c) edPaint(c.c, c.r);
});
cv.addEventListener('mouseup', function(){ ED.painting = false; });


function drawMenu(){
  uiButtons = [];
  ctx.save();
  /* m33007：雨夜街区背景（画质关时自动退化成静态剪影） */
  if (typeof menuBgTick === 'function') menuBgTick(lastDt);
  if (typeof drawMenuBg === 'function') drawMenuBg();
  else { ctx.fillStyle = PAL.P258; ctx.fillRect(0,0,W,H); }
  ctx.textAlign = 'center';

  ctx.fillStyle = PAL.P138;
  ctx.font = 'bold 60px "Microsoft YaHei",sans-serif';
  ctx.fillText('暗区老鼠模拟器', W/2, 168);

  ctx.fillStyle = PAL.P20;
  ctx.font = '17px "Microsoft YaHei",sans-serif';
  ctx.fillText('一颗烟就够。他们看不见你的时候，你现在可以跑了。', W/2, 210);

  /* m33007：这行以前写的是「M 打开地图」——那是局内的事，在主界面按 M 什么都不会发生，
     属于误导。主界面只说主界面真能按的键。 */
  const lines = [
    /* m37450：删掉「空格 / Enter 开始新手教学」——空格不再能直接开局 */
    [keyLabel(BINDS.panel) + ' 或右下角「参数」', '改人机数量、伤害、视野、画质'],
    [keyLabel(BINDS.pause), '在选关 / 结算界面里返回主菜单'],
    ['鼠标左键', '点按钮；局内左键扔烟雾弹'],
    ['1-1 · 仓库', '先学静步躲藏：蹲着走，脚步声传得近得多']
  ];
  ctx.font = '16px "Microsoft YaHei",sans-serif';
  let y = 290;
  for (const [k,v] of lines){
    ctx.textAlign = 'right'; ctx.fillStyle = PAL.P169;
    ctx.fillText(k, W/2-24, y);
    ctx.textAlign = 'left'; ctx.fillStyle = PAL.P193;
    ctx.fillText(v, W/2+24, y);
    y += 31;
  }

  /* m37450 / m37520：3 和 Q 的分工最容易读错（按 Q 想换手雷却是换枪）——
     主界面只留两行讲清楚，详细说明在「参数 → 按键」页那两条高亮行下面。 */
  const _k3 = keyLabel(BINDS.throwToggle), _kq = keyLabel(BINDS.throwSwap);
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(255,196,110,0.10)';
  ctx.fillRect(W/2-330, 424, 660, 66);
  ctx.strokeStyle = 'rgba(255,196,110,0.34)';
  ctx.lineWidth = 1;
  ctx.strokeRect(W/2-330+0.5, 424.5, 659, 65);
  ctx.fillStyle = 'rgba(255,214,150,0.98)';
  ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
  ctx.fillText('按 ' + _k3 + ' 切「枪 ⇄ 投掷物」　·　按 ' + _kq + ' 换手上这一类里的下一个', W/2, 452);
  ctx.fillStyle = 'rgba(210,186,148,0.94)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('拿枪时按 ' + _kq + ' 就是换枪（等于 ' + keyLabel(BINDS.swap) + '）；想换手雷 / 烟雾弹，先按 ' + _k3 + ' 把投掷物拿出来', W/2, 476);


  btn(W/2-150, 524, 300, 56, '新手教学', ()=>goSelect(), {primary:true, sub:'从第一关开始 · 看不见就跑'});
  btn(W/2-150, 590, 300, 50, '娱乐模式', ()=>{ state = 'arcade'; }, {sub:'战斗爽 / 死亡地带 / 势力对抗'});

  /* m33007：告诉新玩家枪不是一开始就有 —— 免得第一章拿小刀以为游戏坏了 */
  ctx.fillStyle = 'rgba(255,196,110,0.92)';
  ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
  ctx.fillText('提示：打完新手教程第三章（停电层），就会解锁枪械', W/2, 668);


  ctx.fillStyle = PAL.P142;
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('右下角的「参数」按钮或按 O：改人机数量、伤害、射速、视野、脚步可听距……凡是数值都能改（需先打开开发者模式）', W/2, 700);

  /* m35368：存档说明 —— 数据只存在本机浏览器里，别指望云端 */
  ctx.textAlign = 'center';
  if (!storageWritable()){
    ctx.fillStyle = 'rgba(255,96,80,0.95)';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.fillText('注意：当前浏览器存不了档（无痕模式？）· 关掉窗口后仓位和进度都会清空', W/2, 738);
  } else {
    ctx.fillStyle = 'rgba(255,104,86,0.96)';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.fillText('※ 存档只在这台电脑的浏览器里 · 无痕模式、清理浏览器数据、换浏览器或换文件夹打开，都会丢', W/2, 734);
  }

  flushButtons();

  /* m35412：删掉底部的预算/花费那行 */
  ctx.restore();
}

/* m35368：主界面得让玩家知道"存档在本机浏览器里"，无痕/清缓存会丢 */
let _storeProbe = null;
function storageWritable(){
  if (_storeProbe !== null) return _storeProbe;
  try {
    const k = '__after5_probe__';
    localStorage.setItem(k, '1');
    const v = localStorage.getItem(k);
    localStorage.removeItem(k);
    _storeProbe = (v === '1');
  } catch (e){ _storeProbe = false; }
  return _storeProbe;
}

/* ---------------- 选关 ---------------- */

/* 死亡地带 · 选图：两张卡二选一（照战斗爽 drawArenaPick 的样子），点卡直接开局 */
const DZ_MAPS = [
  { key:'classic', name:'经典图 · 老图', hint:'6000 × 6000 · 手工布局 · 每局一样',
    tag:'固定' },
  { key:'random',  name:'随机图 · 每局新', hint:'6000 ~ 14000 · 尺寸与布局随种子变',
    tag:'随机' }
];
let dzDevAsk = null;   /* 非空 = 正在问「开发者模式已开启，还要不要进」；值是用户点的那张图的 key */
function drawDzPick(){
  uiButtons = [];
  ctx.save();
  ctx.fillStyle = PAL.P258; ctx.fillRect(0,0,W,H);
  /* 难度背景：随难度渐进变惨（雨夜 → 起火 → 残骸），见 game/52-dzbg.js */
  if (typeof dzBgTick === 'function'){ dzBgTick(); drawDzBg(); }
  /* 环境声（火 / 远处爆炸 / 流弹）跟背景同一套强度量，换难度时一起渐变 */
  if (typeof dzAudioTick === 'function') dzAudioTick(0.016, (typeof dzBgD === 'number' ? dzBgD : 0) / 2);
  ctx.textAlign = 'center';
  const _isCore = (dzTier === 'core');
  /* m35146：硬核难度下，页面标题直接换成「敌人将全力以赴」 */
  if (_isCore){
    const _tp = 0.72 + 0.28 * Math.abs(Math.sin((typeof uiT === 'number' ? uiT : 0) * 1.6));
    ctx.save();
    ctx.shadowColor = 'rgba(255,60,40,0.85)'; ctx.shadowBlur = 22;
    ctx.fillStyle = 'rgba(255,74,56,' + _tp.toFixed(2) + ')';
    ctx.font = 'bold 46px "Microsoft YaHei",sans-serif';
    ctx.fillText('敌人将全力以赴', W/2, 150);
    ctx.restore();
  } else {
    ctx.fillStyle = '#9fd8ff';
    ctx.font = 'bold 42px "Microsoft YaHei",sans-serif';
    ctx.fillText('死亡地带', W/2, 148);
  }
  ctx.fillStyle = 'rgba(220,232,244,0.62)';
  ctx.font = '16px "Microsoft YaHei",sans-serif';
  ctx.fillText('选一张图进去 · 小刀开局，搜到黑匣子再撤离', W/2, 186);
  /* m33834：给这个页面一句氛围文案（最高压之地），让"这儿比故事关狠"一眼就看得出来。
     一行说完，别把下面两张卡顶下去。 */
  ctx.save();
  ctx.shadowColor = 'rgba(255,150,60,0.55)'; ctx.shadowBlur = 14;
  ctx.fillStyle = 'rgba(255,200,128,0.97)';
  ctx.font = 'bold 17px "Microsoft YaHei",sans-serif';
  ctx.fillText('最高压之地 · 最难生存的地方 —— 能否逃离这里？不要被他们发现，小心翼翼地生存…', W/2, 216);
  ctx.restore();
  /* 开发者模式进场确认（m04825）：以前只在标题下挂一行黄字，很容易被忽略；
     现在改成点图之后弹窗确认，避免"糊里糊涂拿开发者模式打了一局"。 */
  if (dzDevAsk){
    ctx.fillStyle = 'rgba(4,8,12,0.74)';
    ctx.fillRect(0, 0, W, H);
    const mw = 620, mh = 272, mx = W/2 - mw/2, my = H/2 - mh/2;
    ctx.fillStyle = 'rgba(18,26,36,0.98)';
    roundRect(mx, my, mw, mh, 16); ctx.fill();
    ctx.strokeStyle = '#ffd090'; ctx.lineWidth = 2;
    roundRect(mx, my, mw, mh, 16); ctx.stroke();
    ctx.fillStyle = '#ffd090';
    ctx.font = 'bold 26px "Microsoft YaHei",sans-serif';
    ctx.fillText('开发者模式已开启', W/2, my + 58);
    ctx.fillStyle = 'rgba(226,236,246,0.88)';
    ctx.font = '16px "Microsoft YaHei",sans-serif';
    ctx.fillText('这一局会被标记成「' + (DZ_TIER_LABEL[dzTier] || dzTier) + '」仓库，不计入正常成绩。', W/2, my + 104);
    ctx.fillText('如果只是想正常玩，回去把开发者模式关掉再来。', W/2, my + 132);
    ctx.fillStyle = 'rgba(200,214,228,0.55)';
    ctx.font = '14px "Microsoft YaHei",sans-serif';
    ctx.fillText('关法：设置 → 开发者 → 关掉「开发者模式」', W/2, my + 168);
    btn(W/2 - 206, my + mh - 78, 186, 50, '返回（先关掉）', ()=>{ dzDevAsk = null; });
    btn(W/2 + 20, my + mh - 78, 186, 50, '仍然进入', ()=>{
      const _k = dzDevAsk; dzDevAsk = null;
      dzMapMode = _k;
      dzSeed = 0;
      dzStartWithLoading(function(){
        startDeathZone();
        if (state !== 'play') showCrash('死亡地带没进去（state=' + state + '，图=' + dzMapMode + '）');
      });
    }, { primary: true });
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(150,170,190,0.45)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText(GAME_VER + ' · ' + BUILD_TAG, 20, H - 16);
    ctx.textAlign = 'center';
    flushButtons();
    ctx.restore();
    return;
  }

  const cw = 380, ch = 196, gap = 36;
  const x0 = W/2 - (cw*2+gap)/2, y0 = 246;
  for (let i=0;i<DZ_MAPS.length;i++){
    const m = DZ_MAPS[i];
    const bx = x0 + i*(cw+gap);
    const on = dzMapMode === m.key;
    const hv = mouse.x >= bx && mouse.x <= bx+cw && mouse.y >= y0 && mouse.y <= y0+ch;
    /* m35146：硬核难度下这两张卡也换成「血色」皮肤，别跟困难/噩梦一个气质 */
    if (_isCore){
      ctx.fillStyle = hv ? 'rgba(46,12,10,0.96)' : 'rgba(26,9,9,0.94)';
      roundRect(bx, y0, cw, ch, 14); ctx.fill();
      /* 顶部压一层暗红渐变，像血渗下来 */
      const _cg = ctx.createLinearGradient(0, y0, 0, y0 + ch);
      _cg.addColorStop(0, 'rgba(255,60,40,' + (on ? 0.20 : 0.12) + ')');
      _cg.addColorStop(0.55, 'rgba(255,60,40,0.03)');
      _cg.addColorStop(1, 'rgba(0,0,0,0.16)');
      roundRect(bx, y0, cw, ch, 14); ctx.fillStyle = _cg; ctx.fill();
      ctx.strokeStyle = on ? 'rgba(255,110,80,0.95)' : (hv ? 'rgba(255,130,100,0.8)' : 'rgba(180,70,54,0.55)');
      ctx.lineWidth = on ? 3 : (hv ? 2.4 : 1.4);
      roundRect(bx, y0, cw, ch, 14); ctx.stroke();
      ctx.save();
      ctx.shadowColor = 'rgba(255,52,32,0.75)'; ctx.shadowBlur = on ? 16 : 9;
      ctx.fillStyle = on ? 'rgba(255,92,68,1)' : 'rgba(255,132,104,0.95)';
      ctx.font = 'bold 27px "Microsoft YaHei",sans-serif';
      ctx.fillText(m.name, bx + cw/2, y0 + 80);
      ctx.restore();
      ctx.fillStyle = 'rgba(255,186,164,0.72)';
      ctx.font = '15px "Microsoft YaHei",sans-serif';
      ctx.fillText(m.hint, bx + cw/2, y0 + 116);
      if (on){
        ctx.fillStyle = 'rgba(255,150,120,0.95)';
        ctx.font = '13px "Microsoft YaHei",sans-serif';
        ctx.fillText('上次选的这张 · 这一次不会有折扣', bx + cw/2, y0 + 154);
      }
    } else {
      ctx.fillStyle = hv ? 'rgba(26,38,52,0.96)' : 'rgba(14,20,28,0.9)';
      roundRect(bx, y0, cw, ch, 14); ctx.fill();
      ctx.strokeStyle = on ? '#8ef0c8' : (hv ? 'rgba(150,200,230,0.7)' : 'rgba(120,150,180,0.35)');
      ctx.lineWidth = on ? 3 : (hv ? 2.4 : 1.3);
      roundRect(bx, y0, cw, ch, 14); ctx.stroke();
      ctx.fillStyle = '#ffd9a0';
      ctx.font = 'bold 26px "Microsoft YaHei",sans-serif';
      ctx.fillText(m.name, bx + cw/2, y0 + 78);
      ctx.fillStyle = 'rgba(220,232,244,0.66)';
      ctx.font = '15px "Microsoft YaHei",sans-serif';
      ctx.fillText(m.hint, bx + cw/2, y0 + 114);
      if (on){
        ctx.fillStyle = '#8ef0c8';
        ctx.font = '13px "Microsoft YaHei",sans-serif';
        ctx.fillText('上次选的这张', bx + cw/2, y0 + 152);
      }
    }
    btn(bx, y0, cw, ch, '', ()=>{
      /* 开发者模式开着时先弹窗确认，别让人稀里糊涂就把这局玩成「困难仓库」 */
      if (devUiOn()){ dzDevAsk = m.key; return; }
      dzMapMode = m.key;
      dzSeed = 0;                    /* 换图/重进都重新掷种子 */
      dzStartWithLoading(function(){
        startDeathZone();
        if (state !== 'play') showCrash('死亡地带没进去（state=' + state + '，图=' + dzMapMode + '）');
      });
    }, {dark:true, invisible:true});
  }

  /* 难度：这里只放死亡地带自己的三档（困难/噩梦/硬核）。
     以前这里挂的是故事关那排（简单/普通/困难/噩梦），可死亡地带根本不读它，
     点了也不会真的变难 —— 两套难度并存只会让人搞不清哪个算数。 */
  const DW = 96, DH = 32, DG = 8;
  const DX = W - 24 - (DZ_TIERS.length*DW + DG*(DZ_TIERS.length-1));
  DZ_TIERS.forEach((kn, i)=>{
    /* m33967：噩梦/硬核要靠成功撤离逐级解锁 */
    const _dzOpen = (typeof progDzUnlocked === 'function') ? progDzUnlocked(kn) : true;
    btn(DX + i*(DW+DG), 30, DW, DH, DZ_TIER_LABEL[kn], ()=>{
      if (!_dzOpen){ setMsg((typeof progDzNeed === 'function') ? progDzNeed(kn) : '这一档还没解锁', 3.2); return; }
      dzTier = kn;
      logInfo('ui', '死亡地带难度改为 ' + DZ_TIER_LABEL[kn]);
    }, { primary: dzTier === kn, dim: !_dzOpen });
    if (!_dzOpen){
      const _lx = DX + i*(DW+DG) + DW - 12, _ly = 34;
      ctx.save(); ctx.strokeStyle = 'rgba(190,200,214,0.9)'; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(_lx, _ly + 3, 3.4, Math.PI, 0); ctx.stroke();
      ctx.fillStyle = 'rgba(190,200,214,0.9)';
      ctx.fillRect(_lx - 4.6, _ly + 3, 9.2, 7); ctx.restore();
    }
  });
  if (_isCore){
    /* m34881：硬核不再解释玩法（打到这一档的人不需要介绍），改成一段压迫感提示。
       诚实地说清楚：别的难度里人机伤害是调过的（打过折），硬核按枪原值算，减免 0%。 */
    ctx.save();
    ctx.textAlign = 'center';
    const _pulse = 0.72 + 0.28 * Math.abs(Math.sin((typeof uiT === 'number' ? uiT : 0) * 1.6));
    /* 版面（m35119）：整块装进一张与上方两张图卡等宽的深色面板，里面从上到下居中排，
       面板左右边界和卡片对齐，视觉上不会再出现'三种宽度乱叠'的别扭感 */
    const _cx = W/2;
    const _pw = 796, _px = Math.round(_cx - _pw/2), _py = 468, _ph = 140;
    ctx.save();
    ctx.fillStyle = 'rgba(12,8,8,0.55)';
    if (typeof roundRect === 'function'){ roundRect(_px, _py, _pw, _ph, 14); ctx.fill(); }
    else ctx.fillRect(_px, _py, _pw, _ph);
    ctx.strokeStyle = 'rgba(255,110,80,0.34)'; ctx.lineWidth = 1.2;
    if (typeof roundRect === 'function'){ roundRect(_px, _py, _pw, _ph, 14); ctx.stroke(); }
    else ctx.strokeRect(_px, _py, _pw, _ph);
    ctx.restore();
    ctx.textAlign = 'center';
    ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(255,186,150,0.95)';
    ctx.fillText('更快的反应速度 · 更高的伤害 · 这是一场最公平的竞争', _cx, _py + 32);
    /* 减免牌：宽度按文字自适应，整体居中 */
    ctx.font = '15px "Microsoft YaHei",sans-serif';
    const _lw = ctx.measureText('伤害减免').width;
    ctx.font = 'bold 30px "Microsoft YaHei",sans-serif';
    const _vw = ctx.measureText('0%').width;
    const _pad = 20, _gapw = 14;
    const _bw = Math.round(_lw + _gapw + _vw + _pad*2), _bh = 40;
    const _bx = Math.round(_cx - _bw/2), _by = _py + 50;
    ctx.fillStyle = 'rgba(255,72,56,0.16)';
    roundRect(_bx, _by, _bw, _bh, 10); ctx.fill();
    ctx.strokeStyle = 'rgba(255,96,72,0.85)'; ctx.lineWidth = 1.6;
    roundRect(_bx, _by, _bw, _bh, 10); ctx.stroke();
    ctx.textAlign = 'left';
    ctx.font = '15px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(255,196,170,0.92)';
    ctx.fillText('伤害减免', _bx + _pad, _by + _bh/2 + 5);
    ctx.save();
    ctx.shadowColor = 'rgba(255,72,48,0.85)'; ctx.shadowBlur = 12;
    ctx.font = 'bold 28px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(255,104,80,1)';
    ctx.fillText('0%', _bx + _pad + _lw + _gapw, _by + _bh/2 + 10);
    ctx.restore();
    ctx.textAlign = 'center';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(206,216,228,0.62)';
    ctx.fillText('别的难度里人机伤害是调过的（打过折）；这里按你手里那把枪的原值算', _cx, _py + 112);
    ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(255,150,120,0.95)';
    ctx.fillText('子弹打在谁身上都致命', _cx, _py + 134);
    ctx.restore();
  } else {
  ctx.fillStyle = 'rgba(200,214,228,0.5)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('困难：敌人伤害基准 14 · 噩梦 19（射速/视野/记忆也更快更远）· 硬核：按手里那把枪的原伤害', W/2, 474);
  ctx.fillStyle = 'rgba(255,196,120,0.72)';
  ctx.fillText('「困难」成功撤离一次 → 解锁噩梦；「噩梦」成功撤离一次 → 解锁硬核（死亡/放弃不算）', W/2, 496);
  }

  /* 硬核时下面要放「敌人将全力以赴」那一块，按钮整体下移，避免和文字压在一起 */
  const _btnDy = _isCore ? 128 : 0;
  btn(140, 520 + _btnDy, 240, 48, '仓库（出发前整理）', ()=>{ if (typeof stashOpenPanel === 'function') stashOpenPanel('pre'); });
  btn(W - 380, 516 + _btnDy, 240, 48, '返回娱乐模式', ()=>{ state = 'arcade'; });
  if (!_isCore){
    ctx.fillStyle = 'rgba(200,214,228,0.42)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText('随机图每局尺寸/位置/物资都不同；经典图就是原来那张', W/2, 594);
  }
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(150,170,190,0.45)';
  ctx.fillText(GAME_VER + ' · ' + BUILD_TAG, 20, H - 16);
  ctx.textAlign = 'center';
  flushButtons();
  ctx.restore();
}

function drawArcade(){
  uiButtons = [];
  ctx.save();
  ctx.fillStyle = PAL.P258; ctx.fillRect(0,0,W,H);
  ctx.textAlign = 'center';
  ctx.fillStyle = PAL.P138;
  ctx.font = 'bold 46px "Microsoft YaHei",sans-serif';
  ctx.fillText('娱乐模式', W/2, 190);
  ctx.fillStyle = PAL.P20;
  ctx.font = '15px "Microsoft YaHei",sans-serif';
  ctx.fillText('不讲剧情，不讲掩体，只讲打得爽不爽', W/2, 228);

  const BW = 320, BX = W/2 - BW/2;
  btn(BX, 248, BW, 54, '战斗，爽！！', ()=>arenaRunSlotCommand('open-entry'),
      {primary:true, sub:'四面八方来人 · 升级三选一'});
  btn(BX, 310, BW, 54, '死亡地带', ()=>{ state = 'dzpick'; },
      {primary:true, sub:'经典图 / 随机图 · 小刀开局 · 搜到黑匣子再撤离'});

  /* m34682：模式内部各自有难度选择（战斗爽在选卡前、死亡地带在选图页），
     这里再放一遍是重复，已删。 */
  /* 两个军团键原来并排各 154px，字宽比按钮还宽 → 互相压字；改成整行上下排 */
  /* m34024：军团推塔改名「势力对抗」，对玩家只做画饼（点不动，抖一下 + 响一声 + 敬请期待）；
     开发者模式里仍然给两个能真进的入口。地图编辑器改名「自定义地图」，玩家同样只画饼。 */
  const _devOn = (typeof devUiOn === 'function') ? devUiOn() : !!(typeof CFG !== 'undefined' && CFG && CFG.dev);
  if (typeof _teaseT === 'number' && _teaseT > 0) _teaseT = Math.max(0, _teaseT - ((typeof lastDt === 'number' && lastDt > 0) ? lastDt : 0.016));
  if (typeof _teaseMsgT === 'number' && _teaseMsgT > 0) _teaseMsgT = Math.max(0, _teaseMsgT - ((typeof lastDt === 'number' && lastDt > 0) ? lastDt : 0.016));
  let _ay = 392;
  if (_devOn){
    btn(BX, _ay, BW, 44, '军团推塔 · 三路', ()=>{ startMoba(); },
        {primary:true, sub:'经典地图 · 三条兵线'});
    _ay += 52;
    btn(BX, _ay, BW, 44, '军团推塔 · 单路', ()=>{ startMoba(MOBA_SINGLE_DEF); },
        {primary:true, sub:'小地图 · 一条兵线'});
    _ay += 52;
  } else {
    /* 玩家视角：死亡地带困难撤离过一次才露出「势力对抗」，而且只给看不给玩 */
    const _teaseFaction = (typeof progFactionTease === 'function') ? progFactionTease() : false;
    if (_teaseFaction){
      btn(BX + teaseShakeX('faction'), _ay, BW, 44, '势力对抗', ()=>{
        teaseTap('faction', '敬请期待 · 势力对抗还在打磨，做好第一时间端上来');
      }, {sub:'三路兵线 · 双方人机对推（开发中）', dim:true});
      _ay += 52;
    }
  }
  btn(BX + teaseShakeX('map'), _ay, BW, 40, '自定义地图', ()=>{
    if (_devOn){ state = 'editor'; return; }
    teaseTap('map', '敬请期待 · 自定义地图还在做，以后能自己画图分享');
  }, {sub: _devOn ? '自己画一张图 · 导出 JSON 能分享' : '自己画一张图分享（开发中）', dim: !_devOn});
  _ay += 48;
  btn(BX, _ay, BW, 44, '返回主菜单', ()=>{ goMenu(); });

  /* 画饼提示：点了未完成模式 → 页面底部出一行金色提示，3.4 秒淡出 */
  if (typeof _teaseMsgT === 'number' && _teaseMsgT > 0 && _teaseMsg){
    const _al = Math.min(1, _teaseMsgT / 0.7);
    ctx.save();
    ctx.globalAlpha = _al;
    ctx.fillStyle = 'rgba(255,214,140,0.98)';
    ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(_teaseMsg, W/2, 640);
    ctx.restore();
  }
  ctx.fillStyle = PAL.P142;
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText(_devOn
      ? '测试区、难度与参数调整都在「新手教学」的选关界面里'
      : '测试区在「新手教学」的选关界面里（要开开发者模式才看得到）', W/2, 676);
  ctx.fillStyle = 'rgba(150,200,170,0.62)';
  ctx.fillText('键盘也能用：D = 进死亡地带选图', W/2, 698);
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(150,170,190,0.45)';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText(GAME_VER + ' · ' + BUILD_TAG, 20, H - 16);
  ctx.textAlign = 'center';
  flushButtons();
  ctx.restore();
}

/* m34931：点锁住的关卡/难度时给点反应——不然玩家以为点了没反应（像卡了 bug）
   注意：选关/菜单状态下 update() 不跑，msgT 不会自减，所以这里用 performance.now() 自己计时 */
let _denyMsg = '', _denyUntil = 0;
function selDeny(text){
  if (!text) return;
  _denyMsg = text;
  _denyUntil = (typeof performance !== 'undefined' ? performance.now() : Date.now()) + 2600;
  if (typeof logInfo === 'function') logInfo('ui', '未解锁：' + text);
  const el = (typeof document !== 'undefined') && document.getElementById && document.getElementById('c');
  if (el && el.animate){
    try{
      el.animate([
        {transform:'translateX(0px)'},{transform:'translateX(-8px)'},{transform:'translateX(7px)'},
        {transform:'translateX(-5px)'},{transform:'translateX(3px)'},{transform:'translateX(0px)'}
      ], {duration: 380, easing:'ease-out'});
    }catch(e){}
  }
  if (typeof teaseDenySfx === 'function') teaseDenySfx();
}

function drawSelToast(){
  if (!_denyMsg) return;
  const now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
  const left = _denyUntil - now;
  if (left <= 0){ _denyMsg = ''; return; }
  const a = Math.min(1, left / 380);
  ctx.save();
  ctx.setTransform(1,0,0,1,0,0);
  ctx.textAlign = 'center';
  ctx.font = 'bold 17px "Microsoft YaHei",sans-serif';
  const tw = ctx.measureText(_denyMsg).width;
  const bw = tw + 40, bh = 40, bx = W/2 - bw/2, by = H - 112;
  ctx.globalAlpha = a;
  ctx.fillStyle = 'rgba(28,14,10,0.92)';
  if (typeof roundRect === 'function'){ roundRect(bx, by, bw, bh, 10); ctx.fill(); }
  else ctx.fillRect(bx, by, bw, bh);
  ctx.strokeStyle = 'rgba(255,140,96,0.72)'; ctx.lineWidth = 1.4;
  if (typeof roundRect === 'function'){ roundRect(bx, by, bw, bh, 10); ctx.stroke(); }
  else ctx.strokeRect(bx, by, bw, bh);
  ctx.fillStyle = 'rgba(255,182,140,0.98)';
  ctx.fillText(_denyMsg, W/2, by + 26);
  ctx.restore();
}

function drawSelect(){
  uiButtons = [];
  ctx.save();
  ctx.fillStyle = PAL.P259; ctx.fillRect(0,0,W,H);
  ctx.textAlign = 'center';

  /* 返回键放左上，水平不跟关卡列表抢位置 */
  btn(24, 26, 150, 40, '返回主菜单', ()=>goMenu());

  /* 难度：右上角一排 */
  const DLBL = DIFF_LABEL;
  const dw = 84, dh = 32, dg = 8;
  /* 按"当前这一章"决定给哪几档：整章都是空手老关卡时，噩梦不出现 */
  const _chLv = LEVELS.filter(l => !l.devOnly && (l.chapter || 1) === selChapter);
  const _dl = DIFF_ORDER.filter(k => k !== 'nightmare' ||
                _chLv.some(l => diffAllowed('nightmare', l)));
  const dx0 = W - 24 - (dw*_dl.length + dg*(_dl.length-1));
  /* m33914：困难/噩梦要按关卡进度上锁。这一章里只要还有一关能玩这个难度，
     按钮就不算锁死（具体能不能用，点关卡时再判一次，提示更准）。 */
  const _chapIdx = [];
  for (let _i = 0; _i < LEVELS.length; _i++){
    const _l = LEVELS[_i];
    if ((_l.chapter || 1) !== selChapter) continue;
    if (_l.devOnly) continue;
    _chapIdx.push(_i);
  }
  /* m34682：难度是"我想玩哪一档"的全局偏好，各关卡能不能用这一档，
     改标在关卡卡片上（见下面的 _diffLock），这里不再替整章打包票。 */
  /* m35945：这一章里没有任何一关能玩这一档 → 按钮变灰 + 小锁（点它也给原因）。
     原来的样子是"点了才发现进不去"，用户要求恢复成灰按钮。 */
  const _dlLock = {};
  _dl.forEach(kn => {
    _dlLock[kn] = (typeof progDiffUnlocked === 'function') && _chapIdx.length
      ? !_chapIdx.some(function(_i){ return progDiffUnlocked(_i, kn); }) : false;
  });
  _dl.forEach((kn, i)=>{
    const _lk = !!_dlLock[kn];
    btn(dx0 + i*(dw+dg), 30, dw, dh, DLBL[kn], ()=>{
      if (_lk){
        const _i0 = _chapIdx.find(function(_i){ return !progDiffUnlocked(_i, kn); });
        selDeny((typeof progDiffNeed === 'function' && _i0 !== undefined) ? progDiffNeed(_i0, kn) : ('「' + DLBL[kn] + '」还没解锁'));
        return;
      }
      applyPreset(kn);
      logInfo('ui', '难度改为 ' + DLBL[kn]);
    }, { primary: !CFG.dev && diffName === kn, dim: _lk });
  });

  ctx.fillStyle = PAL.P186;
  ctx.font = 'bold 32px "Microsoft YaHei",sans-serif';
  ctx.fillText('选择关卡', W/2, 74);

  /* ---- 章节 ---- */
  const chs = CHAPTERS;
  let ci = chs.findIndex(c => c.n === selChapter);
  if (ci < 0) ci = 0;
  const ch = chs[ci];
  const CW = 720, CH = 170, CX = W/2 - CW/2, CY = 100;

  drawChapterCover(CX, CY, CW, CH, ch);

  /* 左右翻章 */
  if (chs.length > 1){
    btn(CX - 74, CY + CH/2 - 26, 58, 52, '‹', ()=>{
      selChapter = chs[(ci - 1 + chs.length) % chs.length].n;
      selLvPage = 0;
      logInfo('ui', '切到第 ' + selChapter + ' 章');
    }, { dim: true });
    btn(CX + CW + 16, CY + CH/2 - 26, 58, 52, '›', ()=>{
      selChapter = chs[(ci + 1) % chs.length].n;
      selLvPage = 0;
      logInfo('ui', '切到第 ' + selChapter + ' 章');
    }, { dim: true });
    ctx.textAlign = 'center';
    ctx.fillStyle = PAL.P154;
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('第 ' + (ci+1) + ' / ' + chs.length + ' 章   ·   ← → 翻章', W/2, CY + CH + 20);
  }

  /* ---- 本关卡的关卡卡片：只列当前这一章 ---- */
  const rowW = 660, rowH = 62, gap = 10;
  /* m33092：在章节封面下方说明「这一章学什么」—— 只讲学习目标，不堆规则；
     位置在关卡列表正上方、与列表左对齐，不压按钮也不压封面 */
  let _learnH = 0;
  if (ch.learn){
    ctx.textAlign = 'left';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    const _maxW = 660;
    const _lines = []; let _cur = '';
    for (const _c of ch.learn){
      if (ctx.measureText(_cur + _c).width > _maxW){ _lines.push(_cur); _cur = _c; }
      else _cur += _c;
    }
    if (_cur) _lines.push(_cur);
    const _ly0 = CY + CH + 52;
    /* 前面一小截竖线，读起来像章节备注而不是又一行参数 */
    ctx.fillStyle = 'rgba(255,196,110,0.55)';
    ctx.fillRect(W/2 - 340, _ly0 - 12, 2, _lines.length * 19 - 4);
    ctx.fillStyle = 'rgba(255,206,140,0.94)';
    _lines.forEach((_s, _i)=> ctx.fillText(_s, W/2 - 330, _ly0 + _i * 19));
    _learnH = _lines.length * 19 + 10;
    ctx.textAlign = 'center';
  }

  const listTop = CY + CH + 38 + _learnH;
  /* 底部还要留：说明行 + 分页行。放不下就分页，别把最后一张卡挤出屏幕 */
  const listBottom = H - 84;
  const perPage = Math.max(3, Math.floor((listBottom - listTop) / (rowH + gap)));
  const items = [];
  for (let i=0;i<LEVELS.length;i++){
    const L = LEVELS[i];
    if ((L.chapter || 1) !== ch.n) continue;
    if (L.devOnly && !((typeof devUiOn === 'function') ? devUiOn() : !!CFG.dev)) continue;      /* 测试地图只给开发者 */
    items.push(i);
  }
  const pages = Math.max(1, Math.ceil(items.length / perPage));
  if (selLvPage > pages - 1) selLvPage = pages - 1;
  if (selLvPage < 0) selLvPage = 0;
  let ry = listTop;
  let n = 0, hoverNote = '';
  const from = selLvPage * perPage, to = Math.min(items.length, from + perPage);
  for (let k=from;k<to;k++){
    const i = items[k];
    const L = LEVELS[i];
    n++;
    const done = !!clearedLv[i];
    /* m33914：解锁链 + 难度锁 + 全难度标记 */
    const _free = (typeof progLevelFree === 'function') ? progLevelFree(L) : true;
    const _st = (typeof progLevelState === 'function') ? progLevelState(i) : { unlocked: true, full: false, any: done };
    const _lock = !_free && !_st.unlocked;
    /* m34682：这一关能不能用"当前选中的难度" */
    const _diffLock = (_lock || _free || typeof progDiffUnlocked !== 'function')
      ? false : !progDiffUnlocked(i, diffName);
    const _subTxt = '地图 ' + L.w + ' × ' + L.h + '   ·   每局物资 ' + ((L.rules && L.rules.devTest) ? L.loot.length : Math.min(Math.round(CFG.loot), L.loot.length)) + ' 件'
      + (_lock ? '   ·   未解锁' : (_diffLock ? '   ·   「' + (DLBL[diffName] || diffName) + '」未解锁' : ''));
    let _badgeRight = W/2 + rowW/2 - 14;   /* 卡片右侧角标从右往左排，互不重叠 */
    const card = btn(W/2 - rowW/2, ry, rowW, rowH, L.name, ()=>{
      if (_lock){
        selDeny((typeof progLevelNeed === 'function' ? progLevelNeed(i) : '先通关上一关'));
        return;
      }
      /* 难度也得这一关自己够格 */
      if (!_free && typeof progDiffUnlocked === 'function' && !progDiffUnlocked(i, diffName)){
        selDeny((typeof progDiffNeed === 'function' ? progDiffNeed(i, diffName) : '这一关还没解锁这个难度'));
        return;
      }
      startLevel(i);
    }, {
      primary: k === 0 && !_lock,
      sub: _subTxt,
      dim: _lock
    });
    /* m33127：娱乐关（3-4 雨雾街头这种没有敌人的）在卡片右侧标一下，别让玩家以为是硬仗 */
    if (L.fun){
      ctx.save();
      const _tw = 46, _th = 18, _tx = _badgeRight - _tw, _ty = ry + (rowH - _th)/2 - 3;
      _badgeRight = _tx - 8;   /* 娱乐章占了右边，通关章往左让 */
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(255,176,96,0.16)';
      roundRect(_tx, _ty, _tw, _th, 9); ctx.fill();
      ctx.strokeStyle = 'rgba(255,196,120,0.55)'; ctx.lineWidth = 1;
      roundRect(_tx, _ty, _tw, _th, 9); ctx.stroke();
      ctx.fillStyle = 'rgba(255,208,146,0.96)';
      ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
      ctx.fillText('娱乐', _tx + _tw/2, _ty + 13);
      ctx.restore();
    }
    /* m34146 / m34352：通关勋章 —— 绿章「✓ 已通关 n/N」，全档通换金章「★ 全难度」。
       N 按这一关真实可选的难度数算（没枪的关卡没有噩梦，所以是 3 不是 4）。 */
    if (!_lock && _st.any){
      const _dlist = (typeof diffListFor === 'function') ? diffListFor(L) : ['easy','normal','hard','nightmare'];
      const _dn = Math.max(1, _dlist.length);
      const _done = _dlist.filter(function(d){ return !!_st[d]; }).length;
      const _isFull = _done === _dn && _done > 0;
      const _txt = _isFull ? '★ 全难度' : ('✓ 已通关 ' + _done + '/' + _dn);
      ctx.save();
      ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
      const _bw2 = Math.max(78, ctx.measureText(_txt).width + 22), _bh2 = 19;
      const _bx2 = _badgeRight - _bw2, _by2 = ry + (rowH - _bh2)/2 - 3;
      ctx.fillStyle = _isFull ? 'rgba(255,206,110,0.22)' : 'rgba(120,220,170,0.20)';
      roundRect(_bx2, _by2, _bw2, _bh2, 9); ctx.fill();
      ctx.strokeStyle = _isFull ? 'rgba(255,214,140,0.90)' : 'rgba(140,235,190,0.85)';
      ctx.lineWidth = _isFull ? 1.6 : 1.3;
      roundRect(_bx2, _by2, _bw2, _bh2, 9); ctx.stroke();
      if (_isFull){
        ctx.shadowColor = 'rgba(255,190,90,0.65)'; ctx.shadowBlur = 10;
        roundRect(_bx2, _by2, _bw2, _bh2, 9); ctx.stroke();
        ctx.shadowBlur = 0;
      }
      ctx.fillStyle = _isFull ? 'rgba(255,232,180,0.99)' : 'rgba(196,248,220,0.99)';
      ctx.textAlign = 'center';
      ctx.fillText(_txt, _bx2 + _bw2/2, _by2 + 14);
      ctx.textAlign = 'left';
      ctx.restore();
    }
    /* 没解锁的关卡：虚线框 + 一把锁 + 明写"未解锁"，一眼看出跟别的关不一样 */
    const _lockX = (L.fun ? (W/2 + rowW/2 - 30 - 56) : (W/2 + rowW/2 - 30));   /* m35945：有「娱乐」章时锁往左让 */
    if (_lock){
      ctx.save();
      ctx.setLineDash([7, 6]);
      ctx.strokeStyle = 'rgba(150,162,180,0.60)'; ctx.lineWidth = 1.6;
      roundRect(W/2 - rowW/2, ry, rowW, rowH, 9); ctx.stroke();
      ctx.setLineDash([]);
      const _lx = _lockX, _ly = ry + rowH/2 - 6;
      ctx.strokeStyle = 'rgba(178,188,204,0.92)'; ctx.lineWidth = 2.4;
      ctx.beginPath(); ctx.arc(_lx, _ly, 6.6, Math.PI, 0); ctx.stroke();
      ctx.fillStyle = 'rgba(178,188,204,0.92)';
      ctx.fillRect(_lx - 9, _ly, 18, 12.5);
      ctx.fillStyle = 'rgba(198,208,222,0.72)';
      ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
      ctx.fillText('未解锁', _lx, _ly + 30);
      ctx.restore();
    }
    /* m34682：这一关没解锁「当前难度」→ 小锁 + 难度名，别让玩家以为是能打 */
    if (_diffLock){
      ctx.save();
      const _lx = _lockX, _ly = ry + rowH/2 - 6;
      ctx.strokeStyle = 'rgba(210,186,140,0.92)'; ctx.lineWidth = 2.2;
      ctx.beginPath(); ctx.arc(_lx, _ly, 6.0, Math.PI, 0); ctx.stroke();
      ctx.fillStyle = 'rgba(210,186,140,0.92)';
      ctx.fillRect(_lx - 8, _ly, 16, 11.5);
      /* 副标题已经写明是哪个难度锁着，这里只画锁不写字 */
      ctx.restore();
    }
    ry += rowH;
    /* 说明只在鼠标停在这张卡上时出现，而且统一画在列表下方那一行 */
    if (L.note && uiHit(mouse.x, mouse.y) === card) hoverNote = L.note;
    ry += gap;
  }
  if (!n){
    ctx.textAlign = 'center';
    ctx.fillStyle = PAL.P153;
    ctx.font = '14px "Microsoft YaHei",sans-serif';
    ctx.fillText('这一章还没做完', W/2, ry + 20);
  }
  /* 分页条：关卡多到一屏放不下时才有。放在屏幕最下面一条，和"说明"那行错开 */
  if (pages > 1){
    const pgY = H - 58;
    ctx.textAlign = 'center';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = PAL.P154;
    ctx.fillText('第 ' + (selLvPage + 1) + ' / ' + pages + ' 页', W/2, pgY + 17);
    if (selLvPage > 0) btn(W/2 - 132, pgY, 92, 26, '‹ 上一页', ()=>{ selLvPage--; }, { dim: true });
    if (selLvPage < pages - 1) btn(W/2 + 40, pgY, 92, 26, '下一页 ›', ()=>{ selLvPage++; }, { dim: true });
  }

  ctx.textAlign = 'center';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  const hintY = (pages > 1) ? H - 86 : Math.min(ry + 14, H - 20);
  if (hoverNote){
    ctx.fillStyle = 'rgba(150,200,232,0.92)';
    ctx.fillText(hoverNote, W/2, (pages > 1) ? hintY : Math.min(ry + 16, H - 20));
  } else {
    ctx.fillStyle = PAL.P151;
    ctx.fillText('把鼠标停在关卡上，看它的一句说明', W/2, hintY);
  }

  flushButtons();
  /* m35945：灰掉的难度按钮再压一把小锁，跟关卡卡片的锁是同一套画法 */
  _dl.forEach((kn, i)=>{
    if (!_dlLock[kn]) return;
    const _bx = dx0 + i*(dw+dg), _lx = _bx + dw - 11, _ly = 30 + 11;
    ctx.save();
    ctx.strokeStyle = 'rgba(178,188,204,0.85)'; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.arc(_lx, _ly - 2, 4.4, Math.PI, 0); ctx.stroke();
    ctx.fillStyle = 'rgba(178,188,204,0.85)';
    ctx.fillRect(_lx - 6, _ly - 2, 12, 8.5);
    ctx.restore();
  });
  ctx.restore();
  drawSelToast();   /* m35034：选关页的'未解锁'提示，自己计时，不靠 update */
}

/* 章节封面：用当前主题画一小段"货架 + 人 + 灯"的示意图，不用外链图片 */
function drawChapterCover(x, y, w, h, ch){
  const light = ch.theme === 'light';
  ctx.save();
  roundRect(x, y, w, h, 12); ctx.clip();

  ctx.fillStyle = light ? PAL.P34 : PAL.P5;
  ctx.fillRect(x, y, w, h);

  /* 网格 */
  ctx.strokeStyle = light ? PAL.P65 : PAL.P299;
  ctx.lineWidth = 1;
  for (let gx = x; gx < x + w; gx += 40){
    ctx.beginPath(); ctx.moveTo(gx, y); ctx.lineTo(gx, y+h); ctx.stroke();
  }
  for (let gy = y; gy < y + h; gy += 40){
    ctx.beginPath(); ctx.moveTo(x, gy); ctx.lineTo(x+w, gy); ctx.stroke();
  }

  /* 货架剪影 */
  ctx.fillStyle = light ? PAL.P25 : PAL.P80;
  const shelves = [[0.06,0.30,0.30,0.05],[0.44,0.30,0.24,0.05],[0.76,0.30,0.20,0.05],
                   [0.02,0.50,0.22,0.05],[0.30,0.50,0.30,0.05],[0.66,0.50,0.28,0.05]];
  for (const [sx,sy,sw,sh] of shelves){
    ctx.fillRect(x + w*sx, y + h*sy, w*sw, h*sh);
  }

  /* 一个亮着的人 + 一束光，代表这一章的气质 */
  const px = x + w*0.50, py = y + h*0.78;
  if (!light){
    ctx.fillStyle = PAL.P128;
    ctx.beginPath(); ctx.moveTo(x + w*0.16, y + h*0.55);
    ctx.lineTo(x + w*0.16, y + h*0.98); ctx.lineTo(x + w*0.62, y + h*0.98);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = PAL.P254;
    ctx.beginPath(); ctx.arc(x + w*0.30, y + h*0.70, 5, 0, TAU); ctx.fill();
  } else {
    ctx.fillStyle = PAL.P277;
    ctx.beginPath(); ctx.moveTo(x + w*0.72, y + h*0.40);
    ctx.lineTo(x + w*0.98, y + h*0.55); ctx.lineTo(x + w*0.72, y + h*0.86);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = PAL.P171;
    ctx.beginPath(); ctx.arc(x + w*0.80, y + h*0.70, 5, 0, TAU); ctx.fill();
  }
  ctx.fillStyle = light ? PAL.P6 : PAL.P2;
  ctx.beginPath(); ctx.arc(px, py, 6, 0, TAU); ctx.fill();
  ctx.strokeStyle = light ? PAL.P176 : PAL.P3;
  ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py, 10, 0, TAU); ctx.stroke();

  /* 底部压暗 + 文案 */
  const g = ctx.createLinearGradient(x, y + h*0.30, x, y + h);
  g.addColorStop(0, light ? PAL.P199 : PAL.P296);
  g.addColorStop(0.55, light ? PAL.P200 : PAL.P297);
  g.addColorStop(1, light ? PAL.P201 : PAL.P298);
  ctx.fillStyle = g; ctx.fillRect(x, y, w, h);

  ctx.textAlign = 'left';
  ctx.fillStyle = light ? PAL.P6 : PAL.P2;
  ctx.font = 'bold 24px "Microsoft YaHei",sans-serif';
  ctx.fillText(ch.name, x + 20, y + h - 42);
  ctx.fillStyle = light ? PAL.P264 : PAL.P185;
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText(ch.tag, x + 20, y + h - 18);

  ctx.restore();
  ctx.strokeStyle = light ? PAL.P120 : PAL.P124;
  ctx.lineWidth = 1.5; roundRect(x, y, w, h, 12); ctx.stroke();
}

/* 章节表：按 LEVELS 里的 chapter 字段归并，没写的算第一章 */
function buildChapters(){
  const meta = {
    1: {name:'第一章 · 夜', tag:'仓库、集散中心、停电层、猎场 · 越往里越黑', theme:'dark',
        learn:'本章：学静步与视野 —— 蹲着走脚步声传得近得多；视野锥外的人你根本看不见，只能听声纹'},
    2: {name:'第二章 · 昼', tag:'天亮了，躲藏变得难得多 · 五关', theme:'light',
        learn:'本章：躲藏变难 + 学会用烟雾弹 —— 天亮了更亮、摄像头与自动门盯着你，靠烟把视线遮断'},
    3: {name:'第三章 · 回收', tag:'从这里开始你手里有枪了 · 机制版本 2', theme:'dark',
        learn:'本章：学战斗 —— 手里终于有枪：换弹、换枪、后坐力、子弹分口径，打中才算数'},
    4: {name:'第四章 · 长廊', tag:'一条很长很长的走廊 · 全是拿枪的 · 视野外直接隐身', theme:'dark',
        learn:'本章：在长走廊里对枪 —— 对面全是持枪的，视野外直接隐身，靠脚步判断谁先到拐角'}
  };
  const ns = [];
  for (const L of LEVELS){
    const n = L.chapter || 1;
    if (ns.indexOf(n) < 0) ns.push(n);
  }
  ns.sort((a,b)=>a-b);
  return ns.map(n => ({ n, name: (meta[n]||{}).name || ('第 ' + n + ' 章'),
                        tag: (meta[n]||{}).tag || '', theme: (meta[n]||{}).theme || 'dark',
                        learn: (meta[n]||{}).learn || '' }));
}
/* var 而不是 let：上面那行 CHAPTERS = buildChapters() 会先跑，let 会撞 TDZ */
var CHAPTERS;
var selChapter = 1;
/* 关卡多到一屏放不下时按页翻（每页行数按窗口高度算），换章就回到第一页 */
var selLvPage = 0;

function drawEnd(kind){
  uiButtons = [];
  const win = kind === 'win', clear = kind === 'clear';
  ctx.save();
  ctx.fillStyle = clear ? PAL.P274 : (win ? PAL.P257 : PAL.P164);
  ctx.fillRect(0,0,W,H);
  ctx.textAlign = 'center';

  ctx.fillStyle = clear ? PAL.P29 : (win ? PAL.P1 : PAL.P32);
  ctx.font = 'bold 54px "Microsoft YaHei",sans-serif';
  ctx.fillText(clear ? (cur().name + ' 撤离成功') : (win ? (dzLvl ? '撤离成功' : '全部通关') : '你被找到了'), W/2, 268);

  ctx.fillStyle = PAL.P20;
  ctx.font = '18px "Microsoft YaHei",sans-serif';
  if (clear){
    ctx.fillText('用时 '+timeAlive.toFixed(1)+' 秒   ·   剩 '+player.grenades+' 颗烟', W/2, 322);
    ctx.fillText(levelIdx < LEVELS.length-1 ? '下一关是 ' + LEVELS[levelIdx+1].name + '，地图 ' + LEVELS[levelIdx+1].w + '×' + LEVELS[levelIdx+1].h : '这是最后一关', W/2, 356);
    ctx.fillStyle = PAL.P0;
    ctx.fillText('难度 ' + (DIFF_LABEL[diffName] || diffName), W/2, 390);
  } else if (win){
    ctx.fillText('总用时 '+(runTimes.reduce((a,b)=>a+(b||0),0)||timeAlive).toFixed(1)+' 秒   ·   剩 '+player.grenades+' 颗烟', W/2, 322);
    ctx.fillText(dzLvl ? '黑匣子到手，这趟没白来。' : (LEVELS[LEVELS.length-1].boss ? '笼子关错了人。' : '全关了。这活儿你能干。'), W/2, 356);
    ctx.fillStyle = PAL.P0;
    ctx.fillText('难度 ' + (dzLvl ? (DZ_TIER_LABEL[dzTier] || dzTier) : (DIFF_LABEL[diffName] || diffName)), W/2, 390);
  } else {
    ctx.fillText('活了 '+timeAlive.toFixed(0)+' 秒   ·   物资 '+player.loot+' / '+lootTotal, W/2, 322);
    ctx.fillText(player.grenades===0 ? '烟扔完了，人还在原地。' : '烟还剩 '+player.grenades+' 颗没扔。', W/2, 356);
    ctx.fillStyle = PAL.P0;
    ctx.fillText('难度 ' + (DIFF_LABEL[diffName] || diffName), W/2, 390);
  }

  const y2 = 430;
  if (clear){
    if (levelIdx < LEVELS.length-1){
      btn(W/2-330, y2, 200, 56, '看全局回放 (R)', ()=>startGreplay(), {primary:true});
      btn(W/2-110, y2, 200, 56, '下一关', ()=>nextLevel());
      btn(W/2+110, y2, 200, 56, '回主菜单', ()=>goMenu());
    } else {
      btn(W/2-330, y2, 200, 56, '看全局回放 (R)', ()=>startGreplay(), {primary:true});
      btn(W/2-110, y2, 200, 56, dzLvl ? '重新选地图' : '重新选关', dzLvl ? ()=>returnDeathZonePrep() : ()=>goSelect());
      btn(W/2+110, y2, 200, 56, '回主菜单', ()=>goMenu());
    }
  } else if (win){
    btn(W/2-330, y2, 200, 56, '看全局回放 (R)', ()=>startGreplay(), {primary:true});
    /* m37154：死亡地带没有"关卡"，这里原来接 goSelect() 会跳到第一章的关卡列表 */
    btn(W/2-110, y2, 200, 56, dzLvl ? '重新选地图' : '重新选关', dzLvl ? ()=>returnDeathZonePrep() : ()=>goSelect());
    btn(W/2+110, y2, 200, 56, '回主菜单', ()=>goMenu());
  } else {
    btn(W/2-430, y2, 200, 56, '看整局回放 (R)', ()=>startGreplay('lose'), {primary:true});
    btn(W/2-210, y2, 200, 56, dzLvl ? '返回出发界面' : '重来本关',
        dzLvl ? ()=>returnDeathZonePrep() : ()=>restartRun());
    /* 死亡地带没有"关卡"：原来这里接 goSelect()（故事关选关），点下去会跳到
       「第一章 · 夜」那种列表，等于回错地方（用户 m16699-7）。
       dz 的"重新选地图"直接回 dzpick；故事关保留原来的"重新选关"。 */
    btn(W/2+10, y2, 200, 56, dzLvl ? '重新选地图' : '重新选关',
        dzLvl ? ()=>returnDeathZonePrep() : ()=>goSelect());
    btn(W/2+230, y2, 200, 56, '回主菜单', ()=>goMenu());
  }

  ctx.fillStyle = PAL.P150;
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillText('Esc 也可以回主菜单   ·   O 改参数', W/2, y2 + 96);

  flushButtons();
  ctx.restore();
}

/* ---------------- 主循环 ---------------- */
