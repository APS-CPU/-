/* 钝器撞上肉的声音：低频下扫 + 一层闷响噪声 + 一点金属味。
   比 beep 单音"有重量"，是击飞/盾撞的专用音。 */
/* 敌人绘制分档：0 = 全套细节，1 = 身体 + 短棍当枪，2 = 一个圆 + 朝向线。
   传入"到玩家的距离平方"，先按望远镜倍率折算成有效距离 ——
   举着望远镜看远处，本来就该看得清他穿什么、拿什么枪，不能退化成圆点。 */
/* 近档放宽到 520：300 太抠了 —— 屏幕上离自己四分之一屏宽的人，玩家眼里就是"在我脸上"，
   那时候还画成棍子，看着像 bug。远档 900：再远才值得退化成圆点。 */
/* LOD 的"近/远"不能按圆算：视野是长方形（1280×800），横向能看 640、纵向只有 400。
   按圆算会让左右两侧明明在眼前的人被降档 —— 玩家看到的就是"拿根棍子的东西"。
   所以用椭圆：横向半径大、纵向半径小，跟画面比例一致。 */
const LOD_NEAR_X = 560, LOD_NEAR_Y = 430;
const LOD_FAR_X = 1010, LOD_FAR_Y = 780;
function enemyLodTier(dx, dy, rk){
  const r = (typeof rk === 'number' && rk > 0) ? rk
    : ((typeof binoRangeK === 'function') ? binoRangeK() : 1);
  /* 阈值可以在 O → 画质 里调（大屏/小屏、老显卡各取所需）；纵向按 0.77 收窄，匹配 16:10 的视野 */
  const _nx = (typeof CFG !== 'undefined' && CFG.lodNear > 0) ? CFG.lodNear : LOD_NEAR_X;
  const _fx = (typeof CFG !== 'undefined' && CFG.lodFar > 0) ? CFG.lodFar : LOD_FAR_X;
  const nx = dx / (_nx * r), ny = dy / (_nx * 0.77 * r);
  if (nx * nx + ny * ny < 1) return 0;
  const fx = dx / (_fx * r), fy = dy / (_fx * 0.77 * r);
  if (fx * fx + fy * fy < 1) return 1;
  return 2;
}

function sfxSlam(heavy){
  if (sndPlay('boss.slam', 0.8)) return;
  if (!actx) return;
  try{
    const t0 = actx.currentTime + 0.004;
    const k = heavy ? 1 : 0.72;
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(120 * k, t0);
    o.frequency.exponentialRampToValueAtTime(28, t0 + 0.30);
    g.gain.setValueAtTime(0.85 * k, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.46);
    o.connect(g); g.connect(duckBus());
    o.start(t0); o.stop(t0 + 0.5);
    /* 一层中频"啪"：撞击的实体感 */
    noiseBurst(0.42 * k, 900, 0.16, 0.9);
    noiseBurst(0.22 * k, 260, 0.34, 1.6);
    /* 金属余响：盾牌/护甲 */
    if (heavy){
      const o2 = actx.createOscillator(), g2 = actx.createGain();
      o2.type = 'triangle';
      o2.frequency.setValueAtTime(430, t0 + 0.01);
      o2.frequency.exponentialRampToValueAtTime(180, t0 + 0.22);
      g2.gain.setValueAtTime(0.10, t0 + 0.01);
      g2.gain.exponentialRampToValueAtTime(0.001, t0 + 0.26);
      o2.connect(g2); g2.connect(duckBus());
      o2.start(t0 + 0.01); o2.stop(t0 + 0.3);
    }
  }catch (e){ if (typeof reportErr === 'function') reportErr('44-sfxcombat', e); }
}
/* 冲击线：从撞击点往外炸开几道短线，0.24 秒散掉。世界坐标。 */
let slamFx = [];
function slamBurst(x, y, ang, n){
  slamFx.push({ x, y, ang, t: 0, n: n || 9 });
  if (slamFx.length > 12) slamFx.shift();
}
function updateSlamFx(dt){
  for (let i = slamFx.length - 1; i >= 0; i--){
    slamFx[i].t += dt;
    if (slamFx[i].t > 0.24) slamFx.splice(i, 1);
  }
}
function drawSlamFx(){
  for (const f of slamFx){
    const p = Math.min(1, f.t / 0.24);
    const e = 1 - p;
    /* 先铺两团软尘：有了这个，线才不像插在空气里的筷子 */
    for (let q = 0; q < 2; q++){
      const rr = (26 + q * 34) * (0.5 + p * 1.5);
      const g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, rr);
      const a0 = (q ? 0.10 : 0.20) * e;
      g.addColorStop(0, 'rgba(255,214,170,' + a0.toFixed(3) + ')');
      g.addColorStop(0.6, 'rgba(220,170,130,' + (a0 * 0.45).toFixed(3) + ')');
      g.addColorStop(1, 'rgba(180,140,110,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(f.x, f.y, rr, 0, TAU); ctx.fill();
    }
    /* 中心白热闪 */
    if (p < 0.4){
      const cr = 9 + 20 * p;
      const cg = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, cr);
      cg.addColorStop(0, 'rgba(255,252,240,' + (0.85 * e).toFixed(3) + ')');
      cg.addColorStop(0.5, 'rgba(255,196,130,' + (0.36 * e).toFixed(3) + ')');
      cg.addColorStop(1, 'rgba(255,150,90,0)');
      ctx.fillStyle = cg;
      ctx.beginPath(); ctx.arc(f.x, f.y, cr, 0, TAU); ctx.fill();
    }
    /* 冲击线：短、细、朝受击方向扇开；两端都收（细头），不再是等宽长条 */
    ctx.lineCap = 'round';
    for (let i = 0; i < f.n; i++){
      const rnd = (Math.sin(i * 12.9898 + f.x * 0.37) + 1) / 2;
      const da = f.ang + (i - (f.n - 1) / 2) * 0.19 + (rnd - 0.5) * 0.22;
      const r0 = 10 + (14 + rnd * 10) * p;
      const r1 = r0 + (12 + rnd * 30) * e + 4;
      const ca = Math.cos(da), sa = Math.sin(da);
      const x0 = f.x + ca * r0, y0 = f.y + sa * r0;
      const x1 = f.x + ca * r1, y1 = f.y + sa * r1;
      const lw = 0.8 + (1.0 + rnd * 2.0) * e;
      const grad = ctx.createLinearGradient(x0, y0, x1, y1);
      grad.addColorStop(0, 'rgba(255,238,214,' + (0.75 * e).toFixed(3) + ')');
      grad.addColorStop(1, 'rgba(255,190,130,0)');
      ctx.strokeStyle = grad;
      ctx.lineWidth = lw;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.stroke();
    }
    ctx.lineCap = 'butt';
  }
}

function sfxThud(){
  if (!actx) return;
  try {
    const t0 = actx.currentTime + 0.005;
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(80, t0);
    o.frequency.exponentialRampToValueAtTime(32, t0 + 0.28);
    g.gain.setValueAtTime(0.62, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.42);
    o.connect(g); g.connect(duckBus());
    o.start(t0); o.stop(t0 + 0.45);
    const len = Math.floor(actx.sampleRate * 0.18);
    const buf = actx.createBuffer(1, len, actx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random()*2-1) * Math.pow(1 - i/len, 2.2);
    const n = actx.createBufferSource(); n.buffer = buf;
    const lp = actx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 420;
    const ng = actx.createGain(); ng.gain.value = 0.34;
    n.connect(lp); lp.connect(ng); ng.connect(duckBus());
    n.start(t0);
  } catch (e){ if (typeof reportErr === 'function') reportErr('44-sfxcombat', e); }
}

function bossCaught(h){
  if (state !== 'play') return;
  state = 'caught';
  stopSiren();
  caughtT = 0.95;
  caughtZoom = 1;
  caughtFx = 0;
  const hx = h ? h.x : player.x, hy = h ? h.y : player.y;
  caughtFocus = {x: player.x*0.42 + hx*0.58, y: player.y*0.42 + hy*0.58};
  caughtHunter = h || null;
  markDeath('catch', h || null, 0, 0);
  sfxThud();
  camShake = 1.0;
  hitFlash = 0.5;      /* 只在最开始闪一下，别挡住"他怎么扑上来"这一下 */
  const idx = h ? hunters.indexOf(h) + 1 : 0;
  const hd = h ? Math.round(dist(h.x, h.y, player.x, player.y)) : -1;
  logError('boss', '被猎手#' + idx + '扑到 · 第 ' + (levelIdx+1) + ' 关 · 撑了 ' + logGame() + ' · 电闸 ' + swDone + '/3 · 距离 ' + hd + 'px · 猎手状态 ' + ((h && h.state) || '?'));
}
function toDeadFrame(fromReplay){
  /* 死亡页是最高优先级：把还开着的那些层全收掉。
     以前只改 state，背包 ui.inv.open 会一直留着 true(用户 m19077：开着背包死掉，
     结算页按键全被那层吃掉，怎么点都没反应)。 */
  ui.inv.open = false; invGeom = null; invGridGeom = null; ui.inv.drag = null;
  mapOpen = false; codexOpen = false; devSpawnOpen = false; confirmBack = false;
  if (typeof devItemOpen !== 'undefined') devItemOpen = false;
  statusOpen = false; statusT = 0;
  /* 抽奖面板同理：开着它死掉，点击全被面板吃掉，死亡页的按钮点不动。
     关面板会顺手把押注退回背包。 */
  if (typeof GACHA !== 'undefined' && GACHA.open && typeof gachaClose === 'function') gachaClose(true);
  /* 一死就什么都不许继续：读条、换弹、上膛、手雷掐火全部作废 */
  if (typeof haltPlayerActions === 'function') haltPlayerActions();
  mouse.fire = false; mouse.down = false;
  for (const k in keys) keys[k] = false;
  state = 'dead';
  revealAll = true;
  deadT = fromReplay ? 0.6 : 0;   /* 回放看完回来就别再等那 0.55 秒 */
}

function startReplay(){
  if (recBuf.length < 10) return;
  replayT = 0;
  state = 'replay';
}

function enterDead(){
  if (typeof levelMusicStop === 'function') levelMusicStop();   /* 死了就别放战斗音乐了 */
  if (!deathMsgText){
    if (!deathHit) markDeath('bleed', null, 0, 0);
    else { deathCause = deathCauseKey(deathHit.src, deathHit.by); deathMsgText = pickDeathMsg(deathCause); }
  }
  revealAll = true;
  deadT = 0;
  replayT = 0;
  /* 结算页必须压在所有东西上面：背包 / 地图 / 图鉴 / 投放面板 / 回大厅确认
     这些层要是还开着，它们会先吃掉点击和按键，玩家看到的就是"结算页点不动" */
  ui.inv.open = false; invGeom = null; invGridGeom = null; ui.inv.drag = null;
  mapOpen = false; codexOpen = false; devSpawnOpen = false; confirmBack = false;
  if (typeof devItemOpen !== 'undefined') devItemOpen = false;
  statusOpen = false; statusT = 0;
  /* 抽奖面板也要收：开着它死掉，点击会被面板吃掉（用户 m12253） */
  if (typeof GACHA !== 'undefined' && GACHA.open && typeof gachaClose === 'function') gachaClose(true);
  if (typeof haltPlayerActions === 'function') haltPlayerActions();
  mouse.fire = false; mouse.down = false;
  for (const k in keys) keys[k] = false;
  lowHpStop();          /* 关掉低血隧道和心跳，别挡住看清敌人 */
  stopSiren();
  sfxLose();
  camShake = 0;
  /* 默认停在定格，回放由玩家自己点/按 R 看，可反复看 */
  deathView = true; deathViewT = 0;
  state = 'dead';
}

function leaveDead(){
  if (state !== 'dead' || deadT < 0.55) return;
  state = 'lose';
  revealAll = false;
}

function updateReplay(dt){
  replayT += dt;
  if (replayT >= REC_SECS){ replayT = REC_SECS; toDeadFrame(true); }
}

function updateCaught(dt){
  caughtT -= dt;
  const el = 0.95 - Math.max(0, caughtT);
  caughtZoom = 1 + 1.7 * (1 - Math.pow(1 - clamp(el/0.22, 0, 1), 3));
  caughtFx = Math.max(0, 1 - el/0.42);
  hitFlash = Math.max(0, hitFlash - dt*5.0);   /* 挨打红闪要在特写里自己退掉，不能一直红着 */
  camShake = Math.max(0, camShake - dt*2.2);
  if (caughtT <= 0){
    /* 特写放完不直接跳结算：先回到战场定格，让人看清周围都有谁 */
    caughtZoom = 1; caughtFx = 0;
    logError('dead', '被猎手扑到 · 第 ' + (levelIdx+1) + ' 关 · 撑了 ' + logGame() + ' · 电闸 ' + swDone + '/3');
    enterDead();
  }
}

function updateBoss(dt){
  const L = cur();
  if (!hunters.length) return;

  /* 玩家这一帧的真实速度，用来算"他抄到你前面"的落点 */
  if (bossPrevX === null){
    bossPrevX = player.x; bossPrevY = player.y;
    bossPVX = 0; bossPVY = 0;
  } else {
    const k = 1 / Math.max(dt, 1e-4);
    bossPVX = lerp(bossPVX, (player.x - bossPrevX) * k, 0.35);
    bossPVY = lerp(bossPVY, (player.y - bossPrevY) * k, 0.35);
    bossPrevX = player.x; bossPrevY = player.y;
  }

  for (const h of hunters) updateOneHunter(L, h, dt);

  /* 冲刺收尾时释放"同一时间只许一个"的锁 */
  if (bossBoostWho && bossBoostWho.boostT <= 0) bossBoostWho = null;
  if (bossBoostLeft < 0) bossBoostLeft = 0;
}

/* 他要抄到的位置：你 1.8 秒后的地方，再往侧面偏 70°，落在你 160~220px 外。
   故意不给你正前方——是"他出现在你侧前方"，不是"他被塞到你脸上"。 */
function bossIntercept(){
  const L = cur();
  const sp = Math.hypot(bossPVX, bossPVY);
  let baseA = sp > 24 ? Math.atan2(bossPVY, bossPVX) : rand(0, TAU);
  const side = (rand(0, 1) < 0.5) ? -1 : 1;
  const a = baseA + side * (70 * Math.PI / 180);
  const r = rand(160, 220);
  let best = null;
  for (let k=0; k<12; k++){
    const aa = a + (k % 2 ? 1 : -1) * (k * 14 * Math.PI / 180);
    const rr = r - k * 4;
    let x = player.x + Math.cos(aa) * rr + bossPVX * 1.8;
    let y = player.y + Math.sin(aa) * rr + bossPVY * 1.8;
    x = clamp(x, 60, L.w - 60); y = clamp(y, 60, L.h - 60);  /* 别算到地图外面 */
    const d2 = Math.hypot(x - player.x, y - player.y);
    if (d2 < 150 || d2 > 240) continue;                       /* 被夹过就换角度重算 */
    if (ptInWall(L, x, y, 22)) continue;
    return {x:Math.round(x), y:Math.round(y)};
  }
  return safeSpot(L, {x:player.x + Math.cos(a) * r, y:player.y + Math.sin(a) * r}, 24);
}
/* 追到最后位置还看不到人时，要围着这个点转一圈找，而不是扭头就走 */
function bossSearchPts(c){
  const L = cur();
  const pts = [];
  for (let i=0;i<4;i++){
    const a = (i/4)*TAU + rand(-0.35, 0.35);
    const r = rand(70, 150);
    const q = safeSpot(L, {x: c.x + Math.cos(a)*r, y: c.y + Math.sin(a)*r}, 24);
    pts.push({x:q.x, y:q.y});
  }
  return pts;
}

const _HUNTER_CHASE_PATH_START={x:0,y:0}, _HUNTER_CHASE_PATH_GOAL={x:0,y:0};
function updateOneHunter(L, b, dt){
  b.hitFlash = Math.max(0, (b.hitFlash||0) - dt*2);

  const bd = dist(b.x, b.y, player.x, player.y);
  const sees = bossSeesNow(b);

  if (sees && !b.seen){
    b.seen = true;
    sfxAlarm();
    camShake = Math.max(camShake, 0.35);
    if (bossExposed) logInfo('boss', '猎手#' + (hunters.indexOf(b) + 1) + ' 收到你的坐标 · 距离 ' + Math.round(bd));
    else logWarn('boss', '猎手#' + (hunters.indexOf(b) + 1) + ' 发现你了 · 距离 ' + Math.round(bd));
  }
  if (sees){
    b.lastKnown = {x:player.x, y:player.y};
    b.lostT = 0;
    b.searched = false;
    if (b.state === 'patrol') b.state = 'chase';
  }

  /* 扑击：预警期间他站着不动，你还有机会躲开 */
  if (b.state === 'pounce'){
    b.pounceT -= dt;
    b.ang = Math.atan2(player.y-b.y, player.x-b.x);
    if (b.pounceT <= 0){
      /* 预警结束：起跳。不是瞬移，是用 LUNGE_DUR 秒滑过去，看得见轨迹 */
      const reach = Math.min(POUNCE_REACH,
                            freeLen(L, b.x, b.y, b.ang, POUNCE_REACH + 60, b.r),
                            Math.max(0, bd - 6));   /* 不越过你站的位置 */
      b.lx0 = b.x; b.ly0 = b.y;
      b.lx1 = b.x + Math.cos(b.ang) * reach;
      b.ly1 = b.y + Math.sin(b.ang) * reach;
      b.state = 'lunge';
      b.lungeT = LUNGE_DUR; b.lungeDur = LUNGE_DUR;
      b.pounceT = 0;
    }
    return;   /* 预警期间不移动 */
  }
  if (b.state === 'lunge'){
    b.lungeT -= dt;
    const lp = clamp(1 - Math.max(0, b.lungeT) / b.lungeDur, 0, 1);
    const e2 = 1 - (1-lp)*(1-lp);           /* ease-out：先快后慢 */
    b.x = b.lx0 + (b.lx1 - b.lx0) * e2;
    b.y = b.ly0 + (b.ly1 - b.ly0) * e2;
    if (b.lungeT <= 0){
      const bd2 = dist(b.x, b.y, player.x, player.y);
      if (bd2 < POUNCE_GRAB){ bossCaught(b); return; }
      b.state = 'recover'; b.recT = 0.9; b.seen = false;
      b.searchAfter = true;
      setMsg('他扑空了', 1.2);
      logInfo('boss', '猎手扑空 · 还差 ' + Math.round(bd2));
    }
    return;
  }
  if (b.state === 'recover'){
    b.recT -= dt;
    if (b.recT <= 0){
      if (sees){ b.state = 'chase'; }
      else if (b.searchAfter){
        b.searchAfter = false;
        b.state = 'search';
        b.searchT = enemyType(b).searchDur;
        b.searchPts = bossSearchPts(b.lastKnown || {x:b.x, y:b.y});
        b.sp = 0; b.spHold = 1.25; b.searchAng = b.ang;
        b.path = null; b.goal = null;
        logInfo('boss', '猎手扑空后原地搜一圈');
      } else { b.state = 'patrol'; bossPickPatrol(b); }
    }
    return;
  }

  /* 守卫有绳子：离自己的点位太远就不追了，回去守着 */
  b.leashCd = Math.max(0, (b.leashCd || 0) - dt);
  const T = enemyType(b);
  if (T.leash && b.guardSpot && b.state === 'chase' && !sees){
    /* 看见你的时候不回去——否则"看见→回点位→又看见"会每帧来回跳，
       日志会刷屏，人也像在原地抽。只有跟丢且跑太远才收回。 */
    if (dist(b.x, b.y, b.guardSpot.x, b.guardSpot.y) > T.leashR || bd > T.leashBreak){
      b.state = 'patrol'; b.lastKnown = null; b.path = null; b.goal = null;
      b.wp = [[b.guardSpot.x, b.guardSpot.y]]; b.i = 0;
      if (b.leashCd <= 0){ logInfo('boss', '守卫回点位'); b.leashCd = 2.5; }
    }
  }

  /* 走到最后看到你的那个位置还找不到人：就地搜一圈，别急着走 */
  if (b.state === 'chase' && !sees && b.lastKnown){
    const dl = dist(b.x, b.y, b.lastKnown.x, b.lastKnown.y);
    if (dl < 46){
      b.state = 'search';
      b.searchT = enemyType(b).searchDur;
      b.searchPts = bossSearchPts(b.lastKnown);
      b.sp = 0; b.spHold = 1.25; b.searchAng = b.ang;
      b.path = null; b.goal = null;
      setMsg('他没走，在原地找', 1.4);
      logInfo('boss', '猎手到了那个位置没看到人 · 开始搜 ' + b.searchT.toFixed(1) + 's');
    }
  }

  /* 看不见你一段时间就回到巡逻（给你的正是"断开视线"的窗口） */
  if (b.state === 'chase' && !sees){
    b.lostT += dt;
    if (b.lostT > T.lostGrace){
      if (!b.searched){
        /* 跟丢了也别马上走：在最后的位置周围找一圈再说 */
        b.searched = true;
        b.state = 'search';
        b.searchT = enemyType(b).searchDur;
        b.searchPts = bossSearchPts(b.lastKnown || {x:b.x, y:b.y});
        b.sp = 0; b.spHold = 1.25; b.searchAng = b.ang;
        b.path = null; b.goal = null;
        setMsg('他没走，在原地找', 1.4);
        logInfo('boss', '猎手追丢了 · 在最后的位置搜一圈');
      } else {
        b.state = 'patrol'; bossPickPatrol(b);
        b.lastKnown = null; b.path = null; b.goal = null;
        setMsg('他没再追过来', 1.2);
        logInfo('boss', '猎手跟丢了 · 回巡逻');
      }
    }
  }

  /* ---------- 离线冲刺 ---------- */
  const inView = playerSees(b);
  if (b.revealT > 0) b.revealT -= dt;

  /* 他重新出现在你视野里的那一瞬：停 0.18 秒，让你有机会反应 */
  if (inView && !b.wasInView && b.boostT > 0){
    b.revealT = 0.18;
    b.boostT = 0; b.boostCd = 1.2; b.boostGoal = null;
    b.revealStop = true;
    thump(0.5, 96, 44);
    camShake = Math.max(camShake, 0.18);
    logInfo('boss', '猎手冲刺后撞进你的视野 · 距离 ' + Math.round(bd) + ' · 停顿 0.18s');
  }
  b.wasInView = inView;
  if (b.boostT > 0 && inView){ b.boostT = 0; b.boostCd = 1.2; b.boostGoal = null; }
  if (b.revealT === undefined) b.revealT = 0;
  b.boostCd = Math.max(0, (b.boostCd || 0) - dt);

  /* 注意：boostT/boostCd 一开始是 undefined，undefined <= 0 是 false，
     所以这里必须用"不大于 0"的写法，不能写 <= 0 */
  if (!inView && !(b.boostT > 0) && !(b.boostCd > 0)
      && (b.state === 'chase' || b.state === 'patrol')
      && bd > 380 && (bossExposed || bd < 760) && bossBoostLeft > 0
      && (bossBoostWho === null || bossBoostWho === b)
      && !(player.moving && bd < 220)){
    b.boostT = 2.5; b.boostCd = 3.7; b.boostStepT = 0;
    b.boostGoal = bossIntercept();
    bossBoostWho = b;
    logInfo('boss', '猎手#' + (hunters.indexOf(b) + 1) + ' 离线冲刺 · 距离 ' + Math.round(bd)
            + ' · 目标 ' + Math.round(b.boostGoal.x) + ',' + Math.round(b.boostGoal.y));
  }

  let tx, ty, spd;
  if (b.state === 'search'){
    b.searchT -= dt;
    b.spHold = (b.spHold || 0) - dt;
    if (!b.searchPts || !b.searchPts.length) b.searchPts = bossSearchPts(b.lastKnown || {x:b.x, y:b.y});
    if (b.spHold <= 0){ b.sp = ((b.sp || 0) + 1) % b.searchPts.length; b.spHold = 1.25; b.path = null; b.goal = null; }
    const q = b.searchPts[b.sp % b.searchPts.length];
    tx = q.x; ty = q.y; spd = 92;
    if (dist(b.x, b.y, tx, ty) < 22){
      /* 到了就站着转头看四周，不是傻站 */
      spd = 0;
      b.searchAng += dt * 2.1;
      b.ang = b.searchAng;
    }
    if (b.searchT <= 0){
      b.state = 'patrol'; bossPickPatrol(b);
      b.lastKnown = null; b.path = null; b.goal = null; b.searchPts = null;
      setMsg('他搜了一圈，走了', 1.2);
      logInfo('boss', '猎手搜完一圈 · 回巡逻');
    }
  } else if (b.state === 'chase' && b.lastKnown){
    tx = b.lastKnown.x; ty = b.lastKnown.y;
    /* 追不是匀速吊着：冲一阵、喘一口，逼上来是一波一波的 */
    b.burstT = (b.burstT || 0) - dt;
    if (b.burstT <= 0){
      b.burstOn = !b.burstOn;
      b.burstT = b.burstOn ? T.burstDur : (bossExposed ? T.restDurOut : T.restDur);
    }
    spd = b.burstOn
      ? (bossExposed ? T.burstSpdOut : T.burstSpd)
      : (bossExposed ? T.restSpdOut : T.restSpd);
    if (bd < POUNCE_RANGE){ b.state = 'pounce'; b.pounceT = pounceSec(); return; }
  } else {
    if (!b.wp || !b.wp.length) bossPickPatrol(b);
    const w = b.wp[b.i % b.wp.length];
    if (ptInWall(L, w[0], w[1], 8)) bossPickPatrol(b);
    tx = w[0]; ty = w[1]; spd = T.patrolSpd;
    /* 到点判定：贴墙/贴地图边缘的点，人挤不进 18px 里，放宽一点，
       否则他会永远差几像素到不了、被当成"走不到"。 */
    const nearEdge = (tx < 70 || ty < 70 || tx > L.w-70 || ty > L.h-70);
    let nearWall = false;
    for (const w2 of L.walls){
      const qx = Math.min(Math.max(tx, w2.x), w2.x+w2.w), qy = Math.min(Math.max(ty, w2.y), w2.y+w2.h);
      if (Math.hypot(qx-tx, qy-ty) < 52){ nearWall = true; break; }
    }
    const arriveR = (nearEdge || nearWall) ? 46 : 18;
    if (dist(b.x, b.y, tx, ty) < arriveR){
      b.wait -= dt;
      if (b.wait <= 0){ bossPickPatrol(b); b.wait = 0.4; }
      spd = 0;
    } else {
      /* 巡逻进度看门狗：盯了 3.5 秒还没靠近 30px，就当这个点到不了，换一个。
         没有这条，一个走不到的巡逻点会让人机永远贴着墙推。 */
      if (b.patTX === undefined || Math.abs(tx - b.patTX) > 1 || Math.abs(ty - b.patTY) > 1){
        b.patTX = tx; b.patTY = ty; b.patPi = b.pi|0; b.patT = 0;
      } else {
        b.patT = (b.patT || 0) + dt;
        /* 用"路径点推进"判断有没有在动，而不是"到目标的直线距离"：
           绕墙的时候直线距离会先变大，用距离判断会把正常绕路当成走不到，
           结果就是人正要绕过墙、却被判失败、重挑一个点，看起来像在原地打转。 */
        /* pi 会随路径重算归零（navSteer 每 0.8 秒重规划一次），拿它当进度会
           把"正在正常赶路"误判成"走不到"——日志里 30 条"换一个"就是这么来的。
           真正该判的是：走了很久 AND 原地打滑（净位移上不去）才算走不到。 */
        if ((b.pi|0) > (b.patPi|0)){ b.patPi = b.pi|0; b.patT = 0; }
        else if (b.patT > 12 && (b.slipN || 0) >= 1){
          b.patT = 0; b.slipN = 0;
          logWarn('boss', '猎手走不到巡逻点 ' + Math.round(tx) + ',' + Math.round(ty) + ' · 换一个');
          bossPickPatrol(b);
          b.path = null; b.goal = null;
        }
      }
    }
  }

  /* 冲刺中：速度拉高，目标换成"你 1.8 秒后的侧前方" */
  if (b.boostT > 0){
    b.boostT -= dt;
    bossBoostLeft -= dt;
    b.boostStepT = (b.boostStepT || 0) - dt;
    if (b.boostStepT <= 0){
      b.boostStepT = 0.6;
      b.boostGoal = bossIntercept();
      b.path = null; b.goal = null;      /* 换目标就重新找近路 */
    }
    if (b.boostGoal){ tx = b.boostGoal.x; ty = b.boostGoal.y; }
    spd *= 1.52;
    b.stepT2 = (b.stepT2 || 0) - dt;
    if (b.stepT2 <= 0){
      /* 模糊的脚步声：你能听见"他在那边跑"，但不知道准在哪 */
      b.stepT2 = 2.2;
      pushEnemyStep(b.x, b.y, true);
    }
    if (b.boostT <= 0){ b.boostGoal = null; }
  }
  if (b.revealT > 0) spd = 0;

  /* 贴着墙角蹭的时候他自己是察觉不到的：1.2 秒净位移太小就换条路 */
  b.netT = (b.netT || 0) + dt;
  if (b.netT >= 1.2){
    const net = (b.netX === undefined) ? 999 : dist(b.x, b.y, b.netX, b.netY);
    /* 只有"他想走却走不动"才算打滑。巡逻点到了原地等一会儿（spd=0）是正常的，
       以前没这层判断，每站定一次就误报一条"打滑"、还会白重挑一次巡逻点。 */
    if (net < 16 && spd > 0.1){
      b.path = null; b.goal = null; b.avoid = null; b.avoidT = 0;
      b.forceT = 0.55;
      b.forceA = rand(0, TAU);
      /* 先看是不是压根站在网格认为"不可走"的角落里 —— 那种地方调方向没用，得挪出来 */
      const moved = unstickHunter(L, b);
      if (moved){
        b.forceT = 0;
        logWarn('boss', '猎手卡在死角（' + Math.round(b.netX) + ',' + Math.round(b.netY) + '）· 挪到 '
                 + Math.round(b.x) + ',' + Math.round(b.y));
      }
      /* 追人的时候目标可能是"够不着"的最后位置：验证一次，够不着就放弃追击 */
      _HUNTER_CHASE_PATH_START.x=b.x;_HUNTER_CHASE_PATH_START.y=b.y;
      if(b.lastKnown){_HUNTER_CHASE_PATH_GOAL.x=b.lastKnown.x;_HUNTER_CHASE_PATH_GOAL.y=b.lastKnown.y;}
      if (b.state === 'chase' && b.lastKnown && !NavQuery.findPath(L,_HUNTER_CHASE_PATH_START,_HUNTER_CHASE_PATH_GOAL) && !navWork.deferred){
        b.mode = 0; b.state = 'patrol'; b.lastKnown = null; b.alertT = 0;
      }
      if (b.state === 'patrol') bossPickPatrol(b);

      /* 兜底：同一小块地方反复打滑，说明这个目标对他就是死路，直接放弃换个活法 */
      b.slipX = b.slipX === undefined ? b.x : b.slipX;
      b.slipY = b.slipY === undefined ? b.y : b.slipY;
      if (dist(b.x, b.y, b.slipX, b.slipY) < 40) b.slipN = (b.slipN || 0) + 1;
      else { b.slipX = b.x; b.slipY = b.y; b.slipN = 0; }
      if (b.slipN >= 3){
        b.slipN = 0; b.mode = 0; b.state = 'patrol'; b.lastKnown = null; b.alertT = 0;
        b.path = null; b.goal = null;
        bossPickPatrol(b);
        logWarn('boss', '猎手在同一处反复卡住 · 放弃当前目标重新巡逻（' + Math.round(b.x) + ',' + Math.round(b.y) + '）');
      }

      if (!moved){
        /* 以前每打滑一次就写一行，日志被刷得看不出问题在哪。
           现在攒着：同一个猎手 8 秒内只报一行，并且带上这 8 秒里打滑了几次。 */
        b.slipCnt = (b.slipCnt || 0) + 1;
        b.slipLogT = (b.slipLogT || 0) - 1.2;
        if (b.slipLogT <= 0){
          const msg = '猎手打滑 ' + b.slipCnt + ' 次 · 最后一次只挪了 ' + Math.round(net) + 'px · 位置 '
                    + Math.round(b.x) + ',' + Math.round(b.y);
          if (b.slipCnt >= 3) logWarn('boss', msg); else logInfo('boss', msg);
          b.slipCnt = 0; b.slipLogT = 8;
        }
      }
    }
    b.netX = b.x; b.netY = b.y; b.netT = 0;
  }

  if (spd > 0){
    /* 他的脚步：频率很低，只有很近才漏得出声纹 */
    b.stepT = (b.stepT || 0) - dt;
    if (b.stepT <= 0){
      b.stepT = T.stepGap;
      if (bd < CFG.hearR * T.stepHear * hearMaskK()){
        pushEnemyStep(b.x, b.y, true);
      }
    }
    let a;
    if (b.forceT > 0){ b.forceT -= dt; a = b.forceA; }
    else a = navSteer(L, b, tx, ty, dt);
    b.ang = lerp(b.ang, a, Math.min(1, dt*7));
    b.x += Math.cos(a)*spd*dt;
    b.y += Math.sin(a)*spd*dt;
    for (const w2 of L.walls) pushOutCircle(b, b.r, w2);
    b.x = clamp(b.x, 18, L.w-18); b.y = clamp(b.y, 18, L.h-18);
  }

  /* 听得见你的脚步：他会被引过来 */
  if (b.state === 'patrol'){
    const nr = playerHearR() * 0.9;
    if (bd < nr && player.moving){
      b.lastKnown = {x:player.x + rand(-40,40), y:player.y + rand(-40,40)};
      b.state = 'chase';
      b.ang = Math.atan2(b.lastKnown.y-b.y, b.lastKnown.x-b.x);
    }
  }
}

/* 拉电闸 */
function updateSwitches(dt){
  const L = cur();
  for (const s of switches) s.pulse += dt*2.6;
  if (swDone >= switches.length) return;
  const s = switches[swDone];
  if (!s || s.on) return;
  if (dist(player.x, player.y, s.x, s.y) < 34){
    s.on = true; swDone++;
    sfxPick();
    camShake = Math.max(camShake, 0.25);
    pullSwitch();
  }
}

function pullSwitch(opts){
  const L = cur();
  const quiet = !!(opts && opts.quiet);   /* 开发者一键全拉时，别把三遍声音和三遍提示叠一起 */
  /* 拉闸的机械声：一个覆盖全图的声纹，等于把自己的位置广播出去 */
  if (!quiet){
    sfxSwitch();
    camShake = Math.max(camShake, 0.45);
    pushEnemyStep(player.x, player.y, true, true);
  }
  for (const h of hunters){
    if (dist(h.x, h.y, player.x, player.y) < 2200){
      h.lastKnown = {x:player.x, y:player.y};
      h.lostT = 0;
      h.searchT = 0; h.searchPts = null; h.searchAfter = false; h.searched = false;
      if (h.state === 'patrol' || h.state === 'search') h.state = 'chase';
    }
  }
  if (!quiet){
    setMsg('闸门咔的一声 —— 整层都听见了', 1.9);
    logWarn('boss', '拉闸的巨响传遍全层 · 猎手都知道了你的位置');
  }
  if (swDone === 1){
    if (!quiet) setMsg('第一个电闸 · 第二个的位置标出来了，多了一个人', 2.6);
    logInfo('boss', '电闸 1/3 · 显示第二个电闸位置 · 场上来了一名哨兵');
    addSentinel();
  } else if (swDone === 2){
    if (hunters.length < 4) addHunter('guard');
    else logInfo('boss', '第二个电闸 · 场上已经够多了，这次没再放人');
    if (!quiet) setMsg('第二个电闸 · 第三个的位置标出来了 · 又来了一个', 2.6);
    logInfo('boss', '电闸 2/3 · 显示第三个电闸位置 · 场上多了一个猎手');
  } else if (swDone >= 3){
    openExit();
  }
}

function addSentinel(){
  /* 第一个电闸原本放的是"哨兵"——一个走普通小怪外形的敌人。
     这一关的设定里没有普通小怪，玩家会以为关卡串了，所以改成再放一个猎手。 */
  if (hunters.length >= 4){ logInfo('boss', '第一个电闸 · 场上已经够多了，这次没再放人'); return; }
  addHunter('guard');
}

function openExit(){
  const L = cur();
  if (exitOpen) return;
  exitOpen = true;
  player.crouchLock = false;
  bossExposed = true;
  runBannerT = 2.6;
  runT = 0;
  sfxSiren(0.62); camShake = 0.8;
  /* 出口开在离你最远的那个点 —— 想赢就得把整张图跑穿 */
  let sp = L.exitSpots[0], best = -1;
  for (const q of L.exitSpots){
    const d = Math.hypot(q.x + q.w/2 - player.x, q.y + q.h/2 - player.y);
    if (d > best){ best = d; sp = q; }
  }
  L.extract = {x:sp.x, y:sp.y, w:sp.w, h:sp.h};
  /* 守卫不再团团转，直接分头去"你和出口之间"的路上堵你 */
  const exC = {x: sp.x + sp.w/2, y: sp.y + sp.h/2};
  const guards = hunters.filter(function(h){ return h.role === 'guard'; });
  const perp = Math.atan2(exC.y - player.y, exC.x - player.x) + Math.PI/2;
  guards.forEach(function(h, gi){
    const t = guards.length <= 1 ? 0.55 : 0.34 + 0.46 * (gi / (guards.length - 1));
    /* 每个人都往侧向错开一点，免得几个人叠在一个点上 */
    const off = (gi - (guards.length - 1)/2) * 58;
    const gx = player.x + (exC.x - player.x) * t + Math.cos(perp) * off;
    const gy = player.y + (exC.y - player.y) * t + Math.sin(perp) * off;
    const q = safeSpot(L, {x:gx, y:gy}, 34);
    h.guardSpot = {x:q.x, y:q.y};
    h.wp = [[q.x, q.y]]; h.i = 0; h.state = 'patrol';
    h.path = null; h.goal = null; h.lastKnown = null;
    logWarn('boss', '猎手#' + (hunters.indexOf(h) + 1) + ' 去堵路了 · 位置 ' + Math.round(q.x) + ',' + Math.round(q.y));
  });
  addHunter('guard');
  setMsg('出口开了 · 跑', 2.8);
  logWarn('boss', '电闸 3/3 · 出口已开（距你 ' + Math.round(best) + 'px，全场最远）· 你的坐标已实时暴露 · 房间又多了一个');
}

/* 第四关的心跳：完全由"他和你的距离"决定，跟血量无关 */
function lowHpBoss(dt){
  hpFx = {f:1, k1:0, k2:0, k3:0};
  let bd = 2400;
  for (const h of hunters) bd = Math.min(bd, dist(h.x, h.y, player.x, player.y));
  const near = clamp((1050 - bd) / (1050 - 150), 0, 1);
  /* 平滑：靠近时跟得紧一点，远离时慢慢松 —— 这样"他在靠近 / 他在远离"听得出来 */
  hbProx += (near - hbProx) * Math.min(1, dt * (near > hbProx ? 2.6 : 1.5));
  const p = clamp(hbProx, 0, 1);
  tense = p;
  const on = p > 0.04;
  hbSampleOn = on;
  if (on && actx && !hbFailed){
    hbDecode();
    hbBpm = clamp(lerp(60, 152, p), 46, 160);
    const period = 60/hbBpm;
    hbBeatClock += dt;
    if (hbBeatClock >= period){
      hbBeatClock -= period;
      hbLastHit = 0;
      hbPulse = 1;
      const vol = clamp(lerp(0.03, 0.86, p), 0, 0.86);
      const t0 = actx.currentTime + 0.012;
      hbPlayAt(HB_LUB, t0, vol);
      hbPlayAt(HB_DUB, t0 + Math.min(0.238, period*0.26), vol*0.62);
      if (p > 0.78) camShake = Math.max(camShake, 0.12*(p-0.78)/0.22);
    }
  } else {
    hbBeatClock = 0;
  }
  hbLastHit += dt;
  hbHum(0, 0);
}

/* 剧情开场 */
const INTRO_LINES = [
  '……有点意思。',
  '仓库、集散中心、停电层，你都活着出来了。',
  '知道为什么没人拦你吗？',
  '因为我在等你自己走进来。',
  '别急着跑，老鼠。笼子已经关了。'
];
const BOSS_HINTS = [
  '这一层只有他一个。你看不见他，但听得见他。',
  '拉满三个电闸，出口才会开。在那之前，你只能静步。'
];
const DAY_HINTS = [
  '白天太吵，他们听不清你的脚步 —— 但眼睛好使得多。',
  '墙上那些东西不追人，它们只负责喊人。'
];
function introOf(L){
  if (L.boss) return {lines:INTRO_LINES, hints:BOSS_HINTS, style:'night'};
  if (L.intro) return {lines:L.intro, hints:(L.introHints || DAY_HINTS), style:(L.introStyle || 'day')};
  return null;
}
function startIntro(){
  const src = introOf(cur());
  if (!src) return;
  intro = {i:0, t:0, lines:src.lines.slice(), hints:src.hints.slice(), style:src.style, t0:0};
  state = 'intro';
  sfxLine();          /* 第一行是立刻出现的，也得有声音 */
}
/* 每露出一行就"叮"一声 */
function introTick(sfx){
  if (!intro) return;
  intro.i++;
  intro.t = 0;
  if (sfx) sfxLine();
}
function updateIntro(dt){
  intro.t += dt;
  if (intro.t > 1.15){
    intro.t = 0;
    if (intro.i < intro.lines.length + (intro.hints||[]).length) introTick(true);
  }
  if (intro.i >= intro.lines.length + (intro.hints||[]).length && intro.t > 0.4) intro.ready = true;
}
function introAdvance(){
  if (!intro) return;
  if (intro.i < intro.lines.length + (intro.hints||[]).length){ introTick(true); }
  else { introSeen[levelIdx] = true; intro = null; state = 'play'; player.heatKeyPrev = true; }
}


/* ---------------- 第四关绘制 ---------------- */
function inView(x, y, pad){
  pad = pad === undefined ? 60 : pad;
  return x > cam.x - pad && x < cam.x + W + pad && y > cam.y - pad && y < cam.y + H + pad;
}
function drawSwitches(th){
  for (let i=0;i<switches.length;i++){
    const s2 = switches[i];
    if (!s2.on && i !== swDone) continue;
    if (!inView(s2.x, s2.y, 80)) continue;
    const on = s2.on;
    const pr = 0.5 + 0.5*Math.sin(s2.pulse*2);
    ctx.save();
    /* 未拉的电闸给一圈呼吸光，好找 */
    if (!on){
      const g = ctx.createRadialGradient(s2.x,s2.y,6,s2.x,s2.y,64);
      g.addColorStop(0,'rgba(255,210,74,'+(0.14+0.10*pr)+')');
      g.addColorStop(1, TC(PAL.P228));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(s2.x,s2.y,64,0,TAU); ctx.fill();
    }
    ctx.translate(s2.x, s2.y);
    ctx.fillStyle = on ? PAL.P281 : PAL.P266;
    ctx.fillRect(-15,-19,30,38);
    ctx.strokeStyle = on ? PAL.P8 : 'rgba(255,210,74,'+(0.65+0.35*pr)+')';
    ctx.lineWidth = 2; ctx.strokeRect(-15,-19,30,38);
    ctx.strokeStyle = on ? PAL.P1 : PAL.P0;
    ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(0,9); ctx.lineTo(on ? 9 : -9, -11); ctx.stroke();
    ctx.restore();
    ctx.save();
    ctx.textAlign = 'center';
    ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = on ? PAL.P15 : PAL.P233;
    ctx.fillText(on ? '已拉' : ('电闸 ' + (i+1)), s2.x, s2.y - 30);
    ctx.restore();
  }
}

function drawBoss(th){
  for (const h of hunters) drawOneBoss(h, th);
}
function drawOneBoss(b, th){
  if (th){
    const g = ctx.createRadialGradient(b.x,b.y,3,b.x,b.y,46);
    g.addColorStop(0, TC(PAL.P238));
    g.addColorStop(0.30, TC(PAL.P211));
    g.addColorStop(1, TC(PAL.P63));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(b.x,b.y,46,0,TAU); ctx.fill();
    return;
  }
  const visible = bossExposed || playerSees(b) || revealAll || (CFG.dev && CFG.xray);
  if (!visible) return;
  const pr = 0.5 + 0.5*Math.sin(uiT*4.4);
  const g2 = ctx.createRadialGradient(b.x,b.y,4,b.x,b.y,62);
  g2.addColorStop(0, b.state==='pounce' ? PAL.P253 : PAL.P247);
  g2.addColorStop(1, TC(PAL.P245));
  ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(b.x,b.y,62,0,TAU); ctx.fill();

  if (b.state === 'pounce'){
    const total = pounceSec();
    const p = clamp(1 - b.pounceT/total, 0, 1);
    ctx.save();
    ctx.fillStyle = PAL.P246;
    ctx.beginPath(); ctx.moveTo(b.x,b.y);
    ctx.arc(b.x,b.y, 96, b.ang-0.55, b.ang+0.55); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(255,80,55,'+(0.95-0.35*p)+')';
    ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(b.x,b.y, b.r+8 + 54*p, 0, TAU); ctx.stroke();
    ctx.restore();
  }

  ctx.fillStyle = b.state==='pounce' ? PAL.P94 : PAL.P78;
  ctx.beginPath(); ctx.arc(b.x,b.y,b.r,0,TAU); ctx.fill();
  ctx.strokeStyle = 'rgba(255,85,60,'+(0.55+0.45*pr)+')'; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(b.x,b.y,b.r+2,0,TAU); ctx.stroke();
  ctx.strokeStyle = PAL.P223; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(b.x,b.y);
  ctx.lineTo(b.x+Math.cos(b.ang)*22, b.y+Math.sin(b.ang)*22); ctx.stroke();

  if (b.state === 'pounce'){
    ctx.fillStyle = PAL.P12; ctx.textAlign = 'center';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText('!', b.x, b.y-28);
  }
}

function drawReplay(){
  const L = cur();
  const f = recBuf[clamp(Math.round(replayT*REC_HZ), 0, recBuf.length-1)];
  if (!f){ ctx.fillStyle = PAL.P5; ctx.fillRect(0,0,W,H); return; }
  const cx = clamp(f.px - W/2, 0, Math.max(0, L.w - W));
  const cy = clamp(f.py - H/2, 0, Math.max(0, L.h - H));

  ctx.fillStyle = PAL.P5; ctx.fillRect(0,0,W,H);
  ctx.save();
  ctx.translate(-cx, -cy);

  /* 网格 */
  ctx.strokeStyle = PAL.P303; ctx.lineWidth = 1;
  for (let x = Math.floor(cx/64)*64; x < cx+W+64; x += 64){
    ctx.beginPath(); ctx.moveTo(x, cy); ctx.lineTo(x, cy+H); ctx.stroke();
  }
  for (let y = Math.floor(cy/64)*64; y < cy+H+64; y += 64){
    ctx.beginPath(); ctx.moveTo(cx, y); ctx.lineTo(cx+W, y); ctx.stroke();
  }

  /* 墙 */
  ctx.fillStyle = PAL.P292;
  for (const w of L.walls) ctx.fillRect(w.x, w.y, w.w, w.h);

  /* 你走过的路（越近越亮），一眼看出自己是从哪走过来的 */
  {
    const idx = clamp(Math.round(replayT*REC_HZ), 0, recBuf.length-1);
    const from = Math.max(0, idx - 70);
    for (let t = from; t <= idx; t += 2){
      const q = recBuf[t]; if (!q) continue;
      const a = 0.06 + 0.30*((t-from)/Math.max(1, idx-from));
      ctx.fillStyle = 'rgba(150,205,235,' + a.toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(q.px, q.py, 2.6, 0, TAU); ctx.fill();
    }
  }

  /* 物资 */
  for (const l of f.lk){
    if (l.t) continue;
    ctx.fillStyle = PAL.P227;
    ctx.fillRect(l.x-6, l.y-6, 12, 12);
  }

  /* 烟 */
  for (const k of f.sm){
    if (k.r < 4) continue;
    const g = ctx.createRadialGradient(k.x,k.y,k.r*0.1,k.x,k.y,k.r);
    g.addColorStop(0, TC(PAL.P146));
    g.addColorStop(1, TC(PAL.P141));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(k.x,k.y,k.r,0,TAU); ctx.fill();
  }

  /* 敌人 */
  for (const e of f.en){
    if (e.s){
      const g2 = ctx.createRadialGradient(e.x,e.y,2,e.x,e.y,34);
      g2.addColorStop(0, TC(PAL.P212));
      g2.addColorStop(1, TC(PAL.P252));
      ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(e.x,e.y,34,0,TAU); ctx.fill();
    }
    ctx.fillStyle = e.s ? PAL.P95 : PAL.P194;
    ctx.beginPath(); ctx.arc(e.x, e.y, 9, 0, TAU); ctx.fill();
    ctx.strokeStyle = PAL.P62; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(e.x, e.y);
    ctx.lineTo(e.x+Math.cos(e.a)*16, e.y+Math.sin(e.a)*16); ctx.stroke();
    if (e.s){
      ctx.fillStyle = PAL.P12; ctx.textAlign = 'center';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText('!', e.x, e.y-16);
    }
  }

  /* 猎手 */
  for (const h of f.hu){
    const g3 = ctx.createRadialGradient(h.x,h.y,4,h.x,h.y,40);
    g3.addColorStop(0, TC(PAL.P249));
    g3.addColorStop(1, TC(PAL.P63));
    ctx.fillStyle = g3; ctx.beginPath(); ctx.arc(h.x,h.y,40,0,TAU); ctx.fill();
    ctx.strokeStyle = PAL.P12; ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.arc(h.x, h.y, 11, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(h.x, h.y);
    ctx.lineTo(h.x+Math.cos(h.a)*18, h.y+Math.sin(h.a)*18); ctx.stroke();
  }

  /* 子弹 */
  ctx.strokeStyle = PAL.P232; ctx.lineWidth = 2;
  for (const b of f.bu){
    ctx.beginPath(); ctx.moveTo(b.x-7, b.y); ctx.lineTo(b.x, b.y); ctx.stroke();
  }

  /* 玩家 */
  ctx.strokeStyle = PAL.P242; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(f.px, f.py, 10, 0, TAU); ctx.stroke();
  ctx.strokeStyle = PAL.P157; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(f.px, f.py);
  ctx.lineTo(f.px+Math.cos(f.aim)*40, f.py+Math.sin(f.aim)*40); ctx.stroke();

  ctx.restore();

  /* ---- 覆盖层 ---- */
  const p = clamp(replayT/REC_SECS, 0, 1);
  const g4 = ctx.createLinearGradient(0,0,0,H);
  g4.addColorStop(0, TC(PAL.P117));
  g4.addColorStop(0.3, TC(PAL.P107));
  g4.addColorStop(1, TC(PAL.P109));
  ctx.fillStyle = g4; ctx.fillRect(0,0,W,H);

  ctx.save();
  ctx.textAlign = 'center';
  ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = PAL.P209;
  ctx.fillText('死亡回放 · 最后 5 秒', W/2, 54);
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = PAL.P196;
  ctx.fillText('白色圆是你 · 红圈是猎手 · 带 ! 的是已经发现你的', W/2, 78);

  /* 进度条 */
  const bw = Math.min(560, W*0.5), bx = W/2 - bw/2, by = H - 74;
  ctx.fillStyle = PAL.P239;
  ctx.fillRect(bx, by, bw, 6);
  ctx.fillStyle = PAL.P204;
  ctx.fillRect(bx, by, bw*p, 6);

  drawDeadBtn(deadBtns().skip, hitDeadBtn(mouse.x, mouse.y, 'skip'));
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = PAL.P198;
  ctx.fillText('播完自动回到定格 · 回去还能再看一次', W/2, H - 46);
  ctx.restore();
}

function deadBtns(){
  const w = 244, h = 44, y = H - 108, gap = 16;
  const total = w*3 + gap*2, x0 = W/2 - total/2;
  return {
    /* 整局回放：上帝视角从头看到尾（跟胜利页那套一样） */
    replay: { x: x0, y: y, w: w, h: h, label: '看整局回放 (R)', on: vrecBuf.length >= 20 },
    /* 死亡瞬间：只放最后 5 秒，看是谁下的手 */
    last:   { x: x0 + w + gap, y: y, w: w, h: h, label: '看死亡瞬间 (V)', on: recBuf.length >= 10 },
    settle: { x: x0 + (w + gap)*2, y: y, w: w, h: h, label: '直接看结算 (ESC)', on: true },
    skip:   { x: W/2 - 110, y: H - 108, w: 220, h: 42, label: '跳过回放 (ESC)', on: true }
  };
}

function hitDeadBtn(mx, my, which){
  const b = deadBtns()[which];
  if (!b || !b.on) return false;
  return mx >= b.x && mx <= b.x+b.w && my >= b.y && my <= b.y+b.h;
}

function drawDeadBtn(b, hot){
  if (!b.on) return;
  ctx.fillStyle = hot ? PAL.P132 : PAL.P261;
  ctx.strokeStyle = hot ? PAL.P215 : PAL.P205;
  ctx.lineWidth = 1.5;
  const r = 10;
  ctx.beginPath();
  ctx.moveTo(b.x+r, b.y); ctx.lineTo(b.x+b.w-r, b.y); ctx.quadraticCurveTo(b.x+b.w, b.y, b.x+b.w, b.y+r);
  ctx.lineTo(b.x+b.w, b.y+b.h-r); ctx.quadraticCurveTo(b.x+b.w, b.y+b.h, b.x+b.w-r, b.y+b.h);
  ctx.lineTo(b.x+r, b.y+b.h); ctx.quadraticCurveTo(b.x, b.y+b.h, b.x, b.y+b.h-r);
  ctx.lineTo(b.x, b.y+r); ctx.quadraticCurveTo(b.x, b.y, b.x+r, b.y);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = PAL.P235;
  ctx.font = 'bold 16px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(b.label, b.x + b.w/2, b.y + b.h/2 + 6);
}

let deathK = 0, deathCv = null, deathCtx = null;
/* 死亡演出：画面一点点掉色、变成黑白（但不会一下子变） */
function applyDeathFx(){
  if (deathK <= 0.001) return;
  if (!deathCv){
    deathCv = document.createElement('canvas');
    deathCtx = deathCv.getContext('2d');
  }
  if (deathCv.width !== W || deathCv.height !== H){
    deathCv.width = W; deathCv.height = H;
  }
  deathCtx.setTransform(1, 0, 0, 1, 0, 0);
  deathCtx.globalCompositeOperation = 'source-over';
  deathCtx.clearRect(0, 0, W, H);
  deathCtx.filter = 'saturate(0) contrast(1.05) brightness(1.02)';
  deathCtx.drawImage(cv, 0, 0, W, H);
  deathCtx.filter = 'none';
  ctx.save();
  ctxScreen();          /* m23103 */
  ctx.globalAlpha = Math.min(1, deathK * 1.05);
  ctx.drawImage(deathCv, 0, 0);
  ctx.restore();
}
let deathView = false, deathViewT = 0;
let playerInWall = false;   /* 玩家此刻是否贴在墙里（只有“无视地形”卡才会） */
/* 定格补画：那一刀是"砍到了"的，不是砍之前就定格 */
function drawDeathHitFx(){
  if (!deathHit || deathHit.src !== 'blade') return;   /* 只有刀手那一下需要补画刀光 */
  const k = clamp(deadT / 0.55, 0, 1);            /* 0→1 在 0.55 秒内走完 */
  const a = 1 - k;
  if (a <= 0.02) return;
  const z2 = 1 - 0.28 * clamp(deadT/0.45, 0, 1);
  const cx = W/2, cy = H/2;                        /* 玩家就在屏幕正中 */
  const R = (player.r * 2.2 + 46) * z2;
  const ang = deathHit.ang;
  ctx.save();
  ctx.lineCap = 'round';
  /* 刀光：一道从 -70° 扫到 +50° 的弧，越来越细、越来越淡 */
  ctx.globalAlpha = a * 0.95;
  ctx.strokeStyle = 'rgba(255,246,238,0.92)';
  ctx.lineWidth = (9 - 5.5*k) * z2;
  ctx.beginPath();
  ctx.arc(cx, cy, R, ang - 1.32 + k*0.20, ang + 0.95 + k*0.20);
  ctx.stroke();
  /* 血：从伤口往被砍的方向喷一小片 */
  ctx.globalAlpha = a;
  ctx.fillStyle = 'rgba(168,14,16,0.92)';
  for (let i = 0; i < 14; i++){
    const p = (i / 13) - 0.5;
    const d = R * (0.30 + k * 1.7) * (0.7 + ((i * 37) % 10) / 18);
    ctx.beginPath();
    ctx.arc(cx + Math.cos(ang + p*1.05) * d, cy + Math.sin(ang + p*1.05) * d,
            (8.4 - 5.2*k) * z2 * (0.55 + ((i*17) % 7) / 9), 0, TAU);
    ctx.fill();
  }
  /* 冲击环：一圈往外扩的白环，强调"砍实了" */
  ctx.globalAlpha = a * 0.5;
  ctx.strokeStyle = 'rgba(255,255,255,0.8)';
  ctx.lineWidth = 3 * z2;
  ctx.beginPath(); ctx.arc(cx, cy, R * (0.55 + k * 1.1), 0, TAU); ctx.stroke();
  ctx.restore();
}

/* 凶手在屏幕上的位置（不同死亡界面用不同镜头） */
function deathScreenPos(wx, wy){
  /* 世界→屏幕，必须和 render 里那串变换逐项对齐（顺序：望远镜 → 观战缩放）。
     以前只写 wx - cam.x，只要画面上有缩放（观战 0.65 / 望远镜 / 死亡拉远），
     气泡、伤害数字、凶手标记就会跟人分家 —— 用户 m42299 看到的"人在这边、对话框在那边"。
     这里按渲染顺序解析地算一遍，不依赖 ctx.getTransform（测试里的假画布没有它）。 */
  if (state === 'dead'){
    const z2 = 1 - 0.28 * clamp(deadT/0.45, 0, 1);
    return { x: (wx - player.x) * z2 + W/2, y: (wy - player.y) * z2 + H/2 };
  }
  if (state === 'caught'){
    return { x: (wx - caughtFocus.x) * caughtZoom + W/2, y: (wy - caughtFocus.y) * caughtZoom + H/2 };
  }
  let x = wx - cam.x, y = wy - cam.y;
  /* 望远镜：绕"自己在屏幕上的位置"缩 */
  const _bz = (typeof binoZoomK === 'function') ? binoZoomK() : 1;
  if (Math.abs(_bz - 1) > 0.001 && player){
    const ax = player.x - cam.x, ay = player.y - cam.y;
    x = ax + (x - ax) * _bz; y = ay + (y - ay) * _bz;
  }
  /* 观战图缩放：绕屏幕中心缩 */
  const _cz = (typeof crkZoomK === 'function') ? crkZoomK() : 1;
  if (Math.abs(_cz - 1) > 0.001){
    x = W/2 + (x - W/2) * _cz; y = H/2 + (y - H/2) * _cz;
  }
  return { x: x, y: y };
}

/* 世界里的发光物在暗色遮罩之后还要补画一次（子弹亮芯、枪口火光、刀光）。
   这时世界矩阵已经 restore，必须把世界坐标手动换成屏幕坐标。
   斗蛐蛐会绕屏幕中心缩放；只做 wx-cam.x 会让补画层和世界层分家，
   100% 时重叠看不出，缩放后就像同一颗子弹在两个位置各画了一条轨迹。 */
function worldGlowScreenPos(wx, wy){
  if (typeof spectatorViewOn === 'function' && spectatorViewOn() &&
      typeof crkSX === 'function' && typeof crkSY === 'function'){
    return { x: crkSX(wx), y: crkSY(wy) };
  }
  return { x: wx - cam.x, y: wy - cam.y };
}
function worldGlowScreenScale(){
  return (typeof spectatorViewOn === 'function' && spectatorViewOn() && typeof crkZoomK === 'function')
    ? crkZoomK() : 1;
}

/* 凶手不在画面里：给它圈个红环，或者在屏幕边上画个箭头 */
function drawKillerMark(){
  const by = deathHit && deathHit.by;
  if (!by || state === 'lose') return;
  const p = deathScreenPos(by.x, by.y);
  const pad = 74;   /* 留出边距，别压到右下角的「参数」按钮 */
  const pulse = 0.55 + 0.45 * Math.sin(uiT * 5.2);
  ctx.save();
  ctx.textAlign = 'center';
  if (p.x > -20 && p.x < W + 20 && p.y > -20 && p.y < H + 20){
    /* 在画面里：套一个涨缩的红环 + 四个短弧 */
    const rr = (by.r || 14) * 2.1 + 10 + pulse * 5;
    ctx.globalAlpha = 0.55 + 0.35 * pulse;
    ctx.strokeStyle = '#ff4a3a';
    ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.arc(p.x, p.y, rr, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 0.28 + 0.22 * pulse;
    ctx.beginPath(); ctx.arc(p.x, p.y, rr + 7, 0, TAU); ctx.stroke();
    /* 上面一小块“就是他” */
    ctx.globalAlpha = 0.8;
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = '#ff8a7a';
    ctx.fillText('就是他', p.x, p.y - rr - 8);
  } else {
    /* 在画面外：在屏幕边上画箭头指过去 */
    const cx = W/2, cy = H/2;
    const a = Math.atan2(p.y - cy, p.x - cx);
    const hw = W/2 - pad, hh = H/2 - pad;
    const t = Math.min(hw / Math.max(0.0001, Math.abs(Math.cos(a))), hh / Math.max(0.0001, Math.abs(Math.sin(a))));
    const mx = cx + Math.cos(a) * t, my = cy + Math.sin(a) * t;
    ctx.globalAlpha = 0.6 + 0.4 * pulse;
    ctx.fillStyle = '#ff4a3a';
    ctx.save();
    ctx.translate(mx, my); ctx.rotate(a);
    ctx.beginPath();
    ctx.moveTo(16, 0); ctx.lineTo(-8, -9); ctx.lineTo(-3, 0); ctx.lineTo(-8, 9);
    ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.globalAlpha = 0.82;
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = '#ff8a7a';
    /* 标签往屏幕里侧挪，并夹在安全区内，避开四角的按钮 */
    const lx = clamp(mx - Math.cos(a) * 52, 76, W - 76);
    const ly = clamp(my - Math.sin(a) * 44, 58, H - 58);
    ctx.fillText('凶手在这边', lx, ly);
  }
  ctx.restore();
}

function drawDead(){
  /* 先把"砍中之后"补上，再压暗、再写字 */
  if (deathHit && player) drawDeathHitFx();
  if (deathView){
    const kk = Math.min(1, Math.max(0, (deathViewT - 0.35) / 0.5));
    if (kk > 0){
      ctx.save();
      ctx.textAlign = 'center';
      ctx.font = '16px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = 'rgba(224,232,244,' + (0.62 * kk).toFixed(2) + ')';
      ctx.fillText('画面已定格 · 按任意键（或点击）看结算', W/2, H - 62);
      ctx.restore();
    }
    return;
  }
  /* 压暗 + 上方"你失败了" + 按键提示；中下部留白，方便看人 */
  const k = clamp(deadT/0.35, 0, 1);
  /* m34931：白天关卡底色反过来是米白，压暗渐变几乎看不出来 → 先垫一层更狠的暗幕 */
  if (typeof THEME_LIGHT !== 'undefined' && THEME_LIGHT){
    ctx.save();
    ctx.fillStyle = 'rgba(6,9,14,' + (0.46*k).toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, 'rgba(6,8,12,' + (0.62*k).toFixed(3) + ')');
  g.addColorStop(0.34, 'rgba(6,8,12,' + (0.22*k).toFixed(3) + ')');
  g.addColorStop(1, 'rgba(0,0,0,' + (0.40*k).toFixed(3) + ')');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

  drawKillerMark();

  /* m34931：白天关卡底色是米白的，那层压暗渐变几乎看不见 → 标题区单独垫一块深色 */
  if (typeof THEME_LIGHT !== 'undefined' && THEME_LIGHT && k > 0.2){
    ctx.save();
    ctx.fillStyle = 'rgba(8,11,16,' + (0.62*k).toFixed(3) + ')';
    if (typeof roundRect === 'function'){ roundRect(W/2 - 420, H*0.075, 840, 132, 14); ctx.fill(); }
    else ctx.fillRect(W/2 - 420, H*0.075, 840, 132);
    ctx.restore();
  }

  ctx.save();
  ctx.textAlign = 'center';
  const a = Math.min(1, k*1.4);
  /* 小字“你失败了”，大字给那句死法文案 */
  ctx.font = 'bold 24px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(240,60,48,' + a.toFixed(2) + ')';
  ctx.fillText('你失败了', W/2, H*0.135);

  const _msg = deathMsgText || '你死了';
  let _fs = 34;
  const _maxW = W - 220;
  ctx.font = 'bold ' + _fs + 'px "Microsoft YaHei",sans-serif';
  while (_fs > 17 && ctx.measureText(_msg).width > _maxW){
    _fs -= 2;
    ctx.font = 'bold ' + _fs + 'px "Microsoft YaHei",sans-serif';
  }
  ctx.shadowColor = 'rgba(255,140,110,0.40)';
  ctx.shadowBlur = 22;
  ctx.fillStyle = 'rgba(255,234,222,' + a.toFixed(2) + ')';
  ctx.fillText(_msg, W/2, H*0.135 + 46);
  ctx.shadowBlur = 0;

  /* 凶手是谁 */
  let _killer = '';
  if (deathHit && deathHit.by) _killer = '凶手：' + deathKillerName(deathHit.by);
  else if (deathCause === 'bleed') _killer = '凶手：没有——你是流血流死的';
  else _killer = '凶手：不明';
  ctx.font = '15px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(255,150,130,' + (0.82*a).toFixed(2) + ')';
  ctx.fillText(_killer, W/2, H*0.135 + 78);

  ctx.font = '13px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(255,210,190,' + (0.62*a).toFixed(2) + ')';
  ctx.fillText('画面已定格 · 视野外的敌人全部显形 · 看清楚是谁下的手', W/2, H*0.135 + 104);

  if (deadT > 0.55){
    const bs = deadBtns();
    drawDeadBtn(bs.replay, hitDeadBtn(mouse.x, mouse.y, 'replay'));
    drawDeadBtn(bs.last, hitDeadBtn(mouse.x, mouse.y, 'last'));
    drawDeadBtn(bs.settle, hitDeadBtn(mouse.x, mouse.y, 'settle'));
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = PAL.P192;
    ctx.fillText(bs.replay.on ? '整局回放可以拖时间轴、WASD 移动视角、滚轮缩放'
                              : '（这一局太短，没录到回放）', W/2, H - 118);
  }
  ctx.restore();
}

function drawCaught(){
  /* 红闪 + 逐渐压暗，然后切结算 */
  const el = 0.95 - Math.max(0, caughtT);
  if (caughtFx > 0){
    /* 只用边缘泛红，中间留出来看清人和自己被扑的那一下 */
    const g0 = ctx.createRadialGradient(W/2, H/2, H*0.10, W/2, H/2, H*0.78);
    g0.addColorStop(0, 'rgba(170,15,10,' + (0.10*caughtFx).toFixed(3) + ')');
    g0.addColorStop(0.55, 'rgba(180,18,10,' + (0.30*caughtFx).toFixed(3) + ')');
    g0.addColorStop(1, 'rgba(150,0,0,' + (0.62*caughtFx).toFixed(3) + ')');
    ctx.save();
    ctx.fillStyle = g0; ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }
  const a = clamp((el - 0.45) / 0.5, 0, 1) * 0.62;
  if (a > 0.01){
    const g = ctx.createRadialGradient(W/2, H/2, H*0.18, W/2, H/2, H*0.80);
    g.addColorStop(0, TC(PAL.P7));
    g.addColorStop(1, 'rgba(30,0,0,' + a.toFixed(3) + ')');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }
  ctx.save();
  ctx.textAlign = 'center';
  ctx.font = 'bold 20px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(255,130,110,' + (0.58 + 0.26*Math.sin(el*24)).toFixed(2) + ')';
  ctx.fillText('被抓住了', W/2, H - 64);
  ctx.restore();
}

function drawRunPanic(){
  /* 门一开，整块屏幕边缘开始红着喘 —— 越拖越红 */
  const k = clamp(runT / 8, 0, 1);
  const pulse = 0.5 + 0.5*Math.sin(uiT*4.4);
  const a = (0.26 + 0.20*k) * (0.55 + 0.45*pulse);
  const g = ctx.createRadialGradient(W/2, H/2, H*0.20, W/2, H/2, H*0.94);
  g.addColorStop(0, TC(PAL.P7));
  g.addColorStop(0.52, 'rgba(185,18,10,' + (a*0.42).toFixed(3) + ')');
  g.addColorStop(0.82, 'rgba(175,10,8,' + (a*0.78).toFixed(3) + ')');
  g.addColorStop(1,    'rgba(150,0,0,' + a.toFixed(3) + ')');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}

function drawBossOverlay(){
  const L = cur();
  if (runBannerT > 0){
    const p = clamp(runBannerT/2.6, 0, 1);
    ctx.save();
    ctx.globalAlpha = Math.min(1, p*1.8);
    ctx.textAlign = 'center';
    ctx.font = 'bold ' + Math.round(120 + 40*(1-p)) + 'px "Microsoft YaHei",sans-serif';
    /* 底下是红的，字要是纯红就糊了：白描边 + 辉光，才压得住 */
    ctx.shadowColor = PAL.P244;
    ctx.shadowBlur = 34 + 18*Math.sin(uiT*7);
    ctx.lineWidth = 10;
    ctx.strokeStyle = PAL.P236;
    ctx.strokeText('跑', W/2, H*0.44);
    ctx.shadowBlur = 0;
    ctx.fillStyle = PAL.P197;
    ctx.fillText('跑', W/2, H*0.44);
    ctx.restore();
  }
  if (!exitOpen) return;
  const X = L.extract;
  const cx2 = X.x + X.w/2, cy2 = X.y + X.h/2;
  const a = Math.atan2(cy2 - player.y, cx2 - player.x);
  const d = Math.round(dist(player.x, player.y, cx2, cy2));
  ctx.save();
  ctx.translate(W/2, 84);
  ctx.rotate(a + Math.PI/2);
  const pulse = 0.62 + 0.38*Math.sin(uiT*5);
  ctx.shadowColor = PAL.P8;
  ctx.shadowBlur = 16*pulse;
  ctx.fillStyle = 'rgba(126,240,181,'+pulse.toFixed(3)+')';
  ctx.beginPath(); ctx.moveTo(0,-30); ctx.lineTo(23,14); ctx.lineTo(0,6); ctx.lineTo(-23,14); ctx.closePath(); ctx.fill();
  ctx.shadowBlur = 0;
  ctx.restore();

  ctx.save();
  ctx.textAlign = 'center';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = PAL.P163;
  ctx.fillText('出口 ' + d + ' m', W/2, 136);
  ctx.fillStyle = PAL.P208;
  ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillText('你的坐标已实时暴露', W/2, 158);
  ctx.restore();
}

/* 开发者用的时间加速：只影响"游戏内逻辑"，不影响 uiT（界面动画该多快还多快）。
   用"多跑几遍 update"实现，而不是把 dt 乘大 —— dt 乘大会让碰撞和寻路直接穿墙。 */
let devTimeScale = 1;
const DEV_TIME_STEPS = [1, 2, 4, 8];
function devCycleTime(){
  const i = DEV_TIME_STEPS.indexOf(devTimeScale);
  devTimeScale = DEV_TIME_STEPS[(i + 1) % DEV_TIME_STEPS.length];
  setMsg('时间 ×' + devTimeScale, 1.4);
  logWarn('dev', '时间加速 · ×' + devTimeScale);
  syncTimeBtn();
}
function syncTimeBtn(){
  const b = document.getElementById('btnTime');
  if (b) b.textContent = '时间加速 ×' + devTimeScale;
}

function devBadgeText(){
  /* m34881：指挥层是给测试者用的，没开开发者模式就别露这行字 */
  const _devOn = (typeof CFG !== 'undefined' && CFG && !!CFG.dev);
  const _ord = _devOn && (typeof devOrd !== 'undefined' && devOrd && devOrd.on);
  return '开发者 · K 处决 · J 投放 · I 沙盒' + (CFG.devSandbox ? '（全开）' : '')
    + ' · 指挥' + (_ord ? '(开)' : '(关/F7)')
    + (CFG.devInfAmmo ? ' · 无限弹' : '')
    + (CFG.devInfMed ? ' · 无限药' : '')
    + (CFG.devNoHealCd ? ' · 秒好' : '')
    + (CFG.heatInf ? ' · 热成像无限' : '')
       + ((function(){ const L = (typeof cur === 'function') ? cur() : null; return (L && L.boss) ? ' · Y 全拉闸' : ''; })())
       + ' · U 透视' + (CFG.xray ? '（开）' : '')
       + ' · P 暂停' + (CFG.devFreeze ? ('（Lv' + (CFG.devFreeze|0) + '）') : '') + ' · Shift+P 时间 ×' + devTimeScale + ' · F1 图鉴' + ' · F2 跳波'
       + ' · C 天气:' + weatherLabel() + ' · B 难度' + ' · H 伤害' + (CFG.devDmg ? '(开)' : '')
       + ' · V 刷物资面板' + '（Shift+V 全套甲 · Ctrl+V 全撒）' + ' · F3 帧率';
}
function drawDevBadge(){
  if (!CFG.dev) return;
  ctx.save();
  ctx.textAlign = 'center';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = PAL.P59;
  ctx.fillText(devBadgeText(), W/2, H - 16);
  ctx.restore();
}

/* 分层的按键提示：只显示"当前这一层真的能用"的键。
   主键没开 → 附属键既不响应也不显示，省得你以为键坏了。 */
function hintLayerText(){
  const _ord = (typeof devOrd !== 'undefined' && devOrd && devOrd.on);
  const _placing = (typeof devPlaceKind !== 'undefined' && !!devPlaceKind);
  if (_placing){
    return '投放：左键放一个 · Shift+左键 吸附 20px 网格 · [ ] 转向 ±15°（Shift ±5°）· 右键退出';
  }
  if (_ord && devOrd.pick){
    return '指挥：左键点目标 · ↑↓←→ 微调坐标（Shift ×10）· [ ] 到达 ' + devOrdSec() + ' 秒 · 中键再点/右键取消';
  }
  if (_ord){
    return '指挥：中键点单位/车 · 左键点目标 · F7 隐藏';
  }
  return '';
}


/* 警报演出：屏幕上方一行大字，告诉玩家敌人正在源源不断地出来 */
function drawRushFx(){
  if (!alarmOn || state !== 'play' || mapOpen) return;
  const pulse = 0.5 + 0.5 * Math.sin(uiT * 2.6);
  const alpha = 0.72 + 0.28 * pulse;
  const cy = H * 0.155;

  ctx.save();
  const g = ctx.createLinearGradient(0, cy - 62, 0, cy + 62);
  g.addColorStop(0, 'rgba(20,0,0,0)');
  g.addColorStop(0.5, 'rgba(20,0,0,0.42)');
  g.addColorStop(1, 'rgba(20,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, cy - 62, W, 124);

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  /* 小字：· 警 报 · */
  ctx.font = '700 18px system-ui,"Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(255,122,102,' + alpha + ')';
  ctx.fillText('·  警   报  ·', W / 2, cy - 34);

  /* 大字：敌人的支援正源源不断地赶来 */
  ctx.font = '900 46px system-ui,"Microsoft YaHei",sans-serif';
  ctx.shadowColor = 'rgba(255,40,24,' + (0.62 * alpha) + ')';
  ctx.shadowBlur = 26 + 16 * pulse;
  ctx.fillStyle = 'rgba(255,96,74,' + alpha + ')';
  ctx.fillText('敌人的支援正源源不断地赶来', W / 2, cy + 12);
  ctx.shadowBlur = 0;
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = 'rgba(255,198,182,' + (0.42 * alpha) + ')';
  ctx.strokeText('敌人的支援正源源不断地赶来', W / 2, cy + 12);
  ctx.restore();
}

/* 人物状态面板（E）—— 只读，随时能看：左边护甲+主武器，中间随身物资，右边备弹。
   全部纯代码画（圆角矩形 + 小图标），半透明黑底，不暂停、不吃输入。 */
function statusIcon(kind, x, y, s, col){
  ctx.save();
  ctx.translate(x, y);
  ctx.strokeStyle = col; ctx.fillStyle = col;
  ctx.lineWidth = 1.6;
  if (kind === 'medSmall' || kind === 'medBig'){
    /* 医疗：圆角小箱 + 十字 */
    const w = s * 0.9, h = s * 0.72;
    roundRect(-w/2, -h/2, w, h, 2.5); ctx.stroke();
    ctx.lineWidth = 2.2;
    ctx.beginPath(); ctx.moveTo(0, -h*0.28); ctx.lineTo(0, h*0.28); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-w*0.26, 0); ctx.lineTo(w*0.26, 0); ctx.stroke();
  } else if (kind === 'grenade'){
    /* 手雷：圆身 + 顶盖 */
    ctx.beginPath(); ctx.arc(0, s*0.12, s*0.30, 0, TAU); ctx.stroke();
    ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(-s*0.13, -s*0.20); ctx.lineTo(s*0.13, -s*0.20); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, -s*0.20); ctx.lineTo(0, -s*0.36); ctx.stroke();
  } else if (kind === 'smoke'){
    /* 烟雾：细长罐 + 一道口 */
    const w = s * 0.52, h = s * 0.86;
    roundRect(-w/2, -h/2, w, h, 3); ctx.stroke();
    ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(-w*0.26, -h*0.10); ctx.lineTo(w*0.26, -h*0.10); ctx.stroke();
  } else if (kind === 'ammo'){
    /* 弹药：一排子弹头 */
    for (let k = -1; k <= 1; k++){
      ctx.beginPath(); ctx.arc(k * s * 0.26, s*0.06, s*0.12, 0, TAU); ctx.fill();
      ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(k * s * 0.26, -s*0.02); ctx.lineTo(k * s * 0.26, -s*0.26); ctx.stroke();
    }
  } else if (kind === 'armor'){
    /* 护甲：马甲剪影 */
    const w = s * 0.72, h = s * 0.82;
    roundRect(-w/2, -h/2, w, h, 3); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, -h*0.22); ctx.lineTo(0, h*0.30); ctx.stroke();
  }
  ctx.restore();
}
function drawHUDBoss(){
  ctx.save();
  ctx.textAlign = 'left';

  ctx.fillStyle = PAL.P231;
  ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
  ctx.fillText('电闸  ' + swDone + ' / 3', 24, 40);
  for (let i=0;i<3;i++){
    const on = i < swDone;
    ctx.beginPath(); ctx.arc(140 + i*22, 34, 8, 0, TAU);
    ctx.fillStyle = on ? PAL.P1 : PAL.P122;
    ctx.fill();
    ctx.strokeStyle = on ? PAL.P15 : PAL.P166;
    ctx.lineWidth = 1; ctx.stroke();
  }

  ctx.fillStyle = PAL.P13; ctx.fillRect(24,58,236,10);
  ctx.fillStyle = PAL.P133;
  ctx.fillRect(24,58,236,10);
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = PAL.P181;
  ctx.fillText(CFG.dev && CFG.heatInf ? '热成像 · 无限（开发者）' : '热成像 · 这一层没电', 30, 84);

  ctx.fillStyle = PAL.P18;
  ctx.fillText('烟雾', 24, 112);
  const maxShow = Math.max(CFG.grenades, player.grenades);
  for (let i=0;i<maxShow;i++){
    ctx.beginPath(); ctx.arc(62+i*22, 107, 7, 0, TAU);
    ctx.fillStyle = i < player.grenades ? PAL.P4 : PAL.P14;
    ctx.fill();
  }

  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = player.crouchLock ? PAL.P161 : PAL.P3;
  ctx.fillText(player.crouchLock ? '静步锁定 · 拉满三个电闸才能跑' : '锁开了 · 可以跑', 24, 136);
  ctx.fillStyle = PAL.P195;
  ctx.fillText('他在哪，只能靠心跳和脚步判断', 24, 158);

  ctx.textAlign = 'right';
  ctx.font = '13px "Microsoft YaHei",sans-serif';
  if (concealed){
    ctx.fillStyle = PAL.P1;
    ctx.fillText('遮蔽中 · '+concealLeft.toFixed(1)+'s', W-28, 42);
  } else {
    ctx.fillStyle = PAL.P56;
    ctx.fillText('暴露中', W-28, 42);
  }
  ctx.fillStyle = PAL.P148;
  ctx.fillText('猎手 · ' + hunters.length, W-28, 64);

  ctx.textAlign = 'left';
  ctx.fillStyle = PAL.P16;
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText(cur().name + '   ·   M 地图', 24, H-20);

  if (msgT > 0 && msg){
    ctx.globalAlpha = Math.min(1, msgT*1.5);
    ctx.textAlign = 'center';
    ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = PAL.P21;
    ctx.fillText(msg, W/2, H-74);
    ctx.globalAlpha = 1;
  }
  ctx.restore();
}

function drawIntro(){
  const style = intro ? intro.style : 'night';
  const day = (style === 'day');
  const mon = (style === 'monitor');
  ctx.save();

  /* 底色 */
  if (mon){ ctx.fillStyle = '#050a08'; }
  else if (day){ ctx.fillStyle = '#f2efe8'; }
  else { ctx.fillStyle = PAL.P71; }
  ctx.fillRect(0,0,W,H);

  /* 监控风格：扫描线 + 角标 */
  if (mon){
    ctx.fillStyle = 'rgba(120,220,160,0.045)';
    for (let y=0; y<H; y+=4) ctx.fillRect(0, y, W, 1);
    const vg = ctx.createRadialGradient(W/2,H/2,H*0.2,W/2,H/2,H*0.85);
    vg.addColorStop(0,'rgba(0,0,0,0)'); vg.addColorStop(1,'rgba(0,0,0,0.55)');
    ctx.fillStyle = vg; ctx.fillRect(0,0,W,H);
    if (Math.sin(uiT*4) > -0.2){
      ctx.fillStyle = 'rgba(226,60,48,0.9)';
      ctx.beginPath(); ctx.arc(52, 46, 7, 0, TAU); ctx.fill();
    }
    ctx.fillStyle = 'rgba(150,220,180,0.85)';
    ctx.font = '13px "Consolas",monospace'; ctx.textAlign = 'left';
    ctx.fillText('REC  CAM-07  06:41:12', 68, 51);
  }

  ctx.textAlign = 'center';
  const lines = intro ? intro.lines : [];
  const n = intro ? Math.min(intro.i, lines.length) : 0;
  const startY = H/2 - 150;
  for (let i=0;i<n;i++){
    const last = (i === lines.length-1);
    ctx.font = (last ? 'bold 34px' : '26px') + ' "Microsoft YaHei",sans-serif';
    const a = (i === n-1) ? 1 : (day ? 0.72 : 0.55);
    if (mon) ctx.fillStyle = last ? 'rgba(255,120,96,'+a+')' : 'rgba(140,225,180,'+a+')';
    else if (day) ctx.fillStyle = last ? 'rgba(178,58,38,'+a+')' : 'rgba(42,50,60,'+a+')';
    else ctx.fillStyle = last ? 'rgba(232,70,55,'+a+')' : 'rgba(205,222,235,'+a+')';
    ctx.fillText(lines[i], W/2, startY + i*56);
  }

  const extra = intro ? intro.i - lines.length : 0;
  const hints = (intro && intro.hints) || [];
  ctx.font = '16px "Microsoft YaHei",sans-serif';
  for (let h=0; h<hints.length; h++){
    if (extra < h+1) break;
    if (mon) ctx.fillStyle = 'rgba(120,200,160,0.78)';
    else if (day) ctx.fillStyle = 'rgba(90,100,112,0.92)';
    else ctx.fillStyle = (h === 0 ? PAL.P222 : PAL.P160);
    ctx.fillText(hints[h], W/2, startY + lines.length*56 + 26 + h*32);
  }

  if (intro && intro.i >= lines.length + hints.length){
    if (mon) ctx.fillStyle = 'rgba(150,230,190,'+(0.45+0.45*Math.sin(uiT*3))+')';
    else if (day) ctx.fillStyle = 'rgba(60,70,80,'+(0.45+0.45*Math.sin(uiT*3))+')';
    else ctx.fillStyle = 'rgba(220,235,245,'+(0.45+0.45*Math.sin(uiT*3))+')';
    ctx.font = 'bold 18px "Microsoft YaHei",sans-serif';
    ctx.fillText('按任意键开始', W/2, H-96);
  }
  ctx.restore();
}

/* ---------------- 渲染 ---------------- */
const THEME_STATES = {play:1, caught:1, dead:1, replay:1, intro:1, greplay:1};

/* 视野光晕只在小离屏画布上生成：最长边 512px，最多每秒 30 次。
   缓存世界坐标，复用期间不跟随玩家平移，避免旧的遮挡轮廓穿过墙。
   停下来后直接复用；门开关、墙破坏、读档/重开立即失效。 */
/* 新手关地面印的位置缓存：键 = 出生点 + 墙数 + 门数 + 图尺寸 + 文案，
   没变就直接复用上一次算出来的落点（算一次要扫全图的墙）。 */
let markSpotKey = '', markSpotXY = null;
let playerVisionCache = null;
const renderVisibility = new WeakMap();
/* 用户 m16899（#8）：热成像开关会让"看不看得见"的判定整体翻转，
   但 WeakMap 里的缓存既没有 thermal 也没有 epoch，切换那一帧还会拿旧结果。
   加一个 epoch，切换时 +1，等于把整表作废。 */
let renderVisEpoch = 0;
let _lastThermal = false;   /* 上一帧热成像是否开着（切关那帧要清可见度） */
function renderPlayerSees(e){
  if(companionSharedSees(e))return true;
  const L = cur();
  /* 热成像：烟也挡不住（同 playerSees，判定顺序必须一致） */
  if (player && player.thermal) return true;
  if (player && smokeBlocks(player.x, player.y, e.x, e.y)) return false;
  const foggy = L.blind || !!(L.rules && (L.rules.testFog || L.rules.fog)) ||
                (typeof fogVisionOn === 'function' && fogVisionOn()) || arenaEventOn('blackout');
  if (!foggy) return true;
  let v = renderVisibility.get(e);
  if (!v || v.player !== player || v.level !== L || v.walls !== L.walls || v.count !== L.walls.length ||
      v.epoch !== renderVisEpoch ||
      uiT < v.at || uiT - v.at >= 0.1 - 1e-9){
    v = {player, level:L, walls:L.walls, count:L.walls.length, epoch:renderVisEpoch, at:uiT, visible:playerSees(e)};
    renderVisibility.set(e, v);
  }
  return v.visible;
}
function drawCompanions(){
  for(const e of allies){
    if(!cullPt(e.x,e.y,60))continue;
    ctx.save();
    ctx.fillStyle='#233d43';ctx.strokeStyle='#77e8c6';ctx.lineWidth=2;
    ctx.beginPath();ctx.arc(e.x,e.y,e.r,0,TAU);ctx.fill();ctx.stroke();
    drawGunModel(e.x+Math.cos(e.ang)*12,e.y+Math.sin(e.ang)*12,1,e.ang,'#b8d1d9','#27343a',e.wid,{});
    ctx.fillStyle='#17352d';ctx.fillRect(e.x-18,e.y-e.r-12,36,4);
    ctx.fillStyle='#77e8c6';ctx.fillRect(e.x-18,e.y-e.r-12,36*Math.max(0,e.hp/e.maxHp),4);
    ctx.font='11px sans-serif';ctx.textAlign='center';ctx.fillText((e.crouch?'队友·静步':'队友')+' · '+(e.reloading>0?'换弹':e.ammo+'/'+companionReserve(e)),e.x,e.y-e.r-17);
    if(e.barkT>0){ctx.fillStyle='#ffe0a0';ctx.fillText(e.bark,e.x,e.y-e.r-33);}
    ctx.restore();
  }
}

function companionConePath(g,v,ox=0,oy=0,points=v.points,scale=1){
  g.beginPath();g.moveTo(v.x-ox,v.y-oy);
  for(const p of points)g.lineTo(v.x-ox+(p.x-v.x)*scale,v.y-oy+(p.y-v.y)*scale);
  g.closePath();
}
function drawCompanionVision(){
  for(const e of allies){
    if(e.dead||e.hp<=0||!cullPt(e.x,e.y,COMPANION_VISION.range))continue;
    companionVisualCache.set(e,drawActorVision(cur(),e,COMPANION_VISION.range,COMPANION_VISION.half,e.ang,
      companionVisualCache.get(e),0));
  }
}
function companionNightVision(g){
  for(const e of allies)if(!e.dead&&e.hp>0){
    const v=companionVisionShape(e,true);companionConePath(g,v,cam.x,cam.y);
    g.fillStyle='rgba(0,0,0,1)';g.fill();
  }
}

function drawPlayerVision(L){
  /* 观战图里玩家只是摄像机：不给他画视野锥（他也不算这一局的人） */
  if (typeof spectatorViewOn === 'function' && spectatorViewOn(L)) return;
  /* 举着望远镜：光锥收窄、照得更远 —— 跟 playerSees 用的是同一对倍率，看到的就是算到的 */
  playerVisionCache=drawActorVision(L,player,seeRange(L)*binoRangeK(),seeFov(L)*binoFovK()*Math.PI/360,player.aim||0,playerVisionCache,1/30);
}
/* Player and companions share the same soft cone renderer; caches belong to each actor. */
function drawActorVision(L,actor,R,half,aim,c,refreshInterval){
  let doorKey = '';
  for (const d of doors) doorKey += doorSolid(d) ? '1' : '0';
  const invalid = !c || c.player !== actor || c.level !== L || c.walls !== L.walls ||
    c.count !== L.walls.length || c.doorKey !== doorKey || c.R !== R || c.half !== half || uiT < c.at;
  const moved = c && (c.x !== actor.x || c.y !== actor.y || c.aim !== aim);
  /* 光锥现在会被烟截断（烟就是墙），所以烟的位置/半径/存在与否一变就得重画缓存 */
  let smokeKey = '';
  for (const s of smokes){
    if (s.life <= 0) continue;
    smokeKey += (s.byEnemy ? 'e' : 'p') + Math.round(s.x) + ',' + Math.round(s.y) + ','
              + Math.round(s.r * Math.min(1, s.age/0.5)) + ';';
  }
  const smokeDirty = c && c.smokeKey !== smokeKey;
  if (invalid || smokeDirty || (moved && uiT - c.at >= refreshInterval - 1e-9)){
    if (!c){
      const canvas = document.createElement('canvas');
      c = {canvas, ctx:canvas.getContext('2d')};
    }
    const size = Math.ceil(2*(R+48)), pixels = Math.min(512, Math.ceil(size/4)), scale = pixels/size;
    if (c.canvas.width !== pixels || c.canvas.height !== pixels){ c.canvas.width = pixels; c.canvas.height = pixels; }
    const g = c.ctx, center = size/2;
    g.setTransform(1,0,0,1,0,0); g.clearRect(0,0,pixels,pixels);
    g.save(); g.scale(scale,scale);
    const wedge = (hh, rad, pad)=>{
      g.beginPath(); g.moveTo(center,center);
      for (let i=0;i<=40;i++){
        const a = aim-hh-pad+(2*hh+2*pad)*i/40;
        let len = rayToWall(actor.x,actor.y,a,rad,true,false,true);
        const _tkP = rayToTruck(actor.x, actor.y, a, rad); if (_tkP < len) len = _tkP;
        /* 烟也是墙：光锥在烟面上就停住，玩家一眼看出「这边被挡住了」 */
        const _sc = raySmokeCut(actor.x, actor.y, a, len, combatFaction(actor) !== 'player');
        if (_sc < len) len = _sc;
        g.lineTo(center+Math.cos(a)*len,center+Math.sin(a)*len);
      }
      g.closePath();
    };
    g.filter = 'blur('+(14*scale)+'px)';
    /* 外圈留一点"软边"，但不能是固定 10°：望远镜把光锥收到 30° 附近时，
       固定加 10° 等于把锥角又撑大一半，看出去就是一大片扇形。
       改成按锥角比例（最多 10°）留边，窄锥才真的窄。 */
    wedge(half, R, Math.min(10 * Math.PI / 180, half * 0.25));
    const outer = g.createRadialGradient(center,center,R*0.05,center,center,R*1.02);
    outer.addColorStop(0,'rgba(158,204,250,0.16)');
    outer.addColorStop(0.5,'rgba(148,196,244,0.10)');
    outer.addColorStop(0.82,'rgba(140,188,238,0.04)');
    outer.addColorStop(1,'rgba(140,188,238,0)');
    g.fillStyle = outer; g.fill(); g.filter = 'none';
    wedge(half*0.86,R*0.55,4*Math.PI/180);
    const inner = g.createRadialGradient(center,center,R*0.03,center,center,R*0.58);
    inner.addColorStop(0,'rgba(172,216,255,0.075)'); inner.addColorStop(1,'rgba(172,216,255,0)');
    g.fillStyle = inner; g.fill();
    /* 视野里压着敌人的烟：把那一块光锥调暗，玩家才知道「这边看不见了」 */
    const _esm = [];
    for (const s of smokes){ if (s.byEnemy && s.life > 0) _esm.push(s); }
    if (_esm.length){
      g.save();
      wedge(half, R, 6*Math.PI/180); g.clip();
      for (const s of _esm){
        const rr = s.r * Math.min(1, s.age/0.5) * 1.04;
        if (rr < 1) continue;
        const sx = center + (s.x - actor.x), sy = center + (s.y - actor.y);
        const gg = g.createRadialGradient(sx, sy, rr*0.25, sx, sy, rr);
        gg.addColorStop(0, 'rgba(9,11,15,0.55)');
        gg.addColorStop(0.7, 'rgba(9,11,15,0.36)');
        gg.addColorStop(1, 'rgba(9,11,15,0)');
        g.fillStyle = gg;
        g.beginPath(); g.arc(sx, sy, rr, 0, TAU); g.fill();
      }
      g.restore();
    }
    g.restore();
    Object.assign(c,{player:actor,level:L,walls:L.walls,count:L.walls.length,doorKey,R,half,aim,
      smokeKey, x:actor.x,y:actor.y,at:uiT,size});
  }
  ctx.drawImage(c.canvas,c.x-c.size/2,c.y-c.size/2,c.size,c.size);
  return c;
}

/* 敌人视野锥的 soft 画风：把扇形烘到一张低分辨率离屏图。
   放回主角画布时放大插值 = 免费羽化，观感和玩家光锥（drawActorVision 的 blur 小图）同路；
   形状仍然用同一份射线顶点，射程/角度/被墙截断的位置一个像素都不改。 */
function coneBake(cc, visR, sees, RAYS){
  /* 分辨率别抠太狠：/3 的时候放大插值会把硬边摊成一格一格，看着像马赛克（用户 m41260）。
     现在按 ~0.75 倍视距烘，再在**小画布上**加一点 blur —— 小画布上 2px 的模糊，放大后
     就是 6~8px 的柔和过渡，而且只在 30Hz 重算时跑一次，不吃每帧预算。 */
  const px = Math.max(96, Math.min(340, Math.round(visR * 0.75)));
  let cv = cc.cv;
  /* 换关 / 读档之后 cc 可能是从存档还原出来的普通对象（离屏画布存不进 JSON，只会变成 {}）。
     这里连同 g 一起校验，否则 g.setTransform is not a function 会打断整帧渲染。 */
  if (!cv || !cv.c || !cv.g || typeof cv.g.setTransform !== 'function'){
    const cn = document.createElement('canvas');
    cv = cc.cv = { c: cn, g: cn.getContext('2d'), grd: null, gi: null, grdKey: '' };
  }
  if (cv.c.width !== px){ cv.c.width = px; cv.c.height = px; }
  const g = cv.g, size = visR * 2, sc = px / size;
  g.setTransform(1,0,0,1,0,0); g.clearRect(0,0,px,px);
  g.save(); g.scale(sc, sc); g.translate(visR, visR);
  const _blurPx = 2 / sc;
  if ('filter' in g) g.filter = 'blur(' + _blurPx.toFixed(2) + 'px)';
  /* CanvasGradient 也属于绘图资源。敌人移动时几何每两帧会刷新一次，但视距、
     阵营色和离屏尺寸通常不变；把两层渐变跟离屏画布一起复用，避免扫射时
     一边刷怪一边每秒创建数百个渐变，给 GC / GPU 驱动制造尖峰。 */
  const _cgk = px + '|' + Math.round(visR * 10) + '|' + (sees ? 1 : 0) + '|' + (THEME_LIGHT ? 1 : 0);
  if (!cv.grd || cv.grdKey !== _cgk){
    /* 亮主题（第一、二章白天关）不能靠"提亮"画锥：底色接近白，lighten 上去等于没画。
       亮主题改用深色扇形 + source-over；暗主题保持原来的发光画法。 */
    const c0 = THEME_LIGHT ? (sees ? 'rgba(56,72,90,0.20)' : 'rgba(64,82,102,0.15)')
                           : TC(sees ? PAL.P250 : PAL.P43);
    cv.grd = g.createRadialGradient(0,0,6,0,0,visR*0.95);
    cv.grd.addColorStop(0, c0);
    cv.grd.addColorStop(0.45, c0);
    cv.grd.addColorStop(1, 'rgba(0,0,0,0)');
    cv.gi = g.createRadialGradient(0,0,4,0,0,visR*0.6);
    cv.gi.addColorStop(0, THEME_LIGHT ? (sees ? 'rgba(40,54,70,0.16)' : 'rgba(46,60,76,0.12)')
                                     : (sees ? 'rgba(255,244,214,0.21)' : 'rgba(176,200,222,0.19)'));
    cv.gi.addColorStop(1, 'rgba(0,0,0,0)');
    cv.grdKey = _cgk;
  }
  g.beginPath(); g.moveTo(0,0);
  for (let r=0;r<=RAYS;r++) g.lineTo(cc.pts[r*2], cc.pts[r*2+1]);
  g.closePath();
  g.fillStyle = cv.grd; g.fill();
  /* 内芯：跟玩家光锥一样再叠一块更亮的小扇形，形状才"立得住"，
     否则整块都是均匀的雾，看不出锥子边界在哪。 */
  g.beginPath(); g.moveTo(0,0);
  for (let r=0;r<=RAYS;r++) g.lineTo(cc.pts[r*2]*0.58, cc.pts[r*2+1]*0.58);
  g.closePath();
  g.fillStyle = cv.gi; g.fill();
  if ('filter' in g) g.filter = 'none';
  g.restore();
  cc.cvAt = cc.at;
}

/* 按投影到画布上的锥长切换档位，留出滞回区间避免滚轮边界闪烁。 */
function coneDetailNear(e, screenRadius){
  if (typeof e._coneNear !== 'boolean') e._coneNear = screenRadius >= 200;
  else if (e._coneNear ? screenRadius < 180 : screenRadius > 220) e._coneNear = !e._coneNear;
  return e._coneNear;
}
/* 同一片区域有很多锥时，把每只的能量按人数摊薄。叠十只仍接近一只的亮度，
   不再靠 source-over 把画面逐层烧成粉白色。 */
function coneCrowdAlpha(n){ return 1 / (1 + 0.8 * Math.max(0, (n | 0) - 1)); }

/* 地面层：只有网格（底色是屏幕空间的 fillRect，不在地图坐标里） */
function stDrawGround(layer){
  if (player && player.thermal) return;      /* 热成像下没有网格 */
  const x0 = Math.floor(layer.x / 64) * 64, y0 = Math.floor(layer.y / 64) * 64;
  const x1 = layer.x + layer.w, y1 = layer.y + layer.h;
  /* 路：大图的地面参照物（只在关卡数据里写了 roads 的关有），烘进静态层 */
  const _L = (typeof cur === 'function') ? cur() : null;
  if (_L && _L.roads && _L.roads.length){
    for (const r of _L.roads){
      if (r._noDraw) continue;                    /* 蛛网路的占位块，画的是曲线不是方块 */
      if (r.x + r.w < layer.x || r.x > x1 || r.y + r.h < layer.y || r.y > y1) continue;
      ctx.fillStyle = 'rgba(30,35,43,0.95)';
      ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.fillStyle = 'rgba(58,66,78,0.55)';
      if (r.w > r.h){ ctx.fillRect(r.x, r.y, r.w, 2); ctx.fillRect(r.x, r.y + r.h - 2, r.w, 2); }
      else { ctx.fillRect(r.x, r.y, 2, r.h); ctx.fillRect(r.x + r.w - 2, r.y, 2, r.h); }
    }
  }
  /* 蛛网路：一条平滑折线，圆头圆角 —— 没有直角折线 */
  if (false && _L && _L.roadPaths && _L.roadPaths.length){   /* 用户 m13089：道路去掉，不画 */
    for (const rp of _L.roadPaths){
      const ps = rp.pts;
      if (!ps || ps.length < 2) continue;
      let bb0 = 1e9, bb1 = 1e9, bb2 = -1e9, bb3 = -1e9;
      for (const q of ps){
        if (q.x < bb0) bb0 = q.x; if (q.y < bb1) bb1 = q.y;
        if (q.x > bb2) bb2 = q.x; if (q.y > bb3) bb3 = q.y;
      }
      if (bb2 < layer.x - 40 || bb0 > x1 + 40 || bb3 < layer.y - 40 || bb1 > y1 + 40) continue;
      ctx.save();
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = 'rgba(30,35,43,0.95)';
      ctx.lineWidth = rp.w;
      ctx.beginPath();
      ctx.moveTo(ps[0].x, ps[0].y);
      for (let i = 1; i < ps.length - 1; i++){
        const mx = (ps[i].x + ps[i + 1].x) / 2, my = (ps[i].y + ps[i + 1].y) / 2;
        ctx.quadraticCurveTo(ps[i].x, ps[i].y, mx, my);
      }
      ctx.lineTo(ps[ps.length - 1].x, ps[ps.length - 1].y);
      ctx.stroke();
      /* 中间一条浅色车辙，让路看着是"被踩出来的" */
      ctx.strokeStyle = 'rgba(58,66,78,0.45)';
      ctx.lineWidth = Math.max(3, rp.w * 0.12);
      ctx.stroke();
      ctx.restore();
    }
  }
  /* 停机坪：水泥地 + 四个车位的白线（只在写了 dzApron 的关有） */
  if (_L && _L.dzApron){
    const a = _L.dzApron;
    if (!(a.x + a.w < layer.x || a.x > x1 || a.y + a.h < layer.y || a.y > y1)){
      ctx.fillStyle = 'rgba(40,44,52,0.96)';
      ctx.fillRect(a.x, a.y, a.w, a.h);
      ctx.strokeStyle = 'rgba(196,202,212,0.32)'; ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 1; i < 4; i++){
        const px = a.x + (a.w / 4) * i;
        ctx.moveTo(px, a.y + 14); ctx.lineTo(px, a.y + a.h - 14);
      }
      ctx.stroke();
      ctx.strokeRect(a.x + 3, a.y + 3, a.w - 6, a.h - 6);
    }
  }
  /* 一次烘焙要 30 竖 + 22 横，原来每条线各自 beginPath/stroke（52 次状态切换 + 52 次光栅化）。
     合成一条路径一次 stroke：像素一样多，调用少一个数量级。 */
  ctx.strokeStyle = PAL.P66; ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = x0; x < x1; x += 64){ ctx.moveTo(x, layer.y); ctx.lineTo(x, y1); }
  for (let y = y0; y < y1; y += 64){ ctx.moveTo(layer.x, y); ctx.lineTo(x1, y); }
  ctx.stroke();
}

/* 哪些"墙"是每帧都要重画的（不能烘进静态层）：
   - 炮塔：会转、会冒火
   - 战利品箱：开没开 / 搜刮时发抖 / 头上挂着 [E] 提示，全是每帧变化的
   放进静态层的话，箱子打开之后画面还是那个关着的箱子（第 33 轮的 bug）。 */
function isDynamicWall(w){
  return !!(w && (w.mobaCover || w.rocketTurret || w.mgSentry || w.loot || w.decor || (w.brk && w.hitT > 0)
    || w.cov === 'watchtower' || w.cov === 'watchtowerOld'));   /* hitT>0 = 正在白闪；塔要看人站没站在上面切层 */
}

/* 墙层：不动的墙/掩体/木箱/碎墙。炮塔与战利品箱排除（它们每帧会变） */
/* 掩体挨打的白闪：把本体在离屏画一遍，再 source-atop 刷白 —— 白只落在物体轮廓上，
   绝不会出现一个方块底。渐隐由 hitT 线性驱动（0.12 秒）。 */
let _coverFlashPass = false;
const COVER_FLASH_T = 0.12;
function drawCoverFlash(w){
  if (_coverFlashPass) return;
  const fl = Math.max(0, Math.min(1, (w.hitT || 0) / COVER_FLASH_T));
  if (fl <= 0) return;
  if (typeof document === 'undefined' || !document.createElement) return;
  const hi = (w.cov && COVER_DEF[w.cov] && COVER_DEF[w.cov].hi) || 0;
  const bx = Math.floor(w.x - 4), by = Math.floor(w.y - 4);
  const bw = Math.ceil(w.w + 8), bh = Math.ceil(w.h + 8);
  if (bw <= 0 || bh <= 0) return;
  if (!_decorFlashCv || _decorFlashCv.width < bw || _decorFlashCv.height < bh){
    _decorFlashCv = document.createElement('canvas');
    _decorFlashCv.width = Math.max(bw, 256); _decorFlashCv.height = Math.max(bh, 256);
    _decorFlashCtx = _decorFlashCv.getContext('2d');
  }
  const cv = _decorFlashCv, oc = _decorFlashCtx;
  oc.setTransform(1, 0, 0, 1, 0, 0);
  oc.clearRect(0, 0, cv.width, cv.height);
  _coverFlashPass = true;
  withDrawCtx(oc, () => {
    ctx.save();
    ctx.translate(-bx, -by);
    drawCover(w);
    ctx.restore();
  });
  _coverFlashPass = false;
  if (typeof oc.globalCompositeOperation === 'string'){
    oc.globalCompositeOperation = 'source-atop';
    oc.fillStyle = '#fff4e2';
    oc.fillRect(0, 0, cv.width, cv.height);
    oc.globalCompositeOperation = 'source-over';
  }
  const prevA = ctx.globalAlpha;
  ctx.globalAlpha = (typeof prevA === 'number' ? prevA : 1) * fl;
  ctx.drawImage(cv, 0, 0, bw, bh, bx, by, bw, bh);
  ctx.globalAlpha = prevA;
}

/* 白闪中的墙按"它本来是什么"画一遍。
   第 44 轮的血案：这里曾写死 drawBreakWall，木箱一挨打就"变脸"成一块灰墙，
   闪白结束静态层重烘才换回来 —— 绝不能按"墙"统一处理，必须看 cov。 */
function drawFlashingWall(w){
  if (w.cov && w.cov !== 'wall'){ drawCover(w); return; }   /* 木箱/小木箱等掩体 */
  drawBreakWall(w);                                         /* 普通可破坏墙 */
}
function drawWallSurface(w, th){
  if (w.cov && w.cov !== 'wall'){ drawCover(w); return; }   /* 掩体：按类型画 */
  if (w.brk){ drawBreakWall(w); return; }
  if (wallMat(w) === 'metal'){
    /* 铁皮：冷一点的板子 + 一道高光 + 四角铆钉，让人远远就知道这块是铁的 */
    ctx.fillStyle = th ? PAL.P25 : PAL.P24;
    ctx.fillRect(w.x, w.y, w.w, w.h);
    ctx.fillStyle = th ? 'rgba(150,175,200,0.20)' : 'rgba(150,175,200,0.17)';
    ctx.fillRect(w.x + 2, w.y + 2, Math.max(2, w.w * 0.28), Math.max(2, w.h - 4));
    ctx.fillRect(w.x + 2, w.y + 2, Math.max(2, w.w - 4), Math.max(2, w.h * 0.16));
    ctx.strokeStyle = th ? PAL.P27 : PAL.P27;
    ctx.lineWidth = 2; ctx.strokeRect(w.x+1, w.y+1, w.w-2, w.h-2);
    ctx.fillStyle = th ? PAL.P30 : PAL.P27;
    const rv = Math.max(2, Math.min(3.2, Math.min(w.w, w.h) * 0.10));
    const pad = Math.min(w.w, w.h) * 0.5;
    for (const t of [[w.x + pad, w.y + pad], [w.x + w.w - pad, w.y + pad],
                     [w.x + pad, w.y + w.h - pad], [w.x + w.w - pad, w.y + w.h - pad]]){
      ctx.beginPath(); ctx.arc(t[0], t[1], rv, 0, TAU); ctx.fill();
    }
  } else {
    ctx.fillStyle = th ? PAL.P280 : PAL.P22;
    ctx.fillRect(w.x,w.y,w.w,w.h);
    ctx.strokeStyle = th ? PAL.P306 : PAL.P24;
    ctx.lineWidth = 2; ctx.strokeRect(w.x+1,w.y+1,w.w-2,w.h-2);
  }
}

function stDrawWalls(layer){
  const L = cur();                     /* 静态层回调只拿到 layer，关卡自己取 */
  const th = player && player.thermal;
  /* 静态层只覆盖一屏多一点，框外的墙没必要画（4-1 的 79 堵里只有 15 堵在框内，
     原来无条件全遍历，其中 61 堵是逐块描边 + 麻点的可破坏墙）。
     留 40 的余量给描边和挨打白闪；layer 为 null 时不裁（测试直接调这个函数）。 */
  const bx0 = layer ? layer.x - 40 : -Infinity, by0 = layer ? layer.y - 40 : -Infinity;
  const bx1 = layer ? layer.x + layer.w + 40 : Infinity, by1 = layer ? layer.y + layer.h + 40 : Infinity;
  for (const w of L.walls){
    if (w.x + w.w < bx0 || w.x > bx1 || w.y + w.h < by0 || w.y > by1) continue;
    if (isDynamicWall(w)) continue;        /* 炮塔 / 战利品箱：留给每帧那一遍 */
    drawWallSurface(w, th);
  }
}

/* 敌人躲到遮挡物后时，补画同一个表面，不能用通用墙板盖住掩体。 */
function drawEnemyOccludingWalls(L, th){
  if (!humanOn() || !player) return;
  let painted;
  for (const e of enemies){
    if (!eStatusHas(e, 'fear') || !e.hideGoal || companionSharedSees(e)) continue;
    if (!losBlocked(player.x, player.y, e.x, e.y)) continue;
    for (const w of L.walls){
      if (w.decor || w.brk || w.glass || w.dead || painted?.has(w)) continue;
      if (!segHitsRect(player.x, player.y, e.x, e.y, w)) continue;
      if (w.cov === 'watchtower' && (towerSeat === w || towerEnemyOf(w))) drawTowerBase(w, w.hi ?? 64);
      else drawWallSurface(w, th);
      (painted ||= new Set()).add(w);
    }
  }
}

/* 静态层的绘制入口：先地面网格，再墙。两层之间没有任何动态绘制，
   所以合成一张画布是安全的（原来地面、墙各一张，每帧要贴两次）。 */
function dzEdgeFog(){
  /* 用户 m12734：边缘不要一条硬线，改成一圈往里收的浓雾，把视线往中间聚拢 */
  const L = (typeof cur === 'function') ? cur() : null;
  if (!L) return;
  const W = L.w, H = L.h;
  const band = Math.min(W, H) * 0.12;
  const g = ctx;
  g.save();
  let grad = g.createLinearGradient(0, 0, band, 0);
  grad.addColorStop(0, 'rgba(3,5,8,0.98)'); grad.addColorStop(1, 'rgba(3,5,8,0)');
  g.fillStyle = grad; g.fillRect(0, 0, band, H);
  grad = g.createLinearGradient(W, 0, W - band, 0);
  grad.addColorStop(0, 'rgba(3,5,8,0.98)'); grad.addColorStop(1, 'rgba(3,5,8,0)');
  g.fillStyle = grad; g.fillRect(W - band, 0, band, H);
  grad = g.createLinearGradient(0, 0, 0, band);
  grad.addColorStop(0, 'rgba(3,5,8,0.98)'); grad.addColorStop(1, 'rgba(3,5,8,0)');
  g.fillStyle = grad; g.fillRect(0, 0, W, band);
  grad = g.createLinearGradient(0, H, 0, H - band);
  grad.addColorStop(0, 'rgba(3,5,8,0.98)'); grad.addColorStop(1, 'rgba(3,5,8,0)');
  g.fillStyle = grad; g.fillRect(0, H - band, W, band);
  g.restore();
}

function stDrawBase(layer){
  stDrawGround(layer);
  stDrawWalls(layer);
  /* m21503：边缘浓雾是给"暗图"收视线用的（rgba(3,5,8,0.98) 几乎纯黑）。
     白天主题下它会把关卡边界涂成一条黑边 —— 用户报的"边界墙上下黑边"就是它。 */
  if (typeof dzEdgeFog === 'function' && !THEME_LIGHT) dzEdgeFog();
  /* 岛图：地面/墙都画完，再把"陆地之外"整个涂成海，最后补一条岸线。
     顺序很重要 —— 先涂海会盖掉岸边房子的地基，先画海再画墙又会被墙压住岸线。 */
  if (typeof dzDrawSea === 'function') dzDrawSea(ctx);
}

/* ---------------- 敌人视野锥几何缓存 ----------------
   每个敌人每帧要打 25 根射线：rayToWall 把当前关的墙全扫一遍，再叠门、车、烟。
   88 个敌人时这是绘制里最大的一笔（见 交接总结_性能与优化.md 第 4 节 ①）。
   锥子的几何只取决于两件事：「他自己在哪、朝哪」和「世界变没变」，所以：
     · 世界签名一帧只算一次（墙体几何版本 / 门开关 / 车的位置 / 烟的半径），变了当帧全部重算；
     · 每个敌人自己的位姿签名（位置 10px 网格、朝向 1/64 弧度、视距 0.5px）没变就复用顶点表。
   位置取整只是不让站着微动的敌人每帧重算；画的时候按真实坐标平移，
   所以锥子永远挂在人身上，长度误差最多 7px —— 它本来就是半透明晕染。
   换关 / reset 时敌人对象是新的，缓存自然作废；世界签名里还带了关卡标记兜底。 */
let _coneSeq = 0, _coneWkSeq = -1, _coneWkVal = '', _coneLv = null, _coneLvTag = 0;
/* 视野锥位姿缓存最少隔几帧才重算：追人时敌人每帧都在转 1/64 弧度，
   不压频就等于没缓存。世界（墙/门/车/烟）变化不吃这个间隔。 */
let CONE_POSE_GAP = 2;
function coneWorldKey(){
  if (_coneWkSeq === _coneSeq) return _coneWkVal;
  _coneWkSeq = _coneSeq;
  const L = cur();
  if (_coneLv !== L){ _coneLv = L; _coneLvTag++; }
  let s = 'L' + _coneLvTag + '/' + L.walls.length + '/' + wallGeomVer + '/';
  for (let i = 0; i < doors.length; i++) s += doorSolid(doors[i]) ? '1' : '0';
  s += '/';
  for (let i = 0; i < trucks.length; i++){
    const t = trucks[i]; if (!t) continue;
    s += (t.x | 0) + ',' + (t.y | 0) + ',' + (((t.ang || 0) * 100) | 0) + ',' + (t.tstate || '') + ';';
  }
  s += '/';
  for (let i = 0; i < smokes.length; i++){
    const m = smokes[i]; if (!m || m.life <= 0) continue;
    s += (m.byEnemy ? 'e' : 'p') + (m.x | 0) + ',' + (m.y | 0) + ','
       + Math.round(m.r * Math.min(1, m.age / 0.5)) + ';';
  }
  _coneWkVal = s;
  return s;
}

/* m23255：物资可见表（每帧复用，不新建数组） */
const _lootVis = [];

function render(){
  /* m36161：死亡地带加载中，只画加载界面，不画世界也不跑 HUD */
  if (typeof state !== "undefined" && state === "dzload"){
    if (typeof dzLoadPaint === "function") dzLoadPaint();
    return;
  }
  /* 每帧重建按钮表：上一屏留下的按钮绝不能活到这一屏。
     剧情黑屏、胜利/失败这些画面本来就没有按钮，不清就会点到选关卡片上。 */
  uiButtons = [];
  updateCam();
  /* 清波特写：把相机直接搬到刚倒下那个人身上，再整体放大 */
  const _holdK = (ar && ar.cinePending && hitStopT > 0) ? 1 : 0;
  if (_holdK > 0){
    /* 定格开始的第一帧就把镜头定在他身上（存下来），
       之后整个定格期间都用这个固定位置 —— 不能每帧重算，
       否则每一帧都会被 updateCam 重置到玩家身上、再被拉过去 */
    if (!ar.holdCam){
      const hp0 = Math.min(1, Math.max(0, (0.9 - hitStopT) / 0.12));
      const tx0 = ar.cineX - W / 2, ty0 = ar.cineY - H / 2;
      ar.holdCam = { x: cam.x * (1 - hp0) + tx0 * hp0, y: cam.y * (1 - hp0) + ty0 * hp0 };
    }
    cam.x = ar.holdCam.x;
    cam.y = ar.holdCam.y;
    /* 震动只叠在这个固定位置上，不参与任何重置 */
    if (shakeOn){
      const kk2 = Math.max(0, hitStopT / 0.9);
      const amp2 = 8 * kk2 * kk2;
      if (typeof ar.shotAng === 'number'){
        cam.x -= Math.cos(ar.shotAng) * amp2;
        cam.y -= Math.sin(ar.shotAng) * amp2;
      } else {
        cam.y -= amp2;
      }
    }
  }
    /* 定格结束后的特写镜头：按 cineK 权重往尸体上靠 */
  const _cine = (ar && state === 'play' && !_holdK && ar.cineK > 0.001) ? ar.cineK : 0;
  if (_cine > 0){
    cam.x += (ar.cineX - W / 2 - cam.x) * _cine;
    cam.y += (ar.cineY - H / 2 - cam.y) * _cine;
  }
  /* m23103：基础变换跟着"渲染分辨率"走；后面所有 1280×800 的逻辑坐标照旧 */
  ctxScreen();
  ctx.clearRect(0,0,W,H);
  const _shakeAmp = shakeOn && !_holdK ? ((camShake > 0 ? camShake*8 : 0)
           + (hpFx.k3*3.4 + hpFx.k2*0.8) * clamp(tense*1.15, 0, 1)) : 0;
  const sh = _shakeAmp;
  const th = player && player.thermal;
  const L = cur();
  /* 锥子几何缓存的帧边界：一帧只算一次世界签名（见 coneWorldKey） */
  _coneSeq++;
  /* 结算 / 选关 / 主菜单都是深色底，那几屏不能走浅色主题，否则深字压深底 */
  THEME_LIGHT = (L.theme === 'light') && !!THEME_STATES[state];

  /* m21503：白天关卡走到边界时，边界墙外侧会露出画布底色（#0d1218 近黑），
     看起来像"墙上下多了一条黑边"。浅色主题下把底色换成地面同色系的浅灰。 */
  ctx.fillStyle = th ? PAL.P72 : (THEME_LIGHT ? '#e9e7e1' : PAL.P5);
  ctx.fillRect(0,0,W,H);

  /* 开着地图时整屏都被地图盖住，而且游戏是暂停的 —— 先把世界画一遍再盖上去纯属白烧帧。
     大地图上世界绘制要 6~8ms，跳过之后开图能跑满 60 帧。此处在 ctx.save() 之前，直接 return 不会漏保存。 */
  if (mapOpen && state === 'play'){ drawMap(); return; }

  segBegin('世界0');
  ctx.save();
  if (sh) ctx.translate(fxRand(-sh,sh), fxRand(-sh,sh));
  if (punchT > 0){
    /* 镜头被这一枪推了一下：世界往反方向弹开几个像素，再自己弹回来 */
    const kk = (punchT / 0.26) * punchAmp;
    ctx.translate(-punchAX*kk, -punchAY*kk);
  }
  if (zoomP > 0){
    /* 冲击缩放：命中一瞬把画面往里顶 4.5%，比单纯抖更"重" */
    const z = 1 + zoomP*0.045;
    ctx.translate(W/2, H/2); ctx.scale(z, z); ctx.translate(-W/2, -H/2);
  }
  if (_cine > 0){
    /* 近距特写：回归时跟 zoomP 一样绕屏幕中心缩放 */
    const czTarget = (ar.cineZ || 1.35);
    const _pan = Math.min(1, ar.cinePan || 0);
    const cz = 1 + (czTarget - 1) * (_pan * _pan * (3 - 2 * _pan));   /* 从 1 推到目标倍率 */
    ctx.translate(W/2, H/2); ctx.scale(cz, cz); ctx.translate(-W/2, -H/2);
  }
  else if (_holdK > 0){
    /* 定格期间只轻微推近，不抢台词 */
    const _hk = Math.min(1, Math.max(0, (0.9 - hitStopT) / 0.22));
    const zh = 1 + 0.34 * _hk;
    ctx.translate(W/2, H/2); ctx.scale(zh, zh); ctx.translate(-W/2, -H/2);
  }
  if (state === 'caught'){
    /* 特写：以"他和你"为中心放大 */
    ctx.translate(W/2, H/2);
    ctx.scale(caughtZoom, caughtZoom);
    ctx.translate(-caughtFocus.x, -caughtFocus.y);
  } else if (state === 'dead'){
    /* 定格时慢慢拉远到 0.72 倍，把周围一圈人都装进画面 */
    const z2 = 1 - 0.28 * clamp(deadT/0.45, 0, 1);
    ctx.translate(W/2, H/2); ctx.scale(z2, z2); ctx.translate(-player.x, -player.y);
  } else {
    /* 望远镜：以【自己的屏幕位置】为锚点把画面拉远（缩小）——
       绕屏幕中心缩放会把人推到画面边上，绕自己缩放则人和光锥原地不动，
       只是看得见的范围变大（HUD 在 restore 之后再画，不受影响） */
    const _bz = binoZoomK();
    if (Math.abs(_bz - 1) > 0.001){
      const _ax = player.x - cam.x, _ay = player.y - cam.y;
      ctx.translate(_ax, _ay); ctx.scale(_bz, _bz); ctx.translate(-_ax, -_ay);
    }
    /* 观战图缩放（m40173）：绕屏幕中心缩，cam 语义不变，
       越界范围由 cullBegin 反算矩阵自动跟着变 */
    const _cz = (typeof crkZoomK === 'function') ? crkZoomK() : 1;
    if (Math.abs(_cz - 1) > 0.001){
      ctx.translate(W/2, H/2); ctx.scale(_cz, _cz); ctx.translate(-W/2, -H/2);
    }
    /* 上帝模式：缩放（绕屏幕中心，跟斗蛐蛐那个一个写法） */
    const _gz = (typeof godZoomK === 'function') ? godZoomK() : 1;
    if (Math.abs(_gz - 1) > 0.001){
      ctx.translate(W/2, H/2); ctx.scale(_gz, _gz); ctx.translate(-W/2, -H/2);
    }
    ctx.translate(-cam.x, -cam.y);
    /* 清波特写：把刚倒下那个人推到屏幕中间并放大，再慢慢拉回去 */
  }

  /* 从这里开始是"世界坐标"的绘制：先用当前变换矩阵反算可见范围 */
  cullBegin();

  /* 夜里你身上有一圈微光：贴到身边的东西就藏不住了（白天没有这回事） */
  const glowR = (L.rules && L.rules.nightGlow) || 0;
  if (glowR > 0 && !th && player){
    const gg = ctx.createRadialGradient(player.x, player.y, glowR*0.18, player.x, player.y, glowR);
    gg.addColorStop(0, 'rgba(190,215,235,0.13)');
    gg.addColorStop(0.55, 'rgba(160,195,225,0.06)');
    gg.addColorStop(1, 'rgba(140,180,215,0)');
    ctx.fillStyle = gg;
    ctx.beginPath(); ctx.arc(player.x, player.y, glowR, 0, TAU); ctx.fill();
  }

  /* 新手关的地面水印：光靠左下角那行小字，新手根本注意不到要按哪个键。
     关卡可以用 rules.mark 自己指定印什么，没写的就还是第一关那套静步提示 */
  /* 注意：关卡既能写 L.mark（第三关·停电层就是这种），也能写 L.rules.mark（第一关/BOSS 用这种），
     之前只认了 rules.mark，所以停电层那句话永远不会出现。 */
  const _mark = (L.rules && L.rules.noMark) ? null
    : (L.mark || (L.rules && L.rules.mark) ||
       (levelIdx === 0 && !dzLvl ? { big: (CFG.walkToggle ? '按一下 ' : '按住 ') +
                                 keyLabel(BINDS.crouch).toUpperCase(),
                          small: '静 步' } : null));
  /* 2026-11-24：一关想要"两行短句"（停电层：空格开热成像 / 左键丢烟），
     mark.lines 就是给这个用的 —— 等比 big/small 更省字，也不用挤成一长串 */
  const _mLines = (_mark && _mark.lines && _mark.lines.length) ? _mark.lines : null;
  if (state === 'play' && !ar && _mark && !th && player){
    /* 原版实现（2026-11-08 快照）：贴在出生点附近的地面印字，墙会盖住它，符合"印在地上"的感觉。
       m34607：按用户要求恢复成这套；只多支持了 mark.lines（停电层那种两行短句）。 */
    const _ls = (_mark.lines && _mark.lines.length) ? _mark.lines : null;
    const _wm1 = _ls ? _ls[0] : _mark.big;
    const _wm2 = _ls ? (_ls[1] || '') : (_mark.small || '');
    const _wmW = 215, _wmH = 80;
    const _pen = (x, y) => {
      let p = 0;
      for (const w of L.walls.concat(doors)){
        const ox = Math.min(x + _wmW, w.x + w.w) - Math.max(x - _wmW, w.x);
        const oy = Math.min(y + _wmH, w.y + w.h) - Math.max(y - _wmH, w.y);
        if (ox > 0 && oy > 0) p += ox * oy;
      }
      return p;
    };
    const _ox = (L.start ? L.start.x : player.x), _oy = (L.start ? L.start.y : player.y);
    const _L2 = cur();
    let _sx = _ox, _sy = _oy - 170, _bp = Infinity;
    for (let _ring = 1; _ring <= 5 && _bp > 0; _ring++){
      const _rr = _ring * 150;
      for (let _k = 0; _k < 8; _k++){
        const _aa = _k * Math.PI / 4;
        const _cx = _ox + Math.cos(_aa) * _rr;
        const _cy = _oy + Math.sin(_aa) * _rr - 60;
        if (_cx < 240 || _cx > _L2.w - 240 || _cy < 120 || _cy > _L2.h - 120) continue;
        const _p = _pen(_cx, _cy);
        if (_p < _bp){ _bp = _p; _sx = _cx; _sy = _cy; }
        if (_p === 0) break;
      }
    }
    ctx.save();
    ctx.textAlign = 'center';
    /* m34759：白天关卡地面是米白的，白字印上去等于没印 → 浅色主题改成墨色，可见度对齐第一章 */
    const _wmInk = (typeof THEME_LIGHT !== 'undefined' && THEME_LIGHT) ? 'rgba(46,58,72,1)' : 'rgba(226,240,255,1)';
    ctx.globalAlpha = (typeof THEME_LIGHT !== 'undefined' && THEME_LIGHT) ? 0.17 : 0.13;
    ctx.fillStyle = _wmInk;
    ctx.font = 'bold 62px "Microsoft YaHei",sans-serif';
    ctx.fillText(_wm1, _sx, _sy);
    ctx.globalAlpha = (typeof THEME_LIGHT !== 'undefined' && THEME_LIGHT) ? 0.16 : 0.12;
    ctx.font = 'bold 50px "Microsoft YaHei",sans-serif';
    ctx.fillText(_wm2, _sx, _sy + 58);
    ctx.restore();
  }
  if (typeof drawMobaField === 'function') drawMobaField(L);
  segBegin('地面印'); drawScorchMarks();
  /* 斗蛐蛐长廊：两半底色 + 中线 + 两端队标，贴在墙和人的下面 */
  if (typeof drawCricketField === 'function') drawCricketField(L);
  drawBlastRings();          /* 火箭冲击波圈：画出真实杀伤半径 */
  drawDecals();            /* 打碎的残留物：纯贴地装饰，在墙和人的下面 */
  segEnd();
  segBegin('铁丝网'); drawWires(); segEnd();             /* 铁丝网：贴地，在墙和人的下面（人从它上面走过去） */
  segBegin('物资堆'); drawPiles(); segEnd();
  if (typeof drawTraders === 'function') drawTraders();   /* 抽奖商人：站在地上，和敌人一样有影子（但金圈中立） */             /* 物资堆：也是贴地矮堆子，在散件上面、墙下面 */
  drawHotMarks();          /* 铁皮弹着点的余辉 */         /* 地上的爆痕（在血印下面） */
  drawDevMarks();            /* 开发者：BOSS 二次确认的牌子 */
  drawBloodMarks();          /* 地上的血印：贴地画，墙会把它盖住 */
  drawSlamFx();              /* 撞击冲击线，同样在世界层 */

  /* ---- 静态图层：地面与墙一起烘在离屏画布上，这里每帧只贴一次 ---- */
  if (!stLayers.base) stLayers.base = stMake();
  if (_stTh !== th || _stLight !== THEME_LIGHT){ _stTh = th; _stLight = THEME_LIGHT; staticInvalidate(); }
  segEnd();   /* 世界0 */
  segBegin('静态层');
  stSync(stLayers.base, stDrawBase);
  segEnd();
  segBegin('贴图'); stBlit(stLayers.base); segEnd();
  segBegin('世界A');
  /* 炮塔 / 战利品箱是"会变的墙"：留在每帧画，且按屏幕裁剪 */
  for (const w of L.walls){
    if (!isDynamicWall(w)) continue;
    if (w.rocketTurret){ if (cullRect(w.x, w.y, w.w, w.h, 90)) drawRocketTurret(w); }
        else if (w.mgSentry){ if (cullRect(w.x, w.y, w.w, w.h, 70)) drawMgSentry(w); }
    else if (w.dead) continue;
    else if (cullRect(w.x, w.y, w.w, w.h, 90)){
      /* 掩体（塔 / 战利品箱 / 会变的掩体）走 cover 通道；其余可破坏墙走白闪通道。
         塔在 isDynamicWall 里，所以它的地基必须在这里补画，否则只烘一次就再也不画了。 */
      if (w.cov) drawCover(w);
      else if (w.brk) drawFlashingWall(w);
    }
  }
  segBegin('装饰'); drawBrkFx(); drawCorpses();
  /* 装饰物：第 47 轮挪到尸体之后 —— 桌子/瓦罐是立着的家具，不该被躺在地上的尸体盖住 */
  drawDecors(); segEnd();
  /* 第三方单位（运兵车）画在敌人之前：它是"场地物件"，
     不吃敌人的可见性/气泡/血条那一套 */
  for (const t of trucks){ if (cullRect(t.x - t.r - 20, t.y - t.r - 20, t.r * 2 + 40, t.r * 2 + 40, 60)) drawTruck(t); }
  drawMgNests();
  if (ar) drawArenaOrbs();

  const E = L.extract;
  const ready = player && player.loot >= lootTotal;
  const pulse = 0.5 + 0.5*Math.sin(timeAlive*3);
  ctx.save();
  ctx.fillStyle = ready ? 'rgba(60,220,140,'+(0.10+0.10*pulse)+')' : PAL.P302;
  ctx.fillRect(E.x,E.y,E.w,E.h);
  ctx.strokeStyle = ready ? PAL.P67 : PAL.P42;
  ctx.setLineDash([10,7]); ctx.lineWidth = 2;
  ctx.strokeRect(E.x,E.y,E.w,E.h);
  ctx.restore();
  ctx.fillStyle = ready ? PAL.P45 : PAL.P46;
  ctx.font = 'bold 15px "Microsoft YaHei",sans-serif'; ctx.textAlign = 'center';
  ctx.fillText(ready?'撤离点 · 可撤':'撤离点', E.x+E.w/2, E.y+E.h/2+5);

  drawWreckFx();            /* 残骸火：压在车壳上、人和掉落物之下 */
  /* 掉落物分三遍画：光晕 → 影子 → 图标。
     影子必须压在光晕上面：光晕是半透明暖色，先画影子再画光晕会把影子洗掉，
     看起来还是浮着。分三遍也不能合成一遍，否则后一件的影子会糊到前一件图标上。 */
  const canDraw = l => (!l.kind || !!LOOT_KINDS[l.kind]);
  if (!GLOW_LOOT){
    /* 以前这里每件东西一次 shadowBlur=14 的高斯模糊，割草里药掉一地时
       和敌人、经验球叠在一起就是成百次模糊。改成一张共用光晕贴图，
       颜色身份交给图标本身（med 绿十字、ammo 各自的色） */
    GLOW_LOOT = glowSprite('loot', [[0,'rgba(255,244,214,0.5)'],
                                    [0.5,'rgba(255,228,176,0.2)'],
                                    [1,'rgba(255,214,150,0)']], 48);
  }
  segBegin('物资');
  /* m23255：物资的屏幕裁剪以前每帧要算三遍（光圈/影子/图标各一遍）。
     先筛一张小表，后面三遍都只走这张 —— 远处几百件东西每帧就只做一次裁剪判定。 */
  _lootVis.length = 0;
  for (const l of loots){
    if (l.taken || !canDraw(l)) continue;
    if (!cullPt(l.x, l.y, 70)) continue;
    _lootVis.push(l);
  }
  for (const l of _lootVis){
    /* 品质在地上就要看得出来：同一堆东西，紫光那件是稀有 */
    const _q = qualityRollFor(l, l.qBias || 0);
    if (!LOOT_GLOW_Q[_q]){
      const _c = QUALITY_DEF[_q].rgb;
      LOOT_GLOW_Q[_q] = glowSprite('lootq' + _q, [[0, 'rgba(' + _c + ',0.5)'],
                                                  [0.5, 'rgba(' + _c + ',0.2)'],
                                                  [1, 'rgba(' + _c + ',0)']], 48);
    }
    drawGlow(LOOT_GLOW_Q[_q], l.x, l.y, 24 + _q * 7, 0.44 + _q * 0.05);
  }
  for (const l of _lootVis){
    const F = lootFoot(l);
    drawLootShadow(l.x + (F[3] || 0), l.y + F[2], F[0], F[1], F[4] || 0);
  }

  for (const l of _lootVis){
    /* 测试区的弹药箱 / 药品 / 枪：地上就要能一眼分开。
       画法交给 LOOT_KINDS，以后加新物资不用回来改这里。
       l.x / l.y 就是地面坐标，图标不再上下浮动（浮动会让人以为它还漂着） */
    const KS = LOOT_KINDS[l.kind];
    if (hasFeat('loot') && KS && KS.draw){
      KS.draw(l.x, l.y, l);
    } else {
      let fc = th ? PAL.P85 : PAL.P0, glow = th ? PAL.P115 : PAL.P60, size = 9;
      ctx.save();
      ctx.shadowColor = glow;
      ctx.shadowBlur = 16;
      ctx.fillStyle = fc;
      ctx.fillRect(l.x-size, l.y-size, size*2, size*2);
      ctx.restore();
      ctx.strokeStyle = PAL.P110; ctx.lineWidth = 2;
      ctx.strokeRect(l.x-size, l.y-size, size*2, size*2);
    }
    /* 自己刚丢出来的东西：外圈那条弧会随着倒计时缩短，5 秒走完才会被自动捡回去 */
    if (l.autoT > 0){
      const _p = clamp(l.autoT / 5, 0, 1);
      ctx.strokeStyle = 'rgba(255,226,150,0.30)';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(l.x, l.y, 21, -Math.PI/2, -Math.PI/2 + TAU * (1 - _p));
      ctx.stroke();
    }
  }

  /* 手动拾取的提示：够得着的那几件描一圈，最近的一件头上挂个"E 拾取"。
     不自动收以后，必须让人一眼看出"这件现在能捡、按什么捡"。 */
  if (state === 'play' && player && player.hp > 0){
    let nearL = null, nd = 1e9;
    for (const l of loots){
      if (!lootPickable(l)) continue;
      const d = dist(player.x, player.y, l.x, l.y);
      if (d < nd){ nd = d; nearL = l; }
      ctx.strokeStyle = 'rgba(255,226,150,0.42)';
      ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(l.x, l.y, 17, 0, TAU); ctx.stroke();
    }
    if (nearL){
      const bx = nearL.x, by = nearL.y - 30;
      ctx.save();
      ctx.fillStyle = 'rgba(10,16,22,0.74)';
      roundRect(bx - 22, by - 8, 44, 16, 4); ctx.fill();
      ctx.strokeStyle = 'rgba(255,226,150,0.5)'; ctx.lineWidth = 1;
      roundRect(bx - 22, by - 8, 44, 16, 4); ctx.stroke();
      ctx.fillStyle = 'rgba(255,238,190,0.96)';
      ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      if (!window.uiHideAll) ctx.fillText('E 拾取', bx, by + 3);
      ctx.textAlign = 'left';
      ctx.restore();
    }
  }
  segEnd();   /* 物资 */

  /* 烟雾：一大团底雾 + 一圈滚动的小烟团，边缘化开，不再是一个灰球 */
  for (const s of smokes){
    const grow = Math.min(1, s.age/0.5);
    const fade = Math.min(1, s.life/2.5);
    const r = s.r * grow;
    if (r < 1) continue;
    if (!cullPt(s.x, s.y, r + 80)) continue;
    if (!inView(s.x, s.y, r + 80)) continue;
    const _k = (s.byEnemy ? 'e' : 'p') + (th ? 'l' : 'd');
    const _kd = _k + 'd';
    const seed = s.seed || 0;
    /* 1) 暗底：先把体积铺开，边缘完全化掉 */
    drawSmokePuff(_kd, s.x, s.y, r * 0.78, 0.40 * fade);
    /* 2) 主体：明暗交替的一圈烟团，缓慢起伏滚动 —— 这是"冒烟"而不是"一个圆"的关键 */
    const N = 13;
    for (let i = 0; i < N; i++){
      const a = seed + i * TAU / N + Math.sin(uiT * 0.55 + i * 1.7) * 0.34;
      const dd = r * (0.30 + 0.14 * Math.sin(uiT * 0.85 + i * 2.3));
      const px = s.x + Math.cos(a) * dd;
      const py = s.y + Math.sin(a) * dd * 0.92;
      const sz = r * (0.38 + 0.13 * Math.sin(uiT * 1.05 + i * 1.9));
      drawSmokePuff((i % 3 === 1) ? _kd : _k, px, py, sz, 0.32 * fade);
    }
    /* 3) 中心亮一点的两团，让烟有"从中间往外翻"的层次 */
    for (let i = 0; i < 3; i++){
      const a = seed * 1.9 + i * 2.1 + Math.sin(uiT * 0.45 + i) * 0.4;
      drawSmokePuff(_k, s.x + Math.cos(a) * r * 0.22, s.y + Math.sin(a) * r * 0.22,
                    r * (0.30 + 0.06 * Math.sin(uiT * 0.7 + i)), 0.26 * fade);
    }

    ctx.globalAlpha = 1;
  }

  /* 门：两扇滑门，开的时候往两侧缩。
     手开关门（manual）画得更"实"一点：厚钢板 + 把手 + 掉血起凹坑，碎了只剩门框。 */
  for (const d of doors){
    if (!inView(d.x + d.w/2, d.y + d.h/2, 170)) continue;
    const half = d.h/2;
    const slide = d.open * (half * 0.92);
    const hurt = d.maxHp ? clamp(1 - Math.max(0, d.hp) / d.maxHp, 0, 1) : 0;
    if (d.swing){
      /* 平开门：真正的一块薄门板 + 两道门垛。门板厚 9px（以前给到 31，像块砖），
         绕上端那根轴转，转 90° 之后横着伸进屋里。 */
      const th = d.th || Math.max(12, Math.min(d.fw - 10, 40));     /* 门板宽度 */
      const gp = d.gap || 5;
      const len = d.len || (d.fh - 2);                              /* 门板长度 */
      const hx = d.hx != null ? d.hx : d.fx + d.fw * 0.5;
      const hy = d.hy != null ? d.hy : d.fy + 1;                    /* 转轴在上门垛的边沿 */
      if (d.broken){
        /* 碎了：门洞是个黑洞，两边门垛各留一截被砸断的木头茬，地上散几块碎板。
           注意这里**不能**画外框 —— 门都没了，留一圈描边会很假。 */
        const _b = (typeof DOOR_SKIN !== 'undefined' && DOOR_SKIN[d.skin]) || null;
        const bf = _b ? _b.frame : '#31373d';
        const bl = _b ? _b.leaf : (THEME_LIGHT ? '#8a7a5f' : '#5a4c39');
        ctx.fillStyle = 'rgba(10,8,6,0.30)';                           /* 只是地面被熏黑，不是黑洞 */
        ctx.fillRect(d.fx + 2, d.fy + gp, d.fw - 4, d.fh - gp * 2);
        ctx.fillStyle = bf;                                            /* 门垛还在 */
        ctx.fillRect(d.fx, d.fy, d.fw, gp);
        ctx.fillRect(d.fx, d.fy + d.fh - gp, d.fw, gp);
        ctx.fillStyle = bl;                                            /* 门垛上被砸断的木头茬 */
        ctx.fillRect(d.fx + d.fw * 0.18, d.fy + gp + 2, d.fw * 0.20, 4);
        ctx.fillRect(d.fx + d.fw * 0.62, d.fy + d.fh - gp - 6, d.fw * 0.24, 4);
        ctx.fillStyle = 'rgba(12,9,6,0.7)';                            /* 地上两块碎板 */
        ctx.fillRect(d.fx + d.fw * 0.30, d.fy + d.fh * 0.42, d.fw * 0.34, 3);
        ctx.fillRect(d.fx + d.fw * 0.26, d.fy + d.fh * 0.60, d.fw * 0.28, 2.4);
        continue;
      }
      /* 1) 地面：门洞里那条比地砖暗一点的门槛，看得出"这是个口子" */
      const _sk = (typeof DOOR_SKIN !== 'undefined' && DOOR_SKIN[d.skin]) || null;
      const skFrame = _sk ? _sk.frame : '#31373d';
      const skLeaf  = _sk ? _sk.leaf  : (THEME_LIGHT ? '#b6a184' : '#6f6049');
      const skHi    = _sk ? _sk.hi    : 'rgba(236,226,200,0.13)';
      const skLo    = _sk ? _sk.lo    : 'rgba(10,9,7,0.42)';
      ctx.fillStyle = 'rgba(0,0,0,0.22)';
      ctx.fillRect(d.fx + 2, d.fy + gp, d.fw - 4, d.fh - gp * 2);
      /* 2) 门垛：上下两头各一块深灰厚墩子（跨度=门洞宽），门板关上的时候杵在中间 */
      ctx.fillStyle = skFrame;
      ctx.fillRect(d.fx, d.fy, d.fw, gp);
      ctx.fillRect(d.fx, d.fy + d.fh - gp, d.fw, gp);
      ctx.fillStyle = 'rgba(198,212,224,0.10)';                     /* 墩子朝里那条棱 */
      ctx.fillRect(d.fx + 1, d.fy + gp - 0.6, d.fw - 2, 1);
      ctx.fillRect(d.fx + 1, d.fy + d.fh - gp - 0.4, d.fw - 2, 1);
      /* 开合范围的一圈淡淡弧线：一眼就知道这是个能转的门，而不是根棍子 */
      if (d.manual && !d.broken){
        ctx.strokeStyle = 'rgba(210,222,232,0.13)'; ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(hx, hy, len, Math.PI / 2 - d.open * Math.PI / 2, Math.PI / 2);
        ctx.stroke();
      }
      /* 3) 门板：薄薄一条，画在局部坐标 x∈[-th/2, th/2]、y∈[0,len]，转轴在原点 */
      ctx.save();
      ctx.translate(hx, hy);
      ctx.rotate(-d.open * Math.PI / 2);                            /* 关着 0°，开着 -90°（横过来） */
      ctx.fillStyle = 'rgba(0,0,0,0.30)';                           /* 贴着地面的落影 */
      ctx.fillRect(-th / 2 + 1.5, 2, th, len);
      ctx.fillStyle = skLeaf;
      ctx.fillRect(-th / 2, 0, th, len);
      /* 板面：木门是一扇居民户的门（两道凹进去的门芯 + 木纹 + 下压把手），
         铁门还是原来那种几块板拼起来的工业门。 */
      const _isWood = (d.skin === 'wood' || d.skin === 'rust');
      if (_isWood){
        /* 木纹：沿门板长边几道很淡的深浅线，位置由坐标哈希定，同一扇门每帧都一样 */
        for (let k = 0; k < 5; k++){
          const gx = -th / 2 + 2 + covHash(d.fx + k * 23, d.fy + k * 11) * Math.max(1, th - 4);
          ctx.fillStyle = (k % 2) ? 'rgba(30,22,14,0.20)' : 'rgba(226,206,172,0.09)';
          ctx.fillRect(gx, 1, 1, len - 2);
        }
        /* 门芯：上半截一块、下半截一块，凹进去 —— 亮边在上、暗边在下，像真的压花门 */
        const pw = th - 6, px0 = -pw / 2;
        const panels = [[4, len * 0.40], [len * 0.48, len * 0.46]];
        for (const [py, ph] of panels){
          ctx.fillStyle = 'rgba(18,13,8,0.34)';                    /* 凹槽底 */
          ctx.fillRect(px0, py, pw, ph);
          ctx.fillStyle = 'rgba(236,220,190,0.10)';                /* 上沿受光 */
          ctx.fillRect(px0, py, pw, 1);
          ctx.fillStyle = 'rgba(12,9,6,0.42)';                     /* 下沿压暗 */
          ctx.fillRect(px0, py + ph - 1, pw, 1);
          ctx.fillStyle = 'rgba(210,190,156,0.06)';                /* 门芯中间微微凸起 */
          ctx.fillRect(px0 + 1.4, py + 1.6, Math.max(1, pw - 2.8), Math.max(1, ph - 3.2));
        }
        /* 边缘：靠轴那一侧亮、自由端那一侧暗，门板就有厚度了 */
        ctx.fillStyle = skHi;
        ctx.fillRect(-th / 2 + 0.8, 0, Math.max(1.2, th * 0.16), len);
        ctx.fillStyle = skLo;
        ctx.fillRect(th / 2 - Math.max(1.4, th * 0.18), 0, Math.max(1.4, th * 0.18), len);
      } else {
        /* 板面：顺着门板长边走的两道板缝，一道受光一道压暗 —— 看得出是几块板拼的门 */
        ctx.fillStyle = skHi;
        ctx.fillRect(-th / 2 + 1.2, 0, Math.max(1.4, th * 0.20), len);
        ctx.fillStyle = 'rgba(14,11,8,0.40)';
        ctx.fillRect(-th / 2 + th * 0.40, 0, 1.3, len);
        ctx.fillRect(-th / 2 + th * 0.72, 0, 1.3, len);
        ctx.fillStyle = skLo;
        ctx.fillRect(th / 2 - Math.max(1.6, th * 0.16), 0, Math.max(1.6, th * 0.16), len);
      }
      ctx.strokeStyle = 'rgba(8,7,5,0.75)'; ctx.lineWidth = 1.2;
      ctx.strokeRect(-th / 2, 0, th, len);
      /* 掉血：板面上砸凹坑 */
      for (let k = 0; k < 4; k++){
        if (hurt < (k + 1) * 0.22) break;
        const hx2 = -th / 2 + 2 + covHash(d.fx + k * 19, d.fy + k * 13) * Math.max(1, th - 4);
        const hy2 = 6 + covHash(d.fx + k * 7, d.fy + k * 31) * Math.max(1, len - 12);
        ctx.fillStyle = 'rgba(26,22,16,0.55)';
        ctx.beginPath(); ctx.arc(hx2, hy2, 1.2 + covHash(d.fx + k * 3, d.fy + k * 5) * 1.3, 0, TAU); ctx.fill();
      }
      /* 弹孔：子弹穿门留下的洞，跟着门板一起转（存的是世界坐标，画前转回局部） */
      if (d.holes && d.holes.length){
        const _wood = (d.skin === 'wood' || d.skin === 'rust');
        const ca2 = Math.cos(d.open * Math.PI / 2), sa2 = Math.sin(d.open * Math.PI / 2);
        for (const h of d.holes){
          const lx2 = (h.x - hx) * ca2 - (h.y - hy) * sa2;
          const ly2 = (h.x - hx) * sa2 + (h.y - hy) * ca2;
          if (ly2 < -1.5 || ly2 > len + 1.5) continue;
          if (_wood){
            /* 木门：暗色小坑 + 边上崩出来的毛刺 */
            ctx.fillStyle = 'rgba(18,12,8,0.9)';
            ctx.beginPath(); ctx.arc(lx2, ly2, h.r + 0.9, 0, TAU); ctx.fill();
            ctx.fillStyle = 'rgba(96,74,50,0.55)';
            ctx.beginPath(); ctx.arc(lx2, ly2, Math.max(0.4, h.r - 0.3), 0, TAU); ctx.fill();
            ctx.strokeStyle = 'rgba(214,192,156,0.35)'; ctx.lineWidth = 0.7;
            for (let q = 0; q < 2; q++){
              const aa = covHash(h.x + q * 17, h.y + q * 9) * TAU;
              ctx.beginPath();
              ctx.moveTo(lx2 + Math.cos(aa) * h.r, ly2 + Math.sin(aa) * h.r);
              ctx.lineTo(lx2 + Math.cos(aa) * (h.r + 2.2), ly2 + Math.sin(aa) * (h.r + 2.2));
              ctx.stroke();
            }
          } else {
            /* 铁门：贯穿的亮划痕（一条拉长的刮痕 + 一点反光） */
            ctx.fillStyle = 'rgba(8,10,12,0.88)';
            ctx.beginPath(); ctx.arc(lx2, ly2, h.r + 0.7, 0, TAU); ctx.fill();
            ctx.strokeStyle = 'rgba(206,224,238,0.55)'; ctx.lineWidth = 0.8;
            ctx.beginPath();
            ctx.moveTo(lx2 - 1.4, ly2 - 1.4);
            ctx.lineTo(lx2 + 1.6, ly2 + 1.6);
            ctx.stroke();
            ctx.fillStyle = 'rgba(240,250,255,0.35)';
            ctx.beginPath(); ctx.arc(lx2 - 0.4, ly2 - 0.4, Math.max(0.3, h.r - 0.5), 0, TAU); ctx.fill();
          }
        }
        if (d.pierceT > 0 && d.holes.length){
          const h = d.holes[d.holes.length - 1];
          const lx2 = (h.x - hx) * ca2 - (h.y - hy) * sa2;
          const ly2 = (h.x - hx) * sa2 + (h.y - hy) * ca2;
          ctx.fillStyle = 'rgba(255,238,196,' + Math.min(0.6, d.pierceT * 2.8).toFixed(3) + ')';
          ctx.beginPath(); ctx.arc(lx2, ly2, 2.4 + (0.20 - d.pierceT) * 12, 0, TAU); ctx.fill();
        }
      }
      const hy3 = len - 13;
      if (_isWood){
        /* 居民户的门把：一块长圆形的锁面板 + 一根往下压的横杆 + 钥匙孔 */
        ctx.fillStyle = 'rgba(186,170,132,0.92)';
        roundRect(-2.6, hy3 - 7, 5.2, 9.4, 2.0); ctx.fill();
        ctx.fillStyle = 'rgba(24,19,12,0.55)';
        roundRect(-1.7, hy3 - 6.1, 3.4, 7.6, 1.4); ctx.fill();
        ctx.fillStyle = '#dfe4e8';                                  /* 横杆 */
        ctx.fillRect(-0.9, hy3 - 4.2, 6.4, 1.7);
        ctx.fillStyle = 'rgba(30,26,20,0.55)';                      /* 杆下那道影 */
        ctx.fillRect(-0.9, hy3 - 2.5, 6.4, 0.8);
        ctx.fillStyle = '#f4f7fa';                                  /* 杆头一点高光 */
        ctx.fillRect(4.6, hy3 - 4.0, 1.1, 1.3);
        ctx.fillStyle = 'rgba(18,13,9,0.8)';                        /* 钥匙孔 */
        ctx.beginPath(); ctx.arc(0, hy3 + 0.6, 0.85, 0, TAU); ctx.fill();
      } else {
        /* 把手：自由端上那颗银白圆点（门把），旁边一小段短杆 */
        ctx.fillStyle = 'rgba(20,17,12,0.6)';
        ctx.beginPath(); ctx.arc(0, hy3, 2.9, 0, TAU); ctx.fill();
        ctx.fillStyle = '#dae0e6';
        ctx.beginPath(); ctx.arc(0, hy3, 2.1, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.beginPath(); ctx.arc(-0.6, hy3 - 0.6, 0.9, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(206,214,222,0.9)';                    /* 把手短杆 */
        ctx.fillRect(-1, hy3 - 6.5, 2.1, 4.6);
      }
      ctx.restore();
      /* 4) 轴：上端那颗深色铰链铆钉 */
      ctx.fillStyle = 'rgba(12,11,9,0.55)';
      ctx.beginPath(); ctx.arc(hx, hy + 1, 3.4, 0, TAU); ctx.fill();
      ctx.fillStyle = '#8b939b';
      ctx.beginPath(); ctx.arc(hx, hy + 1, 2.2, 0, TAU); ctx.fill();
      /* 锁着的挂锁：锁梁 + 锁体 + 钥匙孔（用万能钥匙开了就消失） */
      if (d.isLocked && !d.unlocked){
        const lx2 = hx, ly2 = hy + len - 1;
        ctx.fillStyle = 'rgba(0,0,0,0.38)';
        ctx.beginPath(); ctx.arc(lx2, ly2 - 0.4, 6.0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(226,190,110,0.98)'; ctx.lineWidth = 1.7;
        ctx.beginPath(); ctx.arc(lx2, ly2 - 3.6, 2.7, Math.PI, TAU); ctx.stroke();
        ctx.fillStyle = 'rgba(214,168,74,0.98)';
        roundRect(lx2 - 3.6, ly2 - 3.8, 7.2, 5.8, 1.1); ctx.fill();
        ctx.fillStyle = 'rgba(96,66,16,0.95)';
        ctx.beginPath(); ctx.arc(lx2, ly2 - 1.4, 0.95, 0, TAU); ctx.fill();
      }
      if (d.hitT > 0){
        ctx.fillStyle = 'rgba(255,238,200,' + (d.hitT * 2.2) + ')';
        ctx.fillRect(d.fx, d.fy, d.fw, d.fh);
      }
      continue;
    }
    if (d.broken){                                                 /* 碎了：只剩门框和焦痕 */
      ctx.fillStyle = 'rgba(10,9,8,0.55)';
      ctx.fillRect(d.x - 3, d.y - 3, d.w + 6, d.h + 6);
      continue;
    }
    /* 老滑门的门框（light 主题下是那条浅蓝灰的框；平开门不用它，自己画门垛）
       放在 swing / broken 之后：碎了的门不能还留一圈亮描边 */
    ctx.fillStyle = PAL.P46;
    ctx.fillRect(d.x - 5, d.y - 5, d.w + 10, d.h + 10);
    const plate = d.manual ? (THEME_LIGHT ? '#8d949c' : '#4a545e')
                           : (THEME_LIGHT ? '#9aa2aa' : '#39434d');
    ctx.fillStyle = plate;
    ctx.fillRect(d.x, d.y, d.w, half - slide);                    /* 上扇 */
    ctx.fillRect(d.x, d.y + half + slide, d.w, half - slide);     /* 下扇 */
    if (d.manual){
      /* 钢板上的两条压筋 + 掉血凹坑，一眼能看出它比自动门结实 */
      ctx.fillStyle = 'rgba(210,222,232,0.10)';
      ctx.fillRect(d.x + 2, d.y + 2, d.w - 4, 1.4);
      ctx.fillRect(d.x + 2, d.y + half + slide + 2, d.w - 4, 1.4);
      for (let k = 0; k < 4; k++){
        if (hurt < (k + 1) * 0.22) break;
        const hx = d.x + 3 + covHash(d.x + k * 17, d.y + k * 11) * (d.w - 6);
        const hy = d.y + 4 + covHash(d.x + k * 7, d.y + k * 29) * (d.h - 8);
        ctx.fillStyle = 'rgba(24,26,30,0.55)';
        ctx.beginPath(); ctx.arc(hx, hy, 1.6 + covHash(d.x + k * 3, d.y + k * 5) * 1.8, 0, TAU); ctx.fill();
      }
      /* 把手：靠近中缝的一小段横杆（关门时在缝边，开门时跟着扇走） */
      ctx.fillStyle = 'rgba(20,22,26,0.85)';
      ctx.fillRect(d.x + d.w * 0.42, d.y + half - slide - 13, d.w * 0.16, 5);
    }
    if (half - slide > 6){
      ctx.strokeStyle = THEME_LIGHT ? 'rgba(40,50,60,0.55)' : 'rgba(0,0,0,0.55)';
      ctx.lineWidth = 2;
      ctx.strokeRect(d.x + 1, d.y + 1, d.w - 2, half - slide - 2);
      ctx.strokeRect(d.x + 1, d.y + half + slide + 1, d.w - 2, half - slide - 2);
    }
    /* 中缝的灯：红=关，绿=开 */
    const lit = (d.open > 0.5);
    const lamp = d.manual
      ? (d.isLocked && !d.unlocked ? 'rgba(230,170,60,0.95)'
                                  : (lit ? 'rgba(60,200,120,0.95)' : 'rgba(220,70,50,0.95)'))
      : (lit ? 'rgba(60,200,120,0.95)' : 'rgba(220,70,50,0.95)');
    ctx.fillStyle = lamp;
    ctx.fillRect(d.x, d.y + half - 4, d.w, 8);
    /* 快关上的时候灯闪 */
    if (!lit && d.open > 0.05 && Math.sin(uiT*18) > 0){
      ctx.fillStyle = 'rgba(255,220,80,0.9)';
      ctx.fillRect(d.x, d.y + half - 4, d.w, 8);
    }
    if (d.hitT > 0){                                              /* 刚挨枪：中缝闪一下白 */
      ctx.fillStyle = 'rgba(255,238,200,' + (d.hitT * 2.2) + ')';
      ctx.fillRect(d.x - 1, d.y - 1, d.w + 2, d.h + 2);
    }
    if (lit){
      ctx.strokeStyle = 'rgba(60,200,120,0.35)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(d.x + d.w/2, d.y + half, 16 + 6*Math.sin(uiT*6), 0, TAU); ctx.stroke();
    }
  }

  /* 脚步波纹 + 静步范围环 */
  for (const rp of stepRipples){
    const p = clamp(rp.t/rp.life, 0, 1);
    const rr = rp.r0 + (rp.r1-rp.r0)*p;
    /* 白底上浅色波纹等于没有：浅色关卡改成墨色/赭色，并加粗一档 */
    const rk = 1-p;
    ctx.strokeStyle = THEME_LIGHT
      ? (rp.crouch ? 'rgba(28,96,150,' + (0.72*rk) + ')' : 'rgba(176,88,18,' + (0.78*rk) + ')')
      : (rp.crouch ? 'rgba(120,200,255,' + (0.45*rk) + ')' : 'rgba(255,190,110,' + (0.45*rk) + ')');
    ctx.lineWidth = THEME_LIGHT ? (rp.crouch ? 2.0 : 2.6) : (rp.crouch ? 1.2 : 1.8);
    ctx.beginPath(); ctx.arc(rp.x, rp.y, rr, 0, TAU); ctx.stroke();
  }
  if (player && state === 'play'){
    /* 雷响时这圈也跟着缩：玩家能直接看到现在传不出去 */
    const nrad = maskedHearR(playerHearR());
    /* m32306：这条圈的透明度交给画质页的「玩家声纹透明度」，0 时整圈不画 */
    const _hra = (typeof hearRingAlphaK === 'function') ? hearRingAlphaK() : 1;
    if (_hra > 0.004){
    ctx.save();
    ctx.globalAlpha = _hra;
    /* m32306：原来站立态用的是 PAL.P220（alpha 只有 0.10），肉眼几乎看不见。
       现在 100% 就是一个"看得见但不碍事"的档位，嫌碍眼往下拖、看不清往上拖。 */
    const _hca = player.crouch ? 0.52 : 0.34;
    ctx.setLineDash([3,9]); ctx.lineWidth = THEME_LIGHT ? 1.7 : 1.2;
    ctx.strokeStyle = THEME_LIGHT
      ? (player.crouch ? 'rgba(28,96,150,' + (_hca + 0.10).toFixed(2) + ')' : 'rgba(176,88,18,' + _hca.toFixed(2) + ')')
      : (player.crouch ? 'rgba(120,205,255,' + (_hca + 0.10).toFixed(2) + ')' : 'rgba(255,190,110,' + _hca.toFixed(2) + ')');
    ctx.beginPath(); ctx.arc(player.x, player.y, nrad, 0, TAU); ctx.stroke();
    ctx.restore();
    }
    if (player.crouch){
      ctx.fillStyle = PAL.P162;
      ctx.font = 'bold 11px "Microsoft YaHei",sans-serif'; ctx.textAlign = 'center';
      ctx.fillText('静步', player.x, player.y - player.r - 12);
    }
  }

  /* 声纹：只画声，不画人 */
  for (const es of enemySteps){
    const p = clamp(es.t/es.life, 0, 1);
    if (es.big){
      /* 拉闸的巨响：一圈扫过整张地图 */
      const R = Math.max(cur().w, cur().h) * 0.85 * p;
      const a = 0.92 * Math.pow(1-p, 1.35);
      ctx.strokeStyle = 'rgba(255,215,140,'+a.toFixed(3)+')';
      ctx.lineWidth = 7 * (1-p) + 1.5;
      ctx.beginPath(); ctx.arc(es.x, es.y, R, 0, TAU); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,180,100,'+(a*0.60).toFixed(3)+')';
      ctx.lineWidth = 4 * (1-p) + 1;
      ctx.beginPath(); ctx.arc(es.x, es.y, R*0.80, 0, TAU); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,150,80,'+(a*0.30).toFixed(3)+')';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(es.x, es.y, R*0.58, 0, TAU); ctx.stroke();
      continue;
    }
    /* 密度参数统一来自 data/ai.js 的 DataSfxFoot：默认 1 圈、扩到 62px 就散 */
    const _FD = (typeof DataSfxFoot !== 'undefined') ? DataSfxFoot : {};
    const rr = (_FD.ringFrom || 11) + ((_FD.ringTo || 62) - (_FD.ringFrom || 11)) * p;
    const col = es.hot ? '255,140,120' : '150,205,255';
    const a0 = (es.hot ? (_FD.alphaHot || 0.42) : (_FD.alphaCold || 0.28)) *
               Math.pow(1 - p, (_FD.fadePow || 1.5));
    const _nr = Math.max(1, Math.min(2, (_FD.rings === undefined ? 1 : _FD.rings)));
    for (let k2=0;k2<_nr;k2++){
      ctx.strokeStyle = 'rgba('+col+','+(a0*(1-k2*0.45)).toFixed(3)+')';
      ctx.lineWidth = 1.7 - k2*0.5;
      ctx.beginPath(); ctx.arc(es.x, es.y, Math.max(3, rr*(1-k2*0.34)), 0, TAU); ctx.stroke();
    }
  }

  /* 你自己的视野范围（画出来，才知道"看得见"是哪一块）。
     只要这一关有"看不见的敌人"，就必须同时把你的锥子画出来，
     不然玩家只知道别人看不见我，不知道自己能看见哪 —— 3-x 就是踩了这个坑。 */
  const _foggy = L.blind || (L.rules && (L.rules.fog || L.rules.testFog)) ||
                 (typeof fogVisionOn === 'function' && fogVisionOn());
  if (_foggy && !th && player && state === 'play'){
    drawPlayerVision(L);
  }

  /* 警报线：走到这里就会被封门，提前给个红色提示 */
  if (L.rules && L.rules.alarmAt && !alarmOn && state === 'play' && !th){
    const _ex = (L.extract && L.extract.x) ? L.extract.x : L.w;
    const _ax = (L.start ? L.start.x : 0) + (_ex - (L.start ? L.start.x : 0)) * L.rules.alarmAt;
    const _pulse = 0.55 + 0.45*Math.sin(uiT * 3.4);
    ctx.save();
    const _wg = ctx.createLinearGradient(_ax - 26, 0, _ax + 26, 0);
    _wg.addColorStop(0, 'rgba(220,40,30,0)');
    _wg.addColorStop(0.5, 'rgba(230,50,36,' + (0.16*_pulse).toFixed(3) + ')');
    _wg.addColorStop(1, 'rgba(220,40,30,0)');
    ctx.fillStyle = _wg;
    ctx.fillRect(_ax - 26, 0, 52, L.h);
    ctx.strokeStyle = 'rgba(255,70,52,' + (0.5*_pulse).toFixed(3) + ')';
    ctx.lineWidth = 2;
    ctx.setLineDash([10, 8]);
    ctx.beginPath(); ctx.moveTo(_ax, 40); ctx.lineTo(_ax, L.h - 40); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(255,120,110,' + (0.55*_pulse).toFixed(3) + ')';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('⚠ 警报线', _ax, Math.max(60, L.h*0.5));
    ctx.restore();
  }

  if (L.boss) drawSwitches(th);
  if (L.boss && hunters.length) drawBoss(th);

  /* 玩家倒地演出：画在敌人之前，这样敌人还能压在他身上 */
  if (deathK > 0.01 && player && (state === 'dead' || state === 'arenaOver')){
    const kk3 = Math.min(1, deathK * 1.5);
    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.fillStyle = 'rgba(16,18,22,' + (0.92 * kk3).toFixed(3) + ')';
    ctx.beginPath(); ctx.ellipse(0, 0, 19 * kk3 + 2, 14 * kk3 + 2, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(112,14,10,' + (0.55 * kk3).toFixed(3) + ')';
    ctx.beginPath(); ctx.ellipse(0, 1, 30 * kk3, 20 * kk3, 0, 0, TAU); ctx.fill();
    ctx.rotate(0.85 * kk3);
    ctx.fillStyle = 'rgba(198,204,214,0.94)';
    ctx.beginPath(); ctx.ellipse(1, 0, 13, 8, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(34,38,46,0.95)'; ctx.lineWidth = 1.6; ctx.stroke();
    if (player.gun && typeof drawGunModel === 'function'){
      drawGunModel(24, 7, 0.72, 1.15, 'rgba(206,212,222,0.95)', 'rgba(28,32,38,0.95)', player.wid);
    }
    ctx.restore();
  }

  drawCompanionVision();
  /* 世界签名一帧只算一次：墙体几何版本 / 门开关 / 车的位置 / 烟的半径 */
  const _coneWk = th ? '' : coneWorldKey();
  /* 260px 空间桶：每只敌人只查周围九格，避免大图 300 怪为了算锥子重叠再做 O(N²)。 */
  const _coneCell = 260, _coneGrid = new Map();
  if (!th) for (const _ce of enemies){
    if (!_ce || _ce.dead || _ce.hp <= 0) continue;
    if (_ce.x < CULL.x0-520 || _ce.x > CULL.x1+520 ||
        _ce.y < CULL.y0-520 || _ce.y > CULL.y1+520) continue;
    const _cx = Math.floor(_ce.x / _coneCell), _cy = Math.floor(_ce.y / _coneCell), _ck = _cx + ',' + _cy;
    _coneGrid.set(_ck, (_coneGrid.get(_ck) || 0) + 1);
  }
  segEnd();   /* 世界A */
  segBegin('敌人');
  /* 用户 m16899（#8）：热成像开着时"看得见"是靠 th 短路出来的，visA 全被推到 1。
     一关机，视线判定立刻变 false，但 visA 还要按 3.2/秒 淡出（约 0.3 秒），
     这 0.3 秒里墙后的敌人仍然整块画出来 —— 就是你看到的"那一瞬间看清了装备"。
     所以切换的那一帧直接把"此刻真的看不见"的人清成 0，不再淡出。 */
  if (_lastThermal && !th){
    renderVisEpoch++;
    for (const e of enemies){ if (!renderPlayerSees(e)) e.visA = 0; }
  }
  _lastThermal = !!th;
  for (const e of enemies){
    ctx.globalAlpha = 1;
    /* 屏幕外一律不画：大地图上一屏只占 1280×800，绝大多数敌人都在画布外。
       **先判裁剪，再算可见度** —— renderPlayerSees() 要打一条射线，
       950 个敌人时这一条顺序之差就是 9ms（全图敌人每帧都白算一遍视线）。 */
    if (!cullPt(e.x, e.y, 140)){
      if (e.visA) { e.visA = Math.max(0, e.visA - lastDt * 3.2); }
      if (e.barkT > 0 && e.bark && !e.dead) barkPush(e, 0.72);
      continue;
    }
    /* 进出视野别"啪"一下：一个 0 到 1 的可见度，进去时渐显、出去时渐隐 */
    const _visNow = th || revealAll || (CFG.dev && CFG.xray) || renderPlayerSees(e);
    if (e.visA === undefined) e.visA = _visNow ? 1 : 0;
    e.visA += (_visNow ? 1 : -1) * lastDt * (_visNow ? 6.5 : 3.2);
    if (e.visA < 0) e.visA = 0; else if (e.visA > 1) e.visA = 1;
    /* 气泡跟着人走 —— 但只要还看得见。看不见的那一刻起就不再更新锚点，
       气泡停在最后一次可见的位置，随时间自己淡掉。 */
    if (_visNow){ e.barkX = e.x; e.barkY = e.y; }
    /* 在别的房间的灰暗里、又没被光锥照到：不画身体，只留声纹（drawShadeCues） */
    if (!th && !revealAll && !(CFG.dev && CFG.xray) && shadeCueHidden(e)) continue;
    /* 完全看不见的那部分不画（锥子也不画，否则等于把位置报给你） */
    if (!th && !_visNow && e.visA <= 0.02){
      /* 夜里的微光：贴到身边的敌人会被照出来（白天 glowR=0，这条永远不生效） */
      const gR = (L.rules && L.rules.nightGlow) || 0;
      const lit = gR > 0 && player && dist(e.x, e.y, player.x, player.y) < gR;
      /* 人看不见，但话是听得见的：气泡会飘出来，等于把那边有人这件事告诉你了 */
      const earR = (L.rules && L.rules.barkEar) || 0;
      if (!lit){
        /* 人在暗处看不见，但嘴里的话听得见：气泡钉在他开口的位置，
           不跟着人走，也不用靠近才亮（远一点只是画淡一些） */
        if (e.barkT > 0 && e.bark && !e.dead){
          const _near = (earR > 0) && (dist(e.x, e.y, player.x, player.y) < earR);
          barkPush(e, _near ? 0.85 : 0.72);
        }
        continue;
      }
    }
    if (!th && e.visA < 0.995) ctx.globalAlpha = e.visA;
    /* 巢母的小兵不做光效：它的「材质」就是巢母那个颜色，见下面的 fillStyle */
    if (th){
      const g = ctx.createRadialGradient(e.x,e.y,2,e.x,e.y,30);
      g.addColorStop(0, TC(PAL.P237));
      g.addColorStop(0.35, TC(PAL.P216));
      g.addColorStop(1, TC(PAL.P243));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(e.x,e.y,30,0,TAU); ctx.fill();
    } else {
      const DT = enemyType(e);
      if (!_visNow && e.visA <= 0.03){
        /* 已经完全淡出的敌人不再画锥子；淡出过程让锥子跟身体一起平滑消失，
           避免玩家在可见距离边缘来回走时整块光锥一帧有、一帧无。 */
      } else {
      /* 视野锥：对着墙打射线截断，扇形会被墙挡住（不再穿墙扫人） */
      segBegin('视野锥');
      const FOV = enemyFovHalf(e, DT)*Math.PI/180;
      const visR = enemyVisionRange(e);
      const _coneNear = coneDetailNear(e,visR*CULL.scale);
      const RAYS = _coneNear ? 24 : 12;
      const _softStyle = CFG.coneStyle !== 'classic';
      /* 几何走缓存：位姿签名没变就复用上一帧的顶点表，只重做一次 fill。
         分两路：世界变了（拆墙/关门/车/烟）当帧就得重算，晚一帧锥子就会穿墙；
         只是位姿在微调（追人时每帧都在转 1/64 弧度）压到 30Hz，和玩家视野光效一个节奏。 */
      const _cA = Number.isFinite(e.coneA) ? e.coneA : e.ang;
      const _coneKey = _coneWk + (e.towerOn ? '|tower|' : '|') + (THEME_LIGHT ? 1 : 0) + '|' + Math.round(FOV * 1000) + '|'
                     + Math.round(visR * 0.5) + '|' + Math.round(_cA * 64) + '|'
                     + Math.round(e.x / 10) + ',' + Math.round(e.y / 10);
      let _cc = e._cone;
      const _worldChanged = !_cc || _cc.wk !== _coneWk || _cc.rays !== RAYS;
      const _poseDirty = !_cc || _cc.key !== _coneKey;
      if (_worldChanged || (_poseDirty && (_coneSeq - _cc.at) >= CONE_POSE_GAP)){
        const pts = (_cc && _cc.pts && _cc.pts.length === (RAYS + 1) * 2) ? _cc.pts : new Array((RAYS + 1) * 2);
        /* 位姿变了只重算顶点，不能把已经分配好的离屏 Canvas 一起丢掉。
           旧代码每次都把 cv 置空，移动中的一名敌人约 30Hz 新建 340×340 Canvas；
           同屏几名敌人就会持续触发纹理分配、GC 和浏览器合成停顿。 */
        const _oldCv = _cc && _cc.cv ? _cc.cv : null;
        /* 长度按「站在 10px 网格上」算，画的时候再加回真实坐标 */
        const ox = e.towerOn ? e.x : Math.round(e.x / 10) * 10, oy = e.towerOn ? e.y : Math.round(e.y / 10) * 10;
        for (let r2=0;r2<=RAYS;r2++){
          const aa = _cA - FOV + (2*FOV)*r2/RAYS;
          let len = rayToWall(ox, oy, aa, visR, !!e.towerOn, false, false, e.towerOn);   /* 无人机飞得过墙，但看不穿墙：货架后面安全 */
          const _tkE = rayToTruck(ox, oy, aa, visR); if (_tkE < len) len = _tkE;
          const sc = raySmokeCut(ox, oy, aa, visR);   /* 烟也是墙：锥子要在烟面上停住 */
          if (sc < len) len = sc;
          pts[r2*2] = Math.cos(aa)*len; pts[r2*2+1] = Math.sin(aa)*len;
        }
        _cc = e._cone = { key: _coneKey, wk: _coneWk, at: _coneSeq, rays:RAYS, pts, grd: null, grdKey: '',
                         cv: _oldCv, cvAt: -1,
                         farSees: 'rgba(255,236,200,0.10)', farBlind: 'rgba(150,180,200,0.07)' };
      }
      /* 只有高清柔光档才准备离屏纹理，远景直接填简化的扇形。 */
      if (_softStyle && _coneNear && _cc.cvAt !== _cc.at) coneBake(_cc, visR, e.sees, RAYS);
      /* 渐变按 (看没看见 / 主题 / 视距) 缓存：createRadialGradient 每个敌人每帧一次也不便宜 */
      const _gk = (e.sees ? '1' : '0') + (THEME_LIGHT ? 'L' : 'D') + Math.round(visR * 0.5);
      /* soft 画风直接贴离屏纹理，不会使用主画布渐变；别在这里白建一个。
         classic 的渐变受创建时的世界变换影响，敌人移动后必须按新位置重建。 */
      if (_coneNear && !_softStyle && (!_cc.grd || _cc.grdKey !== _gk)){
        const grd = ctx.createRadialGradient(0,0,8,0,0,visR*0.92);
        grd.addColorStop(0, TC(e.sees ? PAL.P250 : PAL.P43));
        grd.addColorStop(1, TC(PAL.P69));
        _cc.grd = grd; _cc.grdKey = _gk;
      }
      const _coneOK = !(L.rules && L.rules.nightR) || e.sees ||
                      !player || dist(e.x, e.y, player.x, player.y) < (L.rules.nightR * 2 + 260);
      /* 视野锥分两档：近处全须全尾（渐变 + 描边），远处只留一块纯色扇形。
         描边要把 25 段的路径再走一遍 stroke，贵得离谱；远处的锥子本来就只有几像素高，
         描边和渐变都看不出来，砍掉省一半。 */
      /* 白天关用深色扇形 + 正常叠加；暗夜关继续 lighten 发光，重叠处不会糊成白。 */
      const _coneOp = (typeof THEME_LIGHT !== 'undefined' && THEME_LIGHT) ? 'source-over' : 'lighten';
      if (_coneOK){
        ctx.save();
        ctx.translate(e.x, e.y);
        ctx.beginPath(); ctx.moveTo(0, 0);
        for (let r2=0;r2<=RAYS;r2++) ctx.lineTo(_cc.pts[r2*2], _cc.pts[r2*2+1]);
        ctx.closePath();
        let _crowdN = 0, _ecx = Math.floor(e.x / _coneCell), _ecy = Math.floor(e.y / _coneCell);
        for (let _gx=-1; _gx<=1; _gx++) for (let _gy=-1; _gy<=1; _gy++)
          _crowdN += _coneGrid.get((_ecx+_gx) + ',' + (_ecy+_gy)) || 0;
        const _ca = ((typeof coneAlphaK === 'function') ? coneAlphaK() : 1) * coneCrowdAlpha(_crowdN);
        if (THEME_LIGHT){
          /* 第一、二章是米白地面：暗夜关那套"提亮发光锥"在这种底色上等于没画（用户 m03210 复报）。
             这里直接走一条专用画法——半透明深色扇形 + 虚线边，一眼能看出"他在看哪"。
             曲线仍是同一份射线顶点（被墙/烟截断的位置不变），只是上色方式换了。 */
          ctx.globalAlpha = _ca;
          ctx.globalCompositeOperation = 'source-over';
          ctx.fillStyle = e.sees ? 'rgba(30,44,60,0.22)' : 'rgba(36,50,66,0.15)';
          ctx.fill();
          ctx.globalAlpha = _ca * 0.9;
          ctx.strokeStyle = e.sees ? 'rgba(20,32,46,0.36)' : 'rgba(28,42,58,0.26)';
          ctx.lineWidth = 1.6;
          if (ctx.setLineDash) ctx.setLineDash([7, 5]);
          ctx.stroke();
          if (ctx.setLineDash) ctx.setLineDash([]);
        } else if (_coneNear){
          /* 两套画风（O 键设置里切，CFG.coneStyle）：
             soft   —— 默认。射线顶点之间用二次曲线过渡，看不出 24 段的多边形棱角；
                       填充压低一点，边缘用两层"羽化描边"代替 1px 硬边，像一束光。
             classic—— 老画法：硬边多边形 + 1px 描边，射程/角度/遮挡的边界最清楚。
             两种画法的顶点表、长度、遮挡判定是同一份数据，信息量完全一致。 */
          if (_softStyle){
            /* soft：这块扇形已经烘进一张低分辨率离屏图（coneBake），
               贴回来时放大插值本身就是羽化 —— 和玩家光锥一个观感。 */
            ctx.restore();
            if (_cc.cv && _cc.cvAt === _cc.at){
              /* 放大时用高质量插值：默认的低质量最近邻/双线性会把边缘摊成方块。 */
              const _sm = ctx.imageSmoothingEnabled, _sq = ctx.imageSmoothingQuality;
              ctx.imageSmoothingEnabled = true;
              if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'high';
              const _ga = ctx.globalAlpha, _gc = ctx.globalCompositeOperation;
              ctx.globalAlpha = _ga * _ca;
              /* lighten：重叠的锥子取"较亮的那个"，不会一层层叠出一片白 */
              ctx.globalCompositeOperation = _coneOp;
              ctx.drawImage(_cc.cv.c, e.x - visR, e.y - visR, visR*2, visR*2);
              ctx.globalCompositeOperation = _gc;
              ctx.globalAlpha = _ga;
              ctx.imageSmoothingEnabled = _sm;
              if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = _sq;
            }
            ctx.save();
          } else {
            ctx.save();
            ctx.globalAlpha = _ca;
            ctx.globalCompositeOperation = _coneOp;
            ctx.fillStyle = _cc.grd; ctx.fill();
            ctx.globalCompositeOperation = 'source-over';
            ctx.strokeStyle = e.sees ? PAL.P210 : PAL.P291;
            ctx.lineWidth = 1; ctx.stroke();
            ctx.restore();
          }
        } else {
          ctx.save();
          ctx.globalAlpha = _ca;
          ctx.globalCompositeOperation = _coneOp;
          ctx.fillStyle = e.sees ? _cc.farSees : _cc.farBlind;
          ctx.fill();
          ctx.restore();
        }
        ctx.restore();
      }
      segEnd();
      }

      if (e.muzzle > 0){
        ctx.fillStyle = 'rgba(255,215,120,'+Math.min(1,e.muzzle*7)+')';
        ctx.beginPath(); ctx.arc(e.x+Math.cos(e.ang)*18, e.y+Math.sin(e.ang)*18, 9, 0, TAU); ctx.fill();
      }

      /* 运兵车不在这个循环里了（它是 trucks[] 第三方，见前面的独立绘制） */

      if (DT.kind === 'drone'){
        /* 地上的影子：偏下画一圈，一眼看出"它在天上" */
        ctx.fillStyle = 'rgba(60,72,84,0.16)';
        ctx.beginPath(); ctx.ellipse(e.x, e.y + 15, 15, 6, 0, 0, TAU); ctx.fill();
        ctx.save();
        ctx.translate(e.x, e.y);
        ctx.strokeStyle = e.sees ? PAL.P37 : PAL.P111; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, 0, 10, 0, TAU); ctx.stroke();
        /* 四个旋翼 */
        for (let k = 0; k < 4; k++){
          const ra = e.rot + k*Math.PI/2;
          const rx = Math.cos(ra)*15, ry = Math.sin(ra)*15;
          ctx.fillStyle = PAL.P27;
          ctx.beginPath(); ctx.arc(rx, ry, 3.9, 0, TAU); ctx.fill();
          ctx.strokeStyle = PAL.P30; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(rx,ry); ctx.stroke();
        }
        /* 镜头朝哪边 */
        ctx.strokeStyle = e.sees ? PAL.P37 : PAL.P98; ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.moveTo(0,0);
        ctx.lineTo(Math.cos(e.ang)*15, Math.sin(e.ang)*15); ctx.stroke();
        ctx.restore();
        if (e.pulse > 0){
          ctx.strokeStyle = 'rgba(255,90,70,' + (0.65*e.pulse).toFixed(3) + ')';
          ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.arc(e.x, e.y, 16 + 30*(1-e.pulse), 0, TAU); ctx.stroke();
        }
        if (e.sees){
          ctx.fillStyle = PAL.P37; ctx.font = 'bold 20px sans-serif'; ctx.textAlign = 'center';
          ctx.fillText('!', e.x, e.y-26);
        }
        continue;
      }

      if (DT.static){
        /* 摄像头：一个装在支架上的方盒子 + 镜头 */
        ctx.save();
        ctx.translate(e.x, e.y);
        ctx.fillStyle = PAL.P222;
        ctx.fillRect(-3, 8, 6, 12);                    /* 支架 */
        ctx.fillStyle = e.sees ? PAL.P91 : PAL.P27;
        ctx.fillRect(-9, -8, 18, 15);                   /* 机身 */
        ctx.strokeStyle = PAL.P111; ctx.lineWidth = 1.6;
        ctx.strokeRect(-9, -8, 18, 15);
        ctx.fillStyle = e.sees ? PAL.P37 : PAL.P98;     /* 镜头 */
        ctx.beginPath(); ctx.arc(0, 0, 4.2, 0, TAU); ctx.fill();
        ctx.restore();
        if (e.pulse > 0){
          ctx.strokeStyle = 'rgba(255,90,70,' + (0.65*e.pulse).toFixed(3) + ')';
          ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.arc(e.x, e.y, 14 + 26*(1-e.pulse), 0, TAU); ctx.stroke();
        }
        if (e.sees){
          ctx.fillStyle = PAL.P37; ctx.font = 'bold 20px sans-serif'; ctx.textAlign = 'center';
          ctx.fillText('!', e.x, e.y-22);
        } else if (cur().rules && cur().rules.tutorial){
          ctx.fillStyle = PAL.P21; ctx.font = '12px "Microsoft YaHei",sans-serif'; ctx.textAlign = 'center';
          ctx.fillText('摄像头', e.x, e.y-20);
        }
        continue;   /* 摄像头不画弹匣、不画换弹 */
      }

      if ((e.boostT || 0) > 0){
        /* 被警报喊来的路上：一圈往前拖的橙色尾焰，看得出它比平时快 */
        const k = clamp(e.boostT / 2.2, 0, 1);
        ctx.strokeStyle = 'rgba(255,150,70,' + (0.55*k).toFixed(3) + ')';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(e.x - Math.cos(e.ang)*7, e.y - Math.sin(e.ang)*7,
                e.r + 5 + 3*Math.sin(uiT*14), e.ang + 0.9, e.ang + 2*Math.PI - 0.9);
        ctx.stroke();
      }

      /* 紧急呼叫支援：头顶无线电 + 一圈前摇进度，玩家看得见他要喊人 */
      if ((e.callT || 0) > 0){
        const _cd = backupDef();
        const _pr = clamp(1 - e.callT / Math.max(0.1, _cd.windup || 3), 0, 1);
        const _by = e.y - e.r - 36 + Math.sin(uiT * 9) * 2;
        ctx.save();
        ctx.strokeStyle = 'rgba(255,120,220,0.34)';
        ctx.lineWidth = 2.4;
        ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 9, -Math.PI / 2, -Math.PI / 2 + TAU * _pr); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,158,238,0.96)';
        ctx.lineWidth = 1.8;
        ctx.beginPath(); ctx.moveTo(e.x, _by + 9); ctx.lineTo(e.x, _by - 1); ctx.stroke();
        for (let _wi = 1; _wi <= 2; _wi++){
          ctx.globalAlpha = 0.9 - _wi * 0.28;
          ctx.beginPath();
          ctx.arc(e.x, _by - 1, 3.5 + _wi * 4.4, -Math.PI * 0.78, -Math.PI * 0.22);
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
        if (e.callBark){
          ctx.fillStyle = 'rgba(255,196,244,0.95)';
          ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('呼叫中', e.x, _by - 15);
        }
        ctx.restore();
      }
      /* 雨夜：光圈外、又没闪电的时候，人就该是看不见的。
         只靠遮罩压暗不够 —— 亮色轮廓会隐约透出来，所以这里直接不画。 */
      if (nightDark() && flashK < 0.18 && player){
        const _nd = dist(e.x, e.y, player.x, player.y);
        if (_nd > (L.rules.nightR || 0) + 26 && !companionSharedSees(e)){
          /* 人看不见，但声音听得见：气泡留在原地，位置不跟着人走 */
          if (e.barkT > 0 && e.bark) barkPush(e, 1);
          continue;
        }
      }
      /* 穿甲不等于换一张皮：底色只朝甲色偏 30%，
         「看见你了」的红色/橙色信号必须留着，否则看不出他有没有发现你 */
      const _eArmorT = enemyType(e);
      /* 这一只实际穿的甲（逐只可变），没穿就是 null —— 绘制只认它，不认类型上的写死值 */
      const _eArK = (e.armor && e.armor.kind) || _eArmorT.armorKind || null;
      /* 底色统一走 enemyBodyTint()：
         红色「发现你了」只跟 seesPlayer 走，A/B 互相开火不会被刷成同一种颜色 */
      const _eBase = (typeof enemyBodyTint === 'function') ? enemyBodyTint(e)
        : (e.minionTint ? e.minionTint : (e.sees ? PAL.P91 : (e.mode===1 ? PAL.P92 : PAL.P27)));
      ctx.fillStyle = _eBase;
      /* 远处（>660px）只画"一个人"：一个圆 + 朝向的一道短线。
         这个距离上甲片、枪、状态圈都只有几个像素，画了也看不出来；
         950 敌那次实测里，「敌人」段 7.5ms 有一大半花在这些小点上。 */
      let _eD2 = Infinity, _eDX = 0, _eDY = 0;
      if (player){ _eDX = e.x - player.x; _eDY = e.y - player.y; _eD2 = _eDX * _eDX + _eDY * _eDY; }
      const _eTier = enemyLodTier(_eDX, _eDY);
      /* 中档：300~660 之间只保留"能看出是人、朝哪、手里有什么"，
         势力弧 / 受击圈 / 被黑圈这些状态光效在这个距离只有两三个像素，跳过 */
      const _eNear = _eTier === 0;
      if (player && !e.bossKind && !e.dead){
        if (_eTier === 2){
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.r, 0, TAU);
          ctx.fill();
          ctx.strokeStyle = PAL.P111; ctx.lineWidth = 1.4; ctx.stroke();
          /* 朝向那一侧压一道深色面罩弧：一下就能看出"这是个人、朝那边"，
             比单纯"一个球 + 一根棍"好认得多，成本只有一条 arc */
          ctx.strokeStyle = 'rgba(12,16,22,0.62)';
          ctx.lineWidth = Math.max(1.8, e.r * 0.42);
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.r * 0.62, e.ang - 1.15, e.ang + 1.15);
          ctx.stroke();
          ctx.strokeStyle = e.sees ? PAL.P37 : 'rgba(226,234,242,0.62)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(e.x + Math.cos(e.ang) * e.r * 0.55, e.y + Math.sin(e.ang) * e.r * 0.55);
          ctx.lineTo(e.x + Math.cos(e.ang) * (e.r + 9), e.y + Math.sin(e.ang) * (e.r + 9));
          ctx.stroke();
          continue;
        }
      }
      /* 开枪后坐力：整个人往后一蹭，不只是枪在动 */
      const _bRk = bodyRecoil(e);
      const _bA = (e.angS === undefined ? e.ang : e.angS);
      /* 往后蹭多远，跟着枪的后坐力走：手枪 7、步枪 4、霰弹 52 */
      const _bKick = HUMAN.recLean * (e.wid === 'shotgun' ? 1.8 : e.wid === 'rifle' ? 0.8 : 1);
      ctx.beginPath();
      ctx.arc(e.x - Math.cos(_bA) * _bRk * _bKick, e.y - Math.sin(_bA) * _bRk * _bKick,
              e.r * (1 - _bRk * 0.10), 0, TAU);
      ctx.fill();
      ctx.strokeStyle = PAL.P111; ctx.lineWidth = 2; ctx.stroke();
      /* 中档（不是近档）：补一道深色面罩弧，让"球 + 棍"读起来是"人拿着枪" */
      if (!_eNear && !e.dead){
        ctx.strokeStyle = 'rgba(12,16,22,0.55)';
        ctx.lineWidth = Math.max(2, e.r * 0.40);
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.r * 0.64, _bA - 1.15, _bA + 1.15);
        ctx.stroke();
      }
      /* 势力标识：身下一圈弧 + 头顶一个形状标记。
         颜色、线型、标记形状全部来自 data/factionlook.js：
           A 势力 = 铁蓝实线弧 + 头顶尖角(chevron)
           B 势力 = 琥珀虚线弧 + 头顶圆环(ring)
         光靠颜色在夜关/中枪闪红时不够用，所以再叠一层"形状"差异。 */
      /* 只在"刚踩出声纹"时显示：站着不动的敌人不该挂一圈轮廓（那是透视）。
         可见度与声纹同寿（DataSfxFoot.life）并按剩余时间淡出，观感与室外声纹同步。 */
      const _stepK = (typeof enemyStepRevealK === 'function') ? enemyStepRevealK(e) : 1;
      if (_eNear && _stepK > 0.02 && ((typeof enemyShowsFactionArc === 'function') ? enemyShowsFactionArc(e) : (e.factionTint && !e.dead && !e.dummy))){
        const _lk = (typeof factionLook === 'function') ? factionLook(e.faction) : null;
        const _isB = !!(_lk && _lk.mark === 'ring');
        const _arcCol = (_lk && _lk.arc) || e.factionTint || '#5f8fd8';
        ctx.save();
        ctx.globalAlpha = 0.9 * _stepK;
        ctx.strokeStyle = _arcCol;
        ctx.lineWidth = 2.2;
        if (_isB) ctx.setLineDash([5.2, 3.6]);
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.r + 3.4, 0.10 * Math.PI, 1.20 * Math.PI);
        ctx.stroke();
        ctx.globalAlpha = 0.45 * _stepK;
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.r + 3.4, 1.35 * Math.PI, 1.90 * Math.PI);
        ctx.stroke();
        /* 头顶标记：A 尖角朝上，B 空心圆环 */
        ctx.setLineDash([]);
        ctx.globalAlpha = 0.85 * _stepK;
        const _my = e.y - e.r - 8.2;
        if (_isB){
          ctx.beginPath(); ctx.arc(e.x, _my, 3.1, 0, TAU); ctx.stroke();
        } else {
          ctx.beginPath();
          ctx.moveTo(e.x - 3.4, _my + 2.3);
          ctx.lineTo(e.x, _my - 2.6);
          ctx.lineTo(e.x + 3.4, _my + 2.3);
          ctx.closePath();
          ctx.fillStyle = _arcCol;
          ctx.fill();
        }
        ctx.restore();
      }
      /* 「他看见你了」：一圈红环 + 头顶红点，不再是"整个人刷红"。
         以前整身变红 → A/B 交火时两边都红，分不清谁打谁（用户反馈）。 */
      if (_eNear && !e.dead && typeof enemySeesYou === 'function' && enemySeesYou(e) && !e.dummy){
        ctx.save();
        ctx.globalAlpha = 0.75 + 0.25 * Math.sin((typeof uiT === 'number' ? uiT : 0) * 6.5);
        ctx.strokeStyle = 'rgba(236,64,52,0.95)';
        ctx.lineWidth = 1.7;
        ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 6.6, 0, TAU); ctx.stroke();
        ctx.fillStyle = 'rgba(255,86,72,0.98)';
        ctx.beginPath(); ctx.arc(e.x, e.y - e.r - 10.5, 2.4, 0, TAU); ctx.fill();
        ctx.restore();
      }
      /* 穿甲的敌人：和玩家同一份「甲皮肤」（外圈 + 插板 + 胳膊洞），只是颜色跟着甲走 */
      if (_eArK && e.armor && !e.bossKind && !e.dead){
        const _eAp = clamp(e.armor.hp / Math.max(1, e.armor.maxHp), 0, 1);
        const _eAa = (e.angS === undefined ? e.ang : e.angS);
        drawArmorRing(e.x, e.y, e.r, _eArK, _eAp);
        drawArmorPlate(e.x, e.y, e.r, _eAa, _eArK, _eAp);
      }      /* 刀手：手里那把刀画出来，一眼就区别于带枪的 */
      if (e.type === 'blade'){
        ctx.save();
        ctx.translate(e.x, e.y);
        ctx.rotate(e.ang);
        /* 和玩家手里那把完全一样的弯刀（局部坐标系：原点在人身上，+x 是朝向） */
        drawGunModel(e.r + 9, 0, 0.95, 0, 'rgba(214,222,232,0.96)', PAL.P111, (e.wid === 'dao' ? 'dao' : 'knife'));
        ctx.restore();
      }
      /* 刚挨枪：外面炸开一圈红白，一眼看得出"这个人被打中了" */
      if (_eNear && eStatusHas(e, 'hurt')){
        const hk = Math.min(1, (e.hurtT || 0) / 0.42);
        ctx.save();
        ctx.globalAlpha = hk * 0.9;
        ctx.strokeStyle = 'rgba(255,238,226,0.95)';
        ctx.lineWidth = 2 + 2.4 * hk;
        ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 2 + 7 * (1 - hk), 0, TAU); ctx.stroke();
        ctx.globalAlpha = hk * 0.5;
        ctx.strokeStyle = 'rgba(226,52,36,0.95)';
        ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 6 + 10 * (1 - hk), 0, TAU); ctx.stroke();
        ctx.restore();
      }
      /* 眩晕：脑袋上三颗小星子绕着转 + 一个"晕"字标，远远也看得出这人被震懵了 */
      if ((e.stunT || 0) > 0 && !e.dead){
        const _sMax = Math.max(0.35, e.stunMax || e.stunT);
        const _sk = clamp(e.stunT / _sMax, 0, 1);
        const _cy = e.y - e.r * 0.5;
        ctx.save();
        ctx.globalAlpha = 0.55 + 0.45 * _sk;
        /* 三颗小星子绕着脑袋转 */
        for (let _i = 0; _i < 3; _i++){
          const _a = uiT * 4.2 + _i * TAU / 3;
          const _sx = e.x + Math.cos(_a) * (e.r + 5.5);
          const _sy = _cy + Math.sin(_a) * (e.r + 5.5);
          ctx.fillStyle = 'rgba(255,222,120,0.95)';
          ctx.beginPath(); ctx.arc(_sx, _sy, 1.9, 0, TAU); ctx.fill();
        }
        /* 右侧一个小"晕"标：血条和喊话气泡都在正上方，放在右边不打架 */
        ctx.globalAlpha = 0.55 + 0.45 * _sk;
        ctx.fillStyle = 'rgba(255,214,104,0.96)';
        ctx.font = 'bold 11px "Microsoft YaHei",system-ui,sans-serif';
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(0,0,0,0.9)'; ctx.shadowBlur = 4;
        ctx.fillText('晕', e.x + e.r + 9, e.y - e.r - 10);
        ctx.restore();
      }
      /* \u6d3b\u4eba\u611f\u53ef\u89c6\u5316\uff1a\u7f29\u5934\u7684\u4eba\u53ea\u9732\u4e00\u622a\uff0c\u6123\u795e\u7684\u4eba\u5934\u9876\u5192\u7ea2\u53f9\u53f7 */
      if (humanOn() && (e.spotT || 0) > 0){
        const _k = Math.min(1, e.spotT / HUMAN.spot);
        ctx.save();
        ctx.globalAlpha = 0.55 + 0.45 * _k;
        ctx.fillStyle = 'rgba(255,86,72,0.95)';
        const _bx = e.x, _by = e.y - e.r - 30 - (1 - _k) * 6;
        ctx.shadowColor = 'rgba(0,0,0,0.85)'; ctx.shadowBlur = 3;
        ctx.fillStyle = 'rgba(255,74,60,0.98)';
        ctx.beginPath(); ctx.roundRect
          ? ctx.roundRect(_bx - 2.1, _by - 11, 4.2, 11, 2)
          : ctx.rect(_bx - 2.1, _by - 11, 4.2, 11);
        ctx.fill();
        ctx.beginPath(); ctx.arc(_bx, _by + 3.4, 2.3, 0, TAU); ctx.fill();
        ctx.restore();
      }
      /* \u5e26\u5b9d\u7bb1\u7684\u7279\u6b8a\u76ee\u6807\uff1a\u91d1\u5708 + \u5934\u4e0a\u4e00\u4e2a\u5c0f\u5b9d\u7bb1 */
      if (e.special){
        /* 不画金圈了：整个人身上浮一层淡黄光，远一点也能看出来这个人不一样 */
        const _gp = 0.72 + 0.28 * Math.sin(uiT * 2.6);
        const _gr = e.r * 3.1;
        const _gg = ctx.createRadialGradient(e.x, e.y, e.r * 0.4, e.x, e.y, _gr);
        _gg.addColorStop(0, 'rgba(255,214,120,' + (0.30 * _gp).toFixed(3) + ')');
        _gg.addColorStop(0.55, 'rgba(255,198,88,' + (0.13 * _gp).toFixed(3) + ')');
        _gg.addColorStop(1, 'rgba(255,190,70,0)');
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = _gg;
        ctx.beginPath(); ctx.arc(e.x, e.y, _gr, 0, TAU); ctx.fill();
        ctx.restore();
      }
      /* 督军不是一个模子：身上那圈颜色就是它的打法说明书 */
      if (e.bossKind){
        /* 四种督军四个形状，远远一眼就能分出来是谁 */
        ctx.save();
        ctx.globalAlpha = 0.94;
        const _tint = e.bossTint || '#ff9a5a';
        ctx.strokeStyle = _tint;
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 4, 0, TAU); ctx.stroke();
        ctx.fillStyle = 'rgba(10,14,20,0.88)';
        ctx.strokeStyle = _tint;
        ctx.lineWidth = 2;
        if (e.bossKind === 'warlord'){
          /* 督军：尖顶头盔 + 两侧肩甲 */
          ctx.beginPath();
          ctx.moveTo(e.x, e.y - e.r - 9);
          ctx.lineTo(e.x + e.r * 0.62, e.y - e.r + 1);
          ctx.lineTo(e.x - e.r * 0.62, e.y - e.r + 1);
          ctx.closePath(); ctx.fill(); ctx.stroke();
          for (const sgn of [-1, 1]){
            ctx.beginPath();
            ctx.moveTo(e.x + sgn * (e.r + 1), e.y - 3);
            ctx.lineTo(e.x + sgn * (e.r + 8), e.y - 7);
            ctx.lineTo(e.x + sgn * (e.r + 8), e.y + 5);
            ctx.lineTo(e.x + sgn * (e.r + 1), e.y + 6);
            ctx.closePath(); ctx.fill(); ctx.stroke();
          }
        } else if (e.bossKind === 'charger'){
          /* 疯狗：前倾的箭头，后面拖两根尾巴 */
          ctx.save(); ctx.translate(e.x, e.y); ctx.rotate(e.ang || 0);
          ctx.beginPath();
          ctx.moveTo(e.r + 11, 0);
          ctx.lineTo(-e.r * 0.2, -e.r * 0.66);
          ctx.lineTo(-e.r * 0.2, e.r * 0.66);
          ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(-e.r * 0.2, -e.r * 0.5); ctx.lineTo(-e.r - 9, -e.r * 0.9);
          ctx.moveTo(-e.r * 0.2,  e.r * 0.5); ctx.lineTo(-e.r - 9,  e.r * 0.9);
          ctx.stroke();
          ctx.restore();
        } else if (e.bossKind === 'shield'){
          /* 盾卫：两片厚盾绕身转（相隔 180°，相位 shieldOrbit） */
          const _so = e.shieldOrbit || 0;
          for (const _a of [_so, _so + Math.PI]){
            ctx.save(); ctx.translate(e.x, e.y); ctx.rotate(_a);
            ctx.beginPath();
            ctx.moveTo(e.r + 5, -e.r * 0.95);
            ctx.lineTo(e.r + 12, -e.r * 0.55);
            ctx.lineTo(e.r + 12, e.r * 0.55);
            ctx.lineTo(e.r + 5, e.r * 0.95);
            ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(e.r + 8.5, -e.r * 0.72); ctx.lineTo(e.r + 8.5, e.r * 0.72);
            ctx.stroke();
            ctx.restore();
          }
        }
        /* 疯狗点火：爆炸范围 + 越闪越快的红圈，让玩家知道该跑 */
        if (e.bossKind === 'charger' && e.fuse > 0){
          const p = 1 - e.fuse / (e.fuse0 || 0.95);
          ctx.save();
          ctx.strokeStyle = 'rgba(255,86,72,' + (0.22 + 0.30 * Math.abs(Math.sin(p * 14))).toFixed(3) + ')';
          ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(e.x, e.y, 150, 0, TAU); ctx.stroke();
          ctx.strokeStyle = 'rgba(255,120,110,' + (0.5 + 0.5 * Math.abs(Math.sin(p * 16))).toFixed(3) + ')';
          ctx.lineWidth = 3.2;
          ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 8 + (1 - p) * 16, 0, TAU); ctx.stroke();
          ctx.fillStyle = 'rgba(255,64,54,' + (0.18 + 0.25 * Math.abs(Math.sin(p * 16))).toFixed(3) + ')';
          ctx.beginPath(); ctx.arc(e.x, e.y, e.r * 1.5, 0, TAU); ctx.fill();
          ctx.restore();
        }
        if (e.bossKind === 'charger' && e._dying){
          const k = Math.min(1, e.deathT / CHARGER_DEATH_T);
          const pulse = 0.5 + 0.5 * Math.sin(e.deathT * 42);
          ctx.save();
          ctx.fillStyle = 'rgba(255,150,60,' + (0.10 + 0.30 * k).toFixed(3) + ')';
          ctx.beginPath(); ctx.arc(e.x, e.y, e.r * (1.1 + 0.5 * k), 0, TAU); ctx.fill();
          ctx.strokeStyle = 'rgba(255,240,210,' + (0.35 + 0.55 * pulse).toFixed(3) + ')';
          ctx.lineWidth = 2.4;
          ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 4 + 10 * k, 0, TAU); ctx.stroke();
          ctx.strokeStyle = 'rgba(255,90,70,' + (0.20 + 0.45 * k).toFixed(3) + ')';
          ctx.lineWidth = 3;
          ctx.beginPath(); ctx.arc(e.x, e.y, 150 * (0.35 + 0.65 * k), 0, TAU); ctx.stroke();
          ctx.restore();
        }
        if (false){
        } else if (e.bossKind === 'spawner'){
          /* 巢母：八边形躯体 + 一圈卵囊 */
          ctx.beginPath();
          for (let k = 0; k < 8; k++){
            const aa = k / 8 * TAU + 0.2;
            const rr = e.r * 1.22;
            if (k) ctx.lineTo(e.x + Math.cos(aa) * rr, e.y + Math.sin(aa) * rr);
            else ctx.moveTo(e.x + Math.cos(aa) * rr, e.y + Math.sin(aa) * rr);
          }
          ctx.closePath(); ctx.fill(); ctx.stroke();
          for (let k = 0; k < 4; k++){
            const aa = k / 4 * TAU + 0.5;
            ctx.beginPath();
            ctx.arc(e.x + Math.cos(aa) * (e.r + 6), e.y + Math.sin(aa) * (e.r + 6), e.r * 0.27, 0, TAU);
            ctx.fill(); ctx.stroke();
          }
        }
        ctx.restore();
      }
      /* 黑幕里看不见人，就别让他们在黑幕上漂字——那会直接把位置暴露出来 */
      /* 本来这里还要再按“夜里能不能看见”挡一道，
         结果开透视/热成像时人看得见、嘴去被堵上了。
         能走到这一行就说明人是画出来了，那就该让他说。 */
      if (e.barkT > 0 && e.bark) barkPush(e, 1);
      /* 掏雷警告：头顶一个跳动的"雷"字 + 一圈收拢的进度环，看得见才有得躲 */
      if ((e.throwT || 0) > 0){
        const _TH = (typeof DataTHROW === 'object' && DataTHROW) ? DataTHROW : { windup: 1 };
        const _k = 1 - clamp((e.throwT || 0) / Math.max(0.05, _TH.windup || 1), 0, 1);
        const _by = e.y - (e.r || 12) - 20;
        const _bl = 0.72 + 0.28 * Math.sin(perfT() * 22);
        ctx.save();
        ctx.globalAlpha = _bl;
        ctx.fillStyle = 'rgba(24,18,12,0.72)';
        ctx.beginPath(); ctx.arc(e.x, _by, 10, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(255,178,72,0.95)';
        ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(e.x, _by, 10, 0, TAU); ctx.stroke();
        ctx.fillStyle = 'rgba(255,214,120,0.98)';
        ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('雷', e.x, _by + 0.5);
        ctx.strokeStyle = 'rgba(255,120,80,0.95)';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(e.x, _by, 14, -Math.PI / 2, -Math.PI / 2 + TAU * (1 - _k));
        ctx.stroke();
        ctx.restore();
      }
      if (hasFeat('guns') && e.wid && enemyType(e).canShoot){
        /* 手里真的有枪：枪型跟掉落对得上，远远看一眼就知道该躲什么 */
        const _hum = humanOn();
        /* 后坐力曲线：开枪那一下先往后猛地一顿（0.03s），再慢慢回位 */
        const _age = (e.recMax || 0.18) - (e.recT || 0);
        const _rk = _hum ? (_age <= 0 ? 0 : (_age < 0.03 ? _age / 0.03
                   : Math.max(0, 1 - (_age - 0.03) / 0.15))) : 0;
        const _jit = (_hum && e.tucked && !e.shakeOff && !enemyType(e).calm)
          ? Math.sin(perfT() * HUMAN.shakeHz * 6.283) * HUMAN.shakeAmp : 0;   /* calm：缩在墙后也端得稳 */
        /* 开火那一小窗（muzzle>0）里，枪和枪口焰必须指向**真正开火的方向**：
           angS 是按角速度追的显示角，转身后立刻开枪时会落后几十度，
           于是"子弹从背后飞出来"。平时仍然用 angS，保持平滑转身。 */
        const _ga = ((e.muzzle || 0) > 0 && Number.isFinite(e.ang))
          ? e.ang
          : (e.angS === undefined ? e.ang : e.angS);
        const _gx = e.x + Math.cos(_ga) * (e.r * 0.72 - _rk * 6.2) + Math.cos(_ga + 1.5708) * _jit;
        const _gy = e.y + Math.sin(_ga) * (e.r * 0.72 - _rk * 6.2) + Math.sin(_ga + 1.5708) * _jit;
        /* 口径越大，踢得越狠：霰弹的枪口往上甩一截、枪身缩得更多 */
        const _gK = e.wid === 'shotgun' ? 1.9 : e.wid === 'rifle' ? 0.9 : 1.2;
        if (!e.mgSeat){
          if (_eNear){
            drawGunModel(_gx, _gy,
                     (e.wid === 'shotgun' ? 0.66 : e.wid === 'rifle' ? 0.62 : e.wid === 'rpg' ? 0.86 : 0.58) * (1 - _rk * 0.13 * _gK),
                     _ga - _rk * 0.22 * _gK, 'rgba(214,222,232,0.95)', PAL.P111, e.wid,
                     { warhead: e.wid === 'rpg' && enemyWeaponLoaded(e) });
          } else {
            /* 中远档：枪就是一个短棍。整把枪模型有十几段路径，这个距离上只有一条线宽 */
            const _gl = (e.wid === 'shotgun' || e.wid === 'rifle' || e.wid === 'rpg') ? 15 : 11;
            ctx.strokeStyle = 'rgba(206,214,226,0.78)';
            ctx.lineWidth = (e.wid === 'shotgun' || e.wid === 'rpg') ? 3.4 : 2.6;
            ctx.beginPath();
            ctx.moveTo(_gx, _gy);
            ctx.lineTo(_gx + Math.cos(_ga) * _gl, _gy + Math.sin(_ga) * _gl);
            ctx.stroke();
          }
        }
        /* 枪口焰 + 烟：一下就有了'这一枪放出去了'的重量 */
        if ((e.muzzle || 0) > 0){
          const _mk = Math.max(0, (e.muzzle || 0) / 0.08);
          const _mx = _gx + Math.cos(_ga) * (e.wid === 'shotgun' ? 30 : 24);
          const _my = _gy + Math.sin(_ga) * (e.wid === 'shotgun' ? 30 : 24);
          const _mr = (e.wid === 'shotgun' ? 15 : 9) * (0.55 + _mk * 0.75);
          glowInit();
          drawGlow(GLOW_MUZZLE, _mx, _my, _mr * 2.1, 0.92 * _mk);
          drawGlow(GLOW_SMOKE, _mx - Math.cos(_ga) * 6, _my - Math.sin(_ga) * 6, _mr * 3.4, 0.20 * _mk);
        }
      } else {
        ctx.strokeStyle = e.sees ? PAL.P98 : (e.mode===1 ? PAL.P103 : PAL.P30);
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(e.x,e.y);
        ctx.lineTo(e.x+Math.cos(e.ang)*20, e.y+Math.sin(e.ang)*20); ctx.stroke();
      }

      /* 弹匣剩几发：固定 12 格的比例条，弹匣大的枪不会拖出一长溜小方块。
         颜色是它吃的那种子弹 —— 远远看一眼就知道这人会掉什么弹药。
         同样只在有枪的关卡里画：老关卡的人机"没枪"这件事得保持原样 */
      const eGun = hasFeat('guns') ? gunDef({wid:e.wid}) : null;
      /* 单发武器（火箭筒）装填中：头顶一条细进度条 + "装填"两个字。
         5 秒的装填不告诉玩家"他现在是空的"，玩家会以为自己刚被闪避了。 */
      if (eGun && isSingleShotWeapon(eGun) && (e.reloading || 0) > 0){
        const _rt = Math.max(0.2, enemyReloadTime(e));
        const _pr = Math.max(0, Math.min(1, 1 - (e.reloading || 0) / _rt));
        const _bw = 32, _bx = e.x - _bw / 2, _by = e.y - e.r - 25;   /* 让开头顶血条（血条在 -14） */
        ctx.fillStyle = 'rgba(8,11,15,0.74)';
        ctx.fillRect(_bx - 1, _by - 1, _bw + 2, 6);
        ctx.fillStyle = 'rgba(226,178,84,0.94)';
        ctx.fillRect(_bx, _by, _bw * _pr, 4);
      }
      /* 敌人还剩几发：只给开发者看。正常玩的时候这排小方块纯属干扰 */
      if (eGun && CFG.dev && (eGun.cap | 0) > 0){
        if (isSingleShotWeapon(eGun)){
          /* 单发武器只有"有 / 没有"，画 12 格会让人以为他背了一串火箭弹 */
          const loaded = enemyWeaponLoaded(e);
          ctx.fillStyle = loaded ? ammoDef(eGun.ammo).pal : PAL.P30;
          ctx.fillRect(e.x - 4, e.y + e.r + 5, 8, 4);
          ctx.strokeStyle = 'rgba(0,0,0,0.55)'; ctx.lineWidth = 1;
          ctx.strokeRect(e.x - 4.5, e.y + e.r + 4.5, 9, 5);
        } else {
          const ammoCap = Math.max(1, eGun.cap);
          const ammoN = Math.max(0, Math.min(e.ammo, ammoCap));
          const segs = 12, on = Math.round(segs * ammoN / ammoCap);
          for (let i=0;i<segs;i++){
            ctx.fillStyle = i < on ? ammoDef(eGun.ammo).pal : PAL.P30;
            ctx.fillRect(e.x - segs*2.2 + i*4.4, e.y+e.r+5, 3, 4);
          }
        }
      }

      if (e.fleeing){
        /* 逃跑 / 打药：头顶一个跳动的绿十字，蹲住了再写个"打药"，看得懂它在干什么 */
        const posted = e.healK > 0;
        ctx.save();
        ctx.globalAlpha = 0.55 + 0.35*Math.sin(uiT*9);
        ctx.fillStyle = PAL.P67;
        ctx.fillRect(e.x-1.8, e.y-e.r-17, 3.6, 11);
        ctx.fillRect(e.x-5.5, e.y-e.r-13.2, 11, 3.6);
        ctx.restore();
        ctx.fillStyle = PAL.P45;
        ctx.font = '10px "Microsoft YaHei",sans-serif'; ctx.textAlign = 'center';
        ctx.fillText(posted ? '打药' : '跑', e.x, e.y+e.r+19);
      } else if (e.reloading > 0){
        ctx.fillStyle = PAL.P219;
        ctx.font = '10px sans-serif'; ctx.textAlign = 'center';
        ctx.fillText('换弹…', e.x, e.y-20);
      } else if (e.sees){
        ctx.fillStyle = PAL.P37; ctx.font = 'bold 20px sans-serif'; ctx.textAlign = 'center';
        ctx.fillText('!', e.x, e.y-20);
      } else if (e.mode === 1){
        ctx.fillStyle = PAL.P221; ctx.font = 'bold 13px sans-serif'; ctx.textAlign = 'center';
        ctx.fillText('?', e.x, e.y-20);
      }
    }
  }

  /* 敌人循环里会把 globalAlpha 改成可见度（黑暗里是 0），不收回来的话，
     后面画的东西（曳光、子弹、玩家手里的枪/刀）会跟着一起变透明。 */
  ctx.globalAlpha = 1;
  drawEnemyOccludingWalls(L, th);
  /* 玩家的子弹：一段跟着弹头飞的短光带（曳光弹），不是贯穿全屏的激光 */
  const TRACER_LEN = 30;         /* 拖尾长度（世界像素） */
  for (const t of tracers){
    if (!cullRect(Math.min(t.x0, t.x1), Math.min(t.y0, t.y1),
                  Math.abs(t.x1 - t.x0), Math.abs(t.y1 - t.y0), 90)) continue;
    const p = Math.min(1, t.t / t.dur);
    const _dist = Math.max(1, Math.hypot(t.x1 - t.x0, t.y1 - t.y0));
    /* 尾巴只占 TRACER_LEN 那么长，剩下的地方什么都不画 —— 这是"子弹"，不是光线 */
    const _lenU = Math.min(p, TRACER_LEN / _dist);
    const u0 = Math.max(0, p - _lenU), u1 = p;
    const hx = t.x0 + (t.x1 - t.x0) * p, hy = t.y0 + (t.y1 - t.y0) * p;
    const uH = Math.max(u0, u1 - _lenU * 0.35);      /* 从头往前 35% 是亮头，后面是淡尾 */
    /* 到达终点后再留一小会儿余光（打中的地方会亮），然后彻底消失 */
    const fade = p < 1 ? 1 : Math.max(0, 1 - (t.t - t.dur) / 0.055);
    if (fade <= 0) continue;

    /* 穿门那一发在门的位置断成两截：门后那段掉亮度、也细一档（动能损耗） */
    const _cut = t.cut;
    const _f = _cut ? Math.min(1, Math.max(0,
        Math.hypot(_cut.x - t.x0, _cut.y - t.y0) / _dist)) : 1;

    ctx.save();
    ctx.globalAlpha = fade;
    ctx.lineCap = 'round';
    const _pt = (u) => [t.x0 + (t.x1 - t.x0) * u, t.y0 + (t.y1 - t.y0) * u];
    /* 一层描边 = 一条线；光晕靠"宽而淡 + 窄而亮"两层叠出来，
       不用 shadowBlur（一次霰弹 8 条弹道 = 8 次高斯模糊，帧率会腿断）。 */
    const _line = (ua, ub, w, col, al) => {
      if (ub - ua < 1e-4) return;
      const A = _pt(ua), B = _pt(ub);
      ctx.strokeStyle = 'rgba(' + col + ',' + al.toFixed(3) + ')';
      ctx.lineWidth = w;
      ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(B[0], B[1]); ctx.stroke();
    };
    const _seg = (ua, ub, k) => {
      if (ub - ua < 1e-4) return;
      const um = Math.max(ua, Math.min(ub, uH));
      _line(ua, um, 1.8 * (0.5 + 0.5 * k), '255,182,78', 0.55 * k);   /* 细尾：半透明琥珀 */
      _line(um, ub, 6.2 * (0.5 + 0.5 * k), '255,164,52', 0.20 * k);   /* 光晕：宽而淡 */
      _line(um, ub, 2.6 * (0.5 + 0.5 * k), '255,204,118', 0.50 * k);  /* 中间层 */
      _line(um, ub, 1.5, '255,252,236', 0.95 * k);                    /* 亮芯：近白 */
    };
    if (_f >= 1 || u1 <= _f) _seg(u0, u1, 1);
    else if (u0 >= _f) _seg(u0, u1, 0.65);
    else { _seg(u0, _f, 1); _seg(_f, u1, 0.65); }

    if (p < 1){        /* 弹头：一点白芯，一小圈暖光 */
      ctx.fillStyle = 'rgba(255,176,60,0.30)';
      ctx.beginPath(); ctx.arc(hx, hy, 4.6, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,232,170,0.68)';
      ctx.beginPath(); ctx.arc(hx, hy, 2.6, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,253,244,0.95)';
      ctx.beginPath(); ctx.arc(hx, hy, 1.2, 0, TAU); ctx.fill();
    } else if (t.hit){ /* 打中的地方亮一下 */
      glowInit();
      drawGlow(GLOW_HOT, t.x1, t.y1, 16, 0.7 * fade);
    }
    ctx.restore();
  }

  drawBladeSwings();       /* 刀手挥出来的那道白弧 */
  segEnd();                /* 敌人 */
  segBegin('世界B');
  segBegin('特效'); drawImpactFx();
  if (typeof drawRocketFx === 'function') drawRocketFx();
  segEnd();          /* 血渣 / 火星 / 冲击环 / 白闪，压在人身上 */

  /* 火箭尾迹：两层预烘烟团（外圈暖灰 + 内圈亮一点），先铺再画弹体 */
  ctx.save();                       /* drawSmokePuff 会改 globalAlpha，别漏给后面的子弹 */
  for (const _p of rocketTrail){
    const _k = _p.t / _p.dur;
    const _e = 1 - Math.pow(1 - _k, 2.1);
    const _r = _p.r0 + (_p.r1 - _p.r0) * _e;
    const _a = _p.a * Math.pow(1 - _k, 1.35);
    drawSmokePuff('pdd', _p.x, _p.y, _r, _a * 0.78);
    drawSmokePuff('pd',  _p.x - 1.8, _p.y - 2.4, _r * 0.70, _a);
  }
  ctx.restore();

  for (const b of bullets){
    if (!cullPt(b.x, b.y, 100)) continue;
    if (b.turretRocket){
      /* m45306：炮塔炮弹 —— 和玩家那门火箭弹分开画。
         造型是一个又细又长的穿甲弹头：白热尖头 + 冷钢弹身 + 两道后掠短翼，
         尾巴只有一小段蓝白尾焰（火箭弹是粗筒 + 大橙焰，一眼能分开）。 */
      const _ta = Math.atan2(b.vy, b.vx);
      ctx.save();
      ctx.translate(b.x, b.y); ctx.rotate(_ta);
      const _tf = 0.86 + Math.sin(uiT * 60) * 0.12;
      /* 弹体周围一圈很淡的冷光 */
      const _th = ctx.createRadialGradient(-4, 0, 1, -4, 0, 13);
      _th.addColorStop(0, 'rgba(180,224,255,0.20)');
      _th.addColorStop(1, 'rgba(120,180,255,0)');
      ctx.fillStyle = _th;
      ctx.beginPath(); ctx.arc(-4, 0, 13, 0, TAU); ctx.fill();
      /* 尾焰：短、偏蓝白 */
      const _tfr = 7.0 * _tf, _tfry = 2.6 * _tf;
      const _tg = ctx.createRadialGradient(-11, 0, 0.6, -11, 0, _tfr);
      _tg.addColorStop(0,   'rgba(240,250,255,0.95)');
      _tg.addColorStop(0.42,'rgba(150,205,255,0.80)');
      _tg.addColorStop(1,   'rgba(90,150,255,0)');
      ctx.fillStyle = _tg;
      ctx.beginPath(); ctx.ellipse(-11, 0, _tfr, _tfry, 0, 0, TAU); ctx.fill();
      /* 尾翼 */
      ctx.fillStyle = 'rgba(48,58,72,0.98)';
      ctx.beginPath(); ctx.moveTo(-8.6, -2.6); ctx.lineTo(-14.2, -6.4); ctx.lineTo(-5.2, -2.6); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-8.6,  2.6); ctx.lineTo(-14.2,  6.4); ctx.lineTo(-5.2,  2.6); ctx.closePath(); ctx.fill();
      /* 弹身：细长圆筒，冷钢渐变 */
      const _tb = ctx.createLinearGradient(0, -2.8, 0, 2.8);
      _tb.addColorStop(0,   'rgba(226,236,246,0.99)');
      _tb.addColorStop(0.45,'rgba(150,166,184,0.99)');
      _tb.addColorStop(1,   'rgba(78,92,110,0.99)');
      ctx.fillStyle = _tb;
      roundRect(-10.4, -2.8, 19.4, 5.6, 2.2); ctx.fill();
      ctx.strokeStyle = 'rgba(24,34,46,0.80)'; ctx.lineWidth = 1.0; ctx.stroke();
      /* 白热尖头：三角形，尖端再压一点亮 */
      const _tn = ctx.createLinearGradient(6, 0, 12.6, 0);
      _tn.addColorStop(0, 'rgba(255,214,140,0.98)');
      _tn.addColorStop(0.55,'rgba(255,246,222,1)');
      _tn.addColorStop(1, 'rgba(255,255,255,0.98)');
      ctx.fillStyle = _tn;
      ctx.beginPath();
      ctx.moveTo(8.4, -3.2); ctx.lineTo(13.4, 0); ctx.lineTo(8.4, 3.2); ctx.closePath(); ctx.fill();
      ctx.restore();
      continue;
    }
    if (b.rocket){
      /* 火箭弹：灰白尖头 + 深灰短筒 + 尾翼 + 橙黄尾焰（尾气在 update 里撒粒子） */
      const _ang = Math.atan2(b.vy, b.vx);
      ctx.save();
      ctx.translate(b.x, b.y); ctx.rotate(_ang);
      const _fk = 0.88 + Math.sin(uiT * 46) * 0.14;
      /* 弹体周围一层很淡的暖光：暗场里能看出"这里有东西在烧"，也给烟染一点色 */
      const _halo = ctx.createRadialGradient(-6, 0, 2, -6, 0, 17);
      _halo.addColorStop(0, 'rgba(255,186,110,0.24)');
      _halo.addColorStop(1, 'rgba(255,150,70,0)');
      ctx.fillStyle = _halo;
      ctx.beginPath(); ctx.arc(-6, 0, 17, 0, TAU); ctx.fill();
      /* 尾焰：外层橙红大焰 + 内层白黄亮芯，形状是向后拖的椭圆 */
      const _fr = 9.2 * _fk, _fry = 4.6 * _fk;
      const _fg2 = ctx.createRadialGradient(-13.5, 0, 0.8, -13.5, 0, _fr);
      _fg2.addColorStop(0,    'rgba(255,226,158,0.92)');
      _fg2.addColorStop(0.34, 'rgba(255,178,72,0.90)');
      _fg2.addColorStop(0.66, 'rgba(255,112,30,0.52)');
      _fg2.addColorStop(1,    'rgba(255,96,24,0)');
      ctx.fillStyle = _fg2;
      ctx.beginPath(); ctx.ellipse(-13.5, 0, _fr, _fry, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,246,214,0.85)';
      ctx.beginPath(); ctx.ellipse(-11.8, 0, 2.1 * _fk, 1.5 * _fk, 0, 0, TAU); ctx.fill();
      /* 尾翼：上下各一片，靠喷口的深色剪影 */
      ctx.fillStyle = 'rgba(40,44,50,0.98)';
      ctx.beginPath(); ctx.moveTo(-9.2, -3.6); ctx.lineTo(-15.6, -8.6); ctx.lineTo(-4.6, -3.6); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-9.2,  3.6); ctx.lineTo(-15.6,  8.6); ctx.lineTo(-4.6,  3.6); ctx.closePath(); ctx.fill();
      /* 喷口：一小段更深的筒 */
      ctx.fillStyle = 'rgba(58,62,70,0.98)';
      roundRect(-11.6, -3.4, 4.2, 6.8, 1.6); ctx.fill();
      /* 弹体：上亮下暗的金属筒，外面再勒一道深色轮廓（暗底上才立得住） */
      const _bg2 = ctx.createLinearGradient(0, -4.4, 0, 4.4);
      _bg2.addColorStop(0,   'rgba(158,167,178,0.99)');
      _bg2.addColorStop(0.40,'rgba(104,112,124,0.99)');
      _bg2.addColorStop(1,   'rgba(58,64,74,0.99)');
      ctx.fillStyle = _bg2;
      roundRect(-9.4, -4.4, 18.6, 8.8, 3.0); ctx.fill();
      ctx.strokeStyle = 'rgba(26,30,36,0.85)'; ctx.lineWidth = 1.2;
      roundRect(-9.4, -4.4, 18.6, 8.8, 3.0); ctx.stroke();
      /* 两道深色环带 */
      ctx.fillStyle = 'rgba(48,54,62,0.92)';
      ctx.fillRect(-3.4, -4.4, 1.8, 8.8);
      ctx.fillRect(1.4, -4.4, 1.3, 8.8);
      /* 弹头：白灰锥 + 一点橙红引信 + 一道细高光 */
      const _ng = ctx.createLinearGradient(0, -4.4, 0, 4.4);
      _ng.addColorStop(0, 'rgba(248,251,255,0.99)');
      _ng.addColorStop(0.5, 'rgba(212,220,230,0.99)');
      _ng.addColorStop(1, 'rgba(150,158,170,0.99)');
      ctx.fillStyle = _ng;
      ctx.beginPath(); ctx.moveTo(8.4, -4.4); ctx.lineTo(19.2, 0); ctx.lineTo(8.4, 4.4); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(26,30,36,0.7)'; ctx.lineWidth = 1.0; ctx.stroke();
      ctx.fillStyle = 'rgba(255,146,72,0.95)';
      ctx.beginPath(); ctx.moveTo(11.6, -1.7); ctx.lineTo(16.2, 0); ctx.lineTo(11.6, 1.7); ctx.closePath(); ctx.fill();
      ctx.restore();
      continue;
    }
    const tx = b.x - b.vx*0.030, ty = b.y - b.vy*0.030;
    ctx.strokeStyle = PAL.P234;
    ctx.lineWidth = 3; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(tx,ty); ctx.lineTo(b.x,b.y); ctx.stroke();
    ctx.fillStyle = PAL.P224;
    ctx.beginPath(); ctx.arc(b.x,b.y,2.8,0,TAU); ctx.fill();
  }

  /* 上帝模式·隐身：连自己的本体也不画（镜头中心就是你，不用白点提醒） */
  const _godHideSelf = (typeof godInvis === 'function' && godInvis());
  if (player && !playerTruck && !_godHideSelf && !(typeof spectatorViewOn === 'function' && spectatorViewOn())){
    if(playerShieldUp()&&Math.sin(player.aim||0)<0)drawHeldPlayerShield();
    /* 穿了甲就先在身子底下垫一层「马甲轮廓」，人还是那个人，只是厚了一圈；
       人身上再画胸板和两肩，一眼能看出是衣服不是光盾。 */
    const _AV = (player.armor && player.hp > 0) ? (armorDef(player.armor.kind) || ARMOR_DEF.light) : null;
    /* 甲色一律往夜色里压：纯饱和蓝/黄在暗场里像贴着发光贴纸，
       压到 62% 深灰之后只剩「一件事：这人身上有装备」的信息量。 */
    const _AM = _AV ? mixHex(_AV.pal, '#0e1318', 0.74) : null;
    const _AB = _AV ? mixHex(_AV.pal, PAL.P33, 0.80) : null;   /* 身体只留一层很淡的甲色 */
    if (_AV) drawArmorRing(player.x, player.y, player.r, player.armor.kind, armorPct());
    ctx.save();
    ctx.globalAlpha = th ? 0.55 : 1;
    ctx.fillStyle = (player.hp <= 0) ? 'rgba(158,160,166,0.92)'
                  : (player.flash > 0.2 ? PAL.P97 : (_AV ? _AB : PAL.P33));
    ctx.beginPath(); ctx.arc(player.x,player.y,player.r,0,TAU); ctx.fill();
    ctx.restore();
    /* 穿了甲：插板 + 胳膊洞 + 碎甲红圈，全部走共用绘制（和敌人同一份） */
    if (_AV && player.hp > 0){
      drawArmorPlate(player.x, player.y, player.r, player.aim || 0, player.armor.kind, armorPct());
      if (armorBreakT > 0) drawArmorBreakRing(player.x, player.y, player.r, armorBreakT);
    }    /* 死了就在倒下的地方留一个标记，不然一地黑鸽鸽找不到自己 */
    if (player.hp <= 0){
      ctx.save();
      ctx.strokeStyle = 'rgba(232,120,110,0.85)';
      ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(player.x, player.y, player.r + 9, 0, TAU); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(player.x - 5, player.y); ctx.lineTo(player.x + 5, player.y);
      ctx.moveTo(player.x, player.y - 5); ctx.lineTo(player.x, player.y + 5);
      ctx.stroke();
      ctx.restore();
    }
    /* 这个圈只在"蹲着/藏起来了"的时候画 —— 平常跑动时它就是多余的圆框 */
    if (concealed || player.crouch){
      ctx.strokeStyle = concealed ? PAL.P3 : PAL.P145;
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(player.x,player.y,player.r+3.5,0,TAU); ctx.stroke();
    }
    if(playerShieldUp()&&Math.sin(player.aim||0)>=0)drawHeldPlayerShield();
    /* 手上有没有枪，得一眼看出来：枪身贴着身体前沿，枪口朝着准星 */
    /* 挥刀的那一下不画手里的刀：人已经蹲出去了，刀还留在原地很出戏 */
    if (player.hp > 0 && player.hand && !(meleeT > 0)){
      drawHandNade();
    } else if (!playerShieldUp() && player.hp > 0 && player.gun && player.gun.kind !== 'throw' && !(meleeT > 0)){
      const ga = Math.atan2(mouseWorldY()-player.y, mouseWorldX()-player.x);
      const gwid = player.gun.wid || 'pistol';
      /* 长枪握在身前更靠里一点，枪口伸出身体；短枪贴着身体前沿。
         这两个量下面"空匣红点"也要用，所以提到 if 外面声明（以前写在 if 里，
         const 是块级作用域，弹匣一空走到红点那句就 ReferenceError，整个 HUD 全没了）。 */
      const _isRpg = gwid === 'rpg';
      const gd = player.r + (_isRpg ? 1 : gwid === 'pistol' ? 2 : 3);
      const gs = _isRpg ? 0.95 : gwid === 'smoke' ? 1.15 : gwid === 'shotgun' ? 0.76 : gwid === 'rifle' ? 0.70 : gwid === 'ar' ? 0.64 : gwid === 'flare' ? 0.78 : gwid === 'bino' ? 1.25 : gwid === 'dao' ? 1.5 : 0.62;
      /* 坐在重机枪上：手里那把枪收起来，画面上只有枪座那挺 —— 否则两把枪叠在一起看不清 */
      if (!player.mgNest){
      /* 火箭筒是扛在肩上的：再往身体侧面（瞄准方向的左/上）挪一点 */
      const _gox = 0;
      const _goy = 0;
      drawGunModel(player.x + Math.cos(ga)*gd + _gox, player.y + Math.sin(ga)*gd + _goy,
                   gs, ga, th ? 'rgba(150,170,190,0.55)' : 'rgba(214,222,232,0.96)',
                   'rgba(12,16,20,0.62)', gwid, { warhead: (player.gun.mag || 0) > 0 });
      }
      if (!player.mgNest && player.gun.mag <= 0 && player.gun.kind !== 'throw' && player.gun.kind !== 'melee' && !player.gun.tool){        /* 空匣挂个红点，别等按下去才知道没子弹 */
        ctx.fillStyle = 'rgba(232,96,86,0.95)';
        ctx.beginPath();
        ctx.arc(player.x + Math.cos(ga)*(gd+9), player.y + Math.sin(ga)*(gd+9), 2.3, 0, TAU);
        ctx.fill();
      }
    }
    if (state==='play' && !paused){
      ctx.strokeStyle = PAL.P61;
      ctx.setLineDash([4,8]); ctx.lineWidth = 1;
      const a = Math.atan2(mouseWorldY()-player.y, mouseWorldX()-player.x);
      const L2 = Math.min(350, dist(player.x,player.y,mouseWorldX(),mouseWorldY()));
      ctx.beginPath(); ctx.moveTo(player.x,player.y);
      ctx.lineTo(player.x+Math.cos(a)*L2, player.y+Math.sin(a)*L2); ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  /* 坐在椅子上：把椅背补画一次盖在人前面 —— 人才像"坐在椅子上"，
     否则玩家整个人压在椅子上，看着像站在椅子跟前的空地上。 */
  if (player && player.seat && player.seat.sit && !player.seat.dead) drawSeatOverlay(player.seat);

  ctx.globalAlpha = 1;   /* 敌人淡入淡出改过 alpha，画完必须归位，不然 HUD 一起变淡 */

  drawNadeProjectiles();
  if (typeof drawRocketWarn === 'function') drawRocketWarn();   /* m44696：敌方火箭落点预警 */
  drawFlares();
  drawAirdrops();
  for (const g of grenades){
    if (!cullPt(g.x, g.y, 130)) continue;
    const p = clamp(g.t/g.dur,0,1);
    const arc = Math.sin(p*Math.PI)*56;
    ctx.globalAlpha = 0.35; ctx.fillStyle = PAL.P_K;
    ctx.beginPath(); ctx.ellipse(g.x, g.y+8, 6, 3, 0, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1;
    /* 扔出去的是罐子不是球：按飞行方向排一下、还会翻滚 */
    const _ga = Math.atan2(g.y1 - g.y0, g.x1 - g.x0);
    ctx.save();
    ctx.translate(g.x, g.y - arc);
    ctx.rotate(_ga + p * 8.0);
    /* 敌人的罐子刷成暗红：飞过来那一眼就能分出是谁扔的 */
    const _GC = (g.byEnemy && typeof SMOKE_DEF !== 'undefined') ? SMOKE_DEF.enemy : null;
    ctx.fillStyle = _GC ? _GC.canister : PAL.P4;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(-4.6, -2.3, 9.2, 4.6, 2.0); else ctx.rect(-4.6, -2.3, 9.2, 4.6);
    ctx.fill();
    ctx.strokeStyle = 'rgba(10,14,18,0.55)'; ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = _GC ? _GC.band : 'rgba(255,255,255,0.45)';
    ctx.fillRect(-1.4, -2.3, 2.0, 4.6);
    ctx.restore();
  }

  segEnd();   /* 世界B */
  drawCompanions();
  segBegin('屋顶');
  /* 屋顶：画在所有单位之后、光照之前。
     这样它能挡住屋里的敌人（"屋顶会遮挡视线和内部的敌人"），
     又不挡住室内的光（光照是后面那层屏幕空间的黑暗遮罩）。 */
  drawRoofs();   /* 别的房间的灰暗 + 屋顶，一起合成、一起被视野锥挖开 */
  if (typeof drawDoorHints === 'function') drawDoorHints();   /* 提示要压在屋顶上面 */
  if (typeof drawTowerMarks === 'function') drawTowerMarks(); drawTowerTops(); drawTowerHint();  /* 瞭望塔报点的方括号，压在屋顶上面 */
  if (typeof drawTowerHud === 'function') drawTowerHud();   /* 塔上那一行：情报同步给几个人 */
  segEnd();
  segBegin('灰暗'); drawShadeCues(); segEnd();
  segBegin('后期');   /* 灰暗里藏起来的那几个：只报"有动静" */
  /* 这层暗色是按屏幕铺的：望远镜把画面拉远后能看到的范围比 W×H 更大，
     用 cam+W/H 铺就会在边上留一条没盖住的亮边，所以按可见世界矩形铺 */
  if (th){
    const _vx = CULL.ok ? CULL.x0 : cam.x, _vy = CULL.ok ? CULL.y0 : cam.y;
    const _vw = CULL.ok ? (CULL.x1 - CULL.x0) : W, _vh = CULL.ok ? (CULL.y1 - CULL.y0) : H;
    ctx.fillStyle = PAL.P116; ctx.fillRect(_vx, _vy, _vw, _vh);
  }
  ctx.restore();

  if (L.boss && state === 'play') drawBossOverlay();
  if (L.boss && state === 'play' && exitOpen) drawRunPanic();

  /* 雨夜：黑暗遮罩 + 斜雨 + 闪电。屏幕空间，画在世界之后、暗角之前。
     热成像开着就不吃这层黑：它耗电、有冷却、打雷还会花屏，拿它换视野是玩家的选择。 */
  if (player && ((L.rules && L.rules.nightR > 0) || weatherActive())){ segBegin('夜雨'); drawNightRain(L); segEnd(); }
  /* 变天预警盖在世界之上、风线之下（m20460） */
  /* 大风的风线/飘尘画在最上面（屏幕空间），HUD 之前 */
  if (typeof drawWindFx === 'function' && typeof windActive === 'function' && windActive()){
    segBegin('风'); drawWindFx(); segEnd();
  }
  /* 打雷干扰热成像的花屏：独立于天气层，只要开着热成像就看得到 */
  if (heatGlitch > 0 && player && player.thermalOn) drawHeatGlitch();

  /* 暗角：一张只随 W/H/主题变的径向渐变，每帧都重新 createRadialGradient + 全屏填。
     改成烘一次贴一次 —— 贴图在任何后端都不会比逐像素算渐变贵。 */
  drawVignette();

  if (hitFlash > 0){ ctx.fillStyle = 'rgba(200,25,15,'+(hitFlash*0.35)+')'; ctx.fillRect(0,0,W,H); }
  /* 打击感最外层：一瞬全屏白闪 + 溅在屏幕上的血点 */
  if (fxFlash > 0){
    ctx.fillStyle = 'rgba(255,250,240,' + (fxFlash*0.20).toFixed(3) + ')';
    ctx.fillRect(0,0,W,H);
  }
  /* 暴击：一圈从边缘收进来的金色光，只有零点几秒 */
  if (critFlash > 0){
    const cg = ctx.createRadialGradient(W/2, H/2, H*0.26, W/2, H/2, H*0.82);
    cg.addColorStop(0, 'rgba(255,196,70,0)');
    cg.addColorStop(1, 'rgba(255,186,52,' + (critFlash*0.20).toFixed(3) + ')');
    ctx.fillStyle = cg; ctx.fillRect(0,0,W,H);
  }
  /* 自言自语放到所有全屏遮罩之后再画，不然雨夜的黑幕会把它压暗 */
  drawSelfTalk();
  /* 3. 会发光的东西压在遮罩上面：他开枪你得看得见弹道，砍你得看得见刀光 */
  if (state === 'play' && player){
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';

    /* 这里是屏幕空间（世界坐标系已经 pop 掉了）。中心点和尾端分别换算，
       才能与斗蛐蛐世界层的中心缩放完全重合。 */
    const _glowK = worldGlowScreenScale();
    for (const b of bullets){
      const _bh = worldGlowScreenPos(b.x, b.y);
      const _bt = worldGlowScreenPos(b.x - b.vx*0.034, b.y - b.vy*0.034);
      const bx = _bh.x, by = _bh.y, tx2 = _bt.x, ty2 = _bt.y;
      ctx.strokeStyle = 'rgba(255,226,150,0.95)';
      ctx.lineWidth = 3 * _glowK; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(tx2, ty2); ctx.lineTo(bx, by); ctx.stroke();
      ctx.fillStyle = 'rgba(255,250,220,1)';
      ctx.beginPath(); ctx.arc(bx, by, 2.6 * _glowK, 0, TAU); ctx.fill();
    }
    for (const e of enemies){
      if (e.muzzle > 0 && cullPt(e.x, e.y, 60)){
        const kk = Math.min(1, e.muzzle * 7);
        ctx.fillStyle = 'rgba(255,214,120,' + (0.9 * kk).toFixed(3) + ')';
        /* 用「开这一枪时的角度」画火光，而不是身体朝向：e.ang 跟不上转身，
           会造成枪口一发、脑袋上再飘一枚的错觉（m42211）。 */
        const _mzA = (typeof e.mzA === 'number') ? e.mzA : e.ang;
        const _mp = worldGlowScreenPos(e.x + Math.cos(_mzA)*16, e.y + Math.sin(_mzA)*16);
        ctx.beginPath(); ctx.arc(_mp.x, _mp.y, 9.5 * _glowK, 0, TAU); ctx.fill();
      }
    }
    for (const sl of slashFx){
      if (!cullPt(sl.x, sl.y, 120)) continue;
      const kk = 1 - sl.t / sl.dur;
      ctx.strokeStyle = 'rgba(255,92,102,' + (0.9 * kk).toFixed(3) + ')';
      ctx.lineWidth = (0.8 + 4.2 * kk) * _glowK;
      const _sp = worldGlowScreenPos(sl.x, sl.y);
      ctx.beginPath(); ctx.arc(_sp.x, _sp.y, (24 + 14 * (1 - kk)) * _glowK, sl.a - 0.8, sl.a + 0.8); ctx.stroke();
    }
    ctx.restore();
  }

  drawDeathFade();/* 挨打的方向 */
  drawSplats();
  if (hpFx.k1 > 0.01 && !revealAll){   /* 失败定格时不画低血隧道，别挡住看敌人 */
    /* 脉搏：每一下心跳让红边涨一次，然后衰减 */
    const thump = hpFx.k2 > 0.01 ? Math.exp(-hbLastHit*7.2) : 0;
    const k2 = hpFx.k2, k3 = hpFx.k3;
    /* 以"屏幕中心到边缘的半径"为单位，越危险清晰圈越小 —— 隧道视野 */
    const r0 = H*0.10;
    const R1 = H*clamp(0.60 - 0.18*k2 - 0.22*k3, 0.16, 0.62);   /* 开始变暗的半径 */
    const R2 = H*(0.95 - 0.06*k3);
    const f1 = clamp((R1 - r0)/(R2 - r0), 0.06, 0.96);
    const dark = 0.10*hpFx.k1 + 0.20*k2 + 0.22*k3;
    const red  = (0.05*hpFx.k1 + 0.26*k2 + 0.34*k3) * (0.55 + 0.45*thump);
    const vg2 = ctx.createRadialGradient(W/2,H/2,r0,W/2,H/2,R2);
    vg2.addColorStop(0, TC(PAL.P7));
    vg2.addColorStop(f1*0.86,        'rgba(12,0,0,'+(dark*0.60).toFixed(3)+')');
    vg2.addColorStop(f1,             'rgba(70,6,6,'+(dark*1.10).toFixed(3)+')');
    vg2.addColorStop(f1 + (1-f1)*0.55,'rgba(120,8,8,'+(red*0.78).toFixed(3)+')');
    vg2.addColorStop(1,              'rgba('+Math.round(110+60*thump)+',0,0,'+Math.min(0.80, red*(1.05+0.35*thump)).toFixed(3)+')');
    ctx.fillStyle = vg2; ctx.fillRect(0,0,W,H);
  }

  /* 警报时屏幕四周随声音一起泛红（屏幕坐标，不跟相机走） */
  if (alarm2Lvl > 0.01 && !mapOpen && state === 'play' && !ar){
    const pulse = 0.5 + 0.5*Math.sin(uiT * 9.5);
    const a = alarm2Lvl * (0.26 + 0.30*pulse);
    const ag = ctx.createRadialGradient(W/2, H/2, H*0.30, W/2, H/2, H*0.92);
    ag.addColorStop(0, 'rgba(190,20,14,0)');
    ag.addColorStop(0.45, 'rgba(190,20,14,' + (a*0.16).toFixed(3) + ')');
    ag.addColorStop(0.78, 'rgba(185,12,10,' + (a*0.55).toFixed(3) + ')');
    ag.addColorStop(1, 'rgba(160,0,0,' + a.toFixed(3) + ')');
    ctx.fillStyle = ag; ctx.fillRect(0, 0, W, H);
  }

  if (state === 'play' || state === 'clear' || state === 'win' || state === 'lose'){
    /* 血条和伤害数字必须画在"糊"的下面：要不然人一糊，这些字还亮着，
       等于白送敌人位置 */
    if (state === 'play' && !mapOpen && hasFeat('guns')) drawCombatOverlay(isTestZone());
    if (state === 'play'){ if (typeof ghostTryCapture === 'function') ghostTryCapture(); applyVisionBlur(); if (typeof drawBlastGhosts === 'function') drawBlastGhosts(); drawBlindFx(); if (typeof drawBlastFilter === 'function') drawBlastFilter(); }
  if (state === 'play' || state === 'intro') drawBlurFx();
  if (state === 'dead' || state === 'arenaOver') applyDeathFx();
  }
  /* 分段收尾必须无条件执行：上面那个 if 只管"要不要画准星/视野模糊"，
     不能把它当成 HUD 的总开关，否则非 play 状态下'后期'永远不关、F3 记账全乱 */
  segEnd();   /* 后期 */
  /* 军团推塔：自己的 HUD 独立画（不受 F9 拍照模式的总开关影响，否则观战图会一个界面都没有） */
  if (typeof drawMobaHud === 'function' && typeof mobaOn === 'function' && mobaOn()){
    segBegin('MOBA'); drawMobaHud(); segEnd();
  }
  /* 拍照模式（F9）：这一整层 HUD / 气泡 / 面板都不画，只留世界 */
  if (!window.uiHideAll){
  if (state === 'play' || state === 'clear' || state === 'win' || state === 'lose'){
  /* m23640：调"近处/远处细节距离"时，屏幕上直接有一个圈跟着变；关掉面板立刻消失。
     画在世界坐标里会被面板挡住（相机始终把玩家放屏幕正中，而面板也在正中），
     所以在右下角放一个"比例尺"小仪表：它按同样的半径比例实时缩放，拖滑块能立刻看出"多大一圈"。 */
  if (state === 'play' && player && typeof panelOpen === 'function' && panelOpen() &&
      typeof panelTab !== 'undefined' && panelTab === 'perf'){
    const _pn = Math.max(120, CFG.lodNear || 560);
    const _pf = Math.max(_pn + 120, CFG.lodFar || 1010);
    /* m23715：直接画在玩家身上（面板改成靠右停靠，所以不再被盖住） */
    const _sx = player.x - cam.x, _sy = player.y - cam.y;
    ctx.save();
    /* 两圈之间填一层淡黄 = 这段是简化区 */
    ctx.beginPath();
    ctx.arc(_sx, _sy, _pf, 0, 6.2832);
    ctx.arc(_sx, _sy, _pn, 0, 6.2832, true);
    ctx.fillStyle = 'rgba(255,196,90,0.055)'; ctx.fill();
    /* 外圈：简化区边界 */
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255,233,168,0.85)';
    ctx.setLineDash([7, 9]);
    ctx.beginPath(); ctx.arc(_sx, _sy, _pf, 0, 6.2832); ctx.stroke();
    /* 内圈：完整细节边界 */
    ctx.strokeStyle = 'rgba(182,255,207,0.9)';
    ctx.setLineDash([12, 7]);
    ctx.beginPath(); ctx.arc(_sx, _sy, _pn, 0, 6.2832); ctx.stroke();
    ctx.setLineDash([]);
    /* 文字贴在圈右边，实时跟着滑块走 */
    ctx.font = 'bold 13px \"Microsoft YaHei\",sans-serif';
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(182,255,207,0.98)';
    ctx.fillText('完整 ' + Math.round(_pn) + ' px', _sx + _pn + 10, _sy - 6);
    ctx.fillStyle = 'rgba(255,233,168,0.98)';
    ctx.fillText('简化 ' + Math.round(_pf) + ' px', _sx + _pf + 10, _sy + 16);
    ctx.restore();
  }

  /* m34466：地面印字改成「屏幕坐标」的角落提示 —— 固定贴在画面左上角，
     不再跟关卡出生点/墙走（原来那套要在世界坐标里找空地，常常画到屏幕外）。 */

  if (!(mapOpen && state === 'play')){ segBegin('HUD'); drawHUD(); drawThunderBanner();
    drawWeatherDebug();
    if (typeof drawGodTag === 'function') drawGodTag();
    if (typeof drawCricketHud === 'function') drawCricketHud();
    segEnd(); }
  if (state === 'play' && !mapOpen && player && player.mgNest) drawMgNestHud();
  else if (state === 'play' && playerTruck && !mapOpen) drawTruckMgHud();
  else setCursorStyle('crosshair');
  if(state==='play'&&player&&!mapOpen&&!(ar&&ar.freeze)){
    if(player.hasShield || isTestZone()){
      ctx.save();ctx.fillStyle='#9ad0ff';ctx.font='12px "Microsoft YaHei",sans-serif';ctx.textAlign='left';
      ctx.fillText(player.hasShield?('防弹盾牌 · '+(playerShieldUp()?'已举起 [G 收起 / Q 切枪]':'已收起 [G 举盾 / Q 切枪]')):'Q 收盾切枪 · G 举盾 / 收盾 · 丢盾在背包里拖出去',24,H-62);
      /* 盾牌耐久条：贴在状态行下面，掉到 25% 变橙红 */
      if (player.hasShield){
        const maxHp = (typeof player.shieldMaxHp === 'number' && player.shieldMaxHp > 0) ? player.shieldMaxHp : SHIELD_MAX_HP;
        const hp = (typeof player.shieldHp === 'number') ? player.shieldHp : maxHp;
        const pct = clamp(hp / maxHp, 0, 1);
        const bw = 150, bx = 24, by = H - 52;
        ctx.fillStyle = 'rgba(10,16,22,0.72)';
        roundRect(bx, by, bw, 8, 4); ctx.fill();
        ctx.fillStyle = pct > 0.35 ? 'rgba(150,205,235,0.95)' : 'rgba(236,140,110,0.95)';
        roundRect(bx, by, Math.max(2, bw * pct), 8, 4); ctx.fill();
        ctx.fillStyle = 'rgba(200,224,240,0.85)';
        ctx.font = '11px "Microsoft YaHei",sans-serif';
        ctx.fillText(Math.round(hp) + ' / ' + maxHp, bx + bw + 8, by + 8);
      }
      ctx.restore();
    }
    /* 分层提示：只有当前这一层真的能用时才出现（m43728） */
    const _hint2 = (typeof hintLayerText === 'function') ? hintLayerText() : '';
    /* m20503：这条是指挥/投放的开发提示，普通玩家看到会误会成游戏功能 */
    if (CFG.dev && _hint2){
      ctx.save();
      ctx.font = '12px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'left';
      ctx.fillStyle = 'rgba(150,205,235,0.92)';
      ctx.fillText(_hint2, 24, H - 78);
      ctx.restore();
    }
  }
  if (state === 'play' && !mapOpen) drawRushFx();
  drawCompanionHUD();
  /* 人机说话的气泡故意画在 HUD 上面：小兵跒到角落时也能看清 */
  barkFlush();
  if (codexOpen && state === 'play') drawCodex();
  if (state === 'play' && !mapOpen) drawHealBar();
  if (state === 'play' && !mapOpen) drawCrateBar();
  if (state === 'play' && !mapOpen) drawReloadBar();
  if (!isTestZone() && hasFeat('guns') && state === 'play' && !mapOpen) drawCombatHUD();
  /* 洗牌界面是整屏的，底下的割草 HUD 别透上来 */
  const _shufTop = !!(ar && (ar.shuf || (ar.er && ar.er.stage)));   /* 洗牌 / 赌卡都是整屏界面，底下的 HUD 别透上来 */
  if (ar && state === 'play' && !_shufTop) drawArenaHUD();
  if (ar && state === 'play' && !_shufTop && !(ar.er && ar.er.stage)) drawErTag();
  if (ar && state === 'play' && !_shufTop) drawBanAnim();

  if (ar && state === 'play' && !_shufTop) drawArenaBossBar();
  if (ar && state === 'play' && !_shufTop) drawArenaArrow();
  if (ar && state === 'play' && !_shufTop) drawArenaCine();
    if (state === 'play' && !mapOpen){
    if (isTestZone()) drawTestHUD();
    /* 先看有没有登记过的界面（背包 / 抽奖盘……）：有就画它，没有才画老背包 */
    if (typeof uiScreensActive === 'function' && uiScreensActive()) uiDrawScreens();
    else if (hasFeat('meds')) drawInventory();
  }
    /* 人物状态面板（E）：只读小窗，压在这一层 HUD 上面 */
    }
  if (ar && ar.er && ar.er.stage && state === 'play') drawErUI();
  else if (ar && ar.shuf && state === 'play') drawShuffle();
  else if (ar && ar.freeze && state === 'play') drawArenaChoices();
  /* 抽卡展示在最上层，和输入处理的优先级一致。 */
  if (ar && state === 'play') drawDrawShow();
  if (ar && state === 'play' && CFG.dev && ar.devOpen) drawArenaDevJump();
  }   /* !uiHideAll */
  if (state === 'editor') drawEditor();
  if (state === 'arenaPick') drawArenaPick();
  if (state === 'arenaOver') drawArenaOver();
  if (state === 'select') drawSelect();
  if (mapOpen && state === 'play') drawMap();
  if (state === 'intro') drawIntro();
  if (state === 'menu') drawMenu();
  if (state === 'arcade') drawArcade();
  if (state === 'dzpick') drawDzPick();
  /* m36161：公告按钮的显隐要每帧无条件同步 —— 原来只在 HUD 块里同步，
     而 HUD 块只在 play/clear/win/lose 时跑，于是进局时被设成 none 之后，
     回到主菜单没人再把它改回来（按钮永久消失）。 */
  if (typeof noticeSyncVisible === 'function') noticeSyncVisible();
  if (state === 'menu' || state === 'select'){
    ctx.save();
    ctx.textAlign = 'left';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(140,154,172,0.72)';
    ctx.fillText('暗区老鼠模拟器 ' + GAME_VER + ' · ' + (typeof BUILD_TAG !== 'undefined' ? BUILD_TAG : ''), 18, H - 14);
    ctx.restore();
  }
  /* 开发者投放面板画在最后：不被暗角、地图、剧情遮住 */
  if (CFG.dev && devSpawnOpen && state === 'play') drawDevSpawnPanel();
  if (CFG.dev && typeof devItemOpen !== 'undefined' && devItemOpen && state === 'play') drawDevItemPanel();
  if (typeof cargoOpenTruck !== 'undefined'){ if (cargoOpenTruck) drawCargoPanel(); else drawCargoHint(); }
  if (CFG.dev && devPlaceKind && state === 'play') drawDevPlaceGhost();
  if (CFG.dev && typeof drawDevOrder === 'function' && state === 'play') drawDevOrder();
  if (typeof drawBindAudit === 'function') drawBindAudit();
  if (CFG.dev && devFrozen()) drawDevFreezeTag();
  if (state === 'clear') drawEnd('clear');
  if (state === 'win')  drawEnd('win');
  if (state === 'lose') drawEnd('lose');
  if (typeof stashUI !== 'undefined' && stashUI.open && typeof drawStash === 'function') drawStash();
  if (state === 'caught') drawCaught();
  if (state === 'dead') drawDead();
  drawAshScreen();          /* 屏幕灰烬压在所有 UI 之上 */

}
