/* ============================ 运兵车 ============================
   它不是一个"怪"，是一次事件。状态机（全部在 updateTruck 里）：
     drift_in       从画面外横扫进来：横向正弦滑移 + 车头偏转（甩尾），轮胎冒烟
     brake          继续往前蹭一段刹停，烟更凶
     deploy_troops  停稳 → 车门滑开 → 每隔 deployGap 放一个人下车（共 deployCount 个）
     leave          卸完开走，开出画面就消失
     wreck          卸完留在原地当废铁掩体
   两条硬规矩：
     1) 中弹只出金属火花、不流血，而且打不断漂移（它自己停下才算）
     2) 停稳之后是实体：挡敌人子弹、挡玩家
   数值全在 data/enemies.js 的 ENEMY_TYPES.truck。 */

/* *** 运兵车是「第三方」，不在 enemies 数组里 ***
   以前把它塞进 enemies，出了三个毛病：
     a) 敌人的碰撞只对 L.walls 做 → 敌人直接从车上走过去；
     b) 打爆之后它还在 enemies 里 → 继续被当成可命中目标吃伤害；
     c) 关卡清空判定是 enemies.length === 0 → 一辆打不死的车能让整关永远结不了。
   现在它住自己的数组 trucks：不吃敌人那套 AI/命中/计数，只当一个会动的障碍物。 */
const trucks = [];
const TruckSystem=Object.freeze({
  update:function(dt){
    for(const vehicle of trucks){
      updateTruck(vehicle,dt);
      truckSeparate(vehicle);
    }
  },
  removeGone:function(){
    for(let index=trucks.length-1;index>=0;index--){
      if(trucks[index].tstate==='gone')trucks.splice(index,1);
    }
  }
});
/* 玩家正在开的那辆车（null = 步行）。开车时玩家的坐标一直跟着车心，
   所以相机、敌人视线、HUD 全都不用改就自动跟上了。 */
let playerTruck = null;
/* 换关/重开时不能只清 trucks[]：playerTruck 若还指着上一局的车，下一帧会继续
   驾驶这个已从世界删除的对象，把新玩家坐标拖回旧地图。 */
function truckResetPlayerState(){
  const t = playerTruck;
  playerTruck = null;
  if (t && typeof vehEngineSilence === 'function') vehEngineSilence();
  if (!t) return false;
  try {
    truckSetTeam(t, 'neutral');
    if (!t.wreck && t.tstate !== 'gone'){ t.tstate = 'parked'; t.spd = 0; t.solid = true; }
  } catch (e){ if (typeof reportErr === 'function') reportErr('18-truck', e); }
  return true;
}
/* 车壳是个长条矩形（不是正方形）：长 2×bodyHL、宽 2×bodyHW。
   以前用 t.r 当正方形用，车头车尾判定比车身短、两侧又比车身宽 ——
   于是贴墙时车壳会和掩体互相插进去（穿模），侧面撞人还撞不到。 */
const _TRUCK_SHAPE_DEF = vehicleDef('truck');
const TRUCK_BODY = { HL: _TRUCK_SHAPE_DEF.bodyHL, HW: _TRUCK_SHAPE_DEF.bodyHW };
function truckRect(t){
  const ang = t.ang || 0;
  const c = Math.abs(Math.cos(ang)), sn = Math.abs(Math.sin(ang));
  const hx = c * TRUCK_BODY.HL + sn * TRUCK_BODY.HW;
  const hy = sn * TRUCK_BODY.HL + c * TRUCK_BODY.HW;
  return { x: t.x - hx, y: t.y - hy, w: hx * 2, h: hy * 2 };
}
/* 车壳的四个角（世界坐标） */
function truckCorners(t){
  const c = Math.cos(t.ang || 0), sn = Math.sin(t.ang || 0);
  const ux = c * TRUCK_BODY.HL, uy = sn * TRUCK_BODY.HL;
  const vx = -sn * TRUCK_BODY.HW, vy = c * TRUCK_BODY.HW;
  return [{ x: t.x + ux + vx, y: t.y + uy + vy },
          { x: t.x + ux - vx, y: t.y + uy - vy },
          { x: t.x - ux - vx, y: t.y - uy - vy },
          { x: t.x - ux + vx, y: t.y - uy + vy }];
}
/* SAT：车壳 OBB 和矩形墙。返回 null（没碰）或 {nx,ny, depth, px,py}
   nx,ny 是"从墙指向车"的法线；px,py 是真正的撞击点（车壳扎进墙里最深的那个点） */
function obbVsRect(x, y, ang, r){
  const c = Math.cos(ang), sn = Math.sin(ang);
  const hl = TRUCK_BODY.HL, hw = TRUCK_BODY.HW;
  const rcx = r.x + r.w / 2, rcy = r.y + r.h / 2;
  const rhw = r.w / 2, rhh = r.h / 2;
  const dx = x - rcx, dy = y - rcy;
  const axes = [{ x: c, y: sn }, { x: -sn, y: c }, { x: 1, y: 0 }, { x: 0, y: 1 }];
  let best = null;
  for (const a of axes){
    const eo = hl * Math.abs(a.x * c + a.y * sn) + hw * Math.abs(-a.x * sn + a.y * c);
    const er = rhw * Math.abs(a.x) + rhh * Math.abs(a.y);
    const d = dx * a.x + dy * a.y;
    const ov = eo + er - Math.abs(d);
    if (ov <= 0) return null;
    if (!best || ov < best.depth)
      best = { depth: ov, nx: d < 0 ? -a.x : a.x, ny: d < 0 ? -a.y : a.y };
  }
  /* 撞击点：车壳上撒 20 个点，取"扎进矩形最深"的那个 */
  let px = clamp(x, r.x, r.x + r.w), py = clamp(y, r.y, r.y + r.h), deep = -1;
  const cand = [];
  for (const k of [-1, -0.66, -0.33, 0, 0.33, 0.66, 1]){
    cand.push({ x: x + c * hl + (-sn) * hw * k, y: y + sn * hl + c * hw * k });   /* 车头边 */
    cand.push({ x: x - c * hl + (-sn) * hw * k, y: y - sn * hl + c * hw * k });   /* 车尾边 */
    cand.push({ x: x + c * hl * k - sn * hw, y: y + sn * hl * k + c * hw });      /* 一侧 */
    cand.push({ x: x + c * hl * k + sn * hw, y: y + sn * hl * k - c * hw });      /* 另一侧 */
  }
  for (const q of cand){
    if (q.x < r.x || q.x > r.x + r.w || q.y < r.y || q.y > r.y + r.h) continue;
    const dd = Math.min(q.x - r.x, r.x + r.w - q.x) + Math.min(q.y - r.y, r.y + r.h - q.y);
    if (dd > deep){ deep = dd; px = q.x; py = q.y; }
  }
  return { nx: best.nx, ny: best.ny, depth: best.depth, px: px, py: py };
}

/* ---------------- 玩家开车 ----------------
   能开的是"停着的车"（测试区投放的那辆、以及卸完兵停稳的车）。
   瘫了 / 打烂了 / 正在进场 / 正在开走的车都不给上。 */
/* 归属：谁在车上这辆车就归谁。
   neutral = 中立（顶置机枪不开火、谁都能开上去）
   enemy   = 敌方控制（机枪会朝你扫射）
   player  = 你正开着
   敌人站到中立车旁边一会儿，就会把它重新接管回去。 */
/* 车的两个字段，语义必须分清（以前都叫 team，读起来像"阵营"）：
   · owner   = 归属：neutral | enemy | player —— 决定"谁能开、开走后算谁的"
   · faction = 阵营：enemy | bandit | neutral | player —— 决定"打谁"（敌我判定只认它）
   truckTeam / truckSetTeam 保留成别名，免得二十来处调用全改。 */
function truckOwner(t){ return (t && (t.owner || t.team)) || 'neutral'; }
function truckTeam(t){ return truckOwner(t); }
function truckFaction(t){
  if (!t) return 'enemy';
  if (t.faction) return t.faction;
  const own = truckOwner(t);
  if (own === 'player') return (typeof combatFaction === 'function') ? combatFaction(player) : 'player';
  if (own === 'neutral') return 'neutral';
  return 'enemy';
}
function truckSetTeam(t, team, by){
  if (!t) return false;
  const _cf = by ? (by.faction || 'enemy') : (team === 'enemy' ? 'enemy' : team);
  if (truckOwner(t) === team && (t.crewFaction || '') === _cf) return false;
  t.owner = team;
  t.team = team;                     /* 兼容旧字段 */
  /* 谁在控制这辆车。接管的人带阵营就跟着走 —— B 势力中立时把车据为己有，
     机枪也不该朝玩家开火（以前只看 team，bandit 接管会直接变成"敌方车"）。 */
  t.crewFaction = _cf;
  t.faction = _cf;
  t.factionTint = (typeof _ftint === 'function') ? _ftint(_cf) : t.factionTint;
  t.reclaimT = 0;
  if (team !== 'enemy') t.mgRage = 0;
  else if (typeof truckMgWake === 'function') truckMgWake(t);
  return true;
}
/* 是不是"车"（不分车型）。车型现在有 truck / truck_apc / truck_pickup，
   所以不能再拿 t.type === 'truck' 直接比 —— 统一看数据里的 kind 字段。 */
function isTruckEntity(t){
  if (!t || !t.type) return false;
  const T = vehicleDef(t.type);
  return !!(T && T.kind === 'truck');
}
function truckCanDrive(t){
  if (!isTruckEntity(t)) return false;
  if (t.wreck || t.gone || t.paralyzed) return false;
  if (truckTeam(t) === 'enemy'){
    /* 敌方控制的车也不是永久锁死：把守着它的人清掉，就能上去重新夺回（m41341）。
       以前这里无条件 false，死亡地带里车被敌人接管之后玩家再也摸不到它。 */
    let guarded = false;
    for (const o of enemies){
      if (!o || o.dead || o.hp <= 0) continue;
      if (dist(o.x, o.y, t.x, t.y) <= t.r + 74){ guarded = true; break; }
    }
    if (guarded) return false;
  }
  if (t.tstate !== 'parked' && t.tstate !== 'deploy_troops' && t.tstate !== 'brake') return false;
  return !!t.solid;
}
function nearestDrivableTruck(){
  let best = null, bd = 1e9;
  for (const t of trucks){
    if (!truckCanDrive(t)) continue;
    const d = dist(player.x, player.y, t.x, t.y);
    if (d < bd){ bd = d; best = t; }
  }
  return (best && bd <= best.r + 104) ? best : null;
}
function truckEnter(t){
  if (!t || playerTruck || player.hp <= 0) return false;
  if (!truckCanDrive(t)) return false;
  playerTruck = t;
  truckSetTeam(t, 'player');
  t.tstate = 'driven';
  t.spd = 0; t.door = 0; t.tt = 0; t.solid = true;
  player.kickX = 0; player.kickY = 0;
  player.x = t.x; player.y = t.y;
  navPatchTruck(t);
  if (typeof truckSfxStop === 'function') truckSfxStop();
  sfxTruckDoor();
  setMsg('上车了 · 开：WASD　下车：T', 2.4);
  return true;
}
function truckExit(){
  if (!playerTruck) return false;
  const t = playerTruck;
  const L = cur();
  const side = t.ang + Math.PI / 2;
  const px = t.x + Math.cos(side) * (t.r + 26);
  const py = t.y + Math.sin(side) * (t.r + 26);
  const sp = safeSpot(L, { x: px, y: py }, player.r + 2);
  player.x = sp.x; player.y = sp.y;
  playerTruck = null;
  if (typeof vehEngineSilence === 'function') vehEngineSilence();
  truckSetTeam(t, 'neutral');
  t.tstate = 'parked'; t.spd = 0; t.solid = true;
  navPatchTruck(t);
  pushOutTruckCircle(player, t);
  setMsg('下车', 1.0);
  return true;
}
function toggleTruckSeat(){
  if (playerTruck) return truckExit();
  const t = nearestDrivableTruck();
  if (t) return truckEnter(t);
  setMsg('附近没有能开的车', 1.2);
  return false;
}
function truckWreckEject(t){
  if (playerTruck !== t) return;
  playerTruck = null;
  if (typeof vehEngineSilence === 'function') vehEngineSilence();
  truckSetTeam(t, 'neutral');
  const ang = t.ang + rand(-0.7, 0.7);
  const sp = safeSpot(cur(), { x: t.x + Math.cos(ang) * (t.r + 34), y: t.y + Math.sin(ang) * (t.r + 34) }, player.r + 2);
  player.x = sp.x; player.y = sp.y;
  player.kickX = Math.cos(ang) * 1500; player.kickY = Math.sin(ang) * 1500;
  player.stunT = Math.max(player.stunT || 0, 0.6);
  visionBlur = Math.max(visionBlur, 0.7);
  camShake = Math.max(camShake, 1.8);
  if (!player.god){
    const dmg = 26;
    player.hp -= absorbArmor(dmg, 'blast');
    hurtNum(dmg); stOnHurt(dmg, 'blast');
    if (player.hp <= 0) markDeath('blast', t, dmg, ang);
  }
  setMsg('车被打爆了 · 你被甩了出来', 2.4);
}
const TRUCK_DRIVE = {
  /* accel 从 620 降到 330：这车是运兵车不是卡丁车，起步要有一段肉感。
     转向也从 2.35 收到 1.75，并改成"只有滚起来才转得动"（见 truckDrive）。 */
  accel: 330, brake: 880, maxFwd: 620, maxRev: 320, drag: 1.9, turn: 1.75,
  revAccel: 240,                 /* 倒车加速度（比前进还肉，起步同样走曲线） */
  /* --- 撞东西：车身尺寸与手感 --- */
  bodyHL: TRUCK_BODY.HL, bodyHW: TRUCK_BODY.HW,  /* 车壳半长 / 半宽：同一数据源 */
  ramKick: 16,                   /* 撞上瞬间车体视觉后坐的最大像素 */
  ramYaw: 2.4,                   /* 侧面撞上的偏航冲量（弧度/秒） */
  ramStop: 0.055,                /* 撞上瞬间的顿帧时长 */
  ramEnemyMinTiny: 14,           /* 低于这个速度压到人只推不撞（倒车也能撞） */
  /* --- 撞东西（m26089）--- */
  ramGlassSpd: 120,      /* 低于这个速度顶不碎玻璃 */
  ramCrateK: 0.16,       /* 撞木箱的伤害 = 速度 × 这个系数 */
  ramCrateMinSpd: 70,    /* 低于这个速度撞不动箱子，只会顶住 */
  ramBounceK: 0.34,      /* 撞结实掩体时反弹回多少速度（0.34 = 保留三成，往回弹） */
  ramHardSpd: 150,       /* 低于这个速度撞硬墙不算"冲击"（不吃车损、不响） */
  selfHurtK: 0.045,      /* 车自己吃多少伤 = 撞墙速度 × 这个系数 */
  ramEnemyK: 0.40,       /* 撞人的伤害 = 速度 × 这个系数（车速下调后提到 0.40，全速仍是一发要命） */
  ramEnemyMin: 160       /* 低于这个速度只是把人顶开，不算撞 */
};


/* ── 开车撞世界（m26089）─────────────────────────────────────────────
   玻璃：撞碎，不减速多少
   木箱：按速度算伤害，打得穿就直接开过去，打不穿就弹回来
   结实掩体：弹回来 + 撞点冒火星 + 车自己吃一点伤
   返回值：'through' = 这一帧可以继续开过去；'hard' = 撞不动，要反弹 */
function truckRamWall(t, w, spd0, hit){
  if (!w || w.dead) return 'through';
  const B = TRUCK_DRIVE;
  const hx = hit.px, hy = hit.py;             /* 真正的撞击点（车壳扎进墙的那个点） */
  const back = Math.atan2(-hit.ny, -hit.nx);   /* 碎屑全往"车撞过来的反方向"喷 */
  const mat = wallMat(w);

  /* 玻璃：够快就哗啦，撞点那一小块整片碎开 */
  if (w.glass || w.cov === 'glass'){
    if (spd0 < B.ramGlassSpd){
      for (let i = 0; i < 4; i++)
        spawnPart(hx, hy, back + fxRand(-1.2, 1.2), fxRand(60, 160), fxRand(0.10, 0.2), 'mspark', fxRand(0.8, 1.6));
      return 'hard';
    }
    shatterGlass(w, hx, hy, t.ang);
    sfxGlass(1, hx, hy);
    for (let i = 0; i < 26; i++)
      spawnPart(hx, hy, back + fxRand(-1.35, 1.35), fxRand(180, 560), fxRand(0.25, 0.6), 'chip', fxRand(1.0, 2.2));
    camShake = Math.max(camShake, 0.45);
    hitStopT = Math.max(hitStopT || 0, B.ramStop * 0.7);
    t.spd *= 0.90;
    navPatchTruck(t);
    return 'through';
  }

  /* 木箱 / 可破坏物：木头碎裂声，按速度算伤害 */
  if (w.brk){
    /* 低速顶住也算"碰到了"：出一点木头闷响和木屑，不能一声不吭 */
    if (spd0 < B.ramCrateMinSpd){
      sfxCrack(true);
      for (let i = 0; i < 5; i++)
        spawnPart(hx, hy, back + fxRand(-0.8, 0.8), fxRand(40, 140), fxRand(0.14, 0.3), 'chip', fxRand(0.9, 1.8));
      return 'hard';
    }
    /* m19950：撞建筑伤害按速度分档加成（慢顶 1.0、中速 +10%、快 +20%、全速 +30%） */
    const _mxFW = (truckDriveOf(t).maxFwd || 620);
    const _kSpd = Math.min(1, spd0 / _mxFW);
    const _ramMul = _kSpd >= 0.85 ? 1.30 : (_kSpd >= 0.55 ? 1.20 : (_kSpd >= 0.30 ? 1.10 : 1.00));
    const dmg = Math.max(1, Math.round(spd0 * B.ramCrateK * _ramMul));
    const _hp0 = w.hp;
    damageWall(w, dmg, hx, hy, t.ang);
    for (let i = 0; i < 14; i++)
      spawnPart(hx, hy, back + fxRand(-0.9, 0.9), fxRand(90, 380), fxRand(0.22, 0.55), 'chip', fxRand(1.4, 3.0));
    for (let i = 0; i < 6; i++)
      spawnPart(hx, hy, back + fxRand(-1.2, 1.2), fxRand(40, 150), fxRand(0.20, 0.45), 'dust', fxRand(1.6, 3.0));
    spawnPart(hx, hy, 0, 0, 0.10, 'flash', 8);
    camShake = Math.max(camShake, 0.30 + Math.min(0.5, spd0 / 1400));
    hitStopT = Math.max(hitStopT || 0, B.ramStop);
    /* 声音按材质分：木箱是木头裂、铁皮是金属、其余是闷响 + 土声 */
    if (w.cov === 'crate' || w.cov === 'crate2'){ sfxCrack(false); sfxSlam(true); }
    else if (wallMat(w) === 'metal'){ sfxMetalHit(hx, hy); sfxSlam(true); }
    else { sfxCrack(false); sfxDirtHit(hx, hy); sfxThud(); }
    if (w.dead && _hp0 > 0){
      t.spd *= 0.78;
      navPatchTruck(t);
      return 'through';
    }
    return 'hard';
  }

  /* 结实掩体：金属是沉闷巨响 + 金属火花，石头是闷响 + 灰尘碎渣 */
  for (let i = 0; i < 18; i++)
    spawnPart(hx, hy, back + fxRand(-1.1, 1.1), fxRand(240, 780), fxRand(0.10, 0.30), 'mspark', fxRand(1.2, 2.6));
  if (mat === 'metal'){
    hotMarks.push({ x: hx, y: hy, t: 0, dur: 2.0 });
    sfxMetalHit(hx, hy);
    sfxSlam(true);                      /* 金属那一下要"低、闷、厚" */
  } else {
    for (let i = 0; i < 9; i++)
      spawnPart(hx, hy, back + fxRand(-0.9, 0.9), fxRand(50, 220), fxRand(0.16, 0.38), 'dust', fxRand(1.8, 3.4));
    for (let i = 0; i < 4; i++)
      spawnPart(hx, hy, back + fxRand(-0.8, 0.8), fxRand(70, 220), fxRand(0.18, 0.34), 'chip', fxRand(1.0, 2.0));
    sfxDirtHit(hx, hy);
    sfxThud();
  }
  spawnPart(hx, hy, 0, 0, 0.12, 'flash', 9);
  spawnPart(hx, hy, 0, 0, 0.26, 'ring', 14);
  return 'hard';
}

/* 车撞人：按速度给伤害，人被顶开 + 晕一下。撞死就走正常的死亡流程 */
function truckRamEnemies(t, dt){
  const B = TRUCK_DRIVE;
  const spd = Math.abs(t.spd);
  const c = Math.cos(t.ang), sn = Math.sin(t.ang);
  const _dt = (typeof dt === 'number' && dt > 0) ? dt : (1/60);
  for (const e of enemies.slice()){
    if (!e || e.dead) continue;
    /* ramCd 的递减现在只在 eCdTick 里（敌人主循环每帧调一次）。
       这里以前是自己写、自己减，别处再加一个 e.ramCd = 0.28 就永远掉不下来 ——
       被撞过一次的人整局免疫撞伤，查了很久。 */
    
    const er = e.r || 12;
    const dx = e.x - t.x, dy = e.y - t.y;
    const lx = dx * c + dy * sn;              /* 沿着车头方向 */
    const ly = -dx * sn + dy * c;             /* 车身的横向 */
    /* 人自己冲过来撞车也算撞：用"上一帧位移"估他的速度（分离之前记，别把被车顶开算成他跑得快） */
    const _px = (e._rx === undefined) ? e.x : e._rx;
    const _py = (e._ry === undefined) ? e.y : e._ry;
    const eSpd = (e._rx === undefined) ? 0 : Math.hypot(e.x - _px, e.y - _py) / _dt;
    const limX = B.bodyHL + er + 2, limY = B.bodyHW + er + 2;
    /* 用"矩形 + 人的半径"判碰：这样侧擦、倒车压人都能吃到 */
    if (Math.abs(lx) > limX + 1 || Math.abs(ly) > limY + 1) continue;

    /* ── ① 先把人从车壳里挤出去（每一帧都做，跟"这一帧能不能再吃伤害"无关）──
       以前这一步写在"能扣血"的分支里，还带 e.ramCd 冷却：
       冷却期间的 0.28 秒里车又往前开了 3px×若干帧，人就一点点陷进车壳，
       等冷却结束他已经过了中线 —— 表现为"从敌人身上碾过去，无视这块障碍物"。
       现在只要重叠就立刻分离，冷却只决定"要不要结算伤害"。 */
    let ox = lx, oy = ly;
    if (Math.abs(ly) <= B.bodyHW){
      /* 人在车身正下方（车道里）：沿车头/车尾方向推到壳外，绝不让他留在车壳里 */
      ox = (lx >= 0 ? 1 : -1) * limX;
    } else if (Math.abs(lx) <= B.bodyHL){
      oy = (ly >= 0 ? 1 : -1) * limY;         /* 侧擦：往侧面推 */
    } else {
      const overX = limX - Math.abs(lx), overY = limY - Math.abs(ly);
      if (overX <= overY) ox = (lx >= 0 ? 1 : -1) * limX;
      else oy = (ly >= 0 ? 1 : -1) * limY;
    }
    e.x = t.x + c * ox - sn * oy;
    e.y = t.y + sn * ox + c * oy;
    e._rx = e.x; e._ry = e.y;        /* 分离后的位置：下一帧拿它算"他自己跑了多快" */

    /* ── ② 结算伤害：冷却中 / 速度不够就只分离不打 ── */
    const hitSpd = spd;      /* 只算车自己的速度；人自己走进车位不算被撞 */
    if (eCd(e, 'ramCd') > 0 || hitSpd < B.ramEnemyMinTiny) continue;

    /* 撞点：车壳上离人最近的那个点 —— 火花和人一起从这儿飞出去 */
    const qx = clamp(lx, -B.bodyHL, B.bodyHL), qy = clamp(ly, -B.bodyHW, B.bodyHW);
    const px = t.x + c * qx - sn * qy, py = t.y + sn * qx + c * qy;
    const a = Math.atan2(e.y - t.y, e.x - t.x);          /* 人被撞飞的方向 */
    const raw = Math.max(4, Math.round(hitSpd * B.ramEnemyK));
    const dmg = absorbEnemyArmor(e, raw, 'blast');
    e.hp = (e.hp === undefined ? 100 : e.hp) - dmg;
    const killed = e.hp <= 0;
    registerHit(e, a, dmg, killed, false);
    spawnDamageNum(e.x, e.y - 30, dmg, killed, false);
    impactFx(px, py, a, true, 22, false);
    eCdSet(e, 'ramCd', 0.28);
    /* 撞完再甩出去一截，别贴着车壳蹭 */
    e.x += Math.cos(a) * 18; e.y += Math.sin(a) * 18;
    const _L = cur();
    for (const w of _L.walls) pushOutCircle(e, e.r, w);
    for (const ot of trucks) if (ot !== t && ot.solid) pushOutTruckCircle(e, ot);
    e.x = clamp(e.x, 14, _L.w - 14); e.y = clamp(e.y, 14, _L.h - 14);
    if (killed) killTestEnemy(e);
    else {
      enemyStun(e, 0.45 + Math.min(0.9, hitSpd / 900));
      alertByHit(e, a);
    }
    camShake = Math.max(camShake, 0.25 + Math.min(0.45, hitSpd / 1600));
    hitStopT = Math.max(hitStopT || 0, B.ramStop * 0.6);
    sfxSlam(true);
    gameTruckKick(t, -Math.cos(a), -Math.sin(a), Math.min(1, spd / 600));
    logInfo('truck', '车撞人 · 速度 ' + Math.round(spd) + ' · 伤害 ' + dmg);
  }
}

/* 撞上东西的"后坐"：车体视觉上往后退一截 + 侧撞时车头被别歪 */
function gameTruckKick(t, nx, ny, k){
  const B = TRUCK_DRIVE;
  t.ramOX = (t.ramOX || 0) + nx * B.ramKick * k;
  t.ramOY = (t.ramOY || 0) + ny * B.ramKick * k;
  /* 撞击方向与车头方向夹角越大 = 越像侧撞 → 车头被带偏 */
  const fx = Math.cos(t.ang), fy = Math.sin(t.ang);
  const dot = fx * nx + fy * ny;                 /* ±1 正面/追尾，0 = 侧撞 */
  const side = 1 - Math.abs(dot);
  if (side > 0.35){
    const crs = fx * ny - fy * nx;
    t.ramYawV = (t.ramYawV || 0) + (crs >= 0 ? 1 : -1) * B.ramYaw * side * k;
  }
}

/* 车壳和另一辆车的碰撞：和墙用同一个 SAT，nx/ny 是"从那辆车指向我"的法线 */
function truckHitAt(x, y, ang, self){
  for (const ot of trucks){
    if (ot === self || !ot.solid || ot.tstate === 'gone' || ot.dead) continue;
    const h = obbVsRect(x, y, ang, truckRect(ot));
    if (h) return { t: ot, hit: h };
  }
  return null;
}

/* 两辆车撞上了：双方都掉血，火花在接触点，谁都快不了 */
function truckBumpTruck(t, ot, spd0, hit){
  const kIn = Math.max(0, -(Math.cos(t.ang) * hit.nx + Math.sin(t.ang) * hit.ny));
  const dmg = Math.max(8, Math.round(spd0 * 0.24 * (0.45 + 0.55 * kIn)));
  damageTruck(t, Math.round(dmg * 0.55), Math.atan2(-hit.ny, -hit.nx));
  damageTruck(ot, dmg, Math.atan2(hit.ny, hit.nx));
  const px = hit.px, py = hit.py;
  const back = Math.atan2(-hit.ny, -hit.nx);
  for (let i = 0; i < 16; i++){
    spawnPart(px, py, back + fxRand(-1.1, 1.1), fxRand(120, 460), fxRand(0.10, 0.28), 'mspark', fxRand(1.0, 2.2));
  }
  for (let i = 0; i < 5; i++) hotMarks.push({ x: px + fxRand(-6, 6), y: py + fxRand(-6, 6), t: 0, dur: 1.4 });
  for (let i = 0; i < 4; i++) spawnPart(px, py, fxRand(0, TAU), fxRand(30, 90), fxRand(0.35, 0.8), 'smoke', fxRand(6, 11));
  gameTruckKick(t, hit.nx, hit.ny, clamp(spd0 / 360, 0.12, 2.2));
  sfxMetalHit(px, py); sfxSlam(true);
  camShake = Math.max(camShake, 0.45 + Math.min(0.9, spd0 / 800));
  hitStopT = Math.max(hitStopT || 0, TRUCK_DRIVE.ramStop);
  /* 被撞的那辆如果是停着的，就把它顶开一点点，别让两辆车长期重叠 */
  if (ot.tstate === 'parked'){
    ot.x += hit.nx * 2.2; ot.y += hit.ny * 2.2;
    navPatchTruck(ot);
  }
  return dmg;
}

/* 玩家驾驶手感：每款车在自己数据里带一套 drive（data/vehicles.js），
   没给的字段由数据层 mk() 从运兵车继承，这里只做"没数据就退回全局"的兜底。 */
function truckDriveOf(t){
  const T = (typeof vehicleDef === 'function' && t) ? vehicleDef(t.type) : null;
  return (T && T.drive) || TRUCK_DRIVE;
}

/* 纯函数：一帧油门。dir = 1 前进 / -1 倒车 / 0 松油门滑行。
   曲线里的"起步肉"和"接近极速发软"都按本车极速等比缩放，所以换了车手感才对得上。 */
function truckThrottle(D, spd, dt, dir){
  const DD = D || TRUCK_DRIVE;
  const maxF = DD.maxFwd || 620, maxR = DD.maxRev || 320;
  const fwdRamp = Math.max(40, maxF * 0.42);   /* 基准车 620×0.42 ≈ 260，与旧写死值一致 */
  const revRamp = Math.max(30, maxR * 0.56);   /* 基准车 320×0.56 ≈ 180，同上 */
  let out = spd;
  if (dir > 0){
    const aK = 0.10 + 0.90 * Math.min(1, Math.abs(spd) / fwdRamp);
    const topK = 1 - 0.55 * Math.min(1, Math.abs(spd) / maxF);
    out = spd + (DD.accel || 330) * aK * topK * dt;
  }
  else if (dir < 0){
    if (spd > 0) out = spd - (DD.brake || 880) * dt;              /* 先刹车 */
    else {
      const aK = 0.18 + 0.82 * Math.min(1, Math.abs(spd) / revRamp);
      out = spd - (DD.revAccel || 190) * aK * dt;
    }
  }
  else out = spd * Math.max(0, 1 - (DD.drag || 1.9) * dt);
  /* 极速在这里就封住：调用方（truckDrive）不用再关心，纯仿真也拿不到超速的数 */
  return Math.max(-maxR, Math.min(maxF, out));
}

function truckDrive(dt, mx, my){
  const t = playerTruck; if (!t) return;
  const D = truckDriveOf(t);
  if (my < 0){
    /* 起步特别肉：0 速时只有一成的推力，滚到约极速的 42% 才给满；接近极速时再软下来 */
    t.spd = truckThrottle(D, t.spd, dt, 1);
  }
  else if (my > 0){
    t.spd = truckThrottle(D, t.spd, dt, -1);
  }
  else t.spd = truckThrottle(D, t.spd, dt, 0);
  t.spd = clamp(t.spd, -D.maxRev, D.maxFwd);
  t.wheelRot = (t.wheelRot || 0) + t.spd * dt / 9;   /* 轮子转角：半径约 9px */
  /* 开快了后轮扬尘：俯视角度看不出轮胎花纹在转，但烟尘一动就知道车在跑 */
  if (Math.abs(t.spd) > 220 && typeof spawnPart === 'function'){
    t.dustT = (t.dustT || 0) - dt;
    if (t.dustT <= 0){
      t.dustT = 0.05;
      const back = t.ang + Math.PI;
      const side = t.ang + Math.PI / 2;
      for (const sgn of [-1, 1]){
        const px = t.x + Math.cos(back) * 30 + Math.cos(side) * 18 * sgn;
        const py = t.y + Math.sin(back) * 30 + Math.sin(side) * 18 * sgn;
        spawnPart(px, py, back + rand(-0.5, 0.5), rand(20, 70), rand(0.35, 0.7), 'smoke', rand(4, 8));
      }
    }
  }
  /* 归零阈值必须小于"一帧的加速度"。起步阶段一帧只加 330×0.10/60 ≈ 0.55，
     阈值取 0.6 就会每帧刚加完又被清零，车永远起不来（踩过一次坑）。 */
  if (Math.abs(t.spd) < 0.05) t.spd = 0;
  if (mx !== 0 && Math.abs(t.spd) > 1){
    const k = clamp(Math.abs(t.spd) / 220, 0.22, 1);
    t.ang = normAng(t.ang + mx * D.turn * dt * k * (t.spd < 0 ? -1 : 1));
  }
  const L = cur();
  /* 后坐与偏航回正（视觉层，不影响物理坐标） */
  const _dec = Math.max(0, 1 - dt * 9);
  t.ramOX = (t.ramOX || 0) * _dec;
  t.ramOY = (t.ramOY || 0) * _dec;
  if (t.ramOX * t.ramOX + t.ramOY * t.ramOY < 0.02){ t.ramOX = 0; t.ramOY = 0; }
  t.ramYaw = (t.ramYaw || 0) + (t.ramYawV || 0) * dt;
  t.ramYawV = (t.ramYawV || 0) * Math.max(0, 1 - dt * 10);
  t.ramYaw *= Math.max(0, 1 - dt * 7);
  if (Math.abs(t.ramYaw) < 0.002) t.ramYaw = 0;

  const outOfBounds = (x, y) => (x - TRUCK_BODY.HL < 4 || y - TRUCK_BODY.HL < 4 ||
                                 x + TRUCK_BODY.HL > L.w - 4 || y + TRUCK_BODY.HL > L.h - 4);
  /* 车壳在这一位置的碰撞：返回 {w, hit} 或 null */
  function shellHitAt(x, y){
    const probe = { x: x, y: y, ang: t.ang };
    for (const w of L.walls){
      if (w.dead) continue;
      const h = obbVsRect(x, y, t.ang, w);
      if (h) return { w: w, hit: h };
    }
    return null;
  }
  /* m19950：门不在 L.walls 里 —— 以前车直接从关着的门里开过去（穿模）。
     这里单独给车壳做一次门碰撞：滑门 / 平开门都按"关着时的门板矩形"算。 */
  function shellDoorHitAt(x, y){
    if (typeof doors === 'undefined' || !doors) return null;
    for (const d of doors){
      if (!d || d.broken || d.hp <= 0) continue;
      if ((d.open || 0) > 0.6) continue;              /* 开着就让它过去 */
      const r = { x: (d.fx != null ? d.fx : d.x), y: (d.fy != null ? d.fy : d.y),
                  w: (d.fw != null ? d.fw : d.w), h: (d.fh != null ? d.fh : d.h) };
      if (!(r.w > 0) || !(r.h > 0)) continue;
      const h = obbVsRect(x, y, t.ang, r);
      if (h) return { d: d, hit: h };
    }
    return null;
  }

  const dstep = t.spd * dt;
  const sg = t.spd >= 0 ? 1 : -1;
  const spd0 = Math.abs(t.spd);
  const nx = t.x + Math.cos(t.ang) * dstep;
  const ny = t.y + Math.sin(t.ang) * dstep;
  const hitRun = shellHitAt(nx, ny);
  const hitDoor = hitRun ? null : shellDoorHitAt(nx, ny);
  const hitCar = (hitRun || hitDoor) ? null : truckHitAt(nx, ny, t.ang, t);

  if (!outOfBounds(nx, ny) && !hitRun && !hitCar && !hitDoor){
    t.x = nx; t.y = ny;                       /* 一路畅通 */
  } else if (!hitRun && hitCar && eCd(t, 'ramCd') <= 0 && spd0 > 10){
    /* ── 撞上另一辆车：以前两辆车会直接穿过去 ── */
    const h = hitCar.hit;
    truckBumpTruck(t, hitCar.t, spd0, h);
    eCdSet(t, 'ramCd', 0.20);
    const fx2 = Math.cos(t.ang), fy2 = Math.sin(t.ang);
    const headOn2 = Math.abs(fx2 * h.nx + fy2 * h.ny);
    const _mxF2 = (truckDriveOf(t).maxFwd || 620);
    const bounceK2 = 0.14 + 0.30 * Math.min(1, spd0 / _mxF2);
    t.spd = -sg * spd0 * bounceK2 * (0.25 + 0.75 * headOn2);
    if (Math.abs(t.spd) < 12) t.spd = 0;
  } else if (hitDoor && eCd(t, 'ramCd') <= 0 && spd0 > 10){
    /* ── 撞门（m19950）：门是独立对象，以前既挡不住车也不掉血 ── */
    const dh = hitDoor.hit, dd = hitDoor.d;
    const dhx = dh.px, dhy = dh.py;
    const ddmg = Math.max(24, Math.round(spd0 * 0.28));
    if (typeof damageDoor === 'function') damageDoor(dd, ddmg, dhx, dhy, t.ang, false);
    if (typeof impactWallFx === 'function') impactWallFx(dhx, dhy, t.ang);
    if (typeof sfxSlam === 'function') sfxSlam(true);
    if (typeof sfxMetalHit === 'function') sfxMetalHit(dhx, dhy);
    camShake = Math.max(camShake, 0.42 + Math.min(0.5, spd0 / 900));
    hitStopT = Math.max(hitStopT || 0, TRUCK_DRIVE.ramStop);
    const fxD = Math.cos(t.ang), fyD = Math.sin(t.ang);
    const headOnD = Math.abs(fxD * dh.nx + fyD * dh.ny);
    const _mxFD = (truckDriveOf(t).maxFwd || 620);
    const bounceKD = 0.14 + 0.34 * Math.min(1, spd0 / _mxFD);
    t.spd = -sg * spd0 * bounceKD * (0.25 + 0.75 * headOnD);
    if (Math.abs(t.spd) < 12) t.spd = 0;
    gameTruckKick(t, dh.nx, dh.ny, clamp(spd0 / 360, 0.10, 2.4));
    eCdSet(t, 'ramCd', 0.18);
    if (dd.broken || dd.hp <= 0){ t.x = nx; t.y = ny; }   /* 门被撞烂了才开过去 */
  } else if (hitRun && eCd(t, 'ramCd') <= 0 && spd0 > 10){
    /* ── 第一次贴上（或贴着墙继续挤的下一拍）：反馈必须立刻给 ──
       以前这里先试"沿 x 滑 / 沿 y 滑"，斜着撞墙时永远能滑 → 车已经贴脸了却没有火花也没有声音，
       要等滑到彻底卡死才炸一下，看上去就是"延迟一两秒才冒火花"。 */
    const hit = hitRun.hit;
    const ram = truckRamWall(t, hitRun.w, spd0, hit);
    eCdSet(t, 'ramCd', 0.18);                  /* 同一面墙 0.18s 内的重复节拍不再炸 */
    if (ram === 'through'){
      t.x = nx; t.y = ny;                      /* 玻璃碎了 / 木箱塌了：开过去 */
    } else {
      const fx = Math.cos(t.ang), fy = Math.sin(t.ang);
      const headOn = Math.abs(fx * hit.nx + fy * hit.ny);
      /* 后坐量随速度走：慢碰只有一点点，高速撞才明显 */
      gameTruckKick(t, hit.nx, hit.ny, clamp(spd0 / 360, 0.10, 2.4));
      if (spd0 > TRUCK_DRIVE.ramHardSpd){
        damageTruck(t, Math.round(spd0 * TRUCK_DRIVE.selfHurtK * (0.4 + 0.6 * headOn)), t.ang + Math.PI);
        camShake = Math.max(camShake, 0.5 + Math.min(1.0, spd0 / 700));
        hitStopT = Math.max(hitStopT || 0, TRUCK_DRIVE.ramStop + Math.min(0.06, spd0 / 10000));
      }
      /* 反弹速度也随速度走：慢速几乎是停住，高速才被明显弹开 */
      const _mxF = (truckDriveOf(t).maxFwd || 620);
      const bounceK = 0.14 + 0.34 * Math.min(1, spd0 / _mxF);   /* 按本车极速归一：撞越快弹越狠 */
      t.spd = -sg * spd0 * bounceK * (0.25 + 0.75 * headOn);
      if (Math.abs(t.spd) < 12) t.spd = 0;
    }
  } else if (Math.abs(nx - t.x) > 0.02 && !outOfBounds(nx, t.y) && !shellHitAt(nx, t.y) && !truckHitAt(nx, t.y, t.ang, t)){
    t.x = nx; t.spd *= 0.80;                  /* 擦着墙滑过去 */
  } else if (Math.abs(ny - t.y) > 0.02 && !outOfBounds(t.x, ny) && !shellHitAt(t.x, ny) && !truckHitAt(t.x, ny, t.ang, t)){
    t.y = ny; t.spd *= 0.80;
  } else {
    /* 这一帧贴死了但撞的反馈刚给过（ramCd 未到）：只掉速，不重复炸
       注意别把速度写死成 0 —— 那样连倒车都攒不起来，车会永远钉在原地 */
    t.spd *= 0.55;
  }

  /* ── 脱困：车壳绝不允许停在墙里 ──────────────────────────────
     在墙角/建筑拐角处打方向时，新的车身角度可能已经和墙重叠；
     一旦重叠，往前走、横着滑、倒车三种候选位置全都会被判"撞"，
     车就死在角落（连倒车都出不来）。这里按 SAT 给出最小分离向量把车顶出去。 */
  let _pushed = false;
  for (let k = 0; k < 4; k++){
    const pen = shellHitAt(t.x, t.y);
    if (!pen) break;
    const h = pen.hit;
    const push = (h.depth || 0) + 0.8;
    t.x += h.nx * push;
    t.y += h.ny * push;
    t.spd *= 0.35;
    _pushed = true;
  }
  if (_pushed) navPatchTruck(t);            /* 只在真的被顶出来时补一次导航格子 */
  t.x = clamp(t.x, TRUCK_BODY.HL + 5, L.w - TRUCK_BODY.HL - 5);
  t.y = clamp(t.y, TRUCK_BODY.HL + 5, L.h - TRUCK_BODY.HL - 5);
  /* 撞人：前进、倒车、侧擦都算（判碰用车壳矩形 + 人的半径）
     注意：车壳比 t.r 的正方形窄，敌人被 pushOutTrucks 推到车身两侧时正好贴着边，
     所以这里留 3px 容差，否则"侧面撞人"永远判不上。 */
  truckRamEnemies(t, dt);
  player.x = t.x; player.y = t.y;
  if (Math.abs(t.spd) > 60){
    t.smokeAcc = (t.smokeAcc || 0) + dt * (0.6 + Math.abs(t.spd) / 500);
    while (t.smokeAcc >= 0.06){
      t.smokeAcc -= 0.06;
      const rx = t.x - Math.cos(t.ang) * 30, ry = t.y - Math.sin(t.ang) * 30;
      const ox = -Math.sin(t.ang) * 24, oy = Math.cos(t.ang) * 24;
      const sd = Math.random() < 0.5 ? 1 : -1;
      spawnPart(rx + ox*sd + rand(-6,6), ry + oy*sd + rand(-6,6), rand(0, TAU),
                rand(10, 34), rand(0.22, 0.45), 'dust', rand(2.5, 5));
    }
  }
}

/* 动着的车是真的会撞人的：进场漂移、急刹、开走这三段都算。
   以前只有停稳之后才有碰撞（`if (t.solid)`），所以漂移进来的那两秒
   等于一段纯动画 —— 玩家站着不动，车就从身上开过去了。 */
function truckHitPlayer(t){
  if (!t || !player || player.hp <= 0) return false;
  if (t === playerTruck) return false;
  if (t.tstate !== 'drift_in' && t.tstate !== 'brake' && t.tstate !== 'leave') return false;
  const speed = Math.abs(t.spd || 0);
  if (speed < 90) return false;              /* 快停下来了就不算撞 */
  if ((t.hitCd || 0) > 0) return false;      /* 刚撞过，别在车壳上被连碾 */
  const probe = { x: player.x, y: player.y, r: player.r };   /* r 一定要带上：不带半径就只会判「圆心在车里」 */
  if (!pushOutTruckCircle(probe, t)) return false;   /* 没碰上（精确到车身，不再用 AABB） */
  const T = vehicleDef(t && t.type) || enemyType(t);  /* 未知旧输入仍走原回退 */
  const k = clamp(speed / 700, 0.55, 1.35);
  const dmg = Math.round((T.hitDmg === undefined ? 62 : T.hitDmg) * k);
  const ang = Math.atan2(player.y - t.y, player.x - t.x);
  /* 先把人从车壳里推出来，再往外甩：否则下一帧还在里面，会被再撞一次 */
  player.x = probe.x; player.y = probe.y;
  const kb = (T.hitKb === undefined ? 2400 : T.hitKb);
  player.kickX = Math.cos(ang) * kb;
  player.kickY = Math.sin(ang) * kb;
  player.stunT = Math.max(player.stunT || 0, (T.hitStun === undefined ? 0.75 : T.hitStun));
  if (!player.god){
    player.hp -= absorbArmor(dmg, 'blast');
    stOnHurt(dmg, 'blast');
    if (player.hp <= 0) markDeath('blast', t, dmg, ang);
  }
  hurtNum(dmg); player.flash = 1; hitFlash = 1;
  hurtDir(ang, dmg);
  /* 撞车和督军撞人同一套"重击"表现：糊得很重、退得快 */
  visionBlur = Math.max(visionBlur, 0.88);
  visionBlind = Math.max(visionBlind, 0.64);
  blindAlphaK = 0.50;
  camShake = Math.max(camShake, 2.3);
  hitStopT = Math.max(hitStopT, 0.15);
  sfxSlam(true); sfxThud();
  truckSparks(player.x, player.y, ang);
  spillBlood(player.x, player.y, 16);
  t.hitCd = (T.hitCd === undefined ? 0.9 : T.hitCd);
  logWarn('hurt', '被运兵车撞了 · -' + Math.round(dmg) + ' HP');
  setMsg('被运兵车撞了 · 站不稳', 1.5);
  return true;
}

/* 漂移进场 / 急刹 / 开走时撞到敌人。
   以前只有 truckHitPlayer()：A 的车呼啸着从 B 势力身上穿过去，一点事没有 ——
   看着就像这车"不属于敌方单位"。现在按阵营判：只撞敌对阵营（A 撞 B 会，
   A 撞 A 不会，玩家开的车撞谁看 weaponFaction）。
   伤害走和子弹同一条结算链（先削甲、再扣血、再走打击感），所以飘字和护甲都对。 */
function truckHitEnemies(t){
  if (!t || !enemies.length) return 0;
  if (t.tstate !== 'drift_in' && t.tstate !== 'brake' && t.tstate !== 'leave') return 0;
  const speed = Math.abs(t.spd || 0);
  if (speed < 90) return 0;
  if ((t.hitCd || 0) > 0) return 0;
  const T = vehicleDef(t && t.type) || enemyType(t);  /* 未知旧输入仍走原回退 */
  const k = clamp(speed / 700, 0.55, 1.35);
  const base = (T.hitDmg === undefined ? 62 : T.hitDmg) * k
             * (T.ramEnemyK === undefined ? 1 : T.ramEnemyK);
  let hit = 0;
  for (const e of enemies){
    if (!e || e.dead || e.hp <= 0) continue;
    /* 阵营：只撞"自己人以外"的。用 weaponWantsFight 的统一口径，
       B 势力接管的车不会去撞 B 的人。 */
    const _fight = (typeof factionWantsFight === 'function')
      ? factionWantsFight(t, e)
      : true;
    if (!_fight) continue;
    const probe = { x: e.x, y: e.y, r: e.r };
    if (!pushOutTruckCircle(probe, t)) continue;
    const ang = Math.atan2(e.y - t.y, e.x - t.x);
    /* 先推出去再结算，否则下一帧还在车壳里，会被反复撞 */
    e.x = probe.x; e.y = probe.y;
    const kb = (T.hitKb === undefined ? 2400 : T.hitKb);
    e.kickX = Math.cos(ang) * kb;
    e.kickY = Math.sin(ang) * kb;
    /* 眩晕统一走状态系统：直接写字段会被 _tStatusDef 的源码扫描抓出来 */
    if (typeof eStatusSet === 'function') eStatusSet(e, 'stun', (T.hitStun === undefined ? 0.75 : T.hitStun));
    const real = absorbEnemyArmor(e, Math.round(base), 'blast');
    e.hp = (e.hp === undefined ? 100 : e.hp) - real;
    if (typeof factionNoteDamage === 'function' && typeof player !== 'undefined' && player){
      /* 记在"玩家的账"上：撞死人对玩家来说等于自己打死的（以后要算分也方便） */
      factionNoteDamage(e, player, real, 'blast');
    }
    const killed = e.hp <= 0;
    if (typeof registerHit === 'function') registerHit(e, ang, real, killed, false);
    if (typeof spawnDamageNum === 'function') spawnDamageNum(e.x, e.y - 30, real, killed, false);
    if (killed){
      if (typeof killTestEnemy === 'function') killTestEnemy(e);
    } else if (typeof alertByHit === 'function') alertByHit(e, ang);
    hit++;
  }
  if (hit){
    t.hitCd = (T.hitCd === undefined ? 0.9 : T.hitCd);
    camShake = Math.max(camShake, 1.1);
    sfxThud();
    logWarn('hurt', '运兵车撞飞了 ' + hit + ' 个敌人 · 车速 ' + Math.round(speed));
    setMsg('运兵车撞飞了 ' + hit + ' 个敌人', 1.2);
  }
  return hit;
}

/* 把一个人从所有"停稳的车"里顶出去。
   以前只有三条路径推车（挨打后退、逃跑、刀手突进），主移动和卡墙自救都漏了，
   于是废铁挡玩家、不挡敌人 —— 敌人直接从车壳里穿过去。 */
/* 所有弹道都把方向与起点转到车身局部坐标。空角不能用世界轴对齐的矩形判命中。 */
const TRUCK_LOCAL_BODY = {x:-TRUCK_BODY.HL,y:-TRUCK_BODY.HW,w:TRUCK_BODY.HL*2,h:TRUCK_BODY.HW*2};
const TRUCK_BODY_REACH = TRUCK_BODY.HL + TRUCK_BODY.HW;
function truckBodyEntry(t,ox,oy,dx,dy,maxLen){
  const c=Math.cos(t.ang||0),sn=Math.sin(t.ang||0),x=ox-t.x,y=oy-t.y;
  return rayEnter(x*c+y*sn,-x*sn+y*c,dx*c+dy*sn,-dx*sn+dy*c,TRUCK_LOCAL_BODY,maxLen);
}
function rayTruckT(t, ox, oy, a, maxLen){
  if(!t)return null;
  const d=truckBodyEntry(t,ox,oy,Math.cos(a),Math.sin(a),maxLen);
  return d<0?null:d;
}
function projectileTruckHit(b){
  if(!trucks.length)return null;
  const dx=b.x-b.px,dy=b.y-b.py,len=Math.hypot(dx,dy),ux=len?dx/len:0,uy=len?dy/len:0;
  let truck=null,distance=len+1;
  for(const t of trucks){
    if(!t||t.tstate==='gone'||t===b.by||t===b.ownTruck)continue;
    const d=truckBodyEntry(t,b.px,b.py,ux,uy,Math.min(len,distance));
    if(d>=0&&d<distance){truck=t;distance=d;}
  }
  return truck?{truck,distance,x:b.px+ux*distance,y:b.py+uy*distance}:null;
}

/* 点是不是在车身里（局部坐标）——你在车上时，车不该把自己挡瞎 */
function insideTruckBody(t, x, y){
  if (!t) return false;
  const c = Math.cos(t.ang || 0), sn = Math.sin(t.ang || 0);
  const dx = x - t.x, dy = y - t.y;
  const lx = dx * c + dy * sn, ly = -dx * sn + dy * c;
  return lx > -TRUCK_BODY.HL && lx < TRUCK_BODY.HL && ly > -TRUCK_BODY.HW && ly < TRUCK_BODY.HW;
}

/* 车壳挡视线：残骸、停着的车、开着的车都是实体，光锥与 LOS 必须被它截断。
   以前只认 L.walls，车在画面里，子弹打得到、人却“看穿”它。 */
function truckOcclSeg(x1, y1, x2, y2){
  if (!trucks.length) return null;
  for (const t of trucks){
    if (!t || t.tstate === 'gone') continue;
    if (insideTruckBody(t, x1, y1)) continue;      /* 起点在车里：你自己就在车上 */
    if (truckHitTest(t,x1,y1,x2,y2)) return t;
  }
  return null;
}

/* 射线打到车壳的距离，没打到就是 maxLen */
function rayToTruck(ox, oy, a, maxLen){
  let best = maxLen;
  if (!trucks.length) return best;
  const dx = Math.cos(a), dy = Math.sin(a);
  const ex = ox + dx * maxLen, ey = oy + dy * maxLen;
  const left = Math.min(ox, ex) - TRUCK_BODY_REACH, right = Math.max(ox, ex) + TRUCK_BODY_REACH;
  const top = Math.min(oy, ey) - TRUCK_BODY_REACH, bottom = Math.max(oy, ey) + TRUCK_BODY_REACH;
  for (const t of trucks){
    if (!t || t.tstate === 'gone' || t.x < left || t.x > right || t.y < top || t.y > bottom) continue;
    if (insideTruckBody(t, ox, oy)) continue;
    const d = truckBodyEntry(t, ox, oy, dx, dy, best);
    if (d >= 0.5 && d < best) best = d;
  }
  return best;
}
/* 把圆从车身（旋转矩形）里精确顶出去。
   以前一律用 truckRect() 这个 AABB：车一斜，盒子比车身大一圈，
   玩家会「明明还有空位却走不过去」，子弹也会打在空处。 */
function pushOutTruckCircle(e, t){
  if (!e || !t) return false;
  const R = e.r || 0;
  const dx = e.x - t.x, dy = e.y - t.y;
  const reach = TRUCK_BODY_REACH + R;
  if (Math.abs(dx) > reach || Math.abs(dy) > reach) return false;
  const c = Math.cos(t.ang || 0), sn = Math.sin(t.ang || 0);
  const hl = TRUCK_BODY.HL, hw = TRUCK_BODY.HW;
  const lx =  dx * c + dy * sn;          /* 世界 → 车身局部 */
  const ly = -dx * sn + dy * c;
  const qx = clamp(lx, -hl, hl), qy = clamp(ly, -hw, hw);
  let ox = lx - qx, oy = ly - qy;
  let d = Math.hypot(ox, oy);
  if (d > R) return false;               /* 没碰上：这个位置视觉上就是空的 */
  let nx, ny, need;
  if (d > 1e-6){
    nx = ox / d; ny = oy / d; need = R - d;
  } else {
    /* 圆心落在车身里：朝最近的一条边推出去 */
    const px = hl - Math.abs(lx), py = hw - Math.abs(ly);
    if (px < py){ nx = lx < 0 ? -1 : 1; ny = 0; need = R + px; }
    else { nx = 0; ny = ly < 0 ? -1 : 1; need = R + py; }
  }
  const wx = nx * c - ny * sn;           /* 局部法线转回世界 */
  const wy = nx * sn + ny * c;
  e.x += wx * need; e.y += wy * need;
  return true;
}
function pushOutTrucks(e){
  if (!trucks.length) return;
  for (const t of trucks){
    if (!t.solid) continue;
    /* 用车壳矩形推人（以前用 t.r 的正方形，比车身宽一圈，
       侧面永远不会真正贴上，所以"侧面撞人没伤害"） */
    pushOutTruckCircle(e, t);
  }
}

/* 射线和矩形求交：返回沿 a 方向撞上矩形的距离，没撞上返回 null。
   （segHitsRect 只回 bool，这里要的是"多远"，好跟敌人比谁更靠前。） */
function rayRectT(ox, oy, a, maxLen, rc){
  const dx = Math.cos(a), dy = Math.sin(a);
  let t0 = 0, t1 = maxLen;
  /* x 方向 */
  if (Math.abs(dx) < 1e-9){
    if (ox < rc.x || ox > rc.x + rc.w) return null;
  } else {
    let ta = (rc.x - ox) / dx, tb = (rc.x + rc.w - ox) / dx;
    if (ta > tb){ const q = ta; ta = tb; tb = q; }
    t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
    if (t0 > t1) return null;
  }
  /* y 方向 */
  if (Math.abs(dy) < 1e-9){
    if (oy < rc.y || oy > rc.y + rc.h) return null;
  } else {
    let ta = (rc.y - oy) / dy, tb = (rc.y + rc.h - oy) / dy;
    if (ta > tb){ const q = ta; ta = tb; tb = q; }
    t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
    if (t0 > t1) return null;
  }
  return t0 <= maxLen ? t0 : null;
}

/* 瘫痪：车被打得太狠、一时半会动不了。
   瘫在原地不动、不开走，车壳持续冒火花 + 往上冒烟；
   车里若还有乘员，状态切换时会立刻强制卸完（见 truckForceDeploy）。
   但它不是废铁 —— 还能继续打，血打空才变废铁（见 damageTruck）。 */
function truckParalyze(t){
  if (!t || t.paralyzed || t.wreck || t.tstate === 'gone') return false;
  t.paralyzed = true;
  t.tstate = 'paralyzed';
  t.tt = 0;
  t.spd = 0;
  t.solid = true;              /* 瘫了也是块铁：挡人挡子弹 */
  t.door = 1;                  /* 故障时强制开门，让剩余乘员立即撤出 */
  t.sparkT = 0; t.smokeT = 0;
  navPatchTruck(t);
  truckForceDeploy(t);         /* 状态已不再走正常卸兵分支，必须在这里清空乘员队列 */
  if (typeof truckSfxStop === 'function') truckSfxStop();   /* 引擎熄了 */
  sfxSlam(true);
  camShake = Math.max(camShake, 1.25);
  hitStopT = Math.max(hitStopT || 0, 0.10);
  /* 炸开一下：电火花 + 一股烟 */
  for (let i = 0; i < 22; i++){
    spawnPart(t.x + rand(-46, 46), t.y + rand(-26, 26), rand(0, TAU),
              rand(150, 620), rand(0.20, 0.55), 'mspark', rand(1.2, 2.6));
  }
  for (let i = 0; i < 5; i++){
    spawnPart(t.x + rand(-30, 30), t.y + rand(-18, 18), -Math.PI/2 + rand(-0.5, 0.5),
              rand(16, 40), rand(0.9, 1.7), 'smoke', rand(9, 16));
  }
  setMsg('运兵车瘫痪了 · 它动不了了，但还没成废铁', 2.0);
  return true;
}

/* 打中车壳：护甲减伤 + 金属火花，绝不走 registerHit（不喷血、不喊疼）。
   报废之后 invul = true，再怎么打也一滴血不掉 —— 它就是块死铁。 */
/* 车被打爆 = 一次爆炸。车上的人和车旁边的人一起完蛋：
   你自己开着的时候没有"被甩出来"这一说，直接算被炸死（数据里 boomKillCrew 可关）。 */
function truckExplode(t){
  /* 连锁殉爆的递归闸门：A 炸 B、B 又炸回 A 时不会无限递归 */
  if (t._booming) return;
  t._booming = 1;
  const T = vehicleDef(t && t.type) || enemyType(t);  /* 未知旧输入仍走原回退 */
  const R = (T.boomR === undefined ? 210 : T.boomR);
  const D = (T.boomDmg === undefined ? 260 : T.boomDmg);
  const youInside = (playerTruck === t);
  /* —— 画面：白光 + 两圈冲击波 + 一团黑烟 —— */
  if (typeof bossBlastFx === 'function') bossBlastFx(t.x, t.y, R);
  spawnPart(t.x, t.y, 0, 0, 0.34, 'flash', R * 0.60);
  spawnPart(t.x, t.y, 0, 0, 0.52, 'ring', R * 0.80);
  spawnPart(t.x, t.y, 0, 0, 0.84, 'ring', R * 1.20);
  for (let i = 0; i < 34; i++){
    const ba = fxRand(0, TAU), bd = fxRand(0, R * 0.5);
    spawnPart(t.x + Math.cos(ba) * bd, t.y + Math.sin(ba) * bd, ba, fxRand(8, 56),
              fxRand(1.0, 2.2), 'bsmoke', fxRand(7, 15));
  }
  scorchMarks.push({ x: t.x, y: t.y, r: R * 0.32, t: 0 });
  fxFlash = Math.max(fxFlash, 1.0);
  camShake = Math.max(camShake, 2.1);
  beep(52, 0.7, 'sawtooth', 0.34, 22);
  noiseBurst(0.8, 320, 1.1, 1.6);
  /* —— 敌人：半径内一律炸死 —— */
  let killed = 0;
  for (const e of enemies.slice()){
    if (!e || e.dead) continue;
    if (dist(t.x, t.y, e.x, e.y) > R) continue;
    e.hp = 0;
    if (typeof killTestEnemy === 'function') killTestEnemy(e);
    else e.dead = true;
    spawnPart(e.x, e.y, 0, 0, 0.22, 'blood', 7);
    killed++;
  }
  /* —— 别的车：殉爆会连累旁边的车（以前只炸人、炸墙、炸你） —— */
  {
    let chain = 0;
    for (const o of trucks.slice()){
      if (!o || o === t || o.gone || o.tstate === 'gone' || o.wreck || o._booming) continue;
      const od = dist(t.x, t.y, o.x, o.y);
      if (od > R) continue;
      const kd = 1 - od / R;
      damageTruck(o, Math.round(D * (0.35 + 0.65 * kd)), Math.atan2(o.y - t.y, o.x - t.x));
      chain++;
    }
    if (chain) logInfo('gun', '殉爆波及 ' + chain + ' 辆车');
  }
  /* —— 建筑：半径内的可破坏墙 / 玻璃一起崩（打不动的墙只留焦痕） —— */
  if (T.boomWall !== false){
    const _L = cur();
    let broke = 0;
    for (const w of _L.walls.slice()){
      if (!w || !w.brk || w.dead) continue;
      const nx = clamp(t.x, w.x, w.x + w.w);
      const ny = clamp(t.y, w.y, w.y + w.h);
      if (Math.hypot(nx - t.x, ny - t.y) > R) continue;
      const wa = Math.atan2(w.y + w.h / 2 - t.y, w.x + w.w / 2 - t.x);
      damageWall(w, 9999, nx, ny, wa);
      broke++;
    }
    if (broke) logInfo('wall', '运兵车殉爆 · 炸塌 ' + broke + ' 处掩体');
  }
  /* —— 你 —— */
  if (youInside){
    playerTruck = null;
    truckSetTeam(t, 'neutral');
    player.hp = 0;
    player.kickX = 0; player.kickY = 0;
    markDeath('blast', t, 9999, t.ang);
    setMsg('车被打爆了 · 你在车里，没能出来', 3.2);
    logWarn('dead', '运兵车殉爆 · 你还在车上');
  } else if (!player.god && player.hp > 0){
    const d = dist(t.x, t.y, player.x, player.y);
    if (d <= R){
      const k = 1 - d / R;
      const dmg = Math.round(D * (0.35 + 0.65 * k));
      player.hp -= absorbArmor(dmg, 'blast');
      hurtNum(dmg);
      stOnHurt(dmg, 'blast');
      player.stunT = Math.max(player.stunT || 0, 0.5);
      visionBlur = Math.max(visionBlur, 0.75);
      if (player.hp <= 0) markDeath('blast', t, dmg, Math.atan2(player.y - t.y, player.x - t.x));
    }
  }
  ashBurst(t.x, t.y);
  if (killed) logInfo('gun', '运兵车殉爆 · 连带炸死 ' + killed + ' 人');
}
function damageTruck(t, dmg, ang){
  /* 废铁就是废铁：不管是被打烂的还是卸完兵留下的，之后一律不吃伤害。
     以前这里漏了 wreck 判断，卸完兵留下的车还能被打，每刀都重新走一遍
     "血空 → 撞击音 + 镜头震"，看起来就是"打爆了还在震"。 */
  if (!t || t.invul || t.wreck || t.tstate === 'gone') return;
  const T = vehicleDef(t && t.type) || enemyType(t);  /* 未知旧输入仍走原回退 */
  const real = Math.max(1, Math.round(dmg * (1 - (t.armor || 0))));
  t.hp -= real;
  /* 被一发重炮打懵：单次原伤 >= paralyzeDmg 时按概率瘫在原地（手枪永远够不着）。
     只在这一发没打死它的时候才判 —— 打爆就是打爆，不能让"瘫痪"抢了废铁的判定，
     否则最后一发时不时打不死，手感会像卡住了。
     实战里火箭弹对车是 8 倍倍率：贴脸 150×8=1200 原伤、减甲后 780，
     900 血的车剩 120 —— 正好落在"打不爆但足够瘫"的区间里。 */
  if (t.hp > 0 && !t.paralyzed && dmg >= (T.paralyzeDmg === undefined ? 1e9 : T.paralyzeDmg)
      && Math.random() < (T.paralyzeP === undefined ? 0 : T.paralyzeP)){
    truckParalyze(t);
  }
  t.hitT = 0.18;
  truckMgWake(t);              /* 顶置机枪：被打了就转过来还击（自己开的车不算） */
  const hx = t.x + Math.cos(ang + Math.PI) * (t.r * 0.75);
  const hy = t.y + Math.sin(ang + Math.PI) * (t.r * 0.75);
  truckSparks(hx, hy, ang);
  spawnDamageNum(t.x, t.y - 34, real, false, false);
  if (t.hp <= 0){
    /* 殉爆：车上的乘员（包括你）跟车一起没，不再"先卸兵再变废铁"。
       数据里 boomKillCrew: false 可以退回老行为（卸兵 + 把你甩出去）。 */
    const _boomCrew = (T.boomKillCrew !== false);
    if (_boomCrew) truckExplode(t);
    else truckForceDeploy(t);
    t.hp = 0; t.wreck = true; t.solid = true; t.invul = true;
    t.tstate = 'wreck'; t.tt = 0; t.spd = 0;
    if (typeof cargoBurnAll === 'function') cargoBurnAll(t);   /* 货斗里的东西全没了 */
    navPatchTruck(t);                      /* 打烂后是掩体：写进网格，敌人绕开 */
    sfxSlam(true);
    camShake = Math.max(camShake, 1.0);
    for (let i = 0; i < 26; i++){
      spawnPart(t.x + rand(-40, 40), t.y + rand(-28, 28), rand(0, TAU),
                rand(120, 520), rand(0.25, 0.6), 'mspark', rand(1.2, 2.8));
    }
    setMsg('运兵车被打烂了 · 现在只是一块废铁', 1.9);
    truckSfxStop();
    if (!_boomCrew) truckWreckEject(t);        /* 爆炸那一版已经在 truckExplode 里处理过人了 */
  }
}

/* 这块地能不能停车（按车身半径留 pad） */
function _truckFree(x, y, pad){
  const L = cur();
  if (!L) return true;
  if (x < pad || y < pad || x > L.w - pad || y > L.h - pad) return false;
  for (const w of L.walls){
    if (x > w.x - pad && x < w.x + w.w + pad &&
        y > w.y - pad && y < w.y + w.h + pad) return false;
  }
  return true;
}

/* 车停稳以后会变成实体（还会一路挡到被打成废铁），所以停车点不能把
   一条路彻底焊死：左右各留 LANE_MIN 的通行宽度才算合格。
   判定用「离车心的水平/垂直两条通道」——这张地图的车都是横着停的。 */
const TRUCK_LANE_MIN = 90;   /* 玩家半径 22 + 一点余量，够一个人侧身过去 */
/* 精确判定：把车临时写进网格，看左右两侧还能不能走通。
   车停稳后就是实体、还会一路挡到被打成废铁，所以"停得下"不等于"过得去"。 */
function _truckLaneOK(x, y, r, L0){
  const L = L0 || cur();
  if (!L) return true;
  /* 用几何量缝，不用 findPath —— A* 的起点会被 nearestFreeCell 吸附到
     缝隙外的空地上，窄缝照样能"找到路"，判不出来。 */
  const need = TRUCK_LANE_MIN;          /* 一侧至少要留这么宽 */
  const probe = r + 13;                 /* 13 = navBlockedAt 的 pad，缝比它还窄就是死路 */
  /* 沿 x 方向量：车右侧到最近一堵墙的左边缘，以及左侧同理；
     沿 y 方向同理。任意一对（左右 / 上下）都 >= need 才算能绕。 */
  /* 沿某个方向量：从车边到"第一堵真正挡路的墙"有多远。
     挡路 = 该墙在垂直方向上和车有重叠；只比坐标大小会把
     离得很远、根本不在同一片空地里的墙也算进来。 */
  const gapTo = (dirX, dirY, half) => {
    const ex = x + dirX * probe, ey = y + dirY * probe;
    let best = 1e9;
    for (const w of L.walls){
      if (dirX !== 0){
        const ov = w.y < y + half && w.y + w.h > y - half;
        if (!ov) continue;
        if (dirX > 0 && w.x >= ex) best = Math.min(best, w.x - ex);
        if (dirX < 0 && w.x + w.w <= ex) best = Math.min(best, ex - (w.x + w.w));
      } else {
        const ov = w.x < x + half && w.x + w.w > x - half;
        if (!ov) continue;
        if (dirY > 0 && w.y >= ey) best = Math.min(best, w.y - ey);
        if (dirY < 0 && w.y + w.h <= ey) best = Math.min(best, ey - (w.y + w.h));
      }
    }
    const bx = dirX > 0 ? (L.w - 18) - ex : dirX < 0 ? ex - 18 : 1e9;
    const by = dirY > 0 ? (L.h - 18) - ey : dirY < 0 ? ey - 18 : 1e9;
    return Math.min(best, Math.min(bx, by));
  };
  const half = probe;              /* 车在垂直方向上的影响范围 */
  const gx = Math.max(gapTo(1, 0, half), gapTo(-1, 0, half));
  const gy = Math.max(gapTo(0, 1, half), gapTo(0, -1, half));
  /* 窄缺口里：上下各剩 7px，左右看着开阔但那是被车自己挡住的死路 */
  return gx >= need && gy >= need;
}
/* 人挤人：一群敌人朝同一个点走的时候会摞成一坨。
   做一点互相推挤（不动寻路），推力压过走路速度，否则只是把两个人一起平移。
   推开之后还要 pushOutCircle 兜一次，避免把人挤进墙里。 */
let separationFrame=0;
const separationStats={checks:0,pairs:0,active:0};
/* m35719：把单位从墙里彻底弄出来。
   单次 pushOutCircle 只按"最近的那条边"往外顶：当两条墙夹出的缝比身体还窄时，
   它会先被 A 墙顶进 B、再被 B 墙顶回 A —— 玩家看到的就是"一堆人被挤进墙里"。
   所以这里做三轮松弛，仍出不来就挪到最近的空位（safeSpot 只在 96px 内找，不会穿墙乱飞）。 */
function _freeAt(L, x, y, r){
  for (const w of collisionWalls(L, x, y, r)){
    if (!w || w.dead || w.noBlock) continue;
    const px = Math.max(w.x, Math.min(x, w.x + w.w));
    const py = Math.max(w.y, Math.min(y, w.y + w.h));
    if (Math.hypot(x - px, y - py) < r - 0.5) return false;
  }
  return true;
}
function unstickFromWalls(L, e, passes, fromX, fromY, squeeze){
  /* 自检用：window.__NO_UNSTICK 打开时退回旧行为（每帧只做一次 pushOutCircle） */
  if (typeof window !== 'undefined' && window.__NO_UNSTICK) return false;
  const n = passes || 3;
  const radius=squeeze ?? e.roomSearch?.walkRadius ?? e.r;
  if(squeeze!=null){
    // 先尝试该步的短距离修正，再从原位置复核整段，避免脱困点落在隔墙另一侧。
    const walls=collisionWalls(L,e.x,e.y,radius);
    for(const w of walls)if(!w.dead&&!w.noBlock)pushOutCircle(e,radius,w);
    if(!bladeWalkLine(L,radius,fromX,fromY,e.x,e.y,true,undefined,true)){
      e.x=fromX;e.y=fromY;
    }
    return false;
  }
  for (let k = 0; k < n; k++){
    let hit = false;
    for (const w of collisionWalls(L, e.x, e.y, radius)){
      if (!w || w.dead || w.noBlock) continue;
      if (pushOutCircle(e, radius, w)) hit = true;
    }
    if (!hit) return false;
  }
  /* 还在墙里：先试"沿墙最短的那一侧整体弹出去"（四条边各试一次，挑最近且落点干净的），
     不行再退到 safeSpot。以前直接 safeSpot 会让同一帧里好几个人落到同一个点上。 */
  let worst = null, worstPen = 0;
  for (const w of collisionWalls(L, e.x, e.y, radius)){
    if (!w || w.dead || w.noBlock) continue;
    const px = Math.max(w.x, Math.min(e.x, w.x + w.w));
    const py = Math.max(w.y, Math.min(e.y, w.y + w.h));
    const pen = radius - Math.hypot(e.x - px, e.y - py);
    if (pen > worstPen){ worstPen = pen; worst = w; }
  }
  if (!worst) return false;
  const pad = radius + 2;
  const cand = [
    { x: worst.x - pad, y: e.y },
    { x: worst.x + worst.w + pad, y: e.y },
    { x: e.x, y: worst.y - pad },
    { x: e.x, y: worst.y + worst.h + pad }
  ];
  let best = null, bestD = 1e9;
  for (const c of cand){
    if (c.x < radius || c.y < radius || c.x > L.w - radius || c.y > L.h - radius) continue;
    if (!_freeAt(L, c.x, c.y, radius)) continue;
    const d = Math.hypot(c.x - e.x, c.y - e.y);
    if (d < bestD){ bestD = d; best = c; }
  }
  if (best){ e.x = best.x; e.y = best.y; }
  else if (typeof safeSpot === 'function'){
    const sp = safeSpot(L, { x: e.x, y: e.y, wp: e.wp }, Math.max(12, radius + 1));
    if (sp){ e.x = sp.x; e.y = sp.y; }
    /* 同一帧里好几个人可能算出同一个空位，各带一个固定随机角散开，避免又叠成一坨 */
    if (e.__sepAng === undefined) e.__sepAng = Math.random() * Math.PI * 2;
    const _rr = radius * 1.6;
    e.x = Math.max(radius, Math.min(L.w - radius, e.x + Math.cos(e.__sepAng) * _rr));
    e.y = Math.max(radius, Math.min(L.h - radius, e.y + Math.sin(e.__sepAng) * _rr));
  }
  if (typeof separationStats === 'object' && separationStats) separationStats.unstuck = (separationStats.unstuck || 0) + 1;
  return true;
}

function separateEnemies(dt){
  const n=enemies.length,L=cur();separationStats.checks=0;separationStats.pairs=0;
  if(n<2)return;
  const bins=new Map(),active=[],moved=new Set(),officeMoves=new Map();
  function rememberOfficePush(e){
    if(moved.has(e)||officeMoves.has(e))return;
    const radius=officeSqueezeRadius(L,e);
    if(radius!=null)officeMoves.set(e,{x:e.x,y:e.y,radius,waypoint:officeGapWaypoint(L,e,e.roomSearch)});
  }
  let cell=64;
  for(let i=0;i<n;i++){
    const e=enemies[i];
    if(!e||e.dead||e.static||e.towerOn||!e.r||e._lodSleep||e._lodTier===2)continue;
    active.push(i);cell=Math.max(cell,e.r*2.04);
  }
  separationStats.active=active.length;
  for(const i of active){
    const e=enemies[i],k=Math.floor(e.x/cell)+','+Math.floor(e.y/cell);
    let b=bins.get(k);if(!b)bins.set(k,b=[]);b.push(i);
  }
  const frame=separationFrame++;
  for(const i of active){
    const a=enemies[i],cx=Math.floor(a.x/cell),cy=Math.floor(a.y/cell);
    let tested=0;
    for(let yy=-1;yy<=1;yy++)for(let xx=-1;xx<=1;xx++){
      const bucket=bins.get((cx+xx)+','+(cy+yy));if(!bucket)continue;
      const start=(frame+i)%bucket.length;
      for(let q=0;q<bucket.length&&tested<48;q++){
        const j=bucket[(start+q)%bucket.length];tested++;separationStats.checks++;
        if(j<=i)continue;
        const b=enemies[j];let dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);
        if(d>=(a.r+b.r)*1.02)continue;
        rememberOfficePush(a);rememberOfficePush(b);
        const pa=officeMoves.get(a),pb=officeMoves.get(b);
        const need=((pa?.waypoint?pa.radius:a.r)+(pb?.waypoint?pb.radius:b.r))*1.02;
        if(d>=need)continue;
        if(d<.001){const angle=(i*2.399+j*1.618)%TAU;dx=Math.cos(angle);dy=Math.sin(angle);d=1;}
        const push=Math.min((need-d)*.55,210*dt)*.5,ux=dx/d,uy=dy/d;
        /* 1126e 备注：试过"正在抬手的人不被挤"（含只冻结 windup 1 秒的窄版本），
           实测都会让门口几个兵的位置分布改变、进而影响落点分离/同时撒手的判定，
           连锁红 3 套。站位表（nadeStanceClaim/Release）已先落地，
           等门口站位真正参与寻路（走到自己那个站位上）之后再来打开推挤豁免。 */
        /* 推挤豁免（2026-11-25 用户确认要做）：已经抬手投雷的人这一秒站定，
           由另一方承担全部位移 —— 否则被身后同伴一帧一帧顶出门框，前摇自检失败就扔掉。
           站位点已先落地（nadeStanceClaim），这里才安全。 */
        /* 开关：DataTHROW.roomEntry.pushFreeze。默认关 —— 站位点还没改成"站上去一定合法"，
           打开会让门口分布变化、连带 _tNadeRound/_tCoopNade/_tIndoorSearch 红。 */
        const _pf = !!(typeof DataTHROW !== 'undefined' && DataTHROW && DataTHROW.roomEntry && DataTHROW.roomEntry.pushFreeze);
        const _aFrozen = _pf && (a.throwT || 0) > 0;
        const _bFrozen = _pf && (b.throwT || 0) > 0;
        /* 只"整体跳过"，不把对方推开：推 2× 会把同伴顶出他自己的合法站位，
           他于是取消重排、最后变成三个人各投一颗、还不同时撒手（实测 n=3 / dt=4.45）。
           抬手这一秒两人略微重叠是看不出来的，比丢掉一颗雷好。 */
        if (_pf && (_aFrozen || _bFrozen)) continue;
        // 排在前面的人已在窄缝里，后面的人让出间距，避免把前面的人顶离路点。
        if(!pa?.waypoint){a.x-=ux*push;a.y-=uy*push;moved.add(a);}
        if(!pb?.waypoint){b.x+=ux*push;b.y+=uy*push;moved.add(b);}
        separationStats.pairs++;
      }
    }
  }
  // 同一人一帧只做一次墙体修正，不在每一对邻居里遍历全图墙体。
  for(const e of moved){
    const origin=officeMoves.get(e);
    unstickFromWalls(L,e,3,origin?.x,origin?.y,origin?.radius);
    pushOutTrucks(e);
  }
}

/* 势力色：数据在 data/factionlook.js（A 钢蓝 / B 苔绿 / 中立灰 / 玩家亮蓝）。
   这里只做转发，不再写死颜色 —— 改外观去改数据表。只做视觉标识，不参与任何判定。 */
/* 势力色：数据在 data/factionlook.js（A 铁蓝 / B 琥珀 / 中立灰 / 玩家天蓝）。
   这里只做转发，不写死颜色 —— 改外观去改数据表。只做视觉标识，不参与任何判定。 */
function _ftint(f){
  if (typeof factionLook === 'function') return factionLook(f).body;
  if (f === 'bandit') return '#d89a4a';
  if (f === 'neutral') return '#9aa4ae';
  if (f === 'player') return '#6fb3e0';
  return '#5f8fd8';
}
function spawnTruck(kind, pos, faction){
  const L = cur();
  if (!L || state !== 'play') return false;
  /* 第三参：这辆车归谁（默认 A 势力）*/
  const _fc = (faction === 'bandit' || faction === 'neutral' || faction === 'player') ? faction : 'enemy';
  /* kind 不传就是基准运兵车；传 'truck_apc' / 'truck_pickup' 就是别的车型 */
  const _k = (typeof kind === 'string' && ENEMY_TYPES[kind]) ? kind : 'truck';
  const T = vehicleDef(_k) || enemyType({type:_k});  /* 非车辆旧类型仍走原回退 */
  const px = player.x, py = player.y;

  /* 停哪儿：绕着玩家找一块能停车的空地 */
  let tx = px, ty = py, got = false;
  for (const rr of [200, 260, 320, 150]){
    for (let k = 0; k < 16 && !got; k++){
      const a = (k / 16) * TAU + 0.4;
      const cx = px + Math.cos(a) * rr, cy = py + Math.sin(a) * rr;
      /* 离地图边界至少留 130px：贴着边投车，下车的人会被挤进边界墙的导航带里，
         从此哪都"没路"，站在角落一动不动（_tTruckAI 逮到过两个 0px）。 */
      const _mgn = 130;
      const _inMap = cx >= _mgn && cx <= L.w - _mgn && cy >= _mgn && cy <= L.h - _mgn;
      if (_inMap && _truckFree(cx, cy, T.r + 30) && _truckLaneOK(cx, cy, T.r)){ tx = cx; ty = cy; got = true; }
      if (pos && _truckFree(pos.x, pos.y, T.r + 30) && _truckLaneOK(pos.x, pos.y, T.r)){ tx = pos.x; ty = pos.y; got = true; break; }
    }
    if (got) break;
  }

  if(!got){
    tx = Math.min(Math.max(px, 150), L.w - 150);
    ty = Math.min(Math.max(py, 150), L.h - 150);
  }
  /* 从离玩家最近的那条边冲进来：这样它一露头你就能看见 */
  const dl = px, dr = L.w - px, du = py, dd = L.h - py;
  const m = Math.min(dl, dr, du, dd);
  let ex = 1, ey = 0;
  if (m === dl){ ex = -1; ey = 0; }
  else if (m === dr){ ex = 1; ey = 0; }
  else if (m === du){ ex = 0; ey = -1; }
  else { ex = 0; ey = 1; }
  /* 起点在画面外（相机始终跟着玩家，所以按屏幕尺寸往外推就够） */
  const far = Math.max(W, H) * 0.72 + 160;
  const sx = tx - ex * far + (-ey) * 90;
  const sy = ty - ey * far + ( ex) * 90;
  const head = Math.atan2(ty - sy, tx - sx);

  const e = {
    type: _k, veh: T.veh || 'truck', tstate: 'drift_in', tt: 0, owner: _fc === 'player' ? 'player' : 'enemy', team: _fc === 'player' ? 'player' : 'enemy', faction: _fc, crewFaction: _fc, factionTint: _ftint(_fc),
    x: sx, y: sy, r: T.r, ang: head, head: head,
    sx: sx, sy: sy, tx: tx, ty: ty,
    hp: T.hp, maxHp: T.hp, armor: T.armor || 0,
    spd: T.driftSpd, solid: false, door: 0, spawned: 0,
    cargoTotal: T.deployCount || 4, deployT: 0,
    smokeT: 0, visA: 1, hitT: 0, wreck: false, gone: false, invul: false
  };
  trucks.push(e);
  sfxTruckBrake(0.55, true);          /* 冲进来时先来一嗓子轮胎声 */
  /* 实录音：漂移进场这一段要刚好在"停稳"那一刻收住 —— 所以按
     driftDur + brakeDur 这两段实际耗时把音效拉长/压短。 */
  if (typeof TRUCK_SFX !== 'undefined' && TRUCK_SFX.drift){
    truckSfxPlay(TRUCK_SFX.drift, (T.driftDur || 2.2) + (T.brakeDur || 0.62));
  }
  logWarn('dev', '运兵车入场 · 停在 ' + Math.round(tx) + ',' + Math.round(ty));
  return true;
}

/* 开发者：在旁边摆一辆停着不动的车（不进场、不卸兵、不开走）。
   用途是摆场景 / 试掩体：它一生成就是实体，挡人挡子弹，也能被打爆变废铁。 */
function spawnParkedTruck(kind, pos, faction){
  const L = cur();
  const _pf = (faction === 'bandit' || faction === 'enemy' || faction === 'player') ? faction : 'neutral';
  if (!L || state !== 'play') return false;
  const _k = (typeof kind === 'string' && ENEMY_TYPES[kind]) ? kind : 'truck';
  const T = vehicleDef(_k) || enemyType({type:_k});  /* 非车辆旧类型仍走原回退 */
  const px = player.x, py = player.y;
  let tx = px + 200, ty = py, got = false;
  for (const rr of [190, 240, 300, 150]){
    for (let k = 0; k < 16 && !got; k++){
      const a = (k / 16) * TAU;
      const cx = px + Math.cos(a) * rr, cy = py + Math.sin(a) * rr;
      if (_truckFree(cx, cy, T.r + 30)){ tx = cx; ty = cy; got = true; }
      if (pos && _truckFree(pos.x, pos.y, T.r + 30)){ tx = pos.x; ty = pos.y; got = true; break; }
    }
    if (got) break;
  }
  const head = Math.atan2(py - ty, px - tx);      /* 车头冲着玩家，方便看正面 */
  const e = {
    type: _k, veh: T.veh || 'truck', tstate: 'parked', tt: 0, owner: _pf === 'neutral' ? 'neutral' : (_pf === 'player' ? 'player' : 'enemy'), team: _pf === 'neutral' ? 'neutral' : (_pf === 'player' ? 'player' : 'enemy'), faction: _pf, crewFaction: _pf, factionTint: _ftint(_pf),
    x: tx, y: ty, r: T.r, ang: head, head: head,
    sx: tx, sy: ty, tx: tx, ty: ty,
    hp: T.hp, maxHp: T.hp, armor: T.armor || 0,
    spd: 0, solid: true, door: 0, spawned: 0, cargoTotal: 0, deployT: 0,
    smokeT: 0, visA: 1, hitT: 0, wreck: false, gone: false, invul: false, parked: true
  };
  trucks.push(e);
  if (typeof navPatchTruck === 'function') navPatchTruck(e);   /* 立刻写进导航网格：敌人会绕开 */
  setMsg('摆了一辆停着的车 · 它不会开走也不会放人', 2.2);
  logWarn('dev', '静态运兵车 · ' + Math.round(tx) + ',' + Math.round(ty));
  return true;
}

/* 一次金属火花（打中车壳）。和 impactWallFx 的 metal 分支同一套配方，
   但车不是墙，wallAtPoint 找不到它，所以这里自己发。 */
function truckSparks(x, y, ang){
  for (let i = 0; i < 12; i++){
    const a = ang + Math.PI + rand(-0.9, 0.9);
    spawnPart(x, y, a, rand(240, 780), rand(0.10, 0.30), 'mspark', rand(1.1, 2.6));
  }
  spawnPart(x, y, ang, 0, 0.10, 'flash', 7);
  spawnPart(x, y, ang, 0, 0.20, 'ring', 10);
  hotMarks.push({x: x, y: y, t: 0, dur: 2.0});
  sfxMetalHit(x, y);
}

/* 开门音效：两下金属"咣、嗤" */
/* ── 运兵车实录音（m24105 / 修于 m24206）────────────────────────────
   一个 mp3 里塞了两段：前段是漂移进场，后段是开走。靠时间点切，不用切文件。
   进场那段多长要跟着车走的时长走（车从哪儿进场每次都不一样），所以用 playbackRate
   把音效压/拉到刚好等长 —— 但是**不能只靠 rate**：元素还没 load 好的时候设
   playbackRate 会被忽略（回到 1），于是 12.5 秒的整个文件就那么一路播下去，
   中间静音两秒半之后自己把"开走"那一段放了出来 —— 听起来就是"车还没走，音效先响"。
   所以这里三重保险：①先 load 再设 rate（并在 playing 时再补一次）；
   ②按 needDur 挂一个绝对计时器到点就停；③到最后 0.25 秒淡出，不硬切。 */
let _truckAud = null;       /* 复用一个 <audio>，别每辆车 new 一个 */
let _truckAudFade = 0;      /* fade 用的 setInterval 句柄 */
let _truckAudEnd = 0;       /* 到点强停的 setTimeout 句柄 */
let _truckAudSeg = null;    /* 当前这一段（a/b/rate） */
function truckSfxStop(){
  if (_truckAudFade){ clearInterval(_truckAudFade); _truckAudFade = 0; }
  if (_truckAudEnd){ clearTimeout(_truckAudEnd); _truckAudEnd = 0; }
  _truckAudSeg = null;
  if (!_truckAud){ return; }
  try { _truckAud.pause(); } catch (err){ if (typeof reportErr === 'function') reportErr('18-truck', err); }
  try { _truckAud.currentTime = 0; } catch (err){ if (typeof reportErr === 'function') reportErr('18-truck', err); }
  _truckAud.volume = 1;
}
/* 把 rate 真正按上去：load 之前设的会被浏览器丢掉，所以每次播放前后都补一次 */
function _truckApplyRate(){
  if (!_truckAud || !_truckAudSeg) return;
  try{
    _truckAud.defaultPlaybackRate = _truckAudSeg.rate;
    _truckAud.playbackRate = _truckAudSeg.rate;
  }catch (err){ if (typeof reportErr === 'function') reportErr('18-truck', err); }
}
/* 真正的起点：等能播了再跳时间点，跳完再 play */
function _truckSeekAndPlay(){
  if (!_truckAud || !_truckAudSeg) return;
  _truckApplyRate();
  try{ _truckAud.currentTime = _truckAudSeg.a; }catch (err){ if (typeof reportErr === 'function') reportErr('18-truck', err); }
  const p = _truckAud.play();
  if (p && p.catch) p.catch(function(){});
  _truckApplyRate();          /* 有的浏览器在 play() 之后又把 rate 抹回去 */
}
/* seg: TRUCK_SFX.drift / .leave；needDur: 这一段希望响多少秒（不传就照原速） */
function truckSfxPlay(seg, needDur){
  if (typeof TRUCK_SFX === 'undefined' || !seg || !segFileOK()) return false;
  try{
    if (!_truckAud){
      _truckAud = new Audio(AUDIO_DIR + TRUCK_SFX.file);
      _truckAud.preload = 'auto';
      _truckAud.addEventListener('loadeddata', function(){ if (_truckAudSeg) _truckSeekAndPlay(); });
      _truckAud.addEventListener('playing', _truckApplyRate);
      _truckAud.addEventListener('ended', function(){ truckSfxStop(); });
    }
    if (_truckAudFade){ clearInterval(_truckAudFade); _truckAudFade = 0; }
    if (_truckAudEnd){ clearTimeout(_truckAudEnd); _truckAudEnd = 0; }
    const a = seg.a || 0, b = (seg.b === undefined ? a + 1 : seg.b);
    const segLen = Math.max(0.05, b - a);
    const want = (needDur && needDur > 0.1) ? needDur : segLen;
    const rate = clamp(segLen / want, 0.75, 2.0);
    _truckAudSeg = { a: a, b: b, rate: rate, want: want };
    _truckAud.volume = (typeof CFG !== 'undefined' && CFG.gunVol !== undefined) ? clamp(CFG.gunVol, 0, 1) : 0.9;
    if (_truckAud.readyState >= 2) _truckSeekAndPlay();
    else { try{ _truckAud.load(); }catch (err){ if (typeof reportErr === 'function') reportErr('18-truck', err); } }   /* loadeddata 里会自己接上 */
    /* ② 到点强停：哪怕 rate 没生效、哪怕文件下一段自己接上来，也在 needDur 这里掐断 */
    _truckAudEnd = setTimeout(function(){ truckSfxStop(); }, Math.max(120, want * 1000));
    /* ③ 最后 0.25 秒淡出，别"咔"一下 */
    _truckAudFade = setInterval(function(){
      if (!_truckAud || !_truckAudSeg) return;
      const left = _truckAudSeg.want - (_truckAud.currentTime - _truckAudSeg.a) / Math.max(0.1, _truckAud.playbackRate || 1);
      if (left <= 0.25) _truckAud.volume = Math.max(0, left / 0.25) * ((typeof CFG !== 'undefined' && CFG.gunVol !== undefined) ? clamp(CFG.gunVol, 0, 1) : 0.9);
    }, 40);
    return true;
  }catch(err){ return false; }
}
/* 资源真的在不在：没放 mp3 就安静地退回原来的合成音，不是报错 */
function segFileOK(){
  return typeof AUDIO_DIR === 'string' && typeof TRUCK_SFX !== 'undefined' && !!TRUCK_SFX.file;
}

function sfxTruckDoor(){
  if (!actx) return;
  try{
    const t0 = actx.currentTime + 0.004;
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = 'triangle';
    o.frequency.setValueAtTime(220, t0);
    o.frequency.exponentialRampToValueAtTime(90, t0 + 0.16);
    g.gain.setValueAtTime(0.18, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.24);
    o.connect(g); g.connect(duckBus());
    o.start(t0); o.stop(t0 + 0.28);
    noiseBurst(0.26, 1400, 0.10, 0.8);
    noiseBurst(0.14, 420, 0.22, 1.4);
  }catch (err){ if (typeof reportErr === 'function') reportErr('18-truck', err); }
}

/* 轮胎摩擦 / 刹车：一层高频"嘶——" + 一声低频闷响 */
function sfxTruckBrake(vol, long){
  if (!actx) return;
  try{
    const t0 = actx.currentTime + 0.004;
    const k = vol === undefined ? 1 : vol;
    noiseBurst(0.30 * k, 2600, long ? 0.55 : 0.22, 0.7);
    noiseBurst(0.22 * k, 900,  long ? 0.62 : 0.26, 1.1);
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(96, t0);
    o.frequency.exponentialRampToValueAtTime(34, t0 + 0.34);
    g.gain.setValueAtTime(0.42 * k, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.44);
    o.connect(g); g.connect(duckBus());
    o.start(t0); o.stop(t0 + 0.5);
  }catch (err){ if (typeof reportErr === 'function') reportErr('18-truck', err); }
}

/* 从车上下来一个人：字段照 devSpawnKind 的普通敌人抄，位置由车给 */
/* 下车的人要有"自己的巡逻线"，不能只丢一个随机点。
   只给 1 个点 = 走到那儿就开始站着不动（这正是"下来四个人全杵在角落里"的原因）：
   主循环的巡逻分支是靠 e.wp 里多个点轮流走的（e.i 在 wp.length 上取模）。
   这里按"车 → 玩家"的方向，铺一条 3 个点的推进线，每段都验过能不能走通。 */
function _truckDeployRoute(L, sp, e){
  const T = vehicleDef('truck') || enemyType({type:'truck'});
  const n = Math.max(2, (T.deployWp | 0) || 3);
  const adv = (T.deployAdvance === undefined ? 0.62 : T.deployAdvance);
  const jit = (T.deployJitter === undefined ? 0.42 : T.deployJitter);
  const base = Math.atan2(player.y - e.y, player.x - e.x);
  const far = Math.min(560, dist(e.x, e.y, player.x, player.y) * adv);
  const out = [];
  let px = sp.x, py = sp.y;
  for (let k = 1; k <= n; k++){
    const t = Math.max(70, far * (k / n));
    let got = null;
    /* 先沿推进方向试，被墙挡住就往两边偏；偏到头还不行就交给 safeSpot 兜底 */
    for (const da of [0, 0.3, -0.3, 0.62, -0.62, 0.95, -0.95, -1.3, 1.3]){
      const a = base + da + rand(-jit, jit);
      const qx = e.x + Math.cos(a) * t, qy = e.y + Math.sin(a) * t;
      if (!_truckFree(qx, qy, 18)) continue;
      if (!clearWalkLine(L, px, py, qx, qy)) continue;
      /* 关着的门不在导航网格里（它们是"靠近就自己开"的，见 updateDoors），
         但路线规划不能指望"走到门口它就会开"—— 一条巡逻线要是正好穿过
         一扇关着的门，人就会贴着门板一遍遍重算同一条路。这里直接排除。 */
      if (typeof doors !== 'undefined' && doors.length &&
          doors.some(d => doorSolid(d) && segHitsRect(px, py, qx, qy, d))) continue;
      got = {x: qx, y: qy};
      break;
    }
    if (!got){
      const a = base + rand(-jit, jit);
      got = safeSpot(L, {x: e.x + Math.cos(a) * t, y: e.y + Math.sin(a) * t}, 20);
    }
    out.push([got.x, got.y]);
    px = got.x; py = got.y;
  }
  return out;
}
function _truckDeployOne(e, i){
  const L = cur();
  /* 用这辆车自己的数据：以前这里写死 'truck'，装甲车/皮卡/民用车事件都会按运兵车的
     人数和兵种表放人（apc 明明 3 人却放 4 个，皮卡应该放普通兵也变成突击兵）。 */
  const T = vehicleDef(e && e.type) || vehicleDef('truck') || enemyType({type:'truck'});
  const n = T.deployCount || 4;
  /* 车头两侧各排一半：先在车侧，再往后错开，避免叠在一起 */
  const side = (i % 2 === 0) ? 1 : -1;
  const along = -20 + Math.floor(i / 2) * 34;
  const px = e.x + Math.cos(e.ang) * along - Math.sin(e.ang) * side * (T.deploySpread || 60);
  const py = e.y + Math.sin(e.ang) * along + Math.cos(e.ang) * side * (T.deploySpread || 60);
  const sp = _truckFree(px, py, 16) ? {x: px, y: py}
                                    : safeSpot(L, {x: px, y: py}, 16);
  /* 巡逻线：从下车点往玩家方向推进，3 个点；不再用"随机一个点" */
  const route = _truckDeployRoute(L, sp, e);
  /* 下来的是谁看数据：truck.deployMix 里按顺序取，没配就退回步枪兵。
     想让车上下来混编 / 全职业兵，改数据即可，不用动这里。 */
  const _mix = (T.deployMix && T.deployMix.length) ? T.deployMix : ['grunt'];
  const _kind = _mix[i % _mix.length];
  const DT = enemyType({ type: _kind });
  const _hpMax = enemyBaseHp(DT, L);
  enemies.push({
    type: _kind,
    x: sp.x, y: sp.y, r: DT.r || 12, ang: Math.atan2(player.y - sp.y, player.x - sp.x),
    wp: route, i: 0, wait: 0,
    mode: 0, lastKnown: null, alertT: 0, sees: false, heard: false, chk: null,
    ammo: CFG.mag, fireCd: rand(0.5, 1.4), reloading: 0, muzzle: 0,
    hp: _hpMax, maxHp: _hpMax, fleeCd: 0,
    fromTruck: true, deployX: sp.x, deployY: sp.y,
    faction: e.faction || 'enemy', factionTint: e.factionTint || _ftint(e.faction || 'enemy')
  });
  /* 穿甲的（比如职业兵）下车就穿着那件甲，不能等第一次挨打才补 */
  if (DT.armorKind) enemies[enemies.length - 1].armor = armorOf(DT.armorKind);
  assignWeapon(enemies[enemies.length - 1]);
  spawnPart(sp.x, sp.y, rand(0, TAU), rand(20, 60), rand(0.25, 0.5), 'dust', rand(4, 9));
}

/* 故障卸兵：瘫痪 / 报废会跳出 deploy_troops 状态，不能再等逐个下车。
   cargoTotal 明确区分真正载兵的事件车和测试区的空载静态车；旧存档没有该字段时，
   非 parked 的事件车仍按配置推断乘员数。spawned 是唯一进度源，因此重复调用不会多刷。 */
function truckForceDeploy(e){
  if (!isTruckEntity(e)) return 0;
  const T = vehicleDef(e && e.type) || enemyType(e);  /* 未知旧输入仍走原回退 */
  const total = Number.isFinite(e.cargoTotal)
    ? Math.max(0, e.cargoTotal | 0)
    : (e.parked ? 0 : (T.deployCount || 4));
  let made = 0;
  e.door = total > (e.spawned || 0) ? 1 : e.door;
  while ((e.spawned || 0) < total){
    const i = e.spawned || 0;
    _truckDeployOne(e, i);
    e.spawned = i + 1;
    made++;
  }
  return made;
}

/* 卸完兵：一律开走。
   废铁只能由"被打爆"产生（damageTruck 里 hp<=0 那条），不能再靠随机数自己变。
   以后要做"停着不走的剧情车"，另开一个分支，别拿随机数糊。 */
function truckFinishDeploy(e){
  e.tstate = 'leave'; e.tt = 0; e.spd = 60; e.solid = false;
  /* 停车时允许自然斜停；开走再随着加速把方向盘打回路线，不能在起步那一帧瞬间摆正。 */
  e.leaveAng0 = isFinite(e.ang) ? e.ang : e.head;
  e.leaveSteerT = 0;
  e.settleT = 0;
  navPatchTruck(e);                      /* 不再是实体了：把它占的格子还回去 */
  setMsg('运兵车走了', 1.4);
  /* 实录音的后半段：开走。车身离场大约 2.5~3.5 秒，按 3.0 秒压一压 */
  if (typeof TRUCK_SFX !== 'undefined' && TRUCK_SFX.leave){
    truckSfxPlay(TRUCK_SFX.leave, 3.0);
  }
}

/* 两辆车不许穿模：谁和别的车壳重叠，就沿最小分离向量把自己顶出去。
   运兵车那几个状态（进场/刹车/开走）的位置是状态机直接写的，根本不知道"还有别的车"，
   所以只能每帧做一次兜底分离。 */
function truckSeparate(e){
  if (!e || !e.solid || e.tstate === 'gone' || e.dead) return;
  for (const ot of trucks){
    if (ot === e || !ot.solid || ot.tstate === 'gone' || ot.dead) continue;
    const h = obbVsRect(e.x, e.y, e.ang, truckRect(ot));
    if (!h) continue;
    const push = (h.depth || 0) + 0.6;
    /* "不让位"的车：玩家开着的、以及停着当掩体的。
       注意要两边都判 —— 只从 e 的视角判的话，轮到 parked 那辆做 e 时
       它会把"自己是停着的"这件事忘掉，然后把自己推开一半（踩过）。 */
    const _fixE = (e === playerTruck) || e.tstate === 'parked';
    const _fixOt = (ot === playerTruck) || ot.tstate === 'parked';
    if (_fixE && !_fixOt){
      ot.x -= h.nx * push; ot.y -= h.ny * push;      /* 只推开对方 */
      ot.spd *= 0.35;
    } else if (_fixOt && !_fixE){
      e.x += h.nx * push; e.y += h.ny * push;        /* 只把自己顶出去 */
      e.spd *= 0.35;
    } else {
      /* 两辆都不让位（比如两辆停着的叠在一起）：只能各退一半 */
      e.x += h.nx * push * 0.5; e.y += h.ny * push * 0.5;
      ot.x -= h.nx * push * 0.5; ot.y -= h.ny * push * 0.5;
    }
    navPatchTruck(e); navPatchTruck(ot);
  }
}

/* 顶置机枪的数据块（没配或关掉就当它不存在）
   关卡可以在 rules.truckMg 里整体盖一层（死亡地带就用它把机枪调到"压制"档） */
function truckMgDef(t){
  const T = vehicleDef(t && t.type) || enemyType(t);  /* 未知旧输入仍走原回退 */
  const M0 = T && T.mg;
  if (!M0 || M0.on === false) return null;
  const L = (typeof cur === 'function') ? cur() : null;
  const R = L && L.rules;
  if (R && R.truckMg) return Object.assign({}, M0, R.truckMg);
  return M0;
}
/* ——— 机枪过载 ———
   连打会一直涨，涨满锁死；停火之后不是立刻降，先静 heatCoolDelay，再按冷却速率慢慢掉。
   锁死期间降温更慢（heatLockCool），所以"打满一次要等很久"。
   firing 由调用方给（这一帧到底有没有真的打出去），而不是看扳机 —— 没对准/没装填时不应该涨。 */
function mgHeatDef(M){
  M = M || {};
  return {
    max:      M.heatMax      === undefined ? 1.0  : M.heatMax,
    per:      M.heatPerShot  === undefined ? 0.028: M.heatPerShot,
    delay:    M.heatCoolDelay=== undefined ? 0.55 : M.heatCoolDelay,
    cool:     M.heatCool     === undefined ? 0.30 : M.heatCool,
    lockCool: M.heatLockCool === undefined ? 0.16 : M.heatLockCool,
    reset:    M.heatReset    === undefined ? 0.05 : M.heatReset
  };
}
function mgHeatTick(o, M, dt, shots){
  if (!o) return null;
  const H = mgHeatDef(M);
  /* shots = 这一帧真正打出去几发（整数）。以前这里收的是布尔"最近开过火"，
     结果每一帧都加一次 per —— 60fps 下 150 发的弹链 1 秒就打红，
     而且帧率越高过热越快。现在按发数算：150 发就是 150 发。 */
  const n = (shots === true) ? 1 : Math.max(0, Math.round(shots || 0));
  if (n > 0){
    o.mgHeat = Math.min(H.max, (o.mgHeat || 0) + H.per * n);
    o.mgHeatIdle = 0;
    if (o.mgHeat >= H.max - 1e-9) o.mgOverheat = 1;
  } else {
    o.mgHeatIdle = (o.mgHeatIdle || 0) + dt;
    if ((o.mgHeat || 0) > 0 && o.mgHeatIdle >= H.delay){
      const k = o.mgOverheat ? H.lockCool : H.cool;
      o.mgHeat = Math.max(0, (o.mgHeat || 0) - k * dt);
    }
  }
  if (o.mgOverheat && (o.mgHeat || 0) <= H.reset) o.mgOverheat = 0;
  return H;
}
/* 还要多久才能再开火（给 HUD 显示用）：没锁死就是 0 */
function mgHeatLeft(o, M){
  if (!o || !o.mgOverheat) return 0;
  const H = mgHeatDef(M);
  const over = Math.max(0, (o.mgHeat || 0) - H.reset);
  return over > 0 ? over / Math.max(0.01, H.lockCool) : 0;
}

/* 被打就醒：由 damageTruck 调，只有玩家打它才算（自己开的车由 tstate 挡掉） */
function truckMgWake(t){
  const M = truckMgDef(t);
  if (!M || !t || t.tstate === 'driven' || t.tstate === 'gone' || t.wreck) return;
  if (truckTeam(t) !== 'enemy') return;   /* 中立 / 你开的车不会朝你开火 */
  t.mgRage = Math.max(t.mgRage || 0, M.rage === undefined ? 4.5 : M.rage);
}
/* ——— 玩家手操顶置机枪 ———
   上车之后（tstate === 'driven'，team === 'player'）AI 那套 truckMgTick 直接退出，
   这里接手：转塔跟鼠标、左键开火、弹链打空自动装填。
   参数全部复用 mg 表（dmg / spd / rof / spread），不另开一套数值，免得这挺枪失控。 */
function truckMgPlayerInit(t){
  const M = truckMgDef(t);
  if (!M) return null;
  if (t.pmAmmo === undefined) t.pmAmmo = (M.mag || 150);
  if (t.mgAng === undefined) t.mgAng = t.ang - Math.PI / 2;
  if (t.pmFireT === undefined) t.pmFireT = 0;
  if (t.pmReload === undefined) t.pmReload = 0;
  return M;
}
/* 贴墙时枪口可能已越过墙面，连炮塔轴心到枪口这一段也要判墙。 */
function truckMgWallHit(x, y, dx, dy, range){
  let nearest = null, end = range;
  for (const wall of rayWallCandidates(cur(), x, y, dx, dy, range)){
    if (!wall || wall.dead) continue;
    const t = rayEnter(x, y, dx, dy, wall, end);
    if (t < 0 || (nearest && t >= end)) continue;
    end = t;
    nearest = {wall, t, x:x + dx * t, y:y + dy * t};
  }
  return nearest;
}
function truckMgMuzzleHit(t, mx, my){
  const dx = mx - t.x, dy = my - t.y;
  const range = Math.hypot(dx, dy);
  return range > 0 ? truckMgWallHit(t.x, t.y, dx / range, dy / range, range) : null;
}
function truckMgImpactWall(hit, dmg, a, source){
  if (hit.wall.brk || hit.wall.decor) damageWall(hit.wall, dmg, hit.x, hit.y, a, source);
  impactWallFx(hit.x, hit.y, a);
}
/* 一发机枪弹：射线判定，伤害结算跟玩家自己的枪走同一套（护甲/受击反应/飘字/击杀） */
function truckMgPlayerShot(t, M, a, mx, my){
  const muzzleHit = truckMgMuzzleHit(t, mx, my);
  if (muzzleHit){
    truckMgImpactWall(muzzleHit, (M.dmg || 3) * 0.9, a, player);
    gunNoise(1.2);
    if (typeof sfxTruckMg === 'function') sfxTruckMg(t.x, t.y);
    return muzzleHit;
  }
  const maxT = (M.range || 460);
  const wallHit = truckMgWallHit(mx, my, Math.cos(a), Math.sin(a), maxT);
  let endT = wallHit ? wallHit.t : maxT;
  /* 别的车先挡：车壳是掩体，后面的敌人打不到 */
  let _tkHit = null, _tkT = 1e9;
  for (const ot of trucks){
    if (ot === t || ot.tstate === 'gone') continue;
    const tt = rayTruckT(ot, mx, my, a, maxT);
    if (tt !== null && tt < endT && tt < _tkT){ _tkT = tt; _tkHit = ot; }
  }
  if (_tkHit) endT = Math.min(endT, _tkT);
  /* 人：取这条线上最近的那个 */
  let hit = null, hitT = 1e9;
  for (const e of enemies.concat(allies)){
    if (!e || e.dead || !combatCanDamage(player,e)) continue;
    const dx = e.x - mx, dy = e.y - my;
    const tt = dx * Math.cos(a) + dy * Math.sin(a);
    if (tt <= 0 || tt >= endT) continue;
    const px = mx + Math.cos(a) * tt, py = my + Math.sin(a) * tt;
    if (Math.hypot(px - e.x, py - e.y) > (e.r || 12) + 6) continue;
    if (tt < hitT){ hitT = tt; hit = e; }
  }
  if (hit) endT = Math.min(endT, hitT);
  tracers.push({ x0: mx, y0: my, x1: mx + Math.cos(a) * endT, y1: my + Math.sin(a) * endT,
                 t: 0, dur: tracerDur(mx, my, mx + Math.cos(a) * endT, my + Math.sin(a) * endT), hit: !!hit, cut: null });
  if (_tkHit && (!hit || _tkT <= hitT)) damageTruck(_tkHit, M.dmg || 3, a);
  if (hit){
    if(hit.controller==='companion')companionDamage(hit,M.dmg||3,player,'bullet',a);
    else {
    const _dmg = absorbEnemyArmor(hit, M.dmg || 3, 'bullet');
    hit.hp = (hit.hp === undefined ? 100 : hit.hp) - _dmg;
    if(typeof factionNoteDamage==='function')factionNoteDamage(hit,player,_dmg,'bullet');
    const killed = hit.hp <= 0;
    registerHit(hit, a, _dmg, killed, false);
    spawnDamageNum(hit.x, hit.y - 30, _dmg, killed, false);
    if (killed) killTestEnemy(hit);
    else alertByHit(hit, a);
    }
  }
  /* m19692：门在独立的 doors 数组里，而且门**不会缩短 endT**（它不是墙），
     所以"门"这一判定必须独立于 endT 跑一次 —— 以前放在 endT < maxT-1 分支里，
     打门时 endT 等于满射程，那条分支永远进不去，机枪打门一点反应都没有。
     这里直接复用子弹那条路用的 doorAlongRay（自动处理滑门 / 平开门 / 开着的门 / 已破的门）。 */
  const _doorHit = (typeof doorAlongRay === 'function' && typeof doors !== 'undefined' && doors)
    ? doorAlongRay(mx, my, a, endT) : null;
  if (_doorHit && _doorHit.d && typeof damageDoor === 'function'){
    damageDoor(_doorHit.d, (M.dmg || 3) * 1.2, _doorHit.x, _doorHit.y, a, false);
    impactWallFx(_doorHit.x, _doorHit.y, a);
  }
  if (!hit && !_tkHit && wallHit) truckMgImpactWall(wallHit, (M.dmg || 3) * 0.9, a, player);
  gunNoise(1.2);                       /* 枪声传出去：附近的人会往这边摸 */
  /* m19692：车载机枪自己的音色（所有车统一一种，不按车型分） */
  if (typeof sfxTruckMg === 'function') sfxTruckMg(mx, my);
}
function truckMgPlayerTick(t, dt){
  const M = truckMgPlayerInit(t);
  if (!M) return;
  const mag = M.mag || 150;
  t.mgOverMsgT = Math.max(0, (t.mgOverMsgT || 0) - dt);
  /* 过载推进：跟 NPC 那挺共用同一套内核（按"这一帧打了几发"算） */
  const _mgShotsP = t.mgShots | 0;
  t.mgShots = 0;
  t.mgHeatFired = Math.max(0, (t.mgHeatFired || 0) - dt);
  mgHeatTick(t, M, dt, _mgShotsP);
  /* 无限弹链：没有弹匣、没有装填，只有过载这一道闸 */
  /* 转塔跟鼠标：限速，不做瞬间对准 */
  const mwx = mouse.x + cam.x, mwy = mouse.y + cam.y;
  const want = Math.atan2(mwy - t.y, mwx - t.x);
  let diff = want - t.mgAng;
  while (diff > Math.PI) diff -= TAU;
  while (diff < -Math.PI) diff += TAU;
  const step = (M.pmTurn || 13) * dt;
  t.mgAng += clamp(diff, -step, step);
  t.pmFireT = Math.max(0, (t.pmFireT || 0) - dt);
  if (!mouse.fire) return;
  let err = want - t.mgAng;
  while (err > Math.PI) err -= TAU;
  while (err < -Math.PI) err += TAU;
  /* 过载判定放在对准之前：枪管红了就该给反馈，不该因为准星偏了一点就一声不响 */
  if (t.mgOverheat){
    if ((t.mgOverMsgT || 0) <= 0){
      t.mgOverMsgT = 1.2;
      setMsg('机枪过载 · 枪管红了，等它凉', 1.6);
      try{ if (typeof sfxClick === 'function') sfxClick(); }catch (e2){ if (typeof reportErr === 'function') reportErr('18-truck', e2); }
    }
    return;
  }
  if (Math.abs(err) > 0.16) return;      /* 还没转到位：不给开火，枪口跟着手走 */
  if (t.pmFireT > 0) return;
  if (t.mgOverheat){
    /* 打满就锁住：不消耗弹药、不出子弹，只给一次提示 */
    if ((t.mgOverMsgT || 0) <= 0){
      t.mgOverMsgT = 1.2;
      setMsg('机枪过载 · 枪管红了，等它凉', 1.6);
      try{ sfxClick && sfxClick(); }catch (err){ if (typeof reportErr === 'function') reportErr('18-truck', err); }
    }
    return;
  }
  t.pmFireT = Math.max(0.03, M.rof || 0.055);
  t.mgHeatFired = 0.12; t.mgShots = (t.mgShots || 0) + 1;
  const mx2 = t.x + Math.cos(t.mgAng) * 34;
  const my2 = t.y + Math.sin(t.mgAng) * 34;
  const a = t.mgAng + fxRand(-1, 1) * (M.pmSpread || 0.05);
  const muzzleHit = truckMgPlayerShot(t, M, a, mx2, my2);
  if (!muzzleHit) spawnPart(mx2, my2, t.mgAng, 40, 0.10, 'flash', 5.2);
  t.mgFlash = 0.10;
  camShake = Math.max(camShake, 0.5);
  sfxShot();
}
/* 上车时的机枪 HUD：换机枪准星 + 弹链条 */
/* 光标：浏览器里 id="canvas" 会自动挂到 window 上，但测试沙箱没有 DOM，
   所以一律走 typeof 守卫，别直接引用 canvas */
function setCursorStyle(v){
  try{
    if (typeof document !== 'undefined' && document && document.body && document.body.style){
      document.body.style.cursor = v;
    }
  }catch (e){ if (typeof reportErr === 'function') reportErr('18-truck', e); }
}
function truckMgTick(e, dt){
  const M = truckMgDef(e);
  if (!M) return;
  if (e.mgAng === undefined) e.mgAng = e.ang - Math.PI/2;   /* 出生时炮口朝左 */
  /* 计时器一律无条件推进：车一旦归中立/被玩家接管就不再走下面那段，
     以前枪口焰、连发节拍、炮管温度全冻在原地 —— 表现就是"炮口永久顶着一团黄火" */
  e.mgFireT = Math.max(0, (e.mgFireT || 0) - dt);
  e.mgFlash  = Math.max(0, (e.mgFlash || 0) - dt);
  if (e.mgBurstT > 0){
    e.mgBurstT = Math.max(0, e.mgBurstT - dt);
    if (e.mgBurstT <= 0) e.mgPauseT = M.pause === undefined ? 0.6 : M.pause;
  } else {
    e.mgPauseT = Math.max(0, (e.mgPauseT || 0) - dt);
  }
  /* 过载：先按"这一帧打出去几发"推进温度，再决定这一帧能不能扣扳机 */
  const _mgShots = e.mgShots | 0;
  e.mgShots = 0;
  e.mgHeatFired = Math.max(0, (e.mgHeatFired || 0) - dt);
  mgHeatTick(e, M, dt, _mgShots);
  /* 谁在开：车顶机枪只认"控制者阵营"，不认"是不是敌方队伍"。
     B 势力中立时接管的中立车，枪口不会朝你转，更不会开火。 */
  const _mayFire = (typeof weaponWantsFight === 'function')
    ? weaponWantsFight(e, player)
    : (truckTeam(e) === 'enemy');
  if (!_mayFire){ e.mgRage = 0; return; }
  e.mgRage   = Math.max(0, (e.mgRage || 0) - dt);
  if (e.wreck || e.gone || e.tstate === 'gone' || e.tstate === 'driven') return;
  /* 只有在卸兵、或者刚挨了玩家一枪之后才"醒着"；死亡地带的机枪车 mg.always 常驻值守 */
  const awake = (e.tstate === 'deploy_troops') || (e.mgRage > 0) || M.always === true;
  const d = dist(e.x, e.y, player.x, player.y);
  const visible = awake && player.hp > 0 && !concealed && d <= Math.min(M.range || 460,enemyVisionRange(e))
                  && !losBlocked(e.x, e.y, player.x, player.y);
  const want = Math.atan2(player.y - e.y, player.x - e.x);
  if (awake){
    /* 醒着就转塔：看不见也往最后方向转，别僵在原地 */
    const maxTurn = (M.turnSpd || 7.5) * dt;
    e.mgAng = normAng(e.mgAng + clamp(normAng(want - e.mgAng), -maxTurn, maxTurn));
  }
  if (!visible) return;
  if (Math.abs(normAng(want - e.mgAng)) > (M.aimTol || 0.22)) return;
  if (e.mgBurstT <= 0){
    if (e.mgPauseT > 0) return;
    e.mgBurstT = M.burst === undefined ? 0.55 : M.burst;   /* 抬起新的一梭 */
  }
  if (e.mgFireT > 0) return;
  if (e.mgOverheat) return;                 /* 过载锁死：枪管红了，只能等它凉 */
  e.mgFireT = Math.max(0.016, M.rof || 0.055);
  e.mgHeatFired = 0.12; e.mgShots = (e.mgShots || 0) + 1;                     /* 告诉过载系统：这一帧真的打了 */
  const sp = M.spread || 0;
  const a = e.mgAng + rand(-sp, sp);
  const spd = M.spd || 980;
  const mx = e.x + Math.cos(e.mgAng) * 34, my = e.y + Math.sin(e.mgAng) * 34;
  const dmg = mgTruckDmg(e, M);
  const muzzleHit = truckMgMuzzleHit(e, mx, my);
  if (muzzleHit) truckMgImpactWall(muzzleHit, dmg * 0.55, a, e);
  else {
    spawnBullet(mx, my, mx, my, Math.cos(a) * spd, Math.sin(a) * spd,
                e, M.life === undefined ? 0.55 : M.life, dmg, false, 0, false);
    e.mgFlash = 0.05;
    spawnPart(mx, my, a, 260, 0.08, 'flash', 5.5);
    spawnPart(mx, my, a, 90, 0.16, 'smoke', 3.5);
  }
  /* 对照测试：车顶机枪走专用音色，每发直接播放。 */
  if (typeof sfxTruckMg !== 'function' || !sfxTruckMg(muzzleHit ? e.x : mx, muzzleHit ? e.y : my, d)) sfxShot();
}
/* 固定重机枪阵地（m33520）
   参考现实原型：三脚架 + 一挺通用机枪 + 一小块防盾。摆下去就钉在地上，不能推也不能开走。
   玩家：走近按 E 接管（跟车顶机枪同一套：鼠标转枪 / 左键开火 / 枪管过热要凉），再按 E 下枪。
   敌人：走近、警觉了，就坐下来打你（不坐下也能走，但坐下之后射击更稳、更难被顶着打）。
   只在测试区投放。 */
const mgNests = [];
/* 重机枪枪口在枪身局部坐标里的距离：枪管 10..34，消焰器 33..40，再往前 2px 才是弹道起点。
   以前写死 30（枪管中段），子弹和枪口焰各画各的，看上去像从枪顶蹦出来。 */
const MG_MUZZLE = 42;
function mgNestDef(){
  return (typeof DataMGNEST === 'object' && DataMGNEST) ? DataMGNEST : {};
}
function spawnMgNest(x, y, ang, fac){
  const D = mgNestDef();
  if (D.on === false) return false;
  let px = x, py = y;
  if (px === undefined || py === undefined){
    const sp = (typeof devSpotAt === 'function') ? devSpotAt() : null;
    if (!sp){ setMsg('这张图没找到空地', 1.6); return false; }
    px = sp.x; py = sp.y;
  }
  const a = (ang === undefined) ? -Math.PI / 2 : ang;
  mgNests.push({
    x: px, y: py, ang: a, mgAng: a,
    /* 无主阵地默认归 A（enemy），和以前"没人也照样打玩家"一致；
       玩家按 E 接管后写成玩家阵营，就立刻转去打 A/B。
       观战图（m41899）由卡牌指定阵营，直接按落点在中线哪边算。 */
    faction: fac || ((typeof devSpawnFaction === 'function') ? devSpawnFaction() : 'enemy'),
    factionTint: (typeof _ftint === 'function')
      ? _ftint(fac || ((typeof devSpawnFaction === 'function') ? devSpawnFaction() : 'enemy')) : '#6d8fb8',
    seat: null, playerSeat: false,
    mgFireT: 0, mgBurstT: 0, mgPauseT: 0, mgFlash: 0,
    mgHeat: 0, mgHeatIdle: 0, mgOverheat: 0, mgHeatFired: 0, overPulse: 0,
    dropT: 0, emptyT: 0
  });
  setMsg('重机枪阵地架好了 · 走近按 E 接管', 2.0);
  logInfo('mgnest', '投放重机枪阵地 (' + Math.round(px) + ',' + Math.round(py) + ')');
  return true;
}
function mgNestNear(r){
  const R = (r === undefined) ? (mgNestDef().useR || 54) : r;
  let best = null, bd = R;
  for (const n of mgNests){
    const d = dist(player.x, player.y, n.x, n.y);
    if (d < bd){ bd = d; best = n; }
  }
  return best;
}
function mgNestSeatPos(n){
  const D = mgNestDef();
  const back = (D.seatIn === undefined ? 15 : D.seatIn);
  return { x: n.x - Math.cos(n.mgAng) * back, y: n.y - Math.sin(n.mgAng) * back };
}
/* ——— 玩家接管 ——— */
function mountMgNest(n){
  if (!n || !player || player.hp <= 0) return false;
  for (const o of mgNests) if (o.playerSeat) o.playerSeat = false;
  if (n.seat) mgNestUnseat(n);              /* 有人占着就赶下去 */
  n.playerSeat = true;
  player.mgNest = n;
  n.mgAng = Math.atan2((mouse.y + cam.y) - n.y, (mouse.x + cam.x) - n.x);
  const sp = mgNestSeatPos(n);
  player.x = sp.x; player.y = sp.y;
  player.moving = false; player.mvX = 0; player.mvY = 0;
  /* 占领 = 改阵营：这一座从此归你，自动索敌时打的是 A/B，不再打你 */
  n.faction = (typeof combatFaction === 'function') ? combatFaction(player) : 'player';
  n.factionTint = (typeof _ftint === 'function') ? _ftint(n.faction) : n.factionTint;
  setMsg('已接管重机枪 · 左键开火 · 按 E 下枪', 2.2);
  return true;
}
function dismountMgNest(){
  const n = player && player.mgNest;
  if (!n) return false;
  n.playerSeat = false;
  player.mgNest = null;
  setMsg('下枪了', 1.2);
  return true;
}
function mgNestPlayerShot(n, M, a, mx, my){
  const D = mgNestDef();
  const maxT = D.range || 520;
  let endT = Math.min(maxT, rayToWall(mx, my, a, maxT, false, true));
  let _tkHit = null, _tkT = 1e9;
  for (const ot of trucks){
    if (!ot || ot.tstate === 'gone') continue;
    const tt = rayTruckT(ot, mx, my, a, maxT);
    if (tt !== null && tt < _tkT){ _tkT = tt; _tkHit = ot; }
  }
  if (_tkHit) endT = Math.min(endT, _tkT);
  let hit = null, hitT = 1e9;
  for (const e of enemies.concat(allies)){
    if (!e || e.dead || !combatCanDamage(player, e)) continue;
    const dx = e.x - mx, dy = e.y - my;
    const tt = dx * Math.cos(a) + dy * Math.sin(a);
    if (tt <= 0 || tt > endT) continue;
    const px = mx + Math.cos(a) * tt, py = my + Math.sin(a) * tt;
    if (Math.hypot(px - e.x, py - e.y) > (e.r || 12) + 6) continue;
    if (tt < hitT){ hitT = tt; hit = e; }
  }
  if (hit) endT = Math.min(endT, hitT);
  tracers.push({ x0: mx, y0: my, x1: mx + Math.cos(a) * endT, y1: my + Math.sin(a) * endT,
                 t: 0, dur: tracerDur(mx, my, mx + Math.cos(a) * endT, my + Math.sin(a) * endT),
                 hit: !!hit, cut: null });
  const _pd = (D.dmg === undefined ? 18 : D.dmg);
  if (_tkHit && (!hit || _tkT <= hitT)) damageTruck(_tkHit, _pd * 2, a);
  if (hit){
    if (hit.controller === 'companion') companionDamage(hit, _pd, player, 'bullet', a);
    else {
      const _dmg = absorbEnemyArmor(hit, _pd, 'bullet');
      hit.hp = (hit.hp === undefined ? 100 : hit.hp) - _dmg;
      if(typeof factionNoteDamage==='function')factionNoteDamage(hit,player,_dmg,'bullet');
      const killed = hit.hp <= 0;
      registerHit(hit, a, _dmg, killed, false);
      spawnDamageNum(hit.x, hit.y - 30, _dmg, killed, false);
      if (killed) killTestEnemy(hit);
      else alertByHit(hit, a);
    }
  } else if (endT < maxT - 1){
    impactWallFx(mx + Math.cos(a) * endT, my + Math.sin(a) * endT, a);
  }
  gunNoise(1.4);
}
function mgNestPlayerTick(n, dt){
  const D = mgNestDef();
  n.overPulse = (n.overPulse || 0) + dt;
  n.mgFireT = Math.max(0, (n.mgFireT || 0) - dt);
  n.mgFlash = Math.max(0, (n.mgFlash || 0) - dt);
  const _nShots = n.mgShots | 0;
  n.mgShots = 0;
  n.mgHeatFired = Math.max(0, (n.mgHeatFired || 0) - dt);
  mgHeatTick(n, D, dt, _nShots);
  /* 转枪：跟鼠标，但有限速 */
  const mwx = mouse.x + cam.x, mwy = mouse.y + cam.y;
  const want = Math.atan2(mwy - n.y, mwx - n.x);
  const step = (D.pmTurn || 11) * dt;
  n.mgAng = normAng(n.mgAng + clamp(normAng(want - n.mgAng), -step, step));
  /* 射手的屁股钉在枪座上：只让人站住，别让"走位"把人从机枪上拽走 */
  const sp = mgNestSeatPos(n);
  player.x = sp.x; player.y = sp.y;
  player.moving = false; player.mvX = 0; player.mvY = 0;
  player.ang = n.mgAng;
  if (!mouse.fire) return;
  if (n.mgOverheat) return;
  if (Math.abs(normAng(want - n.mgAng)) > 0.14) return;
  if (n.mgFireT > 0) return;
  n.mgFireT = Math.max(0.03, D.rof || 0.075);
  n.mgHeatFired = 0.12; n.mgShots = (n.mgShots || 0) + 1;
  /* 枪口位置：跟 drawMgNest 的消焰器末端对齐（枪管 10..34 + 消焰器到 40）
     以前写 30，子弹从枪管中段冒出来，看着像"从枪顶打出去的" */
  const mx = n.x + Math.cos(n.mgAng) * MG_MUZZLE, my = n.y + Math.sin(n.mgAng) * MG_MUZZLE;
  const a = n.mgAng + fxRand(-1, 1) * (D.pmSpread || 0.05);
  mgNestPlayerShot(n, D, a, mx, my);
  spawnPart(mx, my, n.mgAng, 40, 0.10, 'flash', 5.2);
  n.mgFlash = 0.10;
  camShake = Math.max(camShake, 0.5);
  sfxShot();
}
/* ——— 敌人接管 ——— */
function mgNestSeat(n, e){
  if (!n || !e) return false;
  n.seat = e;
  n.dropT = 0;
  e.mgSeat = n;
  e.path = null; e.goal = null; e.hideGoal = null; e.wp = null;
  e.fireCd = Math.max(e.fireCd || 0, 0.2);
  return true;
}
function mgNestUnseat(n){
  if (!n) return false;
  const e = n.seat;
  n.seat = null;
  if (e && e.mgSeat === n) e.mgSeat = null;
  n.dropT = 0;
  return true;
}
/* 空枪位：不开火。以前这里调 mgNestAutoTick，等于"没人也自己打"，观战图上看着像闹鬼。
   现在只做三件事：降温、余焰衰减、枪口慢慢回到摆放方向。 */
function mgNestIdleTick(n, dt){
  const D = mgNestDef();
  n.mgFireT = 0;
  n.mgFlash = Math.max(0, (n.mgFlash || 0) - dt);
  n.mgBurstT = 0;
  n.mgPauseT = 0;
  const _nShots = n.mgShots | 0;
  n.mgShots = 0;
  n.mgHeatFired = Math.max(0, (n.mgHeatFired || 0) - dt);
  mgHeatTick(n, D, dt, _nShots);
  const _mt = (D.turnSpd || 6) * 0.55 * dt;
  n.mgAng = normAng(n.mgAng + clamp(normAng(n.ang - n.mgAng), -_mt, _mt));
}
/* 敌人手操伤害 = 基准值 × 难度系数（普通 1，简单 0.44，困难 1.56，噩梦 2.11） */
function mgNpcDmg(D){
  const base = (D && D.npcDmg !== undefined) ? D.npcDmg : 22;
  const k = (typeof CFG === 'object' && CFG && CFG.eDmg) ? (CFG.eDmg / 9) : 1;
  return base * k;
}
/* m45062：车载机枪的单发伤害也要吃难度系数（以前只有机枪阵地吃，车顶机枪是死值）。
   调用点只有 truckMgTick —— 那是 NPC 车在扫，玩家自己开车时 tstate='driven' 直接 return，
   所以不会把玩家手操的伤害也缩一遍。 */
function mgTruckDmg(e, M){
  const base = (M && M.dmg !== undefined) ? M.dmg : 7;
  /* 玩家阵营的车不缩水：只有敌方/中立车对玩家开火时才按难度走 */
  const enemySide = (typeof truckTeam === 'function') ? (truckTeam(e) === 'enemy') : true;
  if (!enemySide) return base;
  const k = (typeof CFG === 'object' && CFG && CFG.eDmg) ? (CFG.eDmg / 9) : 1;
  return base * k;
}
function mgNestAiTick(n, dt){
  const D = mgNestDef();
  const e = n.seat;
  if (!e) return;
  n.mgFireT = Math.max(0, (n.mgFireT || 0) - dt);
  n.mgFlash = Math.max(0, (n.mgFlash || 0) - dt);
  if ((n.mgBurstT || 0) > 0){
    n.mgBurstT = Math.max(0, n.mgBurstT - dt);
    if (n.mgBurstT <= 0) n.mgPauseT = (D.pause === undefined ? 0.55 : D.pause);
  } else {
    n.mgPauseT = Math.max(0, (n.mgPauseT || 0) - dt);
  }
  const _nShots = n.mgShots | 0;
  n.mgShots = 0;
  n.mgHeatFired = Math.max(0, (n.mgHeatFired || 0) - dt);
  mgHeatTick(n, D, dt, _nShots);
  /* 枪手钉在座位上，身体跟着枪口转 */
  const sp = mgNestSeatPos(n);
  e.x = sp.x; e.y = sp.y; e.spd = 0;
  /* 打谁不写死"玩家"：座位上的这个人按自己阵营挑目标。
     A 的兵坐上去会先打玩家/ B 的兵；B 的兵坐上去只打 A 的兵（中立时干脆不开火）。 */
  const _tgt = (typeof mgNestPickTarget === 'function') ? mgNestPickTarget(n, D.range || 520, e) : player;
  if (!_tgt){
    /* 没有可打的人：枪口跟着身体，不乱转 */
    const _idle = e.ang;
    const _mt = (D.turnSpd || 6) * dt;
    n.mgAng = normAng(n.mgAng + clamp(normAng(_idle - n.mgAng), -_mt, _mt));
    e.ang = n.mgAng;
    return;
  }
  const want = Math.atan2(_tgt.y - n.y, _tgt.x - n.x);
  const maxTurn = (D.turnSpd || 6) * dt;
  n.mgAng = normAng(n.mgAng + clamp(normAng(want - n.mgAng), -maxTurn, maxTurn));
  e.ang = n.mgAng;
  if (_tgt.hp !== undefined && _tgt.hp <= 0) return;
  const d = dist(n.x, n.y, _tgt.x, _tgt.y);
  if (d > (D.range || 520)) return;
  if (losBlocked(n.x, n.y, _tgt.x, _tgt.y)) return;
  if (Math.abs(normAng(want - n.mgAng)) > (D.aimTol || 0.20)) return;
  if (n.mgBurstT <= 0){
    if (n.mgPauseT > 0) return;
    n.mgBurstT = (D.burst === undefined ? 0.55 : D.burst);
  }
  if (n.mgFireT > 0) return;
  if (n.mgOverheat) return;
  n.mgFireT = Math.max(0.016, D.rof || 0.075);
  n.mgHeatFired = 0.12; n.mgShots = (n.mgShots || 0) + 1;
  const a = n.mgAng + rand(-(D.spread || 0.10), (D.spread || 0.10));
  /* 枪口位置：跟 drawMgNest 的消焰器末端对齐（枪管 10..34 + 消焰器到 40）
     以前写 30，子弹从枪管中段冒出来，看着像"从枪顶打出去的" */
  const mx = n.x + Math.cos(n.mgAng) * MG_MUZZLE, my = n.y + Math.sin(n.mgAng) * MG_MUZZLE;
  spawnBullet(mx, my, mx, my, Math.cos(a) * (D.spd || 1000), Math.sin(a) * (D.spd || 1000),
              e, 0.55, mgNpcDmg(D), false, 0, false);
  n.mgFlash = 0.05;
  spawnPart(mx, my, a, 260, 0.08, 'flash', 5.5);
  spawnPart(mx, my, a, 90, 0.16, 'smoke', 3.5);
  if (typeof enemyGunSfx === 'function'){ if (!enemyGunSfx(n.x, n.y, 'uzi')) sfxShot(); }
  else sfxShot();
}
/* 谁该挨这一枪：只认阵营，不认"是不是玩家"。
   candidates = 玩家（若敌对）+ 队友 + 所有敌人，取射程内、有视线、最近的。 */
function mgNestPickTarget(n, range, shooter){
  const src = shooter || n;
  const can = (t) => {
    if (!t || t === src) return false;
    if (t === player && typeof godInvis === 'function' && godInvis()) return false;
    if (t === player && (cricketOn() || godSafe())) return false; // 观战者和受保护的玩家不是索敌目标。
    if (t.dead || t.gone) return false;
    if (t.hp !== undefined && t.hp <= 0) return false;
    if (t.tstate === 'gone') return false;
    if (typeof factionWantsFight === 'function' && !factionWantsFight(src, t)) return false;
    return true;
  };
  let best = null, bd = range + 1;
  const consider = (t) => {
    if (!can(t)) return;
    const d = dist(n.x, n.y, t.x, t.y);
    if (d > range || d >= bd) return;
    if (losBlocked(n.x, n.y, t.x, t.y)) return;
    bd = d; best = t;
  };
  consider(player);
  if (typeof companions !== 'undefined' && companions) for (const c of companions) consider(c);
  if (typeof enemies !== 'undefined' && enemies) for (const e of enemies) consider(e);
  return best;
}
/* 无人阵地自动开火：和有人时一样的节奏/过热，只是射手记在这个阵地自己身上 */
function mgNestAutoTick(n, dt){
  const D = mgNestDef();
  n.mgFireT = Math.max(0, (n.mgFireT || 0) - dt);
  n.mgFlash = Math.max(0, (n.mgFlash || 0) - dt);
  if ((n.mgBurstT || 0) > 0){
    n.mgBurstT = Math.max(0, n.mgBurstT - dt);
    if (n.mgBurstT <= 0) n.mgPauseT = (D.pause === undefined ? 0.55 : D.pause);
  } else {
    n.mgPauseT = Math.max(0, (n.mgPauseT || 0) - dt);
  }
  const _nShots = n.mgShots | 0;
  n.mgShots = 0;
  n.mgHeatFired = Math.max(0, (n.mgHeatFired || 0) - dt);
  mgHeatTick(n, D, dt, _nShots);
  const t = mgNestPickTarget(n, D.range || 520, n);
  if (!t) return;
  const want = Math.atan2(t.y - n.y, t.x - n.x);
  const maxTurn = (D.turnSpd || 6) * dt;
  n.mgAng = normAng(n.mgAng + clamp(normAng(want - n.mgAng), -maxTurn, maxTurn));
  if (Math.abs(normAng(want - n.mgAng)) > (D.aimTol || 0.20)) return;
  if (n.mgBurstT <= 0){
    if (n.mgPauseT > 0) return;
    n.mgBurstT = (D.burst === undefined ? 0.55 : D.burst);
  }
  if (n.mgFireT > 0 || n.mgOverheat) return;
  n.mgFireT = Math.max(0.016, D.rof || 0.075);
  n.mgHeatFired = 0.12; n.mgShots = (n.mgShots || 0) + 1;
  const a = want + rand(-(D.spread || 0.10), (D.spread || 0.10));
  const mx = n.x + Math.cos(n.mgAng) * MG_MUZZLE, my = n.y + Math.sin(n.mgAng) * MG_MUZZLE;
  spawnBullet(mx, my, mx, my, Math.cos(a) * (D.spd || 1000), Math.sin(a) * (D.spd || 1000),
              n, 0.55, mgNpcDmg(D), false, 0, false);
  n.mgFlash = 0.05;
  spawnPart(mx, my, a, 260, 0.08, 'flash', 5.5);
  spawnPart(mx, my, a, 90, 0.16, 'smoke', 3.5);
  if (typeof enemyGunSfx === 'function'){ if (!enemyGunSfx(n.x, n.y, 'uzi')) sfxShot(); }
  else sfxShot();
}
function updateMgNests(dt){
  if (!mgNests.length) return;
  const D = mgNestDef();
  /* 玩家坐在上面：那一座归 mgNestPlayerTick，其余照常 */
  for (const n of mgNests){
    if (n.playerSeat){
      if (player.mgNest !== n) n.playerSeat = false;
      else if (player.hp <= 0) dismountMgNest();
      else if (state !== 'play') dismountMgNest();
      else {
        if (!n.seat) mgNestPlayerTick(n, dt);
        continue;
      }
    }
    if (n.seat){
      const e = n.seat;
      if (!e || e.dead || e.hp <= 0 || eStatusHas(e, 'stun')){ mgNestUnseat(n); }
      else {
        const dp = dist(e.x, e.y, player.x, player.y);
        if (player.hp <= 0 || dp > (D.aiDropR || 620)) n.dropT = (n.dropT || 0) + dt;
        else n.dropT = 0;
        if ((n.dropT || 0) > 2.5) mgNestUnseat(n);
      }
    }
    if (!n.seat){
      /* 空枪位：警觉的敌人走到跟前就会坐下来（谁近谁用） */
      let best = null, bd = (D.aiClaimR || 130);
      for (const e of enemies){
        if (!e || e.dead || e.hp <= 0 || e.mgSeat) continue;
        if ((e.alertT || 0) <= 0 && !e.sees) continue;
        if (eStatusHas(e, 'stun')) continue;
        const d = dist(e.x, e.y, n.x, n.y);
        if (d < bd){ bd = d; best = e; }
      }
      if (best) mgNestSeat(n, best);
    }
    if (n.seat) mgNestAiTick(n, dt);
    else if (!n.playerSeat) mgNestIdleTick(n, dt);   /* 没人坐 = 不开火，只降温回正 */
  }
  /* 枪口焰 / 过热余温的计时器：没人用的时候也要走完，不然会僵在那一帧 */
  for (const n of mgNests){
    n.mgFlash = Math.max(0, (n.mgFlash || 0) - dt);
  }
}
function updateTruck(e, dt){
  const L = cur();
  const T = vehicleDef(e && e.type) || enemyType(e);  /* 未知旧输入仍走原回退 */
  e.tt += dt;
  /* 发动机声：只要车在跑，就要吵到附近"敌对阵营"的人（m41341 说敌人对他开的车不理不睬）。
     不走 factionEmitNoise 那条宽相位管线（车不是实体单位，没有 faction），
     直接按阵营过滤后给耳朵附近的人一个 lastKnown —— 半径 780，比枪声略小、比脚步大得多。 */
  if (Math.abs(e.spd || 0) > 70 && !e.wreck){
    e.engNoiseT = (e.engNoiseT || 0) - dt;
    if (e.engNoiseT <= 0){
      e.engNoiseT = 0.40;
      const _own = truckOwner(e);
      const _fac = (typeof truckFaction === 'function') ? truckFaction(e) : 'enemy';
      for (const o of enemies){
        if (!o || o.dead || o.hp <= 0) continue;
        if (o === e) continue;
        if (typeof enemyType === 'function' && (enemyType(o) || {}).static) continue;
        if (typeof combatFaction === 'function' && _own !== 'player' && combatFaction(o) === _fac) continue;
        if (_own === 'player' && typeof combatFaction === 'function' &&
            combatFaction(o) === 'player') continue;
        if (dist(o.x, o.y, e.x, e.y) > 780) continue;
        o.lastKnown = { x: e.x, y: e.y };
        o.alertT = Math.max(o.alertT || 0, 3.5);
        if (!o.sees && o.mode !== 1) o.mode = 1;
      }
    }
  }
  eCdTick(e, dt);          /* 撞车/撞墙的节拍：每帧只在这里减一次，且必须在任何提前 return 之前 */
  e.hitT = Math.max(0, (e.hitT || 0) - dt);
  if (e.tstate !== 'driven') e.wheelRot = (e.wheelRot || 0) + (e.spd || 0) * dt / 9;
  e.hitCd = Math.max(0, (e.hitCd || 0) - dt);   /* 撞完人的短暂冷却，见 truckHitPlayer */
  /* 中立车：活着的敌人贴着它站够 0.8 秒，就被敌方接管 */
  if (truckTeam(e) !== 'enemy' && e.tstate !== 'driven' && !e.wreck){
    let _near = null;
    for (const o of enemies){
      if (!o || o.dead || o.hp <= 0) continue;
      if (dist(o.x, o.y, e.x, e.y) <= e.r + 46){ _near = o; break; }
    }
    if (_near){
      e.reclaimT = (e.reclaimT || 0) + dt;
      if (e.reclaimT >= 0.8){
        truckSetTeam(e, 'enemy', _near);
        setMsg('运兵车被敌人接管了', 1.8);
        if (typeof setBark === 'function') setBark(_near, '这车归我们了。', 1.8, 1, false);
      }
    } else e.reclaimT = 0;
  }
  if (e.tstate === 'gone') return;
  truckMgTick(e, dt);          /* 顶置机枪：转塔、索敌、扣扳机都在这 */
  truckSeparate(e);
  /* 摆着不动的车：既不进门也不放兵也不开走，就当一个结实的掩体 */
  /* 玩家在开：位置由 truckDrive 负责，别让状态机抢方向盘 */
  if (e.tstate === 'driven'){ truckMgPlayerTick(e, dt); return; }   /* 你开着：机枪归你手操 */
  if (e.tstate === 'parked'){ e.spd = 0; return; }
  /* 开发者指挥：无人驾驶开往指定点（m42994） */
  if (e.tstate === 'devdrive'){
    if (typeof devDriveTick === 'function') devDriveTick(e, dt);
    else { e.spd = 0; e.tstate = 'parked'; }
    return;
  }
  /* 瘫痪：原地不动，只有火花和烟在动 */
  if (e.tstate === 'paralyzed'){
    e.spd = 0;
    e.sparkT = (e.sparkT || 0) + dt;
    e.smokeT = (e.smokeT || 0) + dt;
    const sg = T.sparkGap || 0.07, mg = T.smokeGap || 0.16;
    while (e.sparkT >= sg){
      e.sparkT -= sg;
      /* 火花从车壳四处迸，偏上半身（冒起来才看得见） */
      spawnPart(e.x + rand(-42, 42), e.y + rand(-24, 20), rand(0, TAU),
                rand(120, 460), rand(0.16, 0.42), 'mspark', rand(1.0, 2.2));
    }
    while (e.smokeT >= mg){
      e.smokeT -= mg;
      spawnPart(e.x + rand(-26, 26), e.y + rand(-16, 10), -Math.PI/2 + rand(-0.45, 0.45),
                rand(14, 32), rand(0.9, 1.7), 'smoke', rand(12, 19));
    }
    return;
  }

  if (e.tstate === 'drift_in'){
    const dur = T.driftDur || 1.3;
    const p = clamp(e.tt / dur, 0, 1);
    /* 每一种车一套"进场姿势"。不是同一个正弦换参数 —— 四款车是四种**不同的运动结构**：
         truck  基准款：横向来回摆 + 一次大甩尾（原版手感）
         arc    重装车：从侧后方**单方向**斜插进来，一路不回摆，车头始终朝着行进方向
         slide  轻车甩尾：横向摆两下 + 车头**反打**（先朝弯内、再反打），像拉手刹过弯
         plain  民用款：几乎没有横移，老实减速停住
       driftMode 决定用哪一种；下面各自的参数（幅度/频率/相位/加速曲线）再从数据取。 */
    const _mode = T.driftMode || 'truck';
    const ease = 1 - Math.pow(1 - p, (T.driftEase || 2.3));
    const nx = e.sx + (e.tx - e.sx) * ease;
    const ny = e.sy + (e.ty - e.sy) * ease;
    let sway = 0, slip = 0;
    if (_mode === 'arc'){
      /* 单峰：从一侧推出去，到中点最远，然后收回线内 —— 全程一个方向，不回摆 */
      sway = Math.sin(p * Math.PI) * (T.driftSway || 46);
      /* 车头在最后一段慢慢回正。
         m42690：以前这里是 `(p > 0.70 ? 1 : 0.15)` —— 一个**阶跃**，
         p 刚过 0.70 那一帧 slip 系数从 0.15 直接蹦到 1，车头角度瞬变，
         看起来就是"停的时候突然卡一下"。改成平滑 ramp：0.55 起坡、0.95 到顶。 */
      const _ramp = clamp((p - 0.55) / 0.40, 0, 1);
      const _slipK = 0.15 + (1 - 0.15) * (_ramp * _ramp * (3 - 2 * _ramp));  /* smoothstep */
      slip = Math.sin(p * Math.PI) * (T.driftSlip || 0) * _slipK;
    } else if (_mode === 'slide'){
      /* 两次摆动 + 车头反打：sway 和 slip 反相，看起来是"车头指向弯外、车身往里滑" */
      sway = Math.sin(p * Math.PI * (T.driftWave || 1.7)) * (T.driftSway || 46) * (1 - p * 0.35);
      slip = -Math.sin(p * Math.PI * (T.driftSlipWave || 1.9) + (T.driftPhase === undefined ? 0.5 : T.driftPhase))
             * (T.driftSlip || 1.05) * (1 - p * 0.45);
    } else if (_mode === 'plain'){
      sway = Math.sin(p * Math.PI) * (T.driftSway || 20);
      slip = Math.sin(p * Math.PI) * (T.driftSlip || 0.4);
    } else {
      /* 原版：横向正弦来回 + 同向甩尾 */
      sway = Math.sin(p * Math.PI * (T.driftWave || 1.7)) * (T.driftSway || 46) * (1 - p * 0.45);
      slip = Math.sin(p * Math.PI * (T.driftSlipWave || 1.9) + (T.driftPhase === undefined ? 0.5 : T.driftPhase))
             * (T.driftSlip || 1.05) * (1 - p * 0.55);
    }
    /* 漂移末段不能为了抵达 tx/ty 又把前面甩出去的车头收回来。
       旧正弦在最后约 1/3 圈会跨过零点：前一秒还斜着横滑，停车前却突然摆成路线方向，
       于是“漂移视觉”和最终停车姿态完全是两套动作。
       现在 68% 后锁住当时的横移/偏角，只做少量阻尼，且 smoothstep 在末端导数为零，
       这份姿态会连续交给 brake，停车位置和前期甩尾属于同一条运动。 */
    const _commitAt = (T.driftCommitAt === undefined ? 0.68 : T.driftCommitAt);
    if (p > _commitAt){
      let _cs = 0, _ca = 0;
      if (_mode === 'arc'){
        _cs = Math.sin(_commitAt * Math.PI) * (T.driftSway || 46);
        const _rr = clamp((_commitAt - 0.55) / 0.40, 0, 1);
        const _sk = 0.15 + 0.85 * (_rr*_rr*(3-2*_rr));
        _ca = Math.sin(_commitAt * Math.PI) * (T.driftSlip || 0) * _sk;
      } else if (_mode === 'slide'){
        _cs = Math.sin(_commitAt * Math.PI * (T.driftWave || 1.7)) * (T.driftSway || 46) * (1 - _commitAt * 0.35);
        _ca = -Math.sin(_commitAt * Math.PI * (T.driftSlipWave || 1.9) + (T.driftPhase === undefined ? 0.5 : T.driftPhase))
              * (T.driftSlip || 1.05) * (1 - _commitAt * 0.45);
      } else if (_mode === 'plain'){
        _cs = Math.sin(_commitAt * Math.PI) * (T.driftSway || 20);
        _ca = Math.sin(_commitAt * Math.PI) * (T.driftSlip || 0.4);
      } else {
        _cs = Math.sin(_commitAt * Math.PI * (T.driftWave || 1.7)) * (T.driftSway || 46) * (1 - _commitAt * 0.45);
        _ca = Math.sin(_commitAt * Math.PI * (T.driftSlipWave || 1.9) + (T.driftPhase === undefined ? 0.5 : T.driftPhase))
              * (T.driftSlip || 1.05) * (1 - _commitAt * 0.55);
      }
      const _q0 = clamp((p - _commitAt) / Math.max(0.01, 1 - _commitAt), 0, 1);
      const _q = _q0*_q0*(3-2*_q0);
      const _endSwayK = (T.driftParkSwayK === undefined ? (_mode === 'plain' ? 0.45 : 0.90) : T.driftParkSwayK);
      const _endSlipK = (T.driftParkSlipK === undefined ? (_mode === 'plain' ? 0.35 : 0.78) : T.driftParkSlipK);
      sway = _cs + (_cs * _endSwayK - _cs) * _q;
      slip = _ca + (_ca * _endSlipK - _ca) * _q;
    }
    const _prevX = e.x, _prevY = e.y, _prevAng = e.ang;
    e.x = nx - Math.sin(e.head) * sway;
    e.y = ny + Math.cos(e.head) * sway;
    e.ang = e.head + slip;
    e.spd = (T.driftSpd || 900) * (1 - ease) + Math.max(160, (T.driftSpd || 900) * 0.30);
    truckHitPlayer(e);                    /* 漂移进场这一段是真的有碰撞体积的 */
    truckHitEnemies(e);                   /* 敌对阵营的人也会被撞飞 */
    if (p >= 1){
      e.tstate = 'brake'; e.tt = 0;
      e.bx = e.x; e.by = e.y;
      /* 入弯末速交给刹车段：刹车距离由它积分出来，不再用写死的 brakeSlide
         （以前 140px/s 进来只滑 8px 就停住，看着像"瞬间钉在地上"） */
      e.brakeSpd0 = e.spd;
      /* 把漂移末帧的真实姿态、速度方向和角速度交给刹车段。
         刹车不再以 head 为强制终点；角速度只受轮胎阻尼自然衰减，最后可以略微斜停。 */
      e.brakeAng0 = e.ang;
      const _vx = e.x - _prevX, _vy = e.y - _prevY;
      e.brakeDir0 = (Math.abs(_vx) + Math.abs(_vy) > 0.01) ? Math.atan2(_vy, _vx) : e.ang;
      e.brakeYawV0 = clamp(normAng(e.ang - _prevAng) / Math.max(dt, 1/240), -1.35, 1.35);
      sfxTruckBrake(1, false);
    }
  } else if (e.tstate === 'brake'){
    const dur = T.brakeDur || 0.6;
    const p = clamp(e.tt / dur, 0, 1);
    /* 刹车：速度线性降到零；漂移留下的角速度按 (1-p)^2 衰减。
       对角速度积分后车头会顺势再甩一点再停，而不是被某个目标方向牵着回正。 */
    const _s0 = isFinite(e.brakeSpd0) ? e.brakeSpd0 : (T.brakeSpd || 260);
    const _w0 = isFinite(e.brakeYawV0) ? e.brakeYawV0 : 0;
    const _yaw = _w0 * dur * (p - p*p + p*p*p/3); /* ∫(1-p)^2 */
    const _dir0 = isFinite(e.brakeDir0) ? e.brakeDir0 : e.ang;
    const _dir = _dir0 + _yaw * 0.34;              /* 轮迹跟一点甩尾，但不追 head */
    e.spd = Math.max(0, _s0 * (1 - p));
    e.x += Math.cos(_dir) * e.spd * dt;
    e.y += Math.sin(_dir) * e.spd * dt;
    const _ang0 = isFinite(e.brakeAng0) ? e.brakeAng0 : e.ang;
    const _tilt = (T.brakeTilt === undefined ? 0.12 : T.brakeTilt);
    e.ang = normAng(_ang0 + _yaw + Math.sin(p * Math.PI) * _tilt * (1-p) * 0.35);
    truckHitPlayer(e);                    /* 急刹那一下也算撞：车还在滑 */
    truckHitEnemies(e);                   /* 敌对阵营的人也会被撞飞 */
    if (p >= 1){
      e.tstate = 'deploy_troops'; e.tt = 0; e.deployT = 0;
      e.solid = true;                    /* 停稳了：从此是实体 */
      navPatchTruck(e);                  /* 也从此挡路：写进网格，敌人会真的绕开 */
      e.spd = 0;
      e.parkAng = e.ang;                 /* 记住自然停下来的角度，卸兵时别再强摆回 head */
      e.settleT = 0;                     /* 停稳后的余震计时（见下面的 deploy_troops 分支） */
      sfxSlam(true);
      camShake = Math.max(camShake, (T.slamShake === undefined ? 0.55 : T.slamShake));
      /* 停稳那一下从后轮两侧扬起一圈土，别让"停住"只有一个音效 */
      for (let _i = 0; _i < 8; _i++){
        const _a = rand(0, TAU);
        spawnPart(e.x - Math.cos(e.parkAng) * 30 + Math.cos(_a) * rand(6, 26),
                  e.y - Math.sin(e.parkAng) * 30 + Math.sin(_a) * rand(6, 26),
                  _a, rand(18, 46), rand(0.35, 0.7), 'dust', rand(3.5, 6.5));
      }
      setMsg('运兵车停稳了 · 有人要下来', 1.6);
    }
  } else if (e.tstate === 'deploy_troops'){
    const doorDur = T.doorDur || 0.4;
    const hold = T.deployHold || 0.55;
    /* 停稳后的余震：车身在 0.55s 里以 26rad/s 抖两下、幅度指数衰减。
       没有这一段的话 p=1 那一帧车就"冻"住了，前面所有减速都白做。 */
    if ((e.settleT || 0) < 0.55){
      e.settleT = (e.settleT || 0) + dt;
      const _k = 1 - e.settleT / 0.55;
      const _park = isFinite(e.parkAng) ? e.parkAng : e.head;
      e.ang = _park + Math.sin(e.settleT * 26) * 0.022 * _k;
    } else {
      /* 余震完了也不是死的：怠速状态车身有极轻微的抖动（9Hz、±0.006rad） */
      const _park = isFinite(e.parkAng) ? e.parkAng : e.head;
      e.ang = _park + Math.sin(e.tt * 9) * 0.006;
    }
    /* 停稳后先愣一下，再开门 */
    if (e.tt >= hold){
      if (e.door === 0) sfxTruckDoor();
      e.door = clamp((e.tt - hold) / doorDur, 0, 1);
    }
    const n = T.deployCount || 4;
    if (e.door >= 1 && e.spawned < n){
      e.deployT += dt;
      const gap = T.deployGap || 0.26;
      while (e.spawned < n && e.deployT >= e.spawned * gap){
        _truckDeployOne(e, e.spawned);
        e.spawned++;
      }
    }
    if (e.spawned >= n){
      e.leaveT = (e.leaveT || 0) + dt;
      /* 卸完兵在原地停一会儿再起步：以前这里减掉了 deployGap*n，
         4 个人下来后只剩 0.26s，看起来像"人刚落地车就窜了" */
      if (e.leaveT >= (T.leaveDelay === undefined ? 2.4 : T.leaveDelay)){
        truckFinishDeploy(e);
      }
    }
  } else if (e.tstate === 'leave'){
    const acc = T.leaveAccel || 900;
    e.spd = Math.min(T.leaveMaxSpd || 1150, e.spd + acc * dt);
    /* 斜停姿态随起步平滑转回离场路线；0.7 秒完成，低速阶段看得到真实转向过程。 */
    e.leaveSteerT = (e.leaveSteerT || 0) + dt;
    const _lp = clamp(e.leaveSteerT / 0.70, 0, 1);
    const _lk = _lp * _lp * (3 - 2 * _lp);
    const _la0 = isFinite(e.leaveAng0) ? e.leaveAng0 : e.ang;
    const _leaveHead = isFinite(e.head) ? e.head : _la0; /* 兼容脚本/旧存档直接构造 leave 状态 */
    e.ang = normAng(_la0 + normAng(_leaveHead - _la0) * _lk);
    e.x += Math.cos(e.ang) * e.spd * dt;
    e.y += Math.sin(e.ang) * e.spd * dt;
    truckHitPlayer(e);                    /* 开走的时候也是真车，别从玩家身上穿过去 */
    truckHitEnemies(e);                   /* 敌对阵营的人也会被撞飞 */
    /* 开出画面就没了 */
    if (e.x < -400 || e.y < -400 || e.x > (L ? L.w + 400 : W + 400) || e.y > (L ? L.h + 400 : H + 400)){
      e.tstate = 'gone'; e.gone = true; e.dead = true;
      navPatchTruck(e);                  /* 走了就别再占着格子 */
      if (trucks.length <= 1) truckSfxStop();   /* 最后一辆车走了：开走的音效该收了 */
    }
  } else if (e.tstate === 'wreck'){
    e.spd = 0;
    if (T.wreckSmoke) e.smokeT += dt;
  }

  /* 轮胎烟：漂移和刹车时最凶，开走时也有 */
  const smT = (e.tstate === 'drift_in' || e.tstate === 'brake') ? 0.022
            : (e.tstate === 'leave' ? 0.055 : 0);
  if (smT > 0){
    e.smokeAcc = (e.smokeAcc || 0) + dt;
    while (e.smokeAcc >= smT){
      e.smokeAcc -= smT;
      /* 只在后轮两侧扬，别糊在车身上 */
      const rx = e.x - Math.cos(e.ang) * 30, ry = e.y - Math.sin(e.ang) * 30;
      const ox = -Math.sin(e.ang) * 24, oy = Math.cos(e.ang) * 24;
      const _sd = Math.random() < 0.5 ? 1 : -1;
      const bx = rx + ox * _sd + rand(-6, 6);
      const by = ry + oy * _sd + rand(-6, 6);
      spawnPart(bx, by, rand(0, TAU), rand(8, 30), rand(0.28, 0.55),
                'dust', rand(2.5, 5));
    }
  }
  /* 废铁的烟：慢、稀、往上飘 */
  if (e.tstate === 'wreck' && e.smokeT > 0.30){
    e.smokeT = 0;
    spawnPart(e.x + rand(-24, 24), e.y + rand(-16, 16), -Math.PI/2 + rand(-0.4,0.4),
              rand(10, 26), rand(0.9, 1.6), 'smoke', rand(8, 15));
  }
}

function truckHitTest(e, x1, y1, x2, y2){
  const dx=x2-x1,dy=y2-y1,len=Math.hypot(dx,dy);
  return truckBodyEntry(e,x1,y1,len?dx/len:0,len?dy/len:0,len)>=0;
}

/* ---------------- 3-3 巷战：增援 ----------------
   只要这关还活着的人少于上限，就隔一段时间从离你最远的那条街塞一个人进来。
   规则全在关卡数据里：rules.reinforce = {every: 秒, max: 人数上限} */
let reinforceT = 0, reinforceN = 0;
function reinforce(L, dt){
  const cfg = L.rules && L.rules.reinforce;
  if (!cfg) return;
  if (reinforceT < 0){ reinforceT = cfg.every || 20; return; }   /* 进关先空跑一轮，别一开局就刷人 */
  const aliveN = enemies.filter(e => !e.dead && !enemyType(e).static).length;
  if (aliveN >= (cfg.max || 14)){ reinforceT = Math.min(reinforceT, 4); return; }
  reinforceT -= dt;
  if (reinforceT > 0) return;
  reinforceT = cfg.every || 20;

  /* 找离玩家最远、又不在墙里的巡逻点：人是"从别的街口绕过来的" */
  let best = null, bestD = -1;
  for (const slot of L.slots){
    const [sx, sy] = slot.wp ? slot.wp[0] : [slot.x, slot.y];
    const d = dist(sx, sy, player.x, player.y);
    if (d < 420) continue;                       /* 别在脸上刷 */
    if (d > bestD){ bestD = d; best = {x: sx, y: sy}; }
  }
  if (!best) return;
  const at = safeSpot(L, best, 24);
  const e = {
    x:at.x, y:at.y, r:12, ang:rand(0,TAU),
    wp:[[at.x, at.y]], i:0, wait:0,
    mode:1, lastKnown:{x: player.x + rand(-90,90), y: player.y + rand(-90,90)},
    alertT: CFG.eMemory + 6, sees:false, heard:false, chk:null,
    ammo: CFG.mag, fireCd: rand(0.5,1.5), reloading:0, muzzle:0,
    hp: L.enemyHp || 100, maxHp: L.enemyHp || 100, fleeCd:0, boostT: 3
  };
  enemies.push(e);
  assignWeapon(e);
  reinforceN++;
  setBark(e, '这边也有动静！', 1.8, 1);
  setMsg('又有人从街口绕过来了（第 ' + reinforceN + ' 个）', 2.0);
  logWarn('ai', '增援 ' + reinforceN + ' · 从 ' + Math.round(at.x) + ',' + Math.round(at.y) + ' 进场');
}

/* 测试区火箭炮塔：底座本身就是墙体，机械部件只改变绘制姿态。 */
function spawnRocketTurret(pos, fac){
  const D=ROCKET_TURRET_DEF, h=D.baseHalf, pad=D.placeClearance;
  const L=cur();
  const cricket = (typeof cricketOn === 'function') && cricketOn(L);
  const moba=typeof mobaOn==='function' && mobaOn(L);
  if((!CFG.dev&&!cricket&&!moba)||state!=='play'||(!(L.rules&&L.rules.devTest)&&!cricket&&!moba))return false;
  let p=null;
  if(pos&&((typeof devPlaceOK!=='function')||devPlaceOK("rocketTurret",pos.x,pos.y,pad)||cricket||moba))p={x:pos.x,y:pos.y};
  for(let i=0;i<80&&!p;i++){const q=devSpotAt();if(!q)break;
    if(q.x<60||q.y<60||q.x>L.w-60||q.y>L.h-60)continue;
    if(L.walls.some(w=>q.x+pad>w.x&&q.x-pad<w.x+w.w&&q.y+pad>w.y&&q.y-pad<w.y+w.h))continue;
    if(enemies.some(e=>!e.dead&&dist(q.x,q.y,e.x,e.y)<80))continue;p=q;break;}
  if(!p){setMsg('没有足够空间放置炮塔',2);return false;}
  const _fac = fac || ((typeof devSpawnFaction === 'function') ? devSpawnFaction() : 'enemy');
  const w={x:p.x-h,y:p.y-h,w:2*h,h:2*h,rocketTurret:true,type:'rocketTurret',brk:true,mat:'metal',hp:D.hp,maxHp:D.hp,ang:Math.atan2(player.y-p.y,player.x-p.x),turnV:0,fireCd:D.initialCooldown,recoilT:0,smokeT:0,wreck:false};
  /* 观战图：炮塔要有阵营，且目标是"敌对阵营的人"而不是玩家（玩家在观战里是隐形摄像机） */
  if (cricket||moba){
    w.faction = _fac;
    w.cricketFaction = _fac;
    w.cricketTarget = null;
    if (typeof _ftint === 'function') w.factionTint = _ftint(_fac);
  }
  L.walls.push(w);wallGeomVer++;navPatchRect(L,w.x,w.y,w.w,w.h);
  setMsg('火箭炮塔已投放 · 击毁后残骸仍是实体掩体',2.5);return w;
}
function damageRocketTurret(w,dmg,hx,hy,ang){
  impactWallFx(hx,hy,ang||0);if(w.wreck)return;
  w.hp=Math.max(0,w.hp-Math.max(0,dmg));w.hitT=.14;
  if(w.hp===0){w.wreck=true;w.turnV=0;w.recoilT=0;w.fireCd=0;w.brk=false;
    const h=ROCKET_TURRET_DEF.baseHalf;
    for(let i=0;i<12;i++)spawnPart(w.x+h,w.y+h,fxRand(0,TAU),fxRand(25,110),fxRand(.3,.7),'smoke',fxRand(5,12));
    setMsg('火箭炮塔报废 · 残骸可作掩体',2);}
}
function turretRecoil(w){const t=w.recoilT||0;return t<=0?0:14*(t>.68?( .76-t)/.08:Math.pow(t/.68,2));}
/* m45306：炮塔不往自己人堆里开炮。
   判据是"弹着点周围这一个圈里有没有同阵营的活人" —— 不是炮塔自己周围，
   因为炮塔离得远、炸的是目标附近。中立/无阵营的炮塔按 combatFaction 走。 */
function turretAllyNear(w, tgt, r){
  if (!tgt || typeof enemies === 'undefined' || !enemies) return false;
  const rf = r || (ROCKET_TURRET_DEF.friendlyClear || 130);
  const myF = (w && w.cricketFaction) ? w.cricketFaction
            : ((typeof combatFaction === 'function') ? combatFaction(w) : 'enemy');
  for (const o of enemies){
    if (!o || o.dead || !(o.hp > 0)) continue;
    if (o === tgt) continue;
    const of = (typeof combatFaction === 'function') ? combatFaction(o) : (o.faction || 'enemy');
    if (of !== myF) continue;
    if (dist(tgt.x, tgt.y, o.x, o.y) <= rf) return true;
  }
  return false;
}
/* m18993：军团推塔里的"炮塔"（= 双方水晶，走 spawnRocketTurret）单独削一档。
   只认 w.kind === 'core'，其它模式 / 斗蛐蛐 / 开发者放炮塔全部吃原值，不动 ROCKET_TURRET_DEF（Object.freeze）。 */
const MOBA_CORE_K = { range: 0.72, dmg: 0.6, cd: 1.3 };
function rocketTurretDefFor(w){
  const D = ROCKET_TURRET_DEF;
  if (!w || w.kind !== 'core') return D;
  const num = (v,d)=> (typeof v === 'number' && isFinite(v)) ? v : d;
  const out = Object.assign({}, D);
  out.spectatorRange = Math.round(num(D.spectatorRange,900) * MOBA_CORE_K.range);
  out.directDamage   = Math.round(num(D.directDamage,100) * MOBA_CORE_K.dmg * 10) / 10;
  out.attackCooldown = Math.round(num(D.attackCooldown,3.2) * MOBA_CORE_K.cd * 100) / 100;
  return out;
}
function updateRocketTurrets(dt){
  const _H0=ROCKET_TURRET_DEF.baseHalf;
  for(const w of cur().walls){if(!w.rocketTurret)continue;
    const D = rocketTurretDefFor(w), h = D.baseHalf || _H0;   /* m18993：逐座取（军团水晶按 MOBA_CORE_K 削） */
    w.recoilT=Math.max(0,(w.recoilT||0)-dt);w.hitT=Math.max(0,(w.hitT||0)-dt);
    w.smokeT=(w.smokeT||0)-dt;w.fireT=(w.fireT||0)-dt;
    if(w.wreck){
      w.irOn=false; w.irLen=0; w.irK=0; w.irFlash=0;   /* m45600：废铁不再有红外 */
      /* 废铁一直烧：火苗密（0.055s 一颗）从断口往上舔，烟稀（0.13s 一团）慢慢滚上去。
         两者各走各的计时，不共用 —— 共用的话火一大烟就跟着变密，看着像爆燃。 */
      if(w.fireT<=0){
        w.fireT=0.050;
        const _fx=w.x+58+fxRand(-7,9), _fy=w.y+34+fxRand(-6,6);
        spawnPart(_fx,_fy,-Math.PI/2+fxRand(-.5,.5),fxRand(12,34),fxRand(.30,.66),'fire',fxRand(4.6,8.6));
        if(fxRand(0,1)<0.35)spawnPart(_fx,_fy,fxRand(0,TAU),fxRand(30,70),fxRand(.12,.26),'spark',fxRand(1,2));
      }
      if(w.smokeT<=0){
        w.smokeT=0.100;
        spawnPart(w.x+58+fxRand(-9,11),w.y+30+fxRand(-6,4),-Math.PI/2+fxRand(-.35,.35),fxRand(14,30),fxRand(1.2,2.1),'smoke',fxRand(14,22));
        if(fxRand(0,1)<0.35)spawnPart(w.x+58,w.y+32,-Math.PI/2+fxRand(-.6,.6),fxRand(24,46),fxRand(.5,.9),'smoke',fxRand(5,9));
      }
      continue;
    }
    if(w.hp/w.maxHp<D.lowHealthRatio&&w.smokeT<=0){w.smokeT=.22;
      spawnPart(w.x+29,w.y+23,-Math.PI/2+fxRand(-.3,.3),fxRand(8,20),fxRand(.65,1.2),'smoke',fxRand(6,10));
      spawnPart(w.x+46,w.y+25,fxRand(0,TAU),30,.16,'flash',3);}
    w.fireCd=Math.max(0,w.fireCd-dt);const x=w.x+h,y=w.y+h;
    /* 观战图：炮塔打"敌对阵营的人"，玩家只是隐形摄像机（m41899）。
       每帧找最近的一个活着的敌对单位，找不到就不开火。 */
    /* m45600：锁定瞬间给一记"抓到你了"的闪光（irFlash 0.34→0），画在 drawRocketTurret 里 */
    w.irFlash = Math.max(0, (w.irFlash||0) - dt);
    w.irK = Math.max(0, Math.min(1, (w.irK||0) + (w.irOn ? dt*7 : -dt*9)));
    if (w.cricketFaction){
      let best=null,bd=D.spectatorRange;
      if (typeof enemies!=='undefined'&&enemies){
        for (const o of enemies){
          if (!o||o.dead||!(o.hp>0))continue;
          const of=(typeof combatFaction==='function')?combatFaction(o):(o.faction||'enemy');
          if (of===w.cricketFaction)continue;
          const d=dist(x,y,o.x,o.y);
          if (d<bd){bd=d;best=o;}
        }
      }
      w.cricketTarget=best;
      w.irOn = !!best; w.irLen = w.irOn ? bd : 0;
      if (w.irOn && !w.irOnPrev) w.irFlash = 0.34;
      w.irOnPrev = w.irOn;
      if (!best){ w.turnV*=Math.max(0,1-dt*3); w.ang=normAng(w.ang+w.turnV*dt); continue; }
      const err=normAng(Math.atan2(best.y-y,best.x-x)-w.ang);
      const desired=clamp(err*1.6,-.85,.85);
      w.turnV+=clamp(desired-w.turnV,-1.8*dt,1.8*dt);w.ang=normAng(w.ang+w.turnV*dt);
      if (Math.abs(err)>.12||w.fireCd>0)continue;
      /* m45306：目标身边有自己人就不开炮（炮弹不分敌我，会把自己人一起炸） */
      if (turretAllyNear(w, best)) continue;
      const a2=w.ang;
      const edge2=h/Math.max(Math.abs(Math.cos(a2)),Math.abs(Math.sin(a2)))+3;
      const mz2=Math.max(edge2,Math.min(65,bd-best.r-3));
      const ax2=x+Math.cos(a2)*mz2,ay2=y+Math.sin(a2)*mz2;
      spawnBullet(ax2,ay2,ax2,ay2,Math.cos(a2)*ROCKET_SPD,Math.sin(a2)*ROCKET_SPD,w,ROCKET_LIFE,D.directDamage,true,ROCKET_BODY_R,true);
      w.fireCd=D.attackCooldown;w.recoilT=.76;spawnPart(ax2,ay2,a2,0,.10,'flash',12);
      if (typeof sfxRocketFire === 'function') sfxRocketFire(ax2,ay2);
      else sfxGunShot(gunDef({wid:'rpg'}));
      continue;
    }
    /* m45306：炮塔弹是"穿墙炮弹"（见 42-actors 的 turretRocket 分支），
       所以不再用墙体/门做视线判定 —— 否则会出现"能打穿墙却不肯瞄"的怪相。
       掩体之外只保留：血量、隐蔽、射程、烟。 */
    const visible=player.hp>0&&!concealed&&dist(x,y,player.x,player.y)<enemyVisionRange(w) && !smokeBlocks(x,y,player.x,player.y,true);
    /* m45600：红外指示线 —— 只在真的看得见玩家时亮，玩家借此知道自己暴露了 */
    w.irOn = visible; w.irLen = visible ? dist(x,y,player.x,player.y) : 0;
    if (w.irOn && !w.irOnPrev) w.irFlash = 0.34;
    w.irOnPrev = w.irOn;
    const err=visible?normAng(Math.atan2(player.y-y,player.x-x)-w.ang):0;
    const desired=visible?clamp(err*1.6,-.85,.85):0;
    w.turnV+=clamp(desired-w.turnV,-1.8*dt,1.8*dt);w.ang=normAng(w.ang+w.turnV*dt);
    if(!visible||Math.abs(err)>.10||w.fireCd>0||player.grace>0)continue;
    /* m45306：玩家身边站着炮塔自己人时也不打（不然一炮把自己人清了） */
    if (turretAllyNear(w, player)) continue;
    const a=w.ang;
    const edge=h/Math.max(Math.abs(Math.cos(a)),Math.abs(Math.sin(a)))+3;
    const muzzle=Math.max(edge,Math.min(65,dist(x,y,player.x,player.y)-player.r-3));
    const ax=x+Math.cos(a)*muzzle,ay=y+Math.sin(a)*muzzle;
    spawnBullet(ax,ay,ax,ay,Math.cos(a)*ROCKET_SPD,Math.sin(a)*ROCKET_SPD,w,ROCKET_LIFE,D.directDamage,true,ROCKET_BODY_R,true);
    w.fireCd=D.attackCooldown;w.recoilT=.76;spawnPart(ax,ay,a,0,.10,'flash',12);
    if (typeof sfxRocketFire === 'function') sfxRocketFire(ax,ay);
    else sfxGunShot(gunDef({wid:'rpg'}));
  }
}

/* ===== m45698 机枪棱堡（mgSentry）：会自己找人的连发据点 =====
   和火箭炮塔共用"墙"这条数据结构（能被拆、能挡路、残骸还是掩体），
   区别只在：打的是子弹、要换弹、只认阵营（不专门针对玩家）。 */
function mgSentryDef(){
  return (typeof MG_SENTRY_DEF === 'object' && MG_SENTRY_DEF) ? MG_SENTRY_DEF : {};
}
function spawnMgSentry(pos, fac){
  const D = mgSentryDef(), h = D.baseHalf || 30, pad = D.placeClearance || 44;
  const L = cur();
  const cricket = (typeof cricketOn === 'function') && cricketOn(L);
  const moba = (typeof mobaOn === 'function') && mobaOn();
  if ((!CFG.dev && !cricket && !moba) || state !== 'play' || (!(L.rules && L.rules.devTest) && !cricket && !moba)) return false;
  let p = null;
  if (pos && ((typeof devPlaceOK !== 'function') || devPlaceOK('mgSentry', pos.x, pos.y, pad) || cricket || moba)) p = { x: pos.x, y: pos.y };
  for (let i = 0; i < 80 && !p; i++){
    const q = devSpotAt(); if (!q) break;
    if (q.x < 60 || q.y < 60 || q.x > L.w - 60 || q.y > L.h - 60) continue;
    if (L.walls.some(w => q.x + pad > w.x && q.x - pad < w.x + w.w && q.y + pad > w.y && q.y - pad < w.y + w.h)) continue;
    if (enemies.some(e => !e.dead && dist(q.x, q.y, e.x, e.y) < 80)) continue;
    p = q; break;
  }
  if (!p){ setMsg('没有足够空间放置棱堡', 2); return false; }
  const _fac = fac || ((typeof devSpawnFaction === 'function') ? devSpawnFaction() : 'enemy');
  const w = {
    x: p.x - h, y: p.y - h, w: 2 * h, h: 2 * h,
    mgSentry: true, type: 'mgSentry', brk: true, mat: 'metal',
    hp: D.hp, maxHp: D.hp,
    ang: Math.atan2(player.y - p.y, player.x - p.x),
    baseAng: Math.atan2(player.y - p.y, player.x - p.x),   /* 沙袋射击口锚定这个方向，不跟枪口转（m45862） */
    faction: _fac, factionTint: (typeof _ftint === 'function') ? _ftint(_fac) : '#6d8fb8',
    mag: D.mag || 200, reloadT: 0, fireT: 0, burstT: 0, flash: 0, hurtT: 0
  };
  L.walls.push(w); wallGeomVer++; navPatchRect(L, w.x, w.y, w.w, w.h);
  setMsg('机枪棱堡已投放 · 认阵营，不认人', 2.5);
  logInfo('mgsentry', '投放机枪棱堡 (' + Math.round(p.x) + ',' + Math.round(p.y) + ') fac=' + _fac);
  return w;
}
function mgSentryHostile(s, o){
  if (!o || o.dead || o.hp <= 0) return false;
  if (typeof combatFaction !== 'function' || typeof factionsHostile !== 'function') return false;
  const fa = (typeof factionAlias === 'function') ? factionAlias(s.faction) : s.faction;
  const fb = (typeof factionAlias === 'function') ? factionAlias(combatFaction(o)) : combatFaction(o);
  if (!fa || !fb || fa === fb || fa === 'neutral' || fb === 'neutral') return false;
  return factionsHostile(fa, fb);
}
function updateMgSentries(dt){
  if (typeof bullets === 'undefined' || !bullets) return;
  const L = cur();
  for (const s of L.walls){
    if (!s.mgSentry) continue;
    const D = mgSentryDef();   /* m18993：棱堡不改，只削炮塔（水晶） */
    s.flash = Math.max(0, (s.flash || 0) - dt);
    s.recoil = Math.max(0, (s.recoil || 0) - dt * 7);   /* 后坐回落 */
    s.hurtT = Math.max(0, (s.hurtT || 0) - dt);
    s.lockT = Math.max(0, (s.lockT || 0) - dt);   /* m45955：复仇锁定倒计时（别一直锁） */
    if (s.hp <= 0) continue;
    const cx = s.x + s.w / 2, cy = s.y + s.h / 2;
    /* 换弹窗口：枪口抬起，谁都不打 —— 这是玩家唯一的进攻时机 */
    if ((s.reloadT || 0) > 0){
      s.reloadT = Math.max(0, s.reloadT - dt);
      if (s.reloadT <= 0) s.mag = D.mag || 200;
      continue;
    }
    let best = null, bd = D.range || 520;
    for (const e of enemies){
      if (!mgSentryHostile(s, e)) continue;
      const d = dist(cx, cy, e.x, e.y); if (d < bd){ bd = d; best = e; }
    }
    if (s.mobaSide===undefined && mgSentryHostile(s, player)){
      const d = dist(cx, cy, player.x, player.y); if (d < bd){ bd = d; best = player; }
    }
    /* m45955：没有看得见的人，但刚挨过打 → 朝"挨打的方向"盲打一阵（有射程上限，锁 1.6 秒） */
    let tx = 0, ty = 0, blind = false;
    if (best){ tx = best.x; ty = best.y; }
    else if ((s.lockT || 0) > 0 && typeof s.lockX === 'number'){
      tx = s.lockX; ty = s.lockY; blind = true;
      if (dist(cx, cy, tx, ty) > (D.range || 520)){ s.burstT = 0; s.fireT = 0; continue; }
    } else { s.burstT = 0; s.fireT = 0; continue; }
    if (!blind && typeof smokeBlocks === 'function' && smokeBlocks(cx, cy, tx, ty, true)){ s.burstT = 0; continue; }
    const want = Math.atan2(ty - cy, tx - cx);
    const err = normAng(want - s.ang);
    const turn = (D.turnSpd || 5.0) * dt;
    s.ang = normAng(s.ang + Math.max(-turn, Math.min(turn, err)));
    if (Math.abs(err) > (D.aimTol || 0.12)){ continue; }
    /* 身前有同伙就压枪（子弹也不分敌我） */
    let blocked = false;
    for (const e of enemies){
      if (e === best || e.dead) continue;
      if (!mgSentryHostile(s, e)) continue;
      if (dist(cx, cy, e.x, e.y) < (D.friendlyClear || 90)){ blocked = true; break; }
    }
    if (blocked) continue;
    s.burstT = (s.burstT || 0) + dt;
    if (s.burstT > (D.burst || 0.9)){ s.burstT = 0; s.fireT = -(D.pause || 0.55); continue; }
    if ((s.fireT || 0) > 0){ s.fireT -= dt; continue; }
    s.fireT = D.rof || 0.14;
    const sp = (D.spread || 0.05) * (blind ? 1.5 : 1);   /* 盲打再散一点：是"压制"，不是狙击 */
    const a = s.ang + (Math.random() - 0.5) * 2 * sp;
    const mz = (D.baseHalf || 30) + 12;
    spawnBullet(cx + Math.cos(a) * mz, cy + Math.sin(a) * mz, cx, cy,
                Math.cos(a) * (D.spd || 1100), Math.sin(a) * (D.spd || 1100),
                s, 1.4, D.dmg || 9, false, 3);
    s.mag = Math.max(0, (s.mag || 0) - 1);
    if (s.mag <= 0){ s.reloadT = D.reloadT || 3.5; s.burstT = 0; s.fireT = 0; }
    if (!s.flash || s.flash < 0.06) s.flash = 0.09;
    s.recoil = 1;   /* 枪管后坐：drawMgSentry 里按这个值往后退 */
    if (typeof sfxMgSentry === 'function') sfxMgSentry(cx, cy);   /* m45899：棱堡专属低频"咚咚" */
    if (typeof spawnPart === 'function') spawnPart(cx + Math.cos(a) * mz, cy + Math.sin(a) * mz, 'flash', 0.05);
  }
}
