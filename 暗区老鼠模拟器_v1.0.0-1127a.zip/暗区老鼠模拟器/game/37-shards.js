/* ============ 爆炸碎片：手雷铁壳炸开，几十块铁皮到处飞 ============
   为什么要单独一套：fxParts 那套是"贴图粒子"（血、火星、烟），
   没有碰撞、不会贴墙、也没有朝向 —— 碎片要的是"撞墙叮一下、掉地上躺一会儿"。
   数量硬上限 NADE_SHARD_CAP，超了就把最早的顶掉，绝不无限长。 */
/* 铁皮的颜色：军绿漆 + 崩掉漆的钢灰 + 被烧黑的边角，不能是纸片那种米白 */
const NADE_SHARD_COLS = ['#65705a', '#7d8767', '#9aa189', '#4b5540', '#b6bcaa', '#39412f'];
function nadeSpawnShards(x, y){
  const L = cur();
  for (let i = 0; i < NADE_SHARD_N; i++){
    if (nadeShards.length >= NADE_SHARD_CAP) nadeShards.shift();
    const a = fxRand(0, TAU);
    /* 两极分化：四成是猛地飞出去的（能甩出爆炸半径之外），六成软绵绵掉在附近；
       每 10 块里有一块是大块的弹壳片，肉眼一眼能看见 */
    const big = (i % 10) === 0;
    const sp = big ? fxRand(300, 620) : (i % 5 < 2 ? fxRand(760, 1320) : fxRand(260, 760));
    nadeShards.push({
      x: x + Math.cos(a) * fxRand(0, 8),
      y: y + Math.sin(a) * fxRand(0, 8),
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      rot: fxRand(0, TAU),
      spin: fxRand(-22, 22),
      len: big ? fxRand(15, 22) : fxRand(5.0, 13.0),
      wid: big ? fxRand(4.0, 6.0) : fxRand(1.8, 3.8),
      col: NADE_SHARD_COLS[(fxRand(0, NADE_SHARD_COLS.length)) | 0],
      t: 0,
      dur: fxRand(1.1, 2.4),
      bounces: 0,
      stuck: false
    });
  }
}

function nadeShardHit(s, r){
  /* 点是否在矩形里（碎片比手雷小得多，用点判定就够） */
  return s.x > r.x && s.x < r.x + r.w && s.y > r.y && s.y < r.y + r.h;
}
function updateNadeShards(dt){
  if (!nadeShards.length) return;
  const L = cur();
  for (let i = nadeShards.length - 1; i >= 0; i--){
    const s = nadeShards[i];
    s.t += dt;
    if (s.t >= s.dur){ nadeShards.splice(i, 1); continue; }
    if (s.stuck) continue;
    s.x += s.vx * dt;
    s.y += s.vy * dt;
    s.rot += s.spin * dt;
    const drag = Math.max(0, 1 - dt * 1.5);       /* 空气阻力：小碎片也能甩出 400~600px */
    s.vx *= drag; s.vy *= drag;
    /* 撞墙：钉住（0.35 概率弹一下再钉），留一小撮灰 */
    let hit = false;
    for (const w of L.walls){
      if (w.dead || w.glass) continue;
      if (nadeShardHit(s, w)){ hit = true; break; }
    }
    if (!hit && typeof doors !== 'undefined' && doors){
      for (const d of doors){
        if (d.broken || !doorSolid(d)) continue;
        if (nadeShardHit(s, d)){ hit = true; break; }
      }
    }
    if (hit){
      if (s.bounces < 1 && Math.abs(s.vx) + Math.abs(s.vy) > 420){
        s.bounces++;
        s.x -= s.vx * dt * 1.6; s.y -= s.vy * dt * 1.6;
        s.vx *= -0.35; s.vy *= -0.35;
      } else {
        s.stuck = true; s.vx = 0; s.vy = 0;
        s.x -= s.vx * dt; s.y -= s.vy * dt;
      }
      s.dur = Math.min(s.dur, s.t + 0.9);         /* 钉住之后很快就淡掉 */
    }
    if (s.x < 6 || s.y < 6 || s.x > L.w - 6 || s.y > L.h - 6){
      s.stuck = true; s.vx = 0; s.vy = 0;
      s.x = clamp(s.x, 6, L.w - 6); s.y = clamp(s.y, 6, L.h - 6);
      s.dur = Math.min(s.dur, s.t + 0.9);
    }
    /* 偶尔在地上拖一粒灰，让"到处飞"有落点感（限量，别刷屏） */
    if (!s.stuck && fxRand(0, 1) < 0.035) spawnPart(s.x, s.y, fxRand(0, TAU), fxRand(0, 26), fxRand(0.25, 0.5), 'bsmoke', fxRand(2.5, 5));
  }
  /* 碎片比粒子活得久，删的时候顺手把已经淡到 0 的清掉 */
  while (nadeShards.length > NADE_SHARD_CAP) nadeShards.shift();
}

function drawNadeShards(){
  if (!nadeShards.length) return;
  for (const s of nadeShards){
    if (typeof cullPt === 'function' && !cullPt(s.x, s.y, 24)) continue;
    const k = s.t / s.dur;
    const a = clamp(s.stuck ? (1 - k) * 0.9 : 1 - k * 0.30, 0, 1);
    if (a <= 0.02) continue;
    /* 飞着的带一条速度拖影：截图里也能看出"嗖"的一下 */
    if (!s.stuck){
      const tl = Math.hypot(s.vx, s.vy) * 0.022;
      if (tl > 1.5){
        ctx.save();
        ctx.globalAlpha = a * 0.30;
        ctx.strokeStyle = 'rgba(226,232,214,0.9)';
        ctx.lineWidth = Math.max(0.8, s.wid * 0.55);
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(s.x - s.vx * 0.022, s.y - s.vy * 0.022);
        ctx.stroke();
        ctx.restore();
      }
    }
    ctx.save();
    ctx.globalAlpha = a;
    ctx.translate(s.x, s.y);
    ctx.rotate(s.rot);
    ctx.fillStyle = s.col;
    /* 一小块不规则铁皮：窄长条 + 斜切角 */
    ctx.beginPath();
    ctx.moveTo(-s.len * 0.5, -s.wid * 0.5);
    ctx.lineTo(s.len * 0.42, -s.wid * 0.22);
    ctx.lineTo(s.len * 0.5, s.wid * 0.34);
    ctx.lineTo(-s.len * 0.36, s.wid * 0.5);
    ctx.closePath();
    ctx.fill();
    /* 上沿一道亮边 = 金属反光；钉住的再压一层黑，看着像插在地上 */
    ctx.globalAlpha = a * 0.55;
    ctx.strokeStyle = 'rgba(238,242,228,0.85)';
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(-s.len * 0.5, -s.wid * 0.5);
    ctx.lineTo(s.len * 0.42, -s.wid * 0.22);
    ctx.stroke();
    if (s.stuck){
      ctx.globalAlpha = a * 0.30;
      ctx.fillStyle = '#000';
      ctx.fill();
    }
    ctx.restore();
  }
  ctx.globalAlpha = 1;
}

/* 一个圆 vs 一个矩形：推进去 + 速度反射（法向保留 55%，切向打 9 折） */
function nadeBounceRect(n, r, breakGlass=false){
  if (!r || r.w <= 0 || r.h <= 0) return false;
  const cx = clamp(n.x, r.x, r.x + r.w), cy = clamp(n.y, r.y, r.y + r.h);
  const dx = n.x - cx, dy = n.y - cy;
  const d2 = dx * dx + dy * dy;
  if (d2 >= NADE_RAD * NADE_RAD) return false;
  let nx = 0, ny = 0;
  let x = n.x, y = n.y;
  if (d2 > 1e-6){
    const d = Math.sqrt(d2);
    nx = dx / d; ny = dy / d;
    x += nx * (NADE_RAD - d + 0.05);
    y += ny * (NADE_RAD - d + 0.05);
  } else {
    /* 圆心正好在矩形里：从最近的那条边推出去 */
    const l = n.x - r.x, rr = r.x + r.w - n.x, t = n.y - r.y, b = r.y + r.h - n.y;
    const m = Math.min(l, rr, t, b);
    if (m === l){ nx = -1; x = r.x - NADE_RAD; }
    else if (m === rr){ nx = 1; x = r.x + r.w + NADE_RAD; }
    else if (m === t){ ny = -1; y = r.y - NADE_RAD; }
    else { ny = 1; y = r.y + r.h + NADE_RAD; }
  }
  const vn = n.vx * nx + n.vy * ny;
  if (breakGlass && -vn >= FRAG_GRENADE_DEF.glassBreakSpeed){
    shatterGlass(r, cx, cy, Math.atan2(n.vy,n.vx));
    const keep = FRAG_GRENADE_DEF.glassSpeedRetention;
    n.vx *= keep; n.vy *= keep;
    return true;
  }
  n.x = x; n.y = y;
  if (vn < 0){
    let tx = n.vx - vn * nx, ty = n.vy - vn * ny;
    tx *= NADE_FRIC; ty *= NADE_FRIC;
    const vn2 = -vn * NADE_REST;
    n.vx = vn2 * nx + tx;
    n.vy = vn2 * ny + ty;
    n.spin += 0.6;
    if ((n.sndT || 0) <= 0){ n.sndT = 0.09; beep(150 + fxRand(0, 50), 0.05, 'square', 0.035); }
  }
  return true;
}

function updateNades(dt){
  /* 全队投雷节奏：每帧只减一次（放这里 = 与敌人数量无关） */
  if (nadeSquadCd > 0) nadeSquadCd = Math.max(0, nadeSquadCd - dt);
  /* 门前投雷轮次：同样每个模拟步推一次（到期、死人或情报失效都在这里释放名额） */
  if (typeof nadeRoundTick === 'function') nadeRoundTick(dt);
  /* 手里捏着的那颗：引信到 0 就在脚下炸 */
  if (player && player.nadeCooking && player.hand === 'nade'){
    player.nadeFuseLeft = Math.max(0, (player.nadeFuseLeft || 0) - dt);
    if (player.nadeFuseLeft <= 0){
      player.nadeCooking = false;
      nadeTakeOne();
      player.throwCd = NADE_RECOVER;
      setMsg('手雷在手里炸了', 2.6);
      logWarn('nade', '手雷在手里炸了 · 自己吃满伤害');
      nadeBlast(player.x, player.y, player);
    }
  }
  if (player && player.throwCd > 0) player.throwCd = Math.max(0, player.throwCd - dt);
  /* 后摇期间按过左键：后摇一结束就把下一颗甩出去（连投，不用再点一次） */
  if (player && player.nadeQueue && (player.throwCd || 0) <= 0){
    player.nadeQueue = false;
    if (player.hand === 'nade' && nadeCount() > 0){
      const _f = nadeThrowAt(NADE_FUSE);
      setMsg('手雷 ×' + nadeCount() + ' · 再按一下接着扔', 1.2);
      logInfo('nade', '连投 · 引信 ' + _f.toFixed(1) + 's · 剩 ' + nadeCount());
    }
  }
  updateNadeShards(dt);
  if (!nades.length) return;
  const L = cur();
  for (let i = nades.length - 1; i >= 0; i--){
    const n = nades[i];
    n.age += dt;
    n.fuse -= dt;
    if (n.sndT > 0) n.sndT -= dt;
    /* 抛掷（AI 的雷）：空中阶段越过掩体，到点直接落定。
       没有这一段，雷会一头撞在被你当掩体的墙上弹回来 —— 明明"扔过去了"却掉在它自己脚边。 */
    if (n.lobT && !n.lobDone && n.age >= n.lobT){
      n.x = n.tx; n.y = n.ty;
      n.vx = 0; n.vy = 0;
      n.rest = true; n.lobDone = true;
      n.sndT = 0;                      /* 马上响一下落地声 */
      spawnPart(n.x, n.y, 0, 0, 0.18, 'dust', 8);
      sfxSlam(false);
    }
    if (!n.rest){
      /* 子步：一帧最多走 8px，薄墙 / 门框 / 车皮都不会被高速穿过去 */
      const spNow = Math.hypot(n.vx, n.vy);
      const _air = !!(n.lobT && !n.lobDone);      /* 还在空中：不跟墙/门/车碰 */
      const playerThrow = n.by === player && !n.enemyNade;
      const maxStep = playerThrow ? Math.min(NADE_SUB,NADE_RAD) : NADE_SUB;
      let left = dt;
      while (left > 1e-6){
        const stepT = Math.min(left, maxStep / Math.max(spNow, 1));
        left -= stepT;
        n.x += n.vx * stepT;
        n.y += n.vy * stepT;
        if (!_air){
          for (let wi=0;wi<L.walls.length;wi++){
            const w=L.walls[wi];
            if (w.dead || (w.glass && !playerThrow)) continue;
            nadeBounceRect(n,w,!!w.glass);
            if(L.walls[wi]!==w)wi--; // 玻璃碎裂会移除当前墙体
          }
          if (typeof doors !== 'undefined' && doors){
            for (const d of doors){
              if (d.broken || !doorSolid(d)) continue;
              nadeBounceRect(n, d);
            }
          }
          if (typeof trucks !== 'undefined' && trucks){
            for (const t of trucks){
              if (!t || t.wreck || t.tstate === 'gone' || !t.solid) continue;
              nadeBounceRect(n, truckRect(t));
            }
          }
        }
        if (!_air){
          if (n.x < NADE_RAD){ n.x = NADE_RAD; n.vx = Math.abs(n.vx) * NADE_REST; }
          if (n.y < NADE_RAD){ n.y = NADE_RAD; n.vy = Math.abs(n.vy) * NADE_REST; }
          if (n.x > L.w - NADE_RAD){ n.x = L.w - NADE_RAD; n.vx = -Math.abs(n.vx) * NADE_REST; }
          if (n.y > L.h - NADE_RAD){ n.y = L.h - NADE_RAD; n.vy = -Math.abs(n.vy) * NADE_REST; }
        }
        if (Math.hypot(n.vx, n.vy) < NADE_STOP) break;
      }
      const sp2 = Math.hypot(n.vx, n.vy);
      n.spin += sp2 * dt * 0.06;
      if (n.lobT && !n.lobDone){
        /* 空中：匀速直线，不衰减也不收边 —— 一衰减就到不了落点，落地那帧会被硬拽过去 */
      } else if (sp2 < NADE_STOP){ n.vx = 0; n.vy = 0; n.rest = true; }
      else { const damp = Math.max(0, 1 - dt * 0.55); n.vx *= damp; n.vy *= damp; }
    }
    if (n.fuse <= 0){
      nades.splice(i, 1);
      nadeBlast(n.x, n.y, n.by);
    }
  }
}

/* 烟雾弹罐子：地上捡的、背包里看到的、手里拿的、飞在空中的，全部走这一个函数，
   形状才不会"手里一个样、地上另一个样"。
   罐体 + 中间浅色色带 + 顶盖 + 拉环，和手雷的椭圆弹体轮廓不同。 */
function drawSmokeCanister(x, y, s, rot, lit){
  const w2 = 7.44, h2 = 12.6;
  ctx.save();
  ctx.translate(x, y);
  if (s && s !== 1) ctx.scale(s, s);
  if (rot) ctx.rotate(rot);
  ctx.fillStyle = 'rgba(52,62,76,0.98)';
  ctx.strokeStyle = 'rgba(22,28,36,0.85)'; ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(-w2, -h2, w2 * 2, h2 * 2, 3);
  else ctx.rect(-w2, -h2, w2 * 2, h2 * 2);
  ctx.fill(); ctx.stroke();
  /* 中间那道浅色色带（强光下也要看得出来是罐子，不是白药丸） */
  ctx.fillStyle = 'rgba(206,220,236,0.95)';
  ctx.fillRect(-w2, -h2 * 0.16, w2 * 2, h2 * 0.32);
  ctx.fillStyle = 'rgba(120,134,150,0.7)';
  ctx.fillRect(-w2, h2 * 0.30, w2 * 2, 1.4);
  /* 顶盖 + 喷嘴（横着拿时也认得出是烟雾罐） */
  ctx.fillStyle = 'rgba(150,164,182,0.98)';
  ctx.fillRect(-w2 * 0.55, -h2 - 3, w2 * 1.1, 4);
  ctx.fillStyle = 'rgba(64,74,86,0.98)';
  ctx.fillRect(-1.6, -h2 - 6.5, 3.2, 3.8);
  /* 拉环：点燃时变橙 */
  if (lit){
    ctx.fillStyle = 'rgba(255,158,96,0.55)';
    ctx.beginPath(); ctx.arc(w2 * 0.95, -h2 + 1, 5.2, 0, TAU); ctx.fill();
  }
  ctx.strokeStyle = lit ? 'rgba(255,170,110,0.98)' : 'rgba(206,220,236,0.95)';
  ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.arc(w2 * 0.95, -h2 + 1, 3.2, 0, TAU); ctx.stroke();
  ctx.restore();
}

/* 弹体：手雷 = 深橄榄绿椭圆 + 上盖 + 压杆 + 拉环；
   烟雾弹 = 罐子（drawSmokeCanister），光靠颜色区分在暗地图上看不出来，形状必须不一样。
   lit = 引信烧着（冒橙光） */
function drawNadeModel(x, y, s, rot, lit, kind){
  if (kind === 'smoke'){ drawSmokeCanister(x, y, s, rot, lit); return; }
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  if (rot) ctx.rotate(rot);
  /* ---- 手雷 ---- */
  ctx.fillStyle = 'rgb(74,86,58)';
  ctx.beginPath(); ctx.ellipse(0, 0, 7.2, 8.6, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.10)';
  ctx.beginPath(); ctx.ellipse(-2.2, -2.4, 3.4, 4.6, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.28)'; ctx.lineWidth = 0.8;
  for (let gy = -3; gy <= 3; gy += 3){
    ctx.beginPath(); ctx.moveTo(-6.2, gy); ctx.lineTo(6.2, gy); ctx.stroke();
  }
  ctx.fillStyle = 'rgb(52,60,44)';
  ctx.beginPath(); ctx.ellipse(0, -7.4, 4.2, 2.6, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = 'rgb(120,126,110)'; ctx.lineWidth = 1.3; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(2.6, -8.2); ctx.quadraticCurveTo(6.4, -3.2, 4.6, 3.2); ctx.stroke();
  ctx.strokeStyle = lit ? 'rgb(255,158,96)' : 'rgb(186,192,176)'; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(0, -9.6, 2.0, 0, TAU); ctx.stroke();
  ctx.strokeStyle = 'rgb(196,186,120)'; ctx.lineWidth = 1.1;
  ctx.beginPath(); ctx.arc(-3.4, -10.4, 2.2, 0, TAU); ctx.stroke();
  ctx.restore();
}

/* 扔出去的手雷飞到哪画到哪（含引信快到的红闪） */
function drawNadeProjectiles(){
  drawNadeShards();
  if (typeof drawTrips === 'function') drawTrips();
  if (!nades.length) return;
  for (const n of nades){
    if (typeof cullPt === 'function' && !cullPt(n.x, n.y, 80)) continue;
    /* 抛掷中的雷画成"飞在空中"：影子在原地、弹体抬起来，抛物线飞过去才看得懂 */
    const _lobAir = !!(n.lobT && !n.lobDone);
    const _k = _lobAir ? clamp((n.age || 0) / n.lobT, 0, 1) : 1;
    const _lift = _lobAir ? Math.sin(Math.PI * _k) * 46 : 0;
    ctx.globalAlpha = 0.32 * (1 - _lift / 150); ctx.fillStyle = PAL.P_K;
    ctx.beginPath(); ctx.ellipse(n.x, n.y + 7, 5.4 * (1 - _lift / 140), 2.6 * (1 - _lift / 140), 0, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1;
    if (_lobAir){
      /* 一道很淡的落地提示：告诉玩家"要砸这儿" */
      ctx.globalAlpha = 0.28; ctx.strokeStyle = 'rgba(255,170,90,0.9)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(n.tx, n.ty, 13, 0, TAU); ctx.stroke();
      ctx.globalAlpha = 1;
    } else if (n.lobT && (n.age - n.lobT) >= 0 && (n.age - n.lobT) < 0.45){
      /* 刚落地：圈再留 0.45 秒淡出 —— 一眼看得出"就是砸这儿"，不会像弹体跳了一下 */
      const _fade = 1 - (n.age - n.lobT) / 0.45;
      ctx.globalAlpha = 0.5 * _fade; ctx.strokeStyle = 'rgba(255,170,90,0.9)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(n.tx, n.ty, 13, 0, TAU); ctx.stroke();
      ctx.globalAlpha = 1;
    }
    drawNadeModel(n.x, n.y - _lift, 1.0, n.spin, n.fuse <= 1.2);
    if (n.fuse <= 1.2){
      const bl = 0.5 + 0.5 * Math.sin(n.age * 40);
      ctx.globalAlpha = 0.55 * bl;
      ctx.fillStyle = 'rgba(255,120,70,0.85)';
      ctx.beginPath(); ctx.arc(n.x, n.y - _lift - 10, 3.2, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1;
    }
  }
}

/* 手里拿着的：捏着的时候弹体抖动 + 头顶倒计时 */
/* m44696：敌方空炸火箭的落点预警。
   扣扳机那一刻 landX/landY 就写好了（`40-inventory.js`），所以能提前一整段飞行时间告诉玩家"要砸这儿"。
   返回 {x,y,left,t,r}；非敌方火箭（玩家自己打的、普通子弹）返回 null。 */
function rocketWarnOf(b){
  if (!b || !b.rocket || !b.landFuse) return null;
  if (!Number.isFinite(b.landX) || !Number.isFinite(b.landY)) return null;
  if (typeof player !== 'undefined' && b.by === player) return null;   /* 自己打的不吓自己 */
  const spd = Math.hypot(b.vx, b.vy) || 1;
  const left = Math.max(0, Math.hypot(b.landX - b.x, b.landY - b.y) / spd);
  const t = clamp(1 - left / 1.6, 0, 1);          /* 0=刚发射，1=马上落 */
  return { x: b.landX, y: b.landY, left: left, t: t, r: (typeof ROCKET_R === 'number' ? ROCKET_R : 320) };
}

function drawRocketWarn(){
  if (typeof bullets === 'undefined' || !bullets) return;
  for (const rb of bullets){
    const w = rocketWarnOf(rb);
    if (!w) continue;
    if (typeof cullPt === 'function' && !cullPt(w.x, w.y, w.r + 60)) continue;
    /* m44839：用户嫌"落点提醒过于花里胡哨"。砍到只剩两圈：
       一圈标出爆炸范围（静态、很淡），一圈往里收（唯一会动的东西）。
       没有旋转、没有闪烁、没有刻度、也不变色 —— 越接近只是越清楚一点。 */
    ctx.save();
    ctx.strokeStyle = 'rgba(255,120,70,0.9)';
    /* 1) 爆炸范围：一圈细线，快落时才亮一点 */
    ctx.globalAlpha = 0.10 + 0.16 * w.t;
    ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.arc(w.x, w.y, w.r, 0, TAU); ctx.stroke();
    /* 2) 收紧环：从半径一路收到中心，收到就是命中 */
    const rr = 8 + (w.r - 8) * (1 - w.t);
    ctx.globalAlpha = 0.22 + 0.30 * w.t;
    ctx.lineWidth = 1.4 + 1.2 * w.t;
    ctx.beginPath(); ctx.arc(w.x, w.y, rr, 0, TAU); ctx.stroke();
    ctx.restore();
  }
}

function drawHandNade(){
  /* 手里那种已经扔光了就当场纠正：宁可换成另一种，也别举着"概念上的手雷"。
     死亡地带这类不走背包格子的关卡，计数走的是影子字段，最容易出现手里显示
     和袋子里对不上的情况，这里兜一道底。 */
  if (player.hand === 'nade' && nadeCount() <= 0){
    if (smokeCount() > 0){ player.hand = 'smoke'; player.handKind = 'smoke'; }
    else { player.hand = null; }
  } else if (player.hand === 'smoke' && smokeCount() <= 0){
    if (nadeCount() > 0){ player.hand = 'nade'; player.handKind = 'nade'; }
    else { player.hand = null; }
  }
  if (!player.hand) return;
  const a = Math.atan2((mouse.y + cam.y) - player.y, (mouse.x + cam.x) - player.x);
  const cook = !!player.nadeCooking;
  const hx = player.x + Math.cos(a) * (player.r + 5);
  const hy = player.y + Math.sin(a) * (player.r + 5);
  const _kind = player.hand === 'smoke' ? 'smoke' : 'nade';
  drawNadeModel(hx, hy, 1.0, cook ? a + Math.sin(uiT * 24) * 0.12 : a, cook, _kind);
  /* 手上还剩几颗：扔完自动补的那颗也在这儿显示，一眼能看出"补上了" */
  if (!cook){
    const n = throwCountOf(_kind);
    if (n > 0){
      ctx.save();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = 'bold 10px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = 'rgba(20,26,32,0.85)';
      ctx.fillText('x' + n, hx + 10.5, hy - 5.5);
      ctx.fillStyle = 'rgba(232,244,255,0.95)';
      ctx.fillText('x' + n, hx + 10, hy - 6);
      ctx.restore();
    }
  }
  if (cook){
    const left = Math.max(0, player.nadeFuseLeft || 0);
    ctx.save();
    ctx.textAlign = 'center';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = left <= 1.5 ? 'rgba(255,118,96,0.98)' : 'rgba(255,214,140,0.96)';
    ctx.fillText(left.toFixed(1) + 's', hx, hy - 17);
    ctx.restore();
  }
}

/* ---------------- 望远镜（举镜程度） ----------------
   binoK 0 = 收着，1 = 完全举起。update 里缓升缓降，所有视觉/视野都读它，
   所以"慢慢变窄、慢慢拉远"是同一个量的不同倍率。 */
function binoK(){ return (player && player.binoK) || 0; }
/* 望远镜画面是【拉远】不是放大：镜头往后退，看得见的东西变小、视野范围变大。
   想反过来（把远处放大）只改 BINO_ZOOM 的符号：1 + 0.30 就是放大。 */
const BINO_ZOOM_OUT = 0.10;
const BINO_PAN = 280;          /* 举镜时镜头朝视线方向前推多少像素 */
function binoZoomK(){ return 1 - BINO_ZOOM_OUT * binoK(); }   /* 画面拉远（90%，看得见更大范围） */
/* 镜头前推量：举满时相机沿视线方向前移 BINO_PAN 像素。
   比单纯拉远好 —— 远处看得见、背后的建筑被前面推走，玩家也不会缩成一小点。 */
function binoPanK(){ return BINO_PAN * binoK(); }
function binoRangeK(){ return 1 + 1.40 * binoK(); }          /* 视距拉远到 ~2.4 倍 */
function binoFovK(){ return 1 - 0.70 * binoK(); }            /* 光锥收窄到 30%（110° → 33°） */

function tryShoot(){
  if (typeof bindMark === 'function') bindMark('shot');
  /* 第 30 轮：开枪不再打断搜刮（只有走出范围才断） */
  if (playerShieldUp()){
    /* 举着盾不能开枪：别静默吞掉点击，否则玩家以为枪坏了 */
    if (!(player._shieldClickT > 0)){
      player._shieldClickT = 1.6;
      setMsg('举着盾不能开枪 · ' + keyLabel(BINDS.swap) + ' 换枪 / ' + keyLabel('KeyG') + ' 收盾', 1.6);
    }
    return;
  }
  if (player.stunT > 0) return;   /* 被撞晕这半秒开不了枪 */
  if (player && player.hp <= 0) return;
  if (state !== 'play') return;
  if (player.hand) return;   /* 手里拿着投掷物：左键是掐引信/扔，不是开枪 */
  if (playerTruck) return;   /* 在车上：左键归顶置机枪 */
  if (player.mgNest) return; /* 坐在重机枪上：左键归那挺枪 */
  const g = player.gun; if (!g) return;
  if (g.reloading > 0) return;
  /* 装了一颗就想打：点鼠标立刻停止装填并开枪 */
  if (g.shelling){
    if (g.mag <= 0) return;
    g.shelling = false; g.shellT = 0; g.shellPumpT = 0;   /* 不加 cd：装一颗就能马上打 */
  }
  if (g.cd > 0) return;
  /* 投掷位：不吐子弹，扔一颗烟出去 */
  if (g.kind === 'throw'){
    if (g.mag <= 0){ setMsg('没有烟雾弹了', 1.0); return; }
    const before = (player.grenades || 0);
    throwGrenade();
    if ((player.grenades || 0) < before){
      /* ver3 里 bagRebuild() 已经把 mag 同步成背包里的烟数了，别再减一次 */
      if (!bagGridOn()) g.mag--;
      g.cd = g.rof * (ar ? ar.rofMul * arenaRofK() * (g.arenaRof || 1) * ((g.wid === 'shotgun' && ar.sgRof) ? ar.sgRof : 1) : 1);
      if (g.mag <= 0){
        /* 扔完了自动切回枪，免得手里攥着一个空位 */
        const back = Object.keys(player.guns || {}).find(k => gunModel(k) !== 'smoke');
        if (back){ player.gun = player.guns[back]; player.gun.reloading = 0; }
      }
    }
    return;
  }
  /* 刀：不吐子弹，一刀砍出去 */
  if (g.kind === 'melee'){ meleeSwing(g); g.cd = g.rof; return; }
  /* 工具（望远镜）：不吐子弹。举镜由 update 里的 binoK 慢慢抬，
     这里只挡住 hitscan，免得按住左键打出一发"空气子弹" */
  if (g.tool) return;
  /* 火箭筒：一次扳机就是一发。普通「双发」和「倾泻」都不改它的弹药账，
     它的双发是专属金卡【火箭筒扩容】（见下面的 rwBurstT）。 */
  const _isRocket = !!(g.rocket && ar);
  const _cost = _isRocket ? 1 : ((ar && ar.ammoCost) ? ar.ammoCost : 1);
  if (g.mag <= 0){
    if (CFG.dev && CFG.devInfAmmo){ g.mag = g.cap; g.reloading = 0; }   /* 沙盒：空匣当场补满 */
    else if (_isRocket && arenaRocketLeft() <= 0){
      setMsg('没有火箭弹了 · 每拿一张卡才多一发', 1.8); return;
    }
    else { setMsg(_isRocket ? '火箭筒空了 · 按 R 装填' : '没子弹了 · 按 R 换弹', 1.1); reloadGun(); return; }
  }
  /* 双发：一次扣扳机打 1+burst 发，也就吃 1+burst 份弹药。
     弹匣不够就按够的份数打（只剩 1 发时只打 1 发），一粒都不浪费。 */
  const _extra = (_isRocket || !(ar && ar.multiShot)) ? 0
               : Math.max(0, Math.floor(ar.multiShot));
  const _shotsWanted = 1 + _extra;
  let _shots = _shotsWanted;
  if (g.mag < _cost * _shotsWanted) _shots = Math.max(1, Math.floor(g.mag / _cost));
  g.mag = Math.max(0, g.mag - _cost * _shots);
  if (CFG.dev && CFG.devInfAmmo){ g.mag = g.cap; }   /* 开发者：无限子弹，弹匣打空也不进换弹 */
  g.cd = g.rof * (ar ? ar.rofMul * arenaRofK() * (g.arenaRof || 1) * ((g.wid === 'shotgun' && ar.sgRof) ? ar.sgRof : 1) : 1);

  sfxGunShot(g);
  camShake = Math.max(camShake, g.kick);
  /* 后坐力：给一个往后的"速度"，不是直接改坐标。update 里会每秒刹掉九成，
     大概 0.1 秒退完 —— 跑着开枪也只是一个顺滑的推背感，不会卡住脚。 */
  if (g.recoil > 0){
    const kv = g.recoil * 9;
    player.kickX = (player.kickX || 0) - Math.cos(player.aim)*kv;
    player.kickY = (player.kickY || 0) - Math.sin(player.aim)*kv;
  }
  punchT = 0.16; punchAX = Math.cos(player.aim); punchAY = Math.sin(player.aim);
  punchAmp = 4 + g.kick*16;

  const ax = player.x, ay = player.y, a = player.aim;
  if (g.flare){
    /* 信号枪：弹药/后坐/音效在外面已经处理过了，这里只把信号弹推出去 */
    fireFlare(a);
    return;
  }
  if (g.rocket){
    fireRocket(a);
    /* 【火箭筒扩容】：扳机只扣一发弹药，第二发排个队稍后自己出膛 */
    if (ar && ar.rwBurst){ ar.rwBurstT = ROCKET_BURST_GAP; ar.rwBurstA = a; }
    return;
  }
  const n = g.pellets || 1;
  /* \u5f00\u4e00\u67aa\u5c31\u5413\u4e00\u6b21\uff1a\u5b50\u5f39\u8d34\u7740\u4eba\u98de\u8fc7\u53bb\u7684\u90a3\u4e2a\uff0c\u6709\u6982\u7387\u4e22\u4e0b\u8def\u7ebf\u53bb\u627e\u63a9\u4f53 */
  if (humanOn()){
    for (const e of enemies){
      if (e.dead || e.tucked || e.boss) continue;
      const dx = e.x - ax, dy = e.y - ay;
      const t = dx*Math.cos(a) + dy*Math.sin(a);
      if (t <= 0 || t > 720) continue;
      const px = ax + Math.cos(a)*t, py = ay + Math.sin(a)*t;
      const off = Math.hypot(px - e.x, py - e.y);
      if (off <= e.r + 6 || off > HUMAN.nearMiss) continue;   /* \u771f\u547d\u4e2d\u7684\u8d70\u53e6\u4e00\u6761\uff0c\u8fd9\u91cc\u7ba1\u64e6\u8fc7 */
      if (losBlocked(ax, ay, e.x, e.y, true)) continue;
      humanFear(e, cur(), HUMAN.fearP * 0.8, null, player);
    }
  }
  /* 暴击：一枪判定一次。霰弹枪要是逐颗判定，一枪蹦出四五个金字就太吵了 */
  const crit = arenaRandom() < (critChance + (ar ? ar.crit : 0));
  const _attDmgK = (typeof attachDmgK === 'function') ? attachDmgK(g) : 1;
  const _dmgBase = g.dmg * _attDmgK * (ar ? ar.dmgMul : 1) * (arenaDealOn() ? 2 : 1);
  let dmgEach = crit
    ? Math.round(_dmgBase * (CRIT_MULT + (ar ? (ar.critDmg || 0) : 0)))
    : Math.round(_dmgBase);
  if (oneShotOn()) dmgEach = 999999;
  const _trHits = [];
  const hits = new Map();          /* 一颗子弹算一次；霰弹的多颗打在同一个身上要加起来 */
  let anyMiss = false;

  const _rays = n * _shots;      /* 双发就是再来一整轮独立的射线 */
  for (let i = 0; i < _rays; i++){
    /* 霰弹散得开，步枪飘一点点，手枪几乎是一条线 */
    const _spK = (typeof attachSpreadK === 'function') ? attachSpreadK(g) : 1;
    const a2 = a + rand(-g.spread * _spK, g.spread * _spK);
    if (typeof traderRayHit === 'function'){
      const _th = traderRayHit(ax, ay, a2, 720);
      if (_th) _trHits.push(_th);
    }
    let best = null, bestT = 1e9;
    const _cands = [];
    /* 这一枪到目前为止攒在他身上的伤害够不够要他的命（甲按倍率粗算，
       真正结算还是走下面的 absorbEnemyArmor）。够 → 后面的弹丸从尸体上穿过去。 */
    const _hitsFromShotDead = (e) => {
      const _r0 = hits.get(e);
      if (!_r0) return false;
      const _hp0 = (e.hp === undefined ? 100 : e.hp);
      return (_hp0 - _r0.dmg * enemyArmorK(e)) <= 0;
    };
    /* 第三方：车壳先吃这一发 —— 它就是掩体，后面的敌人打不到。
       开着的车一样算数（以前只认停稳的 solid，于是漂移/开走那几秒「打不到车」）*/
    let _tkHit = null, _tkT = 1e9;
    for (const _t of trucks){
      if (_t.tstate === 'gone') continue;
      const _tt = rayTruckT(_t, ax, ay, a2, 720);
      if (_tt !== null && _tt < _tkT){ _tkT = _tt; _tkHit = _t; }
    }
    if (_tkHit) bestT = _tkT;
    for (const e of enemies.concat(allies)){
      if (e.dead || !combatCanDamage(player,e)) continue;
      /* 这一枪前面的弹丸已经把他打死了：后面的弹丸直接穿过去，别喂给尸体。
         1 血的敌人一颗弹丸就倒，剩下的 7 颗该继续往前飞，不是凭空消失。 */
      if (_hitsFromShotDead(e)) continue;
      /* 缩头不再是凭空无敌：只有真有东西挡在中间时才打不中（下面的 losBlocked 已经判了）。
         在空地上蹲着发抖也照样能被打中。 */
      const dx = e.x-ax, dy = e.y-ay;
      const t = dx*Math.cos(a2) + dy*Math.sin(a2);
      if (t <= 0 || t > 720) continue;
      if (t >= _tkT) continue;              /* 车挡在前面，这人打不到 */
      const px = ax + Math.cos(a2)*t, py = ay + Math.sin(a2)*t;
      if (Math.hypot(px-e.x, py-e.y) > e.r + 6) continue;
      if (losBlocked(ax, ay, e.x, e.y, true)) continue;   /* 子弹穿门：只要墙不挡就行 */
      _cands.push({e:e, t:t});
      if (t < bestT){ bestT = t; best = e; }
    }
    /* 穿透是概率的：每多穿一个人判一次，概率 = 层数 × 25%（满 4 层才 100%）。
       能穿的人数另外有罩门（最多 1 + 层数 个），不然满层就成了无限贯穿。
       孤注一掷期间不判概率，直接必穿 3 个。 */
    let _hitsOnRay;
    const _deal = arenaDealOn();
    const _pl = ar ? Math.min(4, (ar.pierce | 0)) : 0;
    const _pChance = Math.min(1, _pl * 0.25);
    if ((_pl > 0 || _deal) && _cands.length > 1){
      _cands.sort((p2, q2)=> p2.t - q2.t);
      const _maxHits = Math.min(_cands.length, Math.max(_deal ? 3 : 1, 1 + _pl));
      _hitsOnRay = [_cands[0]];
      for (let _k = 1; _k < _cands.length && _hitsOnRay.length < _maxHits; _k++){
        if (!_deal && arenaRandom() > _pChance) break;   /* 没穿过去就停在这个人身上 */
        _hitsOnRay.push(_cands[_k]);
      }
    } else {
      _hitsOnRay = best ? [{e:best, t:bestT}] : [];
    }
    /* 轨迹：打到人就画到人身上，没打到就到墙（或最大射程）为止 */
    let endT = Math.min(720, rayToWall(ax, ay, a2, 720, false, true));   /* 弹道线画穿门 */
    if (_tkHit && _tkT <= endT){
      /* 车壳比墙比人都靠前：这一发停在车上，后面的东西一个都别想被打到 */
      endT = _tkT;
      damageTruck(_tkHit, dmgEach, a2);
    }
    if (_hitsOnRay.length) endT = Math.min(endT, _hitsOnRay[_hitsOnRay.length-1].t);
    /* 门：子弹照样穿过去，但这一下要真打到门上 —— 扣血、留弹孔、出火星，
       曳光还要在门的位置断一下（穿过去那段变淡），这样才看得出"穿透"。 */
    const _door = doorAlongRay(ax, ay, a2, endT);
    if (_door) damageDoor(_door.d, dmgEach, _door.x, _door.y, a2, true);
    /* 物资堆：不挡子弹，但这一枪真从它上面擦过去就得散一点 */
    const _pile = (typeof pileAlongRay === 'function') ? pileAlongRay(ax, ay, a2, endT) : null;
    if (_pile) damagePile(_pile.p, dmgEach * 0.5, _pile.x, _pile.y);
    /* 能推的小件（瓦罐）也不在墙表里，子弹要能把它打碎 */
    const _dec = (typeof decorAlongRay === 'function') ? decorAlongRay(ax, ay, a2, endT) : null;
    if (_dec && _dec.d._w) damageDecor(_dec.d._w, dmgEach, _dec.x, _dec.y, a2);
    tracers.push({x0:ax, y0:ay, x1:ax+Math.cos(a2)*endT, y1:ay+Math.sin(a2)*endT,
                  t:0, dur: tracerDur(ax, ay, ax+Math.cos(a2)*endT, ay+Math.sin(a2)*endT), hit:_hitsOnRay.length > 0,
                  cut: _door ? {x:_door.x, y:_door.y} : null});
    /* 挡在子弹路上的可破坏墙/玻璃（即使后面还有人）得先碎，
       不然会出现“人先挂彩、玻璃后碎”的先后级错位。 */
    let _brokeWall = false;
    {
      const _bw = breakWallAt(ax, ay, a2, endT);
      if (_bw){
        damageWall(_bw, dmgEach, ax + Math.cos(a2)*endT, ay + Math.sin(a2)*endT, a2, player);
        _brokeWall = true;
      }
    }
    /* 跳弹：这一发确实是撞墙停下来的话，按层数概率再弹一次（弹完不再弹） */
    if (!_brokeWall && ar && ((ar.ricochet | 0) > 0) && endT < 719){
      const _wh = rayHitWall(ax, ay, a2, 720);
      const _p = Math.min(1, (ar.ricochet | 0) * 0.25);
      if (_wh && Math.abs(_wh.t - endT) < 0.6 && arenaRandom() < _p){
        const _w = _wh.w;
        const hx = ax + Math.cos(a2) * endT, hy = ay + Math.sin(a2) * endT;
        const dl = Math.abs(hx - _w.x), dr = Math.abs((_w.x + _w.w) - hx);
        const dt2 = Math.abs(hy - _w.y), db = Math.abs((_w.y + _w.h) - hy);
        const _m = Math.min(dl, dr, dt2, db);
        let nx2 = 0, ny2 = 0;
        if (_m === dl) nx2 = -1; else if (_m === dr) nx2 = 1;
        else if (_m === dt2) ny2 = -1; else ny2 = 1;
        const _dot = Math.cos(a2) * nx2 + Math.sin(a2) * ny2;
        const _rx = Math.cos(a2) - 2 * _dot * nx2, _ry = Math.sin(a2) - 2 * _dot * ny2;
        const a3 = Math.atan2(_ry, _rx);
        const sx2 = hx + nx2 * 2.5, sy2 = hy + ny2 * 2.5;
        const rEnd = Math.min(720, rayToWall(sx2, sy2, a3, 720));
        let rHit = null, rT = 1e9;
        for (const e of enemies.concat(allies)){
          if (e.dead || !combatCanDamage(player,e)) continue;
          const dx2 = e.x - sx2, dy2 = e.y - sy2;
          const t2 = dx2 * Math.cos(a3) + dy2 * Math.sin(a3);
          if (t2 <= 0 || t2 > rEnd) continue;
          const px2 = sx2 + Math.cos(a3) * t2, py2 = sy2 + Math.sin(a3) * t2;
          if (Math.hypot(px2 - e.x, py2 - e.y) > e.r + 6) continue;
          if (t2 < rT){ rT = t2; rHit = e; }
        }
        const _rt = rHit ? rT : rEnd;
        tracers.push({x0:sx2, y0:sy2, x1:sx2 + Math.cos(a3) * _rt, y1:sy2 + Math.sin(a3) * _rt,
                      t:0, dur: tracerDur(sx2, sy2, sx2 + Math.cos(a3) * _rt, sy2 + Math.sin(a3) * _rt), hit:!!rHit});
        impactWallFx(hx, hy, a2);
        if (rHit){
          const rec2 = hits.get(rHit);
          if (rec2) rec2.dmg += dmgEach;
          else hits.set(rHit, {dmg: dmgEach, ang: a3});
        }
      }
    }
    if (!_hitsOnRay.length){
      /* 没打到人：看看这条线是不是顶在可破坏的墙上了。是就打墙 */
      if (!_brokeWall && endT < 700 && !anyMiss){
        anyMiss = true; impactWallFx(ax + Math.cos(a2)*endT, ay + Math.sin(a2)*endT, a2);
      }
      continue;
    }
    for (const _hk of _hitsOnRay){
      const rec = hits.get(_hk.e);
      if (rec) rec.dmg += dmgEach;
      else hits.set(_hk.e, {dmg:dmgEach, ang:a2});
    }
  }
  player.flash = 0.06;            /* 枪口火光，复用现有 flash 字段 */
  gunNoise(2.2);                  /* 枪声传出去：没看见你的人也会往这边摸（2.2 覆盖远程点射：默认 hearR 320 → 704px） */

  if (!hits.size) return;
  /* 打中抽奖商人：记仇 + 掉血（中立 NPC，不参与 enemies 的结算） */
  if (_trHits.length){
    const _seen = new Set();
    for (const _h of _trHits){ if (_seen.has(_h.e)) continue; _seen.add(_h.e); (typeof traderHurt === 'function') && traderHurt(_h.e, dmgEach); }
  }
  for (const [e, rec] of hits){
    if(e.controller==='companion'){companionDamage(e,rec.dmg,player,'bullet',rec.ang);continue;}
    /* 运兵车不在这个循环里了（它是 trucks[] 第三方，伤害由 damageTruck 直接结算） */
    /* 按"你到这个人"的实际距离结算贴脸 / 远射，再看是不是残血背水 */
    if (ar){
      const _dd = dist(player.x, player.y, e.x, e.y);
      if (ar.closeDmg && _dd < 220) rec.dmg = Math.round(rec.dmg * (1 + ar.closeDmg));
      else if (ar.farDmg && _dd > 380) rec.dmg = Math.round(rec.dmg * (1 + ar.farDmg));
      if (ar.rageDmg && player.hp > 0 && player.hp < arenaMaxHp() * 0.40)
        rec.dmg = Math.round(rec.dmg * (1 + ar.rageDmg));
    }
    /* 盾卫：正面那面盾吃子弹，只有绕到背后才打得动 */
    if (e.bossKind === 'shield'){
      /* rec.ang 是子弹飞出去的方向，盾面是「他朝你」的方向，正好差 180°：
         拿 rec.ang + π 去比才对得上，直接比会把正反面判反 */
      /* 双盾：两片盾绕身转（相隔 180°），打到任意一片都只吃 15% */
      const _in = rec.ang + Math.PI;
      const _o1 = (e.shieldOrbit === undefined ? (e.shieldAng || 0) : e.shieldOrbit), _o2 = _o1 + Math.PI;
      const _dA = (ang) => Math.abs(Math.atan2(Math.sin(_in - ang), Math.cos(_in - ang)));
      if (_dA(_o1) < 0.75 || _dA(_o2) < 0.75){
        rec.dmg = Math.max(1, Math.round(rec.dmg * 0.15));
        impactWallFx(e.x + Math.cos(rec.ang) * (e.r + 6), e.y + Math.sin(rec.ang) * (e.r + 6), rec.ang);
      }
    }
    /* 疯狗冲上来的时候可以拿枪顶回去：打中就往后推一点，正在点火的话还把引信往后拖一点。
       拖的总量有上限（fuseDelayMax），火力够能拖住它、拖不死它。 */
    /* 只在“还在往你这边冲”（引信没点着）的时候才推得动；
       一旦贴脸点着火，它就钉在地上，再打也不会被推走 */
    if (e.bossKind === 'charger' && !e.boomRecover && !((e.fuse || 0) > 0)){
      const _cp = (ABILITY_DEF.blast.params || {});
      /* 击退改成「有节奏的推移 + 贴脸递减」：
         以前每中一枪硬推 46px，手枪一秒六枪就是 280px/s，
         而它自己才走 100px/s 左右 —— 永远走不到你面前，
         「贴上来点引信」这个机制直接废掉。
         现在：两次推移至少隔 0.12 秒，且离你越近推得越少。 */
      const _now = (ar ? ar.time : 0);
      const _d2 = dist(player.x, player.y, e.x, e.y);
      const _nearK = clamp(_d2 / 240, 0.22, 1);
      if (_now - (e.kbT === undefined ? -9 : e.kbT) >= 0.12){
        e.kbT = _now;
        const _push = (_cp.knockPush || 10) * _nearK;
        const _q = safeSpot(cur(), { x: e.x + Math.cos(rec.ang) * _push,
                                    y: e.y + Math.sin(rec.ang) * _push }, 12);
        e.x = _q.x; e.y = _q.y;
      }
      if ((e.fuse || 0) > 0){
        const _left = (_cp.fuseDelayMax || 1.4) - (e.fuseAdd || 0);
        const _add = Math.max(0, Math.min(_cp.fuseDelay || 0.16, _left));
        e.fuse += _add; e.fuseAdd = (e.fuseAdd || 0) + _add;
      }
      camShake = Math.max(camShake, 0.22);
      slamBurst(e.x, e.y, rec.ang + Math.PI, 5);
      logInfo('gun', '把疯狗顶回去了 · 引信还拖着 ' + (e.fuseAdd || 0).toFixed(2) + 's');
    }
    /* 三级甲在这里削：面板、飘字、日志都报"真正落在他身上的数"，不是枪的理论值 */
    const _hitDmg = absorbEnemyArmor(e, rec.dmg, 'bullet');
    e.hp = (e.hp === undefined ? 100 : e.hp) - _hitDmg;
    if(typeof factionNoteDamage==='function')factionNoteDamage(e,player,_hitDmg,'bullet');
    const killed = e.hp <= 0;
    registerHit(e, rec.ang, _hitDmg, killed, crit);   /* 打击感全在这一句里 */
    spawnDamageNum(e.x, e.y-30, _hitDmg, killed, crit && !killed);
    dummyRecord(e, _hitDmg, crit);
    if (killed) killTestEnemy(e);
    else {
      alertByHit(e, rec.ang);          /* 没打死就会立刻反应过来，不许站着挨枪 */
      logInfo('gun', (crit ? '暴击 · ' : '') + '命中 · -' + _hitDmg + ' · 剩 ' + Math.max(0, Math.round(e.hp)));
    }
  }
}

/* 尸体：倒下的人在地上躺一会儿再变淡，不是一闪就没了 */
let corpses = [];
let lootTotal = 0;        /* 这一关要拿多少件货（只算地图上摆的，不算人家掉的） */

/* ---------------- 负面状态（流血 / 视力模糊） ---------------- */
let stBleedT = 0, visionBlur = 0, visionBlind = 0, visionCd = 0, blindAlphaK = 1;
let visionBlurHold = 0;   /* 爆炸这类"糊住不放"的计时，走完才开始衰减 */
let blurFastT = 0;        /* m36675：快速散掉的模糊（疯狗自爆），期间强制加速衰减 */
/* 流血分级：0 没有 / 1 轻 / 2 重。II 级定时结束后降到 I 级，I 级走完才算愈合 */
let stBleedLv = 0;
let armorBreakT = 0;   /* 护甲刚碎的红光，1 → 0 衰减 */
let bloodMarks = [];   /* 地上的血印：{x,y,r,t}，10 秒后慢慢淡掉 */
let scorchMarks = [];
/* 火箭爆炸的冲击波圈：{x,y,R,t,life}。R 是这颗弹头真实的杀伤半径，
   画出来的圈正好是「谁在这圈里谁就得挨炸」，【高爆弹头】每叠一层圈就大一圈，看得见。 */
let blastRings = [];
/* 铁皮打中后留的一颗亮点，慢慢暗下去 */
let hotMarks = [];  /* 地上的爆痕：{x,y,r,t}，6 秒后淡掉（疯狗自爆留的） */
let deathHit = null;

/* ---------------- 死亡归因（数据流）----------------
 * 玩家倒下那一下，记下“是谁、用什么打死的”，
 * 然后从 data/death_msgs.js 里挑一句对应的话。
 * 注意：流血流死时候确实没有凶手，那种情况单独算一类。 */
let deathCause = '';
let deathMsgText = '';

/* 凶手叫什么（优先用它自己身上的 label） */
function deathKillerName(e){
  if (!e) return '';
  if (e.boss){
    if (e.bossName) return e.bossName;
    if (typeof BOSS_KIT !== 'undefined' && BOSS_KIT[e.bossKind] && BOSS_KIT[e.bossKind].label) return BOSS_KIT[e.bossKind].label;
    return '不明';
  }
  if (e.wid === 'dao') return '疯刀手';
  const T = (typeof ENEMY_TYPES !== 'undefined' && ENEMY_TYPES[e.type]) || null;
  if (e.isMinion) return (T && T.label ? T.label : '小兵') + '（巢母放的）';
  if (T && T.label) return T.label;
  return '不明';
}

/* 归成哪一类死法 */
function deathCauseKey(src, by){
  if (by && by.boss){
    if (by.bossKind === 'charger') return 'blast';
    if (by.bossKind === 'warlord') return 'dash';
    if (by.bossKind === 'shield') return 'shield';
    if (by.bossKind === 'spawner') return 'swarm';
    return src === 'blade' ? 'blade' : 'bullet';
  }
  if (src === 'blade') return (by && by.wid === 'dao') ? 'dao' : 'blade';
  if (src === 'catch') return 'caught';
  if (src === 'bleed') return 'bleed';
  if (by){
    if (by.isMinion) return 'swarm';
    if (by.type === 'drone') return 'drone';
    if (by.type === 'sentinel' || by.type === 'hunter') return 'sniper';
  }
  if (src === 'bullet') return 'bullet';
  return 'unknown';
}

/* 抽一句卡当时那一类的话（抽过就存起来，不能每帧再抽） */
function pickDeathMsg(key){
  const g = (typeof DEATH_MSG !== 'undefined' && DEATH_MSG[key]) || null;
  const arr = (g && g.length) ? g : ((typeof DEATH_MSG !== 'undefined' && DEATH_MSG.unknown) || ['你死了']);
  return arr[Math.floor(Math.random() * arr.length)];
}

/* 记一笔死因：只认第一次（同一帧可能挨好几下） */
function markDeath(src, by, dmg, ang){
  if (deathHit) return false;
  deathCause = deathCauseKey(src, by);
  deathHit = { ang: (ang === undefined ? 0 : ang), dmg: dmg || 0, src: src || 'unknown',
               by: by || null, at: (typeof performance !== 'undefined' ? performance.now() : Date.now()) };
  deathMsgText = pickDeathMsg(deathCause);
  return true;
}

let bleedDripT = 0;      /* 流血滴血印的计时器 */   /* 被什么打死的：{ang, dmg, src, t} —— 定格的时候要把那一刀补画出来 */
const BLOOD_LIFE = 10;   /* visionBlur 越糊；visionBlind 越红；visionCd 重击冷却 */
const ST_BLEED_DPS = 1.1;        /* 每秒扣多少血（时间拉长，强度减轻） */
const ST_BLEED_DUR = 12;         /* I 级持续秒数 */
const ST_BLEED_DPS2 = 2.8;       /* II 级每秒扣血（比 I 级狠得多） */
const ST_BLEED_DUR2 = 8;         /* II 级持续秒数，到点降成 I 级 */
const ST_BLEED_CHANCE = 0.35;    /* 中弹时触发概率 */
/* 重击门槛：单下掉血超过上限的这个比例，就把整片视野糊掉 */
const ST_BLUR_DMG_K = 0.055;   /* 6% 上限就糊：原来是 10%，导致普通枪弹永远够不到 */
/* 难度越高，负面状态越容易上身、扣血越痛 */
const ST_DIFF = {
  easy:      { c: 0.55, d: 0.65 },
  normal:    { c: 1.00, d: 1.00 },
  hard:      { c: 1.35, d: 1.30 },
  nightmare: { c: 1.75, d: 1.60 }
};
function stDiff(){ return ST_DIFF[diffName] || ST_DIFF.normal; }
function stClear(){ stBleedT = 0; stBleedLv = 0; visionBlur = 0; visionBlind = 0; visionCd = 0; visionBlurHold = 0; blurFastT = 0; blindAlphaK = 1; bloodMarks = []; bleedDripT = 0; }
/* 上流血：只会升不会降（II 级再挨一下不会变成 I 级），重上同级别会刷新时间 */
function stBleedAdd(lv){
  lv = Math.max(1, Math.min(2, lv | 0));
  if (lv > stBleedLv){
    stBleedLv = lv;
    stBleedT = (lv === 2) ? ST_BLEED_DUR2 : ST_BLEED_DUR;
    if (lv === 2) setMsg('大出血 · 流血 II 级', 2.2);
  } else if (lv === stBleedLv){
    stBleedT = Math.max(stBleedT, (lv === 2) ? ST_BLEED_DUR2 : ST_BLEED_DUR);
  }
}
/* 状态数据流：HUD 只读这张表，新状态在这里登记一次就够 */
function statusList(){
  const out = [];
  if (player && player.stunT > 0){
    out.push({ key:'stun', label:'眩晕', lv:0, t:player.stunT, total:2.4, col:'rgba(255,214,104,0.98)' });
  }
  if (stBleedT > 0 && stBleedLv > 0){
    out.push({ key:'bleed', label:'流血', lv:stBleedLv, t:stBleedT,
               total:(stBleedLv === 2 ? ST_BLEED_DUR2 : ST_BLEED_DUR),
               col:(stBleedLv === 2 ? 'rgba(255,86,60,0.99)' : 'rgba(232,118,90,0.98)') });
  }
  if (visionBlur > 0.01){
    out.push({ key:'blur', label:'视野模糊', lv:0, t:visionBlur, total:1, col:'rgba(196,170,255,0.96)', pct:true });
  }
  if (visionBlind > 0.01){
    out.push({ key:'blind', label:'致盲', lv:0, t:visionBlind, total:1, col:'rgba(255,160,160,0.96)', pct:true });
  }
  return out;
}
/* 自带一个随机源：不能去抢主流程的 Math.random，
   否则老关卡的随机序列被打乱，定种子对比就废了 */
let stRng = 987654321;
function stRand(){
  stRng = (stRng * 1103515245 + 12345) & 0x7fffffff;
  return stRng / 0x7fffffff;
}
/* 中弹：按概率流血；血少于一半时还可能被打的眼前一黑（视力模糊） */
function stOnHurt(dmg, src){
  const _sd = stDiff();
  if ((ar ? arenaRandom() : stRand()) < Math.min(0.9, ST_BLEED_CHANCE * _sd.c)) stBleedAdd(1);
  if (player && (dmg || 0) >= 6){
    spillBlood(player.x, player.y, 8 + Math.min(5, (dmg || 0) * 0.12));
    for (let i = 0; i < 5; i++) spillBlood(player.x + (i-2)*17, player.y + 12 + (i%2)*10, 2.6 + i * 0.6);
  }
  /* 只有近战砍到才会糊眼：枪子儿不来这一套（不然一梭子下去人全程瞎） */
  if (src === 'bullet') return;   /* 只有枪子儿不来这一套；刀、爆炸、撞都算重击 */
  /* 重击：一下就掉一大截血，画面当场糊住；糊多深看这一下有多重。
     之后靠"歇着"慢慢变清晰（见 stUpdate）。小擦伤不会糊。 */
  const maxHp = (ar ? arenaMaxHp() : CFG.hp);
  /* 冷却 + 上一次还没缓过来就别再叠：连着挨刀也不该一直瞎 */
  if (ar) return;                                  /* 割草模式不糊：爽快优先，不折磨 */
  /* m44245：刀兵砍糊眼只给"专门这么设计"的关卡（rules.blurOnBlade，目前只有 3-4 雨雾街头）。
     用户原话："除了雨夜街头，拿刀的兵种攻击玩家不会有模糊效果，这个暂时不设为全局"。
     所以这里是按关卡开关，不是一个全局布尔。 */
  if (src === 'blade' || src === 'dao'){
    const _L0 = (typeof cur === 'function') ? cur() : null;
    if (!(_L0 && _L0.rules && _L0.rules.blurOnBlade)) return;
  }
  if (visionCd > 0 || visionBlur > 0.30) return;
  const heavy = Math.max(5, maxHp * ST_BLUR_DMG_K * _sd.d);
  if ((dmg || 0) >= heavy){
    visionCd = 7.0;
    const k = clamp(0.60 + 0.40 * ((dmg || 0) / (maxHp * 0.30)), 0.60, 1);
    visionBlur = Math.min(1, Math.max(visionBlur, k));
    /* 失明：先是整片白，再慢慢退成"糊"，最后才恢复 */
    visionBlind = Math.min(1, Math.max(visionBlind, clamp(0.45 + (dmg || 0) / (maxHp * 0.45), 0.45, 1)));
    setMsg('重击 · 眼前见红', 1.6);
  }
}
/* 在地上留一摊血：流血时会一滴滴往下掉，挨刀/中弹那一下掉一大摊 */
function spillBlood(x, y, size){
  if (bloodMarks.length > 90) bloodMarks.shift();
  bloodMarks.push({ x: x + stRand()*16 - 8, y: y + stRand()*16 - 8, r: size * (0.7 + stRand()*0.55), t: 0, a: fxRand(0, TAU) });
}
function drawDevMarks(){
  if (!CFG.dev) return;
  for (const e of enemies){
    if (!e.devMark || e.dead) continue;
    const sx = e.x, sy = e.y - e.r - 30;
    if (sx < cam.x - 120 || sx > cam.x + W + 120 || sy < cam.y - 60 || sy > cam.y + H + 60) continue;
    const txt = '再按一次 K 处决';
    ctx.font = 'bold 13px ui-monospace, monospace';
    const tw = ctx.measureText(txt).width;
    ctx.fillStyle = 'rgba(20,8,8,0.82)';
    ctx.fillRect(sx - tw/2 - 8, sy - 13, tw + 16, 20);
    ctx.strokeStyle = 'rgba(255,120,110,0.9)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(sx - tw/2 - 8, sy - 13, tw + 16, 20);
    ctx.fillStyle = '#ffd7d2';
    ctx.textAlign = 'center';
    ctx.fillText(txt, sx, sy + 2);
    ctx.textAlign = 'left';
  }
}

function updateHotMarks(dt){
  for (let i = hotMarks.length - 1; i >= 0; i--){
    hotMarks[i].t += dt;
    if (hotMarks[i].t > hotMarks[i].dur) hotMarks.splice(i, 1);
  }
}
function drawHotMarks(){
  for (const m of hotMarks){
    const k = 1 - m.t / m.dur;
    if (k <= 0) continue;
    if (m.x < cam.x - 40 || m.x > cam.x + W + 40 || m.y < cam.y - 40 || m.y > cam.y + H + 40) continue;
    const r = 3.2 + 4.6 * k;
    const g = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, r);
    g.addColorStop(0, 'rgba(255,247,210,' + (0.92 * k).toFixed(3) + ')');
    g.addColorStop(0.45, 'rgba(255,196,86,' + (0.55 * k * k).toFixed(3) + ')');
    g.addColorStop(1, 'rgba(255,150,40,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(m.x, m.y, r, 0, TAU); ctx.fill();
  }
}
function updateBlastRings(dt){
  for (let i = blastRings.length - 1; i >= 0; i--){
    const b = blastRings[i];
    b.t += dt;
    if (b.t > b.life) blastRings.splice(i, 1);
  }
}
function drawBlastRings(){
  for (const b of blastRings){
    if (!cullPt(b.x, b.y, b.R + 80)) continue;
    const k = b.t / b.life;                 /* 0 → 1 */
    ctx.save();
    /* 第一段（前 55%）：一道亮圈从中心推到杀伤边缘，像气浪扫过去 */
    const _small = b.small === true;
    if (k < 0.55){
      const wk = k / 0.55;
      const rr = b.R * (0.22 + 0.80 * Math.min(1, wk * 1.18));
      ctx.globalAlpha = (_small ? 0.8 : 0.92) * (1 - wk);
      ctx.strokeStyle = _small ? 'rgba(255,178,120,0.95)' : 'rgba(255,236,186,0.98)';
      ctx.lineWidth = (_small ? 1.4 : 2.2) + (_small ? 3.0 : 6.0) * (1 - wk);
      ctx.beginPath(); ctx.arc(b.x, b.y, rr, 0, TAU); ctx.stroke();
    }
    /* 第二段（整段）：杀伤圈本身定格一秒，收尾时慢慢淡掉 —— 
       看这一圈就知道【高爆弹头】把它放到哪了，不靠猜。 */
    if (_small && k > 0.55){ ctx.restore(); continue; }   /* 小炸点只留前半秒，别在屏幕上堆圈（别忘了先把 save 还回去） */
    ctx.globalAlpha = (_small ? 0.4 : 0.62) * (1 - k * k);
    ctx.strokeStyle = _small ? 'rgba(255,150,96,0.95)' : 'rgba(255,160,78,0.95)';
    ctx.lineWidth = (_small ? 1.2 : 2.0) + 1.4 * (1 - k);
    ctx.beginPath(); ctx.arc(b.x, b.y, b.R, 0, TAU); ctx.stroke();
    /* 圈里再套一道细虚线，和地面上别的圆（声纹/技能圈）分开 */
    if (_small){ ctx.restore(); continue; }
    ctx.globalAlpha = 0.30 * (1 - k * k);
    ctx.strokeStyle = 'rgba(255,214,150,0.9)';
    ctx.lineWidth = 1.1;
    ctx.setLineDash([16, 14]);
    ctx.beginPath(); ctx.arc(b.x, b.y, b.R * 0.965, 0, TAU); ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }
}
function updateScorch(dt){
  for (let i = scorchMarks.length - 1; i >= 0; i--){
    scorchMarks[i].t += dt;
    if (scorchMarks[i].t > 6) scorchMarks.splice(i, 1);
  }
}
function drawScorchMarks(){
  for (const m of scorchMarks){
    const k = 1 - m.t / 6;                       /* 1 → 0 */
    if (k <= 0) continue;
    const sx = m.x, sy = m.y;
    if (sx < cam.x - 80 || sx > cam.x + W + 80 || sy < cam.y - 80 || sy > cam.y + H + 80) continue;
    const g = ctx.createRadialGradient(sx, sy, 1, sx, sy, m.r);
    g.addColorStop(0, 'rgba(28,20,16,' + (0.62 * k) + ')');
    g.addColorStop(0.55, 'rgba(40,28,20,' + (0.40 * k) + ')');
    g.addColorStop(1, 'rgba(20,14,10,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(sx, sy, m.r, 0, TAU); ctx.fill();
    /* 边缘一圈焦黑碎屑，别让它像个圆盘子 */
    ctx.fillStyle = 'rgba(16,12,10,' + (0.5 * k) + ')';
    for (let i = 0; i < 7; i++){
      const a = (i / 7) * TAU + m.r;
      const rr = m.r * (0.72 + 0.22 * Math.sin(i * 2.1));
      ctx.beginPath();
      ctx.arc(sx + Math.cos(a) * rr, sy + Math.sin(a) * rr, m.r * 0.10, 0, TAU);
      ctx.fill();
    }
  }
}

function updateBlood(dt){
  for (let i = bloodMarks.length - 1; i >= 0; i--){
    bloodMarks[i].t += dt;
    if (bloodMarks[i].t > BLOOD_LIFE) bloodMarks.splice(i, 1);
  }
}
function drawBloodMarks(){
  if (!bloodMarks.length) return;
  ctx.save();
  for (const b of bloodMarks){
    const p = b.t / BLOOD_LIFE;
    const a = (p < 0.62) ? 1 : (1 - (p - 0.62) / 0.38);   /* 前 6 秒实，后 4 秒淡出 */
    if (a <= 0.01) continue;
    const sx = b.x, sy = b.y;                       /* 世界坐标：外面已经 translate 过了 */
    if (sx < cam.x - 60 || sx > cam.x + W + 60 || sy < cam.y - 60 || sy > cam.y + H + 60) continue;
    /* 软边 + 深色底：硬边实心圆会像"贴上去的贴纸"，和地面不在一个层 */
    ctx.save();
    ctx.translate(sx, sy); ctx.rotate(b.a || 0);
    const _g = ctx.createRadialGradient(0, 0, b.r * 0.1, 0, 0, b.r * 2.3);
    _g.addColorStop(0,    'rgba(104,7,9,' + (a * 0.95).toFixed(3) + ')');
    _g.addColorStop(0.45, 'rgba(126,11,13,' + (a * 0.72).toFixed(3) + ')');
    _g.addColorStop(1,    'rgba(72,4,6,0)');
    ctx.fillStyle = _g;
    /* 拉长成一道血印：宽 1.5r、长 2.6r */
    ctx.beginPath(); ctx.ellipse(0, 0, b.r * 2.6, b.r * 1.5, 0, 0, TAU); ctx.fill();
    ctx.globalAlpha = a * 0.5;
    ctx.fillStyle = 'rgba(56,2,4,0.9)';
    ctx.beginPath(); ctx.ellipse(0, 0, b.r * 0.9, b.r * 0.5, 0, 0, TAU); ctx.fill();
    ctx.restore();
  }
  ctx.restore();
}

function stUpdate(dt){
  updateBlood(dt);
  updateSlamFx(dt);
  updateScorch(dt);
  updateBlastRings(dt);
  updateHotMarks(dt);
  if (stBleedLv <= 0 && stBleedT > 0) stBleedLv = 1;
  if (stBleedT > 0){
    const d = Math.min(dt, stBleedT);   /* 只算真正流着的那段时间，到期就不再扣 */
    stBleedT = Math.max(0, stBleedT - dt);
    const dps = (stBleedLv === 2 ? ST_BLEED_DPS2 : ST_BLEED_DPS) * stDiff().d;
    player.hp -= dps * d;
    if (player.hp <= 0) markDeath('bleed', null, 0, 0);
    bleedDripT += d;
    const drip = (stBleedLv === 2 ? 0.085 : 0.14);
    if (bleedDripT > drip){
      bleedDripT = 0;
      spillBlood(player.x, player.y, (stBleedLv === 2 ? 4.2 : 2.8) + stRand()*2.0);
    }
    if (stBleedT <= 0){
      if (stBleedLv === 2){ stBleedLv = 1; stBleedT = ST_BLEED_DUR; setMsg('血止住一些 · 降为流血 I 级', 2.0); }
      else { stBleedLv = 0; setMsg('止血了', 1.6); }
    }
  }
  /* 模糊自己会退：站着不动退得快，边走边打退得慢（"休息才看得清"） */
  if (visionCd > 0) visionCd = Math.max(0, visionCd - dt);
  if (player.stunT > 0) player.stunT = Math.max(0, player.stunT - dt);
  if (visionBlind > 0){
    /* 白茫茫退得快：0.7 秒左右，剩下的靠 blur 慢慢恢复 */
    visionBlind = Math.max(0, visionBlind - dt * (player.stunT > 0 ? 3.2 : 1.45));
    if (visionBlind <= 0) blindAlphaK = 1;
  } else if (blindAlphaK !== 1){ blindAlphaK = 1; }
  if (visionBlurHold > 0) visionBlurHold = Math.max(0, visionBlurHold - dt);
  if (blurFastT > 0) blurFastT = Math.max(0, blurFastT - dt);
  if (visionBlur > 0 && (visionBlurHold <= 0 || blurFastT > 0)){
    const still = !player.moving && !player.heal;
    /* 撞晕时糊得快、退得也快，别一撞就瞎好几秒 */
    let _rate = player.stunT > 0 ? 1.9 : (still ? 0.62 : 0.24);
    /* m36675：疯狗自爆那一层不加僵直，所以单独给一条"快退"通道（0.55 秒基本散完） */
    if (blurFastT > 0) _rate = Math.max(_rate, 1.8);
    visionBlur = Math.max(0, visionBlur - _rate * dt);
  }
}
/* 失明的那一层白：越接近 1 越白，快速退掉 */
function drawBlindFx(){
  if (visionBlind <= 0.01) return;
  /* 半透明：还能看见底下的轮廓，只是红了一片 */
  const a = Math.min(0.56, visionBlind * 0.56) * (blindAlphaK || 1);
  const g = ctx.createRadialGradient(W/2, H/2, H*0.12, W/2, H/2, H*0.95);
  g.addColorStop(0,   'rgba(255,70,56,' + (a * 0.55).toFixed(3) + ')');
  g.addColorStop(0.55,'rgba(205,20,14,' + (a * 0.85).toFixed(3) + ')');
  g.addColorStop(1,   'rgba(120,0,0,' + a.toFixed(3) + ')');
  ctx.save();
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}

/* 画面糊掉之后单独补一个清楚的「你」，否则重击瞬间连自己在哪都找不到 */
/* 视力模糊时能看远的距离变短 */
function pVisionNow(){ return CFG.pVision * (1 - 0.45 * clamp(visionBlur, 0, 1)) * (arenaEventOn('blackout') ? 0.55 : 1); }
/* 整片画面变糊：中心也糊，四周更糊；强度跟着 visionBlur 走 */
let blurCv = null, blurCtx = null;
function applyVisionBlur(){
  const k = clamp(visionBlur, 0, 1);
  if (k <= 0.01) return;
  if (!blurCv){
    blurCv = document.createElement('canvas');
    blurCtx = blurCv.getContext('2d');
  }
  if (blurCv.width !== W || blurCv.height !== H){
    blurCv.width = W; blurCv.height = H;
  }
  blurCtx.setTransform(1, 0, 0, 1, 0, 0);
  blurCtx.globalCompositeOperation = 'source-over';
  blurCtx.globalAlpha = 1;
  /* 先铺底色，否则模糊后边缘会透出透明 */
  blurCtx.fillStyle = THEME_LIGHT ? '#ece9e2' : '#080d12';
  blurCtx.fillRect(0, 0, W, H);
  blurCtx.filter = 'blur(' + (2 + 20 * k).toFixed(1) + 'px)';
  blurCtx.drawImage(cv, 0, 0, W, H);
  blurCtx.filter = 'none';

  ctx.save();
  /* 整张换掉：直接把糊的盖上去（不是半透明叠加，否则后面的清晰原图会透出来，
     看起来只是"蒙了一层雾"，不是真的糊） */
  ctx.drawImage(blurCv, 0, 0);
  /* 重影：左右各错开一点，叠出双影 */
  const off = 2 + 9 * k;
  ctx.globalAlpha = 0.30 + 0.22 * k;
  ctx.drawImage(blurCv, -off, 0);
  ctx.drawImage(blurCv, off, 0);
  ctx.globalAlpha = 1;
  ctx.restore();
}

function drawBlurFx(){
  if (visionBlur <= 0.01) return;
  const fadeIn = Math.min(1, visionBlur / 0.35);
  const k = fadeIn * (0.82 + 0.18 * Math.sin(uiT * 3.1));
  ctx.save();
  const g = ctx.createRadialGradient(W/2, H/2, Math.min(W, H) * 0.26, W/2, H/2, Math.max(W, H) * 0.70);
  g.addColorStop(0, 'rgba(6,8,12,0)');
  g.addColorStop(0.55, 'rgba(6,8,12,' + (0.26 * k).toFixed(3) + ')');
  g.addColorStop(1, 'rgba(3,4,7,' + (0.74 * k).toFixed(3) + ')');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  ctx.restore();
}
function addCorpse(e, ang){
  corpses.push({x: e.x, y: e.y, ang: ang || e.ang || 0, r: e.r || 12,
                wid: e.wid || null, t: 0, dur: 5.0});
  if (corpses.length > 24) corpses.shift();
}
function updateCorpses(dt){
  for (let i = corpses.length - 1; i >= 0; i--){
    const c = corpses[i];
    c.t += dt;
    if (c.t > c.dur) corpses.splice(i, 1);
  }
}
function drawCorpses(){
  for (const c of corpses){
    if (!cullPt(c.x, c.y, 90)) continue;
    const k = c.t / c.dur;
    const a = Math.min(1, (1 - k) * 1.6);
    ctx.save();
    ctx.globalAlpha = a * 0.85;
    ctx.translate(c.x, c.y);
    ctx.rotate(c.ang + 1.35);
    /* 一个微肿的身体 + 一坨更暗的血 */
    ctx.fillStyle = 'rgba(120,30,26,0.55)';
    ctx.beginPath(); ctx.ellipse(0, 0, c.r * 1.7, c.r * 1.05, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(78,84,92,0.95)';
    ctx.beginPath(); ctx.ellipse(0, 0, c.r * 1.15, c.r * 0.62, 0, 0, TAU); ctx.fill();
    if (c.wid) drawGunModel(c.r * 0.7, 0, 0.55, 0.2, 'rgba(170,178,188,0.75)', 'rgba(20,24,30,0.7)', c.wid);
    ctx.restore();
  }
  ctx.globalAlpha = 1;
}

function finalizeCineKill(){
  if (ar) ar.holdCam = null;
  if (ar && ar.cinePending && ar.cinePending.boss) bossReward(ar.cinePending);
  if (ar && ar.cinePending && ar.cinePending.special) specialReward(ar.cinePending);
  if (!ar || !ar.cinePending) return;
  const e = ar.cinePending;
  ar.cinePending = null;
  addCorpse(e, Math.atan2(e.y - player.y, e.x - player.x) + Math.PI);
  if (!e.noXp) arenaOrb(e.x, e.y);
  arenaBoom(e, 40 * ar.dmgMul);
  arenaKillReward();
  e.dead = true;
  const k = enemies.indexOf(e);
  if (k >= 0) enemies.splice(k, 1);
  ar.inter = ARENA_INTER;
  ar.cineT = 1.1;
  ar.cineX = e.x; ar.cineY = e.y;
  camShake = Math.max(camShake, 1.1);
  punchT = Math.max(punchT, 0.3); punchAmp = 14;
  sfxWaveClear();
  const _wv = arenaScoreWave();
  setMsg('第 ' + ar.wave + ' 波 清空 · +' + _wv + ' 分', 2.2);
}

function killTestEnemy(e){
  if (e._settled) return;                    /* 已经结算过了，别重复给分 */
  if (e._dying) return;                      /* 正在自爆，等它炸完 */
  if (e.bossKind === 'charger' && !e._dyingDone && ar && !isTestZone()){
    /* 疯狗死前先把引信烧完：站定、鼓起来、炸开，然后才结算 */
    e._dying = true; e.deathT = 0; e.hp = 0;
    e.fuse = 0; e.boomRecover = 0; e.chargeT = 0; e.spdK = 0;
    setMsg('疯狗烧起来了 · 让开', 1.3);
    beep(180, 0.5, 'sawtooth', 0.05, 700);
    return;
  }
  /* 清波的那一个：先定格在“被打中”的姿态，等定格结束才倒地 */
  if (ar && !CFG.dev && (ar.spawnLeft || 0) <= 0 && enemies.length <= 1){
    ar.kills++;
    arenaScoreKill(e);
    ar.cinePending = e;
    ar.cineX = e.x; ar.cineY = e.y;
    e.hitHold = true;
    eStatusSet(e, 'hurt', 0.42);
    return;
  }
  addCorpse(e, Math.atan2(e.y - player.y, e.x - player.x) + Math.PI);
  if (ar){
    ar.kills++;
    arenaScoreKill(e);
    if (!e.noXp) arenaOrb(e.x, e.y);
    arenaBoom(e, 40 * ar.dmgMul);
    if (e.special) specialReward(e);
    if (e.boss) bossReward(e);
    if (e.boss && e.bossKind === 'spawner') spawnerBanClear();
    arenaKillReward();
  }
  if (typeof dzLvl !== 'undefined' && dzLvl && typeof dzAlertGain === 'function') dzAlertGain(2.2);
  dropLoot(e);
  /* 同伴倒下：只通知同阵营，并以真正的击杀者为威胁方向。 */
  if (typeof humanComradeFall === 'function') humanComradeFall(e, player);
                            /* 先掉东西，再把人从数组里去掉 */
  e.dead = true; e._settled = true;
  const i = enemies.indexOf(e);
  if (i >= 0) enemies.splice(i, 1);
  if (ar && !CFG.dev && (ar.spawnLeft || 0) <= 0 && enemies.length === 0){
    /* 清波：先特写，再给三秒喘息（期间不出人） */
    ar.inter = ARENA_INTER;
    ar.cineT = 1.1;
    ar.cineX = e.x; ar.cineY = e.y;
    camShake = Math.max(camShake, 1.5);
    punchT = Math.max(punchT, 0.3); punchAmp = 16;
    sfxWaveClear();
    setMsg('第 ' + ar.wave + ' 波 清空了', 2.0);
  } else {
    setMsg('干掉一个', 1.0);
  }
  logWarn('gun', '打倒了一个 ' + enemyType(e).label);
}

function dropGun(){
  const g = player.gun; if (!g) return;
  const dx = Math.cos(player.aim)*38, dy = Math.sin(player.aim)*38;
  const d = safeSpot(cur(), {x:player.x + dx, y:player.y + dy}, 20);
  loots.push({x:d.x, y:d.y, taken:false, kind:'gun', cool:1.2,
              wid:g.wid, mag:g.mag, name:g.name});
  const _gk = gunKeyOf(g);
  if (player.guns && _gk) delete player.guns[_gk];
  clearGunSlot(_gk);
  player.gun = null;
  setMsg(g.name + ' 丢下了 · 走过去能捡回来', 1.8);
  logWarn('gun', '丢下 ' + g.name + ' · 弹匣 ' + g.mag + ' · 子弹还在包里');
}

function companionStopReload(g){
  g.reloading=0;g.shelling=false;g.shellT=0;g.shellPumpT=0;g.reloadDurNow=0;
}
function companionPack(e){
  if(!e.pack){
    const g=makeGun(e.wid, e.ammo);g.reloading=0;
    e.pack={guns:[g],selected:0,ammo:{}};
  }
  return e.pack;
}
function companionSyncGun(e){
  const p=companionPack(e),g=p.guns[p.selected];
  if(g){g.mag=e.ammo;g.cd=e.fireCd||0;g.reloading=e.reloading||0;}
}
function companionEquip(e,index){
  const p=companionPack(e);if(!p.guns[index])return false;
  companionSyncGun(e);if(p.guns[p.selected])companionStopReload(p.guns[p.selected]);
  p.selected=index;const g=p.guns[index];
  e.wid=g.wid;e.ammo=g.mag;e.reloading=0;companionStopReload(g);
  e.fireCd=Math.max(e.fireCd||0,g.cd||0,.3);e.specShotRecovery=Math.max(e.specShotRecovery||0,.3);
  e.tactical=null;return true;
}
function companionReserve(e){const p=companionPack(e);return p.ammo[gunDef({wid:e.wid}).ammo]||0;}

function companionCanTrade(e){return !!e&&!e.dead&&allies.includes(e)&&dist(e.x,e.y,player.x,player.y)<=180;}
function companionGiveGun(e,key){
  if(!companionCanTrade(e))return false;
  const p=companionPack(e),g=player.guns&&player.guns[key];
  if(!g||weaponCore(g.wid).kind!=='gun'||p.guns.length>=COMPANION_PACK.guns)return false;
  // Interrupt reload without creating rounds; preserve the exact weapon instance.
  companionStopReload(g);clearGunSlot(key);delete player.guns[key];
  if(player.gun===g){player.gun=null;const next=gunOrder()[0];if(next)useGun(next);}
  p.guns.push(g);if(p.guns.length===1)companionEquip(e,0);
  mouse.down=false;mouse.fire=false;return true;
}
function companionTakeGun(e,index){
  if(!companionCanTrade(e))return false;
  const p=companionPack(e),g=p.guns[index];if(!g)return false;
  if(bagGridOn()&&gunClassFull(gunClass(g.wid)))return false;
  companionSyncGun(e);const key=gunNewKey(g.wid);
  player.guns[key]=g;
  if(!autoEquipGun(key)){delete player.guns[key];return false;}
  const selected=p.selected;p.guns.splice(index,1);companionStopReload(g);
  if(index===selected){
    // Do not sync the removed magazine into its replacement.
    p.selected=-1;e.reloading=0;e.ammo=0;
    if(p.guns.length)companionEquip(e,Math.min(index,p.guns.length-1));
  }else if(index<selected)p.selected--;
  if(!player.gun)useGun(key);return true;
}
function companionTransferAmmo(e,type,give,n=30){
  if(!companionCanTrade(e)||!Object.hasOwn(AMMO,type)||!Number.isInteger(n)||n<=0)return 0;
  const p=companionPack(e),stored=p.ammo[type]||0;let moved=0;
  if(give){
    n=Math.min(n,COMPANION_PACK.ammo-stored);if(n<=0)return 0;
    moved=spendAmmo(type,n);p.ammo[type]=stored+moved;
  }else{
    n=Math.min(n,stored);
    if(bagGridOn())moved=bagAddAmmo(type,n);
    else{player.ammo[type]=(player.ammo[type]||0)+n;moved=n;}
    p.ammo[type]=stored-moved;
  }
  return moved;
}

function companionPackValid(e){
  const p=e.pack;if(p===undefined)return true; // old saves migrate with zero spare rounds
  if(!p||!Array.isArray(p.guns)||p.guns.length>COMPANION_PACK.guns||!p.ammo||Array.isArray(p.ammo))return false;
  if(!Number.isInteger(p.selected)|| (p.guns.length?(p.selected<0||p.selected>=p.guns.length):p.selected!==-1))return false;
  if(!p.guns.every(g=>g&&WEAPONS[g.wid]&&weaponCore(g.wid).kind==='gun'&&Number.isInteger(g.mag)&&g.mag>=0&&g.mag<=weaponCore(g.wid).cap))return false;
  if(!Object.entries(p.ammo).every(([t,n])=>AMMO[t]&&Number.isInteger(n)&&n>=0&&n<=COMPANION_PACK.ammo))return false;
  const g=p.guns[p.selected];return g?g.wid===e.wid&&g.mag===e.ammo:e.ammo===0;
}

/* 某把枪身上的配件表（懒建，老存档的枪没有这个字段） */
function gunAtt(g){
  if (!g) return null;
  if (!g.att || typeof g.att !== 'object') g.att = {};
  return g.att;
}
function gunAttachId(g, slot){
  const a = g && g.att;
  const id = a && a[slot];
  return attachDef(id) ? id : null;
}
/* 装上（返回被换下来的那件 id，没有就 null）。不适配直接返回 false */
function gunAttach(g, id){
  const d = attachDef(id);
  if (!g || !d || !g.wid) return false;
  if (!attachFits(id, g.wid)) return false;
  const a = gunAtt(g);
  const old = a[d.slot] || null;
  a[d.slot] = id;
  return old;
}
/* 取下某个槽，返回取下的 id（没有就 null） */
function gunDetach(g, slot){
  const a = g && g.att;
  if (!a || !a[slot]) return null;
  const id = a[slot];
  delete a[slot];
  return id;
}

/* 所有已装配件的系数乘积 —— 没装就是全 1 */
function gunAttachMods(g){
  const out = { spreadK:1, dmgK:1, recoilK:1 };
  const a = g && g.att;
  if (!a) return out;
  for (const slot in a){
    const d = attachDef(a[slot]);
    if (!d || !d.mods) continue;
    for (const k in d.mods) out[k] = (out[k] === undefined ? 1 : out[k]) * d.mods[k];
  }
  return out;
}
function attachSpreadK(g){ return gunAttachMods(g).spreadK; }
function attachDmgK(g){ return gunAttachMods(g).dmgK; }
/* 弹匣容量是"绝对值"不是乘算：装了扩容/快速弹匣就以它的 magCap 为准，没装就回原厂 cap0 */
function attachMagCap(g){
  const a = g && g.att;
  if (!a) return 0;
  const d = attachDef(a.mag);
  const v = d && d.mods && d.mods.magCap;
  return (typeof v === 'number' && v > 0) ? v : 0;
}
function attachReloadK(g){
  const a = g && g.att;
  if (!a) return 1;
  let k = 1;
  for (const slot in a){
    const d = attachDef(a[slot]);
    const v = d && d.mods && d.mods.reloadK;
    if (typeof v === 'number' && v > 0) k *= v;
  }
  return k;
}
/* 配件变了就把枪的 cap / reloadDur 重算一遍（cap0 / reloadDur0 是原厂值，第一次调用时记下来）。
   返回"因为容量变小而多出来的子弹数"，调用方负责还给玩家（掉脚边），绝对不能吞。 */
function gunApplyAttach(g){
  if (!g) return 0;
  if (typeof g.cap0 !== 'number' || !isFinite(g.cap0)) g.cap0 = (typeof g.cap === 'number' ? g.cap : 0);
  if (typeof g.reloadDur0 !== 'number' || !isFinite(g.reloadDur0)) g.reloadDur0 = (typeof g.reloadDur === 'number' ? g.reloadDur : 1);
  const cap = attachMagCap(g) || g.cap0;
  if (cap > 0) g.cap = cap;
  g.reloadDur = Math.max(0.05, g.reloadDur0 * attachReloadK(g));
  if (typeof g.reloading === 'number' && g.reloading > 0) g.reloading = Math.min(g.reloading, g.reloadDur);
  if (typeof g.reloadDurNow === 'number' && g.reloadDurNow > 0) g.reloadDurNow = Math.min(g.reloadDurNow, g.reloadDur);
  let over = 0;
  if (typeof g.mag === 'number' && g.mag > g.cap){ over = g.mag - g.cap; g.mag = g.cap; }
  return over;
}

/* ---------------- 武器栏（只有 ver3 的关卡才有） ----------------
   手上最多两把：player.slots = [wid, wid]。老关卡（非 ver3）不启用，
   gunOrder() 直接回退成"包里有什么就能切什么"，行为跟以前一模一样。 */
function gunSlots(){
  if (!Array.isArray(player.slots)) player.slots = [null, null, null, null];
  /* 老存档：两格 [主, 副] → [主1, 主2, 副, 近战]；三格（上一版）→ 末尾补一格近战 */
  if (player.slots.length === 2) player.slots = [player.slots[0], null, player.slots[1], null];
  while (player.slots.length < 4) player.slots.push(null);
  return player.slots;
}
function gunSlotOf(wid){ return gunSlots().indexOf(wid); }
/* 枪分三类：主武器（长枪 / 火箭筒 / 信号枪以外的长枪）、副武器（手枪 / 信号枪）、近战（刀） */
const GUN_CLASS = { pistol:'side', flare:'side', bino:'side', knife:'melee', dao:'melee', shotgun:'main', rifle:'main', ar:'main', rpg:'main' };
function gunClass(wid){ return GUN_CLASS[gunModel(wid)] || 'main'; }
/* 0 / 1 = 主武器栏（两把长枪），2 = 副武器栏（手枪 / 信号枪），3 = 近战栏（刀） */
const GUN_SIDE_SLOT = 2;
const GUN_MELEE_SLOT = 3;
function gunSlotIndex(wid){
  const cls = gunClass(wid);
  if (cls === 'side') return GUN_SIDE_SLOT;
  if (cls === 'melee') return GUN_MELEE_SLOT;
  const S = gunSlots();
  if (!S[0]) return 0;
  if (!S[1]) return 1;
  return 0;                       /* 两个主武器栏都占着时返回 0（会被判满） */
}
function gunSlotWid(cls){
  const S = gunSlots();
  if (cls === 'side') return S[GUN_SIDE_SLOT];
  if (cls === 'melee') return S[GUN_MELEE_SLOT];
  return S[0] || S[1];
}
function gunClassFull(cls){
  const S = gunSlots();
  const live = w => !!(w && player.guns && player.guns[w]);
  if (cls === 'side') return live(S[GUN_SIDE_SLOT]);
  if (cls === 'melee') return live(S[GUN_MELEE_SLOT]);   /* 刀只能拿一把 */
  return live(S[0]) && live(S[1]);         /* 两个主武器栏都满了才算满 */
}
function gunSlotsFull(){ return gunSlots().every(w => !!(w && player.guns && player.guns[w])); }
function gunOrder(){
  if (!bagGridOn()){
    const keys = Object.keys(player.guns || {});
    keys.sort((a, b) => {
      const ia = WEAPON_ORDER.indexOf(gunModel(a)), ib = WEAPON_ORDER.indexOf(gunModel(b));
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    /* 烟雾弹是投掷物，不进换枪轮换（不然按 Q/F 会切出一颗烟，还切不回去） */
    return keys.filter(k => {
      const g = player.guns[k];
      return !!g && g.kind !== 'throw' && gunModel(k) !== 'smoke';
    });
  }
  const out = gunSlots().filter(w => w && player.guns && player.guns[w]);
  return out;
}
/* 把一把枪放进第 i 格；同一把枪原来在别的格子就先腾出来 */
function equipGunSlot(i, wid){
  const S = gunSlots();
  if (!(player.guns && player.guns[wid])) return false;
  const cls = gunClass(wid);
  const tgt = cls === 'side' ? GUN_SIDE_SLOT : cls === 'melee' ? GUN_MELEE_SLOT : (i === 1 ? 1 : 0);
  if (S[tgt] && S[tgt] !== wid && player.guns && player.guns[S[tgt]]) return false;   /* 那格有别人 */
  const old = S.indexOf(wid);
  if (old === tgt) return true;
  if (old >= 0) S[old] = S[tgt] || null;        /* 同栏互换：把对调过来的那把挪到原位置 */
  S[tgt] = wid;
  return true;
}
/* 拖动换位：把 from 格那把枪放到 to 格（类别要相容），成功返回 true */
function gunMoveSlot(from, to){
  const S = gunSlots();
  if (from === to) return false;
  const a = S[from];
  if (!a) return false;
  const _ac = gunClass(a);
  if (to === GUN_SIDE_SLOT && _ac !== 'side'){
    setMsg('副武器栏只能放手枪 / 信号枪', 1.6); return false;
  }
  if (to === GUN_MELEE_SLOT && _ac !== 'melee'){
    setMsg('近战栏只能放刀', 1.6); return false;
  }
  if (to !== GUN_SIDE_SLOT && _ac === 'side'){
    setMsg('手枪只能进副武器栏', 1.6); return false;
  }
  if (to !== GUN_MELEE_SLOT && _ac === 'melee'){
    setMsg('刀只能进近战栏', 1.6); return false;
  }
  const b = S[to];
  S[to] = a; S[from] = b || null;
  return true;
}
function clearGunSlot(wid){
  const S = gunSlots();
  const i = S.indexOf(wid);
  if (i >= 0) S[i] = null;
}
/* 捡到新枪时按类别落位：长枪进主武器 1/2 的空位，手枪刀进副武器栏 */
function autoEquipGun(wid){
  if (!bagGridOn()) return true;
  const S = gunSlots();
  if (S.indexOf(wid) >= 0) return true;
  let i;
  const _cls = gunClass(wid);
  if (_cls === 'side' || _cls === 'melee'){
    i = _cls === 'melee' ? GUN_MELEE_SLOT : GUN_SIDE_SLOT;
    if (S[i] && player.guns && player.guns[S[i]]) return false;
  } else {
    i = (S[0] && player.guns && player.guns[S[0]]) ? (S[1] && player.guns && player.guns[S[1]] ? -1 : 1) : 0;
    if (i < 0) return false;
  }
  S[i] = wid;
  return true;
}

/* Q 键轮换手里的枪。每把枪的弹匣/备弹各自记着，换回来还是原来的数 */
/* 直接切到某一把（点武器栏用），跟 switchWeapon 走同一套收尾 */
function useGun(wid){
  if (!hasFeat('guns')) return false;
  player.hand = null;   /* 点枪栏 = 从手雷换回枪 */
  const g = player.guns && player.guns[wid];
  if (!g || player.gun === g) return false;
  if (playerShieldUp()){ player.shieldRaised = false; mouse.fire = false; mouse.down = false; }
  if (player.gun) (player.guns || (player.guns = {}))[gunKeyOf(player.gun)] = player.gun;
  player.gun = g;
  g.reloading = 0;
  g.cd = Math.max(g.cd, 0.12);
  if (!ar) player.heal = null;
  sfxClickGun(true);
  setMsg(g.kind === 'throw'
    ? (g.name + ' ×' + g.mag + '　左键扔出去')
    : (g.name + ' · 弹匣 ' + g.mag + ' / ' + g.cap + '　' + ammoDef(g.ammo).label + ' ' + ammoOf(g)), 1.6);
  logInfo('gun', '换到 · ' + g.name);
  return true;
}

function switchWeapon(dir){
  if (!hasFeat('guns')) return;
  player.hand = null;   /* F 换枪 = 从手雷换回枪 */
  player.qPhase = 'gun';
  /* 举着盾按换枪：先把盾收起来，但这次按键继续往下走，直接换到下一把枪。
     以前这里直接 return，玩家按 F 只会看到"收盾 · 手枪"，感觉像卡在盾和手枪之间。 */
  let lowered = false;
  if (playerShieldUp()){ player.shieldRaised = false; mouse.fire = false; mouse.down = false; lowered = true; }
  const bag = player.guns || (player.guns = {});
  const order = gunOrder();
  if (order.length < 2){
    /* 手上这把其实是投掷物（老存档）：换枪就换到唯一那把真枪，别又把烟塞回手里 */
    if (player.gun && player.gun.kind === 'throw' && order.length >= 1){
      const nxt = bag[order[0]];
      if (nxt && nxt !== player.gun){
        bag[gunKeyOf(player.gun)] = player.gun;
        player.gun = nxt;
        nxt.reloading = 0; nxt.cd = Math.max(nxt.cd, 0.12);
        player.hand = null;
        sfxClickGun(true);
        setMsg((lowered ? '收盾 · ' : '') + '换到 ' + nxt.name, 1.2);
        return;
      }
    }
    if (lowered) setMsg('收盾 · ' + ((player.gun && player.gun.name) || '手上这把枪') + '（只有一把枪，按 G 再举盾）', 1.8);
    return;
  }
  const curW = (player.gun && gunKeyOf(player.gun)) || order[0];
  let i = order.indexOf(curW);
  if (i < 0) i = 0;
  i = (i + (dir || 1) + order.length) % order.length;
  const next = bag[order[i]];
  if (!next) return;
  if (player.gun) bag[gunKeyOf(player.gun)] = player.gun;
  player.gun = next;
  next.reloading = 0;
  next.cd = Math.max(next.cd, 0.12);      /* 换枪有个小硬直 */
  if (!ar) player.heal = null;            /* 换枪会打断吃药；战斗，爽！！里不打断 */
  /* 老存档里烟雾弹是"挂在武器栏的一把投掷枪"，换到它时别画那个枪模型，
     直接变成"手里拿着烟雾罐"，模型才和背包/地上一套 */
  if (next.kind === 'throw' && typeof handHoldKind === 'function'){
    handHoldKind('smoke');
    logInfo('gun', '换到 · 烟雾弹');
    return;
  }
  sfxClickGun(true);
  setMsg((lowered ? '收盾 · ' : '') + (next.kind === 'throw'
    ? (next.name + ' ×' + next.mag + '　左键扔出去')
    : (next.name + ' · 弹匣 ' + next.mag + ' / ' + next.cap +
       '　' + ammoDef(next.ammo).label + ' ' + ammoOf(next))), 1.6);
  logInfo('gun', '换到 · ' + next.name);
}

function ammoLabelOf(t){ const d = AMMO[t]; return d ? d.label : (t || '子弹'); }
/* 背包里"另一种口径"的余量，用来在换不了弹时说清楚为什么 */
function bagAmmoSummary(exceptType){
  const order = (typeof AMMO_ORDER !== 'undefined' && AMMO_ORDER) ? AMMO_ORDER : Object.keys(AMMO);
  const parts = [];
  for (const t of order){
    if (t === exceptType) continue;
    const n = (player.ammo && player.ammo[t]) || 0;
    if (n > 0) parts.push(ammoLabelOf(t) + ' ' + n);
  }
  return parts.join('、');
}
function noAmmoMsg(g){
  const need = ammoLabelOf(g && g.ammo);
  const other = bagAmmoSummary(g && g.ammo);
  if (other) setMsg('没有' + need + '了 · 背包里只有 ' + other + '（口径不对，按 F 换枪）', 2.6);
  else setMsg('没有' + need + '了', 1.4);
}
function reloadGun(){
  /* m20307：手里拿着手雷/烟雾弹时按 R 什么也不该发生 ——
     以前会去换背后那把枪：听得到换弹声、弹药也真扣了，
     玩家看着手里那颗雷，以为在"给手雷换弹"。 */
  if (player && player.hand){
    setMsg('手上是' + ((typeof throwNameOf === 'function') ? throwNameOf(player.hand) : '投掷物') +
           ' · 按 ' + keyLabel(BINDS.throwToggle) + ' 换回枪再换弹', 1.2);
    return;
  }
  const g = player.gun; if (!g) return;
  /* 兜底：任何一项计时是 NaN，换弹就会永远卡在"进行中"，按 R 一点反应都没有 */
  if (!isFinite(g.reloading) || g.reloading < 0) g.reloading = 0;
  if (!isFinite(g.reloadDur) || g.reloadDur <= 0) g.reloadDur = 1.0;
  if (!isFinite(g.shellT)) g.shellT = 0;
  if (!isFinite(g.shellPumpT)) g.shellPumpT = 0;
  if (!isFinite(g.shellDur) || g.shellDur <= 0) g.shellDur = 0.42;
  if (g.shelling && g.mag >= g.cap) g.shelling = false;
  if (g.kind === 'throw'){ setMsg('这个没法换弹', 0.9); return; }
  if (g.reloading > 0 || g.mag >= g.cap) return;
  /* 火箭筒：弹匣上限由【火箭筒弹匣】金卡决定，装填只能从弹药池里取 */
  if (g.rocket && ar){
    g.cap = arenaRocketCap();
    if (g.mag >= g.cap) return;
    if (arenaRocketLeft() <= 0){ setMsg('没有火箭弹了 · 每拿一张卡才多一发', 1.6); return; }
  }
  /* 霰弹枪：一颗一颗往里塞，塞完一颗就能开枪打断 */
  if (gunDef(g).shellReload){
    if (g.shelling) return;
    if (!(CFG.dev && CFG.devInfAmmo) && ammoOf(g) <= 0){
      noAmmoMsg(g); return;
    }
    const _sm = (ar && ar.reloadMul) ? ar.reloadMul : 1;
    g.shelling = true;
    /* 先拉一次枪膀（这是“上子弹”的前摇），拉完才能连续往里塞 */
    g.shellPumpT = SHELL_PUMP_T * _sm;
    g.shellPumpDur = g.shellPumpT;
    g.shellT = 0;
    g.shellDur = (gunDef(g).shellDur || 0.42) * _sm;
    if (!sndPlay('gun.shotgun.pump', 0.6)) sfxClickGun(true);
    logInfo('gun', '开始逐发装填 · 弹匣 ' + g.mag + '/' + g.cap);
    return;
  }
  if (!(CFG.dev && CFG.devInfAmmo) && ammoOf(g) <= 0){
    noAmmoMsg(g); return;
  }
  const _rm = (ar && ar.reloadMul) ? ar.reloadMul : 1;
  /* 快手 ×0.88/层；火箭筒在割草里再砍半（见 ARENA_ROCKET_RELOAD_K） */
  g.reloading = g.reloadDur * _rm * ((g.rocket && ar) ? ARENA_ROCKET_RELOAD_K : 1);
  g.reloadDurNow = g.reloading;
  /* m20234：AR15 换弹三段音 —— 必须等 g.reloading 算完再排期，
     以前用 g.reloadDur 提前算，配件改过换弹速度或 reloadMul 不等于 1 时就会错位。 */
  if (g.wid === 'ar' && typeof sfxAr15ReloadSeq === 'function') sfxAr15ReloadSeq(g);
  /* 真录的换弹声（时长已按 reloadDur 做过变速），没文件就用原来的点击音 */
  /* AR15 已经放了实录，就不要再叠一层电子"咔哒" */
  if (g.wid !== 'ar' &&
      !(g.wid === 'rifle'  && sndPlay('gun.uzi.reload', 0.55)) &&
      !(g.wid === 'pistol' && sndPlay('gun.pistol.reload', 0.55))) sfxClickGun(false);
  logInfo('gun', '换弹 · ' + g.reloading.toFixed(1) + ' 秒');
}

function useMed(kind){
  /* 战斗，爽！！没有打药这回事：地上的药捡起来当场吃掉 */
  if (ar){ setMsg('割草模式不打药 · 地上的药捡起来就回血', 1.2); return; }
  if (player && player.hand){ player.hand = null; player.nadeCooking = false; player.nadeQueue = false; }
  if (!hasFeat('meds')) return;
  /* 已经倒地了就别再开新读条：药救不回来（用户 m13074） */
  if (typeof dyingT !== 'undefined' && (dyingT > 0 || player.hp <= 0)){ setMsg('人已经倒了 · 药没用', 1.0); return; }
  if (playerInWall){ setMsg('人还卡在墙里 —— 先出去再处理伤口', 1.8); return; }
  const d = MED_DEF[kind]; if (!d) return;
  if (!player.meds) return;
  if (player.heal){ cancelHeal(); return; }
  if (!(CFG.dev && CFG.devInfMed) && (player.meds[kind]||0) <= 0){ setMsg('没有' + d.label, 1.0); return; }
  if (player.hp >= arenaMaxHp()){ setMsg('血是满的', 1.0); return; }
  let _mq = 0, _mdu = 100;
  if (!(CFG.dev && CFG.devInfMed)){
    if (bagGridOn()){
      const _mi = bagTakeMed(kind);             /* ver3：这一颗真的从格子里拿走了 */
      if (_mi){
        if (_mi.q) _mq = _mi.q;                 /* 拿的是哪一颗，就按哪一颗的品质回血 */
        _mdu = medDuOf(_mi);                    /* 还剩多少耐久，就只回多少 */
      }
    } else player.meds[kind]--;
  }
  /* 流血不再"一点就停"（远古 bug）：等读条真的落地第一段才止血，见 update 里 */
  const _duK = Math.max(0.25, _mdu / 100);
  const _dur = (CFG.dev && CFG.devNoHealCd) ? 0.05 : Math.max(0.35, d.dur * _duK);
  /* 打药分三段（m19010）：每 1/3 读条结算一次血，耐久也跟着掉一段。
     一件药就是三段，中途取消只退还没打的段（part 记在格子上）。 */
  const _mAmt = Math.round(d.amt * qualityK(_mq) * _mdu / 100);
  player.heal = {kind:kind, t:0, dur:_dur, q:_mq, du0:_mdu, healed:0, amt:_mAmt,
                 per:_mAmt / 3, need:3, ticks:0, hp0:player.hp};
  ui.inv.open = false;
  setMsg('用药中 · ' + d.label + '（X 取消）', 1.6);
  logInfo('med', '开始用 ' + d.label + ' · ' + d.dur + 's');
}

/* 死了 / 结算：把玩家身上所有"正在进行"的动作掐掉。
   以前读条能跨过死亡继续，血条一到就把人从地上拉起来（用户 m13074）。 */
function haltPlayerActions(){
  if (!player) return;
  player.heal = null;
  player.nadeCooking = false;
  player.nadeQueue = false;
  player.binoK = 0;
  if (player.hand) player.hand = null;
  if (player.gun){
    player.gun.reloading = 0;
    player.gun.shellT = 0;
    player.gun.shellPumpT = 0;
  }
}

function cancelHeal(){
  const h = player.heal; if (!h) return;
  let _back = true;
  if (!(CFG.dev && CFG.devInfMed)){
    if (bagGridOn()){
      /* 取消不吞药：先试着放回格子；背包满了就掉在脚边，绝不凭空消失 */
      const _useK = (h.amt > 0) ? Math.max(0, Math.min(1, (h.healed || 0) / h.amt)) : 0;
      const _leftDu = Math.max(1, Math.round((h.du0 || 100) * (1 - _useK)));
      _back = bagAddMed(h.kind, h.q, _leftDu);
      if (!_back && typeof bagLootFromItem === 'function'){
        bagLootFromItem({ k:'med', r:h.kind, q:h.q, du:_leftDu });
      }
    } else player.meds[h.kind] = (player.meds[h.kind]||0) + 1;   /* 取消不吞药 */
  }
  player.heal = null;
  setMsg(_back ? '取消了，药还在包里' : '背包满了 · 药掉在你脚边', _back ? 1.2 : 1.8);
  logInfo('med', '用药取消');
}

/* ---------- 测试区专属：人机会「伤重就跑、躲起来自己打药」 ----------
   只在 devTest 关卡里被 update() 调用；正式关卡一帧都进不来，
   所以那些关卡的人机行为和现在完全一样。 */

/* 你（玩家）能不能看见这个点？视距 + 视角 + 没有墙挡着。
   和 playerSees 用的是同一套数，所以 AI 说的"你看不见"和你屏幕上的"看不见"是同一件事。 */
function playerCanSeePoint(x, y){
  const L = cur();
  if (player && player.thermal) return true;      /* 热成像里没有掩体 */
  const d = dist(player.x, player.y, x, y);
  /* 夜里的微光：贴得够近就算看得见（画面上也确实会把它照出来） */
  const glow = (L.rules && L.rules.nightGlow) || 0;
  if (glow > 0 && d <= glow) return true;
  if (d > pVisionNow()) return false;
  if (d > 120){
    const ang = Math.atan2(y - player.y, x - player.x);
    const da = Math.abs(normAng(ang - (player.aim || 0)));
    if (da > CFG.pFov * Math.PI / 360) return false;
  }
  /* m44971：车壳也该挡你的视线。以前 clearLine 只查墙，车停在中间时
     "你看不见他"和"血条还亮着"是两套答案 —— 现在统一按车身算。 */
  if (typeof truckOcclSeg === 'function' && truckOcclSeg(player.x, player.y, x, y)) return false;
  return clearLine(L, player.x, player.y, x, y);
}

/* 挑一个躲的地方 —— 关键不是你离它多远，而是"你看不见它"。
   老版本只按距离打分，结果它会蹲在空地正中间、你站着就能瞄准的地方打药。
   现在先粗网格扫一遍全图（每 64px 一个点），只收能真正藏住的点：
     ① 是空地（safeSpot 推出去）② 离你 > 170px ③ 你的视线到不了。
   剩下的按"离它自己近"排序——先到得了，才叫躲；跑半个地图早被打死了。 */
/* 身体是不是整个都在掩体后面（不是只看中心点）——中心 + 两侧身宽三个点都被挡才算真躲好 */
/* 开枪后坐力的进度：0 = 没后坐力，1 = 刚踢到最远。
   注意必须用 e.recMax（每把枪/每发都可能不同），不要用常量——否则没开过枪的敌人
   分母会算成 NaN，整个人直接画不出来（这个 bug 真踩过）。 */
function bodyRecoil(e){
  if (!e || !humanOn()) return 0;
  const total = (e.recMax > 0 ? e.recMax : 0.18);
  const age = total - (e.recT > 0 ? e.recT : 0);
  if (!(age > 0)) return 0;
  if (age < HUMAN.recKick) return age / HUMAN.recKick;
  const back = Math.max(0.01, total - HUMAN.recKick);
  const v = Math.pow(1 - (age - HUMAN.recKick) / back, 2);
  return (v > 0 && v <= 1) ? v : 0;
}

/* 任意战斗实体能不能看见一个点。玩家沿用玩家视野；NPC 走自己的视距、视角和 LOS。 */
function combatActorCanSeePoint(viewer, x, y){
  if (!viewer) return false;
  if (viewer === player) return playerCanSeePoint(x, y);
  if (viewer.dead || viewer.gone || (viewer.hp !== undefined && viewer.hp <= 0)) return false;
  if (viewer.type || viewer.controller || viewer.faction || viewer.team){
    return npcSeesTarget(viewer, {x:x, y:y, r:0, hp:1}, false);
  }
  /* 只有声音记忆坐标、没有实体时，不凭空造一个朝向；只要求几何射线能通。 */
  return !losBlocked(viewer.x, viewer.y, x, y, false, true);
}

function bodyBlind(ex, ey, r, threat){
  threat = threat || player;
  if (!threat || threat.x === undefined || threat.y === undefined) return false;
  const rr = r || 11;
  if (!losBlocked(threat.x, threat.y, ex, ey, false, true)) return false;
  const a = Math.atan2(ey - threat.y, ex - threat.x) + Math.PI / 2;
  const ox = Math.cos(a) * rr * 0.92, oy = Math.sin(a) * rr * 0.92;
  if (!losBlocked(threat.x, threat.y, ex + ox, ey + oy, false, true)) return false;
  if (!losBlocked(threat.x, threat.y, ex - ox, ey - oy, false, true)) return false;
  return true;
}
/* 贴墙：从选好的点往墙边挤，一直挤到刚刚好还被挡住为止 */
function hugCover(L, p, threat){
  threat = threat || player;
  let bx = p.x, by = p.y;
  const a = Math.atan2(threat.y - p.y, threat.x - p.x);
  for (let i = 0; i < 7; i++){
    const nx = bx + Math.cos(a) * 5, ny = by + Math.sin(a) * 5;
    if (!bodyBlind(nx, ny, 11, threat)) break;
    const sp = safeSpot(L, {x:nx, y:ny}, 22);
    if (Math.hypot(sp.x - nx, sp.y - ny) > 1.5) break;
    bx = nx; by = ny;
  }
  return {x: bx, y: by};
}
/* Hide-spot candidate grid, built once per level.
   Building it inside pickHideSpot cost ~1660 points on 4-1 per call. */
function hideGrid(L){
  if (L._hideGrid && L._hideGW === L.w && L._hideGH === L.h) return L._hideGrid;
  const g = [];
  const st = HIDE_CFG.gridStep;
  for (let x = 70; x < L.w - 70; x += st)
    for (let y = 70; y < L.h - 70; y += st) g.push({x: x, y: y});
  L._hideGrid = g; L._hideGW = L.w; L._hideGH = L.h;
  return g;
}

/* 点到线段距离 < r？逃命时用来判断"这条路线会不会从玩家身边擦过去" */
function segNearPoint(x1, y1, x2, y2, px, py, r){
  const dx = x2 - x1, dy = y2 - y1;
  const L2 = dx * dx + dy * dy;
  let t = L2 ? ((px - x1) * dx + (py - y1) * dy) / L2 : 0;
  if (t < 0) t = 0; else if (t > 1) t = 1;
  const cx = x1 + dx * t, cy = y1 + dy * t;
  return Math.hypot(px - cx, py - cy) <= (r || 90);
}

/* 逃命掩体的四道否决（抽成独立函数，方便单测）：
   ① 不能躲进你正在待的那间屋子   ② 跑完不能离你更近
   ③ 方向不能朝着你               ④ 路线不能从你身边擦过去 */
function fleeSpotRejected(L, e, p, threat, d0, away0){
  const rG = levelRoomAt(L, p.x, p.y);
  if (rG && rG === levelRoomAt(L, threat.x, threat.y)) return true;
  const d = dist(p.x, p.y, threat.x, threat.y);
  if (d < d0 - 30) return true;
  const bear = Math.atan2(p.y - threat.y, p.x - threat.x);
  if (Math.abs(normAng(bear - away0)) > 1.31) return true;
  const clearance=96;
  if (d0<=clearance){
    /* 已经被贴脸时，允许沿远离威胁的方向退出这圈。 */
    return (e.x-threat.x)*(p.x-e.x)+(e.y-threat.y)*(p.y-e.y)<0;
  }
  if (segNearPoint(e.x, e.y, p.x, p.y, threat.x, threat.y, clearance)) return true;
  return false;
}

/* opts.flee：残血逃命专用。
   逃兵不能"往你脸上跑"—— 之前只按"到掩体的距离近 + 中间隔墙"打分，
   于是玩家正对面那间屋子的内墙会拿到 +260，敌人扛着枪从你面前冲进屋里躲起来。
   加上这几条之后，逃命目标必须离你更远、方向不能朝你、也不能是你在的那间屋。 */
function pickHideSpot(L, e, minPD, strict, threat, opts){
  threat = threat || ((typeof enemyThreatOf === 'function') ? enemyThreatOf(e) : player) || player;
  const _room=levelRoomAt(L,e.x,e.y);
  const _localRoom=_room&&levelRoomAt(L,threat.x,threat.y)===_room?_room:null;
  const _minRange=_localRoom?Math.min(Math.max(170,minPD||0),Math.max(65,Math.min(_room.w,_room.h)*.35)):Math.max(170,minPD||0);
  /* 硬上事件：这段时间敌人不找掩体，直接压上来（子弹该被墙挡还是被墙挡） */
  const cands = [];
  if (e.wp && e.wp.length) for (const w of e.wp) cands.push({x:w[0], y:w[1]});
  const away = Math.atan2(e.y - threat.y, e.x - threat.x);
  for (let k = 1; k <= 8; k++){
    const a = away + (k % 2 ? 1 : -1) * 0.3 * k;
    const t = 160 + k * 55;
    cands.push({x: e.x + Math.cos(a)*t, y: e.y + Math.sin(a)*t});
  }
  /* Only sample the grid near the enemy (<=1500px) and cap the count:
     the full grid is up to ~1660 cells on the long levels and each cell
     runs safeSpot + playerCanSeePoint + losBlocked. */
  const grid = hideGrid(L);
  const rad2 = HIDE_CFG.searchR * HIDE_CFG.searchR;
  const near = [];
  for (const g of grid){
    const dx = g.x - e.x, dy = g.y - e.y;
    if (dx*dx + dy*dy <= rad2) near.push(g);
  }
  const cap = HIDE_CFG.maxCands;
  const step = near.length > cap ? Math.ceil(near.length / cap) : 1;
  for (let i = 0; i < near.length; i += step) cands.push(near[i]);

  let best = null, bs = -1e9;          /* 最好：中间隔着墙，你打不到也看不见 */
  let best2 = null, bs2 = -1e9;        /* 次好：没有墙，但不在你视野里 */
  let fb = null, fbs = -1e9;           /* 一处都藏不住时的兜底：挑最远的 */
  const banOn = e.banT && uiT < e.banT;
  /* 逃命约束（见函数头注释） */
  const _flee = !!(opts && opts.flee);
  const _d0 = _flee ? dist(e.x, e.y, threat.x, threat.y) : 0;
  const _away0 = Math.atan2(e.y - threat.y, e.x - threat.x);     /* 从你指向它 = "远离你" */
  const _roomYou = _flee ? levelRoomAt(L, threat.x, threat.y) : null;
  for (const c of cands){
    const p = safeSpot(L, c, 22);
    p.x = clamp(p.x, 20, L.w-20); p.y = clamp(p.y, 20, L.h-20);
    if(_localRoom&&!roomHasPoint(_localRoom,p.x,p.y))continue;
    const d = dist(p.x, p.y, threat.x, threat.y);
    if (_flee && fleeSpotRejected(L, e, p, threat, _d0, _away0)) continue;
    if (d > fbs){ fbs = d; fb = {x:p.x, y:p.y}; }
    if (d < _minRange) continue;
    if (combatActorCanSeePoint(threat, p.x, p.y)) continue;
    const walled = losBlocked(threat.x, threat.y, p.x, p.y);
    const hidden = !strict || bodyBlind(p.x,p.y,11,threat);
    if (strict && (!walled || !hidden)) continue;
    /* 刚逃出来的那片地方不要再回去。不然两处一样好的掩体会被反复选中，
       你站在中间就能看见它左右横跳 —— 这就是那个"来回晃"的 bug。 */
    if (banOn && e.banned){
      let skip = false;
      for (const b of e.banned) if (dist(b.x, b.y, p.x, p.y) < 90){ skip = true; break; }
      if (skip) continue;
    }
    const de = dist(p.x, p.y, e.x, e.y);
    /* 直着就能跑过去的地方额外加分：少绕路，也就少贴着墙角来回磨 */
    const straight = clearLine(L, e.x, e.y, p.x, p.y) ? 80 : 0;
    const sc = -de * 0.85 + Math.min(d, 1100) * 0.35 + straight + (walled ? 260 : 0);
    if (walled){ if (sc > bs){ bs = sc; best = {x:p.x, y:p.y}; } }
    else if (sc > bs2){ bs2 = sc; best2 = {x:p.x, y:p.y}; }
  }
  if (strict && best){
    const tucked=hugCover(L,best,threat);
    return _localRoom&&!roomHasPoint(_localRoom,tucked.x,tucked.y)?best:tucked;
  }
  return strict ? (best || null) : (best || best2 || fb);
}

/* 气泡：默认跟着人画在头顶。alpha 参数给 1；看不见人只听见声音时用更淡的值 */
function drawBark(e, alpha){
  if (!e || e.hp <= 0 || e.dead || e.gone) return;
  /* 绝对到期：barkT 只在"这只敌人被 update 到"的某些分支里减，
     可它一旦切成搜房/支援/刀手就会提前 return，或者干脆被 LOD 睡着不再更新 ——
     barkT 停在 0.6 永远不减，气泡就被 clamp 到屏幕边上赖着不走（用户报的"左上角那句话不消失"）。
     这里用关卡时钟兜底：到点就清，不依赖任何一条 update 路径。 */
  if (typeof timeAlive === 'number' && typeof e.barkUntil === 'number' && timeAlive > e.barkUntil){
    e.barkT = 0; e.bark = '';
    return;
  }
  /* 离得太远就别画了：气泡会被 clamp 到屏幕边缘，看着像挂在 UI 上 */
  if (player && typeof dist === 'function' && dist(player.x, player.y, e.x, e.y) > 1150) return;
  const k = Math.min(1, e.barkT / 0.25) * (alpha === undefined ? 1 : alpha);
  ctx.save();
  ctx.globalAlpha = k;
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  const bw = ctx.measureText(e.bark).width + 14;
  /* 气泡是在 HUD 之上、屏幕空间里画的（barkFlush 在世界变换还原之后），
     所以这里必须自己把世界坐标换成屏幕坐标，否则会拿着关卡里的坐标直接画，
     在大地图上直接跑到屏幕外去。 */
  const _ax = (typeof e.barkX === 'number') ? e.barkX : e.x;
  const _ay = (typeof e.barkY === 'number') ? e.barkY : e.y;
  const _sp = deathScreenPos(_ax, _ay);
  const bx = clamp(_sp.x, bw/2 + 6, W - bw/2 - 6);
  const by = clamp(_sp.y - e.r - 16, 22, H - 20);
  const tx = clamp(_sp.x, bx - bw/2 + 9, bx + bw/2 - 9);   /* 小尖角指着说话的人 */
  ctx.fillStyle = 'rgba(12,16,22,0.86)';
  roundRect(bx - bw/2, by - 11, bw, 17, 4); ctx.fill();
  ctx.strokeStyle = e.barkRed ? 'rgba(255,86,66,0.85)' : 'rgba(240,178,110,0.55)';
  ctx.lineWidth = 1;
  roundRect(bx - bw/2, by - 11, bw, 17, 4); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(tx - 4, by + 6); ctx.lineTo(tx + 4, by + 6); ctx.lineTo(tx, by + 11);
  ctx.closePath(); ctx.fillStyle = 'rgba(12,16,22,0.86)'; ctx.fill();
  ctx.fillStyle = e.barkRed ? 'rgba(255,136,114,0.99)' : 'rgba(255,226,190,0.96)';
  ctx.fillText(e.bark, bx, by + 1);
  ctx.restore();
}

/* 说话气泡要画在 HUD 上面：不然小兵跒到屏幕左上角时，
   气泡会被左上那堆文字盖住。所以先记下来，等 HUD 画完再补上。 */
var _barkQueue = [];
function barkPush(e, alpha){ _barkQueue.push({e: e, a: alpha}); }
function barkFlush(){
  if (!_barkQueue.length) return;
  for (const q of _barkQueue) drawBark(q.e, q.a);
  _barkQueue.length = 0;
}

/* 人机说话：气泡挂在它自己头顶上，而不是屏幕中间 —— 你才知道是谁在喊 */
let barkCoolT = 0, barkLastOwner = null, barkLastAt = -99;
const MAX_SPEAKERS = 2;   /* 同屏最多两个人同时开口，再多就像菜市场 */
const VOICE_CD = 6.0;   /* 同一个小兵两句话之间至少隔这么久 */
function pickBark(arr){ return arr[Math.floor(Math.random() * arr.length)]; }
/* 人味：按状态从 data/voice.js 里抽一句台词。
   只有 humanOn(L) 为真的关卡（4-1 及以后新增的关卡）才会说；
   老关卡、割草、BOSS 关一个字都不会冒。 */
function voiceSay(e, key, chance, prio){
  if (e && e.dummy) return false;      /* 假人不喊话：他连"人"都不是 */
  if (!e || e.dead || e.hp <= 0) return false;
  /* 有自己台词组的类型（职业兵 tac）：别的情绪喊话一律换成术语，概率也换成它自己的 */
  const _VT = enemyType(e);
  if (_VT.voice && key !== _VT.voice && VOICE[_VT.voice]){
    key = _VT.voice;
    chance = (_VT.barkChance === undefined ? 0.3 : _VT.barkChance);
  }
  if (typeof VOICE === 'undefined' || !VOICE[key] || !VOICE[key].length) return false;
  if (!humanOn(cur())) return false;
  if ((e.voiceCd || 0) > 0) return false;                 /* 同一个人别念念叨叨 */
  if (chance !== undefined && chance !== null && Math.random() >= chance) return false;
  const arr = VOICE[key];
  /* 两个人同时开口时不要唱同一句（听着像回音）：碰上了就重抽，最多试四次 */
  let it = arr[Math.floor(Math.random() * arr.length)];
  let txt = (typeof it === 'string') ? it : (it && it.t);
  for (let _t = 0; _t < 4 && txt; _t++){
    let _dup = false;
    for (const _o of enemies){
      if (_o && _o !== e && _o.barkT > 0 && _o.bark === txt){ _dup = true; break; }
    }
    if (!_dup) break;
    it = arr[Math.floor(Math.random() * arr.length)];
    txt = (typeof it === 'string') ? it : (it && it.t);
  }
  if (!txt) return false;
  const red = (typeof it === 'string')
    ? !!(typeof VOICE_RED !== 'undefined' && VOICE_RED[key])
    : !!it.red;
  setBark(e, txt, 2.6, prio === undefined ? 2 : prio, red);
  if (e.barkT > 0) e.voiceCd = VOICE_CD;                   /* 没说出去（有人在说）就不算冷却 */
  return e.barkT > 0;
}
function setBark(e, txt, dur, prio, red){
  if (e && e.dummy) return;            /* 假人头顶只挂统计板，不挂台词 */
  if (!e || e.dead || e.hp <= 0) return;
  if (player && player.hp <= 0) return;      /* 玩家倒了，没人听得见他们叽叽 */
  const _bl = cur();
  /* 割草与 BOSS 关不说话：屏幕上已经很多字了，且那两种玩法不靠听声定位 */
  if (ar || (_bl && _bl.boss)) return;
  /* 全局节奏：同一时间只让一两个人开口，不然一群人一起喊就成了弹幕 */
  /* 同一时间只让一个人开口：屏幕上已经有人在说就不再加了 */
  let _speaking = 0;
  for (const _o of enemies){ if (_o && _o !== e && _o.barkT > 0) _speaking++; }
  if (_speaking >= MAX_SPEAKERS && !(e.barkT > 0)) return;
  /* 优先级：3 = 逃跑/发现尸体这种急事，2 = 战斗，1 = 闲聊。
     高优先级正在说的时候，低优先级不能把它顶掉 */
  const _p = prio || 1;
  if (e.barkT > 0 && (e.barkPrio || 1) > _p) return;
  e.bark = txt;
  e.barkT = dur || 2.0;
  e.barkMax = e.barkT;
  e.barkPrio = _p;
  e.barkRed = !!red;
  /* 记住开口那一刻的位置：气泡钉在原地，不跟着人跑 */
  e.barkX = e.x; e.barkY = e.y;
  /* 绝对到期（关卡时钟），防止 barkT 没被减到 0 时气泡赖在屏幕上 */
  e.barkUntil = ((typeof timeAlive === 'number') ? timeAlive : 0) + e.barkT + 0.35;
}

var lastFleeCallT = -99;
function woundedThreatAlive(e,t){
  return !!(t&&t!==e&&!t.dead&&!t.gone&&(t.hp===undefined||t.hp>0)&&
    (t!==player||!spectatorViewOn())&&factionWantsFight(e,t));
}
/* 负伤撤离不能再把“威胁”写死成玩家。优先沿用已锁定目标，并允许一个明显
   更近的敌对实体接管；18% 滞回避免两个人距离接近时每帧换方向。 */
function woundedThreatOf(e){
  let best=woundedThreatAlive(e,e.fleeThreat)?e.fleeThreat:null;
  const seen=(typeof enemyTargetEntity==='function')?enemyTargetEntity(e):null;
  if(woundedThreatAlive(e,seen)){
    if(!best||seen===best||e.sees||dist(e.x,e.y,seen.x,seen.y)<dist(e.x,e.y,best.x,best.y)*.82)best=seen;
  }
  const consider=t=>{
    if(!woundedThreatAlive(e,t))return;
    if(!best||dist(e.x,e.y,t.x,t.y)<dist(e.x,e.y,best.x,best.y)*.82)best=t;
  };
  consider(e.lastKnownSource);
  consider(player);
  if(typeof factionSpatialEach==='function')factionSpatialEach(e.x,e.y,620,consider,48);
  else for(const o of enemies)consider(o);
  if(best)e.fleeThreat=best;
  return best;
}
/* 一边跑一边喊人：附近听得见的都叫过来（效果同摄像头警报，只是范围小些） */
function fleeCallBackup(L, e, threat){
  if(!e || e.dead || behaviorOf(e).canCallBackup !== true)return 0;
  const target=woundedThreatAlive(e,threat)?threat:woundedThreatOf(e);
  if(!target)return 0;
  const ownFaction=combatFaction(e), laneCall=!!e.mobaRoute;
  const responders=[];
  let n = 0;
  for (const o of enemies){
    if (o === e || o.dead) continue;
    if (enemyType(o).static) continue;
    if (combatFaction(o)!==ownFaction || (laneCall && !mobaBackupFollower(e,o))) continue;
    if (dist(o.x, o.y, e.x, e.y) > 520) continue;
    if(!factionWantsFight(o,target))factionRememberThreat(o,target,FACTION_HATE_DEF.hitGain,FACTION_HATE_DEF.duration,target.x,target.y);
    if(!factionWantsFight(o,target))continue;
    o.mode = 1; o.heard = false; o.lookT = 0;
    o.alertT = Math.max(o.alertT || 0, CFG.eMemory + 6);
    o.lastKnown = {x: target.x + rand(-50,50), y: target.y + rand(-50,50)};
    o.lastKnownSource=target;o.heardSource=target;o.tgtCache=target;
    o.ang = Math.atan2(o.lastKnown.y - o.y, o.lastKnown.x - o.x);
    o.boostT = 4;
    responders.push(o);
    n++;
  }
  for (const h of hunters){
    if (!h || h.dead || dist(h.x, h.y, e.x, e.y) > 520) continue;
    if(combatFaction(h)!==ownFaction)continue;
    if(!factionWantsFight(h,target))factionRememberThreat(h,target,FACTION_HATE_DEF.hitGain,FACTION_HATE_DEF.duration,target.x,target.y);
    if(!factionWantsFight(h,target))continue;
    h.state = 'chase'; h.lastKnown = {x: target.x, y: target.y}; h.lastKnownSource=target;h.lostT = 0;
    n++;
  }
  if (n > 0 && (uiT - lastFleeCallT) > 2.5){
    lastFleeCallT = uiT;
    sfxAlarm();
    setBark(e, '有人趴了！过来！', 2.2, 3);
    for (const o of responders) setBark(o, '来了！', 1.6);
  }
  return n;
}

function finishWoundedFlee(e){
  e.fleeing=0;e.fleeGoal=null;e.fleeT=0;e.healK=0;e.fleeCd=6;
  e.fleeAge=0;e.fleeProgress=null;
  e.wait=.5;e.stuckT=0;e.path=null;e.goal=null;
}
/* 返回 true = 这一帧由撤离或治疗接管。 */
function updateWoundedFlee(L, e, dt){
  if (!e || e.dead || e.maxHp === undefined) return false;
  /* 被震懵的时候不会有意识地往掩体方向靠 */
  if (eStatusHas(e, 'stun')){ if(e.fleeing)finishWoundedFlee(e); return false; }   /* 没有血量的怪不参与 */
  if (e.boss) return false;        /* BOSS 没有"躲起来回血"这一说：只能打死它 */

  const HP_LOW = 0.35, HP_DONE = 0.9;
  if (!e.fleeing){
    e.fleeCd = Math.max(0, (e.fleeCd || 0) - dt);
    if (!(e.hp > 0) || e.hp > e.maxHp * HP_LOW || e.fleeCd > 0) return false;
  }
  const threat=woundedThreatOf(e);
  const fort=enemyIsFortification(threat)?threat:null;
  const threatPoint=fort ? {x:fort.x+fort.w/2,y:fort.y+fort.h/2} :
    (threat || (spectatorViewOn(L) ? null : player));

  if (!e.fleeing){
    /* 受到威胁时找更远的掩体。威胁已经消失时可以就地治疗。 */
    const goal = threatPoint ? pickHideSpot(L,e,0,false,threatPoint,{flee:true}) : {x:e.x,y:e.y};
    if (!goal) return false;
    e.fleeAge=0;e.fleeProgress=null;
    e.fleeing = 1; e.fleeGoal = goal; e.fleeT = 0; e.healK = 0; e.fleeAng = undefined;
    e.path = null; e.goal = null; e.pi = 0; e.stuckT = 0;
    e.lookT = 0; e.lastKnown = null; e.alertT = 0;
    e.mode = 0; e.heard = false; e.forceT = 0;
    logWarn('flee', '人机#' + ((enemies.indexOf(e)|0)+1) + ' 血只剩 ' + Math.round(e.hp) +
                    ' · 掉头找地方躲 ' + Math.round(goal.x) + ',' + Math.round(goal.y));
    fleeCallBackup(L,e,threat);            /* 一边跑一边喊人 */
  }

  e.sees = false;                      /* 跑路时背对着你，不会开枪 */
  e.fleeT = (e.fleeT || 0) + dt;
  e.fleeAge = (e.fleeAge || 0) + dt;

  const gx = e.fleeGoal ? e.fleeGoal.x : e.x, gy = e.fleeGoal ? e.fleeGoal.y : e.y;
  const far = dist(e.x, e.y, gx, gy);
  const nearYou0 = threatPoint ? dist(e.x,e.y,threatPoint.x,threatPoint.y) : Infinity;
  /* 当前敌对目标现在是不是能看见它（视野里 + 没被墙挡住）。看得见就绝不能蹲下打药。
     想蹲下来打药，要么中间隔着一面墙，要么离得足够远（600 以外）又不在视野里 ——
     不然就会出现"当着你的面原地回血"那种假戏。 */
  const walled = !threat || losBlocked(threatPoint.x,threatPoint.y,e.x,e.y,false,false,fort);
  /* 隔着一面墙就是安全位置，哪怕离得近 —— 你要绕过去才能打断它。
     没有墙的时候才要求"离你 600 以外"，不然就是当着你面回血。 */
  const threatSight=fort ? (!walled && nearYou0 < (fort.rocketTurret ? 900 : mgSentryDef().range)) :
    !!threat && (threat===player ? playerCanSeePoint(e.x,e.y) : npcSeesTarget(threat,e,false));
  const exposed = threatSight || (!walled && nearYou0 < 600);
  const unsafe=exposed||!!(threat&&nearYou0<210);
  if(unsafe && e.fleeAge>=DataWOUNDED_FLEE.escapeSeconds){finishWoundedFlee(e);return false;}
  // 到达掩体、等待重新寻路、打药被打断时也能还击，不只在移动分支里开枪。
  if (threat && !fort) specRetreatFire(e,dt,walled,nearYou0,threat);
  /* 跑不到位（绕不过去 / 被堵）就别死磕：蹲下打药 —— 但只在你看不见的时候 */
  if (far > 24 && (e.fleeT < 6 || unsafe)){
    e.healK=0;
    if(!e.fleeProgress)e.fleeProgress={x:e.x,y:e.y,t:0};
    const pos=e.fleeProgress;
    const a = navSteer(L, e, gx, gy, dt);
    /* 转向有速度上限：如果方向每帧翻一次，人就会在原地左右抖。
       限成 7 rad/s，看上去才是"掉头跑"，不是抽筋。 */
    const prev = (e.fleeAng === undefined) ? a : e.fleeAng;
    let da = normAng(a - prev);
    const maxTurn = dt * 7;
    if (da > maxTurn) da = maxTurn; else if (da < -maxTurn) da = -maxTurn;
    e.fleeAng = prev + da;
    /* fleeAng 是一路累加出来的，会慢慢飘出 ±π；不把它拉回 e.ang 这一圈，
       下面的 lerp 就会走长弧（从 3.1 绕到 -3.1 要转半圈），看上去就是原地打转。 */
    e.fleeAng += Math.round((e.ang - e.fleeAng) / TAU) * TAU;
    const mv = enemyType(e).kind === 'blade' ? a : e.fleeAng;
    /* 边撤边打：中间没墙、你还在射程内，就把「朝哪边看」从我逃跑方向换成你身上，
       但脚还是往 fleeAng 走 —— 所以是「退着打」，不是「停下转身」。
       注意朝向只在这一处限速（7 rad/s），别在下面再转一次，否则两段叠起来会像抽筋。 */
    const _pdNow2 = nearYou0;
    const _shootable = (behaviorOf(e).fleeFire || behaviorOf(e).retreatFire) &&
      !!threat&&!fort&&enemyType(e).canShoot&&!walled&&e.ammo>0&&e.reloading<=0&&_pdNow2<520;
    const _face2 = _shootable ? Math.atan2(threat.y-e.y,threat.x-e.x) : mv;
    /* 掉头限速 7 rad/s。以前限的是 fleeAng 再 lerp —— navSteer 只要一帧内把方向
       翻了半圈，lerp 就会一步甩过大半个圆，看着就是"原地打转"。现在直接限 e.ang
       每帧能转多少，不管目标怎么跳，它都只能是"慢慢掉头"。 */
    let _ad = normAng(_face2 - e.ang);
    const _tmax = dt * 7;
    if (_ad > _tmax) _ad = _tmax; else if (_ad < -_tmax) _ad = -_tmax;
    e.ang = normAng(e.ang + _ad);
    /* 逃跑速度也要吃减速：以前这里没乘 e.spdK，被炸晕之后照样按全速跑，
       眩晕只压住了「正常走路」，一进入残血逃跑就绕过了减速。 */
    const sp = CFG.eSpeed * behaviorOf(e).fleeSpdK * eMoveK(e);   /* 慌了比平时快一点，但眩晕照样慢 */
    const step = (enemyType(e).kind === 'blade' || enemyType(e).canShoot) ? Math.min(sp*dt,e.bladeNavDistance) : sp*dt;
    e.x += Math.cos(mv)*step;
    e.y += Math.sin(mv)*step;
    for (const w of collisionWalls(L,e.x,e.y,e.r)) pushOutCircle(e, e.r, w);
    for (const t of trucks) if (t.solid) pushOutTruckCircle(e, t);
    e.x = clamp(e.x, 14, L.w-14); e.y = clamp(e.y, 14, L.h-14);
    if(dist(pos.x,pos.y,e.x,e.y)>=12){
      pos.x=e.x;pos.y=e.y;pos.t=0;
    }else if((pos.t+=dt)>=DataWOUNDED_FLEE.stallSeconds){
      e.fleeProgress=null;
      if(unsafe){finishWoundedFlee(e);return false;}
      e.fleeGoal=null; // 实际已脱险，不用继续顶着走不到的目标。
    }
    /* 边撤边打：中间没墙就回头点一枪（人往后退，枪口朝你）。
       以前一进入逃跑就 e.sees = false 并且再也不扣扳机，看着就是「闷头挨打」。
       这里不拦它的脚步（方向还是 fleeAng），只把朝向慢慢转到你身上，
       转到位了才开枪 —— 所以是「退着打」，不是「停下转身」。 */
    if (_shootable && behaviorOf(e).fleeFire){
      const _fa = Math.atan2(threat.y-e.y,threat.x-e.x);
      e.fleeFireT = (e.fleeFireT || 0) - dt;
      if (e.fleeFireT <= 0 && Math.abs(normAng(_fa - e.ang)) < 0.40){
        e.blindShot = false;
        const _angKeep = e.ang;          /* 打归打，朝向还是交给上面那 7rad/s 的限速管 */
        const _ok = enemyFireWeapon(e,enemies.indexOf(e),undefined,undefined,threat);
        e.ang = _angKeep;
        if (_ok) e.fleeFireT = 0.55;
        else e.fleeFireT = 0.2;      /* 正对着墙：稍等一下再试 */
      }
    }
    return true;
  }

  /* 蹲住了：打药。血条就在头顶，能看见它一格一格往回涨 */
  /* 你一靠近就立刻打断，连药都不打完，爬起来接着跑 ——
     站着被你贴脸打死不叫"更智能"。
     触发两条：贴到 210 以内；或者它已经打了一会儿、而你正好转头看得见这个位置。 */
  const nearYou = nearYou0;
  /* 只在你确实看不见的地方打药 —— 当着你面回血是最假的一种演出。
     看得见就立刻打断，连那一口都不让它打完；贴到 210 以内也算被你堵住了。 */
  const inSight = threatSight;
  e.fleeProgress=null;
  if(unsafe)e.healK=0;
  if (unsafe && (inSight || nearYou < 210) && (uiT - (e.repathT || -99)) > 0.9){
    /* 现在蹲的这块地方拉黑 8 秒：不加这条，它会在两处一样好的掩体之间来回跳 */
    e.banned = e.banned || [];
    e.banned.push({x: e.x, y: e.y});
    if (e.banned.length > 5) e.banned.shift();
    e.banT = uiT + 10;
    /* 换的那处必须比你现在的距离再远 60px 以上：
       否则它只是在同一圈里左右换位置，看着就是"原地晃"。 */
    const g2 = pickHideSpot(L,e,nearYou+60,false,threatPoint);
    if (g2 && dist(g2.x, g2.y, e.x, e.y) > 60){
      e.repathT = uiT;
      e.fleeGoal = g2; e.fleeT = 0; e.healK = 0; e.path = null; e.goal = null;
      fleeCallBackup(L,e,threat);          /* 换个地方的时候也喊一嗓子 */
      return true;
    }
    /* 整张图都找不到你看不见的角落：别站着被你打，先朝背离你的方向跑 */
    const back = Math.atan2(e.y-threatPoint.y,e.x-threatPoint.x);
    e.repathT = uiT;
    e.fleeGoal = { x: clamp(e.x + Math.cos(back)*340, 30, L.w-30),
                   y: clamp(e.y + Math.sin(back)*340, 30, L.h-30) };
    e.fleeT = 0; e.healK = 0; e.path = null; e.goal = null;
    return true;
  }
  /* 到了地方却还露在你眼前：不算藏住了，接着跑（换点有 0.6 秒冷却，免得来回跳） */
  if (unsafe){
    e.healK = 0;
    if ((uiT - (e.repathT || -99)) > 0.6){
      e.banned = e.banned || [];
      e.banned.push({x: e.x, y: e.y});
      if (e.banned.length > 5) e.banned.shift();
      e.banT = uiT + 10;
      const g3 = pickHideSpot(L,e,nearYou0+80,false,threatPoint);
      e.repathT = uiT;
      e.fleeGoal = (g3 && dist(g3.x, g3.y, e.x, e.y) > 60) ? g3 : (function(){
        const back = Math.atan2(e.y-threatPoint.y,e.x-threatPoint.x);
        return { x: clamp(e.x + Math.cos(back)*380, 30, L.w-30),
                 y: clamp(e.y + Math.sin(back)*380, 30, L.h-30) };
      })();
      e.fleeT = 0; e.path = null; e.goal = null;
      fleeCallBackup(L,e,threat);
    }
    return true;              /* 这一帧也不打药，下一帧走接着跑那条分支 */
  }

  e.healK = (e.healK || 0) + dt;
  const targetHp=e.maxHp*HP_DONE;
  if(e.hp<targetHp)e.hp=Math.min(targetHp,e.hp+e.maxHp*DataWOUNDED_FLEE.healPerSecond*dt);
  if (e.hp >= targetHp || e.healK >= 6){
    finishWoundedFlee(e);
    logInfo('flee', '人机#' + ((enemies.indexOf(e)|0)+1) + ' 打完药 · 血回到 ' + Math.round(e.hp));
  }
  return true;
}

function updateTestZone(dt){
  const g = player.gun; if (!g) return;
  /* NaN 兜底：这些计时一旦变成 NaN，下面的 `<= 0` 永远不成立，换弹/装填就永远卡住 */
  if (!isFinite(g.cd)) g.cd = 0;
  if (!isFinite(g.reloading)) g.reloading = 0;
  if (!isFinite(g.reloadDur) || g.reloadDur <= 0) g.reloadDur = 1.0;
  if (!isFinite(g.shellT)) g.shellT = 0;
  if (!isFinite(g.shellPumpT)) g.shellPumpT = 0;
  if (!isFinite(g.shellDur) || g.shellDur <= 0) g.shellDur = 0.42;
  if (g.shelling && g.mag >= g.cap){ g.shelling = false; g.shellT = 0; }
  if (g.cd > 0) g.cd -= dt;
  /* 霰弹枪逐发装填：每一声都是真的往里塞了一颗 */
  if (g.shelling && g.kind !== 'throw' && (g.shellPumpT || 0) > 0){
    g.shellPumpT -= dt;
    if (g.shellPumpT <= 0){
      g.shellPumpT = 0;
      g.shellT = g.shellDur || 0.42;      /* 枪膀拉完，第一颗从这里开始计时 */
    }
  } else if (g.shelling && g.kind !== 'throw'){
    g.shellT -= dt;
    if (g.shellT <= 0){
      const _inf = (CFG.dev && CFG.devInfAmmo);
      const _pool = ammoOf(g);
      if (_inf || (_pool > 0 && g.mag < g.cap)){
        /* m32458「成排压弹」：霰弹枪一次往里塞 ar.shellBulk 发（1~6），
           别的枪不受影响；备弹不够、弹匣塞满都当场停手，不会多花子弹。 */
        const _bulk = ((typeof ar === 'object' && ar && ar.shellBulk && g.wid === 'shotgun')
          ? Math.max(1, Math.round(ar.shellBulk)) : 1);
        let _put = 0;
        for (let _i = 0; _i < _bulk; _i++){
          if (g.mag >= g.cap) break;
          if (!_inf){
            if (ammoOf(g) <= 0) break;
            g.mag += 1; spendAmmo(g.ammo, 1);
          } else {
            g.mag = Math.min(g.cap, g.mag + 1);
          }
          _put++;
        }
        if (_put > 0 && !sndPlay('gun.shotgun.load', 0.55)) sfxClickGun(false);
        const _done = (g.mag >= g.cap) || (!_inf && ammoOf(g) <= 0);
        if (_done){
          g.shelling = false; g.shellT = 0; g.cd = Math.max(g.cd, 0.12);
          logInfo('gun', '装填完成 · 弹匣 ' + g.mag + '/' + g.cap);
        } else {
          g.shellT = (gunDef(g).shellDur || 0.42) * ((ar && ar.reloadMul) ? ar.reloadMul : 1);
          g.shellDur = g.shellT;
        }
      } else {
        g.shelling = false; g.shellT = 0; g.cd = Math.max(g.cd, 0.10);
      }
    }
  }
  if (g.reloading > 0){
    g.reloading -= dt;
    if (g.reloading <= 0){
      g.reloading = 0;
      /* 火箭筒：从弹药池里一发一发装进膛，池子空了就只装得到几发 */
      if (g.rocket && ar){
        const _need = g.cap - g.mag;
        const _pool = arenaRocketLeft();
        const _take = Math.min(_need, _pool);
        g.mag += _take;
        ar.rwSpent = (ar.rwSpent | 0) + _take;
        sfxClickGun(true);
        if (!_take) setMsg('没有火箭弹了 · 每拿一张卡才多一发', 1.5);
        logInfo('gun', '火箭筒装填 ' + _take + ' 发 · 池里还剩 ' + (_pool - _take));
        return;
      }
      const need = g.cap - g.mag;
      if (CFG.dev && CFG.devInfAmmo){ g.mag = g.cap; sfxClickGun(true); return; }
      const pool = ammoOf(g);
      const take = Math.min(need, pool);
      g.mag += take;
      spendAmmo(g.ammo, take);
      sfxClickGun(true);
      logInfo('gun', '换弹完成 · 弹匣 ' + g.mag + ' · ' + ammoDef(g.ammo).label + ' 剩 ' + (pool - take));
    }
  }
}

/* 这些计时器以前是塞在 updateTestZone() 尾巴上的，而那个函数的头一行是
   `const g = player.gun; if (!g) return;` —— 于是「没有枪的关卡」里
   它们一帧都不推进：打药的进度条卡在 0%，刀手砍出来的红弧永远不消失，
   伤害数字永远挂在屏幕上。3-4 雨雾街头 weapons:[] 就是这么中的招。
   计时器是全局的，跟有没有枪无关，单独拎出来每帧都跑。 */
function updateTimers(dt){
  for (let i=dmgNums.length-1;i>=0;i--){ dmgNums[i].t += dt; if (dmgNums[i].t > 0.9) poolReleaseAt(dmgNums,i); }
  for (let i=hurtNums.length-1;i>=0;i--){ hurtNums[i].t += dt; if (hurtNums[i].t > 1.1) poolReleaseAt(hurtNums,i); }
  if (hurtStreakT > 0){ hurtStreakT -= dt; if (hurtStreakT <= 0) hurtStreakN = 0; }
  for (let i=tracers.length-1;i>=0;i--){ tracers[i].t += dt; if (tracers[i].t > tracers[i].dur + 0.06) tracers.splice(i,1); }
  for (let i=slashFx.length-1;i>=0;i--){ slashFx[i].t += dt; if (slashFx[i].t >= slashFx[i].dur) slashFx.splice(i,1); }
  for (let i=hurtArcs.length-1;i>=0;i--){ hurtArcs[i].t += dt; if (hurtArcs[i].t >= hurtArcs[i].dur) hurtArcs.splice(i,1); }
  const h = player.heal;
  updateCrateSearch(dt);              /* 战利品木箱的搜刮读条 */
  updateWires(dt);                    /* 铁丝网：谁站在网里、划伤 / 掉血 / 减速 */
  /* 推得动的小物件：先看玩家有没有顶上去，再让它们自己滑一小段、撞墙停下 */
  if (player && player.r && !player.seat && state === 'play'){
    const _pd = pushedDecorAt(player.x, player.y, player.r * 0.9);
    if (_pd){
      const _nx = (_pd.x + _pd.w * 0.5) - player.x, _ny = (_pd.y + _pd.h * 0.5) - player.y;
      const _nl = Math.hypot(_nx, _ny) || 1;
    /* 推的速度跟着玩家的**实际位移**走。
       别用 player.vx —— 玩家移动是直接改 x/y 的，根本没有 vx/vy（第 41 轮踩的坑：
       用 vx 算出来永远是 0，于是"怎么推都推不动"）。 */
    const _ppx = player._px == null ? player.x : player._px;
    const _ppy = player._py == null ? player.y : player._py;
    const _pd2 = playerMoveSpeed(dt);
      if (_pd2 > 5) pushDecor(_pd, _nx / _nl, _ny / _nl, _pd2);
    }
  }
  if (player){ player._px = player.x; player._py = player.y; }
  updatePushables(dt);
  updateRoofs(dt);        /* 屋顶：有人进屋就从 1 淡到 0（0.2 秒），没人再淡回来 */
  if (typeof updateWatchTower === 'function') updateWatchTower(dt);   /* 瞭望塔：钉位置 + 报点给队友 */
  if (h){
    h.t += dt;
    /* ---- 分段结算（m19010）：三段各回 1/3，最后一段补齐除不尽的零头 ---- */
    const _need = Math.max(1, h.need || 3);
    const _stage = h.dur / _need;
    const _want = Math.min(_need, Math.floor(h.t / _stage + 1e-9));
    while ((h.ticks || 0) < _want){
      h.ticks = (h.ticks || 0) + 1;
      if (player.hp <= 0 || dyingT > 0 || state !== 'play') break;
      /* 药真正打进身体的第一段：这时候才止血（原来一点药就止血） */
      if (h.ticks === 1 && (stBleedT > 0 || stBleedLv > 0)){ stBleedT = 0; stBleedLv = 0; setMsg('止血了', 1.0); }
      const _per = (h.ticks >= _need) ? ((h.amt || 0) - (h.per || 0) * (_need - 1)) : (h.per || 0);
      const _b0 = player.hp;
      player.hp = Math.min(ar ? arenaMaxHp() : CFG.hp, player.hp + Math.max(0, _per));
      const _got = Math.max(0, player.hp - _b0);
      h.healed = (h.healed || 0) + _got;
      if (_got > 0) setMsg('+' + Math.round(_got) + ' 血 · 第 ' + h.ticks + '/' + _need + ' 段', 1.0);
      /* 回满了就当场收手：剩下的耐久退回背包，不白烧 */
      if (player.hp >= (ar ? arenaMaxHp() : CFG.hp) - 0.001) break;
    }
    const _fullNow = (ar ? arenaMaxHp() : CFG.hp);
    if (h.t >= h.dur || player.hp >= _fullNow - 0.001){
      const d = MED_DEF[h.kind];
      const _amt = (h.amt || Math.round(d.amt * qualityK(h.q || 0)));
      const before = player.hp;
      player.heal = null;
      /* 血刚好在这 1 秒倒地窗口里流光了：药打上了就该把人拉回来。
         以前这里直接 hp = 0 + amt，人活了但 dyingT 还挂着 —— 动不了、却还能开枪（假死）。 */
      /* 人已经倒了就是倒了：药不再把人从地上拉回来（用户 m13074：死前打上药能原地复活） */
      if (player.hp <= 0 || dyingT > 0 || state !== 'play'){
        setMsg('人已经倒了 · 药没来得及', 1.4);
        logInfo('med', '倒地后药不再生效');
        return;
      }
      /* 血已经在每段里发过了，这里不再加，只报总数 */
      /* 按"实际回血 / 原始回血量"折算，没用完的耐久退回背包（回满才会剩） */
      const _useK = (h.amt > 0) ? Math.max(0, Math.min(1, (h.healed || 0) / h.amt)) : 1;
      const _leftDu = Math.round((h.du0 || 100) * (1 - _useK));
      if (_leftDu >= 1 && !(CFG.dev && CFG.devInfMed)){
        let _put = false;
        if (bagGridOn()) _put = bagAddMed(h.kind, h.q, _leftDu);
        else player.meds[h.kind] = (player.meds[h.kind] || 0) + 1;
        if (!_put && typeof bagLootFromItem === 'function') bagLootFromItem({ k:'med', r:h.kind, q:h.q, du:_leftDu });
      }
      const _tot = Math.round(player.hp - (h.hp0 == null ? before : h.hp0));
      setMsg(_leftDu >= 1 ? ('血回满了 · 共 +' + _tot + ' 点 · 药还剩 ' + _leftDu + '% 耐久') : ('药打完了 · 共 +' + _tot + ' 点血'), 1.7);
      logInfo('med', '用药完成 · 共 +' + _tot + ' HP · 剩 ' + Math.round(player.hp) + (_leftDu >= 1 ? (' · 退回耐久 ' + _leftDu + '%') : ''));
    }
  }
}

/* 有枪的关卡都要这三样：受伤敌人的血条、伤害数字、准星命中标记。
   fullBars = 测试区那种"全都亮"；正式关卡只在你打伤它之后才亮血条。 */
function drawCombatOverlay(fullBars){
  if (!hasFeat('guns')) return;
  /* 观战图：全员亮血条、不需要"看得见"，而且坐标要按缩放走（否则血条和人对不上） */
  const _crk = (typeof cricketOn === 'function' && cricketOn());
  if (_crk) fullBars = true;
  const _zk = (typeof crkZoomK === 'function') ? crkZoomK() : 1;
  const _sx = (typeof crkSX === 'function') ? crkSX : (x => x - cam.x);
  const _sy = (typeof crkSY === 'function') ? crkSY : (y => y - cam.y);
  ctx.save();
  for (const e of enemies){
    if (e.maxHp === undefined || e.dead) continue;
    if (!_crk && !fullBars && e.hp >= e.maxHp) continue;
    /* 身体都藏起来了，血条不能还飘在半空——那等于把位置报给你 */
    if (!_crk && !revealAll && !(CFG.dev && CFG.xray) && !playerCanSpot(e)) continue;
    const sx = _sx(e.x), sy = _sy(e.y);
    if (sx < -60 || sx > W+60 || sy < -60 || sy > H+60) continue;
    const w = 34, hh = 5, bx = sx - w/2, by = sy - (e.r || 12) * (_crk ? _zk : 1) - 14;
    const k = clamp(e.hp / e.maxHp, 0, 1);
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    ctx.fillRect(bx-1, by-1, w+2, hh+2);
    ctx.fillStyle = k > 0.55 ? 'rgba(110,210,120,0.95)' : (k > 0.25 ? 'rgba(235,190,80,0.95)' : 'rgba(230,80,60,0.95)');
    ctx.fillRect(bx, by, w*k, hh);
  }
  /* 伤害数字 */
  for (const d of dmgNums){
    const p = d.t / 0.9;
    const pop = d.crit ? (1 + 1.35*Math.exp(-d.t*17)) : (1 + 0.95*Math.exp(-d.t*20));
    ctx.save();
    ctx.globalAlpha = 1 - p*p;
    ctx.translate(_sx(d.x), _sy(d.y) - p*(d.crit ? 40 : 30) * _zk);
    ctx.scale(pop, pop);
    ctx.textAlign = 'center';
    ctx.font = 'bold ' + (d.crit ? 23 : 17) + 'px "Microsoft YaHei",sans-serif';
    ctx.lineWidth = d.crit ? 4.4 : 3.2;
    ctx.strokeStyle = d.crit ? 'rgba(60,32,0,0.75)' : 'rgba(18,8,4,0.62)';
    if (d.crit){ ctx.shadowColor = 'rgba(255,190,40,0.95)'; ctx.shadowBlur = 16; }
    ctx.strokeText('-' + d.val, 0, 0);
    ctx.fillStyle = d.crit ? '#ffe07a' : (d.kill ? '#ff8a4a' : '#ffd76a');
    ctx.fillText('-' + d.val, 0, 0);
    if (d.crit){
      ctx.shadowBlur = 8;
      ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = '#fff2c0';
      ctx.fillText('暴击', 0, -20);
    }
    ctx.restore();
  }
  /* 自己挨的伤害：红色、大一号，黑描边保证任何底色都读得清 */
  for (const h of hurtNums){
    const p = h.t / 1.1;
    const pop = 1 + 0.9 * Math.exp(-h.t * 16);
    ctx.save();
    ctx.globalAlpha = 1 - p * p;
    ctx.translate(_sx(h.x), _sy(h.y) - p * 42 * _zk);
    ctx.scale(pop, pop);
    ctx.textAlign = 'center';
    ctx.font = 'bold 20px "Microsoft YaHei",sans-serif';
    ctx.lineWidth = 4.2;
    ctx.strokeStyle = 'rgba(24,0,0,0.78)';
    ctx.shadowColor = 'rgba(255,60,50,0.75)';
    ctx.shadowBlur = 12;
    const txt = '-' + Math.round(h.val);
    ctx.strokeText(txt, 0, 0);
    ctx.fillStyle = '#ff6a5a';
    ctx.fillText(txt, 0, 0);
    ctx.restore();
  }
  ctx.restore();
  drawHitMark();                                  /* 准星上的命中标记（屏幕空间） */
}

/* 测试区：血条全开（保留这个名字，老调用点不用改） */
/* 玩家挨打时冒一个数字。0.22 秒内的连续伤害并成一个（霰弹一枪打 6 颗也不会刷屏） */
function hurtNum(dmg){
  if (!CFG.showHurt || !(dmg > 0.4)) return;
  const v = Math.round(dmg);
  const last = hurtNums[hurtNums.length - 1];
  if (last && last.t < 0.22){ last.val += v; last.t = 0; last.pop = 1; return; }
  /* 错开一点，连挨几下时不会两串数字叠成一个 */
  const jx = (Math.random() - 0.5) * 34, jy = (hurtNums.length % 3) * 12;
  spawnHurtNum(player.x + jx, player.y - 24 - jy, v);
  if (hurtNums.length > 12) poolReleaseAt(hurtNums, 0);
}

function drawTestOverlay(){ drawCombatOverlay(true); }

function drawTestHUD(){
  if (!isTestZone()) return;
  const g = player.gun;
  if (!g){
    ctx.save();
    ctx.textAlign = 'left';
    ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = THEME_LIGHT ? 'rgba(150,90,60,0.95)' : 'rgba(240,160,120,0.95)';
    ctx.fillText('空手 · 地上有枪可以捡', 24, 170);
    ctx.fillStyle = THEME_LIGHT ? 'rgba(60,76,92,0.8)' : 'rgba(150,168,184,0.85)';
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText(keyLabel(BINDS.medSmall) + '/' + keyLabel(BINDS.medBig) + ' 用药 · ' +
                 keyLabel(BINDS.cancel) + ' 取消 · ' + keyLabel(BINDS.bag) + ' 背包', 24, 194);
    ctx.restore();
    return;
  }
  const ink = THEME_LIGHT ? 'rgba(30,40,52,0.95)' : 'rgba(226,236,244,0.95)';
  const dim = THEME_LIGHT ? 'rgba(60,76,92,0.8)'  : 'rgba(150,168,184,0.85)';
  ctx.save();
  ctx.textAlign = 'left';
  /* 左边已经有血条/电量/烟雾/脚步四行，从 150 开始，别压上去 */
  let y = 170;
  ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = ink;
  ctx.fillText(g.kind === 'melee'
    ? (g.name + '　近战 · 挥砍间隔 ' + g.rof.toFixed(2) + ' 秒')
    : (g.tool
      ? (g.name + '\u3000' + (binoK() > 0.02
          ? ('看远 ×' + binoRangeK().toFixed(2) + ' · 画面 ' + Math.round(binoZoomK() * 100) + '%')
          : '未举起') +
         '\u3000按住左键举起 · 视野收窄但看得更远')
      : (g.name + '　' + (playerTruck ? '机枪接管中 · 左键开火' : ('弹匣 ' + g.mag + ' / ' + g.cap)) + '　' +
         ammoDef(g.ammo).label + ' ×' + (ar ? '∞' : ammoOf(g)) +
         (g.pellets > 1 ? '　每发 ' + g.pellets + ' 弹丸' : ''))), 24, y);
  y += 12;
  /* 弹匣空了、背包里只有别的口径：明说一句，免得玩家以为换弹坏了 */
  if (!ar && ammoOf(g) <= 0 && ammoLabelOf(g.ammo)){
    const _oth = bagAmmoSummary(g.ammo);
    if (_oth){
      ctx.font = '12px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = 'rgba(242,158,116,0.98)';
      ctx.fillText('背包里只有 ' + _oth + '　口径对不上 · ' + keyLabel(BINDS.swap) + ' 换枪', 24, y + 12);
      y += 24;
    }
  }
  if (g.reloading > 0){
    const p = 1 - g.reloading / Math.max(0.01, (g.reloadDurNow || g.reloadDur));
    ctx.fillStyle = 'rgba(235,190,80,0.28)';
    ctx.fillRect(24, y, 150, 8);
    ctx.fillStyle = 'rgba(235,190,80,0.95)';
    ctx.fillRect(24, y, 150*clamp(p,0,1), 8);
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(235,190,80,0.95)';
    ctx.fillText('换弹 ' + g.reloading.toFixed(1) + 's', 182, y + 8);
    y += 22;
  } else if (player.heal){
    const d = MED_DEF[player.heal.kind];
    const p = clamp(player.heal.t / player.heal.dur, 0, 1);
    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.fillRect(24, y, 150, 8);
    ctx.fillStyle = d.bg;
    ctx.fillRect(24, y, 150*p, 8);
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = d.bg;
    ctx.fillText(d.label + ' ' + Math.round(p*100) + '%　X 取消', 182, y + 8);
    y += 22;
  } else {
    y += 8;
  }
  /* 药品两格：格子只做底和边，药包本体交给 drawMedModel */
  let bx = 24;
  const by = y + 6;
  for (const k of ['small','big']){
    const d = MED_DEF[k], n = player.meds[k] || 0;
    ctx.globalAlpha = n > 0 ? 1 : 0.32;
    ctx.fillStyle = THEME_LIGHT ? 'rgba(210,206,196,0.45)' : 'rgba(255,255,255,0.05)';
    roundRect(bx, by, 22, 22, 5); ctx.fill();
    ctx.strokeStyle = d.bg; ctx.lineWidth = 1.2;
    roundRect(bx + 0.6, by + 0.6, 20.8, 20.8, 5); ctx.stroke();
    drawMedModel(bx + 11, by + 12, 0.72, k, {shadow:false});
    ctx.textAlign = 'left';
    ctx.fillStyle = n > 0 ? ink : dim;
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText(d.label + ' ×' + n + '　(' + (k === 'small' ? '1' : '2') + ')', bx + 28, by + 16);
    ctx.globalAlpha = 1;
    bx += 116;
  }
  /* 投掷物：手里拿着的和背包里的都算；手雷和烟雾弹各一行，拿哪种哪种亮 */
  if (nadeCount() > 0){
    drawNadeModel(bx + 11, by + 12, 0.62, 0, player.hand === 'nade', 'nade');
    ctx.textAlign = 'left';
    ctx.fillStyle = ink;
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('手雷 ×' + nadeCount() + '　按 ' + keyLabel(BINDS.throwToggle) + ' 拿在手上', bx + 28, by + 16);
    bx += 150;
  }
  if (smokeCount() > 0){
    drawNadeModel(bx + 11, by + 12, 0.62, 0, player.hand === 'smoke', 'smoke');
    ctx.textAlign = 'left';
    ctx.fillStyle = ink;
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('烟雾弹 ×' + smokeCount() + '　按 ' + keyLabel(BINDS.throwToggle) + ' 拿在手上', bx + 28, by + 16);
    bx += 150;
  }
  /* 万能钥匙：捡到就在 HUD 上挂一枚，免得走到锁门才发现没带 */
  if (keyCount() > 0){
    drawKeyIcon(bx + 11, by + 12, 0.62);
    ctx.textAlign = 'left';
    ctx.fillStyle = ink;
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText('万能钥匙　走到锁门按 ' + keyLabel(BINDS.interact) + ' 开（无限开）',
                 bx + 28, by + 16);
  }
  ctx.fillStyle = dim;
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText('左键 开枪 · ' + keyLabel(BINDS.reload) + ' 换弹 · ' + keyLabel(BINDS.swap) +
               ' 换枪 · ' + keyLabel(BINDS.medSmall) + '/' + keyLabel(BINDS.medBig) +
               ' 用药 · ' + keyLabel(BINDS.cancel) + ' 取消 · ' +
               keyLabel(BINDS.bag) + ' 背包 · ' + keyLabel(BINDS.panel) + ' 设置', 24, by + 46);
  ctx.restore();
}

function invSlots(){
  const out = [];
  const g = player.gun;
  if (g) out.push({kind:'gun'});
  /* 子弹按种类一格一格排，捡到哪种子弹就多一格 */
  for (const t of AMMO_ORDER){
    const n = (player.ammo && player.ammo[t]) || 0;
    if (n > 0) out.push({kind:'ammo', ammo:t, n:n});
  }
  if ((player.meds.small||0) > 0) out.push({kind:'med', rarity:'small', n:player.meds.small});
  if ((player.meds.big||0) > 0) out.push({kind:'med', rarity:'big', n:player.meds.big});
  return out;
}

function invInfo(it){
  const g = player.gun;
  if (it.kind === 'gun') return {
    title:(g ? g.name : GUN_DEF.name), tag:'装备', col:'rgba(150,190,220,0.95)',
    lines:['伤害 ' + (g ? g.dmg : GUN_DEF.dmg) +
           (g && g.pellets > 1 ? ' ×' + g.pellets + ' 弹丸' : '') +
           ' · 射速 ' + (1/(g ? g.rof : GUN_DEF.rof)).toFixed(1) + ' 发/秒',
           '弹匣 ' + (g ? g.mag : 0) + ' / ' + (g ? g.cap : GUN_DEF.cap) +
           '　' + ammoDef(g ? g.ammo : 'pistol').label + ' ' + (g ? ammoOf(g) : 0),
           '换弹 ' + (g ? g.reloadDur : GUN_DEF.reloadDur) + ' 秒',
           '左键开枪 · R 换弹 · F 换枪',
           'G 丢下（走过去能捡回来）']
  };
  if (it.kind === 'ammo'){
    const A = ammoDef(it.ammo);
    return {
      title:A.label, tag:'弹药', col:A.pal,
      lines:['存量 ×' + it.n,
             '地上捡弹药箱，每个 +' + A.box + ' 发',
             '只有吃这种子弹的枪能用，别捡错了']
    };
  }
  const d = MED_DEF[it.rarity];
  return {
    title:d.label, tag:d.tier, col:d.bg,
    lines:['存量 ×' + it.n,
           '回复 ' + d.amt + ' 点生命',
           '用时 ' + d.dur + ' 秒',
           '按 ' + (it.rarity === 'small' ? '1' : '2') + ' 使用',
           '用药时移速降到 30%，不会被打断',
           '按 X 取消，药退回包里']
  };
}

/* 有枪的正式关卡：屏幕左下一条武器栏。
   测试区那整块开发者面板不往正式关卡里搬 —— 那边要的是调试信息，这边要的是"还剩几发"。 */
const _COMBAT_WEAPON_HUD_VIEW={};
function combatWeaponHudView(gun,reloadKey,result){
  const melee=gun.kind==='melee';
  result.warn=gun.reloading>0||gun.mag<=Math.ceil(gun.cap*0.25);
  let line=melee?(gun.name + '\u3000\u8fd1\u6218 \u00b7 \u6325\u780d ' + gun.rof.toFixed(2) + ' \u79d2'):(gun.name + '\u3000' + gun.mag + ' / ' + gun.cap);
  if(!melee){
    if(gun.shelling&&(gun.shellPumpT||0)>0)line+='\u3000\u62c9\u67aa\u8180\u2026';
    else if(gun.shelling)line+='\u3000\u88c5\u586b\u4e2d\u2026 \u70b9\u5de6\u952e\u53ef\u6253\u65ad';
    else if(gun.reloading>0)line+='\u3000\u6362\u5f39\u4e2d\u2026';
    else if(gun.mag<=0)line+='\u3000\u6309 ' + keyLabel(reloadKey) + ' \u6362\u5f39';
  }
  result.label=line;
  return result;
}
const _COMBAT_AMMO_HUD_VIEW={};
function combatAmmoHudView(gun,inArena,swapKey,reloadKey,result){
  const reserve=inArena?(gun.rocket?String(arenaRocketLeft()):'∞'):ammoOf(gun);
  const swap=keyLabel(swapKey);
  result.label=ammoLabelOf(gun.ammo) + ' ×' + reserve + '　' + swap + ' 换枪　' + keyLabel(reloadKey) + ' 换弹';
  const other=!inArena&&reserve<=0?bagAmmoSummary(gun.ammo):'';
  result.mismatch=other?'背包里只有 ' + other + '　口径对不上 · ' + swap + ' 换枪':'';
  return result;
}
function drawCombatHUD(){
  const g = player.gun;
  let _hintY = 0;   /* 口径不对提示占用的行位，0 = 没有 */
  ctx.save();
  /* 在车上：左下那栏让位给顶置机枪的弹链，别显示一把你现在打不出去的枪 */
  if (playerTruck){ ctx.restore(); return; }
  ctx.textAlign = 'left';
  const ink   = THEME_LIGHT ? 'rgba(26,36,46,0.95)' : 'rgba(232,240,248,0.95)';
  const dim   = THEME_LIGHT ? 'rgba(70,86,102,0.85)' : 'rgba(150,168,184,0.9)';
  const warn  = THEME_LIGHT ? 'rgba(170,60,30,0.98)'  : 'rgba(240,140,90,0.98)';
  if (g && g.kind === 'throw'){
    ctx.font = 'bold 16px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = g.mag > 0 ? ink : warn;
    ctx.fillText(g.name + '　×' + g.mag, 24, 180);
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = dim;
    ctx.fillText('左键扔出去 · 烟里谁也看不见谁　' + keyLabel(BINDS.swap) + ' 换枪', 24, 200);
  } else if (g && g.tool){
    const _bk = binoK();
    ctx.font = 'bold 16px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = ink;
    ctx.fillText(g.name + '\u3000' + (_bk > 0.02
      ? ('看远 ×' + binoRangeK().toFixed(2) + ' · 画面 ' + Math.round(binoZoomK() * 100) + '%')
      : '未举起'), 24, 180);
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = dim;
    ctx.fillText('\u6309\u4f4f\u5de6\u952e\u4e3e\u8d77 \u00b7 \u753b\u9762\u62c9\u8fdc \u00b7 \u89c6\u91ce\u6536\u7a84\u4f46\u770b\u5f97\u66f4\u8fdc\u3000' + keyLabel(BINDS.swap) + ' 换枪', 24, 200);
  } else if (g){
    const weapon = combatWeaponHudView(g,BINDS.reload,_COMBAT_WEAPON_HUD_VIEW);
    ctx.font = 'bold 16px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = weapon.warn ? warn : ink;
    ctx.fillText(weapon.label, 24, 180);
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = dim;
    const ammo = combatAmmoHudView(g,!!ar,BINDS.swap,BINDS.reload,_COMBAT_AMMO_HUD_VIEW);
    ctx.fillText(ammo.label, 24, 200);
    /* 包里全是别的口径：单独占一行（以前写在 196，正好压在 200 那行上） */
    if (ammo.mismatch){
      _hintY = 222;
      ctx.font = '12px "Microsoft YaHei",sans-serif';
      ctx.fillStyle = warn;
      ctx.fillText(ammo.mismatch, 24, _hintY);
    }
  } else {
    ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = warn;
    ctx.fillText('空手 · 地上有枪可以捡', 24, 180);
  }
  /* 药：割草模式没有打药（捡到就回血），这行不占地方 */
  const md = player.meds || {small:0, big:0};
  if (!ar){
    ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillStyle = dim;
    /* 手雷只写一次：之前"手雷 ×N / 烟 ×M"和后面那句"手雷 ×N [3 拿在手上]"重复，整行挤成一团 */
    const _throwLine = '手雷 ×' + nadeCount() + ' / 烟 ×' + smokeCount() +
      ' [' + keyLabel(BINDS.throwToggle) + ' 切 ' + keyLabel(BINDS.throwSwap) + ' 换]';
    ctx.fillText('小药 ×' + (md.small||0) + ' [' + keyLabel(BINDS.medSmall) + ']' +
                 '　绿药包 ×' + (md.big||0) + ' [' + keyLabel(BINDS.medBig) + ']' +
                 '　' + _throwLine +
                 (keyCount() > 0 ? '　万能钥匙（无限开，不消耗）' : ''), 24, _hintY ? 244 : 222);
  }

  /* 受伤提示：只在开了 healHint 的关卡、真的掉到六成血以下时出现，几秒后自己消失 */
  if (player.hintT > 0 && !player.heal){
    const hpMax = CFG.hp;
    const small = (md.small || 0) > 0, big = (md.big || 0) > 0;
    const low = player.hp < hpMax * 0.6;
    if (low && (small || big)){
      const pulse = 0.72 + 0.28 * Math.sin(uiT * 6);
      ctx.globalAlpha = Math.min(1, player.hintT) * pulse;
      ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = THEME_LIGHT ? 'rgba(160,52,26,0.98)' : 'rgba(255,196,132,0.98)';
      const key = small ? keyLabel(BINDS.medSmall) : keyLabel(BINDS.medBig);
      const nm  = small ? '小药' : '绿药包';
      ctx.fillText('血不多了 —— 按 ' + key + ' 用' + nm, W/2, H - 172);
      ctx.textAlign = 'left';
      ctx.globalAlpha = 1;
    }
  }
  ctx.restore();
}

/* 换弹进度：屏幕中下、比血条还粗的一道，谁都能一眼看到 */
function drawReloadBar(){
  const g = player && player.gun;
  if (!g || g.kind === 'throw') return;
  const _shell = !!g.shelling;
  if (!(g.reloading > 0) && !_shell) return;
  const _pump = _shell ? (g.shellPumpT || 0) : 0;
  const p = _shell
    ? (_pump > 0
        ? clamp(1 - _pump / Math.max(0.01, (g.shellPumpDur || SHELL_PUMP_T)), 0, 1)
        : clamp(1 - g.shellT / Math.max(0.01, (g.shellDur || 0.42)), 0, 1))
    : clamp(1 - g.reloading / Math.max(0.01, (g.reloadDurNow || g.reloadDur)), 0, 1);
  const bw = 320, bh = 16;
  const bx = Math.round(W/2 - bw/2), by = Math.round(H/2 + 92);
  ctx.save();
  ctx.fillStyle = 'rgba(8,12,18,0.78)';
  roundRect(bx - 4, by - 4, bw + 8, bh + 8, 7); ctx.fill();
  ctx.strokeStyle = 'rgba(235,190,80,0.55)'; ctx.lineWidth = 1.2;
  roundRect(bx - 3.5, by - 3.5, bw + 7, bh + 7, 7); ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.12)';
  roundRect(bx, by, bw, bh, 5); ctx.fill();
  const gg = ctx.createLinearGradient(bx, 0, bx + bw, 0);
  gg.addColorStop(0, 'rgba(255,214,120,0.95)');
  gg.addColorStop(1, 'rgba(255,246,200,0.98)');
  ctx.fillStyle = gg;
  roundRect(bx, by, Math.max(3, bw * p), bh, 5); ctx.fill();
  ctx.textAlign = 'center';
  ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = 'rgba(255,240,205,0.98)';
  ctx.fillText((_shell ? ((g.shellPumpT || 0) > 0 ? '拉枪膀… ' : '装填中 ' + g.mag + '/' + g.cap + ' · ') : '换弹中 ')
    + Math.round(p * 100) + '%', W/2, by + bh + 18);
  ctx.textAlign = 'left';
  ctx.restore();
}

function drawHealBar(){
  const h = player && player.heal;
  if (!h) return;
  const d = MED_DEF[h.kind] || { label: '', bg: '#7fd4ff' };
  const p = clamp(h.t / h.dur, 0, 1);
  const bw = 240, bh = 12;
  const bx = Math.round(W/2 - bw/2), by = Math.round(H/2 + 64);
  ctx.save();
  ctx.fillStyle = 'rgba(8,12,18,0.72)';
  roundRect(bx - 3, by - 3, bw + 6, bh + 6, 5); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.14)';
  roundRect(bx, by, bw, bh, 4); ctx.fill();
  ctx.fillStyle = d.bg;
  roundRect(bx, by, Math.max(2, bw * p), bh, 4); ctx.fill();
  ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(214,232,248,0.96)';
  ctx.fillText((d.label || '') + ' ' + Math.round(p * 100) + '%', bx + bw/2, by - 7);
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(210,226,240,0.85)';
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillText('正在用药 · X 取消', bx + bw/2 - 44, by + bh + 15);
  ctx.restore();
}

/* 背包面板的几何/拖拽状态（面板代码里到处用，先声明好） */
let invGridGeom = null;
let bagIconRotOverride = null;      /* 只给拖拽预览用：临时按指定朝向画图标（0/1 或 null=按 it.rot） */
let bagSlotRect = null, shieldSlotRect = null, heatSlotRect = null;
let gunSlotRects = [null, null, null];
let attSlotRects = [null, null, null];

/* ---------- 背包面板用的小工具（ver2 / ver3 共用） ---------- */
/* 悬停说明的统一出口：先拿原来那段（title/tag/col/lines），
   再补一行"这东西是干嘛的"。这一行来自 data/lootkinds.js 的 brief ——
   新增物资只改数据文件就会自动出现在这里，不用再回来加文案。 */
function bagItemInfo(it){
  const d = bagItemInfoCore(it);
  if (d && it && it.k){
    const br = (typeof lootBrief === "function") ? lootBrief(it.k) : "";
    if (br && d.lines.indexOf(br) < 0) d.lines = d.lines.concat([br]);
  }
  return d;
}

function bagItemLabel(it){
  if (!it) return '东西';
  if (it.k === 'med') return (MED_DEF[it.r] && MED_DEF[it.r].label) || '药';
  if (it.k === 'ammo') return (ammoDef(it.t || 'pistol').label) + ' ×' + (it.n | 0);
  if (it.k === 'smoke') return '烟雾弹';
  if (it.k === 'armor') return (typeof armorDef === 'function' && armorDef(it.ak) && armorDef(it.ak).label) || '防弹衣';
  if (it.k === 'bag') return (bagDef(it.bk || 'small') || {}).label || '背包';
  if (it.k === 'shield') return '防弹盾牌';
  if (it.k === 'thermal') return '热成像';
  if (it.k === 'key') return '万能钥匙';
  if (it.k === 'nade') return '手雷';
  if (it.k === 'heatcell') return '热成像电池';
  if (it.k === 'rope') return '绳子';
  if (it.k === 'tripwire') return '绊雷';
  return '东西';
}

function bagItemInfoCore(it){
  if (!it) return { title:'', tag:'', col:'rgba(200,180,150,0.9)', lines:[] };
  /* m35945：简介里的按键一律跟着玩家的自定义绑定走，不再写死 V / 3 / Q / X / R / G */
  const _K = function(name, def){ return (typeof keyLabel === 'function' && typeof BINDS !== 'undefined' && BINDS[name]) ? keyLabel(BINDS[name]) : def; };
  const _K_THROW = _K('throwToggle', '3'), _K_SWAP = _K('throwSwap', 'Q');
  const _K_SMALL = _K('medSmall', '1'), _K_BIG = _K('medBig', '2');
  const _K_RELOAD = _K('reload', 'R'), _K_PICK = _K('interact', 'E');
  const _K_SHIELD = _K('shield', 'G'), _K_MED = _K('med', 'X');
  const _K_THERM = _K('thermal', '空格');
  if (it.k === 'rope'){
    return { title:'绳子', tag:'材料', col:'rgba(214,190,140,0.95)',
      lines:['占 1×1 格', '拖到手雷上 = 合成绊雷', 'Shift + 拖 = 只换位置，不合成'] };
  }
  if (it.k === 'tripwire'){
    return { title:'绊雷', tag:'可布设', col:'rgba(226,146,96,0.95)',
      lines:['左键点格子开始布设（A 点 → 走到另一边放 B 点）',
             '最长 ' + (typeof TRIP_MAX_LEN === 'number' ? TRIP_MAX_LEN : 160) + ' px · 右键 / Esc 取消',
             '敌人踩到 0.5 秒后爆炸', '你自己踩不炸 · 右键解开成绳子和手雷'] };
  }
  if (it.k === 'med'){
    const d = MED_DEF[it.r] || MED_DEF.small;
    const _qq = (it.q === undefined ? 0 : it.q);
    const _du = (typeof medDuOf === 'function') ? medDuOf(it) : 100;
    const _k = qualityK(it.q === undefined ? 0 : it.q);
    return { title:qualityPrefix(_qq) + d.label, tag:'耐久 ' + _du + '%', col:qualityCol(_qq),
      lines:['点格子 或 按 ' + (it.r === 'big' ? _K_BIG : _K_SMALL) + ' 使用（' + _K_MED + ' 取消）',
             '这一颗最多回 ' + Math.round(d.amt * _k * _du / 100) + ' 血（读条 ' + (d.dur * _du / 100).toFixed(1) + ' 秒）',
             '血差多少用多少，回满当场停', '占 1×1 格，不能叠放'] };
  }
  if (it.k === 'ammo'){
    const A = ammoDef(it.t || 'pistol');
    if ((it.t || '') === 'rocket'){
      return { title:A.label, tag:'弹药', col:A.pal,
        lines:['这一条 ' + ((it.n | 0) || 1) + ' 发', '占 2×1 格', '按 ' + _K_RELOAD + ' 换弹（火箭筒）'] };
    }
    return { title:A.label, tag:'弹药', col:A.pal,
      lines:['这一盒 ' + (it.n | 0) + ' 发（一格 ' + AMMO_PER_CELL + ' 发）', '占 1×1 格',
             '按 ' + _K_RELOAD + ' 换弹，直接从盒子里扣'] };
  }
  if (it.k === 'smoke'){
    return { title:'烟雾弹', tag:'投掷', col:'rgba(180,210,230,0.95)',
      lines:['按 ' + _K_THROW + ' 拿到手上（' + _K_SWAP + ' 换手雷 / 烟雾弹）',
             '左键扔出去，挡住敌人的视线', '占 1×1 格'] };
  }
  if (it.k === 'nade'){
    return { title:'手雷', tag:'投掷', col:'rgba(198,206,150,0.95)',
      lines:['按 ' + _K_THROW + ' 拿到手上（' + _K_SWAP + ' 换手雷 / 烟雾弹）',
             '按住左键掐引信（最长 3 秒），松手扔出', '撞墙会反弹', '占 1×1 格，一颗一格'] };
  }
  if (it.k === 'heatcell'){
    return { title:'热成像电池', tag:'耗材', col:'rgba(255,178,96,0.95)',
      lines:['一格最多叠 ' + HEATCELL_STACK + ' 颗（现在 ' + ((it.n | 0) || 1) + ' 颗）',
             '点格子换电，' + BAT_SWAP_DUR + ' 秒充满', '已满电时不会浪费',
             '只有新关卡和死亡地带能搜到'] };
  }
  if (it.k === 'armor'){
    const A = (typeof armorDef === 'function' && armorDef(it.ak)) || { label:'防弹衣', reduce:0, pal:'rgba(200,180,150,0.95)' };
    return { title:(A.label || '防弹衣'), tag:'防弹衣', col:A.pal,
      lines:['耐久 ' + Math.round(it.hp) + ' / ' + Math.round(it.maxHp) + ' · 减伤 ' + Math.round((A.reduce||0)*100) + '%',
             '拖到护甲框 = 换上', '占 3×3 格'] };
  }
  if (it.k === 'bag'){
    const B = bagDef(it.bk || 'small');
    return { title:(B.label || '背包'), tag:'背包', col:'rgba(210,186,140,0.95)',
      lines:['随身 ' + ((B.slots | 0) + 0) + ' 格（占 2×3 格）', '拖到左边背包栏 = 换上',
             '换小包时塞不下的会掉在脚边'] };
  }
  if (it.k === 'thermal'){
    return { title:'热成像', tag:'装备', col:'rgba(255,178,96,0.95)',
      lines:['电量 ' + heatPct(thermalPower(it).battery) + '%', '拖到左边「热成像」栏 = 戴上',
             '戴上后按 ' + _K_THERM + ' 开机 / 再按一下关机'] };
  }
  if (it.k === 'key'){
    return { title:'万能钥匙', tag:'钥匙', col:'rgba(228,180,78,0.95)',
      lines:['走到锁着的门边按 ' + _K_PICK + ' = 开锁', '无限次，不消耗', '占 1×1 格'] };
  }
  if (it.k === 'attach'){
    const A = (typeof attachDef === 'function' && attachDef(it.aid)) || null;
    if (!A) return { title:'枪械配件', tag:'配件', col:'rgba(200,180,150,0.95)', lines:[] };
    const fits = (A.fits || []).map(w => (WEAPONS[w] && WEAPONS[w].name) || w).join(' / ');
    const slotName = (typeof attachSlotName === 'function') ? attachSlotName(A.slot) : '配件';
    /* 数值说明全部由数据表里的 mods 自动翻译，加新数值类型不用改这里 */
    const lines = attachLines(A);
    if (A.notes && A.notes.length) for (const n of A.notes) lines.push(n);
    lines.unshift('只能装：' + (fits || '任意'));
    lines.push('拖到武器栏 = 装上，点小槽 = 取下');
    return { title:A.name, tag: slotName + '配件', col:'rgba(196,168,116,0.95)', lines:lines };
  }
  if (it.k === 'rare'){
    return { title:'金条', tag:'值钱', col:'rgba(244,206,102,0.96)',
      lines:['抽奖商人收 450（押注按这个算）', '占 2×1 格 · 可直接拖出面板丢掉',
             '不算撤离物资件数'] };
  }
  if (it.k === 'shield'){
    return { title:'防弹盾牌', tag:'装备', col:'rgba(180,210,235,0.95)',
      lines:['耐久 ' + Math.round(player.shieldHp || 0) + ' / ' + (SHIELD_MAX_HP || 600),
             _K_SHIELD + ' 举盾 / 收盾 · ' + _K_SWAP + ' 收盾切枪', '拖到面板外面 = 丢在地上'] };
  }
  return { title:bagItemLabel(it), tag:'', col:'rgba(200,180,150,0.9)', lines:[] };
}

/* 把一件背包物品画进格子里：用真实的 LOOT_KINDS 画法，缩放塞进 box */
const BAG_NAT = { med:34, ammo:26, smoke:26, armor:20, bag:22, shield:22, thermal:24, key:24, nade:26, heatcell:22, attach:24, rare:30 };
function bagDrawItemIcon(it, cx, cy, box){
  if (!it) return;
  const K = LOOT_KINDS[it.k];
  if (!K || !K.draw) return;
  /* 配件不同款式画出来大小差很多（短枪口 / 长弹匣），自然尺寸写在数据表里，
     否则背包只按格子算缩放，弹匣会斜着戳出 1×1 格子 */
  const nat = (it.k === 'attach' && typeof attachNat === 'function')
    ? attachNat(it.aid)
    : (BAG_NAT[it.k] || 26);
  const cap = it.k === 'armor' ? 6.2 : (it.k === 'bag' ? 6.0 : 3.2);
  /* 火箭弹是 2×1 的横条，按"卡片宽度"来放，用短边算会缩成一小块 */
  const _rocketAmmo = (it.k === 'ammo' && it.t === 'rocket');
  /* 金条也是 2×1 的横条：按短边算会缩成一小块，跟火箭弹一样按卡片宽度放大 */
  const _wideCard = _rocketAmmo || it.k === 'rare';
  const _cap = _wideCard ? 3.5 : cap;
  /* 转过 90° 的那件卡片变窄了，同样的 box 会显得小一圈，放大一点填满 */
  const _rot = (bagIconRotOverride === null) ? !!it.rot : !!bagIconRotOverride;
  const _box = _rot ? box * 1.06 : box;
  const _rocketK = _wideCard ? (_rot ? 1.0 : 1.42) : 1;
  let s = clamp((_box * _rocketK) / nat, 0.5, _cap);
  /* 兜个底：图标画出来的长边不许超过卡片（斜放 + 放大容易戳出去） */
  s = Math.min(s, (box + 6) / nat * 1.9) * (it.k === 'attach' ? 0.82 : 1);
  ctx.save();
  if (_rot){                         /* 转过 90° 的：图标也跟着转，长边对上卡片长边 */
    ctx.translate(cx, cy);
    ctx.rotate(Math.PI / 2);
    ctx.translate(-cx, -cy);
  }
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  const l = { kind:it.k, rarity:it.r, ammo:it.t };
  if (it.k === 'attach') l.aid = it.aid || null;
  if (it.k === 'ammo'){ l.ammo = it.t; l.n = it.n; }
  if (it.k === 'smoke'){ l.n = it.n; }
  if (it.k === 'heatcell'){ l.n = it.n; }
  if (it.k === 'armor'){ l.armor = it.ak; l.hp = it.hp; l.maxHp = it.maxHp; }
  if (it.k === 'bag'){ l.bag = it.bk; }
  if (it.k === 'med'){ l.rarity = it.r; }
  try {
    if (it.k === 'attach' && typeof drawAttachIcon === 'function') drawAttachIcon(0, 0, 1, l.aid);
    else K.draw(0, 0, l);
  } catch (e) {}
  ctx.restore();
  /* 药包耐久：永远画在格子底部中间（满耐久也画，用户要求一眼能看）
     做法是压一条半透明底条，所以在浅色药包图标上也读得清 */
  if (it.k === 'med'){
    const _du = (typeof medDuOf === 'function') ? medDuOf(it) : 100;
    const _txt = Math.round(_du) + '%';
    ctx.save();
    ctx.font = (typeof fonts === 'function' ? fonts('tiny') : '10px sans-serif');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const _tw = ctx.measureText(_txt).width;
    const _bh = Math.max(10, box * 0.17);
    const _by = cy + box * 0.5 - _bh - 5;
    ctx.fillStyle = 'rgba(6,8,12,0.72)';
    ctx.fillRect(cx - _tw / 2 - 3, _by, _tw + 6, _bh);
    ctx.fillStyle = _du <= 34 ? 'rgba(255,150,120,0.99)' : (_du <= 66 ? 'rgba(255,214,140,0.98)' : 'rgba(232,238,244,0.96)');
    ctx.fillText(_txt, cx, _by + _bh * 0.52);
    ctx.restore();
  }
}

/* 把身上那件护甲换下来（拖到护甲框时用） */
function bagWearArmor(it, take = bagRemoveItem){
  const A = (typeof armorDef === 'function') ? armorDef(it.ak) : null;
  if (!A) return false;
  const old = player.armor;
  if (!take(it)) return false;
  player.armor = { kind:it.ak, label:A.label, hp:it.hp, maxHp:it.maxHp, reduce:A.reduce, q:(it.q || 0) };
  if (!(typeof sfxArmorWear === 'function' && sfxArmorWear())) sfxPick();
  if (old){
    const rec = bagAddArmor(old.kind, old.hp, old.maxHp);
    if (!rec) bagLootFromItem({ k:'armor', ak:old.kind, hp:old.hp, maxHp:old.maxHp });
  }
  bagRebuild();
  setMsg('换上 ' + A.label + '（旧的' + (old ? '放进背包' : '') + '）', 1.8);
  return true;
}

/* 戴上热成像：背包里那件消失，改成"穿在身上" */
function bagWearThermalItem(it, take = bagRemoveItem){
  if (player.heatWorn){ setMsg('已经戴着一台了', 1.4); return false; }
  if (!it || it.k !== 'thermal') return false;
  if (!take(it)) return false;
  bagRebuild();
  thermalSetWorn(it);
  if (!(typeof sfxBagPlace === 'function' && sfxBagPlace())) sfxPick();
  setMsg('戴上热成像 · 空格开机（随时可以关）', 2.2);
  logInfo('item', '戴上热成像');
  return true;
}
/* 摘下热成像：塞回背包；塞不下就不摘 */
function bagRemoveThermal(){
  if (!player.heatWorn) return false;
  const rec = bagAddCell('thermal', thermalPower(player));
  if (!rec){ setMsg('背包里没位置放热成像（要 1×2 空格）', 1.7); return false; }
  thermalSetWorn(null);
  bagRebuild();
  setMsg('摘下热成像 · 收进背包', 1.8);
  return true;
}

/* ---------- 装备槽（护甲 / 背包 / 盾牌 / 热成像）拖出拖入 ---------- */
function bagEquipItem(eq){
  if (eq === 'armor') return player.armor ? player.armor : null;
  if (eq === 'bag') return (player.bag && player.bag.kind !== 'none') ? player.bag : null;
  if (eq === 'shield') return player.hasShield ? { hp:player.shieldHp } : null;
  if (eq === 'thermal') return player.heatWorn ? { k:'thermal', eq:'thermal', uid:-4, w:GRID_W.thermal, h:GRID_H.thermal, ...thermalPower(player) } : null;
  return null;
}

function bagDropEquipped(eq){
  if (eq === 'armor'){
    if (!player.armor) return false;
    const a = player.armor;
    player.armor = null;
    bagLootFromItem({ k:'armor', ak:a.kind, hp:a.hp, maxHp:a.maxHp });
    setMsg('把护甲丢在了地上', 1.6);
    return true;
  }
  if (eq === 'bag'){
    if (!player.bag || player.bag.kind === 'none') return false;
    const kind = player.bag.kind;
    player.bag = Object.assign({}, BAG_NONE);
    bagLootFromItem({ k:'bag', bk:kind });
    bagRefit();
    setMsg('把背包丢在了地上（只剩口袋 4 格）', 2.0);
    return true;
  }
  if (eq === 'shield'){
    if (!player.hasShield) return false;
    return dropPlayerShield();
  }
  if (eq === 'thermal'){
    if (!player.heatWorn) return false;
    bagLootFromItem({ k:'thermal', ...thermalPower(player) });
    thermalSetWorn(null);
    setMsg('把热成像丢在了地上', 1.7);
    logInfo('item', '丢下热成像');
    return true;
  }
  return false;
}
