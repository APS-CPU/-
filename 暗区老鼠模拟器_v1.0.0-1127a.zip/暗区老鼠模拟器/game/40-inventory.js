
/* 把装备塞回格子里的 (tx,ty) 位置；塞不下就返回 false */
function bagUnequipToGrid(eq, tx, ty){
  const it = bagEquipItem(eq);
  if (!it) return false;
  if (eq === 'armor'){
    if (!bagFreeAt(bagOcc(null), GRID_W.armor, GRID_H.armor, tx, ty)) return false;
    bagItems().push({ uid:_bagUid++, k:'armor', ak:it.kind, hp:it.hp, maxHp:it.maxHp, x:tx, y:ty, w:GRID_W.armor, h:GRID_H.armor });
    player.armor = null;
    bagRebuild();
    return true;
  }
  if (eq === 'bag'){
    const rec = bagAddCell('bag', { bk:it.kind, x:tx, y:ty });
    if (!rec) return false;
    player.bag = Object.assign({}, BAG_NONE);
    bagRefit();
    return true;
  }
  if (eq === 'thermal'){
    if (!bagFreeAt(bagOcc(null), GRID_W.thermal, GRID_H.thermal, tx, ty)) return false;
    bagItems().push({ uid:_bagUid++, k:'thermal', x:tx, y:ty, w:GRID_W.thermal, h:GRID_H.thermal, ...thermalPower(player) });
    thermalSetWorn(null);
    bagRebuild();
    return true;
  }
  return false;
}

/* ---------- 拖拽 ---------- */
function bagDragStart(rec, mx, my){
  if (!rec || !rec.it) return false;
  const it = rec.it;
  if (it.w == null) it.w = GRID_W[it.k] || 1;
  if (it.h == null) it.h = GRID_H[it.k] || 1;
  /* from:'bag' 是给"落点判定"用的：以前这里不写 from，货斗那边只认 from==='bag'，
     于是真实点击永远走不到装车分支（只能直接调 bagDragDrop 的测试能过，实机点不动）。 */
  ui.inv.drag = { it:it, from:'bag', cellRec:rec, ox:mx - rec.x, oy:my - rec.y, sx:mx, sy:my };
  ui.inv.selUid = it.uid || 0;
  return true;
}

/* 体积置换：把 it 放到 (tx,ty)，被它压住的 A、B…再重新排进腾出来的空间。
   全程在虚拟网格上预演：成功才真的改坐标，失败一个格子都不动。
   规则（用户定的）：同尺寸直接换；不同尺寸只要总面积装得下就换；
   拼不出形状（碎片化）就拒绝。 */
function bagTrySwap(it, tx, ty){
  if (!it) return false;
  const g = bagGridSize();
  const w = it.w || GRID_W[it.k] || 1, h = it.h || GRID_H[it.k] || 1;
  if (tx < 0 || ty < 0 || tx + w > g.w || ty + h > g.h) return false;
  /* 一件东西要么整个在背包区，要么整个在口袋行 */
  const inBag = (ty + h <= g.bh && tx + w <= g.bw);
  const inPocket = (ty >= g.bh && ty + h <= g.bh + g.ph && tx + w <= g.pw);
  if (!inBag && !inPocket) return false;
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++)
    if (!bagCellOk(tx + i, ty + j, g)) return false;

  /* 目标区域压住了谁 */
  const hit = [];
  for (const o of bagItems()){
    if (o === it) continue;
    if (o.x + o.w <= tx || tx + w <= o.x) continue;
    if (o.y + o.h <= ty || ty + h <= o.y) continue;
    hit.push(o);
  }
  if (!hit.length) return false;              /* 没压到东西就不叫置换 */

  /* 虚拟网格：先把它和这些被压住的都拿下来，再把 it 摆到目标位置 */
  const occ = bagOcc(it);
  for (const o of hit) for (let j = 0; j < o.h; j++) for (let i = 0; i < o.w; i++){
    const xx = o.x + i, yy = o.y + j;
    if (occ[yy] && occ[yy][xx] === o) occ[yy][xx] = null;
  }
  const put = (o, x, y) => {
    for (let j = 0; j < o.h; j++) for (let i = 0; i < o.w; i++) occ[y + j][x + i] = o;
  };
  put(it, tx, ty);

  /* 被换下来的：大的先放。先试自己的原位，再试它原来那块地（it 腾出来的），最后全图找。 */
  const ox0 = it.x, oy0 = it.y, ow = it.w || w, oh = it.h || h;
  const inOld = (x, y, ww, hh) => x >= ox0 && y >= oy0 && x + ww <= ox0 + ow && y + hh <= oy0 + oh;
  const order = hit.slice().sort((a, b) => (b.w * b.h) - (a.w * a.h));
  const plan = [];
  for (const o of order){
    let pos = null;
    if (bagFreeAt(occ, o.w, o.h, o.x, o.y)) pos = { x: o.x, y: o.y };
    if (!pos){
      for (let y = oy0; y + o.h <= oy0 + oh && !pos; y++) for (let x = ox0; x + o.w <= ox0 + ow && !pos; x++)
        if (inOld(x, y, o.w, o.h) && bagFreeAt(occ, o.w, o.h, x, y)) pos = { x: x, y: y };
    }
    if (!pos){
      for (let y = 0; y + o.h <= g.h && !pos; y++) for (let x = 0; x + o.w <= g.w && !pos; x++)
        if (bagFreeAt(occ, o.w, o.h, x, y)) pos = { x: x, y: y };
    }
    if (!pos) return false;                   /* 拼不出来 = 拒绝，什么都不改 */
    put(o, pos.x, pos.y);
    plan.push({ o: o, x: pos.x, y: pos.y });
  }

  /* 预演全部通过，落地 */
  it.x = tx; it.y = ty;
  for (const q of plan){ q.o.x = q.x; q.o.y = q.y; }
  return true;
}

/* 把背包里的一件东西转 90°（横的 2×1 ↔ 竖的 1×2）。
   就位放不下 → 试体积置换 → 试附近空位 → 都不行就转回来。 */
function bagRotateItem(it){
  if (!it || it.eq) return false;
  if (it.w === it.h) return false;                 /* 正方形转了没意义 */
  const w0 = it.w, h0 = it.h, r0 = it.rot || 0;
  it.w = h0; it.h = w0; it.rot = r0 ? 0 : 1;
  if (bagFreeAt(bagOcc(it), it.w, it.h, it.x, it.y)){ it.rotManual = 1; return true; }
  if (bagTrySwap(it, it.x, it.y)){ it.rotManual = 1; return true; }
  const spot = bagSpot(it.w, it.h, it);
  if (spot){ it.x = spot.x; it.y = spot.y; it.rotManual = 1; return true; }
  it.w = w0; it.h = h0; it.rot = r0;               /* 放不下就还原 */
  return false;
}

/* 一件东西"本来"的朝向（没被转过的时候） */
function bagNatWH(it){
  if (!it) return { w:1, h:1 };
  if (it.k === 'ammo'){ const c = ammoCellSize(it.t || 'pistol'); return { w: c.w, h: c.h }; }
  return { w: GRID_W[it.k] || it.w || 1, h: GRID_H[it.k] || it.h || 1 };
}

/* 把 it 放到 (tx,ty)：先按当前方向试空位、试体积置换；不行就原地转 90° 再试一遍。
   成功返回 true（可能已经把这件转过了），失败返回 false 且什么都不改。 */
function bagPlaceAt(it, tx, ty){
  if (!it) return false;
  const w0 = it.w, h0 = it.h, r0 = it.rot || 0;
  /* 上次是被自动转过的话，先试试能不能转回"本来的朝向"——
     玩家想横着放的时候不该被上一次的自动旋转绑架（R 手动转过的除外） */
  if (!it.rotManual){
    const nat = bagNatWH(it);
    if ((nat.w !== w0 || nat.h !== h0) && nat.w !== nat.h){
      it.w = nat.w; it.h = nat.h; it.rot = 0;
      if (bagFreeAt(bagOcc(it), it.w, it.h, tx, ty) || bagTrySwap(it, tx, ty)){
        it.x = tx; it.y = ty; it.rotManual = 0;
        return true;
      }
      it.w = w0; it.h = h0; it.rot = r0;
    }
  }
  if (bagFreeAt(bagOcc(it), w0, h0, tx, ty)){ it.x = tx; it.y = ty; return true; }
  if (bagTrySwap(it, tx, ty)) return true;
  if (w0 !== h0){
    it.w = h0; it.h = w0; it.rot = r0 ? 0 : 1;
    if (bagFreeAt(bagOcc(it), it.w, it.h, tx, ty) || bagTrySwap(it, tx, ty)){
      it.x = tx; it.y = ty; it.rotManual = 0;
      return true;
    }
    it.w = w0; it.h = h0; it.rot = r0;
  }
  return false;
}

/* 只预演不改动：这块地方能不能放下（含自动转向 / 体积置换），高亮和 ghost 用 */
function bagProbe(it, tx, ty){
  if (!it) return null;
  const keep = bagItems().map(o => ({ o:o, x:o.x, y:o.y, w:o.w, h:o.h, rot:o.rot || 0 }));
  const w0 = it.w, h0 = it.h, r0 = it.rot || 0;
  let out = null;
  try {
    if (!it.rotManual){
      const nat = bagNatWH(it);
      if ((nat.w !== w0 || nat.h !== h0) && nat.w !== nat.h){
        it.w = nat.w; it.h = nat.h; it.rot = 0;
        if (bagFreeAt(bagOcc(it), it.w, it.h, tx, ty)) out = { mode:'free', rot:0 };
        else if (bagTrySwap(it, tx, ty)) out = { mode:'swap', rot:0 };
        it.w = w0; it.h = h0; it.rot = r0;
      }
    }
    if (out) { /* 已经能放下，直接返回 */ }
    else if (bagFreeAt(bagOcc(it), w0, h0, tx, ty)) out = { mode:'free', rot:r0 };
    else if (bagTrySwap(it, tx, ty)) out = { mode:'swap', rot:r0 };
    else if (w0 !== h0){
      it.w = h0; it.h = w0; it.rot = r0 ? 0 : 1;
      if (bagFreeAt(bagOcc(it), it.w, it.h, tx, ty)) out = { mode:'free', rot:it.rot };
      else if (bagTrySwap(it, tx, ty)) out = { mode:'swap', rot:it.rot };
    }
  } catch (e){ out = null; }
  for (const q of keep){ q.o.x = q.x; q.o.y = q.y; q.o.w = q.w; q.o.h = q.h; q.o.rot = q.rot; }
  it.w = w0; it.h = h0; it.rot = r0;
  return out;
}

/* 拖多格物品时，鼠标不一定正好落在它应占的左上格。
   先在光标附近按距离找真正的空位，并同时尝试横/竖两个方向；这样右边只剩
   一条竖缝时，横放的火箭弹会直接吸过去转成 1×2，而不是先去挤动别的物品。 */
function bagSmartCells(tx, ty, radius = 2){
  const out = [];
  for (let dy = -radius; dy <= radius; dy++) for (let dx = -radius; dx <= radius; dx++){
    out.push({ x:tx + dx, y:ty + dy, d:Math.abs(dx) + Math.abs(dy), dx, dy });
  }
  out.sort((a, b) => a.d - b.d || Math.abs(a.dy) - Math.abs(b.dy) || a.dx - b.dx || a.dy - b.dy);
  return out;
}
function bagSmartDirs(it){
  const cur = { w:it.w || 1, h:it.h || 1, rot:it.rot || 0 };
  const dirs = [];
  const add = d => { if (!dirs.some(q => q.w === d.w && q.h === d.h)) dirs.push(d); };
  if (!it.rotManual){
    const nat = bagNatWH(it);
    if (nat.w !== cur.w || nat.h !== cur.h) add({ w:nat.w, h:nat.h, rot:0 });
  }
  add(cur);
  if (cur.w !== cur.h) add({ w:cur.h, h:cur.w, rot:cur.rot ? 0 : 1 });
  return dirs;
}
function bagSmartFreeProbe(it, tx, ty){
  if (!it) return null;
  const occ = bagOcc(it), cells = bagSmartCells(tx, ty), dirs = bagSmartDirs(it);
  for (const p of cells) for (const d of dirs){
    if (bagFreeAt(occ, d.w, d.h, p.x, p.y))
      return { mode:'free', x:p.x, y:p.y, w:d.w, h:d.h, rot:d.rot };
  }
  return null;
}
/* 预览和放手沿用同一个抓取点，并读取光标下的实际格子。 */
function bagDragTarget(gx, gy, cell, gap, cols, rows, drag){
  const step = cell + gap;
  const px = mouse.x - gx, py = mouse.y - gy;
  return {
    x:Math.round((px - drag.ox) / step), y:Math.round((py - drag.oy) / step),
    hoverX:Math.floor(px / step), hoverY:Math.floor(py / step),
    overGrid:px >= 0 && py >= 0 && px <= cols * step - gap && py <= rows * step - gap
  };
}
function bagSmartPreferExact(it, tx, ty, target){
  /* 挪动后仍压着原占格时，优先尝试置换。否则原位置可能被当作附近空位吸回去。 */
  const dx = Math.abs(tx - it.x), dy = Math.abs(ty - it.y);
  const overlapsOrigin = (dx > 0 || dy > 0) && dx < it.w && dy < it.h;
  if (overlapsOrigin || it.k === 'armor') return true;
  const hx = target?.hoverX, hy = target?.hoverY;
  const pointsIntoFootprint = hx >= tx && hx < tx + it.w && hy >= ty && hy < ty + it.h;
  return bagItems().some(o => o !== it && (
    (o.x === tx && o.y === ty && o.w === it.w && o.h === it.h) ||
    (pointsIntoFootprint && hx >= o.x && hx < o.x + o.w && hy >= o.y && hy < o.y + o.h)
  ));
}
function bagSmartProbe(it, tx, ty, target){
  if (bagSmartPreferExact(it, tx, ty, target)){
    const exact = bagProbe(it, tx, ty);
    if (exact) return { ...exact, x:tx, y:ty };
  }
  const free = bagSmartFreeProbe(it, tx, ty);
  if (free) return free;
  /* 附近确实没有空位，才退回原有的体积置换。 */
  for (const p of bagSmartCells(tx, ty)){
    const q = bagProbe(it, p.x, p.y);
    if (q) return { ...q, x:p.x, y:p.y };
  }
  return null;
}
function bagSmartPlace(it, tx, ty, target){
  if (bagSmartPreferExact(it, tx, ty, target) && bagPlaceAt(it, tx, ty)) return true;
  const p = bagSmartFreeProbe(it, tx, ty);
  if (p){
    const turned = p.w !== it.w || p.h !== it.h;
    it.x = p.x; it.y = p.y; it.w = p.w; it.h = p.h; it.rot = p.rot;
    if (turned) it.rotManual = 0;
    return true;
  }
  for (const q of bagSmartCells(tx, ty)) if (bagPlaceAt(it, q.x, q.y)) return true;
  return false;
}

/* 只问"能不能置换"，不改任何东西（拖动高亮用）。真正的置换是 bagTrySwap。 */
function bagSwapPossible(it, tx, ty){
  if (!it) return false;
  const keep = bagItems().map(o => ({ o: o, x: o.x, y: o.y }));
  let ok = false;
  try { ok = bagTrySwap(it, tx, ty); } catch (e){ ok = false; }
  for (const q of keep){ q.o.x = q.x; q.o.y = q.y; }
  return ok;
}

/* null 表示没有命中对应装备栏，false 表示命中但无法装备。 */
function bagEquipAtPointer(it, take){
  const G = invGridGeom;
  if (!G || it.eq) return null;
  if (it.k === 'armor' && G.armSlot && inRect(G.armSlot)) return bagWearArmor(it, take);
  if (it.k === 'bag' && G.bagSlot && inRect(G.bagSlot)) return bagWearBag(it, take);
  /* 电池拖到「热成像」格 = 给这台机器换电（倒计时，电池留在包里） */
  if (it.k === 'heatcell' && G.heatSlot && inRect(G.heatSlot)) return heatCellBeginSwap(it);
  if (it.k === 'thermal' && G.heatSlot && inRect(G.heatSlot)) return bagWearThermalItem(it, take);
  if (it.k === 'shield' && G.shieldSlot && inRect(G.shieldSlot)){
    if (player.hasShield){ setMsg('先卸下身上的盾牌', 1.4); return false; }
    return (take || bagRemoveItem)(it) && LOOT_KINDS.shield.take({...it, shieldHp:it.shieldHp ?? it.hp});
  }
  if (it.k === 'attach'){
    const index = (G.gunSlots || []).findIndex(slot => slot && inRect(slot));
    if (index >= 0) return bagAttachToGun(it, index, take);
  }
  return null;
}

function bagDragDrop(shift = false){
  const it = ui.inv.drag && ui.inv.drag.it;
  if (!it) return '';
  const dx = mouse.x - ui.inv.drag.sx, dy = mouse.y - ui.inv.drag.sy;
  const moved = Math.abs(dx) + Math.abs(dy) > 6;
  const G = invGridGeom;
  const res = (function(){
    if (!G) return '';
    const drag = ui.inv.drag;
    const truck = inventoryCargoTruck();
    if (drag.from === 'cargo'){
      if (!truck) return '';
      const equipped = bagEquipAtPointer(it, item => cargoRemoveCell(truck, item));
      if (equipped !== null) return equipped ? 'wear' : '';
    }
    /* 原地点一下药 = 直接吃（要先判，否则会被下面的"落在同一格"吃掉） */
    if (drag.from !== 'cargo' && !moved && it.k === 'med' && !it.eq){ useMed(it.r || 'small'); return 'use'; }
    /* 点一下电池 = 立刻充满热成像（满电时不浪费） */
    if (drag.from !== 'cargo' && !moved && it.k === 'heatcell' && !it.eq){ return bagUseHeatCell(it) ? 'use' : ''; }
    /* 点一下绊雷 = 开始布设（右键是解开，在 16-frag 里处理） */
    if (drag.from !== 'cargo' && !moved && it.k === 'tripwire' && !it.eq){
      if (typeof tripStartPlace === 'function' && tripStartPlace(it)) return 'use';
    }
    /* 点一下身上那台热成像 = 摘下来放回包里 */
    if (!moved && it.eq === 'thermal'){ return bagRemoveThermal() ? 'move' : ''; }
    const inPanel = mouse.x >= G.px && mouse.x <= G.px + G.pw && mouse.y >= G.py && mouse.y <= G.py + G.ph;
    /* ---- 货斗（背包面板右栏，Tab 站在民用皮卡旁边才出现） ----
       以前这里没有任何分支：拖到货斗上既不算"落在格子里"、也不算"面板外"，
       于是直接被 return '' 吞掉 —— 玩家只看到东西弹回原地，像是没反应。
       接上以后：背包 → 货斗 = 装车；货斗 → 背包格 = 拿回来；货斗 → 面板外 = 丢地上。 */
    const _dg = ui.inv.drag;
    const hasCargo = !!inventoryCargoTruck();
    if (_dg.from === 'cargo' && !hasCargo) return '';
    if (hasCargo){
      const _CR = G.cargo || (typeof cargoBagGeom !== 'undefined' ? cargoBagGeom : null);
      const _overCargo = !!_CR && mouse.x >= _CR.x - 8 && mouse.x <= _CR.x + _CR.w + 8 &&
                                  mouse.y >= _CR.y - 8 && mouse.y <= _CR.y + _CR.h + 8;
      const _overBagGrid = mouse.x >= G.gx && mouse.x <= G.gx + G.cols * (G.cell + G.gap) &&
                           mouse.y >= G.gy && mouse.y <= G.gy + G.rows * (G.cell + G.gap);
      if (_dg && _dg.from === 'cargo'){
        if (_overCargo) return '';                                  /* 放回货斗：不动 */
        if (_overBagGrid) return cargoBagTakeOut(_dg.cellRec);       /* 拿回背包 */
        if (!inPanel) return cargoBagDropOut(_dg.cellRec);           /* 丢地上 */
        return '';
      }
      if (_overCargo){
        /* 身上穿着的防弹衣 / 热成像也允许直接拖进货斗：先卸下、再装车（cargoPutEquipped 负责）。 */
        if (it.eq){
          if (typeof cargoPutEquipped === 'function' && typeof cargoOpenTruck !== 'undefined' &&
              cargoPutEquipped(cargoOpenTruck, it)) return 'move';
          setMsg('先卸下来再装车', 1.6);
          return '';
        }
        return cargoBagPut(it);
      }
    }
    /* 松手在面板外：丢在地上 */
    if (!inPanel){
      if (it.eq) return bagDropEquipped(it.eq) ? 'drop' : '';
      bagDropItem(it);
      setMsg('丢在地上：' + bagItemLabel(it), 1.6);
      return 'drop';
    }
    /* 拖到另一件东西上：绳子 + 手雷 = 绊雷（一次只消耗这两件） */
    if (!it.eq && (it.k === 'rope' || it.k === 'nade')){
      const _tgt = (typeof bagItemAtPoint === 'function') ? bagItemAtPoint(mouse.x, mouse.y) : null;
      if (_tgt && _tgt !== it){
        /* 按住 Shift = 我只想跟它换个位置，别合成 */
        const _shift = shift || !!(keys.ShiftLeft || keys.ShiftRight);
        if (!_shift && typeof bagCraftTripwire === 'function' && bagCraftTripwire(it, _tgt)){
          setMsg('合成绊雷 · 只换位置请按住 Shift 拖', 2.2);
          return 'move';
        }
      }
    }
    const equipped = bagEquipAtPointer(it);
    if (equipped !== null) return equipped ? 'wear' : '';
    /* 拖到格子 = 挪位置（装备则是卸下来） */
    const cols = G.cols, rows = G.rows, cell = G.cell, gap = G.gap;
    const target = bagDragTarget(G.gx, G.gy, cell, gap, cols, rows, drag);
    const {x:cx0, y:cy0} = target;
    if (target.overGrid){
      if (it.eq){
        if (bagUnequipToGrid(it.eq, cx0, cy0)) return 'move';
        return '';
      }
      if (bagSmartPlace(it, cx0, cy0, target)) return 'move';
      setMsg('空间不足 · 换不了位置', 1.5);
    }
    /* 原地点一下：药直接吃 */
    return '';
  })();
  ui.inv.drag = null;
  if (bagGridOn()) bagCompactAmmo();
  /* 落地音：装备/穿戴由各自流程发声，这里只给"挪位置/互换/卸进格子"补一声轻响 */
  if (res === 'move' && typeof sfxBagPlace === 'function') sfxBagPlace();
  return res;
}

/* ---- 配件：装到某一把枪上（把那件从背包里拿掉；换下来的旧配件回包里） ---- */
/* 配件让弹匣变小的时候，多的子弹掉脚边还给玩家（不能凭空蒸发） */
function gunReturnRounds(g, n){
  if (!player || !g || !(n > 0)) return 0;
  const t = g.ammo || 'pistol';
  if (typeof bagLootFromItem === 'function') bagLootFromItem({ k:'ammo', t:t, n:n });
  setMsg('弹匣变小了 · 多的 ' + n + ' 发' + (typeof ammoDef === 'function' ? ammoDef(t).label : '') + '掉在脚边', 2.6);
  logInfo('item', '配件换装退回 ' + n + ' 发 ' + t);
  return n;
}
function gunApplyAttachAndReturn(g){
  if (!g || typeof gunApplyAttach !== 'function') return 0;
  const over = gunApplyAttach(g);
  if (over > 0) gunReturnRounds(g, over);
  return over;
}
function bagAttachToGun(it, gi, take = bagRemoveItem){
  if (!it || it.k !== 'attach' || !it.aid) return false;
  const d = attachDef(it.aid);
  if (!d) return false;
  const S = gunSlots();
  const wid = S[gi];
  const g = wid && player.guns && player.guns[wid];
  if (!g){ setMsg('这个栏里没有枪', 1.4); return false; }
  if (!attachFits(it.aid, g.wid)){ setMsg(d.name + ' 装不上 ' + g.name + '（只能装在' + (d.fits || []).join('/') + '上）', 2.2); return false; }
  if (!take(it)) return false;
  const old = gunAttach(g, it.aid);
  if (old){
    const od = attachDef(old);
    if (!bagAddCell('attach', { aid: old })) bagLootFromItem({ k:'attach', aid: old });
    logInfo('item', '换下 ' + (od ? od.name : old) + ' 回到背包');
  }
  const _over = gunApplyAttachAndReturn(g);
  bagRebuild();
  sfxPick();
  setMsg('装上 ' + d.name + ' · ' + d.desc + ' · 弹匣 ' + g.mag + '/' + g.cap + (_over ? '' : ''), 2.6);
  logInfo('item', '装上配件 ' + d.name + ' → ' + g.name + '（' + g.cap + ' 发）');
  return true;
}
/* ---- 配件：从某一把枪上取下，回到背包（放不下就掉脚边） ---- */
function bagDetachFromGun(gi, slot){
  const S = gunSlots();
  const wid = S[gi];
  const g = wid && player.guns && player.guns[wid];
  if (!g) return false;
  const _sl = (typeof slot === 'string' && slot) ? slot : 'muzzle';
  const id = gunDetach(g, _sl);
  if (!id) return false;
  gunApplyAttachAndReturn(g);
  const d = attachDef(id);
  if (!bagAddCell('attach', { aid: id })) bagLootFromItem({ k:'attach', aid: id });
  bagRebuild();
  sfxPick();
  setMsg('取下 ' + (d ? d.name : '配件') + ' 放回背包 · 弹匣 ' + g.mag + '/' + g.cap, 1.9);
  logInfo('item', '取下配件 ' + (d ? d.name : id));
  return true;
}

/* 界面注册表：加新界面 = 写一个渲染函数 + 在这里登记 + 把状态挂进 UI_STATE */
const UI_SCREENS = {
  inv: { active: function(){ return ui.inv.open && bagGridOn(); }, draw: function(){ drawInventoryGrid(); } },
  gacha: { active: function(){ return typeof GACHA !== 'undefined' && GACHA.open; }, draw: function(){ drawGacha(); } }
};
function uiScreensActive(){ for (const k in UI_SCREENS){ if (UI_SCREENS[k].active()) return k; } return null; }
function uiDrawScreens(){
  const k = uiScreensActive();
  if (k) UI_SCREENS[k].draw();
  return k;
}

function drawInventory(){
  if (!hasFeat('meds') || !ui.inv.open) return;
  if (uiDrawScreens()) return;
  const ink  = THEME_LIGHT ? 'rgba(26,36,46,0.95)' : 'rgba(232,240,248,0.95)';
  const dim  = THEME_LIGHT ? 'rgba(70,86,102,0.85)' : 'rgba(146,166,182,0.9)';
  const panel= THEME_LIGHT ? 'rgba(250,248,242,0.98)' : 'rgba(9,14,19,0.97)';
  const line = THEME_LIGHT ? 'rgba(120,132,144,0.6)' : 'rgba(110,140,164,0.45)';

  const cols = 6, rows = 4, cell = 58, gap = 8;
  const gw = cols*cell + (cols-1)*gap;
  const gh = rows*cell + (rows-1)*gap;
  const stW = 196;
  const pw = 22 + stW + 18 + gw + 240, ph = gh + 132;
  const px = Math.round(W/2 - pw/2), py = Math.round(H/2 - ph/2);
  const sx = px + 22, sy = py + 78;
  const gx = px + 22 + stW + 18, gy = py + 78;
  const sw = stW - 2;

  ctx.save();
  ctx.fillStyle = panel; ctx.strokeStyle = line; ctx.lineWidth = 1.6;
  roundRect(px, py, pw, ph, 12); ctx.fill(); ctx.stroke();

  ctx.textAlign = 'left';
  ctx.fillStyle = ink; ctx.font = 'bold 18px "Microsoft YaHei",sans-serif';
  ctx.fillText('背包', px + 22, py + 34);
  ctx.fillStyle = dim; ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText(keyLabel(BINDS.bag) + ' 关闭 · G 丢枪', px + 74, py + 34);

  /* 左侧状态 */
  ctx.fillStyle = THEME_LIGHT ? 'rgba(236,232,222,0.75)' : 'rgba(18,25,32,0.8)';
  roundRect(sx, sy, sw, gh, 9); ctx.fill();
  ctx.strokeStyle = line; ctx.lineWidth = 1.2;
  roundRect(sx, sy, sw, gh, 9); ctx.stroke();

  /* 护甲 */
  const AD = (player.armor && typeof armorDef === 'function') ? armorDef(player.armor.kind) : null;
  const aPct = (player.armor && player.armor.maxHp > 0) ? clamp(player.armor.hp / player.armor.maxHp, 0, 1) : 0;
  ctx.fillStyle = dim; ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillText('防弹衣', sx + 12, sy + 22);
  ctx.fillStyle = AD ? AD.pal : dim; ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillText(AD ? (player.armor.label || AD.label) : '没穿', sx + 12, sy + 40);
  if (AD){
    ctx.fillStyle = 'rgba(10,16,22,0.6)';
    roundRect(sx + 12, sy + 48, sw - 24, 6, 3); ctx.fill();
    ctx.fillStyle = AD.pal;
    roundRect(sx + 12, sy + 48, Math.max(3, (sw - 24) * aPct), 6, 3); ctx.fill();
    ctx.fillStyle = dim; ctx.font = '10px "Microsoft YaHei",sans-serif';
    ctx.fillText(Math.ceil(player.armor.hp) + ' / ' + player.armor.maxHp + ' · 减伤 ' + Math.round((AD.reduce||0)*100) + '%', sx + 12, sy + 66);
  }

  /* 主武器 */
  ctx.fillStyle = dim; ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillText('主武器', sx + 12, sy + 92);
  ctx.fillStyle = ink; ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillText(player.gun ? (player.gun.name || '武器') : '空手', sx + 12, sy + 112);
  if (player.gun){
    ctx.textAlign = 'right'; ctx.fillStyle = dim; ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText((player.gun.mag | 0) + ' / ' + (player.gun.cap | 0), sx + sw - 12, sy + 112);
    ctx.textAlign = 'left';
  }

  /* 背包 */
  ctx.fillStyle = dim; ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillText('背包', sx + 12, sy + 138);
  ctx.fillStyle = ink; ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillText(bagDef(player.bag.kind).label, sx + 12, sy + 158);

  /* 中间：格子 */
  const slots = invSlots();
  const list = [];
  for (let i = 0; i < cols*rows; i++) list.push(slots[i] || null);
  let hover = null;
  for (let y = 0; y < rows; y++){
    for (let x = 0; x < cols; x++){
      const it = list[y*cols + x];
      const cx0 = gx + x*(cell+gap), cy0 = gy + y*(cell+gap);
      const hot = mouse.x >= cx0 && mouse.x <= cx0 + cell && mouse.y >= cy0 && mouse.y <= cy0 + cell;
      ctx.fillStyle = hot ? (THEME_LIGHT ? 'rgba(212,226,238,0.9)' : 'rgba(40,58,74,0.9)')
                          : (THEME_LIGHT ? 'rgba(232,232,226,0.7)' : 'rgba(255,255,255,0.045)');
      roundRect(cx0, cy0, cell, cell, 6); ctx.fill();
      ctx.strokeStyle = line; ctx.lineWidth = 1;
      roundRect(cx0 + 0.5, cy0 + 0.5, cell - 1, cell - 1, 6); ctx.stroke();
      if (!it) continue;
      if (hot) hover = it;
      if (it.kind === 'gun'){
        try { drawGunModel(cx0 + cell/2, cy0 + cell/2, 0.9, -0.45, '#c8d6e2', '#26323c', (player.gun && player.gun.kind) || 'pistol'); } catch (e){ if (typeof reportErr === 'function') reportErr('40-inventory', e); }
      } else if (it.kind === 'ammo'){
        bagDrawItemIcon({ k:'ammo', t:it.ammo, n:it.n }, cx0 + cell/2, cy0 + cell/2 - 4, cell - 14);
        ctx.textAlign = 'right'; ctx.fillStyle = ink; ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
        ctx.fillText(it.n, cx0 + cell - 6, cy0 + cell - 6);
        ctx.textAlign = 'left';
      } else if (it.kind === 'med'){
        bagDrawItemIcon({ k:'med', rarity:it.rarity }, cx0 + cell/2, cy0 + cell/2 - 6, cell - 16);
        ctx.textAlign = 'right'; ctx.fillStyle = ink; ctx.font = 'bold 11px "Microsoft YaHei",sans-serif';
        ctx.fillText('×' + it.n, cx0 + cell - 6, cy0 + cell - 6);
        ctx.textAlign = 'left';
      }
    }
  }
  invGeom = { cols:cols, rows:rows, gx:gx, gy:gy, cell:cell, gap:gap, slots:list };

  /* 右侧说明 */
  const ix = gx + gw + 22, iy = py + 78, ih = gh;
  ctx.fillStyle = THEME_LIGHT ? 'rgba(238,235,228,0.8)' : 'rgba(18,25,32,0.85)';
  roundRect(ix, iy, 240 - 22, ih, 9); ctx.fill();
  ctx.strokeStyle = line; ctx.lineWidth = 1.2;
  roundRect(ix, iy, 240 - 22, ih, 9); ctx.stroke();
  if (hover){
    const info = invInfo(hover);
    ctx.fillStyle = info.col; ctx.fillRect(ix + 16, iy + 18, 5, 20);
    ctx.fillStyle = ink; ctx.font = 'bold 15px "Microsoft YaHei",sans-serif';
    ctx.fillText(info.title, ix + 28, iy + 34);
    ctx.textAlign = 'right'; ctx.fillStyle = info.col; ctx.font = '12px "Microsoft YaHei",sans-serif';
    ctx.fillText(info.tag, ix + 202, iy + 34);
    ctx.textAlign = 'left';
    ctx.strokeStyle = line; ctx.beginPath();
    ctx.moveTo(ix + 16, iy + 48); ctx.lineTo(ix + 202, iy + 48); ctx.stroke();
    let yy = iy + 72;
    ctx.font = '12px "Microsoft YaHei",sans-serif'; ctx.fillStyle = ink;
    for (const ln of info.lines){ ctx.fillText(ln, ix + 16, yy); yy += 20; }
  } else {
    ctx.fillStyle = dim; ctx.font = '12.5px "Microsoft YaHei",sans-serif';
    ctx.fillText('鼠标停到格子上', ix + 16, iy + 40);
    ctx.fillText('看这件东西的说明', ix + 16, iy + 60);
  }
  ctx.fillStyle = dim; ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.fillText(keyLabel(BINDS.bag) + ' 关闭 · G 丢枪 · 1 / 2 用药', px + 22, py + ph - 18);
  ctx.restore();
}

/* ---------- 网格背包面板（机制版本 3） ---------- */
/* ============================================================================
 * 背包界面：视图模型（纯数据）
 * ----------------------------------------------------------------------------
 * 这里只做一件事：把"游戏数据 + UI_STATE"翻译成一张纯数据表。
 * 不碰 ctx、不读鼠标、不写任何游戏状态（只把交互热区顺手记下来给鼠标逻辑用）。
 * 绘制函数拿到的就是这张表，里面已经没有任何"if (player.xxx)"。
 * ========================================================================== */
function uiBagViewModel(subject){
  const owner=subject?subject.actor:player;
  const viewItems=subject?subject.items:bagItems();
  const inv=subject?{drag:null,selUid:subject.selUid}:ui.inv;
  const C = UI_CFG, M = C.metric, X = C.text;
  const T = THEME_LIGHT ? C.palette.light : C.palette.dark;
  const font = C.fonts();

  /* ---------------- 几何 ---------------- */
  const g = subject ? subject.grid : bagGridSize();
  const cols = Math.max(1, g.w), rows = Math.max(1, g.h), gap = M.gap;
  /* 有货斗：面板往右长出一块，背包和货斗用同样大的格子并排（不再挤成一条缝） */
  const _cargoOn = !subject && !!inventoryCargoTruck();
  const cargoCols = _cargoOn ? CARGO_W : 0, cargoRows = _cargoOn ? CARGO_H : 0;
  let cell = cols <= 6 ? M.cellBig : M.cellSmall;
  const panelW = (c) => {
    const base = M.panelPad + M.slotW + 18 + (cols*c + (cols-1)*gap);
    if (_cargoOn) return base + 26 + (cargoCols*c + (cargoCols-1)*gap) + M.panelPad;
    return base + 20 + M.infoW + M.panelPad;
  };
  while (cell > M.minCell && panelW(cell) > W - 40) cell--;
  const gw = cols*cell + (cols-1)*gap;
  const gh = rows*cell + (rows-1)*gap;
  const colH = Math.max(M.slotNeed, Math.min(gh, 6*cell + 5*gap));
  const cgW = _cargoOn ? (cargoCols*cell + (cargoCols-1)*gap) : 0;
  const cgH = _cargoOn ? (cargoRows*cell + (cargoRows-1)*gap) : 0;
  const pw = M.panelPad + M.slotW + 18 + gw + (_cargoOn ? (26 + cgW) : (20 + M.infoW)) + M.panelPad;
  const ph = Math.max(gh, colH, cgH) + 96;
  const px = Math.round(W/2 - pw/2), py = Math.round(Math.max(24, H/2 - ph/2));
  const sx = px + M.panelPad, sy = py + M.headerH;
  const gridOffY = Math.max(0, (colH - gh) / 2);
  const gx = px + M.panelPad + M.slotW + 18, gy = py + M.headerH + gridOffY;
  const sw = M.slotW - 2;
  const cargoRect = _cargoOn ? {
    x: gx + gw + 26, y: py + M.headerH + Math.max(0, (colH - cgH) / 2),
    w: cgW, h: cgH, cell: cell, gap: gap, cols: cargoCols, rows: cargoRows
  } : null;

  /* ---------------- 标题栏 ---------------- */
  const bd = bagDef(owner.bag && owner.bag.kind);
  const shape = g.bw > 0
    ? ((g.inf ? ' · ' + cols + '×' + rows + X.shapeUnlimited : ' · ' + g.bw + '×' + g.bh) + X.pocketPlus + POCKET_COLS + X.cells)
    : (X.onlyPocket + POCKET_COLS + X.cells);
  const header = {
    title: X.bagTitle,
    sub: (bd.label || '') + shape,
    cap: (subject ? viewItems.reduce((n,it)=>n+it.w*it.h,0) : bagUsed()) + ' / ' + g.cap + X.cells
  };

  /* ---------------- 左列四个装备槽 ---------------- */
  const padX = M.padX, iconW = M.iconW, aw = sw - 20;
  const ax = sx + 10;
  const slots = [];
  let cy = sy + 10;

  /* 护甲 */
  {
    const rect = { x: ax, y: cy, w: aw, h: M.armorH };
    const ad = (owner.armor && typeof armorDef === 'function') ? armorDef(owner.armor.kind) : null;
    const pct = (owner.armor && owner.armor.maxHp > 0) ? clamp(owner.armor.hp / owner.armor.maxHp, 0, 1) : 0;
    const hot = !!(inv.drag && inv.drag.it && inv.drag.it.k === 'armor' && inRect(rect));
    slots.push({
      id: 'armor', rect, hot,
      label: hot ? X.armorDrop : X.armor,
      icon: ad ? { kind: 'armor', size: iconW - 12, data: { k:'armor', ak:owner.armor.kind, hp:owner.armor.hp, maxHp:owner.armor.maxHp } } : null,
      empty: ad ? null : X.armorEmpty,
      name: ad ? (owner.armor.label || ad.label) : X.armorEmptyMark,
      nameColor: ad ? ad.pal : T.dim,
      line: ad ? (X.armorReduce + Math.round((ad.reduce||0)*100) + '%') : '',
      bar: ad ? { pct, color: pct > 0.35 ? ad.pal : T.barBad, text: Math.ceil(owner.armor.hp) + ' / ' + owner.armor.maxHp } : null,
      dimmed: !!(inv.drag && inv.drag.it && inv.drag.it.eq === 'armor'),
      hotStyle: 'cool'
    });
    cy += M.armorH + M.slotGap;
  }

  /* 背包 */
  {
    const rect = { x: ax, y: cy, w: aw, h: M.bagH };
    const bk = (owner.bag && owner.bag.kind) || 'none';
    const hot = !!(inv.drag && inv.drag.it && inv.drag.it.k === 'bag' && inRect(rect));
    slots.push({
      id: 'bag', rect, hot,
      label: hot ? X.bagDrop : X.bag,
      icon: bk !== 'none' ? { kind: 'bag', size: iconW - 14, data: { k:'bag', bk } } : null,
      empty: bk !== 'none' ? null : X.bagEmpty,
      name: bd ? bd.label : X.bagEmptyMark,
      nameColor: T.ink,
      line: X.bagCarry + Math.max(0, g.cap - POCKET_COLS * POCKET_ROWS) + X.cells,
      bar: null,
      dimmed: !!(inv.drag && inv.drag.it && inv.drag.it.eq === 'bag'),
      hotStyle: 'bag'
    });
    cy += M.bagH + M.slotGap;
  }

  /* 盾牌 */
  {
    const rect = { x: ax, y: cy, w: aw, h: M.shieldH };
    const has = !!owner.hasShield;
    const hot = !!(inv.drag && inv.drag.it && inv.drag.it.eq === 'shield' && inRect(rect));
    const maxHp = SHIELD_MAX_HP || 600;
    const pct = clamp((owner.shieldHp || 0) / maxHp, 0, 1);
    slots.push({
      id: 'shield', rect, hot,
      label: hot ? X.shieldDrop : (has ? X.shieldOn : X.shield),
      icon: has ? { kind: 'shield', size: iconW - 16, data: { k:'shield' } } : null,
      empty: has ? null : X.shieldEmpty,
      name: has ? (owner.shieldRaised ? X.shieldUp : X.shieldDown) : '',
      nameColor: T.hot,
      line: '',
      bar: has ? { pct, color: pct > 0.35 ? T.hot : T.barBad, text: Math.ceil(owner.shieldHp) + ' / ' + maxHp } : null,
      dimmed: !!(inv.drag && inv.drag.it && inv.drag.it.eq === 'shield'),
      hotStyle: 'cool'
    });
    cy += M.shieldH + M.slotGap;
  }

  /* 热成像 */
  {
    const rect = { x: ax, y: cy, w: aw, h: M.heatH };
    const worn = !!owner.heatWorn;
    const hot = !!(inv.drag && inv.drag.it && inv.drag.it.k === 'thermal' && !inv.drag.it.eq && inRect(rect));
    const swapping = owner.batSwapT > 0;
    const stateTxt = swapping ? X.heatSwapping : (owner.thermal ? X.heatOn : (owner.heatCd > 0 ? X.heatCd : X.heatWorn));
    slots.push({
      id: 'thermal', rect, hot,
      label: hot ? X.heatDrop : X.heat,
      icon: worn ? { kind: 'thermal', data: {}, alpha: owner.thermal ? 1 : 0.72 } : null,
      empty: worn ? null : X.heatEmpty,
      name: worn ? stateTxt : '',
      nameColor: T.thermal,
      line: '',
      hint: worn ? '' : X.heatHint,
      bar: worn && swapping ? { pct: clamp(1 - owner.batSwapT / BAT_SWAP_DUR, 0, 1), color: T.thermal,
                                 text: X.heatRemaining + owner.batSwapT.toFixed(1) + ' 秒' }
        : worn ? { pct: clamp((owner.battery || 0)/heatCapNow(), 0, 1), color: owner.batLock ? T.barBad : T.thermal,
                   text: X.heatBattery + heatPct(owner.battery || 0) + '%' } : null,
      dimmed: !!(inv.drag && inv.drag.it && inv.drag.it.eq === 'thermal'),
      hotStyle: 'heat', on: worn
    });
    cy += M.heatH + M.slotGap;
  }

  /* ---------------- 武器栏（ver3）/ 主武器 ---------------- */
  const weapons = [];
  if (bagGridOn()){
    const S = subject ? subject.slots : gunSlots();
    const _gunLabels = [X.gun1, X.gun2, X.gun3, X.gun4];
    for (let i = 0; i < 4; i++){
      const wid = S[i];
      const g = wid && owner.guns && owner.guns[wid] ? owner.guns[wid] : null;
      const rect = { x: ax, y: cy, w: aw, h: M.weaponH };
      weapons.push({
        id: 'gun' + i, rect, idx: i, wid: g ? g.wid : null,
        label: _gunLabels[i] || X.gun1,
        iconCol: T.gunIcon, iconEdge: T.gunIconEdge,
        name: g ? (g.name || X.weapon) : X.gunEmpty,
        ammo: g ? ((g.mag | 0) + ' / ' + (g.cap | 0)) : '',
        active: !!(g && owner.gun === g),
        empty: !g,
        hot: !!(g && inRect(rect)),
        /* 配件小格：这把枪支持几个槽就画几个（枪口 / 弹匣） */
        attShow: !!(g && g.wid && (typeof attachSlotsFor === 'function') && attachSlotsFor(g.wid).length > 0),
        attChips: (g && g.wid && typeof attachSlotsFor === 'function')
          ? attachSlotsFor(g.wid).map(sl => ({ slot: sl, id: gunAttachId(g, sl), name: ATTACH_SLOT_NAME[sl] || sl }))
          : []
      });
      cy += M.weaponH + M.slotGap;
    }
    cy += 10;    /* 跟上要跟下面的提示留一点空 */
  }
  const gw2 = owner.gun;
  const weapon = {
    label: X.weapon,
    name: gw2 ? (gw2.name || X.weapon) : X.fist,
    ammo: gw2 ? ((gw2.mag | 0) + ' / ' + (gw2.cap | 0)) : '',
    y: cy + 14
  };
  const hints = [
    { text: X.hintLine1, y: cy + 4 },
    { text: X.hintLine2, y: cy + 21 },
    { text: X.hintLine3, y: cy + 38 }
  ];

  /* ---------------- 格子底板 ---------------- */
  const cells = [];
  for (let y = 0; y < rows; y++){
    for (let x = 0; x < cols; x++){
      if (!bagCellOk(x, y, g)) continue;
      cells.push({
        x: gx + x*(cell+gap), y: gy + y*(cell+gap), s: cell,
        bg: (y >= g.bh) ? T.pocket : T.cell,
        edge: T.cellEdge
      });
    }
  }
  const pocket = (g.bh > 0 && g.ph > 0)
    ? { show: true, y: gy + g.bh*(cell+gap) - gap/2, x1: gx, x2: gx + gw,
        label: X.pocketLabel + POCKET_COLS + X.cells, labelX: gx + gw }
    : { show: false };

  /* ---------------- 格子里的物品卡片 ---------------- */
  const cards = [];
  const items = [];
  let hoverUid = 0;
  for (const it of viewItems){
    if (it === (inv.drag && inv.drag.it)) continue;
    const rx = gx + it.x*(cell+gap), ry = gy + it.y*(cell+gap);
    const rw = it.w*cell + (it.w-1)*gap, rh = it.h*cell + (it.h-1)*gap;
    const rect = { x: rx, y: ry, w: rw, h: rh };
    const hot = inRect(rect);
    const sel = it.uid === inv.selUid;
    if (hot) hoverUid = it.uid;
    items.push({ it, x: rx, y: ry, w: rw, h: rh });
    const card = {
      uid: it.uid, rect, hot, sel,
      icon: { it, x: rx + rw/2, y: ry + rh/2 - (it.k === 'armor' ? 10 : 0), size: Math.min(rw, rh) - 8 },
      badge: null
    };
    if (it.k === 'ammo' || ((it.k === 'rope' || it.k === 'heatcell' || it.k === 'med') && (it.n || 0) > 1)){
      card.badge = { type: 'num', text: String(it.n || 0),
                     font: C.style(Math.max(10, Math.round(cell*0.22)), 'bold'), color: T.num };
    } else if (it.k === 'armor'){
      const bh = 14, bw = rw - 6, bx = rx + 3, by = ry + rh - bh - 3;
      const pct = clamp(it.hp / Math.max(1, it.maxHp), 0, 1);
      card.badge = { type: 'dur', x: bx, y: by, w: bw, h: bh, pct,
                     color: pct > 0.35 ? T.hot : T.barBad,
                     text: Math.round(it.hp) + ' / ' + Math.round(it.maxHp) };
    }
    cards.push(card);
  }

  /* ---------------- 拖动 ---------------- */
  let drag = null;
  if (inv.drag){
    const it = inv.drag.it;
    const target = bagDragTarget(gx, gy, cell, gap, cols, rows, inv.drag);
    const {x:cx0, y:cy0, overGrid} = target;
    const pr = overGrid ? bagSmartProbe(it, cx0, cy0, target) : null;
    const tx = gx + (pr ? pr.x : cx0) * (cell+gap), ty = gy + (pr ? pr.y : cy0) * (cell+gap);
    const drawRot = pr ? (pr.rot || 0) : (it.rot || 0);
    const flip = (drawRot ? 1 : 0) !== (it.rot ? 1 : 0);
    const dw = flip ? it.h : it.w, dh = flip ? it.w : it.h;
    const tw = dw*cell + (dw-1)*gap, th = dh*cell + (dh-1)*gap;
    const ok = !!pr && pr.mode === 'free';
    drag = {
      overGrid, rot: drawRot,
      target: overGrid ? { x: tx, y: ty, w: tw, h: th,
                           fill: ok ? T.okFill : (pr ? T.softFill : T.badFill),
                           line: ok ? T.okLine : (pr ? T.softLine : T.badLine) } : null,
      /* 鼠标上的图标必须以指针为中心：bagDrawItemIcon 的 (cx,cy) 是中心点，
         以前这里加的是格子左上角 + 半个格子，等于把图标往右下推了半个身位。 */
      ghost: { it, x: mouse.x, y: mouse.y, size: Math.min(tw, th) - 8 }
    };
  }

  /* ---------------- 右侧说明 ---------------- */
  const shown = (hoverUid ? viewItems.find(i => i.uid === hoverUid) : null)
              || (inv.selUid ? viewItems.find(i => i.uid === inv.selUid) : null) || null;
  let info;
  if (shown){
    const d = bagItemInfo(shown);
    info = { show: true, title: d.title, tag: d.tag, color: d.col, lines: d.lines.slice() };
  } else {
    info = { show: false, empty: X.infoEmpty };
  }

  return {
    C, T, M, X, font,
    geom: { px, py, pw, ph, gx, gy, gw, gh, cell, gap, cols, rows, colH, sx, sy, sw,
            ix: gx + gw + 20, iy: py + M.headerH, iw: M.infoW, cargo: cargoRect },
    header, slots, weapons, weapon, hints, cells, pocket, cards, items, drag, info,
    cursor: inv.carry ? { it:inv.carry.item, count:inv.carry.count, x:mouse.x, y:mouse.y } : null,
    footer: {
      y: Math.min(py + ph - 18, H - 18),
      text: keyLabel(BINDS.bag) + ' 关闭 · ' + keyLabel(BINDS.inventoryTakeOne) + ' 拿一个 · ' +
        keyLabel(BINDS.inventoryTakeHalf) + ' 拿半堆 · ' + keyLabel(BINDS.inventoryPlace) + ' 放下手上物资'
    },
    hoverUid
  };
}

/* 点/矩形命中：UI 内部工具，不算游戏逻辑 */
function inRect(r){
  return mouse.x >= r.x && mouse.x <= r.x + r.w && mouse.y >= r.y && mouse.y <= r.y + r.h;
}

let companionBagButtons=[];
function companionBagClick(){
  if(!ui.inv.open)return false;
  const b=companionBagButtons.find(b=>mouse.x>=b.x&&mouse.x<=b.x+b.w&&mouse.y>=b.y&&mouse.y<=b.y+b.h);
  if(b){b.action();ui.inv.drag=null;ui.inv.gunDrag=null;mouse.down=false;mouse.fire=false;return true;}
  return !!ui.inv.companion; // modal: no click-through into the player's inventory
}
function companionBagButton(x,y,w,h,label,action,enabled=true){
  const T=THEME_LIGHT?UI_CFG.palette.light:UI_CFG.palette.dark,M=UI_CFG.metric;
  ctx.fillStyle=enabled?T.card:T.emptySlot;roundRect(x,y,w,h,M.cardRadius);ctx.fill();
  ctx.strokeStyle=enabled?T.hot:T.line;ctx.lineWidth=M.lineW.slot;ctx.stroke();
  ctx.fillStyle=enabled?T.ink:T.dim;ctx.font=UI_CFG.fonts().sub;ctx.textAlign='center';
  ctx.fillText(label,x+w/2,y+h/2+5);
  companionBagButtons.push({x,y,w,h,label,enabled,action:enabled?action:()=>{}});
}
function companionBagEntry(G){
  companionBagButtons=[];if(!allies.length)return;
  companionBagButton(G.px+G.pw-170,G.py+3,148,18,'队友背包 →',()=>{ui.inv.companion=allies[0].id;ui.inv.companionAmmo='pistol';});
}
function companionBagViewModel(e){
  const p=companionPack(e),items=Object.keys(AMMO).map((t,i)=>({uid:'ally-ammo-'+t,k:'ammo',t,n:p.ammo[t]||0,
    x:i%4,y:Math.floor(i/4),w:t==='rocket'?2:1,h:1}));
  // The same player view model builds every slot, card, icon, font and geometry.
  // Explicit owner data avoids ever replacing the global player during rendering.
  const guns=Object.fromEntries(p.guns.map((g,i)=>['slot'+i,g]));
  const actor={armor:e.armor,bag:{kind:'mid'},guns,gun:p.guns[p.selected],ammo:p.ammo};
  const vm=uiBagViewModel({actor,items,grid:{w:4,h:6,bw:4,bh:5,pw:4,ph:1,cap:24,inf:false},
    slots:[0,1,2].map(i=>p.guns[i]?'slot'+i:null),selUid:'ally-ammo-'+(ui.inv.companionAmmo||'pistol')});
  vm.header.sub='队友 '+e.id;vm.header.cap='武器 '+p.guns.length+' / 3';
  vm.slots.find(s=>s.id==='bag').line='弹药储备';
  vm.weapons.forEach((w,i)=>{w.label='武器 '+(i+1);});
  vm.hints=vm.hints.map((h,i)=>({...h,text:['点击武器栏切换装备','点击弹药格选择口径','右栏交接枪械与弹药'][i]||''}));
  const t=ui.inv.companionAmmo||'pistol';
  vm.info={show:true,title:'装备交接',tag:companionCanTrade(e)?'可交接':'距离过远',color:vm.T.hot,
    lines:['靠近队友后交接装备','我的武器 → 队友','弹匣随枪，备用弹药单独交接']};
  vm.footer.text='Tab / Esc 关闭 · 点击枪栏换枪 · 点击弹药格选择口径';
  return vm;
}
function drawCompanionBag(){
  if(!ui.inv.companion)return false;
  const e=allies.find(a=>a.id===ui.inv.companion);
  if(!e){ui.inv.companion=null;companionBagButtons=[];return false;}
  companionSyncGun(e);const p=companionPack(e),near=companionCanTrade(e),vm=companionBagViewModel(e),G=vm.geom;
  companionBagButtons=[];drawInventoryGrid(vm);ctx.save();
  companionBagButton(G.px+G.pw-170,G.py+3,148,18,'← 我的背包',()=>{ui.inv.companion=null;});
  allies.forEach((a,i)=>companionBagButton(G.px+22+i*92,G.py+37,86,18,a.id+(a===e?' · 当前':''),()=>{ui.inv.companion=a.id;}));
  for(const w of vm.weapons){
    companionBagButtons.push({...w.rect,label:'队友武器'+(w.idx+1),action:()=>{
      if(near&&p.guns[w.idx]){companionEquip(e,w.idx);ui.inv.companionAmmo=gunDef(p.guns[w.idx]).ammo;}
    }});
  }
  for(const item of vm.items)companionBagButtons.push({...item,label:ammoLabelOf(item.it.t),action:()=>{ui.inv.companionAmmo=item.it.t;}});
  const x=G.ix+12,w=G.iw-24;
  const button=(yy,label,fn,on=true)=>companionBagButton(x,G.iy+yy,w,30,label,fn,on);
  gunOrder().filter(k=>weaponCore(player.guns[k].wid).kind==='gun').slice(0,3).forEach((key,i)=>{
    const g=player.guns[key];button(140+i*36,g.name+' '+g.mag+'/'+g.cap+' →',()=>companionGiveGun(e,key),near&&p.guns.length<3);
  });
  button(268,'取回当前装备',()=>{if(!companionTakeGun(e,p.selected))setMsg('对应武器栏已满，请先腾出位置',2);},near&&p.selected>=0);
  const type=ui.inv.companionAmmo||'pistol';
  ctx.fillStyle=vm.T.ink;ctx.font=vm.font.infoLine;ctx.textAlign='left';
  ctx.fillText(ammoLabelOf(type),x,G.iy+340);
  ctx.fillText('队友 '+(p.ammo[type]||0)+' / 我的 '+((player.ammo||{})[type]||0),x,G.iy+364);
  button(384,'交给队友 →',()=>companionTransferAmmo(e,type,true),near&&((player.ammo||{})[type]||0)>0);
  button(424,'← 取回弹药',()=>companionTransferAmmo(e,type,false),near&&(p.ammo[type]||0)>0);
  ctx.fillStyle=vm.T.dim;ctx.font=vm.font.hint;ctx.textAlign='left';
  ctx.fillText('每次交接30发，不足按实际数量',x,G.iy+480);
  ctx.fillText('没有弹药时停止射击',x,G.iy+502);
  ctx.restore();return true;
}

/* ============================================================================
 * 背包界面：绘制
 * ----------------------------------------------------------------------------
 * 这里只允许做三件事：读 VM、调 ctx、写 UI 自己的热区缓存。
 * 不允许出现 player.*、不允许写死颜色/字号/中文文案。
 * ========================================================================== */
function drawInventoryGrid(viewModel){
  if(!viewModel&&drawCompanionBag())return;
  const vm = viewModel || uiBagViewModel();
  const T = vm.T, M = vm.M, F = vm.font, G = vm.geom;

  ctx.save();

  /* ---- 皮面 ---- */
  const pg = ctx.createLinearGradient(G.px, G.py, G.px, G.py + G.ph);
  pg.addColorStop(0, T.panelTop);
  pg.addColorStop(0.5, T.panel);
  pg.addColorStop(1, T.panelBot);
  ctx.fillStyle = pg;
  ctx.strokeStyle = T.panelEdge;
  ctx.lineWidth = M.lineW.panel;
  roundRect(G.px, G.py, G.pw, G.ph, M.panelRadius); ctx.fill(); ctx.stroke();
  ctx.save();
  ctx.setLineDash(M.dash.stitch);
  ctx.strokeStyle = T.stitch; ctx.lineWidth = M.lineW.stitch;
  roundRect(G.px + 5, G.py + 5, G.pw - 10, G.ph - 10, 9); ctx.stroke();
  ctx.restore();

  /* ---- 标题栏 ---- */
  ctx.textAlign = 'left';
  ctx.fillStyle = T.ink; ctx.font = F.title;
  ctx.fillText(vm.header.title, G.px + M.panelPad, G.py + 34);
  ctx.fillStyle = T.dim; ctx.font = F.sub;
  ctx.fillText(vm.header.sub, G.px + 74, G.py + 34);
  ctx.textAlign = 'right';
  ctx.fillStyle = T.dim; ctx.font = F.cap;
  ctx.fillText(vm.header.cap, G.px + G.pw - M.panelPad, G.py + 34);
  ctx.textAlign = 'left';

  /* ---- 左列底板 ---- */
  ctx.fillStyle = T.slotBg;
  roundRect(G.sx, G.sy, G.sw, G.colH, 10); ctx.fill();
  ctx.strokeStyle = T.line; ctx.lineWidth = M.lineW.slot;
  roundRect(G.sx, G.sy, G.sw, G.colH, 10); ctx.stroke();

  /* ---- 四个装备槽 ---- */
  const padX = M.padX, iconW = M.iconW;
  for (const s of vm.slots){
    const r = s.rect;
    const bg = s.hot ? (s.hotStyle === 'bag' ? T.bagHot : s.hotStyle === 'heat' ? T.heatHot
                      : s.on ? T.heatOn : T.hotBg)
                     : (s.on ? T.heatOn : T.emptySlot);
    ctx.fillStyle = bg;
    roundRect(r.x, r.y, r.w, r.h, M.slotRadius); ctx.fill();
    ctx.strokeStyle = s.hot ? (s.hotStyle === 'bag' ? T.bagHotLine : s.hotStyle === 'heat' ? T.thermal : T.hot)
                            : (s.on ? T.heatLine : T.line);
    ctx.lineWidth = s.hot ? M.lineW.hot : M.lineW.slot;
    roundRect(r.x, r.y, r.w, r.h, M.slotRadius); ctx.stroke();

    ctx.fillStyle = T.dim; ctx.font = F.slotLabel;
    ctx.fillText(s.label, r.x + padX, r.y + 15);

    /* 图标底 */
    const ix = r.x + padX - 2, iy = r.y + 20, ih = r.h - 30;
    ctx.fillStyle = T.slotIcon;
    roundRect(ix, iy, iconW, ih, 6); ctx.fill();

    if (s.icon){
      const cx = ix + iconW/2, cyy = iy + ih/2;
      if (s.icon.alpha !== undefined) { ctx.save(); ctx.globalAlpha = s.icon.alpha; }
      if (s.icon.kind === 'thermal') drawThermalIcon(cx, cyy, 1.5);
      else bagDrawItemIcon(s.icon.data, cx, cyy, s.icon.size);
      if (s.icon.alpha !== undefined) ctx.restore();
    } else if (s.empty){
      ctx.fillStyle = T.dim; ctx.font = F.empty;
      ctx.textAlign = 'center';
      ctx.fillText(s.empty, ix + iconW/2, iy + ih/2 + 4);
      ctx.textAlign = 'left';
    }

    const tx0 = r.x + padX + iconW + 8;
    const tw0 = r.x + r.w - padX - tx0;
    if (s.name){
      ctx.fillStyle = s.nameColor || T.ink;
      ctx.font = s.id === 'armor' ? F.slotName : F.slotStat;
      ctx.fillText(s.name, tx0, r.y + (s.id === 'armor' ? 44 : s.id === 'bag' ? 48 : 42));
    }
    if (s.line){
      ctx.fillStyle = T.dim; ctx.font = F.slotLine;
      ctx.fillText(s.line, tx0, r.y + (s.id === 'bag' ? 68 : 63));
    }
    if (s.hint){
      ctx.fillStyle = T.dim; ctx.font = F.tiny;
      ctx.fillText(s.hint, tx0, r.y + 46);
    }
    if (s.bar){
      const by = r.y + (s.id === 'armor' ? 70 : s.id === 'shield' ? 50 : 48);
      ctx.fillStyle = T.barTrack;
      roundRect(tx0, by, tw0, M.barH, M.barR); ctx.fill();
      ctx.fillStyle = s.bar.color;
      roundRect(tx0, by, Math.max(3, tw0 * s.bar.pct), M.barH, M.barR); ctx.fill();
      ctx.fillStyle = T.dim; ctx.font = F.tiny;
      ctx.fillText(s.bar.text, tx0, by + 20);
    }
    if (s.dimmed){
      ctx.fillStyle = T.dimmed;
      roundRect(r.x, r.y, r.w, r.h, M.slotRadius); ctx.fill();
    }

    /* 把热区交给鼠标逻辑 */
    if (!viewModel){
      if (s.id === 'bag') bagSlotRect = s.rect;
      else if (s.id === 'shield') shieldSlotRect = s.rect;
      else if (s.id === 'thermal') heatSlotRect = s.rect;
    }
  }

  /* ---- 武器栏 ---- */
  for (const wp of (vm.weapons || [])){
    const r = wp.rect;
    ctx.fillStyle = wp.active ? T.heatOn : (wp.hot ? T.hotBg : T.emptySlot);
    roundRect(r.x, r.y, r.w, r.h, M.slotRadius); ctx.fill();
    ctx.strokeStyle = wp.active ? T.heatLine : (wp.hot ? T.hot : T.line);
    ctx.lineWidth = wp.active ? M.lineW.hot : M.lineW.slot;
    roundRect(r.x, r.y, r.w, r.h, M.slotRadius); ctx.stroke();

    /* 图标：跟背包槽一样，每个武器栏都画一把枪（左边留 34px 的图标位） */
    const icx = r.x + padX + 15, icy = r.y + r.h / 2;
    if (wp.wid){
      drawGunModel(icx, icy, 0.36, -0.22, wp.iconCol, wp.iconEdge, wp.wid);
    } else {
      ctx.strokeStyle = T.line; ctx.lineWidth = 1;
      roundRect(icx - 13, icy - 7, 26, 14, 3); ctx.stroke();
    }

    const tx0 = r.x + padX + 38;
    ctx.fillStyle = T.dim; ctx.font = F.slotLabel;
    ctx.fillText(wp.label, tx0, r.y + 15);

    ctx.fillStyle = wp.empty ? T.dim : T.ink;
    ctx.font = F.weapon;
    ctx.fillText(wp.name, tx0, r.y + 31);
    if (wp.ammo){
      ctx.textAlign = 'right'; ctx.fillStyle = T.dim; ctx.font = F.sub;
      ctx.fillText(wp.ammo, r.x + r.w - padX, r.y + 31);
      ctx.textAlign = 'left';
    }
    if (wp.active){
      ctx.fillStyle = T.thermal; ctx.font = F.tiny;
      ctx.fillText(vm.X.gunUsing, r.x + r.w - padX - 62, r.y + 15);
    }

    /* 配件小格：右上角横排，装了显示配件、空着显示虚线框（枪口 / 弹匣） */
    const _attRects = [];
    if (wp.attShow && wp.attChips && wp.attChips.length){
      const _aw2 = 26, _ah = 16, _agap = 4;
      const _n = wp.attChips.length;
      for (let _ci = 0; _ci < _n; _ci++){
        const _c = wp.attChips[_ci];
        const _x = r.x + r.w - padX - _aw2 - (_n - 1 - _ci) * (_aw2 + _agap);
        const _rr = { x: _x, y: r.y + 4, w: _aw2, h: _ah, slot: _c.slot };
        ctx.fillStyle = _c.id ? T.hotBg : T.emptySlot;
        roundRect(_rr.x, _rr.y, _aw2, _ah, 4); ctx.fill();
        ctx.strokeStyle = _c.id ? T.hot : T.line;
        ctx.lineWidth = _c.id ? M.lineW.hot : 1;
        roundRect(_rr.x, _rr.y, _aw2, _ah, 4); ctx.stroke();
        if (_c.id) drawAttachIcon(_rr.x + _aw2/2, _rr.y + _ah/2, 0.62, _c.id);
        _attRects.push(_rr);
      }
      if (wp.hot) ctx.fillStyle = T.dim;
    }
    /* 热区交给鼠标逻辑 */
    if(!viewModel){ gunSlotRects[wp.idx] = r; attSlotRects[wp.idx] = _attRects; }
    if (ui.inv.gunDrag && ui.inv.gunDrag.from === wp.idx){
      ctx.strokeStyle = T.hot; ctx.lineWidth = M.lineW.hot;
      roundRect(r.x, r.y, r.w, r.h, M.slotRadius); ctx.stroke();
    }
  }

  /* ---- 左列提示（武器已经画在武器栏里，不再重复） ---- */
  ctx.fillStyle = T.dim; ctx.font = F.hint;
  for (const h of vm.hints) ctx.fillText(h.text, G.sx + 10, h.y);

  /* ---- 格子底板 ---- */
  for (const c of vm.cells){
    ctx.fillStyle = c.bg;
    roundRect(c.x, c.y, c.s, c.s, M.cellRadius); ctx.fill();
    ctx.strokeStyle = c.edge; ctx.lineWidth = M.lineW.cell;
    roundRect(c.x + 0.5, c.y + 0.5, c.s - 1, c.s - 1, M.cellRadius); ctx.stroke();
  }

  /* ---- 口袋分隔线 ---- */
  if (vm.pocket.show){
    ctx.save();
    ctx.setLineDash(M.dash.pocket);
    ctx.strokeStyle = T.brassLine; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(vm.pocket.x1, vm.pocket.y); ctx.lineTo(vm.pocket.x2, vm.pocket.y); ctx.stroke();
    ctx.restore();
    ctx.fillStyle = T.brass; ctx.font = F.tiny;
    ctx.textAlign = 'right';
    ctx.fillText(vm.pocket.label, vm.pocket.labelX, vm.pocket.y - 5);
    ctx.textAlign = 'left';
  }

  /* ---- 物品卡片 ---- */
  for (const cd of vm.cards){
    const r = cd.rect;
    ctx.fillStyle = (cd.hot || cd.sel) ? T.cardHot : T.card;
    roundRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2, M.cardRadius); ctx.fill();
    ctx.strokeStyle = (cd.hot || cd.sel) ? T.hot : T.line;
    ctx.lineWidth = (cd.hot || cd.sel) ? M.lineW.cardHot : M.lineW.card;
    roundRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2, M.cardRadius); ctx.stroke();

    bagDrawItemIcon(cd.icon.it, cd.icon.x, cd.icon.y, cd.icon.size);

    if (cd.badge && cd.badge.type === 'num'){
      ctx.textAlign = 'right';
      ctx.fillStyle = cd.badge.color; ctx.font = cd.badge.font;
      ctx.fillText(cd.badge.text, r.x + r.w - 5, r.y + r.h - 5);
      ctx.textAlign = 'left';
    } else if (cd.badge && cd.badge.type === 'dur'){
      const b = cd.badge;
      ctx.fillStyle = T.armorBarBg;
      roundRect(b.x, b.y, b.w, b.h, 3); ctx.fill();
      ctx.save();
      roundRect(b.x, b.y, b.w, b.h, 3); ctx.clip();
      ctx.fillStyle = b.color;
      ctx.fillRect(b.x, b.y, Math.max(1, b.w * b.pct), b.h);
      ctx.restore();
      ctx.textAlign = 'center';
      ctx.font = F.armorBar;
      ctx.lineWidth = 2.6; ctx.strokeStyle = T.numStroke;
      ctx.strokeText(b.text, b.x + b.w/2, b.y + b.h - 3.6);
      ctx.fillStyle = T.armorBarTx;
      ctx.fillText(b.text, b.x + b.w/2, b.y + b.h - 3.6);
      ctx.textAlign = 'left';
    }
  }

  /* ---- 拖动：落点高亮 + 手上那件 ---- */
  if (vm.drag){
    if (vm.drag.target){
      const t = vm.drag.target;
      ctx.fillStyle = t.fill;
      roundRect(t.x, t.y, t.w, t.h, M.cardRadius); ctx.fill();
      ctx.strokeStyle = t.line; ctx.lineWidth = M.lineW.hot;
      roundRect(t.x, t.y, t.w, t.h, M.cardRadius); ctx.stroke();
    }
    ctx.save();
    ctx.globalAlpha = 0.85;
    bagIconRotOverride = vm.drag.rot;
    if (vm.drag.ghost.it.n === undefined)
      bagDrawItemIcon(vm.drag.ghost.it, vm.drag.ghost.x, vm.drag.ghost.y, vm.drag.ghost.size);
    bagIconRotOverride = null;
    ctx.restore();
  }

  /* ---- 右侧：有货斗就给货斗，没有才是说明 ---- */
  if (G.cargo && typeof drawCargoInBag === 'function'){
    drawCargoInBag(G);
  } else {
  ctx.fillStyle = T.infoBg;
  roundRect(G.ix, G.iy, G.iw, G.colH, 9); ctx.fill();
  ctx.strokeStyle = T.line; ctx.lineWidth = M.lineW.slot;
  roundRect(G.ix, G.iy, G.iw, G.colH, 9); ctx.stroke();

  if (vm.info.show){
    ctx.fillStyle = vm.info.color;
    ctx.fillRect(G.ix + 16, G.iy + 18, 5, 20);
    ctx.fillStyle = T.ink; ctx.font = F.infoTitle;
    ctx.fillText(vm.info.title, G.ix + 28, G.iy + 34);
    ctx.textAlign = 'right';
    ctx.fillStyle = vm.info.color; ctx.font = F.infoTag;
    ctx.fillText(vm.info.tag, G.ix + G.iw - 16, G.iy + 34);
    ctx.textAlign = 'left';
    ctx.fillStyle = T.line;
    ctx.fillRect(G.ix + 16, G.iy + 48, G.iw - 32, 1);
    let yy = G.iy + 72;
    ctx.font = F.infoLine;
    for (const ln of vm.info.lines){
      ctx.fillStyle = T.ink;
      ctx.fillText(ln, G.ix + 16, yy);
      yy += 20;
    }
  } else {
    ctx.fillStyle = T.dim; ctx.font = F.infoEmpty;
    let yy = G.iy + 40;
    for (const ln of vm.info.empty){
      ctx.fillText(ln, G.ix + 16, yy);
      yy += (yy === G.iy + 60 ? 28 : 20);
    }
  }
  }

  /* ---- 底部提示 ---- */
  ctx.fillStyle = T.dim; ctx.font = F.footer;
  ctx.fillText(vm.footer.text, G.px + M.panelPad, vm.footer.y, G.pw - M.panelPad * 2);

  const ghost = vm.drag?.ghost;
  const held = vm.cursor || (ghost?.it.n !== undefined
    ? {...ghost, count:inventoryUnits(ghost.it), rot:vm.drag.rot} : null);
  if (held){
    const {it, count, x, y} = held;
    const label = '×' + count, size = 26, height = size + 8;
    ctx.font = F.cap; ctx.textAlign = 'left';
    const width = size + Math.ceil(ctx.measureText(label).width) + 14;
    const left = clamp(x + 14, 3, W - width - 3), top = clamp(y - height - 8, 3, H - height - 3);
    ctx.fillStyle = T.panel; ctx.strokeStyle = T.hot; ctx.lineWidth = M.lineW.hot;
    roundRect(left, top, width, height, M.cardRadius); ctx.fill(); ctx.stroke();
    bagIconRotOverride = held.rot ?? null;
    bagDrawItemIcon(it, left + size / 2 + 4, top + height / 2, size);
    bagIconRotOverride = null;
    ctx.font = F.cap; ctx.fillStyle = T.num;
    ctx.fillText(label, left + size + 7, top + height / 2 + 4);
  }
  ctx.restore();

  /* ---- 交互缓存（鼠标逻辑要用） ---- */
  if(viewModel)return;
  invGridGeom = {
    px: G.px, py: G.py, pw: G.pw, ph: G.ph, gx: G.gx, gy: G.gy,
    cell: G.cell, gap: G.gap, cols: G.cols, rows: G.rows,
    /* 货斗区（Tab 站在民用皮卡旁边才有）：拖放的落点判定要用它，以前这里漏了这个字段，
       于是"拖到货斗上"根本没地方可判定，看上去就是没反应。 */
    cargo: G.cargo || null,
    items: vm.items,
    armSlot: vm.slots[0].rect,
    bagSlot: bagSlotRect, shieldSlot: shieldSlotRect, heatSlot: heatSlotRect,
    gunSlots: [gunSlotRects[0], gunSlotRects[1], gunSlotRects[2]],
    attSlots: [attSlotRects[0], attSlotRects[1], attSlotRects[2]]
  };
  invHoverIt = vm.hoverUid ? (bagItems().find(i => i.uid === vm.hoverUid) || null) : null;
  ui.inv.hoverUid = vm.hoverUid;
  companionBagEntry(G);
  if (typeof drawTripDisarm === 'function') drawTripDisarm();
}



/* 第三关专用：你能不能看见这个人机？
   规则：视距内 + 视野角内 + 没有墙挡着。贴到 120px 以内不用转头也能察觉。
   开热成像则无视以上全部——热源直接可见。 */
/* 「屏幕上到底看不看得见这个人」——给血条 / 命中标记这类 UI 用。
   和 playerSees 的区别：白天也不许隔墙看见。playerSees 在非暗关里直接 return true，
   那是给玩法判定用的（白天本来就该看得见人），但 UI 不能拿它当遮挡判定，
   否则人在屋里、你在屋外，血条会从墙上飘出来，等于给你透视。 */
function playerCanSpot(e){
  if (!e) return false;
  if (player && player.thermal) return true;          /* 热成像：本来就该穿墙 */
  if (companionSharedSees(e)) return true;            /* 队友共享视野 */
  const L = cur();
  if (player && smokeBlocks(player.x, player.y, e.x, e.y)) return false;
  const d = dist(player.x, player.y, e.x, e.y);
  if (d > seeRange(L)) return false;
  if (!sightLine(L, player.x, player.y, e.x, e.y)) return false;   /* 墙 / 车壳 / 门 */
  const foggy = L.blind || !!(L.rules && (L.rules.testFog || L.rules.fog)) ||
                (typeof fogVisionOn === 'function' && fogVisionOn()) || arenaEventOn('blackout');
  if (foggy) return playerSees(e);                    /* 暗关还要管朝向和扇形 */
  return true;
}

function playerSees(e){
  if(companionSharedSees(e))return true;
  const L = cur();
  /* 热成像开机时按「看热量」算：烟、黑暗、掩体全都穿得过去 —— 这就是开关机那 13 秒电量的意义。
     放在烟判定**前面**，否则烟会把热成像一起挡住，等于把这台机器的功能废掉。 */
  if (player && player.thermal) return true;
  /* 烟挡视线：谁扔的都挡玩家（敌人扔的专门就是干这个的）。没开热成像才挡。 */
  if (player && smokeBlocks(player.x, player.y, e.x, e.y)) return false;
  /* blind = 本来就是暗关；testFog = 测试区打开了遮挡（白天也按视野算）；
     fogVisionOn() = 面板上手动开的"视野外隐身"，任何关卡都能用 */
  const foggy = L.blind || !!(L.rules && (L.rules.testFog || L.rules.fog)) ||
                (typeof fogVisionOn === 'function' && fogVisionOn());
  /* 停电事件：黑灯瞎火，视野外的人直接看不见（热成像照样看得见） */
  const evBlack = arenaEventOn('blackout');
  if (!foggy && !evBlack) return true;
  if (player && player.thermal) return true;
  const d = dist(player.x, player.y, e.x, e.y);
  const _pR = seeRange(L) * binoRangeK();
  if (d > _pR) return false;
  if (d > 120){
    const ang = Math.atan2(e.y - player.y, e.x - player.x);
    const _half = seeFov(L) * binoFovK() * Math.PI / 360;
    /* 近了不管头转不转都能发现；远了就得在锥子里，
       边缘那一圈算上身体半径，否则“视野开大了”感觉不出来 */
    const da = Math.abs(normAng(ang - (player.aim || 0)));
    /* 边缘那一几度也算看得见：身体有半径，不能只算中心点 */
    const _rHalf = Math.max(0, (e.r || 12) / Math.max(1, d));
    if (da > _half + _rHalf) return false;
  }
  return sightLine(L, player.x, player.y, e.x, e.y);
}

function enemySees(e, hidden){
  if (typeof godInvis === 'function' && godInvis()) return false;   /* 上帝模式：隐身 */
  if (player.grace > 0) return false;
  if (hidden) return false;
  const d = dist(e.x, e.y, player.x, player.y);
  const T = enemyType(e);
  const _eL = cur();
  const range = enemyVisionRange(e);
  if (d > range) return false;
  /* 玩家在车里时，视线要打到**车身靠过来的那一侧**，不能打到车心：
     车壳是实体，`losBlocked` 会把"敌人→车心"这条线判成被挡，于是站在车里的你
     对敌人等于隐身（用户 m41341「敌人不会打车上的我」）。
     这里把判定点挪到车壳外沿，车壳不再自己挡自己；子弹照样打在车上（那是另一条线）。 */
  let ax = player.x, ay = player.y;
  const _pt = (typeof playerTruck !== 'undefined') ? playerTruck : null;
  if (_pt){
    const _a = Math.atan2(e.y - _pt.y, e.x - _pt.x);
    ax = _pt.x + Math.cos(_a) * (_pt.r + 16);
    ay = _pt.y + Math.sin(_a) * (_pt.r + 16);
  }
  if (losBlocked(e.x, e.y, ax, ay, false, false, e.towerOn)) return false;
  /* 烟挡在中间：只对摄像头生效。普通敌人维持原样（他们只在你"人在烟里"时瞎），
     免得顺手改了前几关的手感。 */
  if ((T.static || T.fly) && smokeBlocks(e.x, e.y, player.x, player.y, true)) return false;
  const a = Math.atan2(player.y-e.y, player.x-e.x);
  const _eFov = enemyFovHalf(e, T)*Math.PI/180;
  return Math.cos(normAng(a - e.ang)) >= Math.cos(_eFov);
}

/* 教程关专用：一大群人从地图外圈（尽量是屏幕外）冲进来，永久加速 */
let tutHordeDone = false;
function spawnHorde(L, n){
  const vx0 = cam.x, vy0 = cam.y, vx1 = cam.x + W, vy1 = cam.y + H;
  const pts = [];
  for (let k=0;k<n;k++){
    const baseA = (k/n)*TAU + rand(-0.16, 0.16);
    let best = null, bestScore = -1e9;
    for (let t=0;t<40;t++){
      const a = baseA + rand(-0.30, 0.30);
      /* 从玩家朝这个方向一直走到撞墙，退回来一点 —— 就是地图外圈上的一点 */
      const far = freeLen(L, player.x, player.y, a, 2400, 10);
      const rr = Math.max(300, far - rand(30, 110));
      const x = clamp(player.x + Math.cos(a)*rr, 46, L.w-46);
      const y = clamp(player.y + Math.sin(a)*rr, 46, L.h-46);
      const q = safeSpot(L, {x:x, y:y}, 26);
      const out = (q.x < vx0-16 || q.x > vx1+16 || q.y < vy0-16 || q.y > vy1+16);  /* 屏幕外 */
      const d = dist(q.x, q.y, player.x, player.y);
      const score = (out ? 2000 : 0) + d;
      if (score > bestScore){ bestScore = score; best = q; }
      if (out && d > 430) break;
    }
    if (best) pts.push(best);
  }
  for (const p of pts){
    const T = ENEMY_TYPES.grunt;
    enemies.push({
      type: 'grunt', x: p.x, y: p.y, r: T.r,
      ang: Math.atan2(player.y-p.y, player.x-p.x),
      wp: [[p.x, p.y]], i: 0, wait: 0,
      mode: 1, lastKnown: {x: player.x, y: player.y},
      alertT: 9e9, seen: false, heard: false, chk: null,
      ammo: CFG.mag, fireCd: rand(0.4,1.2), reloading: 0, muzzle: 0,
      boostT: 9e9                      /* 永久加速：这一关不打算让你跑掉 */
    });
  }
  logWarn('tutorial', '教程关 · 一窝蜂冲进来 ' + pts.length + ' 个（屏幕外 → 内），永久加速');
  setMsg('被它看见了 —— 全都从外面涌进来了。烟能挡住它的视线，重来一次试试', 3.6);
  camShake = 0.8;
}

/* 长廊关的警报：走到一定位置就封门，从左边不断出人往右搜 */
let alarmRushT = 0, alarmSpawnN = 0, alarmOn = false;
/* 警报“快跑”演出：rushFxT 从拉响那一刻计时，rushFxDir 指向撤离点 */
let rushFxT = 0, rushFxDir = 0;
function alarmRushReset(){ alarmRushT = 0; alarmSpawnN = 0; alarmOn = false; rushFxT = 0; rushFxDir = 0; }
function alarmRushUpdate(dt){
  const L = cur();
  if (!L || !L.rules || !L.rules.alarmAt) return;
  /* 没到位置不动作，到了就此生效（一次性） */
  if (!alarmOn){
    const _at = L.start ? L.start.x : 0;
    const _ex = (L.extract && L.extract.x) ? L.extract.x : L.w;
    const _f = (player.x - _at) / Math.max(1, _ex - _at);
    if (_f < L.rules.alarmAt) return;
    alarmOn = true;
    alarmRushT = 0;
    setMsg('警报！他们封了门 —— 左边一直在出人', 3.4);
    camShake = 1.4; hitFlash = 0.78;
    rushFxT = 0;
    (function(){
      const _ex = (L.extract && typeof L.extract.x === "number") ? L.extract : { x: L.w, y: player.y };
      rushFxDir = Math.atan2((_ex.y || player.y) - player.y, _ex.x - player.x);
    })();
    /* 这一刻起换成关卡自带的音乐，警报声自动退到底下 */
    if (L.rules.music) levelMusicStart(L.rules.music);
    logWarn('alarm', '警报启动 · 玩家位置 ' + Math.round(player.x));
  }
  /* 铃声 + 红边：复用摄像头那套（alarm2Lvl 全局控制红边浓度） */
  alarm2Want = 1;
  rushFxT += dt;
  /* 源源不断：每 alarmRush 秒从左边上一个，到上限为止 */
  alarmRushT -= dt;
  if (alarmRushT > 0) return;
  alarmRushT = Math.max(0.4, L.rules.alarmRush || 2.4);
  const cap = L.rules.alarmCap || 20, maxAll = L.rules.alarmMax || 44;
  let live = 0;
  for (const e of enemies){ if (e._rush) live++; }
  /* 注意：不能拿“场上总人数”当上限——这关开局就有 56 个人，
     那样永远满足条件、一个也涌不出来。只管“涌出来的那批”。 */
  if (live >= cap) return;
  if (alarmSpawnN >= maxAll) return;
  alarmSpawnN++;
  const T = ENEMY_TYPES.grunt;
  /* 随机枪：不能一枪到底全是手枪 */
  const _rw = arenaRandom();
  const _wid = _rw < 0.45 ? 'rifle' : (_rw < 0.78 ? 'shotgun' : 'pistol');
  /* 出生点：玩家左边一截（不让他们出现在屏幕里），并且在地图范围内 */
  let sx = player.x - rand(760, 980);
  if (sx < 90) sx = 90;
  const sy = clamp(player.y + rand(-300, 300), 90, (cur().h || 900) - 90);
  const q = safeSpot(cur(), {x: sx, y: sy}, T.r + 6);
  enemies.push({
    type: 'grunt', x: q.x, y: q.y, r: T.r,
    ang: Math.atan2(player.y - q.y, player.x - q.x),
    wp: [[q.x, q.y]], i: 0, wait: 0,
    mode: 1, lastKnown: {x: player.x, y: player.y},
    alertT: 9e9, seen: false, heard: false, chk: null,
    wid: _wid, ammo: (weaponCore(_wid).cap || 6), fireCd: rand(0.3, 1.1), reloading: 0, muzzle: 0,
    _rush: true, boostT: 1.6
  });
}

/* 教程关：摄像头一看见你就叫人来（只叫一次） */
function tutorialHorde(L){
  if (tutHordeDone) return false;
  tutHordeDone = true;
  spawnHorde(L, 10);
  return true;
}

/* 摄像头拉警报：把附近的人机/猎手叫过来，路上还带一段加速 */
function cameraAlarm(cam){
  const T = enemyType(cam);
  cam.alarmCd = T.alarmCd || 3.2;
  cam.pulse = 1;
  sfxAlarm();
  camShake = Math.max(camShake, 0.28);
  let n = 0;
  for (const e of enemies){
    if (enemyType(e).static) continue;
    if (dist(e.x, e.y, cam.x, cam.y) > T.alarmR) continue;
    e.mode = 1; e.heard = false; e.lookT = 0;
    e.alertT = Math.max(e.alertT || 0, CFG.eMemory + 6);
    e.lastKnown = {x: player.x + rand(-40,40), y: player.y + rand(-40,40)};
    e.ang = Math.atan2(e.lastKnown.y-e.y, e.lastKnown.x-e.x);
    e.boostT = T.boostDur || 4;
    n++;
  }
  for (const h of hunters){
    if (dist(h.x, h.y, cam.x, cam.y) > T.alarmR) continue;
    h.state = 'chase';
    h.lastKnown = {x: player.x, y: player.y};
    h.lostT = 0; h.searched = false;
    n++;
  }
  logWarn('camera', (enemyType(cam).kind === 'drone' ? '无人机' : '摄像头') + '看见你了 · 警报 · 叫来 ' + n + ' 个 · 位置 '
          + Math.round(cam.x) + ',' + Math.round(cam.y));
  if (cur().rules && cur().rules.tutorial){ tutorialHorde(cur()); return; }
  setMsg(enemyType(cam).kind === 'drone' ? '被无人机盯上了 —— 有人过来了' : '摄像头看见你了 —— 有人过来了', 1.8);
}

/* 一个人被打，周围的同伴会一起过来看 —— 这是"有人在我们这儿开枪"的正常反应 */
function callAllies(e, ang, source){
  const L = cur();
  source = source || player;
  const own = (typeof combatFaction === 'function') ? combatFaction(e) : (e.faction || e.team || 'enemy');
  const ax = Math.cos(ang + Math.PI), ay = Math.sin(ang + Math.PI);   /* 朝打枪的那边 */
  for (const o of enemies){
    if (o === e) continue;
    const T = enemyType(o);
    if (T.static || T.fly) continue;
    if (typeof combatFaction === 'function' && combatFaction(o) !== own) continue;
    if (Math.hypot(o.x - e.x, o.y - e.y) > 620) continue;             /* 太远的听不见 */
    if (!((o.HM !== undefined ? o.HM : T.hearMul) > 0)) continue;
    if (source && typeof factionWantsFight === 'function' && !factionWantsFight(o, source)){
      if (typeof factionRememberThreat === 'function')
        factionRememberThreat(o, source, FACTION_HATE_DEF.hitGain, FACTION_HATE_DEF.duration, source.x, source.y);
      if (!factionWantsFight(o, source)) continue;
    }
    /* 他们先跑到同伴身边，再从那儿往枪响的方向找 */
    /* 先到中枪同伴附近集结，再沿来弹方向查。射手实体另外写进 lastKnownSource，
       所以到场后仍会锁定 A/B 的真实攻击者，同时保留原有的小队响应节奏。 */
    const sx = e.x + ax * 60;
    const sy = e.y + ay * 60;
    const spot = safeSpot(L, {
      x: sx + rand(-40, 40),
      y: sy + rand(-40, 40)
    }, 14);
    o.lastKnown = spot;
    o.lastKnownSource = source; o.heardSource = source; o.tgtCache = source;
    o.mode = 1; o.heard = true; o.lookT = 0; o.chk = null;
    o.alertT = Math.max(o.alertT || 0, CFG.eMemory + 5);
    o.ang = Math.atan2(spot.y - o.y, spot.x - o.x);
    o.allyGo = true;
    setBark(o, '听见了，过去看看', 1.8);
  }
}

/* 被打中但没死：立刻知道子弹是从哪个方向来的 —— 转身、警戒、往那边压。
   距离越远越不准，不让他一枪就把你的位置锁死。 */
function alertByHit(e, ang, source){
  if (enemyType(e).static) return;
  source = source || player;
  if (!source || source === e) return;
  const wasIdle = (e.mode === 0);
  eStatusSet(e, 'hurt', 0.42);                      /* 身上闪一下，看得见"打到了" */
  /* 已经在攻击这个枪位，持续命中仍正常扣血，避免每颗子弹把交战重置成盲扫。 */
  if (source === e.structureEngaged) return;
  e.mode = 1; e.heard = true; e.lookT = 0; e.chk = null;
  const dd = dist(e.x, e.y, source.x, source.y);
  const jit = Math.min(170, 26 + dd * 0.18);        /* 越远越糊 */
  e.lastKnown = { x: source.x + rand(-jit, jit), y: source.y + rand(-jit, jit) };
  e.lastKnownSource = source; e.heardSource = source; e.tgtCache = source;
  e.alertT = Math.max(e.alertT || 0, CFG.eMemory + 6);
  /* 疼的时候不管看不看得见：朝子弹来的方向先打一梭子，压住对面 */
  /* 一直在打就不重新开一轮 —— 否则每中一枪都重置，能连着打到弹匣空 */
  const _sBusy = eStatusHas(e, 'suppress') || (e.suppressCd || 0) > 0;
  /* 盲扫强度跟难度走：难关压得更久、打得更多、间隔更短、散开更小 */
  const _sdl = Math.max(0, DIFF_ORDER.indexOf(diffName));
  if (enemyType(e).canShoot && (e.ammo || 0) > 0 && !_sBusy){
    eStatusSet(e, 'suppress', rand(1.0, 1.6) + _sdl * 0.55);
    if (typeof tacBump === 'function') tacBump('suppress');
    e.suppressAng = ang + Math.PI + rand(-0.12, 0.12);
    e.suppressN = 2 + Math.floor(arenaRandom() * 2) + _sdl;
    e.suppressGap = Math.max(0.11, 0.34 - _sdl * 0.07);
    /* 盲扫扇面：简单 ±45°（共 90°，扫得散），恶梦 ±35°（共 70°，扫得准） */
    e.suppressJit = (45 - _sdl * (10 / 3)) * Math.PI / 180;
    e.suppressI = 0;
    e.suppressDir = arenaRandom() < 0.5 ? 1 : -1;
    e.suppressStep = (e.suppressJit * 2) / Math.max(1, e.suppressN - 1);
    e.fireCd = Math.min(e.fireCd || 99, rand(0.04, 0.12));
  }
  {
    const _B = behaviorOf(e);
    if(_B.instantAim){ e.spotT=0; e.fireCd=Math.min(e.fireCd||0,_B.instantAimClamp); }
    /* 远处挨枪：躲掩体只会越躲越远（掩体就在他背后），改成先朝枪口方向压。
       近距离（<360px）照旧找掩体——那时候躲是有意义的。 */
    /* 压制锁期间 / 已经缩在掩体里：只许往掩体里缩，绝不再往前顶。
       否则玩家连点几下，他就变成「躲一枪、冲一步」的钟摆。 */
    const _suppressed = (e.rushLockT || 0) > 0
      || (e.hideGoal && (e.hideT || 0) > 0.3);
    if (dd > HIT_FAR_R && enemyType(e).canShoot && !_suppressed){
      e.hideGoal = null; e.coverOK = 0; e.hideT = 0; e.peekPhase = null; e.peekT = 0;
      e.fearT = 0; eStatusClear(e, 'fear');
      e.rushT = Math.max(e.rushT || 0, HIT_RUSH_T);
      e.rushHits = 0; e.rushLeg = 0; e.rushPause = 0; e.rushCov = null;
    } else {
      specSeekCover(e, source);
      /* 已经躲好的：这一枪把他按在掩体里，别让 hideT 攒满又探出去 */
      if (_suppressed && e.hideGoal) e.hideT = 0;
    }
    /* 普通兵没有职业兵的强制转掩体开关，但 NPC 对战也要有机会进入慌乱、
       摇摆跑位、缩头/探头这一整条人格战术链。 */
    if (source !== player && !_B.seekCoverOnNoise && !eStatusHas(e, 'fear'))
      humanFear(e, cur(), Math.min(1, HUMAN.fearP * 0.8), {x:source.x,y:source.y}, source);
  }
  callAllies(e, ang, source);
  /* 转身：先朝子弹来向，再看那个模糊位置 */
  e.ang = ang + Math.PI;
  if (wasIdle) setBark(e, pickBark(['他在哪？朝那个可疑的声音方向开枪',
                                     '可疑的脚步声在这个方向',
                                     '哪来的枪？！']), 2.0);
  if (wasIdle && dist(e.x, e.y, player.x, player.y) < 420) sfxAlarm();
  logWarn('ai', enemyType(e).label + ' 挨了一枪 · 转身搜索 (' + Math.round(e.x) + ',' + Math.round(e.y) + ')');
}

/* 聚到三个人以上：不再一个一个去搜，整队朝那个可疑方向压过去。
   这是"喊人"的结果，不是另一套 AI —— 只有开了 rules.charge 的关卡才会发生。 */
let chargeCd = 0, chargeLockT = 0;
function squadCharge(L, dt){
  chargeCd -= dt;
  if (chargeCd > 0) return;
  chargeCd = 0.5;
  if (chargeLockT > 0){ chargeLockT -= 0.5; return; }   /* 刚冲过：冷却里不再集合 */
  const alive = [];
  for (const e of enemies){
    if (e.dead || enemyType(e).static || enemyType(e).fly) continue;
    if (e.fleeing || e.chargeT > 0) continue;
    if ((e.chargeCd || 0) > 0) continue;      /* 这个兵刚冲完，让它先喘口气 */
    if (e.mode !== 1 || !e.lastKnown) continue;
    alive.push(e);
  }
  if (alive.length < 3) return;
  for (const seed of alive){
    const grp = alive.filter(o => dist(o.x, o.y, seed.x, seed.y) < 300);
    if (grp.length < 3) continue;
    let gx = 0, gy = 0;
    for (const o of grp){ gx += o.lastKnown.x; gy += o.lastKnown.y; }
    gx /= grp.length; gy /= grp.length;
    /* 领头的是离目标最近的那个：它先冲，剩下的跟着 */
    let lead = grp[0], ld = 1e9;
    for (const o of grp){
      const d = dist(o.x, o.y, gx, gy);
      if (d < ld){ ld = d; lead = o; }
    }
    for (const o of grp){
      o.chargeT = 7.5;
      o.chargeGoal = { x: gx + rand(-40, 40), y: gy + rand(-40, 40) };
      o.alertT = Math.max(o.alertT || 0, CFG.eMemory + 8);
      o.path = null; o.goal = null; o.lookT = 0;
    }
    setBark(lead, '人齐了 —— 跟我上！', 2.4);
    chargeLockT = 6.5;                       /* 整队冲一次就歇 6.5 秒 */
    for (const o of grp) o.chargeCd = 9;
    sfxAlarm();
    logWarn('charge', grp.length + ' 个人凑齐了 · 朝 ' +
            Math.round(gx) + ',' + Math.round(gy) + ' 冲');
    setMsg('他们凑够 ' + grp.length + ' 个人了 —— 要一起冲过来', 2.4);
    return;
  }
}

/* 开枪的声音会传出去：附近没看见你的人也会往这边摸 */
/* 静步的脚步声范围：困难以上不再放大。最高就是困难的静步范围，
   最低是简单的静步范围（恶梦成了也不会比困难更大）。 */
const CROUCH_NOISE = 0.35;
function playerHearR(){
  const base = CFG.hearR;
  if (!player || !player.crouch) return base;
  const lo = (PRESETS.easy && PRESETS.easy.hearR ? PRESETS.easy.hearR : base) * CROUCH_NOISE;
  const hi = (PRESETS.hard && PRESETS.hard.hearR ? PRESETS.hard.hearR : base) * CROUCH_NOISE;
  return clamp(base * CROUCH_NOISE, lo, hi);
}

function gunNoise(mul, sx, sy, source, kind){
  /* sx/sy 不传就是"玩家脚下"；爆炸可以指定炸点，让远处的人也往弹坑摸 */
  const qx = (typeof sx === 'number') ? sx : player.x;
  const qy = (typeof sy === 'number') ? sy : player.y;
  const who=source||player;
  if (typeof godSilent === 'function' && godSilent() && who === player) return;   /* 上帝模式：不出声纹 */
  const _kind = kind || 'shot';
  if (who===player && typeof dzLvl !== 'undefined' && dzLvl && typeof dzAlertGain === 'function') dzAlertGain(mul || 1.6);
  const rad = CFG.hearR * (mul || 1.6) * hearMaskK();
  if(typeof factionEmitNoise==='function'){
    factionEmitNoise(who,_kind,qx,qy,rad);
    return;
  }
  for (const e of enemies){
    if (enemyType(e).static) continue;
    if(typeof factionWantsFight==='function'&&!factionWantsFight(e,who))continue;
    if (dist(e.x, e.y, qx, qy) > rad) continue;
    alertBySound(e, qx, qy, who, _kind);
  }
}

/* 听见脚步：不是精确坐标，给一个偏移，人机会慢走过去 */
/* 声音允许有误差，但落脚点不能漂到声源所在实体墙的另一侧。 */
function soundSearchPoint(L,e,x,y,px,py){
  if(!L.rooms?.length)return {x:px,y:py};
  const room=levelRoomAt(L,x,y);
  const r=Math.max(e.r||13,NAV_PAD);
  const local=collisionWalls(L,x,y,48+r);
  function valid(a,b){
    if(a<r+2||b<r+2||a>L.w-r-2||b>L.h-r-2||levelRoomAt(L,a,b)!==room)return false;
    for(const w of local){
      const dx=a-clamp(a,w.x,w.x+w.w),dy=b-clamp(b,w.y,w.y+w.h);
      if(dx*dx+dy*dy<r*r||segHitsRect(x,y,a,b,w))return false;
    }
    return true;
  }
  if(valid(px,py))return {x:px,y:py};
  if(valid(x,y))return {x,y};
  for(const d of [8,16,24,36,48]){
    for(let i=0;i<8;i++){
      const a=x+Math.cos(i*TAU/8)*d,b=y+Math.sin(i*TAU/8)*d;
      if(valid(a,b))return {x:a,y:b};
    }
  }
  return {x,y};
}
function rocketBlastSoundIgnored(e){
  return e.rocketBlastMuteUntil > timeAlive || e.rocketLaunchUntil > timeAlive ||
    e.rocketBlastInvestigateUntil > timeAlive;
}

function alertBySound(e, sx, sy, source, kind){
  /* sx/sy 是"声音从哪来"：默认玩家脚下；爆炸传过去的是炸点 */
  const qx = (typeof sx === 'number') ? sx : player.x;
  const qy = (typeof sy === 'number') ? sy : player.y;
  const who=source||player;
  if(typeof factionWantsFight==='function'&&!factionWantsFight(e,who))return;
  /* 摄像头是装在墙上的，没耳朵，也不会因为一点动静就把脸转过来 */
  if (enemyType(e).static) return;
  if (!((e.HM !== undefined ? e.HM : enemyType(e).hearMul) > 0)) return;
  if(e.dead)return;
  const launch = kind === 'rocketLaunch';
  if (launch) e.rocketLaunchUntil = timeAlive + ROCKET_HEARING.launchPriority;
  if (kind === 'rocketBlast' && rocketBlastSoundIgnored(e)) return;
  const explosion = kind === 'blast' || kind === 'rocketBlast';
  const changedLaunch = launch && (e.lastKnownSource !== who || e.lastSoundKind !== kind);
  /* 爆炸声只当"附近炸了一下"，不当"我知道他在哪"：
     同一批人每隔几秒被自己的爆炸重新点名，就会出现"炸一次来一批、再来一批"的雪球。
     每人对爆炸声 4 秒只认一次，而且目标点抖动更大（听个大概就行）。 */
  if(kind === 'blast'){
    if((e.nadeDeafT || 0) > 0) return;
    e.nadeDeafT = 4.0;
  }
  /* 刚放弃了同一块地方：短暂"不再被同一声源牵着走"，避免来回折返 */
  if (!launch && (e.deafT || 0) > 0 && e.deafSpot && dist(qx, qy, e.deafSpot.x, e.deafSpot.y) < 90) return;
  if (kind === 'rocketBlast') e.rocketBlastInvestigateUntil = timeAlive + ROCKET_HEARING.blastRepeatCooldown;
  /* 支持区域声纹射击的爆炸武器保存原始声音坐标。这里必须早于单发武器的
     换弹掩体拦截：火箭兵躲着装填时听到的新脚步，也要留给下一发使用。 */
  if (typeof explosiveSoundRemember === 'function') explosiveSoundRemember(e,qx,qy,who,kind);
  const _soundW = (typeof gunDef === 'function') ? gunDef({wid:e.wid || 'pistol'}) : null;
  const _soundRepathD = _soundW && _soundW.soundAreaFire === true
    ? Math.max(72,Number(_soundW.soundRepathDist)||180) : 0;
  /* 火箭兵换弹时由自己的状态机解释声纹：近了继续撤，远了且持续外移才追。
     通用听觉分支会清 hideGoal/peekPhase，正是“看不见目标反而不躲”的根因。 */
  if (typeof singleShotCoverHear === 'function' && singleShotCoverHear(e,qx,qy,who)) return;
  e.heardSource=who;
  e.lastKnownSource=who;
  const soundMap=cur();
  const sourceRoom=soundMap.rooms?.length?levelRoomAt(soundMap,qx,qy):null;
  const oldRoom=e.lastKnown&&soundMap.rooms?.length?levelRoomAt(soundMap,e.lastKnown.x,e.lastKnown.y):null;
  const changedRoom=!!(e.lastKnown&&oldRoom!==sourceRoom);
  const foot=kind==='step'&&sourceRoom;
  if(foot){
    const checked=e.roomFootSettled;
    if(!e.sees&&checked&&checked.source===who&&checked.room===sourceRoom&&uiT<checked.until&&
       dist(checked.x,checked.y,qx,qy)<64){
      checked.until=uiT+2;
      return;
    }
  }
  const previous=foot&&e.roomFootClue;
  const stable=previous&&previous.source===who&&previous.room===sourceRoom;
  const soundDelta=stable?dist(previous.x,previous.y,qx,qy):
    (e.lastKnown?dist(e.lastKnown.x,e.lastKnown.y,qx,qy):Infinity);
  const rememberFoot=()=>{if(foot)e.roomFootClue={source:who,room:sourceRoom,x:qx,y:qy};};
  e.heardAt=uiT;                 /* 协同战术据此区分新脚步与陈旧记忆。 */
  if(behaviorOf(e).ignoreStepsInCombat){
    // 看见目标、正在受击/压制或残血撤退时，脚步不能抢走当前战斗行为。
    if(e.sees||e.fleeing||(!launch&&(eStatusHas(e,'hurt')||eStatusHas(e,'suppress')||eStatusHas(e,'stun'))))return;
    const fresh=e.mode!==1||!e.heard||!e.lastKnown||changedRoom||changedLaunch||
      soundDelta>(foot?64:(_soundRepathD||72));
    if(fresh){
      rememberFoot();
      e.lastSoundKind = kind;
      const L=cur(), px=qx+rand(-32,32), py=qy+rand(-32,32);
      e.lastKnown=L.rooms?.length?soundSearchPoint(L,e,qx,qy,px,py):safeSpot(L,{x:px,y:py},e.r||13);
      if(!e.roomSearch){e.path=null;e.goal=null;e.chk=null;e.stuckT=0;e.lookT=0;}
      e.forceT=0;e.forceA=null;e.netT=0;e.netX=e.x;e.netY=e.y;
    }
    const newlyHeard=e.mode!==1||!e.heard;
    e.mode=1;e.heard=true;e.alertT=Math.max(e.alertT||0,CFG.eMemory+8);
    eStatusClear(e,'fear');e.hideGoal=null;e.coverOK=0;e.peekPhase=null;e.peekT=0;e.hideT=0;
    e.tucked=false;e.holding=0;e.holdBackT=0;e.cornerWatch=null;
    e.tacticPhase=null;e.tacStage=null;e.blindShot=false;e.snapPeek=false;
    e.slideT=0;e.slideDir=0;e.strafeT=0;e.strafeDir=0;e.glanceT=0;
    if(newlyHeard){
      /* 声纹只负责给寻路一个调查目标。这里若直接写 e.ang，下一段移动又会把它
         拉回路径方向；连续脚步就表现成“突然左看、突然回正”。转向交给移动层平滑完成。 */
      setBark(e, launch ? '听见火箭筒了，去那边。' : '有脚步，过去看看。',1.8,2);
      if(dist(e.x,e.y,qx,qy)<260)sfxAlarm();
    }
    return;
  }
  /* 白天听得更差：同一套数值要乘上本关的听觉系数 */
  const hearK = (e.HM !== undefined ? e.HM : enemyType(e).hearMul) * cur().rules.hearK;
  /* 抖动别给太大：每走一步目标点就跳几十 px，绕墙时会一会儿绕上、一会儿绕下，
     看着就是贴着墙来回抽。16px 足够表现「听个大概」。 */
  const jitter = explosion ? 32 : 16;
  /* 脚步只用来「刷新这个人在哪」，不能每一下都换目标点：
     人在原地踱步时，目标点每 0.4 秒换一个新位置，
     敌人就会在「直线能走」和「要绕另一头」之间反复切换 —— 贴着墙上下抽就是这个原因。
     所以只有第一次听见、或者他已经走开一段距离（>64px）时才改目标点。 */
  const fresh = e.mode !== 1 || !e.heard || !e.lastKnown || changedRoom || changedLaunch ||
                soundDelta > (foot?64:(_soundRepathD||64));
  const newlyHeard = e.mode !== 1 || !e.heard;
  if (fresh){
    rememberFoot();
    e.lastSoundKind = kind;
    e.lastKnown = soundSearchPoint(cur(),e,qx,qy,qx+rand(-jitter,jitter),qy+rand(-jitter,jitter));
    /* 声源真的换了地方才换路线。同一个位置连续发出脚步声只续记忆，
       不能把已经选好的“绕房左边/右边”每隔 0.34 秒推翻一次。 */
    if(!e.roomSearch){
      e.path=null;e.bladeNavPath=null;e.goal=null;e.chk=null;e.stuckT=0;e.lookT=0;
      e.bladeNavPoint=null;e.bladeNavStall=0;
    }
  }
  e.alertT = Math.max(e.alertT || 0, CFG.eMemory + 8);
  /* 同一位置连续发出的脚步只续警戒时间，不能重置到场环视。
     否则脚步每 0.3~0.5 秒把 lookT 清回 0，人机永远结束不了 1.5 秒环视，
     表现就是已经到场却一直原地左右转。声音真的移开后 fresh=true，才重新追。 */
  if (fresh || newlyHeard) e.lookT = 0;
  /* 已经处在追查模式也必须恢复 heard。旧代码只在 mode!==1 时赋值，
     某些“看见后又丢失”的过渡帧会变成 mode=1、heard=false，随后被射界横移接管。 */
  e.mode = 1; e.heard = true;
  if (newlyHeard){
    /* 不瞬间抢走移动层的朝向控制权；navSteer 会沿实际可走路线平滑转过去。 */
    if (!e.sees) setBark(e, launch ? '听见火箭筒了，去那边。' : pickBark(['谁？出来！！', '谁的脚步声？', '谁在那里？']), 1.8, 2);
    if (dist(e.x,e.y,qx,qy) < 260) sfxAlarm();
  }
}

/* 找出射手到目标之间第一个真实遮挡物。压制射击以前把整条线穿过的所有墙、车
   都拿来候选，第二栋房子甚至无关废车的角也会被选中，于是枪口会突然转向乱扫。
   这里同时纳入墙、门和运兵车，并严格只返回最近的一件。 */
function segRectEntryT(x1,y1,x2,y2,rc){
  let t0=0,t1=1;
  const dx=x2-x1,dy=y2-y1,p=[-dx,dx,-dy,dy];
  const q=[x1-rc.x,rc.x+rc.w-x1,y1-rc.y,rc.y+rc.h-y1];
  for(let i=0;i<4;i++){
    if(Math.abs(p[i])<1e-9){if(q[i]<0)return null;}
    else{
      const t=q[i]/p[i];
      if(p[i]<0){if(t>t1)return null;if(t>t0)t0=t;}
      else{if(t<t0)return null;if(t<t1)t1=t;}
    }
  }
  return t0;
}
function firstSightBlocker(x1,y1,x2,y2){
  const L=cur(),len=Math.hypot(x2-x1,y2-y1);
  if(len<1e-6)return null;
  let best=null;
  const take=(rc,kind,ref,tOverride)=>{
    if(!rc)return;
    /* 射手自己贴着/站在掩体中时，这件物体不是前方的遮挡。 */
    if(x1>rc.x&&x1<rc.x+rc.w&&y1>rc.y&&y1<rc.y+rc.h)return;
    const t=tOverride===undefined?segRectEntryT(x1,y1,x2,y2,rc):tOverride;
    if(t===null||t<0||t>1||(best&&t>=best.t))return;
    best={rect:rc,kind,ref,t};
  };
  for(const w of L.walls)if(!w.glass)take(w,'wall',w);
  for(const d of doors)if(doorSolid(d))take(d,'door',d);
  if(typeof trucks!=='undefined'&&typeof rayTruckT==='function'&&typeof truckRect==='function'){
    const a=Math.atan2(y2-y1,x2-x1);
    for(const t of trucks){
      if(!t||t.tstate==='gone'||(typeof insideTruckBody==='function'&&insideTruckBody(t,x1,y1)))continue;
      const hit=rayTruckT(t,x1,y1,a,len);
      if(hit!==null&&hit!==undefined&&hit>=0&&hit<=len)take(truckRect(t),'truck',t,hit/len);
    }
  }
  return best;
}
function visibleBlockerCorners(e,target,block,pad){
  if(!block)return [];
  const L=cur(),w=block.rect,p=Math.max(22,pad||22);
  const pts=[
    {x:w.x-p,y:w.y-p},{x:w.x+w.w+p,y:w.y-p},
    {x:w.x-p,y:w.y+w.h+p},{x:w.x+w.w+p,y:w.y+w.h+p}
  ],out=[];
  for(const q of pts){
    if(q.x<18||q.y<18||q.x>L.w-18||q.y>L.h-18||losBlocked(e.x,e.y,q.x,q.y))continue;
    out.push({x:q.x,y:q.y,score:dist(q.x,q.y,target.x,target.y)+dist(e.x,e.y,q.x,q.y)*.16});
  }
  return out;
}

/* 丢失视野后架住第一个遮挡物的可见外沿。只用最后已知位置，短时锁定避免左右换角。 */
function enemyWatchCorner(e, target){
  if (!target) return false;
  const old=e.cornerWatch;
  if(old && old.until>uiT && old.nav===navVer && dist(e.x,e.y,old.ex,old.ey)<12){
    e.ang=Math.atan2(old.y-e.y,old.x-e.x); return true;
  }
  let best=null, score=Infinity;
  const block=firstSightBlocker(e.x,e.y,target.x,target.y);
  const basePad=Math.min(64,Math.max(26,(e.r||12)+10,dist(e.x,e.y,target.x,target.y)*.045));
  for(const p of visibleBlockerCorners(e,target,block,basePad)){
    let cost=p.score;
    if(old&&dist(p.x,p.y,old.x,old.y)<8)cost-=36;
    if(cost<score){score=cost;best={x:p.x,y:p.y};}
  }
  if(!best){e.cornerWatch=null;return false;}
  if (!old && typeof tacBump === 'function') tacBump('corner');
  e.cornerWatch={...best,ex:e.x,ey:e.y,until:uiT+.2,nav:navVer};
  e.ang=Math.atan2(best.y-e.y,best.x-e.x);return true;
}

/* 压制射击只瞄“从射手位置真实可见”的目标点/掩体外沿。
   返回空数组表示没有安全射界：宁可不开枪，也不能隔墙锁定目标后乱扫墙面。 */
function tacticalSuppressPoints(e,target){
  if(!e||!target||!Number.isFinite(target.x)||!Number.isFinite(target.y))return [];
  const L=cur();
  if(!losBlocked(e.x,e.y,target.x,target.y))return [{x:target.x,y:target.y}];
  const block=firstSightBlocker(e.x,e.y,target.x,target.y);
  if(!block)return [];
  /* 留出弹道散布的宽度；只贴着 18px 角点瞄，步枪在远距离的随机散布仍会连续打中车壳。 */
  const pad=Math.min(64,Math.max(26,(e.r||12)+10,dist(e.x,e.y,target.x,target.y)*.045));
  const cands=visibleBlockerCorners(e,target,block,pad);
  cands.sort((a,b)=>a.score-b.score);
  const out=[];
  for(const p of cands){
    const a=Math.atan2(p.y-e.y,p.x-e.x);
    if(out.some(q=>Math.abs(normAng(Math.atan2(q.y-e.y,q.x-e.x)-a))<.08))continue;
    out.push({x:p.x,y:p.y});
    if(out.length>=2)break;
  }
  return out;
}

/* 敌人一发子弹的伤害。
   死亡地带（rules.dmgMode === 'gun'）按「手里那把枪原本多少伤害就打多少」算：
   手枪 46 / 步枪 24 / AR 36 / 霰弹每颗 14，再乘这一关的 dmgMul（硬核 1.0、噩梦 1.5）。
   其它关卡没有这个字段，照旧走 CFG.eDmg 那一套难度公式，一行都没动。 */
function enemyBulletDmg(e, N){
  const L = cur();
  const R = L && L.rules;
  if (R && R.dmgMode === 'gun'){
    const wid = e.wid || 'pistol';
    const W = (typeof WEAPONS !== 'undefined' && WEAPONS[wid]) || WEAPONS.pistol || { dmg: 10 };
    return (W.dmg || 10) * (R.dmgMul || 1) * (e.dmgK || 1);
  }
  return CFG.eDmg * (N.dmg || 1) * (e.dmgK || 1) * (ar ? 0.7 : 1) * arenaEnemyDmgK();
}

function enemyShoot(e, ei, aimAngle, spreadMul, target){
  const T = enemyType(e);
  if (!T.canShoot) return false;
  if(e.controller==='companion'&&(e.ammo<=0||e.reloading>0))return false;
  /* 拿着副武器的火箭兵：时间到、路通了就换回火箭筒 */
  if (e.rpgMainWid) rpgSidearmTick(e);
  if (eStatusNo(e, 'noFire')) return false;   /* 眩晕之类的状态：扳机扣不动 */
  if (e && e.towerOn) return false;           /* 塔上只观察不开火（塔是眼睛不是手） */
  // 枪械冷却独立于探头/受击/发现目标的反应时间，不允许状态切换取消。
  if(behaviorOf(e).ownCooldown && (e.specShotRecovery||0)>1e-8)return false;
  const W = gunDef({wid: e.wid || 'pistol'});
  const N = W.npc || {dmg:1, pellets:1, spread:1, rof:1, spd:1};
  /* 盲射不朝你现在的坐标打（那等于隔墙点你），朝你最后露头的位置打 */
  // 已重新看见玩家时，旧的盲射标记不能把枪口拉回背后的记忆点。
  if(e.sees)e.blindShot=false;
  const _tgt = EnemyPerception.shotTarget(e,target);
  if (e.controller==='companion' && (!target || !combatHostile(e,target))) return false;

  if (!_tgt||_tgt===e){ e.blindShot=false; return false; }
  const directed = Number.isFinite(aimAngle);
  const base = directed ? normAng(aimAngle) : Math.atan2(_tgt.y-e.y, _tgt.x-e.x);
  // 不能只查枪口前 26px：远处的墙同样会挡住整条射线。
  const shotRange=Math.max(26,dist(e.x,e.y,_tgt.x,_tgt.y));
  const endX=directed?e.x+Math.cos(base)*shotRange:_tgt.x;
  const endY=directed?e.y+Math.sin(base)*shotRange:_tgt.y;
  /* 定向压制也必须拥有一条真实可见的射线。压制点由 tacticalSuppressPoints 选在
     掩体外沿；这里再做最终校验，防止动态门/新墙让旧压制点变成隔墙扫射。 */
  if (!W.rocket && (!e.sees || directed) && losBlocked(e.x,e.y,endX,endY)){
    if(e.controller!=='companion')enemyWatchCorner(e,_tgt);e.blindShot=false;return false;
  }
  /* 枪口正对着墙就别扣扳机了。
     以前盲射是拿「你最后露头的位置」当靶子，人一躲到掩体另一侧，它就对着自己面前那堵墙
     一梭子一梭子地扫，看起来像傻的。这里沿枪口方向探一小段，撞墙就不打，
     等视线真的开了再开 —— 也就是「拉出去再打」，而不是「隔着墙打」。 */
  const _probe = directed ? 26 : Math.min(26, Math.max(0, dist(e.x, e.y, _tgt.x, _tgt.y)));
  /* 只在「看不见你、还照着印象位置扫」时才拦：看得见你说明中间本来就是空的，
     再探一次会把「贴墙角点射」也误杀（_tEnemyGun 就是被这条误杀过）。 */
  if (!W.rocket && (!e.sees || directed) && _probe > 8 && losBlocked(e.x, e.y, e.x + Math.cos(base)*_probe, e.y + Math.sin(base)*_probe)){ e.blindShot=false; return false; }
  /* 普通枪在走到这里时已经通过了全部射线检查，可以提交开火朝向和后坐力。
     火箭还要在下方解算爆炸落点、墙体传播与友军弹道；若现在先写朝向，失败的
     声纹试射也会把警戒移动中的枪口扯向声源，下一帧寻路再拉回来，形成反复抽动。 */
  if(!W.rocket){
    /* 后坐力真的作用在人身上：不是瞬移，登记一段推力，由 update 在 recKick 内逐帧放完 */
    if (humanOn()){
      e.recPush = (W.recoil || 6) * HUMAN.recPushK;
      e.recAng = base;
    }
    e.ang = base; e.shotAng=base;        /* 开火这一帧的真实朝向必须与弹道相同。 */
    /* 身体（e.angS）只在"站定对枪/边打边走位"时跟着枪口瞬间对齐 —— 枪口必须对着弹道。
       但「正在跑向掩体」（peekPhase==='run'）是一次转身：这时候再瞬间掰，
       跑动中连开两枪就成了"九十度转弯再转弯、快得像瞬移"。跑掩体期间交给 turnSpd 慢慢追。 */
    if (e.angS !== undefined && e.peekPhase !== 'run') e.angS = base;
  }
  /* 战斗，爽！！：人多枪多，再准就没法玩了 —— 散布放大、伤害压低 */
  const sp = CFG.spread * Math.PI/180 * (N.spread || 1) * (ar ? 1.9 : 1) *
             (Number.isFinite(spreadMul) ? Math.max(0, spreadMul) : (e.blindShot ? 3.2 : 1)) *
             (behaviorOf(e).aimError || 1);
  /* 火箭筒：不是"子弹"，是一发飞出去的弹丸，撞到东西才炸。
     刻意不走下面的子弹循环 —— 火箭弹必须带 turretRocket 标记，
     否则撞玩家的判定（`!b.rocket` 那一行）会把它整个跳过。 */
  if (W.rocket){
    /* 贴脸绝不发射：这一炮等于同归于尽（门槛走 DataRPG.minRange） */
    const _D = rpgDef();
    const _pd = dist(e.x, e.y, _tgt.x, _tgt.y);
    const _minR = (_D && _D.minRange !== undefined) ? _D.minRange : 130;    if (shotRange < _minR || _pd < _minR){
      /* 太近：这一炮会把自己也点着。以前只是"站着不发射"，对面上来贴脸就永远哑火；
         现在退半步（RPG 兵才有），拉开一点距离就能打 —— 用户 m41130 说"对玩家很利索、
         对 A/B 很苛刻"，就是因为 A/B 会冲到脸上来。 */
      /* 纯声纹只是一个区域估计，隔墙听见近距离脚步时不能把它当作贴脸实体，
         否则警戒寻路要往前查、rpgBackpedal 又每次把人往后拽，贴墙就会一抽一抽。 */
      if (_pd < _minR && !_tgt.fromSound && typeof rpgBackpedal === 'function') rpgBackpedal(e);
      e.fireCd = 0.7; e.blindShot = false;
      return false;
    }
    /* —— 从这里开始换成"打爆炸落点" ——
       求解器同时保证枪口能打到落点、爆炸也能从落点传到目标；
       所有可覆盖落点都失败时才退回目标坐标，再由下面的射界逻辑决定是否换位。 */
    const structure = _tgt.structureWall;
    const _spot = !structure && (typeof rpgAreaSpot === 'function') ? rpgAreaSpot(e, _tgt, _D) : null;
    const _ax = structure ? structure.x + structure.w/2 : (_spot ? _spot.x : _tgt.x);
    const _ay = structure ? structure.y + structure.h/2 : (_spot ? _spot.y : _tgt.y);
    const _aimA = Math.atan2(_ay - e.y, _ax - e.x);
    const _aimD = dist(e.x, e.y, _ax, _ay);
    /* 中间有墙/车：这一炮会打在墙上白给。先侧移让射界，让不开就先不打。 */
    if (typeof losBlocked === 'function' && losBlocked(e.x, e.y, structure ? _tgt.x : _ax, structure ? _tgt.y : _ay)){
      e.fireCd = Math.max(e.fireCd || 0, (_D && _D.ffCd * 2) || 0.7);
      /* 声纹落点全部无效、只能回退直瞄时，继续走警戒调查路线。
         不让“侧移找射界”与寻路同时争夺移动权；真实看见目标仍照旧侧移。 */
      if (_tgt.fromSound){
        e.blindShot = false;
        return false;
      }
      if (!rpgSidestep(e,{x:_ax,y:_ay})) e.blindShot = false;
      return false;
    }
    /* 弹道上压着自己人：放弃这一炮，记一笔；等太久就换副武器 */
    if (rpgTraceBlocked(e, _aimA, Math.min(_aimD + 60, 900))){
      e.fireCd = Math.max(e.fireCd || 0, (_D && _D.ffCd) || 0.35);
      e.blindShot = false;
      /* 声纹试射失败不能累计“队友挡弹道”并触发侧移。声纹每走一步都会刷新，
         若在这里调用 rpgNoteBlocked，就会每隔一两个脚步把警戒中的人横拽一次。 */
      if (_tgt.fromSound) return false;
      rpgNoteBlocked(e,{x:_ax,y:_ay});
      return false;
    }
    e.rpgBlockT = 0;
    /* 落点随目标移动每炮都换：不开镜、不点射，就是往那片地儿糊一发 */
    e.ang = _aimA; e.shotAng = _aimA;
    if (e.angS !== undefined && e.peekPhase !== 'run') e.angS = _aimA;
    if (humanOn()){ e.recPush = (W.recoil || 6) * HUMAN.recPushK; e.recAng = _aimA; }
    /* m44395：以前敌人这发只有 540，玩家同款是 ROCKET_SPD(1000)，
       肉眼就是"慢慢飘过来"。改成跟玩家同速（可在 DataRPG.spd 覆盖）。 */
    const _rspd = rpgBulletSpeed();
    const _rocket=spawnBullet(e.x + Math.cos(_aimA)*24, e.y + Math.sin(_aimA)*24, e.x, e.y,
                              Math.cos(_aimA)*_rspd, Math.sin(_aimA)*_rspd,
                              e, (_D && _D.projectileLife) || 3.2, 120, true, ROCKET_BODY_R, !structure);
    /* “朝落点方向飞”还不够：没有这枚空炸引信，弹丸会穿过解算点继续直飞，
       视频里就像整发打歪。撞墙/撞人仍可在到点前提前引爆。 */
    if(_rocket && !structure){
      _rocket.landFuse=true;_rocket.landX=_ax;_rocket.landY=_ay;
      /* 保存“这一炮想炸谁/哪片声纹”。进入爆炸覆盖圈后，引信只做一次前向最高伤害解算；
         不按兵种名写死，未来其它直射爆炸武器也可给弹丸打开 smartFuse。
         开关在 DataRPG.airburst：默认关（玩家会看到落点自己往前跳），只在军团对抗开。 */
      if (typeof rpgAirburstOn !== 'function' || rpgAirburstOn()){
        _rocket.smartFuse=true;
        _rocket.fuseTargetX=_tgt.x;_rocket.fuseTargetY=_tgt.y;
        _rocket.fuseTargetRef=_tgt.fromSound?null:_tgt;
        _rocket.fuseLookAhead=(_D&&_D.airburstLookAhead)||0;
        _rocket.fuseStep=(_D&&_D.airburstStep)||0;
        _rocket.fuseGain=(_D&&_D.airburstGain)||0;
      }
    }
    spawnPart(e.x + Math.cos(_aimA) * 22, e.y + Math.sin(_aimA) * 22, _aimA, 300, 0.13, 'flash', 11);
    spawnPart(e.x + Math.cos(_aimA) * 18, e.y + Math.sin(_aimA) * 18, _aimA + Math.PI, 120, 0.30, 'smoke', 8);
    if (actx && typeof sfxRocketFire === 'function') sfxRocketFire(e.x, e.y);
    else if (!enemyGunSfx(e.x, e.y, 'rpg')) sfxShot();
    e.muzzle = 0.13;
    e.blindShot = false;
    e.fireCd = 0.35;                    /* 只留抬枪时间：装填交给 enemyReloadTime（火箭筒 3.4s × 难度系数） */
    if (humanOn()){ e.recT = 0.52; e.recMax = 0.52; }
    gunNoise(ROCKET_NOISE_FIRE, e.x + Math.cos(_aimA)*24, e.y + Math.sin(_aimA)*24, e, 'rocketLaunch');
    return true;
  }
  /* 枪口焰要画在「真正打出这一发」的方向上：e.ang 是身体朝向，转身时它和
     射击角（base）差十几度，火光就会飘到脑袋上，看着像凭空多了一枚子弹。 */
  e.mzA = base;
  const n = N.pellets || 1;
  const spd = CFG.bulletSpd * (N.spd || 1);
  for (let i = 0; i < n; i++){
    const a = base + rand(-sp, sp);
    spawnBullet(e.x + Math.cos(a)*16, e.y + Math.sin(a)*16, e.x, e.y,
                Math.cos(a)*spd, Math.sin(a)*spd, e, 3,
                enemyBulletDmg(e, N),
                false, 0, false);
  }
  /* 难度定了基础射速，割草里还要按“爬档”往上加；但必须有硬上限，
     否则后期一屏人一秒几十发，玩家没有任何反应窗口。
     上限本身是数据（data/ai.js 的 DataROF_CAP）：硬核等模式在
     game/14-enemytypes.js::enemyRofCap() 里按模式取倍率，这里不再写死常数。 */
  const _rofCap = (typeof enemyRofCap === 'function')
    ? enemyRofCap(enemyRofTierKey(), e.wid) : ARENA_REF_ROF;
  const _rof = Math.min(_rofCap, CFG.fireRate * weaponCore(e.wid).npcRof * (ar ? arenaRofMul() : 1)
                        * (humanOn() ? (TAC.fireK || 1) : 1));
  e.fireCd = 1/Math.max(0.05, _rof);
  /* 霰弹枪：人机不能"一次全喷完再连喷"，给它多加一道间隔 */
  if ((e.wid || '') === 'shotgun') e.fireCd *= (TAC.shotgunK || 1);
  {
    const _SR = behaviorOf(e).shotRecover;
    if(_SR){
      e.fireCd=Math.min(e.fireCd, e.wid==='shotgun'?_SR.shotgun:_SR.other);
      e.specShotRecovery=e.fireCd;
    }
  }
  e.muzzle = 0.08;
  e.blindShot = false;
  /* 开枪后坐力：身体/枪一起往后一顿，然后慢慢回位（人机专用的长曲线） */
  if (humanOn()){ e.recT = HUMAN.recKick + HUMAN.recBack; e.recMax = e.recT; }
  else { e.recT = 0.18; e.recMax = 0.18; }
  /* 敌人开枪声：全场共用固定几个槽位，按屏幕左右分声像、按距离衰减
     （不给每个小兵建播放器） */
  if (typeof enemyGunSfx === 'function'){
    if (!enemyGunSfx(e.x, e.y, e.wid || 'pistol')) sfxShot();
  } else sfxShot();
  if(typeof factionHearShot==='function')factionHearShot(e,e.x,e.y);
  logInfo('shot', '人机#' + ((ei|0)+1) + ' 用' + W.name + ' 开枪 · ' + n + ' 发 · 余弹 ' + Math.max(0, e.ammo-1));
  return true;
}

