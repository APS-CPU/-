/* ================= 精英投雷（frag） =================
   复用玩家那颗雷的物理与爆炸（nades / updateNades / nadeBlast），
   这里只多做三件事：什么时候扔、扔到哪、扔完进冷却。 */
function enemyThrowDef(){
  return (typeof DataTHROW === 'object' && DataTHROW) ? DataTHROW : null;
}
function enemyCanThrow(e,roomEntry=false){
  const TH = enemyThrowDef();
  if (!TH || TH.on === false) return false;
  if (!e || e.dead || !player || player.hp <= 0) return false;
  const T=enemyType(e);
  return roomEntry ? T.canShoot && !T.static : T.canThrow === true;
}
/* 它"以为"目标在哪：只听/只看过一次的余温（lastKnown）。
   没有这一条就完全不扔 —— 只是头上顶个问号并不代表它知道你在哪。
   alertT 掉光了也当作不知道（记忆过期）。 */
function enemyNadeTarget(e){
  if (!e || !e.lastKnown) return null;
  if ((e.alertT || 0) <= 0) return null;
  const lk = e.lastKnown;
  if (!isFinite(lk.x) || !isFinite(lk.y)) return null;
  return { x: lk.x, y: lk.y };
}
/* 室内外互斥：屋里的人不往屋外扔、屋外的人也不往屋里扔。
   判据是"施法者所在的房间"和"落点所在的房间"必须同一间（同为室外也算同一间）。 */
function nadeRoomOK(L, e, x, y){
  if (!L || !L.rooms || !L.rooms.length) return true;
  return levelRoomAt(L, e.x, e.y) === levelRoomAt(L, x, y);
}
/* 落点：目标身后一点点 + 横向随机；先过 safeSpot，免得扔进墙里 */
function enemyNadeSpot(L, e, tgt){
  const TH = enemyThrowDef();
  const T = tgt || enemyNadeTarget(e);
  if (!T) return null;
  const a = Math.atan2(T.y - e.y, T.x - e.x);
  const back = TH.back[0] + Math.random() * (TH.back[1] - TH.back[0]);
  const side = (Math.random() * 2 - 1) * TH.spread;
  /* 径向随机误差：一群人扔出来的雷不该全部砸在同一个点上。
     还在"看不见"状态里，误差随时间放大 —— 它是凭记忆扔的，不是透视。 */
  const missA = Math.random() * TAU;
  const missK = TH.miss + Math.min(TH.missBlind || 60, (e.throwHideT || 0) * 14);
  const missR = Math.random() * missK;
  const raw = {
    x: T.x + Math.cos(a) * back + Math.cos(a + Math.PI / 2) * side + Math.cos(missA) * missR,
    y: T.y + Math.sin(a) * back + Math.sin(a + Math.PI / 2) * side + Math.sin(missA) * missR
  };
  /* 不许炸到自己：落点离投掷者至少 selfR（默认 200，比爆炸半径 170 再远一点）。
     少了这一步，只要"他以为的你"离得近、随机误差又朝他那头偏，雷就落自己脚下了。 */
  const selfR = (TH.selfR === undefined) ? 200 : TH.selfR;
  {
    const dx0 = raw.x - e.x, dy0 = raw.y - e.y;
    const d0 = Math.hypot(dx0, dy0);
    if (d0 < selfR){
      const ux = (d0 > 1) ? (dx0 / d0) : Math.cos(a);
      const uy = (d0 > 1) ? (dy0 / d0) : Math.sin(a);
      raw.x = e.x + ux * selfR;
      raw.y = e.y + uy * selfR;
    }
  }
  if (!L || !L.walls) return raw;
  /* pad 只用 4：你脚下一定是能站人的，pad 给大了 safeSpot 会把你从掩体后推到墙外面 */
  let spot = safeSpot(L, raw, 4);
  /* 落点得和"它以为的你"在同一片空地（中间不隔墙），也别跨房间 */
  if (!clearWalkLine(L, spot.x, spot.y, T.x, T.y) || !nadeRoomOK(L, e, spot.x, spot.y)){
    /* 退路：沿"敌→你"方向推到 selfR 外，别再退回到你脚上（那等于贴着自己扔） */
    spot = safeSpot(L, { x: e.x + Math.cos(a) * selfR, y: e.y + Math.sin(a) * selfR }, 4);
  }
  /* 最后一关：还是太近就干脆别扔（宁可不开这个前摇，也不能自爆） */
  if (dist(e.x, e.y, spot.x, spot.y) < selfR - 8) return null;
  return spot;
}
/* 场上还有几颗"人机扔的"雷（含落地待炸的）—— 用来限流，别一群人一起扔 */
function nadeLiveEnemy(){
  let n = 0;
  for (const g of nades) if (g && g.enemyNade) n++;
  return n;
}
/* 落点上有非敌对 NPC 时跳过，避免让他们被自己的队伍逼退或打断动作。 */
function enemyNadeCrowded(e,x,y){
  if(typeof factionWantsFight!=='function')return false;
  const r=NADE_R*.95, r2=r*r;
  for(const o of enemies){
    if(!o || o===e || o.dead || o.gone)continue;
    if((o.x-x)**2+(o.y-y)**2<r2 && !factionWantsFight(e,o))return true;
  }
  return false;
}
/* 举着手这段时间里如果又听见脚步（新的声纹位置），撒手时就朝"刚听到的那边"扔。
   只认**比举起手更晚**的听觉更新，免得被旧的记忆拽回去；落点仍要过一遍几何校验。
   注意：这里只算一个候选点、不改 entry —— 前摇中途改 entry 会让撒手复核失败，整颗雷卡死。 */
function enemyNadeReaimPoint(L,e,entry,TH){
  if(!entry || !TH) return null;
  const cfg = TH.roomEntry || {};
  if(cfg.reaim === false) return null;
  if(!e || !isFinite(e.heardAt) || !e.lastKnown) return null;
  const since = (entry.at === undefined) ? -1e9 : entry.at;
  if(!(e.heardAt > since)) return null;
  const p = e.lastKnown;
  if(!isFinite(p.x) || !isFinite(p.y)) return null;
  const d = Math.hypot(p.x - e.x, p.y - e.y);
  if(d < (TH.minR || 150) || d > (TH.maxR || 400)) return null;
  /* 自己上一颗刚落在同一个声音点附近时别改 —— 改过去就是"两颗叠在一点"，
     交给 enemyDoorFragSpot 的 avoid 列表去拉开距离更稳（见下面补投避让）。 */
  if(e._lastDoorNade){
    const _ms = (TH.minSeparation === undefined) ? 42 : TH.minSeparation;
    if(Math.hypot(p.x - e._lastDoorNade.x, p.y - e._lastDoorNade.y) < _ms) return null;
  }
  const order = entry.order;
  if(order && typeof enemyDoorFragActiveFrame === 'function'){
    const f = enemyDoorFragActiveFrame(L,e,order);
    if(!f) return null;
    if(typeof enemyDoorFragLanding === 'function' && !enemyDoorFragLanding(L,e,order.room,f,p.x,p.y,TH)) return null;
  }
  /* 两个人一起改落点时别砸到同一个点：按"投掷者→声音点"的垂线各偏一半，天然拉开 sepGuard */
  let bx = p.x, by = p.y;
  const sep = cfg.sepGuard === undefined ? 42 : cfg.sepGuard;
  if(order && order.slots && order.slots.length > 1){
    const _idx = order.slots.findIndex(sl => sl && sl.owner === e);
    const _sgn = (_idx % 2 === 0) ? 1 : -1;
    const _perp = Math.atan2(p.y - e.y, p.x - e.x) + Math.PI / 2;
    let _placed = false;
    for(const _f of [0.5, 0.36, 0.26, 0.18]){
      const nx = p.x + Math.cos(_perp) * _sgn * sep * _f;
      const ny = p.y + Math.sin(_perp) * _sgn * sep * _f;
      if(typeof enemyDoorFragActiveFrame === 'function'){
        const f2 = enemyDoorFragActiveFrame(L,e,order);
        if(f2 && typeof enemyDoorFragLanding === 'function' && !enemyDoorFragLanding(L,e,order.room,f2,nx,ny,TH)) continue;
      }
      bx = nx; by = ny; _placed = true; break;
    }
    /* 偏移点都过不了几何校验：宁可不改，也别让两颗雷砸到同一个点上 */
    if(!_placed) return null;
  }
  /* 已经飞在空中/刚落地的那颗雷也是"别人的落点"：贴太近就宁可按原计划扔 */
  const _minS = (TH.minSeparation === undefined) ? 42 : TH.minSeparation;
  if(typeof nades !== 'undefined' && nades){
    for(const _n of nades){
      if(!_n || _n.dead || !_n.enemy) continue;
      if(Math.hypot(_n.tx - bx, _n.ty - by) < _minS) return null;
    }
  }
  return { x: bx, y: by };
}
/* 2026-11-25：已经抬手却被挤进屋 / 站位失效时的应急落点。
   目标房内挑「离自己最远、不撞墙」的点；只要求距离不小于最小投掷距离的一半，
   宁可扔得近一点，也不要把已经拉环的那一颗吞掉。 */
function enemyNadePanicSpot(L, e, room, TH, accept, score){
  if (!room || !isFinite(room.x) || !isFinite(room.w)) return null;
  const _minR = (TH && TH.roomEntry && TH.roomEntry.minRange) ? TH.roomEntry.minRange : 88;
  const minD = Math.max(48, _minR * 0.55);
  let best = null, bd = -1;
  const step = 40;
  for (let y = room.y + 30; y <= room.y + room.h - 30; y += step){
    for (let x = room.x + 30; x <= room.x + room.w - 30; x += step){
      if (typeof navBlockedAt === 'function' && navBlockedAt(L, x, y)) continue;
      const d = Math.hypot(x - e.x, y - e.y);
      if (d < minD) continue;
      const point={x,y}, value=score ? score(point) : d;
      if (value > bd && (!accept || accept(point))){ bd = value; best = point; }
    }
  }
  return best;
}
/* 真的撒手：朝落点方向给初速。整段飞行是"抛物线"，途中不跟墙碰 —— 到点直接落定（见 updateNades）。 */
function enemyLobNade(L, e){
  const TH = enemyThrowDef();
  if (!TH) return false;
  const entry=e.roomEntryThrow;
  if(entry)e.roomEntryThrow=null;
  /* 撒手前再核一次：场上已经够多了就不扔（前摇期间别人可能先扔了） */
  if (nadeLiveEnemy() >= (TH.maxLive === undefined ? 2 : TH.maxLive)){ e.throwT = 0; return false; }
  let at;
  const avoid=entry?.round ? nadeRoundSpotAvoid(entry.round,e) : null;
  const spaced=point=>!avoid || nadeRoundSpotClear(point,avoid);
  const uncrowded=point=>!enemyNadeCrowded(e,point.x,point.y);
  if(entry){
    const order=entry.order, f=enemyDoorFragActiveFrame(L,e,order);
    if(f){
      /* 前摇期间又听见脚步 → 优先朝"刚听到的那边"扔；几何不过就退回原计划 */
      const _re = (!(entry.order && entry.order.slots) && typeof enemyNadeReaimPoint === 'function') ? enemyNadeReaimPoint(L,e,entry,TH) : null;
      const _cand = _re || { x: entry.x, y: entry.y };
      if(spaced(_cand) && enemyDoorFragLanding(L,e,order.room,f,_cand.x,_cand.y,TH) && uncrowded(_cand)){
        at = _cand;
      }else if(avoid){
        at = nadeRoundPickSpot(L,e,f,avoid,TH,uncrowded);
      }else{
        at = enemyDoorFragSpot(L,e,order,f,TH);
      }
    }
  }else{
    const tgt = enemyNadeTarget(e);
    if(tgt && nadeRoomOK(L,e,tgt.x,tgt.y))at=enemyNadeSpot(L,e,tgt);
  }
  /* 同一轮/同一门口的补投：刚砸过的地方别再砸一遍 —— 具体避让交给 enemyDoorFragSpot 的 avoid 列表处理 */
  /* 旧路径的补投：同一扇门、同一个 order 里第二颗常常算出同一个点（order.nade 换新对象就丢了记忆）。
     用投掷者自己的上一颗落点兜一下，太近就沿垂线挪开 —— 保证"两颗"看得见是两颗。 */
  if (entry && at && !entry.round && e._lastDoorNade){
    const _ms = (TH.minSeparation === undefined) ? 42 : TH.minSeparation;
    const _ax = (at.tx !== undefined ? at.tx : at.x);
    const _ay = (at.ty !== undefined ? at.ty : at.y);
    if (Math.hypot(_ax - e._lastDoorNade.x, _ay - e._lastDoorNade.y) < _ms){
      const _perp = Math.atan2(_ay - e.y, _ax - e.x) + Math.PI / 2;
      const _order = entry.order;
      const _f = (typeof enemyDoorFragActiveFrame === 'function') ? enemyDoorFragActiveFrame(L, e, _order) : null;
      const _try = (dx, dy) => {
        const x = _ax + dx, y = _ay + dy;
        if (typeof enemyDoorFragLanding === 'function' && _f && _order &&
            !enemyDoorFragLanding(L, e, _order.room, _f, x, y, TH)) return null;
        if (enemyNadeCrowded(e, x, y)) return null;
        return { x: x, y: y, tx: x, ty: y };
      };
      const _c1 = _try(Math.cos(_perp) * _ms, Math.sin(_perp) * _ms) ||
                  _try(-Math.cos(_perp) * _ms, -Math.sin(_perp) * _ms);
      /* 两侧都放不下就宁可贴着原地扔（至少那一颗是成功的），别把雷丢到房外 */
      if (_c1) at = _c1;
    }
  }
  /* 已经起手的一颗：哪怕人已经被挤进屋、门框几何对不上了，也把雷扔进房里，不许吞雷 */
  if (!at && entry){
    const _room = entry.order ? entry.order.room : null;
    const inRoom=point=>levelRoomAt(L,point.x,point.y)===_room;
    const accept=avoid ? point=>spaced(point) && inRoom(point) : null;
    const frame=avoid?.spots.length && entry.order.door && roomDoorFrame(entry.order.door);
    const score=frame ? point=>nadeRoundCoverageScore(point,avoid,frame) : null;
    at = enemyNadePanicSpot(L,e,_room,TH,accept,score) ||
         (isFinite(entry.x) && isFinite(entry.y) && spaced(entry) ? {x:entry.x,y:entry.y} : null);
  }
  if (!at){
    if(avoid)nadeRoundCancel(e,'no-spot');
    e.throwT=0;
    return false;
  }
  if(!entry && enemyNadeCrowded(e,at.x,at.y)){
    e.throwT=0;e.throwCd=Math.max(e.throwCd||0,1.6);
    return false;
  }
  const a = Math.atan2(at.y - e.y, at.x - e.x);
  /* 出手点在手上，不是脚下 —— 距离要从出手点量，否则飞行时间对不上，落地会瞬移一小段 */
  const sx = e.x + Math.cos(a) * (e.r + 4);
  const sy = e.y + Math.sin(a) * (e.r + 4);
  const d = Math.hypot(at.x - sx, at.y - sy);
  const flight = Math.max(0.22, d / Math.max(120, TH.v0));
  /* 引信抖动：落地后还要多久炸，每颗都不一样（fuseJit 是相对幅度）。
     用户要"随机一点有点波动" —— 固定 1.45 秒等于能背秒数，一抖就变成"它可能随时炸"。 */
  const _jit = (TH.fuseJit === undefined ? 0.24 : TH.fuseJit);
  const _fuseAfter = TH.fuse * (1 + (Math.random() * 2 - 1) * _jit);
  const nade={
    x: sx, y: sy,
    vx: (at.x - sx) / flight, vy: (at.y - sy) / flight,   /* 匀速直达：t=flight 时刚好在落点 */
    tx: at.x, ty: at.y, lobT: flight, lobDone: false,     /* 抛掷：空中段越过掩体 */
    fuse: flight + _fuseAfter, age: 0, spin: 0, rest: false, by: e, enemyNade: true, sndT: 0
  };
  nades.push(nade);
  /* 记住这颗的落点：后来的人挑落点时要和它拉开距离（跨轮次也管） */
  if (typeof nadeSpotRemember === 'function') nadeSpotRemember(at.x, at.y);
  if(entry){
    e._lastDoorNade = { x: at.x, y: at.y, t: uiT };
    /* 新路径：这颗粒记到轮次 slot 上（一次性，重复调用同一颗）；旧路径维持 follow 记账 */
    if(typeof nadeRoundOn==='function' && nadeRoundOn() && entry.round) nadeRoundReleased(e,nade);
    else enemyDoorFragReleased(entry.order,nade,TH);
  }
  e.throwCd = TH.cd;
  e.throwT = 0;
  e.throwHideT = 0;
  e.fireCd = Math.max(e.fireCd || 0, 0.45);
  sfxThrow();
  setBark(e, '雷！', 1.4, 1, false);
  logInfo('nade', '投雷 · 距离 ' + Math.round(d) + 'px');
  return true;
}
/* 每帧推进：冷却 → 判定 → 前摇 → 撒手 */
function enemyThrowTick(L, e, dt){
  const TH = enemyThrowDef(), entry=e.roomEntryThrow;
  if (!TH || TH.on === false){
    if(entry){e.roomEntryThrow=null;e.throwT=0;}
    return;
  }
  if ((e.throwCd || 0) > 0) e.throwCd = Math.max(0, (e.throwCd || 0) - dt);
  /* 2026-11-25：已经抬手的这一颗，不许因为「中途看见玩家 / 被挤出原位」而取消。
     只要不是真的不能扔（死亡/眩晕/被压制），就把它扔完。 */
  const _committedThrow = !!(entry && ((e.throwT||0) > 0) && (entry.round || entry.order));
  if (!enemyCanThrow(e,!!entry) || (entry && !_committedThrow && !enemyDoorFragActiveFrame(L,e,entry.order))){
    if(typeof NADE_ROUND!=='undefined'){const _d=NADE_ROUND.dbg||(NADE_ROUND.dbg={});
      const _k=!enemyCanThrow(e,!!entry)?'x-can':'x-active';_d[_k]=(_d[_k]||0)+1;}
    if(entry){
      /* 前摇被打断：显式记一条取消原因（死亡/眩晕/门关/情报失效/被车挤开都能看出来） */
      if(typeof nadeRoundCancel==='function' && entry.round) nadeRoundCancel(e,'inactive');
      /* 前摇被打断（眩晕/门关/被挤开）就不要再试：直接放弃破门、走进屋里搜。
         旧实现取消后 `s.entryFrag` 作废、由兜底计时接管；换成轮次后必须显式告诉搜房
         "这一趟别扔了"，否则它会原地再起一轮、被同一次眩晕反复打断。 */
      if(e && e.roomSearch){ e.roomSearch.fragGiveUp = true; e.roomSearch.fragAt = uiT; }
      e.roomEntryThrow=null;
    }
    e.throwT=0;e.throwHideT=0;
    return;
  }
  if ((e.throwT || 0) > 0){
    /* 前摇中挨了眩晕/被门夹：立刻放弃这一颗（旧路径靠别处清 throwT，新路径必须显式收尾） */
    if (entry && eStatusHas(e, 'stun')){
      if(typeof nadeRoundCancel==='function' && entry.round) nadeRoundCancel(e,'stun');
      if(e.roomSearch){ e.roomSearch.fragGiveUp = true; e.roomSearch.fragAt = uiT; }
      e.roomEntryThrow = null;
      e.throwT = 0; e.throwHideT = 0;
      return;
    }
    /* 前摇：站定、抬枪压下去，头顶响提示音（落点在前摇里不写死，撒手那一刻再按最新听觉定） */
    e.throwT = Math.max(0, e.throwT - dt);
    e.fireCd = Math.max(e.fireCd || 0, 0.15);
    if ((e.throwBeepT || 0) <= 0){ e.throwBeepT = 0.33; sfxPin(); }
    else e.throwBeepT -= dt;
    if (e.throwT <= 0) enemyLobNade(L, e);
    return;
  }
  if (eStatusHas(e, 'stun') || e.sees){ e.throwHideT = 0; return; }
  if ((e.throwCd || 0) > 0){ e.throwHideT = 0; return; }
  /* 全队限流：别四个人一起掏雷。
     ①容量（场上敌雷 + 已预约未出手，各计一次）到顶 → 谁都不许再扔；
     ②离上一颗撒手不到 gap 秒 → 想扔也先等着（谁先满足条件谁先扔，天然错开）。 */
  const _capNow=(typeof nadeRoundOn==='function' && nadeRoundOn() && typeof nadeRoundCapacity==='function')
    ? nadeRoundCapacity().total : nadeLiveEnemy();
  if (_capNow >= (TH.maxLive === undefined ? 2 : TH.maxLive)){ e.throwHideT = 0; return; }
  if (nadeSquadCd > 0) return;
  /* 它得"有你的下落"才扔：只有 ?? 不算知道，记忆过期（alertT 归零）也不算。
     这一条就是不许它凭"侦察兵雷达"精准砸人。 */
  const tgt0 = enemyNadeTarget(e);
  if (!tgt0){ e.throwHideT = 0; return; }
  /* 室内外互斥：屋外的不往屋里扔，屋里的也不往屋外扔 */
  if (!nadeRoomOK(L, e, tgt0.x, tgt0.y)){ e.throwHideT = 0; return; }
  const d = dist(e.x, e.y, tgt0.x, tgt0.y);
  if (d < TH.minR || d > TH.maxR){ e.throwHideT = 0; return; }
  e.throwHideT = (e.throwHideT || 0) + dt;
  if (e.throwHideT < TH.hiddenSec) return;
  startEnemyThrow(e,TH);
}
function startEnemyThrow(e,TH,noSquad){
  e.throwHideT = 0;
  e.throwT = TH.windup;
  e.throwBeepT = 0;
  if(!noSquad) nadeSquadCd = (TH.gap === undefined ? 3.5 : TH.gap);   /* 占住全队的"下一个"名额 */
  e.fireCd = Math.max(e.fireCd || 0, TH.windup + 0.2);
  voiceSay(e, 'tac', 1, 2);
}

/* 共用门前投雷。调用者持续传同一份 order（房间、门、入室方向，可选 isActive）。
   这里推进投掷和等雷；由调用者决定哪些敌人何时使用。返回 true 时占用移动权。 */
function enemyDoorFragFrame(L,e,room,door,side,viaConnectedRoom=false,drift=0,allowInside=false,ignoreGate=false){
  /* 2026-11-25 反馈「模板房子基本不扔雷」：原来要求门开到 95% 才肯扔，
     而模板房的门是敌人边走边推开的 —— 等它开到位，人已经贴在门槛上（depth 判据）过了窗口，
     于是很多房子根本凑不出「可以扔」的那一帧。
     现在放宽成「门开到 60% 就算能扔进去」，并把站位窗口从 +16px 放宽到 roomEntry.waitDistance（74），
     让它在门口真正停下来扔，而不是一路走进去。已锁且没解锁的门仍然不许。 */
  if(!side || !room || !door) return null;
  if(!ignoreGate && !((typeof doorGateOpen === 'function') ? doorGateOpen(door) :
     (!door.broken && (door.open>=0.60) && !(door.isLocked&&!door.unlocked))))return null;
  const f=roomDoorFrame(door), half=(f.vertical?f.w:f.h)/2;
  const depth=(f.vertical?e.x-f.cx:e.y-f.cy)*side;
  /* allowInside（补第二颗 / 队友接手）：允许人已经贴到门口甚至迈进门里再撒手，
     只保留一个宽松的"别在屋外太远"上限 —— 否则接手的人站在门槛上会被判不合格。 */
  const _wd = (typeof DataTHROW !== 'undefined' && DataTHROW.roomEntry &&
    isFinite(DataTHROW.roomEntry.waitDistance)) ? DataTHROW.roomEntry.waitDistance : 74;
  const _maxD=allowInside ? half+(e.r||13)+90+drift : half+(e.r||13)+_wd+drift;
  if(!allowInside && depth>=-half)return null;
  if(dist(e.x,e.y,f.cx,f.cy)>_maxD || (!allowInside && levelRoomAt(L,e.x,e.y)===room))return null;
  /* 2026-11-24 反馈：精英出房子时也会朝门里再投一颗雷，看着像「临走还要排点」。
     规矩收窄成「只有从屋外往屋里才投」——投掷者必须站在街上（不在任何房间内）。
     同栋楼的相邻房区（viaConnectedRoom）也一并收掉：人已经在屋里了就不该再扔。
     例外（allowInside）：这一轮的第一颗已经出手（order 里已有 nade）时允许它把
     「补第二颗」补完 —— 目标没变、只是它自己已经迈进门里等爆炸，不能算新开一轮。 */
  const _hereRoom=levelRoomAt(L,e.x,e.y);
  if(_hereRoom && !allowInside)return null;
  const inside=(half+4)*side;
  const entranceRoom=levelRoomAt(L,f.cx+(f.vertical?inside:0),f.cy+(f.vertical?0:inside));
  if(entranceRoom===room)return f;
  // 同栋建筑可以有多个逻辑房区，投掷路径仍须通过门洞且不撞墙。
  return viaConnectedRoom && room.building!=null && entranceRoom?.building===room.building ? f : null;
}
function enemyDoorFragAllowed(L,e,order,force){
  return !e.fleeing && !enemyLowHp(e) && !eStatusHas(e,'stun') && !eStatusHas(e,'hurt') &&
    !eStatusHas(e,'suppress') && !eStatusHas(e,'call') &&
    (!order.isActive || force || order.isActive(L,e,order));
}
function enemyDoorFragActiveFrame(L,e,order){
  const cfg=enemyThrowDef()?.roomEntry;
  /* 轮次路径：站在门槛/门里也算起手合法（slot 已经拿到名额，位置由几何单独校验） */
  const _byRound=!!(e.roomEntryThrow && e.roomEntryThrow.round);
  return cfg && enemyDoorFragAllowed(L,e,order,!!e.roomEntryForce) &&
    enemyDoorFragFrame(L,e,order.room,order.door,order.side,order.viaConnectedRoom,cfg.windupDrift,!!order.nade || !!e.roomEntryForce || _byRound);
}
function enemyDoorFragLanding(L,e,room,f,x,y,TH){
  const dx=x-e.x,dy=y-e.y,d=Math.hypot(dx,dy);
  /* 小房间放宽：进深不足时按进深比例下调最小投掷距离，否则一个合法落点都没有 */
  let _minR = TH.roomEntry ? TH.roomEntry.minRange : 88;
  if (room && isFinite(room.w) && isFinite(room.h)){
    const _depth = Math.min(room.w, room.h);
    if (_depth < 260) _minR = Math.min(_minR, Math.max(52, _depth * 0.42));
  }
  if(!TH.roomEntry || d<_minR || d>TH.maxR ||
     levelRoomAt(L,x,y)!==room || navBlockedAt(L,x,y))return false;
  const t=f.vertical?(f.cx-e.x)/dx:(f.cy-e.y)/dy;
  const across=f.vertical?e.y+t*dy-f.cy:e.x+t*dx-f.cx;
  if(!(t>0 && t<1) || Math.abs(across)>(f.vertical?f.h:f.w)/2-NADE_RAD)return false;
  return !truckOcclSeg(e.x,e.y,x,y) && rayToWall(e.x,e.y,Math.atan2(dy,dx),d,false,false,true)>=d;
}
/* 一支队伍分方向占用同一扇门。投掷者中断后释放，已落下的雷仍等到引信结束。 */
const _enemyDoorFragOrders=new WeakMap();
function enemyDoorFragReservation(L,e,door,side,coop){
  const slots=_enemyDoorFragOrders.get(door);
  if(!slots)return null;
  const key=combatFaction(e)+':'+side+(coop?':c':''),order=slots.get(key);
  if(!order)return null;
  if(order.nade && nades.includes(order.nade))return order;
  const owner=order.owner;
  if(owner && !owner.dead && !owner.gone && enemyDoorFragAllowed(L,owner,order) &&
     ((owner.throwT>0 && owner.roomEntryThrow?.order===order) || (order.follow && uiT<order.followBy)))
    return order;
  slots.delete(key);
  return null;
}
function enemyDoorFragReserve(e,order){
  let slots=_enemyDoorFragOrders.get(order.door);
  if(!slots){slots=new Map();_enemyDoorFragOrders.set(order.door,slots);}
  order.owner=e;
  slots.set(combatFaction(e)+':'+order.side+(order.coop?':c':''),order);
}
function enemyDoorFragSpot(L,e,order,f,TH){
  const room=order.room,cfg=TH.roomEntry,previous=order.nade;
  if(room.w<=cfg.inset*2 || room.h<=cfg.inset*2)return null;
  const opening=(f.vertical?f.h:f.w)/2-NADE_RAD;
  if(opening<=0)return null;
  const left=room.x+cfg.inset,right=room.x+room.w-cfg.inset;
  const top=room.y+cfg.inset,bottom=room.y+room.h-cfg.inset;
  const half=(f.vertical?f.w:f.h)/2;
  for(let i=0;i<cfg.samples;i++){
    // 在门洞内取方向，再在实际可达的房内深度上采样，窄门也不会把样本都丢在墙上。
    const lateral=(arenaRandom()*2-1)*opening;
    const dx=f.cx+(f.vertical?0:lateral)-e.x,dy=f.cy+(f.vertical?lateral:0)-e.y;
    const len=Math.hypot(dx,dy),ux=dx/len,uy=dy/len;
    const near=Math.max(cfg.minRange,len+(half+cfg.inset)/Math.abs(f.vertical?ux:uy),
      ux?((ux>0?left:right)-e.x)/ux:-Infinity,
      uy?((uy>0?top:bottom)-e.y)/uy:-Infinity);
    const boxFar=Math.min(TH.maxR,ux?((ux>0?right:left)-e.x)/ux:Infinity,
      uy?((uy>0?bottom:top)-e.y)/uy:Infinity);
    if(boxFar<=near)continue;
    const wallFar=rayToWall(e.x,e.y,Math.atan2(uy,ux),boxFar,false,false,true);
    const far=wallFar<boxFar?wallFar-NADE_RAD:boxFar;
    if(far<=near)continue;
    const d=near+arenaRandom()*(far-near),x=e.x+ux*d,y=e.y+uy*d;
    if(previous && dist(x,y,previous.tx,previous.ty)<cfg.minSeparation)continue;
    if(enemyDoorFragLanding(L,e,room,f,x,y,TH) && !enemyNadeCrowded(e,x,y))return {x,y};
  }
  return null;
}
function enemyDoorFragStart(L,e,order,f,TH,force){
  /* 新路径：门前投雷统一走"轮次"（成员/名额/计划落点/取消原因都显式），
     旧路径保留在 useRound:false 之下，便于 A/B 与回退。 */
  if (typeof nadeRoundOn === 'function' && nadeRoundOn() && order && order.slots){
    const slot=nadeRoundJoin(L,e,order.door,order.side,order.room,order.search);
    if(!slot)return false;                       /* 名额满/轮次已关：把控制权交还搜房 */
    const why=nadeRoundBegin(L,e,slot.order,f);
    if(why!=='windup'){
      if(typeof nadeRoundCancel==='function')nadeRoundCancel(e,why);
      return false;
    }
    if(!order.nade)order.stand={x:e.x,y:e.y};
    return true;
  }
  /* coop（队友接手补第二颗）/ 轮次里的第二个人都要跳过全队节奏闸门，
     否则还是得白等 gap 秒 —— 「同时撒手」就没了意义。
     注意：容量（场上敌雷上限）仍然要管，不分轮次。 */
  const _byRound = !!(order && order.slots);
  if(!force && ((nadeSquadCd>0 && !order.coop && !_byRound) || nadeLiveEnemy()>=(TH.maxLive??2)))return false;
  if(force && nadeLiveEnemy()>=(TH.maxLive??2))return false;
  const at=enemyDoorFragSpot(L,e,order,f,TH);
  if(!at)return false;
  if(!order.nade)order.stand={x:e.x,y:e.y};
  e.roomEntryThrow={order,x:at.x,y:at.y,at:uiT};
  e.roomEntryForce=!!force;
  if(!force)enemyDoorFragReserve(e,order);
  startEnemyThrow(e,TH,!!(force||order.coop));
  return true;
}
function enemyDoorFragTick(L,e,order,dt){
  const TH=enemyThrowDef();
  if(!TH?.roomEntry || !enemyCanThrow(e,true) || !enemyDoorFragAllowed(L,e,order))return false;
  if(e.throwT>0)return e.roomEntryThrow?.order===order;
  const reserved=enemyDoorFragReservation(L,e,order.door,order.side,!!order.coop);
  if(reserved && reserved!==order)return true;
  const previous=order.nade;
  if(previous && nades.includes(previous) && !order.coop)return true;
  if(order.tried && !order.follow)return false;
  if(previous && uiT>=order.followBy){order.follow=false;return false;}
  const f=enemyDoorFragFrame(L,e,order.room,order.door,order.side,order.viaConnectedRoom,0,!!previous);
  if(previous){
    // 自己投的雷也会触发游戏现有的躲雷。炸完后可以短暂回到原来的门外位置。
    const {x,y}=order.stand, d=dist(e.x,e.y,x,y);
    if((!f || d>6) && d>.5 && bladeWalkLine(L,e.r||13,e.x,e.y,x,y)){
      const a=Math.atan2(y-e.y,x-e.x);
      bladeMove(L,e,a,Math.min(d,CFG.eSpeed*.72*eMoveK(e)*enemyMoveK(e)*dt));
      return true;
    }
    if(!f){order.follow=false;return false;}
    if(nadeSquadCd>0 && !order.coop)return true;
  }
  if(!f)return false;
  order.tried=true;
  order.follow=false;
  if(!previous && ((e.throwCd||0)>0 || arenaRandom()>=TH.roomEntry.firstChance))return false;
  const _ok=enemyDoorFragStart(L,e,order,f,TH);
  /* coop 找不到合格落点时会空手而归：别把它判死，下一帧换个采样点再试 */
  if(!_ok && order.coop){ order.tried=false; order.follow=true; }
  return _ok;
}
function enemyDoorFragReleased(order,nade,TH){
  order.follow=!order.nade && arenaRandom()<TH.roomEntry.followChance;
  order.nade=nade;
  order.followBy=uiT+Math.max(nade.fuse,nadeSquadCd)+TH.roomEntry.returnTime;
}

/* 掏雷前摇期间不再"原地定住"。
   以前 throwT>0 时整只敌人 speed=0，看上去像被按了暂停；现在允许以 35% 速度往当前目标挪，
   朝向也按 4 rad/s 慢慢转 —— 观感是"一边走一边拉环"，而不是"硬直"。
   不开火、不放技能这些限制不变（fireCd 在 enemyThrowTick 里已被按住）。 */
function enemyThrowShuffle(L, e, dt){
  if ((e.throwT || 0) <= 0) return;
  const entry=e.roomEntryThrow;
  let gx = null, gy = null;
  if(entry){gx=entry.x;gy=entry.y;}
  else if (e.goal && isFinite(e.goal.x) && isFinite(e.goal.y)){ gx = e.goal.x; gy = e.goal.y; }
  else if (e.lastKnown && isFinite(e.lastKnown.x) && isFinite(e.lastKnown.y)){ gx = e.lastKnown.x; gy = e.lastKnown.y; }
  else if (e.wp && e.wp.length){
    const w = e.wp[(e.i | 0) % e.wp.length] || e.wp[0];
    if (w && isFinite(w[0]) && isFinite(w[1])){ gx = w[0]; gy = w[1]; }
  }
  if (gx === null) return;
  if (Math.hypot(gx - e.x, gy - e.y) < 30) return;       /* 已经站到点上了，就别原地蹭 */
  const a = Math.atan2(gy - e.y, gx - e.x);
  // 门前投掷只转身，普通投掷仍允许沿路线缓步移动。
  if(!entry){
    const spd=CFG.eSpeed*.35*eMoveK(e)*enemyMoveK(e);
    const nx=e.x+Math.cos(a)*spd*dt, ny=e.y+Math.sin(a)*spd*dt;
    if(!navBlockedAt(L,nx,ny)){e.x=nx;e.y=ny;}
  }
  let da = normAng(a - e.ang);
  const mx = dt * 4;
  if (da > mx) da = mx; else if (da < -mx) da = -mx;
  e.ang = normAng(e.ang + da);
  if (typeof pushOutTrucks === 'function') pushOutTrucks(e);
}

/* 扛着什么枪就跑多慢：只有 rpg 写了 moveK(0.72)，其它枪是 1。
   玩家侧在 update() 里乘过一次，敌人这里补上 —— 之前敌人的速度从来没查过武器表。 */
function enemyMoveK(e){
  return weaponCore(e && e.wid).moveK || 1;
}

/* 火箭筒兵的换弹：不吃"整张图统一 CFG.reload"，按玩家那把火箭筒的 reloadDur 算，
   难度越高越接近玩家（噩梦 = 和玩家一模一样），越简单越慢。
   换别的枪的敌人照旧走 CFG.reload，手感和以前完全一样。 */
const RPG_RELOAD_K = { easy: 1.90, normal: 1.55, hard: 1.25, nightmare: 1.00 };
function enemyReloadTime(e){
  /* 统一入口：火箭筒按玩家那把枪的 reloadDur × 难度系数，其他枪仍吃 CFG.reload */
  return npcStatsOf(e && e.wid, typeof diffName === 'string' ? diffName : 'normal').reloadTime;
}

/* 单发武器：一发一装（火箭筒 cap 1、rocket:true）。以后再加"一次性发射器"
   只要在 WEAPONS 里写 rocket:true 或 singleShot:true，AI 这边一行都不用改。 */
function isSingleShotWeapon(W){
  return !!(W && (W.rocket || W.singleShot || (W.cap | 0) <= 1));
}

/* 单发重武器的完整战斗循环：开火 -> 撤进掩体 -> 在掩体内装填 -> 探出。
   这层只认武器属性，不认“玩家”这个对象；A/B 阵营互打时同样会围绕当前威胁工作。
   炮塔、Boss 和玩家队友有各自的控制器，不接管它们。 */
function singleShotCoverEligible(e, W){
  if (!e || e.dead || e.controller === 'companion' || e.bossKind) return false;
  const T = (typeof enemyType === 'function') ? enemyType(e) : null;
  return isSingleShotWeapon(W || weaponCore(e.wid)) && !(T && T.static);
}
function singleShotCoverClear(e, chase){
  if (!e) return;
  const _threat = e.singleCoverThreat || ((typeof enemyThreatOf === 'function') ? enemyThreatOf(e) : null);
  const _now = (typeof uiT === 'number') ? uiT : 0;
  const _D = (typeof rpgDef === 'function' && rpgDef()) || {};
  const _soundFresh = Number.isFinite(e.singleCoverSoundAt) &&
    _now - e.singleCoverSoundAt <= (_D.reloadHearFresh || 1.35);
  let _remember = null;
  if (_soundFresh && Number.isFinite(e.singleCoverSoundX) && Number.isFinite(e.singleCoverSoundY))
    _remember = { x:e.singleCoverSoundX, y:e.singleCoverSoundY };
  else if (e.sees && _threat && _threat !== e && Number.isFinite(_threat.x) && Number.isFinite(_threat.y))
    _remember = { x:_threat.x, y:_threat.y };
  else if (e.lastKnown && Number.isFinite(e.lastKnown.x) && Number.isFinite(e.lastKnown.y))
    _remember = { x:e.lastKnown.x, y:e.lastKnown.y };
  e.singleCoverPhase = null; e.singleCoverT = 0; e.singleCoverPeekT = 0;
  e.singleCoverEscapeT = 0; e.singleCoverGoal = null;
  e.singleCoverThreat = null; e.singleCoverSoundX = null; e.singleCoverSoundY = null;
  e.singleCoverSoundAt = null; e.singleCoverSoundSeq = 0; e.singleCoverSoundTrend = 0;
  e.singleCoverLastSoundD = null; e.singleCoverRetreatAt = null;
  if (chase){
    if (_remember){
      e.lastKnown = _remember;
      if (_threat && _threat !== e && _threat.hp !== undefined) e.lastKnownSource = _threat;
      e.mode = 1; e.heard = true; e.alertT = Math.max(e.alertT || 0, (CFG.eMemory || 6) + 2);
    }
    e.hideGoal = null; e.coverOK = 0; e.peekPhase = null; e.tucked = false;
    e.path = null; e.goal = null; e.chk = null; e.stuckT = 0;
  }
}
/* m44291：打完一发就撤到掩体 —— 用户说"换弹期间全程追着我"，
   但也不能一路跑远（拉太开、装完弹就忘了人在哪）。
   注意：这件事**已经**由下面的单发武器系统（singleShotCoverStart +
   singleShotCoverClear）统一实现，RPG 也在其中：
   - 撤到哪：pickHideSpot(L, e, 150, true, 威胁)
   - 躲多久 / 听到新脚步怎么办：DataRPG.reloadHearFresh / reloadDangerR /
     reloadEscapeMove / reloadEscapeGain
   - 记忆：开火那一刻写 lastKnown，alertT 直接盖住"整段装填 + CFG.eMemory + 2"
   m44538 之前这里还躺着 rpgAfterFire / rpgReloadTick 两个函数，从没被调用过
   （同一件事的第二套实现），已按"一处实现、一个旋钮"的原则删除。 */
/* 单发武器（火箭筒、榴弹）打一发就换位置的通用实现：
   开火 → seek（跑向掩体）→ reload（装填）→ peek（探头再打）。 */
function singleShotCoverStart(e, target){
  const W = weaponCore(e && e.wid);
  if (!singleShotCoverEligible(e, W) || typeof pickHideSpot !== 'function' || typeof cur !== 'function') return false;
  const t = target || ((typeof enemyThreatOf === 'function') ? enemyThreatOf(e) : null);
  if (!t || t === e || !Number.isFinite(t.x) || !Number.isFinite(t.y)) return false;
  const L = cur();
  const p = pickHideSpot(L, e, 150, true, t);
  if (!p || dist(e.x, e.y, p.x, p.y) < 24) return false;
  e.singleCoverPhase = 'seek'; e.singleCoverT = 0; e.singleCoverEscapeT = 0;
  const _soundSource = t.soundSource && !t.soundSource.dead && !t.soundSource.gone ? t.soundSource : null;
  e.singleCoverThreat = _soundSource || ((t.hp !== undefined || t === player) ? t : null);
  e.singleCoverAnchorX = e.x; e.singleCoverAnchorY = e.y;
  e.singleCoverShotX = t.x; e.singleCoverShotY = t.y;
  e.singleCoverStartD = dist(e.x, e.y, t.x, t.y);
  e.singleCoverPrevD = e.singleCoverStartD;
  e.singleCoverReloadMax = Math.max(0, e.reloading || enemyReloadTime(e));
  e.singleCoverSoundX = null; e.singleCoverSoundY = null; e.singleCoverSoundAt = null;
  e.singleCoverSoundSeq = 0; e.singleCoverSoundTrend = 0;
  e.singleCoverLastSoundD = e.singleCoverStartD; e.singleCoverRetreatAt = -99;
  e.singleCoverGoal = { x:p.x, y:p.y };
  e.hideGoal = { x:p.x, y:p.y }; e.coverOK = 1;
  e.peekPhase = 'run'; e.tucked = false; e.holding = 0; e.blindShot = false;
  e.tacticPhase = null; e.tacStage = null; e.suppressN = 0;
  e.path = null; e.goal = null; e.chk = null; e.stuckT = 0;
  /* 开炮这一刻的坐标就是可靠的最后目击点。警戒时间覆盖“跑路+整段装填”，
     所以即使目标之后不再出声，换完弹也不会把战斗对象忘干净。 */
  e.lastKnown = { x:t.x, y:t.y };
  if (_soundSource) e.lastKnownSource = _soundSource;
  else if (t.hp !== undefined) e.lastKnownSource = t;
  e.mode = 1;
  e.alertT = Math.max(e.alertT || 0, e.singleCoverReloadMax + (CFG.eMemory || 6) + 2);
  return true;
}

/* 换弹中的单发兵听到当前威胁：只登记声纹，不让通用 alertBySound 清掉掩体路线。
   决策在 singleShotCoverTick 做，这样 A/B 阵营与玩家都走同一条传感器链。 */
function singleShotCoverHear(e, x, y, source){
  if (!e || !e.singleCoverPhase || !Number.isFinite(x) || !Number.isFinite(y)) return false;
  if (!singleShotCoverEligible(e, weaponCore(e.wid))) return false;
  const old = e.singleCoverThreat;
  /* 换弹动作已经锁定当前交战对象。附近第三方的一声脚步不能让通用听觉把
     掩体路线清掉；消费该声音，但不拿它覆盖当前威胁。 */
  if (old && source && old !== source && !old.dead && !old.gone && (old.hp === undefined || old.hp > 0)) return true;
  if (source && source !== e) e.singleCoverThreat = source;
  const ax = Number.isFinite(e.singleCoverAnchorX) ? e.singleCoverAnchorX : e.x;
  const ay = Number.isFinite(e.singleCoverAnchorY) ? e.singleCoverAnchorY : e.y;
  const ad = dist(ax, ay, x, y);
  const prev = Number.isFinite(e.singleCoverLastSoundD) ? e.singleCoverLastSoundD : ad;
  e.singleCoverSoundTrend = clamp((e.singleCoverSoundTrend || 0) * 0.45 + (ad - prev), -160, 220);
  e.singleCoverLastSoundD = ad;
  e.singleCoverSoundX = x; e.singleCoverSoundY = y;
  e.singleCoverSoundAt = (typeof uiT === 'number') ? uiT : 0;
  e.heardAt = e.singleCoverSoundAt;
  e.singleCoverSoundSeq = (e.singleCoverSoundSeq || 0) + 1;
  e.lastKnown = { x:x, y:y };
  if (source && source !== e){ e.heardSource = source; e.lastKnownSource = source; }
  e.mode = 1; e.heard = true;
  e.alertT = Math.max(e.alertT || 0, (e.reloading || 0) + (CFG.eMemory || 6) + 2);
  return true;
}

function singleShotRetreatFromSound(L, e, x, y){
  const now = (typeof uiT === 'number') ? uiT : 0;
  if (now - (e.singleCoverRetreatAt || -99) < 0.55) return false;
  const threat = { x:x, y:y };
  let p = (typeof pickHideSpot === 'function') ? pickHideSpot(L, e, 150, true, threat) : null;
  const hereD = dist(e.x, e.y, x, y);
  if (p && (dist(e.x,e.y,p.x,p.y) < 28 || dist(p.x,p.y,x,y) < hereD + 24)) p = null;
  if (!p && typeof safeSpot === 'function'){
    const a = Math.atan2(e.y-y, e.x-x);
    for (const step of [180,240,300,140]){
      const q = safeSpot(L, {x:e.x+Math.cos(a)*step,y:e.y+Math.sin(a)*step}, (e.r||13)+6);
      if (q && dist(e.x,e.y,q.x,q.y)>36 && dist(q.x,q.y,x,y)>hereD+20){ p=q; break; }
    }
  }
  if (!p) return false;
  e.singleCoverPhase = 'seek'; e.singleCoverT = 0;
  e.singleCoverGoal = {x:p.x,y:p.y}; e.hideGoal = {x:p.x,y:p.y}; e.coverOK = 1;
  e.peekPhase = 'run'; e.tucked = false; e.peekT = 0;
  e.path = null; e.goal = null; e.chk = null; e.stuckT = 0;
  e.singleCoverRetreatAt = now;
  return true;
}
function singleShotCoverTick(L, e, dt){
  if (!e || !e.singleCoverPhase) return false;
  if (!singleShotCoverEligible(e, weaponCore(e.wid))){ singleShotCoverClear(e, false); return false; }
  e.singleCoverT = (e.singleCoverT || 0) + dt;
  const D = (typeof rpgDef === 'function' && rpgDef()) || {};
  const now = (typeof uiT === 'number') ? uiT : 0;
  const live = (e.sees && typeof enemyTargetEntity === 'function') ? enemyTargetEntity(e) : null;
  const heardFresh = Number.isFinite(e.singleCoverSoundAt) &&
    now - e.singleCoverSoundAt <= (D.reloadHearFresh || 1.35);
  const sx = live && live !== e ? live.x : (heardFresh ? e.singleCoverSoundX : NaN);
  const sy = live && live !== e ? live.y : (heardFresh ? e.singleCoverSoundY : NaN);
  if (Number.isFinite(sx) && Number.isFinite(sy)){
    const close = dist(e.x,e.y,sx,sy) <= (D.reloadDangerR || 270);
    const ax = Number.isFinite(e.singleCoverAnchorX) ? e.singleCoverAnchorX : e.x;
    const ay = Number.isFinite(e.singleCoverAnchorY) ? e.singleCoverAnchorY : e.y;
    const moved = dist(sx,sy,e.singleCoverShotX,e.singleCoverShotY);
    const fromShot = dist(ax,ay,sx,sy);
    const escaping = !close && moved >= (D.reloadEscapeMove || 100) &&
      fromShot >= (e.singleCoverStartD || fromShot) + (D.reloadEscapeGain || 70) &&
      (live || (e.singleCoverSoundSeq || 0) > 0);
    if (close && (e.reloading || 0) > 0){
      e.singleCoverEscapeT = Math.max(0,(e.singleCoverEscapeT||0)-dt*3);
      if (e.singleCoverPhase === 'reload') singleShotRetreatFromSound(L,e,sx,sy);
    } else {
      e.singleCoverEscapeT = Math.max(0, (e.singleCoverEscapeT || 0) + (escaping ? dt : -dt * 2));
      if (e.singleCoverEscapeT > 0.24){ singleShotCoverClear(e, true); return false; }
    }
  }
  /* 装填可以在撤向掩体的途中进行；弹已上膛就结束逃跑，重新接战。
     旧版把 seek 阶段排除在换弹计时外，简单难度可能“跑路 5 秒后再装 6 秒”。 */
  if (e.singleCoverPhase === 'seek' && (e.reloading || 0) <= 0 && (e.ammo | 0) > 0){
    e.singleCoverPhase = 'peek'; e.singleCoverPeekT = 0.38;
    e.peekPhase = 'peek'; e.tucked = false; e.peekT = Math.max(e.peekT || 0, 0.38);
    e.fireCd = Math.max(e.fireCd || 0, 0.16);
  }
  if (e.singleCoverPhase === 'seek'){
    const g = e.singleCoverGoal || e.hideGoal;
    const seekMax = Math.max(5.0, (e.singleCoverReloadMax || 0) + 2.5);
    if (!g || e.singleCoverT > seekMax){ singleShotCoverClear(e, true); return false; }
    if (dist(e.x, e.y, g.x, g.y) <= 22){
      e.singleCoverPhase = 'reload'; e.singleCoverT = 0;
      e.hideGoal = { x:e.x, y:e.y }; e.coverOK = 1;
      e.peekPhase = 'tuck'; e.tucked = true; e.peekT = Math.max(e.peekT || 0, (e.reloading || 0) + 0.25);
      e.path = null; e.goal = null;
    }
  } else if (e.singleCoverPhase === 'reload'){
    e.peekPhase = 'tuck'; e.tucked = true;
    e.peekT = Math.max(e.peekT || 0, (e.reloading || 0) + 0.2);
    if ((e.reloading || 0) <= 0 && (e.ammo | 0) > 0){
      e.singleCoverPhase = 'peek'; e.singleCoverPeekT = 0.38;
      e.peekPhase = 'peek'; e.tucked = false; e.peekT = Math.max(e.peekT || 0, 0.38);
      e.fireCd = Math.max(e.fireCd || 0, 0.16); /* 先让身体拉出来，再发下一炮 */
    }
  } else if (e.singleCoverPhase === 'peek'){
    e.peekPhase = 'peek'; e.tucked = false;
    e.singleCoverPeekT = (e.singleCoverPeekT || 0) - dt;
    if (e.singleCoverPeekT <= 0) singleShotCoverClear(e, false);
  }
  return !!e.singleCoverPhase;
}

/* 敌人扣一次扳机的唯一入口：打子弹、扣弹药、进换弹，全在这里。
   单发武器额外做三件事：不吃"点射 N 发"的计数、打完立刻进装填、抬枪时间固定。
   调用点只管"要不要开枪"，不用再自己 ammo-- / reloading=。 */
/* 这把枪现在"膛里有没有东西"：单发武器打完就是空管，装填完才算又压上一发。
   画枪时直接用它决定画不画弹头（warhead）。 */
function enemyWeaponLoaded(e){
  const W = (e && e.wid && typeof WEAPONS !== 'undefined') ? WEAPONS[e.wid] : null;
  if (!W) return false;
  if (isSingleShotWeapon(W)) return (e.ammo | 0) > 0 && (e.reloading || 0) <= 0;
  return (e.ammo | 0) > 0;
}

/* 火箭筒兵的友军火力规避（m29597）：
   扣扳机前先做一条射线，线上有活队友就放弃这一炮；等不到队友走开就换副武器。
   参数全在 data/ai.js 的 DataRPG 里，on=false 直接退回旧行为。 */
function rpgDef(){
  if (typeof DataRPG === 'undefined' || !DataRPG) return null;
  return DataRPG;
}
/* m44395：敌人火箭弹的初速。以前这里写死 540，玩家同款是 ROCKET_SPD(1000)，
   看起来就是"敌人的弹慢慢飘、我的一下就到"。统一成 1000，可用 DataRPG.spd 覆盖。 */
function rpgBulletSpeed(){
  const D = rpgDef();
  if (D && D.spd) return D.spd;
  return (typeof ROCKET_SPD === 'number') ? ROCKET_SPD : 1000;
}
/* 这条弹道会不会穿到队友身上：返回 true = 有自己人挡着。
   ox/oy 允许在真正移动前检查候选射击位。 */
function rpgTraceBlockedFrom(e, ox, oy, a, maxD){
  const D = rpgDef();
  if (!D || D.on === false) return false;
  if (typeof enemies === 'undefined' || !enemies) return false;
  const w = (D.width || 14);
  const dx = Math.cos(a), dy = Math.sin(a);
  const x1 = ox + dx * 18, y1 = oy + dy * 18;
  for (const o of (e.controller==='companion'?[player,...allies]:enemies)){
    if (!o || o === e || o.dead || o.hp <= 0) continue;
    /* enemies[] 里现在同时装着 A、B 等多个阵营，不能再把“同数组”当成“友军”。
       敌对目标（包括另一阵营的火箭兵）本来就是这一炮要打的人，不能反过来
       触发友军避火，导致双方永远互相架着。 */
    if (typeof factionWantsFight === 'function' && factionWantsFight(e, o)) continue;
    /* 沿着弹道投影：必须在前面，且不能超出目标距离太多 */
    const rel = (o.x - x1) * dx + (o.y - y1) * dy;
    if (rel < 8 || rel > maxD + 24) continue;
    const perp = Math.abs((o.x - x1) * dy - (o.y - y1) * dx);
    if (perp > w + (o.r || 12)) continue;
    return true;
  }
  return false;
}
function rpgTraceBlocked(e, a, maxD){
  return rpgTraceBlockedFrom(e,e.x,e.y,a,maxD);
}
/* 被挡一次记一笔；挡太久就"让开射界"，而不是换手枪。
   以前这里直接 rpgSidearm()：三个人挤在一起互相挡弹道，半秒后集体把手里的
   火箭筒换成手枪，玩家看到的就是"碰到人就不敢开炮了"。真正的毛病人挤人，
   该解决的是站位，不是武器。 */
function rpgNoteBlocked(e, target){
  const D = rpgDef();
  if (!D) return;
  e.rpgBlockT = (e.rpgBlockT || 0) + (D.ffCd || 0.35);
  if (e.rpgBlockT >= (D.waitT || 0.9)){
    e.rpgBlockT = 0;
    if (!rpgSidestep(e,target) && (e.ammo | 0) <= 0) rpgSidearm(e);   /* 真的空膛了才换副武器 */
  }
}
/* 朝侧向让开半个身位，把射界腾出来。位移很小（D.sideGap，默认 26px），
   必须过"脚下不被墙/车/门挡住"，否则宁可不动。 */
function rpgSidestep(e, target){
  const D = rpgDef();
  const step = (D && D.sideGap) || 26;
  const maxSide = Math.max(step, (D && D.sideMax) || step * 5);
  const now = (typeof uiT === 'number') ? uiT : 0;
  if (now < (e.rpgLaneRetryAt || 0)) return false;
  const tx = target || ((typeof enemyTargetPoint === 'function') ? enemyTargetPoint(e) : player);
  if (!tx || tx === e) return false;
  /* 先把最终射击位算出来，再连续走过去；不能每 34px 停一次重新规划。 */
  if (e.rpgMoveGoal) return true;
  const a = Math.atan2(tx.y - e.y, tx.x - e.x);
  const side = e.rpgSideDir || (e.rpgSideDir = (arenaRandom() < 0.5 ? -1 : 1));
  const L = cur();
  for (const sgn of [side, -side]){
    for(let off=step;off<=maxSide+0.01;off+=step){
      const nx = e.x + Math.cos(a + Math.PI/2) * off * sgn;
      const ny = e.y + Math.sin(a + Math.PI/2) * off * sgn;
      if (typeof navBlockedAt === 'function' && navBlockedAt(L, nx, ny)) break;
      if (typeof clearWalkLine === 'function' && !clearWalkLine(L, e.x, e.y, nx, ny)) break;
      const na=Math.atan2(tx.y-ny,tx.x-nx),nd=dist(nx,ny,tx.x,tx.y);
      if(typeof losBlocked==='function'&&losBlocked(nx,ny,tx.x,tx.y))continue;
      if(rpgTraceBlockedFrom(e,nx,ny,na,Math.min(nd+60,900)))continue;
      e.rpgSideDir=sgn;
      const laneSpd=Math.max(90,CFG.eSpeed*1.05)*eMoveK(e);
      e.rpgMoveGoal={x:nx,y:ny,kind:'lane',t:0,maxT:Math.max(0.85,off/laneSpd+0.35)};
      /* 只清寻路缓存，**不要清 e.wp**：让位/侧移只是临时接管，清掉巡逻线会让这个兵永远站着当雕像
         （死亡地带里那个 wp 为空的火箭筒兵就是这么来的）。rpgRepositionTick 会提前 return，
         巡逻在让位期间本来就不会跑。 */
      e.path=null;e.goal=null;
      return true;
    }
  }
  /* 规划半径内没有安全射界，就等待队友/目标移动。禁止继续横穿地图找角度。 */
  e.rpgLaneRetryAt=now+((D&&D.sideRetry)||0.85);
  return false;
}
/* 通用爆炸武器落点求解器。
   它不认识火箭兵、玩家或阵营，只处理四件事：
   1) 落点在爆炸有效半径内；2) 落点自身可用；3) 弹丸能直飞到落点；
   4) 爆炸从落点传播到目标时不会被实体墙完全截断。
   opts 允许未来的榴弹、迫击炮等兵种传入自己的半径、采样密度和判定函数；
   所有候选都失败才返回目标坐标，并用 direct=true 明确标记这次是直瞄回退。 */
function solveExplosiveLandingPoint(shooter, target, opts){
  if (!shooter || !target) return null;
  opts = opts || {};
  const blastRadius = Math.max(1, Number(opts.blastRadius) || 1);
  const coverageK = clamp(Number.isFinite(opts.coverageK) ? opts.coverageK : 0.72, 0.08, 0.96);
  const coverR = blastRadius * coverageK;
  const samples = Math.max(8, Math.min(32, opts.samples | 0 || 16));
  const rings = Array.isArray(opts.rings) && opts.rings.length ? opts.rings : [1, 0.70, 0.42];
  const minShooterDist = Math.max(0, Number(opts.minShooterDist) || 0);
  const L = (typeof cur === 'function') ? cur() : null;
  const landingBlocked = typeof opts.landingBlocked === 'function'
    ? opts.landingBlocked
    : function(x,y){ return !!(L && typeof navBlockedAt === 'function' && navBlockedAt(L,x,y)); };
  const projectileBlocked = typeof opts.projectileBlocked === 'function'
    ? opts.projectileBlocked
    : function(x1,y1,x2,y2){ return typeof losBlocked === 'function' && losBlocked(x1,y1,x2,y2); };
  const damageBlocked = typeof opts.damageBlocked === 'function'
    ? opts.damageBlocked
    : function(x1,y1,x2,y2){ return typeof blastBlocked === 'function' && blastBlocked(x1,y1,x2,y2); };

  /* 从“目标朝向射手”的一侧开始，完整扫一圈。开放场地会优先选较短弹道；
     有墙时仍会继续检查其它角度，不会因为第一个点被挡就立刻直瞄目标。 */
  const base = Math.atan2(shooter.y - target.y, shooter.x - target.x);
  let best = null, bestScore = Infinity;
  for (let ri = 0; ri < rings.length; ri++){
    const ringK = clamp(Number(rings[ri]) || 0, 0.08, 1);
    const offset = coverR * ringK;
    for (let i = 0; i < samples; i++){
      const a = base + i * Math.PI * 2 / samples;
      const x = target.x + Math.cos(a) * offset;
      const y = target.y + Math.sin(a) * offset;
      const targetD = dist(x,y,target.x,target.y);
      const shotD = dist(shooter.x,shooter.y,x,y);
      if (targetD > blastRadius + 0.01 || shotD < minShooterDist) continue;
      if (landingBlocked(x,y,shooter,target)) continue;
      if (projectileBlocked(shooter.x,shooter.y,x,y,shooter,target)) continue;
      if (damageBlocked(x,y,target.x,target.y,shooter,target)) continue;
      /* 同一圈优先较短的飞行距离；外圈略优先，确保不是换一种方式继续瞄人脚下。 */
      const score = shotD + ri * blastRadius * 0.06;
      if (score < bestScore){
        bestScore = score;
        best = { x:x, y:y, direct:false, targetDistance:targetD };
      }
    }
  }
  return best || { x:target.x, y:target.y, direct:true, targetDistance:0 };
}

/* 火箭筒只是通用求解器的第一个调用者。实际爆炸半径包含割草模式的卡牌倍率，
   因而 AI 选出的落点与 rocketBlast 真正使用的伤害圈保持一致。 */
function rpgAreaSpot(e, tgt, D){
  if (!tgt) return null;
  D = D || {};
  const radius = (typeof ROCKET_R === 'number' ? ROCKET_R : 320) *
    (typeof arenaRocketRadiusK === 'function' ? arenaRocketRadiusK() : 1);
  return solveExplosiveLandingPoint(e,tgt,{
    blastRadius: radius,
    coverageK: D.aimCoverageK,
    rings: D.aimRings,
    samples: D.aimSamples,
    minShooterDist: D.minRange
  });
}

/* 区域爆炸武器的声纹接口。是否支持由 WEAPONS.soundAreaFire 声明，不认兵种名称；
   以后榴弹发射器、迫击炮等只要接入自己的发射分支并打开字段，就能复用这一套。
   爆炸声不作为攻击坐标，防止两拨火箭兵被弹坑互相触发成无限盲炸。 */
function explosiveSoundRemember(e, x, y, source, kind){
  if (!e || e.dead || !Number.isFinite(x) || !Number.isFinite(y)) return false;
  const W = (typeof gunDef === 'function') ? gunDef({wid:e.wid || 'pistol'}) : null;
  if (!W || W.soundAreaFire !== true || kind === 'blast' || kind === 'rocketBlast') return false;
  const D = (typeof rpgDef === 'function' && rpgDef()) || {};
  if (source && typeof factionWantsFight === 'function' && !factionWantsFight(e,source)) return false;
  const now = (typeof uiT === 'number') ? uiT : 0;
  /* 声音中断后再次听见才重新准备；连续脚步只更新落点参考。
     准备时间只约束开火，移动和武器冷却照常推进。 */
  if (!Number.isFinite(e.explosiveSoundAt) || now - e.explosiveSoundAt > (D.soundFireFresh || 1.8)){
    e.explosiveSoundReadyAt = now + (Number.isFinite(W.soundAreaDelay) ? W.soundAreaDelay : 0.16);
  }
  e.explosiveSoundX = x; e.explosiveSoundY = y;
  e.explosiveSoundAt = now;
  e.explosiveSoundSource = source || null;
  e.explosiveSoundKind = kind || 'step';
  e.explosiveSoundSpent = false;
  return true;
}
function explosiveSoundTarget(e){
  if (!e || e.explosiveSoundSpent) return null;
  const W = (typeof gunDef === 'function') ? gunDef({wid:e.wid || 'pistol'}) : null;
  if (!W || W.soundAreaFire !== true) return null;
  const D = (typeof rpgDef === 'function' && rpgDef()) || {};
  const now = (typeof uiT === 'number') ? uiT : 0;
  if (!Number.isFinite(e.explosiveSoundAt) || now - e.explosiveSoundAt > (D.soundFireFresh || 1.8)) return null;
  if (!Number.isFinite(e.explosiveSoundX) || !Number.isFinite(e.explosiveSoundY)) return null;
  const source = e.explosiveSoundSource;
  if (source && (source.dead || source.gone || (source.hp !== undefined && source.hp <= 0))) return null;
  if (source && typeof factionWantsFight === 'function' && !factionWantsFight(e,source)) return null;
  return { x:e.explosiveSoundX, y:e.explosiveSoundY, soundSource:source || null, fromSound:true };
}
/* 视觉开火入口之外的独立声纹扳机。它只决定“现在可否拿声纹当区域目标”；
   落点、墙体爆炸遮挡、友军弹道和最小安全距离仍全部走 enemyFireWeapon 的原规则。 */
function explosiveSoundFireTick(e, ei, dt){
  if (!e || e.dead || e.sees || e.singleCoverPhase || (e.reloading || 0) > 0 || (e.ammo | 0) <= 0) return false;
  if (typeof eStatusHas === 'function' && (eStatusHas(e,'stun') || eStatusHas(e,'fear'))) return false;
  const target = explosiveSoundTarget(e);
  if (!target) return false;
  if (!behaviorOf(e).ownCooldown) e.fireCd = Math.max(0,(e.fireCd || 0) - Math.max(0,dt || 0));
  if ((e.fireCd || 0) > 0 || (e.explosiveSoundReadyAt || 0) > uiT) return false;
  if (!enemyFireWeapon(e,ei,undefined,undefined,target)) return false;
  e.explosiveSoundSpent = true;
  return true;
}
function rpgBackpedal(e){  const tx = (typeof enemyTargetPoint === 'function') ? enemyTargetPoint(e) : player;
  if (!tx || tx === e) return false;
  if (e.rpgMoveGoal) return true;
  const a = Math.atan2(tx.y - e.y, tx.x - e.x);
  const step = 16;
  const nx = e.x - Math.cos(a) * step, ny = e.y - Math.sin(a) * step;
  const L = cur();
  if (typeof navBlockedAt === 'function' && navBlockedAt(L, nx, ny)) return false;
  if (typeof clearWalkLine === 'function' && !clearWalkLine(L, e.x, e.y, nx, ny)) return false;
  e.rpgMoveGoal = { x:nx, y:ny, kind:'back', t:0 };
  /* 同上：保留 e.wp，只清寻路缓存 */
  e.path = null; e.goal = null;
  return true;
}
/* RPG 的临时让位只接管二三百毫秒。每帧最多走正常跑速的一小段，
   途中若墙/车改变就取消，绝不再用安全点把人弹到另一边。 */
function rpgRepositionTick(L, e, dt){
  const g = e && e.rpgMoveGoal;
  if (!g) return false;
  if (eStatusHas(e, 'stun')){ e.rpgMoveGoal = null; return false; }
  g.t = (g.t || 0) + dt;
  const dx = g.x - e.x, dy = g.y - e.y, d = Math.hypot(dx, dy);
  if (d <= 1.5 || g.t > (g.maxT || 0.85)){
    e.rpgMoveGoal = null;
    if(g.kind==='lane')e.rpgLaneRetryAt=((typeof uiT==='number')?uiT:0)+(((rpgDef()||{}).sideRetry)||0.85);
    return false;
  }
  const step = Math.min(d, Math.max(90, CFG.eSpeed * 1.05) * eMoveK(e) * dt);
  const nx = e.x + dx / d * step, ny = e.y + dy / d * step;
  if ((typeof navBlockedAt === 'function' && navBlockedAt(L, nx, ny)) ||
      (typeof clearWalkLine === 'function' && !clearWalkLine(L, e.x, e.y, nx, ny))){
    e.rpgMoveGoal = null;
    return false;
  }
  e.x = nx; e.y = ny;
  return true;
}
function rpgSidearm(e){
  if(e.controller==='companion'){
    const p=companionPack(e),i=p.guns.findIndex((g,i)=>i!==p.selected&&!g.rocket&&(g.mag>0||(p.ammo[g.ammo]||0)>0));
    return i>=0&&companionEquip(e,i);
  }
  const D = rpgDef();
  if (!D || !D.sidearm) return false;
  /* 有火箭弹就绝不换手枪：换手是"没弹了"的补救，不是"前面有人"的退路 */
  if ((e.ammo | 0) > 0) return false;
  if (e.wid === D.sidearm) return true;
  e.rpgMainWid = e.wid;                 /* 记着原来扛的是什么 */
  e.wid = D.sidearm;
  e.ammo = Math.max(1, weaponCore(D.sidearm).cap | 0);
  e.reloading = 0; e.burstLeft = 0;
  e.rpgSideUntil = uiT + (D.sideT || 4.0);
  e.fireCd = Math.max(e.fireCd || 0, 0.4);   /* 换手要一点时间 */
  return true;
}
function rpgRestore(e){
  const D = rpgDef();
  if (!D || !e.rpgMainWid) return false;
  e.wid = e.rpgMainWid;
  e.rpgMainWid = null;
  e.ammo = 1; e.reloading = 0; e.rpgBlockT = 0; e.rpgSideUntil = 0;
  return true;
}
/* 拿着副武器的人：时间到了、路也通了，就换回火箭筒 */
function rpgSidearmTick(e){
  const D = rpgDef();
  if (!D || !e.rpgMainWid) return;
  if (uiT < (e.rpgSideUntil || 0)) return;
  const t = (typeof enemyThreatOf === 'function') ? enemyThreatOf(e) : player;
  if (!t || t === e) return;
  const a = Math.atan2(t.y - e.y, t.x - e.x);
  const pd = dist(e.x, e.y, t.x, t.y);
  if (rpgTraceBlocked(e, a, pd)) { e.rpgSideUntil = uiT + 0.8; return; }
  rpgRestore(e);
}

function enemyFireWeapon(e, ei, aimAngle, spreadMul, target){
  if(e&&e.controller==='companion'&&((e.ammo|0)<=0||(e.reloading||0)>0))return false;
  const W = gunDef({wid: (e && e.wid) || 'pistol'});
  const single = isSingleShotWeapon(W);
  if (single && ((e.ammo | 0) <= 0 || (e.reloading || 0) > 0)) return false;
  if (!enemyShoot(e, ei, aimAngle, spreadMul, target)) return false;
  /* 枪声传出去：同阵营之外、离得够近的敌对 NPC 都会过来看看（A 打 B / B 打 A） */
  if (!gunDef(e).rocket && typeof factionHearShot === 'function') factionHearShot(e);
  e.ammo = Math.max(0, (e.ammo | 0) - 1);
  if (single){
    e.burstLeft = 0; e.tacLeft = 0;                 /* 不参与点射/盲扫的连发计数 */
    e.fireCd = Math.max(e.fireCd || 0, 0.35);       /* 只留抬枪时间 */
    e.reloading = Math.max(e.reloading || 0, enemyReloadTime(e));
    singleShotCoverStart(e, target || ((typeof enemyThreatOf === 'function') ? enemyThreatOf(e) : null));
  } else if (e.ammo <= 0){
    e.reloading = Math.max(e.reloading || 0, enemyReloadTime(e));
  }
  return true;
}

function assignWeapon(e){
  const pool = enemyType(e).weaponPool;
  if (!pool || !pool.length) return;
  /* 故事关默认只用第一把（老关卡行为一字不变）；
     weaponRand:true 的精英（职业兵 / 包抄精英）会在整池里随机抽 —— 于是"职业兵有概率拿新枪" */
  const _rand = hasFeat('guns') || enemyType(e).weaponRand === true;
  const wid = _rand ? pool[Math.floor(arenaRandom()*pool.length) % pool.length] : pool[0];
  e.wid = wid;
  const _cap = Math.max(1, weaponCore(wid).cap | 0);
  /* 难度给的弹匣（CFG.mag）不能超过枪本身的容量：
     RPG 的 cap 是 1，再按 CFG.mag=8 发就是"八连发火箭筒"。 */
  e.ammo = Math.min(Math.max(1, (e.ammo || CFG.mag || 1) | 0), _cap);
}

/* 反应倍率：缩回、探头、抬手这些 HUMAN.* 的时长统一乘它。
   <1 = 更快（职业兵 0.38）；没写这个字段的怪等于 1，行为一字不变。 */
/* 职业兵受击后转移到真掩体；锁住已选路线，连续命中不反复换目标。 */
function specSeekCover(e, threat){
  const _B = behaviorOf(e);
  if(!_B.seekCoverOnNoise||e.dead||e.fleeing||!humanOn())return;
  if((e.specCoverCd||0)>0)return;
  e.specCoverCd=.8;
  if(e.hideGoal&&e.peekPhase==='run'&&dist(e.x,e.y,e.hideGoal.x,e.hideGoal.y)>18)return;
  threat = threat || ((typeof enemyThreatOf === 'function') ? enemyThreatOf(e) : player);
  if (!threat || threat === e) return;
  const p=pickHideSpot(cur(),e,_B.coverStrategy==='advance'?120:170,true,threat);
  if(!p||dist(e.x,e.y,p.x,p.y)>700||dist(e.x,e.y,p.x,p.y)<20)return;
  e.hideGoal={x:p.x,y:p.y};e.coverOK=1;eStatusSet(e,'fear',4);
  e.peekPhase='run';e.peekT=0;e.tucked=false;e.holding=0;e.glanceT=0;e.glanceAt=null;
  e.tacticPhase=null;e.tacStage=null;e.blindShot=false;e.hideT=0;
  e.path=null;e.goal=null;e.chk=null;e.stuckT=0;
}
function specRetreatFire(e,dt,walled,d,target){
  if(!behaviorOf(e).retreatFire)return;
  const t=target||player;
  if(!t||t.dead||t.gone||(t.hp!==undefined&&t.hp<=0)||!factionWantsFight(e,t))return;
  if(e.reloading>0){
    e.reloading=Math.max(0,e.reloading-dt);
    if(e.reloading===0)e.ammo=weaponCore(e.wid).cap;
  }
  if(e.ammo<=0&&e.reloading<=0)e.reloading=enemyReloadTime(e);
  if(walled||d>520||
     (t===player&&(player.grace>0||concealed||player.hp<=0||(nightBlindsAi()&&flashK<.18)))||
     smokeBlocks(e.x,e.y,t.x,t.y,true))return;
  const a=Math.atan2(t.y-e.y,t.x-e.x);
  e.ang=normAng(e.ang+clamp(normAng(a-e.ang),-12*dt,12*dt));
  if(e.reloading>0||e.ammo<=0||e.fireCd>0||Math.abs(normAng(a-e.ang))>.4)return;
  e.blindShot=false;
  enemyFireWeapon(e,enemies.indexOf(e),undefined,undefined,t);
}

function reactK(e){
  const k = enemyType(e).quickK;
  return (k === undefined || !(k > 0)) ? 1 : k;
}

/* 敌人身上的甲：目前只有职业兵（spec）有，等价三级防弹衣的减伤。
   玩家打上去的伤害先乘这个系数，再扣血 —— 别在别处再削一次。 */
/* 一件新甲：数据和玩家穿的完全同源（ARMOR_DEF），只是挂在谁身上 */
function armorOf(kind){
  const A = armorDef(kind);
  if (!A) return null;
  return { kind: kind, label: A.label, hp: A.dur, maxHp: A.dur, reduce: A.reduce };
}
/* 这一下打过来，甲到底挡多少：刀/爆炸以后可以单独调，armorK 缺省 1 */
function armorReduceFor(A, src){
  if (!A) return 0;
  /* 系数永远现查 ARMOR_DEF：改数据文件就能让「场上已穿着的甲」立刻变，不用重开 */
  const D = armorDef(A.kind) || A;
  const k = (src === 'blade') ? (D.bladeK === undefined ? 1 : D.bladeK)
          : (src === 'blast') ? (D.blastK === undefined ? 1 : D.blastK)
          : 1;
  return clamp((A.reduce === undefined ? D.reduce : A.reduce) * k, 0, 0.95);
}
/* 甲的磨损系数：bladeWear 是"挨一刀磨掉多少耐久"（相对这一刀伤害的倍数）。
   防弹衣不防刀（刀伤原样进血），但钢板照样会挨磨 —— 以前 bladeK=0 时连耐久都不掉，
   等于"刀砍上去甲毫发无伤"，不合理。 */
function bladeWearK(){
  return (typeof ARMOR_K_DEF !== 'undefined' && typeof ARMOR_K_DEF.bladeWear === 'number')
    ? clamp(ARMOR_K_DEF.bladeWear, 0, 4) : 1;
}
/* 甲吃伤害：返回 { hp: 真正落到血上的, broke: 甲是不是这一下碎的 } */
function armorSoak(A, dmg, src){
  let left = dmg, broke = false;
  if (A && A.hp > 0 && left > 0){
    /* 防弹衣只防子弹：刀、爆炸、毒、流血都不吃减伤，也不磨耐久 */
    if (src !== 'bullet') return { hp: left, broke: false };
    const r = armorReduceFor(A, src);
    if (r > 0){
      const absorbed = left * r;
      const eat = Math.min(A.hp, absorbed);
      /* 爆炸对护甲的耐久是"毁灭性"的：挡掉的伤害照算，但甲掉得比挡的多 2.6 倍 */
      const wear = Math.min(A.hp, absorbed * (src === 'blast' ? 2.6 : 1));
      A.hp -= wear;
      left -= eat;
      if (A.hp <= 0.001){ A.hp = 0; broke = true; }
    }
  }
  return { hp: left, broke: broke };
}
/* 通用发甲：谁都能穿（BOSS 除外），穿哪一档看 e.armorKind → 数据里的 armorKind → 最后才去摇概率表。
   ARMOR_ROLL 默认 on:false，所以现在除了职业兵谁都没甲；想开就把 on 改 true（见 data\enemies.js）。
   临时指定某一只：`e.armorKind = 'heavy'; e.armor = undefined; ensureEnemyArmor(e);` */
function rollEnemyArmor(e){
  const R = (typeof ARMOR_ROLL !== 'undefined') ? ARMOR_ROLL : null;
  if (!R || R.on !== true) return null;
  const T = enemyType(e);
  if (T.armorKind || e.bossKind || T.bossKind) return null;   /* 自带甲的 / BOSS 不摇 */
  const list = R.table && R.table[e.type];
  if (!list || !list.length) return null;
  for (const row of list){
    if (!row || !row.kind) continue;
    if (arenaRandom() < (row.p || 0)) return row.kind;
  }
  return null;
}
function ensureEnemyArmor(e){
  if (e.armor !== undefined) return e.armor;
  const T = enemyType(e);
  const kind = e.armorKind || T.armorKind || rollEnemyArmor(e);
  e.armorKind = kind || null;          /* 这一只实际穿的是哪一档（绘制、掉落、面板都读它） */
  e.armor = kind ? armorOf(kind) : null;
  return e.armor;
}
/* 敌人挨一下：返回真正落到血上的伤害；甲被这一下打碎就掉甲（并留下 e.armorGone） */
function absorbEnemyArmor(e, dmg, src){
  /* 压上期间被压制：连挨 HIT_RUSH_BREAK 枪、或者吃到爆炸，立刻放弃压上，
     就地找掩体打对枪 —— 不许顶着弹雨一路走到玩家脸上。 */
  if (e && !e.dead && (e.rushT || 0) > 0){
    e.rushHits = (e.rushHits || 0) + 1;
    if (src === 'blast' || e.rushHits >= HIT_RUSH_BREAK){
      e.rushT = 0; e.rushLeg = 0; e.rushPause = 0; e.rushCov = null; e.rushHits = 0;
      e.rushLockT = HIT_RUSH_LOCK;            /* 锁住：这几秒里再挨枪也只会往掩体里缩 */
      e.fearT = 0; eStatusClear(e, 'fear');
      e.strafeT = 0;
      specSeekCover(e);
      if (e.hideGoal && HITREACT && HITREACT.breakBark) setBark(e, HITREACT.breakBark, 1.6, 1, false);
    }
  }
  const A = ensureEnemyArmor(e);
  const r = armorSoak(A, dmg, src);
  if (r.broke){
    e.armor = null;
    e.armorGone = true;
    for (let i = 0; i < 8; i++) spawnPart(e.x, e.y, fxRand(0, TAU), fxRand(50, 190), fxRand(0.16, 0.34), 'mspark', fxRand(1.0, 2.0));
    spawnPart(e.x, e.y, 0, 0, 0.20, 'ring', 12);
    sfxSlam(false);
    setBark(e, '甲碎了。', 1.6, 1, false);
  }
  return Math.max(1, Math.round(r.hp));
}
function enemyArmorK(e){
  const T = enemyType(e);
  return 1 - clamp(T.armor || 0, 0, 0.9);
}

/* 打死后往地上扔东西。掉什么完全由 ENEMY_TYPES[type].drops 决定，
   弹药类不用写种类，掉的就是它手里那把枪吃的那种。 */
function dropLoot(e){
  if (!hasFeat('loot')) return;          /* 老关卡的人机还是什么都不掉 */
  /* 观战图（rules.noLoot）：人机独场秀，地上不许躺东西挡视线 */
  const _Ld = cur();
  if (_Ld && _Ld.rules && _Ld.rules.noLoot) return;
  /* 这一关允许掉枪：只掉你还没有的那把 —— 重复的枪捡起来没有任何意义 */
  const L0 = cur();
  if (!ar && L0.dropGuns && e.wid && WEAPONS[e.wid] && gunCountModel(e.wid) < 2){
    const gs = safeSpot(L0, {x: e.x + 14, y: e.y + 10}, 14);
    loots.push({x:gs.x, y:gs.y, taken:false, cool:0.7, killDrop:true,
                kind:'gun', wid:e.wid, mag: Math.max(1, Math.ceil(WEAPONS[e.wid].cap * 0.4))});
  }
  /* 战斗，爽！！里子弹是无限的、枪也全给了，所以只掉药，而且掉得比剧情模式勤 */
  /* 场上没捡的药会一直画（每件一次光晕），后期一波几十只死下来就铺满地图。
     超过 20 件就不再掉了 —— 药够用，别让它变成负担（以前是 40，满血时整张图都是药）。 */
  if (ar){
    let n = 0;
    for (const l of loots) if (!l.taken && l.killDrop) n++;
    if (n >= ARENA_LOOT_MAX) return;
  }
  const table = ar ? [{ kind:'med', p:0.26, rarity:'small' },
                      { kind:'med', p:0.06, rarity:'big' }]
                   : enemyType(e).drops;
  if (!table || !table.length) return;
  const L = cur();
  const wAmmo = (e.wid && WEAPONS[e.wid]) ? WEAPONS[e.wid].ammo : 'pistol';
  for (let i = 0; i < table.length; i++){
    const d = table[i];
    if (d.p !== undefined && arenaRandom() > d.p) continue;
    /* 上面那道闸只在进门时数了一次，一个人掉两样就会顶过线；
       每件落下来之前再数一遍，保证严格不超。 */
    if (ar){
      let n2 = 0;
      for (const l of loots) if (!l.taken && l.killDrop) n2++;
      if (n2 >= ARENA_LOOT_MAX) return;
    }
    /* 同一个人掉好几样的时候转着圈摆开，别叠成一坨 */
    const at = safeSpot(L, {x: e.x + Math.cos(i*2.1 - 0.6)*22, y: e.y + Math.sin(i*2.1 - 0.6)*22}, 14);
    if (d.kind === 'ammo'){
      const t = d.ammo || wAmmo;
      loots.push({x:at.x, y:at.y, taken:false, cool:0.7, killDrop:true,
                  kind:'ammo', ammo:t, n: d.n || ammoDef(t).box});
    } else if (d.kind === 'med'){
      loots.push({x:at.x, y:at.y, taken:false, cool:0.7, killDrop:true,
                  kind:'med', rarity: d.rarity || 'small'});
    } else if (d.kind === 'armor'){
      /* 带耐久的甲：durPct 是百分比区间，每个掉落的耐久都不一样（别写死） */
      const AD = (typeof ARMOR_DEF !== 'undefined' && ARMOR_DEF[d.armor]) ? ARMOR_DEF[d.armor] : null;
      const dur = AD ? AD.dur : 250;
      const rng = d.durPct || [1, 1];
      const body = (e && e.armor && e.armor.kind === (d.armor || 'light')) ? e.armor : null;
      const hp = body ? Math.max(1, Math.round(body.hp)) : Math.max(1, Math.round(dur * lerp(rng[0], rng[1], arenaRandom())));
      loots.push({x:at.x, y:at.y, taken:false, cool:0.7, killDrop:true,
                  kind:'armor', armor: d.armor || 'light', hp: hp, maxHp: dur});
    } else if (d.kind === 'smoke'){
      loots.push({x:at.x, y:at.y, taken:false, cool:0.7, killDrop:true,
                  kind:'smoke', n: d.n || 1});
    } else if (d.kind === 'gun'){
      const GW = (typeof WEAPONS !== 'undefined') ? WEAPONS[d.wid] : null;
      if (!GW) continue;
      const mag = (d.mag !== undefined) ? d.mag : Math.max(1, Math.round((GW.cap || 1) * 0.5));
      loots.push({x:at.x, y:at.y, taken:false, cool:0.7, killDrop:true,
                  kind:'gun', wid: d.wid, mag: mag});
    } else {
      loots.push({x:at.x, y:at.y, taken:false, cool:0.7, killDrop:true, kind:d.kind});
    }
  }
  /* 背包：不进 drops 表，单独一次掷骰（普通兵极小概率、职业兵/突击兵大概率掉三级包） */
  if (!ar && typeof BAG_DROP !== 'undefined' && BAG_DROP.on !== false){
    const isElite = (BAG_DROP.elite || []).indexOf(e.type) >= 0;
    const _pick = (o) => (o ? (isElite ? (o.elite || 0) : (o.normal || 0)) : 0);
    const pB = _pick(BAG_DROP.pBig), pM = _pick(BAG_DROP.pMid);
    /* 先看三级包，没中再看二级包：一个人最多掉一个，不会既掉三级又掉二级 */
    let _bt = null;
    /* 一次掷骰、按阈值切段：这样"三级 25% + 二级 35%"就是各占 25/35 个百分点，
       不会出现"先掷三级没中才掷二级"把二级压成 (1-0.25)*0.35 的情况 */
    const _rB = arenaRandom();
    if (pB > 0 && _rB < pB) _bt = 'big';
    else if (pM > 0 && _rB < pB + pM) _bt = 'mid';
    if (_bt){
      const at = safeSpot(L, {x: e.x + Math.cos(2.4) * 24, y: e.y + Math.sin(2.4) * 24}, 14);
      loots.push({x:at.x, y:at.y, taken:false, cool:0.7, killDrop:true,
                  kind:'bag', bag: _bt});
    }
  }
}
/* 会"看见就报警"的机器：摄像头固定、无人机乱飞，但报警流程是同一套 */
function isAlarmer(o){ const T = enemyType(o); return !!(T.alarm && (T.static || T.fly || T.kind === 'drone')); }

/* 出生点离玩家起点至少这么远；不够就整条换掉 */
const SPAWN_SAFE = 420;

/* 刀手：随机丢在一个离出生点够远、又看不见出生点的空地上。
   开局就站在明处会被玩家一进门就看见，那就不叫黑暗关里的威胁了。 */
function makeBladeEnemy(L){
  const T = ENEMY_TYPES.blade;
  let q = null;
  for (let k = 0; k < 260; k++){
    const x = rand(70, L.w - 70), y = rand(70, L.h - 70);
    const c = safeSpot(L, {x: x, y: y}, 26);
    const d = dist(c.x, c.y, L.start.x, L.start.y);
    if (d < 480 || d > 1400) continue;
    if (losBlocked(c.x, c.y, L.start.x, L.start.y)){ q = c; break; }
  }
  if (!q) q = safeSpot(L, {x: L.w * 0.5, y: L.h * 0.5}, 26);
  /* 巡逻点：在出生位置附近绕几个能走到的空地，别站着当雕像 */
  const wp = [[q.x, q.y]];
  for (let k = 0; k < 4; k++){
    const a = rand(0, TAU), rr = rand(140, 420);
    const c = safeSpot(L, {x: q.x + Math.cos(a) * rr, y: q.y + Math.sin(a) * rr}, 24);
    wp.push([c.x, c.y]);
  }
  return {
    type: 'blade', x: q.x, y: q.y, r: T.r, ang: rand(0, TAU),
    wp: wp, i: 0, wait: rand(0, 1.2),
    mode: 0, lastKnown: null, alertT: 0, sees: false, heard: false, chk: null,
    ammo: 0, fireCd: 0, reloading: 0, muzzle: 0, bladeCd: rand(0.2, 0.8),
    /* 三分之一拿弯刀：更慢、更远、更痛 */
    wid: (arenaRandom() < 0.35 ? 'dao' : 'knife'),
    windup: 0, huntT: 0, slashT: 0, slashA: 0
  };
}

/* 关卡里直接摆一个训练假人（data 里写 devDummies:[{x,y,kind:'dummy'}]）
   —— 测试穿门射击要用："门后站一个人，打门能不能打到他"。 */
function makeDummyAt(x, y, kind){
  const k = kind || 'dummy';
  const DT = enemyType({type: k});
  const e = {
    type: k, x: x, y: y, r: DT.r || 14, ang: Math.PI / 2,
    wp: [], i: 0, wait: 0, mode: 0, lastKnown: null, alertT: 0,
    sees: false, heard: false, chk: null, ammo: 0, fireCd: 99, reloading: 0, muzzle: 0,
    hp: DT.hp, maxHp: DT.maxHp, fleeCd: 0,
    dummy: true, dummyIdx: (++_dummySeq),
    stunT: 1e9, spdK: 0, tucked: false, peekPhase: 'tuck',
    dHits: 0, dTotal: 0, dMax: 0, dCrit: 0, dLast: 0, dLog: []
  };
  if (DT.armorKind) e.armor = armorOf(DT.armorKind);
  return e;
}

/* 掷弹兵概率替换：把一部分普通步枪兵换成"会扔雷的普通兵"。
   生效条件（缺一不可）：
   - GRENADIER.on 为真、这兵种在 GRENADIER.from 里；
   - 关卡写了 rules.grenadierP（数值即概率），或在测试区用默认 GRENADIER.p；
   - 战斗爽（arena）与没写 grenadierP 的老关卡 —— 概率 0，一个都不会刷。 */
function maybeGrenadier(L, kind){
  if (typeof GRENADIER === 'undefined' || !GRENADIER || GRENADIER.on === false) return kind;
  if (!GRENADIER.from || GRENADIER.from.indexOf(kind) < 0) return kind;
  if (L && L.arena) return kind;
  const R = (L && L.rules) || {};
  let p = (R.grenadierP === undefined) ? (R.devTest ? GRENADIER.p : 0) : R.grenadierP;
  if (!(p > 0)) return kind;
  if (!ENEMY_TYPES[GRENADIER.type]) return kind;
  return (arenaRandom() < p) ? GRENADIER.type : kind;
}

function spawnEnemies(){
  const out = [];
  const L = cur();
  if (L.arena) return out;      /* 战斗，爽！！的人由波次自己刷 */
  /* 关卡自带的假人先摆上：它们不巡逻、不打人、打不死 */
  if (L.devDummies){
    for (const p of L.devDummies) out.push(makeDummyAt(p.x, p.y, p.kind));
  }
  const want = (L.rules && L.rules.enemyCount !== undefined) ? L.rules.enemyCount : CFG.enemies;
  const wantBlade = Math.max(0, (L.rules && (L.rules.bladeCount | 0)) || 0);
  /* 0 就是这一关本来没人（雨夜那种）：下面 clamp 的下限是 1，得先拦一道。
     "没人"不等于"没威胁"：雨夜只放刀手，不放带枪的。 */
  if (!(want > 0) && !wantBlade) return out;
  for (let i = 0; i < wantBlade; i++) out.push(makeBladeEnemy(L));
  const n = (want > 0) ? clamp(Math.round(want), 1, L.slots.length) : 0;
  /* 原来按关卡数组顺序取，第五关最后一条离起点只有 300px，困难模式人多就会刷在脸上。
     现在按"离起点由远到近"排序后再取，人多也只会从远端开始铺。 */
  const order = L.slots.map((s, idx) => ({
    s, idx, d: dist(s.x, s.y, L.start.x, L.start.y)
  })).sort((a, b) => (L.rules && L.rules.spawnNearFirst ? a.d - b.d : b.d - a.d));
  /* m34931：带 must 标记的巡逻线永远先刷。2-4 自动门就是靠它开门的——
     简单难度只刷 2 个人，如果都按「离起点最远优先」取，开门的那条巡逻线就没了，关卡直接无解。 */
  const _must = order.filter(o => o.s && o.s.must);
  const _rest = order.filter(o => !(o.s && o.s.must));
  const pick = _must.concat(_rest);
  const nReal = Math.max(n, Math.min(_must.length, L.slots.length));
  for (let i=0;i<nReal;i++){
    const pick0 = pick[i % pick.length];
    const s = safeSpot(L, pick0.s);
    const wpSrc = pick0.s.wp;            /* 巡逻路线始终用关卡里写的那条 */
    let px = s.x, py = s.y;
    /* 关卡可以自己定"离出生点多远才允许刷人"，默认 420 */
    const _safeD = (L.rules && L.rules.spawnSafe) || SPAWN_SAFE;
    if (pick0.d < _safeD){
      /* 整张图都离起点很近（小地图）时，至少往外推一把 */
      const a = Math.atan2(py - L.start.y, px - L.start.x) || 0;
      const q = safeSpot(L, {x: px + Math.cos(a)*_safeD, y: py + Math.sin(a)*_safeD}, 26);
      px = q.x; py = q.y;
    }
    const T = ENEMY_TYPES[CFG.eType] || ENEMY_TYPES.grunt;
    const _base = T === ENEMY_TYPES.sentinel ? 'sentinel' : 'grunt';
    const _et = maybeGrenadier(L, _base);
    out.push({
      type: _et,
      x:px, y:py, r:(ENEMY_TYPES[_et] || T).r, ang:0,
      /* 巡逻点也要避开墙：原来直接用作者写的坐标，有的贴着墙，人机会一直挤在墙边 */
      wp: wpSrc.map(p=>{ const q = safeSpot(L, {x:p[0], y:p[1]}, 22); return [q.x, q.y]; }), i:1, wait:0,
      mode:0, lastKnown:null, alertT:0, sees:false, heard:false, chk:null,
      ammo: CFG.mag, fireCd: rand(0.3,1.2), reloading:0, muzzle:0
    });
    assignWeapon(out[out.length-1]);
  }
  return out;
}

/* 规则归一化：数据里可以只写 rules.mode，代码里继续用 L.boss / L.blind 两个派生别名，
   这样老代码不用动，新关卡也只要写一行数据。 */
function normalizeRules(){
  for (const L of LEVELS){
    const r = L.rules || (L.rules = {});
    if (r.mode === undefined) r.mode = L.boss ? 'boss' : (L.blind ? 'blind' : 'stealth');
    L.boss = (r.mode === 'boss');
    L.blind = (r.mode === 'blind' || r.mode === 'boss');
    if (r.thermal === undefined) r.thermal = !L.boss;        /* 猎场这一层没电 */
    if (r.crouchLock === undefined) r.crouchLock = !!L.boss; /* 拉满电闸前只能静步 */
    if (r.switches === undefined) r.switches = L.boss ? 3 : 0;
    /* 白天 / 黑夜的玩法差别（不只是换皮）：
       hearK     听觉系数（白天环境嘈杂，脚步传得没那么远）
       walkDelay 看见你之后"走神"零点几秒才转身开枪（白天光线好，反应快）
       nightGlow 你自带的微光半径（夜里你能看见敌人多靠近你，白天是 0） */
    if (r.hearK === undefined) r.hearK = (L.theme === 'light') ? 0.72 : 1;
    if (r.walkDelay === undefined) r.walkDelay = L.boss ? 0 : ((L.theme === 'light') ? 0.10 : 0.32);
    if (r.nightGlow === undefined) r.nightGlow = (L.theme === 'light') ? 0 : 190;
    /* 雨夜：只看得见脚边那一圈（0 = 这一关不做黑暗遮罩） */
    if (r.nightR === undefined) r.nightR = 0;
    /* 雨夜：下雨 + 打雷。素材在 data/rain.js 里，进这一关才动态载入 */
    if (r.rain === undefined) r.rain = false;
  }
}
normalizeRules();

/* 玩家自己的心里话：新手引导不放在屏幕角落，贴着人说 */
let selfSay = '', selfSayT = 0, selfScript = [];

function saySelf(txt, dur){
  selfSay = txt; selfSayT = dur || 3.6;
}

function drawSelfTalk(){
  if (!selfSay || selfSayT <= 0) return;
  if (player && player.hp <= 0) return;      /* 人都倒下了就别再自言自语 */
  const k = Math.min(1, selfSayT / 0.45);
  if (k <= 0.01) return;
  ctx.save();
  ctx.globalAlpha = k;
  ctx.font = '15px "Microsoft YaHei",sans-serif';
  const tw = ctx.measureText(selfSay).width;
  const bw = tw + 26, bh = 34;
  const _px = player.x - cam.x, _py = player.y - cam.y;
  /* 先居中到人身上，再拉回可见区域内，不让它跑出屏幕 */
  let bx = _px - bw/2;
  bx = Math.min(Math.max(bx, 10), W - 10 - bw);
  const by = _py - player.r - 62;
  ctx.fillStyle = 'rgba(10,14,20,0.88)';
  roundRect(bx, by, bw, bh, 10); ctx.fill();
  ctx.strokeStyle = 'rgba(150,196,240,0.55)';
  ctx.lineWidth = 1.2;
  roundRect(bx, by, bw, bh, 10); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(_px - 6, by + bh - 1);
  ctx.lineTo(_px + 6, by + bh - 1);
  ctx.lineTo(_px, by + bh + 9);
  ctx.closePath();
  ctx.fillStyle = 'rgba(10,14,20,0.88)';
  ctx.fill();
  ctx.fillStyle = 'rgba(214,232,248,0.96)';
  ctx.textAlign = 'center';
  ctx.fillText(selfSay, bx + bw/2, by + 22);
  ctx.restore();
}

/* 本关的最低血量：rules.hpMin / 亿 100 取大。进关、换类型都会过一遍 */
function hpFloorOf(L){ const f = (L && L.rules && L.rules.hpMin) || 0; return Math.max(100, f); }
function applyHpFloor(L){
  const k = hpFloorOf(L);
  if (CFG.hp < k) CFG.hp = k;
  if (typeof syncHpRow === 'function') syncHpRow();
}
function reset(){
  if (ui.inv.open || ui.inv.carry) inventoryClose();
  if (typeof truckResetPlayerState === 'function') truckResetPlayerState();
  /* 每次重开/进关都算"重新进场"：清掉斗蛐蛐的已离开标记，
     否则回过大就再也进不去观战图（m41899） */
  if (typeof cricketEnter === 'function') cricketEnter();
  try { chunksReset(); staticInvalidate(); } catch (err) {}
  poolClearView(wreckFxs); poolClearView(ashes); ashT = 0; ashAcc = 0;   /* 特效池一起清掉 */
  if (typeof levelMusicStop === 'function') levelMusicStop();   /* 重开/换关不能把上一关的音乐带过去 */
  /* 开局前先把本关的血下限夹一下：困难/噩梦那几档连 100 都不到，进关就统一抬到 100 */
  applyHpFloor(cur());
  stClear();
  deathHit = null;
  deathCause = '';
  deathMsgText = '';
  deathK = 0; deathView = false; deathViewT = 0; dyingT = 0;
  revealAll = false; deadT = 0; replayT = 0; recBuf = []; recAcc = 0; vrecBuf = []; vrecAcc = 0; gT = 0; gPlaying = true; gAutoCam = true; gDrag = null;
  tutHordeDone = false;   /* 教程关每次重开都重新允许叫一次 */
  if (typeof alarmRushReset === 'function') alarmRushReset();
  confirmBack = false;
  statusOpen = false; statusT = 0;   /* 重开/换关时把状态面板收掉，别带进新局 */
  /* 重开就是重开：上一局的警报、螺旋桨声、合成警笛一律停掉。
     这条原来只在 boss 分支里，非 boss 关重开会带着上一局的声音进新局 */
  stopSiren();
  /* 耳鸣也是上一局留下的声音：重开必须停掉，否则被火箭弹炸过一次之后，
     新一局还会继续"嗡"（2026-11-23 反馈：上一把的晕眩下一把还在） */
  if (typeof tinStop === 'function') tinStop();
  if (typeof rocketAudioReset === 'function') rocketAudioReset();
  const L = cur();
  /* 这一关没有的难度档（比如空手的第一章配噩梦）自动落回困难，并说一句 */
  if (!diffAllowed(diffName, L)){
    const _bad = diffName;
    applyPreset('hard', false);
    setMsg('这一关没有「' + (DIFF_LABEL[_bad] || _bad) + '」这一档，已按困难开始', 3.2);
  }
  initBreakables(L);
  initDoors(L);            /* 门也在这里重建：reset() 是唯一的入口，别指望调用方记得 */
  /* 保险箱：等本局的墙、可拆箱子、门全部就位之后再摆一遍。
     initBreakables 里那次摆得太早——那时候"可拆箱子墙"（lootKind 非空、brk=1）还没并进 L.walls，
     于是 8/12 只箱子会摞在弹药箱/医疗箱/杂物堆上（用户报的"保险箱和某些容器重叠"）。
     dzPlaceSafes 自己会先把旧箱子摘掉，所以重复调用是安全的，数量还是 12。 */
  if (L.rules && L.rules.dz && typeof dzPlaceSafes === 'function' && L._safesDone !== 2){
    L._safesDone = 2;
    L.dzSafeCount = dzPlaceSafes(L, 12).length;
  }
  /* 出生点最后一道把关：到这一步 walls/brk/roofs 才是本局最终形态，
     早于 initBreakables 判断会漏掉"家具、屋顶、可拆墙展开"这些东西。 */
  if (typeof dzLvl !== 'undefined' && dzLvl === L && typeof dzSpawnBad === 'function' &&
      typeof dzFixSpawnPt === 'function' && dzSpawnBad(L, L.start)){
    L.start = dzFixSpawnPt(L, L.start || { x: L.w / 2, y: L.h / 2 });
  }
  THEME_LIGHT = (L.theme === 'light');
  player = {x:L.start.x, y:L.start.y, r:11, hp:CFG.hp, grace:1.6,
            armor:null,     /* 防弹衣：{kind, label, hp, maxHp, reduce}，数值在 data/items.js */
            bag:{ kind:(typeof BAG_DEFAULT !== 'undefined' ? BAG_DEFAULT : 'small'), label:'小背包', slots:6, ammoK:1.0 },
            grenades:CFG.grenades, battery:100, thermal:false, thermalOn:false, heatCd:0, heatOffT:0, heatKeyPrev:false, heatWorn:false,
            batLock:false, batRelease:false, god:false,
            loot:0, holdT:0, crouch:false, crouchLock:!!L.rules.crouchLock, flash:0, stepT:0, moving:false,
     walkToggleOn:false, walkKeyPrev:false,
            ammo: startingAmmo(), guns:null, gun:null, kickX:0, kickY:0, hintT:0, stunT:0, keys:0, nades:0, hand:null, nadeCooking:false, nadeFuseLeft:0, throwCd:0, nadeQueue:false,
            meleeSta:120, meleeStaMax:120, meleeStaDelay:0,
            stam:100, stamMax:100, stamLock:false, stamMsgT:0, lungeT:0, lungeA:0, lungeSpeed:0, recoverT:0};
  player.stamMax = Math.max(60, (cur().rules && cur().rules.stamMax) || 100);
  player.stam = player.stamMax;
  /* 关卡可以规定玩家开局属于哪个阵营（rules.factions.player），
     默认 'player'。放在这里是因为后面 resetCompanions/生成敌人都会读它。 */
  /* m35424：?nanwatch=1 时给玩家坐标装探针（player 刚建好，这里才装得上） */
  try { if (window.__NANWATCH_WANT && typeof installNanWatch === 'function') installNanWatch(); } catch (e){}
  player.faction = (L.rules && L.rules.factions && L.rules.factions.player) || 'player';
  CFG.devFreeze = false;   /* 暂停是临时状态，换关/重开都清掉 */
  devPlaceKind = null;
  devPlaceFac = null;
  devPlaceAng = 0;   /* 投放朝向只在换关/重开时归零（m43911：切兵种不该清） */
  grenades = []; smokes = []; nades.length = 0; nadeShards.length = 0; flares.length = 0; airDrops.length = 0; signalSpots.length = 0; poolClearView(bullets); reinforceT = -1; reinforceN = 0; nadeSquadCd = 0;
  resetCompanions();
  if (typeof factionResetRuntime === 'function') factionResetRuntime();
  trucks.length = 0;                /* 第三方单位（运兵车）跟着关卡一起清 */
  mgNests.length = 0;               /* 重机枪阵地也跟着关卡一起清 */
  if (L.boss){
    /* 第四关：没有会开枪的人机，只有一个猎手；血条没有意义 */
    enemies = [];
    switches = [];
    const pool = L.switchSpots.slice();
    for (let i=0;i<3;i++){
      const k = Math.floor(arenaRandom()*pool.length);
      const sp = safeSpot(L, pool.splice(k,1)[0], 34);
      switches.push({x:sp.x, y:sp.y, on:false, pulse:fxRand(0,TAU)});
    }
    /* 上一局拉完第三个闸时 openExit() 改过 L.extract，这里必须还原，
       否则重开这一关会凭空多出一个已开放的撤离点 */
    L.extract = {x:-9000, y:-9000, w:10, h:10};
    swDone = 0; exitOpen = false; bossExposed = false; hbProx = 0;
    exitArrowT = 0; runBannerT = 0; runT = 0;
    bossBoostLeft = 12; bossBoostWho = null;
    bossPVX = 0; bossPVY = 0; bossPrevX = null; bossPrevY = null;
    /* 难度决定开局有几个猎手：简单 1 个，普通/困难 2 个（其余几个去守点位） */
    const nHunt = (diffName === 'easy') ? 1 : 2;
    hunters = [];
    for (let i=0;i<nHunt;i++){
      const role = (i === 0) ? 'chase' : 'guard';
      const at = (role === 'guard')
        ? L.guardSpots[(i - 1) % L.guardSpots.length]
        : null;
      hunters.push(spawnHunter(role, at));
    }
    boss = hunters[0];
  } else {
    boss = null; hunters = []; switches = []; swDone = 0; exitOpen = false; bossExposed = false;
    enemies = spawnEnemies();
    /* 观战图（斗蛐蛐长廊）：两边的人由 cricketSpawn 自己摆，不用关卡 slots */
    if (typeof cricketOn === 'function' && cricketOn(L) && typeof cricketSpawn === 'function') cricketSpawn(L);
    /* 关卡数据里写了 cameras 就摆摄像头 —— 加摄像头同样只是加一段数据 */
    if (L.cameras) for (const c of L.cameras) enemies.push(spawnCamera(c));
    if (L.drones) for (const d of L.drones) enemies.push(spawnDrone(d));
  }
  /* 本关"听觉系数"落到每个敌人身上：白天环境嘈杂，同一套数值传得没那么远 */
  for (const e of enemies){
    if (!enemyType(e).static) e.HM = enemyType(e).hearMul * (L.rules.hearK || 1);
  }
  const nLoot = (L.rules && L.rules.devTest) ? L.loot.length : clamp(Math.round(CFG.loot),1,L.loot.length);
  /* 物资点：levels.js 里写什么就带什么
     —— {kind:'armor', armor:'light'} 这样就能在任何新关卡里自然刷出甲；
        wid / ammo / n / bag / hp 同理，以前只认 kind/rarity/gear，其它字段会被丢掉 */
  loots = L.loot.slice(0, nLoot)
                  .map(p=>{
                    const q = safeSpot(L, p, 20);
                    /* 关卡里只写 kind:'ammo' 却没写 ammo 的，是"老式方块物资"（黄色方箱），
                       不能当手枪弹刷出来 —— 从 3-1 起那批点全都缺 ammo 字段，误刷成了黄色子弹。 */
                    const _kind = (p.kind === 'ammo' && !p.ammo) ? 'supply' : (p.kind || 'supply');
                    const o = {x:q.x, y:q.y, taken:false, kind:_kind, rarity:p.rarity, gear:!!p.gear};
                    if (p.armor) o.armor = p.armor;
                    if (p.bag)   o.bag   = p.bag;
                    if (p.wid)   o.wid   = p.wid;
                    if (p.ammo)  o.ammo  = p.ammo;
                    if (p.n)     o.n     = p.n;
                    if (p.hp)    o.hp    = p.hp;
                    if (p.maxHp) o.maxHp = p.maxHp;
                    if (p.kind === 'armor' && !o.hp){
                      /* 关卡里刷出来的甲也是"捡到的旧东西"：按 durPct 抽，
                         没写 durPct 就 30%~85%，三成机会接近全新 */
                      const _AD = (typeof ARMOR_DEF !== 'undefined' && ARMOR_DEF[o.armor]) ? ARMOR_DEF[o.armor] : null;
                      const _dur = _AD ? _AD.dur : 80;
                      const _rng = p.durPct || [0.30, 0.85];
                      o.hp = Math.max(1, Math.round(_dur * rollDurPct(_rng[0], _rng[1])));
                      o.maxHp = _dur;
                    }
                    return o;
                  });
  /* 盾牌先只在"测试区"供应（正式关卡放不放、怎么放，等策划定）。
     这样 G 举盾 / Q 丢下·捡起 这套机制有地方能验。 */
  if (loots.length && L.rules && L.rules.devTest){
    loots[loots.length - 1] = { x: loots[loots.length - 1].x, y: loots[loots.length - 1].y,
                                taken:false, kind:'shield', cool:0 };
    /* 火箭筒也只在测试区供应（正式关卡放不放、怎么放，等策划定）：
       出生点旁边摆一把筒 + 两发弹，方便直接试爆炸范围 */
    const _st = L.start || { x: 170, y: 820 };
    const _g1 = safeSpot(L, { x: _st.x + 54, y: _st.y - 6 }, 18);
    loots.push({ x:_g1.x, y:_g1.y, taken:false, kind:'gun', wid:'rpg', cool:0 });
    for (let _i = 0; _i < 2; _i++){
      const _a1 = safeSpot(L, { x: _st.x + 54 + (_i ? 34 : 0), y: _st.y + (_i ? 30 : -34) }, 14);
      loots.push({ x:_a1.x, y:_a1.y, taken:false, kind:'ammo', ammo:'rocket', n:1, cool:0 });
    }
    /* 突击步枪：出生点右边三步摆一把 + 一盒步枪弹（测试区不塞进 weapons 列表，
       免得把开局的枪位撑满） */
    const _g3 = safeSpot(L, { x: _st.x + 96, y: _st.y - 26 }, 18);
    loots.push({ x:_g3.x, y:_g3.y, taken:false, kind:'gun', wid:'ar', cool:0 });
    const _a3 = safeSpot(L, { x: _st.x + 96, y: _st.y + 6 }, 14);
    loots.push({ x:_a3.x, y:_a3.y, taken:false, kind:'ammo', ammo:'ar', n:25, cool:0 });
    /* 热成像也只在测试区供应：出生点左手边一步，方便直接试戴 */
    const _g2 = safeSpot(L, { x: _st.x - 8, y: _st.y - 46 }, 16);
    loots.push({ x:_g2.x, y:_g2.y, taken:false, kind:'thermal', cool:0, gear:true });
    /* 热成像电池：测试区摆两颗（v2 关卡才有，正好这张图开了 thermalV2），
       点一下背包里那格就能把电量充满 */
    for (let _i = 0; _i < 2; _i++){
      const _b1 = safeSpot(L, { x: _st.x - 40 - _i * 26, y: _st.y - 12 }, 12);
      loots.push({ x:_b1.x, y:_b1.y, taken:false, kind:'heatcell', n:1, cool:0 });
    }
  }
  lootTotal = loots.filter(l => !l.gear).length;
  /* 热成像：地图上摆了就当"要自己找"，没摆就按老规矩开局直接戴着（老关卡不受影响） */
  player.heatWorn = (L.rules && L.rules.thermalGear === false)
    ? false                                     /* 这一关不让玩家自带热成像：要就得自己找 */
    : !loots.some(l => l.kind === 'thermal');
  player.thermalOn = false; player.thermal = false; player.heatOffT = 0;
  if (L.rules && L.rules.devTest) resetTestZone();
  else if (hasFeat('guns')) grantLoadout(L);
  camShake = 0; timeAlive = 0; msg=''; msgT=0; hitFlash = 0;
  selfSay = ''; selfSayT = 0; selfScript = [];
  /* 第一关没写 hint 也给它一句：新手引导不能靠屏幕角落那行小字 */
  /* noTalk：这一关故意一句台词都不给，让玩家自己摸（迷宫里写着"往右走"就废了） */
  const _coach = !L.arena && !(L.rules && L.rules.noTalk) && (levelIdx === 0 ||
                (L.rules && (L.rules.tutorial || L.rules.hint || L.rules.script)));
  if (_coach && L.rules && L.rules.script && L.rules.script.length){
    /* 关卡自己在数据里写了整段引导：第几句说什么、什么时候说 */
    selfScript = L.rules.script.map(o => ({t: o.t, txt: o.txt}));
  } else if (_coach){
    selfScript = [
      {t: 1.4, txt: (L.rules && L.rules.hint) || (levelIdx === 0
                 ? ('脚步放轻 —— ' + (CFG.walkToggle
                      ? '按一下 ' + keyLabel(BINDS.crouch) + ' 切静步'
                      : '按住 ' + keyLabel(BINDS.crouch) + ' 静步') + '，别让他们听见')
                 : '先看清楚周围再说')},
      {t: 11,  txt: '静步之后脚步声只剩三成半，蹲着敌人看见我的范围也更小'},
      {t: 24,  txt: '货在亮着的地方，捡够了就往撤离点走'}
    ];
  }
  concealed = false; concealLeft = 0; hbT = 0; stepRipples = []; enemySteps = [];
  /* 雨夜：进这一关才去拉 data/rain.js（2.4MB，别让别的关陪着背） */
  {
    const _w = (L.rules && L.rules.weather) || (L.rules && L.rules.rain ? 'rain' : 'clear');
    weatherSet(_w, true, true);
  }
  flashK = 0; boltPts = null; thunderWait = 4 + Math.random() * 4;
  rainDrops.length = 0;
  slashFx.length = 0;
  hurtArcs.length = 0;
  /* 上一局的残骸不能带进来：血泄、碎渣、尸块、弹痕、暴击数字、刀影 */
  splats.length = 0; poolClearView(fxParts); brkChunks.length = 0; brkDust.length = 0; rocketTrail.length = 0;
  tracers.length = 0; poolClearView(dmgNums); poolClearView(hurtNums); hitMarks.length = 0; meleeTrail.length = 0;
  /* 尸体也要清：不清的话快速重进会把上一局的尸体带进来，而且那些画面不走 update 就永远不消失 */
  corpses.length = 0;
  if (rainWant) rainScriptLoad(() => { rainDecode(); thunderDecode(); });
  else rainHardStop();
  cam = {x:0,y:0};
  updateCam();
  logInfo('game', '开局 · ' + L.name + ' · 地图 ' + L.w + '×' + L.h + ' · 人机 ' + CFG.enemies + ' · 每发 ' + CFG.eDmg);
  prewarmNav(L);              /* 导航网格提前建，别让第一只敌人帮你卡一下 */
  /* 屋子自动登记：正式关没有手写 rooms[] 时，敌人就没有"进屋找人"的能力（m37080）。
     这里必须放在 prewarmNav 之后、生成敌人之前。 */
  if (typeof autoRoomsFor === 'function') autoRoomsFor(L);
  if (typeof tacStatReset === 'function') tacStatReset();
  if (typeof boundReset === 'function') boundReset();
}

/* ---------------- 音效 ---------------- */
/* 把所有 new Audio(...) 出来的 <audio> 实例登记下来。
   为什么需要：车引擎/漂移、背景音乐这些是 HTMLAudio，不走 WebAudio 总线，
   "暂停时压总线"对它们完全无效（用户 m15129 就是听到漂移声没停）。
   包一层构造函数是最省事的做法——不用去改每个 new Audio 的调用点。 */
(function audioRegistry(){
  if (typeof window === 'undefined' || !window.Audio) return;
  if (window.__audioEls) return;
  window.__audioEls = [];
  const Orig = window.Audio;
  function Patched(src){
    const el = new Orig(src);
    if (audioIsBackground()) el.muted = true;
    try { window.__audioEls.push(el); } catch(e){}
    return el;
  }
  Patched.prototype = Orig.prototype;
  try { window.Audio = Patched; } catch(e){}
})();
function audioEls(){
  if (typeof window === 'undefined' || !window.__audioEls) return [];
  return window.__audioEls;
}

let actx = null, noiseBuf = null;
/* 所有音效都从这里出去：耳鸣时只压这一根总线，
   就不用去改几十个 sfx 函数（耳鸣自己走 destination，不受影响） */
let _duckBus = null, _duckLP = null;
let _pauseGain = null, _pauseWant = -1, _pauseGainWant = -1;
let _masterLimiter = null;
let _masterLimiterOn = false;
let _audioPageHidden = false, _audioBackgroundActive = false;
let _audioResumeAt = -Infinity, _audioWasRunning = false;
const _audioClock = { next:0, value:NaN, movedAt:0, retryAt:0, restarting:false };
let _duckTarget = NaN, _duckCutTarget = NaN;
function audioIsBackground(){
  // 窗口失焦时页面可以仍然可见（录屏控件、覆盖层、双屏等）。
  return _audioPageHidden || (typeof document !== 'undefined' && !!document.hidden);
}
function audioTryResume(fromGesture = false){
  const ctx = actx;
  if (!ctx || (_audioClock.restarting && !fromGesture) || audioIsBackground() ||
      (ctx.state !== 'suspended' && ctx.state !== 'interrupted')) return;
  const now = performance.now();
  if (!fromGesture && now - _audioResumeAt < 2000) return;
  _audioResumeAt = now;
  try {
    Promise.resolve(ctx.resume()).then(() => { if (ctx.state === 'running') _audioWasRunning = true; }, () => {});
  } catch (e){}
}
/* 状态事件可能缺失，甚至报告 running 但时钟一直不走。低频检查，避免正常帧反复唤醒设备。 */
function audioHealthTick(now = performance.now()){
  const ctx = actx, clock = _audioClock;
  if (!ctx || !_audioWasRunning || now < clock.next) return;
  clock.next = now + 500;
  if (state !== 'play' || audioIsBackground()){
    clock.value = NaN;
    return;
  }
  if (ctx.state !== 'running'){
    clock.value = NaN;
    audioTryResume();
    return;
  }
  if (ctx.currentTime !== clock.value){
    clock.value = ctx.currentTime;
    clock.movedAt = now;
    return;
  }
  if (now - clock.movedAt < 1500 || now < clock.retryAt || clock.restarting || typeof ctx.suspend !== 'function') return;
  clock.retryAt = now + 15000;
  const recovery = {};
  clock.restarting = recovery;
  if (typeof logWarn === 'function') logWarn('audio', '音频时钟未推进，正在恢复输出');
  const finish = () => {
    if (clock.restarting !== recovery) return;
    clearTimeout(recovery.timer);
    clock.restarting = false;
    clock.value = NaN;
    _audioResumeAt = -Infinity;
    if (actx === ctx) audioTryResume();
  };
  /* 有的设备已经挂起，但 suspend() 一直没有回执，不能把后续 resume 永久锁住。 */
  recovery.timer = setTimeout(finish, 750);
  try { Promise.resolve(ctx.suspend()).then(finish, finish); }
  catch (e){ finish(); }
}
function audioBackgroundChanged(){
  const hidden = audioIsBackground();
  audioPauseTick();
  if (_audioBackgroundActive === hidden) return;
  _audioBackgroundActive = hidden;
  _audioClock.value = NaN;
  if (hidden){
    if (typeof rocketAudioReset === 'function') rocketAudioReset();
    if (typeof vehEngineSilence === 'function') vehEngineSilence();
    if (typeof dzAudioStop === 'function') dzAudioStop();
    if (rainOn || rainSynth) rainStop();
  } else audioTryResume();
}
/* 所有音效都必须走这里。耳鸣(效果)优先级最高：
   耳鸣响着的时候总线音量压到 12%，同时低通从 20k 压到 900Hz（听感上就是"被耳鸣盖住、别的声音闷掉"），
   耳鸣结束后用慢时间常数放回来（约 0.9s 缓缓回升），而不是啪一下恢复。 */
/* 总线压限开关：正常游戏里由 game/05-audio.js 的 audioMasterLimit 控制；
   测试沙箱（只切了本文件一段源码）里没有那个全局，这里用 typeof 兜住，默认关。 */
function audioLimitWant(){
  return (typeof audioMasterLimit === 'undefined') ? false : !!audioMasterLimit;
}
function audioSyncMasterLimiter(){
  const want = audioLimitWant();
  if (!actx || !_pauseGain || want === _masterLimiterOn) return;
  if (want){
    try {
      if (!_masterLimiter){
        const limiter = actx.createDynamicsCompressor();
        limiter.threshold.value = -9;
        limiter.knee.value = 6;
        limiter.ratio.value = 14;
        limiter.attack.value = 0.003;
        limiter.release.value = 0.18;
        _masterLimiter = limiter;
      }
    } catch (e){ return; }
    _pauseGain.disconnect(actx.destination);
    _pauseGain.connect(_masterLimiter);
    _masterLimiter.connect(actx.destination);
  } else {
    _pauseGain.disconnect(_masterLimiter);
    _masterLimiter.disconnect(actx.destination);
    _pauseGain.connect(actx.destination);
  }
  _masterLimiterOn = want;
}

function duckBus(){
  if (!_duckBus && actx){
    _duckBus = actx.createGain();
    _duckBus.gain.value = 1;
    _duckTarget = NaN; _duckCutTarget = NaN;
    _duckLP = actx.createBiquadFilter();
    _duckLP.type = 'lowpass';
    _duckLP.frequency.value = 20000;
    _duckLP.Q.value = 0.6;
    /* 末端再加一级"暂停静音"：开发者暂停时把这一级压到 0。
       放最末端是因为有些声音（车引擎、漂移、雨声）是长循环，
       起点在暂停之前就开好了，只靠"不再触发新音效"是关不掉的。 */
    if (!_pauseGain){
      _pauseGain = actx.createGain();
      _pauseGain.gain.value = 1;
      _masterLimiterOn = false;
      _pauseGain.connect(actx.destination);
      audioSyncMasterLimiter();
    }
    _duckBus.connect(_duckLP);
    _duckLP.connect(_pauseGain);
  }
  return _duckBus || actx.destination;
}

/* 每帧按耳鸣强度算总线的"压多少 / 闷多少"。attack 快、release 慢（用户要的"慢慢回升"）。 */
const DUCK_FLOOR = 0.12;
/* 暂停静音：放在 render 里每帧调 —— update() 暂停时不跑，
   把静音逻辑放 update 里就是"暂停之后总线再也压不下去"。 */
function audioPauseTick(){
  const want = (audioIsBackground() || (typeof devFrozen === 'function' && devFrozen())) ? 0 : 1;
  /* HTMLAudio 先处理：这条路不依赖 WebAudio 是否可用 */
  if (_pauseWant !== want){
    _pauseWant = want;
    for (const el of audioEls()){ try { el.muted = (want === 0); } catch(e){} }
  }
  if (!actx) return;
  if (!_pauseGain){ duckBus(); }
  if (!_pauseGain) return;
  if (_pauseGainWant === want) return;
  _pauseGainWant = want;
  try { _pauseGain.gain.setTargetAtTime(want, actx.currentTime, 0.015); }
  catch(e){ try { _pauseGain.gain.value = want; } catch(e2){} }
}

function duckUpdate(){
  if (!actx) return;
  const bus = duckBus();
  if (!bus || !bus.gain) return;
  const lvl = clamp(tinLevel ? tinLevel() : 0, 0, 1);
  /* 长时间连续耳鸣（一屋子火箭筒轮流炸）会把这根总线一直压在 12% + 900Hz，
     听感就是"别的音效全被吞了"。连续超过 3 秒之后，慢慢把总线放回 55% / 6kHz：
     耳鸣本身照旧在响，但打斗声又回来了 —— 不是把音效丢掉，是别让一个效果霸占整场。 */
  /* 这一阵已经连续响了多久：用 tinDur - tinT 推，不另存状态（沙箱测试里也拿得到） */
  const _tinElapsed = typeof tinDur === 'number' ? Math.max(0, tinDur - tinT) : 0;
  const _chainK = clamp((_tinElapsed - 3.0) / 2.0, 0, 1);
  const _floor = DUCK_FLOOR + (0.55 - DUCK_FLOOR) * _chainK;
  let want = 1 - (1 - _floor) * lvl;
  /* 开发者暂停：整条音效总线静音（耳鸣仍然按它自己的曲线算，恢复时不会跳） */
  if (typeof devFrozen === 'function' && devFrozen()) want = 0;
  const now = actx.currentTime;
  let cur = 1;
  try { cur = bus.gain.value; } catch(e){}
  const attack = want < cur;                    /* 在往下压 = 快 */
  const tau = attack ? 0.05 : 0.55;             /* 松开 = 慢（约 4 个 tau ≈ 0.9s 回到原样） */
  if (want !== _duckTarget){
    _duckTarget = want;
    try { bus.gain.setTargetAtTime(want, now, tau); } catch(e){ try { bus.gain.value = want; } catch(e2){} }
  }
  if (_duckLP && _duckLP.frequency){
    /* 同上：连续耳鸣久了，低通不要一直压在 900Hz，慢慢回到 6kHz */
    const _lpFloor = 900 + (6000 - 900) * _chainK;
    const fq = 20000 - (20000 - _lpFloor) * lvl; /* 耳鸣越强，其它声音越闷 */
    if (fq !== _duckCutTarget){
      _duckCutTarget = fq;
      try { _duckLP.frequency.setTargetAtTime(fq, now, attack ? 0.05 : 0.55); } catch(e){ try { _duckLP.frequency.value = fq; } catch(e2){} }
    }
  }
}

function audioInit(){
  if (audioIsBackground()) return;
  if (actx){
    audioTryResume(true);
    return;
  }
  try { actx = new (window.AudioContext||window.webkitAudioContext)(); } catch(e){}
  if (!actx) return;
  _audioResumeAt = -Infinity;
  _audioWasRunning = actx.state === 'running';
  actx.addEventListener?.('statechange', () => {
    if (actx.state === 'running') _audioWasRunning = true;
    else if (_audioWasRunning) audioTryResume();
  });
  audioTryResume(true);
  /* 先把三段素材解码掉：decodeAudioData 是异步的，等真正要放的时候再解就来不及了 */
  try { alDecode(); } catch(e){}
  try { al2Decode(); } catch(e){}
  try { stepDecode(); } catch(e){}
  try { swDecode(); } catch(e){}
  try { hbDecode(); } catch(e){}
  try { lineDecode(); } catch(e){}
  try { loadGlass(); } catch(e){}
  try { bladeDecode(); } catch(e){}   /* 近战：挥刀 / 砍中各自切好片段 */
  /* 耳鸣素材 900KB，等开局稳下来再解，别和雨水抢 */
  setTimeout(function(){ try { tinDecode(); } catch(e){} }, 1200);
  /* 手雷爆炸素材 ~70KB，比耳鸣小得多，稍晚一点点解就行 */
  setTimeout(function(){ try { nadeBoomDecode(); } catch(e){} }, 1600);
  setTimeout(function(){ try { weaponSfxDecode(); } catch(e){} }, 1900);
  setTimeout(function(){ try { if (typeof pickSfxDecode === 'function') pickSfxDecode(); } catch(e){} }, 2100);
setTimeout(function(){ try { if (typeof rocketSfxDecode === 'function') rocketSfxDecode(); } catch(e){} }, 1800);
  /* 把常用合成音的滤波和包络提前渲染到短采样里。 */
  setTimeout(combatSamplesWarm, 250);
}


/* ---------------- 雨夜：雨声 / 雷声 ----------------
   素材是没加工过的录音，直接 loop 会在接缝处"咔"一下，所以雨声用两个源交叉淡化：
   第 k 段放到 dur-X 的时候就起第 k+1 段，双方各用 X 秒交叉，听起来是连续的雨。
   雷声一条文件里塞了好几种（远雷、炸雷、闷响），解码后按能量找起点，每次抽不同的一段。 */
const RAIN_XFADE = 1.5;
let darkKey = '', darkGrad = null, darkCanvas = null;   /* 黑暗遮罩：整块黑挖洞，缓存在离屏图上 */          /* 交叉淡化时长（秒） */
let rainWant = false, rainOn = false, rainNodes = [], rainCursor = 0;

/* 天气是一套独立机制，不是某一关的死通道：
   关卡数据只要写 weather:'rain' / 'storm' / 'drizzle' / 'clear'，
   开发者模式按 C 随时切换；雨、闪电、黑幕、花屏全走这里。 */
/* 雨的"满值"和雷的"满值"：所有 0~1 归一化都除这两个数，别在绘制里再写死。
   m21755：以前 1.35 在四处各写一遍，加一档更大的雨就会溢出。 */
const WMAX = { rain: 1.35, thunder: 1.8 };
/* 雨雾圈从"多大雨量开始起雾"到"满强度"的区间（m21755 从绘制里提出来） */
const FOG_RAIN = { lo: 0.28, span: 1.02 };

const WEATHER_DEF = {
  /* mask：打雷/下雨时"声音传不出去"的系数。1 = 照常传，0.3 = 只剩三成。
     雷暴里雷声会盖住枪声和脚步（人机听不见你，你也听不见他们）；
     想要哪个关卡用这套，只改 rules.weather 一个字段就行。
     flowDegrees 可选：0 向右、90 向下、180 向左。省略时继承当前风雨方向。 */
  clear:   { cat:'clear', label:'晴',   rain:0,    thunder:0,   mask:1.00 },
  drizzle: { cat:'rain',  label:'小雨', rain:0.55, thunder:0,   mask:0.85 },
  rain:    { cat:'rain',  label:'雨',   rain:1.0,  thunder:1.0, mask:0.55 },
  storm:   { cat:'rain',  label:'雷暴', rain:1.35, thunder:1.8, mask:0.30 },
  /* 大风：不下雨不打雷，只刮风 —— 顺风跑得快、逆风被顶住（见 73-wind.js） */
  breeze:  { cat:'wind',  label:'微风', rain:0,    thunder:0,   wind:1, windK:0.34, mask:1.00, push:0.50 },
  wind:    { cat:'wind',  label:'大风', rain:0,    thunder:0,   wind:1, windK:1.00, mask:1.00, push:0.85 },
  /* 风雷（m19577）：刮风 + 打雷的组合。不下雨，但雷声照旧盖住脚步和枪声，
     传声只剩 42%（脚步声纹明显变小）；同时整片场子被风顶着，
     逆风跑吃力、顺风被推一把 —— push 是这一档的风力倍率（1 更大） */
  gale:    { cat:'wind',  label:'风雷', rain:0,    thunder:1.15, wind:1, windK:0.88, mask:0.30, baseMask:0.42, push:1.00 },
  /* 狂风暴雨：风雷再叠一场大雨 —— 雨声 + 风声双重盖脚步，风更猛、雷更密 */
  squall:  { cat:'rain',  label:'狂风暴雨', rain:1.35, thunder:1.6, wind:1, windK:1.10, mask:0.24, baseMask:0.34, push:1.12 },
  /* 大雾雷暴（m21653）：不下雨，只有雾 + 雷。打雷那一下整屏被照亮、能看清地形；
     平时所有人（玩家和敌人）的视距大幅缩短，且只有视野锥正前方勉强能看清。
     pin:1 = 这档天气一旦生效就整局锁定，不参与轮换（用户要求）。 */
  fogstorm:{ cat:'vis',   label:'大雾雷暴', rain:0, thunder:0.9, wind:0, fog:1, seeK:0.45, mask:0.92, baseMask:0.88, pin:1 }
};
/* 开发者面板可手动选大雾雷暴。C 键和实战轮换都跳过锁定的测试天气。 */
const WEATHER_ORDER = ['clear', 'breeze', 'wind', 'drizzle', 'rain', 'storm', 'squall', 'gale', 'fogstorm'];
const WEATHER_CYCLE = WEATHER_ORDER.filter(k => !WEATHER_DEF[k].pin);
/* 每档的稳定持续时间（秒）及下一档权重。过渡耗时另计。 */
const WEATHER_ROTATION = {
  /* m24019：晴天的停留改成 1~6 分钟随机（原来 4~7 分钟），别一开局就晾太久 */
  clear:   { hold: [60, 360],  next: { breeze: 5, drizzle: 3 } },
  breeze:  { hold: [180, 300], next: { wind: 4, drizzle: 3 } },
  wind:    { hold: [90, 180],  next: { breeze: 2, gale: 4, drizzle: 2 } },
  drizzle: { hold: [120, 210], next: { rain: 5, clear: 2, breeze: 1 } },
  rain:    { hold: [150, 270], next: { drizzle: 4, storm: 4, squall: 2 } },
  storm:   { hold: [75, 120],  next: { rain: 5, squall: 3 } },
  squall:  { hold: [60, 105],  next: { rain: 5, storm: 3 } },
  gale:    { hold: [25, 34],   next: { squall: 5, storm: 4 } }
};
const WEATHER_ROTATE_BLEND = 12;
function weatherPickNext(current){
  const next = WEATHER_ROTATION[current]?.next;
  if (!next) return null;
  const choices = Object.entries(next).filter(([k, weight]) =>
    k !== current && WEATHER_DEF[k] && !WEATHER_DEF[k].pin && weight > 0
  );
  let roll = Math.random() * choices.reduce((total, [, weight]) => total + weight, 0);
  for (const [k, weight] of choices){
    roll -= weight;
    if (roll < 0) return k;
  }
  return null;
}
let weather = 'clear';
/* WXC = 当前"混合后"的连续参数（0~1 之间会连续变）。
   以前所有判断都直接读天气表，于是换天气必然是一次跳变；现在画面和声音都读 WXC。 */
const WXC = { rain:0, thunder:0, wind:0, windK:0, push:1, baseMask:1, mask:1, fog:0, seeK:1, angle:null };
let wFrom = 'clear', wTo = 'clear', wMix = 1, wDur = 0;
/* 打断过渡时从"当前混合状态"接着走，而不是跳回起点（m21975） */
let wStart = null;
let wRotT = 0, wRotNext = null, wWindPrev = false, wSettled = true;
/* m21975：屏幕上的"雨雾滤镜"单独走一条慢通道 —— 判定/声音照旧按 wDur 走，
   但画面用 ~4 秒的时间常数慢慢追上去，从晴天切到雨天不会"啪"地糊上一张膜。 */
let wVizRain = 0;
/* 变天预警（m20460）：轮换到点前 WEATHER_WARN_LEAD 秒开始给提示；
   但**硬核难度不给**（用户要求：硬核就是要被天气阴）。 */
let wWarnT = 0, wWarned = false;
const WEATHER_WARN_LEAD = 3.6;
function weatherWarnAllowed(){
  if (typeof dzTier === 'undefined' || typeof dzLvl === 'undefined') return true;
  return dzTier !== 'core';
}
/* 预警要用的颜色：雨偏冷蓝、风偏灰白、雷偏紫白，按目标档的强弱混出来 */
/* m23747：变天预警只保留一行文字（setMsg），四边泛白那种滤镜取消 */

function weatherCh(k){
  const d = weatherDef(k);
  return {
    rain: d.rain || 0, thunder: d.thunder || 0, wind: d.wind ? 1 : 0,
    windK: (d.windK !== undefined ? d.windK : (d.wind ? 1 : 0)),
    push: (d.push !== undefined ? d.push : 1),
    baseMask: (d.baseMask !== undefined ? d.baseMask : 1),
    mask: (d.mask !== undefined ? d.mask : 1),
    fog: (d.fog !== undefined ? d.fog : 0),
    seeK: (d.seeK !== undefined ? d.seeK : 1)      /* 视距倍率：雾天 0.45，其它默认 1 */
  };
}
function weatherFlowTarget(k){
  const def = weatherDef(k);
  if (Number.isFinite(def.flowDegrees)) return normAng((def.flowDegrees % 360) * Math.PI / 180);
  if (WXC.angle !== null) return WXC.angle;
  if (!def.wind && !def.rain) return null;
  /* 第一段风雨才选择来向。之后即使短暂放晴也记住它。 */
  const tilt = rand(0.50, 0.72);
  return rand(0, 1) < 0.5 ? tilt : Math.PI - tilt;
}

/* 把 from→to 按进度 k(0~1) 混进 WXC，并顺手把"有没有风/雨"的开关同步过去 */
function wxApply(fromK, toK, k, aOverride){
  const a = aOverride || weatherCh(fromK), b = weatherCh(toK);
  const e = k * k * (3 - 2 * k);            /* smoothstep：两头慢、中间快，不会像线性那样"起步就变脸" */
  WXC.rain     = a.rain     + (b.rain     - a.rain)     * e;
  WXC.thunder  = a.thunder  + (b.thunder  - a.thunder)  * e;
  WXC.wind     = a.wind     + (b.wind     - a.wind)     * e;
  WXC.windK    = a.windK    + (b.windK    - a.windK)    * e;
  WXC.push     = a.push     + (b.push     - a.push)     * e;
  WXC.baseMask = a.baseMask + (b.baseMask - a.baseMask) * e;
  WXC.mask     = a.mask     + (b.mask     - a.mask)     * e;
  WXC.fog      = a.fog      + (b.fog      - a.fog)      * e;
  WXC.seeK     = a.seeK     + (b.seeK     - a.seeK)     * e;
  if (aOverride && aOverride.angle !== null) WXC.angle = normAng(aOverride.angle + aOverride.angleDelta * e);
  if (WXC.angle !== null && typeof windDirectionSet === 'function') windDirectionSet(WXC.angle);
  const _wk = clamp(WXC.wind, 0, 1);
  const windOn = _wk > 0;
  const _wp  = WXC.push * _wk;
  const _wkk = WXC.windK * _wk;
  if (windOn !== wWindPrev){
    wWindPrev = windOn;
    if (typeof windSet === 'function') windSet(windOn, _wp, _wkk);
    if (windOn && typeof windAudioStart === 'function') windAudioStart();
  } else if (windOn && typeof windPushSet === 'function'){
    windPushSet(_wp, _wkk);
  }
  /* windK 已包含有风/无风的插值，除以覆盖度得到有风部分的档位强度。 */
  if (typeof windVisualSet === 'function') windVisualSet(_wk, windOn ? WXC.windK / _wk : 0);
  rainWant = WXC.rain > 0.02;
}

/* 过渡到下一档：dur 秒内从当前档挪过去 */
function weatherTransition(k, dur, silent){
  if (!WEATHER_DEF[k]) k = 'clear';
  if (k === weather && wSettled) return;
  /* 从当前实际混合值起步：中途再按 C 也不会先跳回起点（m21975） */
  const targetAngle = weatherFlowTarget(k);
  const angle = WXC.angle ?? targetAngle;
  wStart = { ...WXC, angle, angleDelta:angle === null ? 0 : normAng(targetAngle - angle) };
  wFrom = weather; wTo = k; wMix = 0; wDur = Math.max(0.5, dur || 9); wSettled = false;
  weatherRotateReset();
  flashK = 0; flashT = 0; flashPulses = []; boltPts = null; boltW = null;
  thunderWait = 2 + Math.random() * 3;
  /* 资源先备好：只要有一头需要雨/雷的素材，就把素材拉下来 */
  const a = weatherCh(wFrom), b = weatherCh(wTo);
  if (a.rain > 0 || b.rain > 0 || a.thunder > 0 || b.thunder > 0){
    rainScriptLoad(function(){ rainDecode(); thunderDecode(); });
  }
  wxApply(wFrom, wTo, 0, wStart);
  if (!silent) setMsg('天气转 ' + weatherDef(k).label + ' ……', 2.2);
  if (typeof CFG !== 'undefined' && CFG.dev) logInfo('weather', '天气过渡 · ' + weatherDef(wFrom).label + ' → ' + weatherDef(k).label);
}

/* 每帧推进过渡 + 轮换（由 game/42-actors.js 的 update 调） */
function weatherTick(dt){
  /* 视觉雨量慢慢追（不受 wDur 影响，约 4 秒追到目标） */
  {
    const _vk = Math.min(1, Math.max(0, dt * 0.36));
    wVizRain += (WXC.rain - wVizRain) * _vk;
    if (Math.abs(WXC.rain - wVizRain) < 0.004) wVizRain = WXC.rain;
  }
  if (!wSettled){
    wMix = Math.min(1, wMix + dt / wDur);
    wxApply(wFrom, wTo, wMix, wStart);
    if (wMix >= 1){
      wSettled = true; weather = wTo; wStart = null;
      rainWant = weatherCh(wTo).rain > 0.02;
      if (!rainWant){ rainStop(); rainDrops.length = 0; }
      weatherRotateReset();
      if (typeof CFG !== 'undefined' && CFG.dev) logInfo('weather', '天气到位 · ' + weatherDef(wTo).label);
    }
    return;
  }
  if (state !== 'play' || !wRotNext) return;
  wRotT = Math.max(0, wRotT - dt);
  if (wRotT === 0){
    weatherTransition(wRotNext, WEATHER_ROTATE_BLEND);
    return;
  }
  if (!wWarned && wRotT <= WEATHER_WARN_LEAD){
    wWarned = true;
    if (weatherWarnAllowed()){
      wWarnT = wRotT;
      setMsg('天色变了 · 要转 ' + weatherDef(wRotNext).label, 2.4);
    }
  } else if (wWarnT > 0){
    wWarnT = wRotT;
  }
}

function weatherRotateReset(){
  wRotNext = null;
  wRotT = 0;
  wWarned = false;
  wWarnT = 0;
  const rotation = WEATHER_ROTATION[weather];
  if (!wSettled || !cur()?.rules?.weatherRotate || !rotation || weatherDef(weather).pin) return;
  wRotNext = weatherPickNext(weather);
  if (wRotNext){
    const [min, max] = rotation.hold;
    wRotT = min + Math.random() * (max - min);
  }
}

function drawWeatherDebug(){
  if (!CFG.dev || state !== 'play' || !cur()?.rules?.weatherRotate) return;
  let label;
  if (!wSettled){
    label = '天气过渡 · ' + weatherDef(wTo).label + ' · 剩 ' + Math.ceil(wDur * (1 - wMix)) + ' 秒';
  } else if (wRotNext){
    const seconds = Math.ceil(wRotT);
    const time = Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
    label = weatherDef(weather).label + ' · 下次天气 ' + weatherDef(wRotNext).label + ' · ' + time;
  } else if (weatherDef(weather).pin){
    label = weatherDef(weather).label + ' · 手动测试';
  } else {
    return;
  }
  ctx.save();
  ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'center';
  const width = ctx.measureText(label).width + 20;
  ctx.fillStyle = 'rgba(10,16,22,0.84)';
  ctx.fillRect((W - width) / 2, 16, width, 22);
  ctx.fillStyle = 'rgba(170,222,245,0.96)';
  ctx.fillText(label, W / 2, 31);
  ctx.restore();
}

function weatherDef(k){ return WEATHER_DEF[k] || WEATHER_DEF.clear; }
function weatherHasRain(){ return WXC.rain > 0.02; }
/* m21653：大雾雷暴把所有人的能见距离压下去（玩家、敌人一起压，公平）。
   fog=1 时只剩 45% 视距。 */
function weatherSeeK(){ return Math.min(1, Math.max(0.05, WXC.seeK)); }
function weatherHasThunder(){ return WXC.thunder > 0.05; }
function weatherHasWind(){ return WXC.wind > 0.02; }
function weatherActive(){ return weatherHasRain() || weatherHasThunder() || weatherHasWind(); }
function weatherLabel(){
  if (wSettled) return weatherDef(weather).label;
  return weatherDef(wFrom).label + ' → ' + weatherDef(wTo).label;
}

function weatherSet(k, silent, newRun = false){
  wVizRain = (weatherDef(k).rain) || 0;      /* m21975：瞬间切换就立刻到位 */
  if (!WEATHER_DEF[k]) k = 'clear';
  if (newRun) WXC.angle = null;
  WXC.angle = weatherFlowTarget(k);
  weather = k;
  const w = weatherDef(k);
  wFrom = k; wTo = k; wMix = 1; wDur = 0; wSettled = true;
  weatherRotateReset();
  wWindPrev = !!w.wind;
  if (typeof windSet === 'function') windSet(!!w.wind, w.push || 1, w.windK || 1);
  wxApply(k, k, 1);
  flashK = 0; flashT = 0; flashPulses = []; boltPts = null; boltW = null;
  rainWant = w.rain > 0;
  thunderWait = 2 + Math.random() * 3;
  if (w.wind && typeof windAudioStart === 'function') windAudioStart();
  if (rainWant || w.thunder > 0){
    rainScriptLoad(function(){ rainDecode(); thunderDecode(); });
  }
  /* m20749：只有"这一档有雨"才该有雨声。风雷是 thunder>0 但 rain=0，
     以前跟着雷一起进了拉素材那支，结果切过去雨声还在响 —— 这里单独再判一次。 */
  if (!rainWant){
    rainStop();
    rainDrops.length = 0;
  }
  if (!silent) setMsg('天气 · ' + w.label + (CFG.dev ? '（C 切下一个）' : ''), 1.6);
  if (CFG.dev) logInfo('weather', '天气切换 · ' + w.label);
}
function weatherCycle(){
  /* m21897：C 键也走过渡，方便直接看"换天"的效果；Shift+C 还是瞬间切，排查问题用。
     过渡时长 2 秒（比自然轮换的 9~13 秒短，纯粹方便开发看）。 */
  const i = WEATHER_CYCLE.indexOf(weather);
  const next = WEATHER_CYCLE[(i + 1) % WEATHER_CYCLE.length];
  if (!(keys.ShiftLeft || keys.ShiftRight)){
    weatherTransition(next, 2.0);
  } else {
    weatherSet(next);
  }
}
/* 黑幕是关卡自己的视野限制，跟天气无关 */
function nightDark(){ const L = cur(); return !!(L && L.rules && L.rules.nightR > 0); }
/* 3-4 那套「黑暗里谁也看不见谁」：敌人平时是瞎的，只有闪电亮的那一下才看得见你。
   死亡地带要的是「黑暗只管玩家，敌人眼睛正常」，所以用 rules.nightBlind:false 关掉这一层。 */
function nightBlindsAi(){ const L = cur(); return nightDark() && !(L && L.rules && L.rules.nightBlind === false); }
let rainBuf = null, rainDecoding = false, rainFailed = false, rainScriptLoading = false;
let thunderBuf = null, thunderDecoding = false, thunderFailed = false, thunderSeeds = null;
/* m21147：正在响的雷声（用来避免"三连雷"互相切） */
let thunderVoices = null;
let thunderWait = 6, flashK = 0, boltPts = null;
/* 雷响之后的一小段时间里，枪声和脚步都传不出去（人机也听不见），
   时长由 WEATHER_DEF[..].mask 决定衰减多少，不写 mask 的天气不遮声。 */
let thunderMaskT = 0;
/* 用户 m13205：雷声结束之后不要"啪"一下把听力全恢复，要缓慢放大回满。
   所以遮盖分三段：起手渐入（THUNDER_IN）→ 满遮盖（由 mask 决定的 1.15 秒）→ 回落（THUNDER_TAIL）。 */
let thunderTailT = 0;
const THUNDER_IN = 0.22, THUNDER_TAIL = 2.6;
/* 用户 m16699："瞬间变小那一段"要久一点 —— 满遮盖从 1.15 提到 2.4 秒，回涨速度不动。 */
const THUNDER_HOLD = 2.4;
function thunderMaskLevel(){
  const m = WXC.mask;
  if (m >= 1) return 1;                       /* 这种天气本来就不遮声 */
  if (thunderMaskT > 0) return m;             /* 雷一响就是满遮盖（雷是突然炸的，不该渐入） */
  if (thunderTailT > 0){                      /* 雷响完了：从满遮盖慢慢回到 1 */
    const a = thunderTailT / THUNDER_TAIL;    /* 1 → 0 */
    return m + (1 - m) * (1 - a);
  }
  return 1;
}
/* 每帧推进两个计时器（由 game/42-actors.js 的 update 调） */
function thunderMaskTick(dt){
  if (thunderMaskT > 0){
    thunderMaskT = Math.max(0, thunderMaskT - dt);
    if (thunderMaskT === 0 && thunderTailT <= 0) thunderTailT = THUNDER_TAIL;
  } else if (thunderTailT > 0){
    thunderTailT = Math.max(0, thunderTailT - dt);
  }
}
function hearMaskK(){
  /* baseMask：这一档天气"平时"就把声音压下去多少（风一直刮，不是只有打雷时才压）。
     没有这个字段的天气（晴天/小雨/雷暴）照旧只看雷声那套。 */
  return Math.min(WXC.baseMask, thunderMaskLevel());
}
/* 声音能传多远（枪声/脚步共用）。雷响的时候乘上掩盖系数，
   双方都用它 —— 你听不见他们的脚步，他们也听不见你的。 */
function maskedHearR(r){
  const k = hearMaskK();
  return k >= 1 ? r : r * k;
}
let flashT = 0, flashPulses = [], boltW = null;
let heatGlitch = 0;          /* 雷暴干扰热成像：大于 0 的时候屏幕上全是雪花 */

function rainScriptLoad(cb){
  if (window.RAIN_SRC){
    if (cb) cb();
    return;
  }
  if (rainScriptLoading) return;
  rainScriptLoading = true;
  try {
    const el = document.createElement('script');
    el.src = 'data/rain.js';
    el.onload = () => { rainScriptLoading = false; if (cb) cb(); };
    el.onerror = () => { rainScriptLoading = false; rainFailed = true; };
    document.body.appendChild(el);
  } catch(e){ rainScriptLoading = false; rainFailed = true; }
}

function b64ToBuf(src, ok, bad){
  try {
    const b = src.slice(src.indexOf(',') + 1);
    const bin = atob(b);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    actx.decodeAudioData(arr.buffer, ok, bad);
  } catch(e){ bad(); }
}

/* ---------------- 耳鸣 ----------------
   被火箭弹震到：一瞬间响起来，同时把所有音效压下去；结束时渐隐。
   时长按爆炸距离算（越近越久），素材是 data/tinnitus.js 里的 base64 mp3。 */
let tinBuf = null, tinDecoding = false, tinSrc = null, tinGain = null, tinT = 0, tinDur = 0, tinVol = 0;
let tinStartAt = 0, tinHitUntil = 0, tinHitK = 0, tinRearmAt = 0;
let tinPending = null;   /* 素材还没解码完时，先把这次爆炸记下来，解完立刻补响 */
function tinDecode(){
  if (tinBuf || tinDecoding || !actx || !window.TINNITUS_SRC) return;
  tinDecoding = true;
  b64ToBuf(window.TINNITUS_SRC,
    x => {
      tinBuf = x; tinDecoding = false;
      if (tinPending !== null){ const q = tinPending; tinPending = null; tinStart(q); }
    },
    () => { tinDecoding = false; });
}
function tinLevel(){
  if (!(tinT > 0) || !actx) return 0;
  const tail = Math.min(1, tinT / 0.9);
  const hit = Math.max(0, (tinHitUntil - actx.currentTime) / 0.24) * tinHitK * 0.18;
  return Math.min(1, tinVol + hit) * tail;
}
function tinStop(naturalEnd = false){
  tinT = 0; tinVol = 0;
  tinPending = null;
  tinHitUntil = 0; tinHitK = 0;
  if (!naturalEnd) tinRearmAt = 0;
  const src = tinSrc, g = tinGain;
  tinSrc = null; tinGain = null;
  if (!actx) return;
  const t = actx.currentTime;
  if (g){ try { g.gain.cancelScheduledValues(t); g.gain.setValueAtTime(g.gain.value, t); g.gain.linearRampToValueAtTime(0.0001, t + 0.3); } catch(e){} }
  if (src){ try { src.stop(t + 0.34); } catch(e){} }
}
function tinStart(k){
  if (!actx) return;
  tinDecode();
  if (!tinBuf){ tinPending = Math.max(tinPending || 0, k); return; }
  k = clamp(k, 0, 1);
  const dur = 2.2 + 5.4 * k;             /* 贴脸 ~7.6s，圈边 ~2.2s */
  const now = actx.currentTime;
  const stillInBurst = now < tinRearmAt;
  tinRearmAt = now + 1.4;
  /* 同一轮的后续冲击只加短促的压耳感，起点和结束时间保持原值。 */
  if (tinT > 0 && now < tinStartAt + tinDur){
    tinHitK = k;
    tinHitUntil = now + 0.24;
    return;
  }
  if (tinSrc) tinStop(true);
  if (stillInBurst) return;
  const src = actx.createBufferSource();
  src.buffer = tinBuf; src.loop = true;
  const g = actx.createGain();
  g.gain.setValueAtTime(0.0001, now);
  g.gain.linearRampToValueAtTime(0.55, now + 0.045);   /* 瞬间出现 */
  const fadeAt = now + Math.max(0.6, dur - 0.9);
  g.gain.setValueAtTime(0.55, fadeAt);
  g.gain.linearRampToValueAtTime(0.0001, now + dur);   /* 结束前渐隐 */
  duckBus();
  src.connect(g); g.connect(_pauseGain || actx.destination); /* 跳过压耳滤波，共用末端压限 */
  try { src.start(now); src.stop(now + dur + 0.06); } catch(e){}
  tinSrc = src; tinGain = g; tinT = dur; tinDur = dur; tinVol = 0.65 + 0.35 * k;
  tinStartAt = now;
  tinUpdate(0);   /* 立刻把音量压下去，别等到下一帧 */
}
function tinUpdate(){
  if (!actx) return;
  if (tinT > 0){
    tinT = Math.max(0, tinStartAt + tinDur - actx.currentTime);
    if (tinT <= 0) tinStop(true);
  }
  duckUpdate();
}

function rainDecode(){
  if (rainBuf || rainDecoding || rainFailed || !actx || !window.RAIN_SRC) return;
  rainDecoding = true;
  b64ToBuf(window.RAIN_SRC,
    x => { rainBuf = x; rainDecoding = false; },
    () => { rainFailed = true; rainDecoding = false; });
}

function thunderDecode(){
  if (thunderBuf || thunderDecoding || thunderFailed || !actx || !window.THUNDER_SRC) return;
  thunderDecoding = true;
  b64ToBuf(window.THUNDER_SRC,
    x => { thunderBuf = x; thunderSeeds = thunderFindSeeds(x); thunderDecoding = false; },
    () => { thunderFailed = true; thunderDecoding = false; });
}

/* 一条文件里可能有好几种雷：按 60ms 窗口算能量，找"从安静突然变响"的地方当起点。
   每个起点往后取 2.6 秒算一个变种；一个都找不到就整段当一种。 */
function thunderFindSeeds(buf){
  const ch = buf.getChannelData(0);
  const sr = buf.sampleRate;
  const win = Math.max(1, Math.round(sr * 0.06));
  const rms = [];
  for (let i = 0; i + win < ch.length; i += win){
    let ss = 0;
    for (let j = 0; j < win; j++){ const v = ch[i + j]; ss += v * v; }
    rms.push(Math.sqrt(ss / win));
  }
  let peak = 0;
  for (const v of rms) if (v > peak) peak = v;
  if (!(peak > 0)) return [{ off: 0, dur: Math.min(3, buf.duration) }];
  const out = [];
  for (let i = 2; i < rms.length; i++){
    const before = Math.max(rms[i - 1], rms[i - 2]);
    if (rms[i] > peak * 0.22 && rms[i] > before * 2.2){
      const off = (i * win) / sr;
      if (!out.length || off - out[out.length - 1].off > 1.2){
        out.push({ off: off, dur: Math.min(3.2, Math.max(1.4, buf.duration - off)) });
      }
    }
  }
  return out.length ? out : [{ off: 0, dur: Math.min(3, buf.duration) }];
}

/* m20556：雨声以前是"每段各自定一个音量"，所以变天时听感是一格一格跳；
   现在所有段先汇到一条总线上，音量由总线连续跟随 WXC.rain（0.45 秒时间常数）。 */
let rainBus = null;
function rainBusGet(){
  if (!actx) return null;
  if (!rainBus){
    rainBus = actx.createGain();
    rainBus.gain.value = 0.0001;
    rainBus.connect(duckBus());
  }
  return rainBus;
}
/* m20641：录音只有"一段"，雨大只能变响。这一层是**算出来的**雨：
   一段白噪声 → 高通 + 低通（做"沙沙"的底），再加一层高 Q 带通 + 颤音（做"密"）。
   雨量越大：带通越亮（频率上移）、颤音越快、这一层越响 —— 听感是"下密了"，不只是"变响了"。 */
let rainSynth = null;
function rainSynthBuild(){
  if (!actx || rainSynth) return rainSynth;
  try {
    const mkNoise = function(sec){
      const n = Math.floor(actx.sampleRate * sec);
      const b = actx.createBuffer(1, n, actx.sampleRate);
      const d = b.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
      return b;
    };
    const buf = mkNoise(3.0);
    /* 底：宽带噪声，压掉低频以免糊 */
    const s1 = actx.createBufferSource(); s1.buffer = buf; s1.loop = true;
    const hp1 = actx.createBiquadFilter(); hp1.type = 'highpass'; hp1.frequency.value = 420;
    const lp1 = actx.createBiquadFilter(); lp1.type = 'lowpass'; lp1.frequency.value = 4200; lp1.Q.value = 0.5;
    const g1 = actx.createGain(); g1.gain.value = 0.16;
    /* 密：高 Q 带通 + 颤音，雨越大频率越高、颤得越快 */
    const s2 = actx.createBufferSource(); s2.buffer = buf; s2.loop = true;
    const bp = actx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 2600; bp.Q.value = 1.6;
    const g2 = actx.createGain(); g2.gain.value = 0.05;
    /* m20749：这层原来挂了 4~13Hz 颤音做"密"，听感像在打拍子，去掉。
       密度改成靠"两层错位素材 + 这层宽带噪声"叠出来，不用周期性调制。 */
    s1.connect(hp1); hp1.connect(lp1); lp1.connect(g1);
    s2.connect(bp); bp.connect(g2);
    const bus = rainBusGet();
    if (!bus) return null;
    g1.connect(bus); g2.connect(bus);
    s1.start(0); s2.start(0);
    rainSynth = { s1: s1, s2: s2, g1: g1, g2: g2, lp1: lp1, bp: bp };
    return rainSynth;
  } catch(e){ rainSynth = null; return null; }
}
/* 每帧跟着雨量推参数（0.25 秒时间常数，听不出台阶） */
function rainSynthTick(){
  const r = Math.min(1, Math.max(0, WXC.rain / WMAX.rain));
  if (r <= 0.02){ return; }
  const syn = rainSynthBuild();
  if (!syn || !actx) return;
  try {
    const now = actx.currentTime;
    syn.lp1.frequency.setTargetAtTime(3600 + 3200 * r, now, 0.25);
    syn.bp.frequency.setTargetAtTime(2000 + 2600 * r, now, 0.25);
    syn.g1.gain.setTargetAtTime(0.07 + 0.10 * r, now, 0.25);
    syn.g2.gain.setTargetAtTime(0.015 + 0.06 * r, now, 0.25);
  } catch(e){}
}
/* 硬停：换图/重开用，不讲究 */
function rainSynthStopNodes(syn){
  if (!syn) return;
  for (const k of ['s1','s2']){ try { syn[k].stop(); } catch(e){} }
  for (const k of ['g1','g2','lp1','bp']){ try { syn[k].disconnect(); } catch(e){} }
}
function rainSynthStop(){
  const syn = rainSynth;
  rainSynth = null;
  rainSynthStopNodes(syn);
}

function rainHardStop(){
  rainSynthStop();
  rainOn = false;
  if (rainBus){ try { rainBus.disconnect(); } catch(e){} rainBus = null; }
  for (const nd of rainNodes){
    try { nd.s.stop(); } catch(e){}
    try { nd.s.disconnect(); nd.g.disconnect(); } catch(e){}
  }
  rainNodes = [];
  rainCursor = 0;
}
/* 软停：雨停了但还在过渡，先淡出再拆（0.9 秒），不会"啪"一下没了 */
function rainStop(){
  rainOn = false;
  rainCursor = 0;
  const bus = rainBus;
  const list = rainNodes;
  const synth = rainSynth;
  rainBus = null;
  rainSynth = null;
  rainNodes = [];
  if (!bus && !list.length && !synth) return;
  if (bus){
    try {
      const now = actx.currentTime;
      bus.gain.cancelScheduledValues(now);
      bus.gain.setTargetAtTime(0.0001, now, 0.32);
    } catch(e){}
  }
  setTimeout(function(){
    for (const nd of list){
      try { nd.s.stop(); } catch(e){}
      try { nd.s.disconnect(); nd.g.disconnect(); } catch(e){}
    }
    rainSynthStopNodes(synth);
    if (bus){ try { bus.disconnect(); } catch(e){} }
  }, 1100);
}

/* 每帧调用：把"后面几段雨"排进时间线，而不是 loop 一个源（那样接缝必然断） */
function rainTick(){
  if (!rainWant || audioIsBackground()) return;
  if (!actx) return;
  if (!rainBuf){ rainDecode(); return; }
  const now = actx.currentTime;
  const bus = rainBusGet();
  if (!bus) return;
  if (!rainOn){ rainOn = true; rainCursor = now + 0.06; }
  const dur = rainBuf.duration;
  /* 总线音量连续跟随雨量：变天时是一条曲线，不是台阶 */
  const lvlNow = 0.5 * Math.min(1, Math.max(0.18, WXC.rain / 1.2)) * ((typeof ambVolK === 'function') ? ambVolK() : 1);
  try { bus.gain.setTargetAtTime(lvlNow, now, 0.45); } catch(e){}
  rainSynthTick();
  const X = Math.min(RAIN_XFADE, Math.max(0.2, dur * 0.25));
  let guard = 0;
  while (rainCursor < now + dur + 0.4 && guard++ < 4){
    const first = rainNodes.length === 0;
    const t0 = rainCursor;
    const s2 = actx.createBufferSource();
    s2.buffer = rainBuf;
    const g = actx.createGain();
    const lvl = 1.0;
    if (first){
      g.gain.setValueAtTime(lvl, t0);
    } else {
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(lvl, t0 + X);
    }
    g.gain.setValueAtTime(lvl, t0 + Math.max(X + 0.01, dur - X));
    g.gain.linearRampToValueAtTime(0.0001, t0 + dur);
    s2.connect(g); g.connect(bus);
    s2.start(t0);
    s2.stop(t0 + dur + 0.05);
    rainNodes.push({ s: s2, g });
    /* m20749：同一段素材再叠一层，错开半个周期、速率略微不同 ——
       两层叠起来就听不出"一段在循环"了（这也是用户提的做法）。 */
    const s3 = actx.createBufferSource();
    s3.buffer = rainBuf;
    s3.playbackRate.value = 1.043;
    const g3 = actx.createGain();
    const t3 = t0 + dur * 0.5;
    g3.gain.setValueAtTime(0.0001, t3);
    g3.gain.linearRampToValueAtTime(1, t3 + X);
    g3.gain.setValueAtTime(1, t3 + dur - X);
    g3.gain.linearRampToValueAtTime(0.0001, t3 + dur);
    s3.connect(g3); g3.connect(bus);
    s3.start(t3, dur * 0.37);
    s3.stop(t3 + dur + 0.05);
    rainNodes.push({ s: s3, g: g3 });
    if (rainNodes.length > 3) rainNodes.shift();
    rainCursor = t0 + dur - X;
  }
}

/* 多久之后再打一道雷。
   不是均匀随机 —— 真雷雨是有节奏的：大多几秒到十几秒，偶尔安静半分多钟，
   而且经常"连着响两下"。所以分三档抽样，再叠一点抖动。
   rules.thunderK 越小越稀疏（死亡地带 0.45），天气档的 thunder 越大越密（雷暴 1.8）。 */
function nextThunderWait(){
  const k = (cur().rules && cur().rules.thunderK) || 1;
  const spd = Math.max(0.05, WXC.thunder * k);
  const r = Math.random();
  let base;
  if (r < 0.30)      base = 0.8 + Math.random() * 1.6;   /* 连击：紧跟着又炸一下 */
  else if (r < 0.76) base = 4.5 + Math.random() * 8.5;   /* 常规间隔 */
  else               base = 24 + Math.random() * 24;     /* 长空档：雷雨中间那段安静 */
  base *= 0.85 + Math.random() * 0.3;                    /* 再抖 30%，别每次同一拍子 */
  /* 上限 55 秒：再长玩家会以为这局不打雷了 */
  return Math.min(55, base / spd);
}

/* 打一个雷：闪白 + 抽一段雷声 + 一点震屏 */
function thunderStrike(){
  /* 先做画面：没点过鼠标、声音还没初始化的时候，雷也得照闪 */
  flashK = 1;
  thunderMaskT = THUNDER_HOLD;   /* 这段时间里，枪声和脚步都被雷压住了 */
  thunderTailT = 0;         /* 新一轮雷，先把"回落"清掉 */
  camShake = Math.max(camShake, 0.32);
  /* 真雷不是"闪一下"，是连着闪几下、每下亮度都不一样：
     第一下最亮，隔 0.1 秒补一下暗的，再隔 0.15 秒回来一下更亮的。 */
  flashT = 0;
  flashPulses = [
    { t: 0,     amp: 1.00 },
    { t: 0.09 + Math.random() * 0.05, amp: 0.45 + Math.random() * 0.25 },
    { t: 0.26 + Math.random() * 0.10, amp: 0.70 + Math.random() * 0.30 }
  ];
  /* 雷暴对电子设备有干扰：热成像开着就花屏 */
  if (player && player.thermalOn) heatGlitch = 0.95;
  /* 闪电的折线每次重新生成一次，别每帧乱跳。
     真实闪电是上面粗、往下分叉变细，所以每段单独存一个宽度 */
  boltPts = [];
  boltW = [];
  let bx = W * (0.2 + Math.random() * 0.6), by = -10;
  let bw = 7.5;
  boltPts.push({ x: bx, y: by });
  boltW.push(bw);
  for (let i = 0; i < 9; i++){
    bx += (Math.random() - 0.5) * 78;
    by += H * 0.082;
    bw = Math.max(0.9, bw * 0.78);
    boltPts.push({ x: bx, y: by });
    boltW.push(bw);
  }
  bakeBolt();
  /* 打雷那一下整条街都亮了：附近的人因此知道你站在哪。
     注意只给一个半径（REVEAL_R），不是全图共享坐标 —— 离得远的人不该有雷达。 */
  if (player && enemies.length){
    const REVEAL_R = 640;
    for (const e of enemies){
      if (e.type !== 'blade') continue;
      if (dist(e.x, e.y, player.x, player.y) > REVEAL_R) continue;
      e.memo = { x: player.x, y: player.y };
      e.memoT = 6.5;
    }
  }
  if (!actx) return;
  thunderDecode();
  const now = actx.currentTime;
  if (!thunderBuf || !thunderSeeds || !thunderSeeds.length) return;
  try {
    /* m21147：三连雷时，旧版两声可能挤在 0.15 秒内同时起 —— 听起来像"第二声把第一声切了"。
       现在同一时间只让一声"主导"，新雷进来时把上一声平滑压下去（不是 stop），
       过近的直接往后排一小段，于是是"滚过去"而不是"被切断"。 */
    if (!thunderVoices) thunderVoices = [];
    for (let i = thunderVoices.length - 1; i >= 0; i--){
      const v = thunderVoices[i];
      if (!v || now - v.t0 > v.durr + 0.4){ thunderVoices.splice(i, 1); continue; }
      /* 旧版这里会把上一声压低 —— 用户听成"第二声把第一声切了"。
         现在只统计、不压：三声雷就是三声叠着滚，靠错开起音时间避免糊成一坨。 */
    }
    const seed = thunderSeeds[(Math.random() * thunderSeeds.length) | 0];
    const durr = Math.min(seed.dur, Math.max(0.8, thunderBuf.duration - seed.off));
    /* 变体：同一条素材靠"播速 + 低通 + 音量 + 偏移"组合出不同质感 */
    const rate = 0.82 + Math.random() * 0.42;         /* 0.82~1.24：更闷 ↔ 更脆 */
    const vol  = (0.48 + Math.random() * 0.30) * ((typeof ambVolK === 'function') ? ambVolK() : 1);
    const cut  = 620 + Math.random() * 1500;          /* 远雷闷、近雷亮 */
    const src = actx.createBufferSource();
    src.buffer = thunderBuf;
    src.playbackRate.value = rate;
    const lp = actx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = cut;
    lp.Q.value = 0.7;
    const g = actx.createGain();
    /* 雷声比画面慢一点：先看到闪，再听到；三连时后两声再往后错开一点 */
    const t0 = now + 0.06 + Math.random() * 0.10 + (thunderVoices.length ? 0.10 + Math.random() * 0.22 : 0);
    const realDur = Math.max(0.8, durr / rate);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + 0.05 + Math.random() * 0.05);
    g.gain.setValueAtTime(vol, t0 + Math.max(0.12, realDur - 0.7));
    g.gain.linearRampToValueAtTime(0.0001, t0 + realDur);
    src.connect(lp); lp.connect(g); g.connect(duckBus());
    src.start(t0, seed.off, Math.min(durr, Math.max(0.8, thunderBuf.duration - seed.off)));
    src.stop(t0 + realDur + 0.05);
    thunderVoices.push({ t0, durr: realDur, g });
    /* 回响层：一层更闷更轻的，错开 0.3~0.7 秒叠上去，听起来像在山谷/楼群里滚 */
    const dBuf = actx.createBufferSource();
    dBuf.buffer = thunderBuf;
    dBuf.playbackRate.value = rate * (0.66 + Math.random() * 0.12);
    const dlp = actx.createBiquadFilter();
    dlp.type = 'lowpass';
    dlp.frequency.value = 240 + Math.random() * 260;
    const dg = actx.createGain();
    const dt0 = t0 + 0.28 + Math.random() * 0.45;
    dg.gain.setValueAtTime(0.0001, dt0);
    dg.gain.linearRampToValueAtTime(vol * 0.42, dt0 + 0.12);
    dg.gain.linearRampToValueAtTime(0.0001, dt0 + Math.max(0.6, realDur * 0.85));
    dBuf.connect(dlp); dlp.connect(dg); dg.connect(duckBus());
    dBuf.start(dt0, seed.off, Math.min(durr, Math.max(0.8, thunderBuf.duration - seed.off)));
    dBuf.stop(dt0 + Math.max(0.7, realDur * 0.9));
  } catch(e){}
}


/* ---------------- 雨夜：黑暗遮罩 / 斜雨 / 闪电 ----------------
   这一关的目标不是"暗一点"，而是只看得见脚边那一圈：
   世界照常画完，再在屏幕上盖一层中间有洞的黑 —— 洞的半径就是 rules.nightR。
   打雷的时候把这一层整体压淡，于是整个画面"闪"一下就全亮，之后指数式暗回去。 */
const rainDrops = [];
/* m22299 朦胧感 A：一层随风雨漂移的噪声雾团，让远处不再是"一块死板" */
let fogNoiseCan = null, fogNoisePat = null;
/* m22515 A：画质档位 —— 0 高 / 1 低 / 2 极低（低配机器用 2） */
let PERF_LV = 0;
try { const _v = parseInt(localStorage.getItem('after5_perflv') || '0', 10); if (_v >= 0 && _v <= 2) PERF_LV = _v; } catch(e){}
try {
  /* m23956：URL 参数 ?fx=0|1|2 直接钉死雨雾特效档 */
  const _mfx = /[?&]fx=([^&]*)/.exec((typeof location !== 'undefined' && location.search) || '');
  if (_mfx){
    const _fx = parseInt(decodeURIComponent(_mfx[1]), 10);
    if (_fx >= 0 && _fx <= 2){ PERF_LV = _fx; localStorage.setItem('after5_perflv', String(_fx)); }
  }
} catch(e){}
function perfLv(){ return PERF_LV | 0; }
function perfSetLv(v){
  PERF_LV = Math.max(0, Math.min(2, v | 0));
  try { localStorage.setItem('after5_perflv', String(PERF_LV)); } catch(e){}
  if (typeof buildPerfRows === 'function') { try { buildPerfRows(); } catch(e){} }
  if (typeof setMsg === 'function'){
    setMsg('画质：' + ['高', '低', '极低'][PERF_LV] + (PERF_LV === 2 ? ' · 雨丝更少、雾改用静态贴图（遮挡不变）' : (PERF_LV === 1 ? ' · 雨丝更少' : '')), 2.4);
  }
}
/* C：雾团/光晕的预渲染贴图（128×128，白色径向 → 透明），每帧只 drawImage，不再 createRadialGradient */
let perfGlowCan = null;
function perfGlowBuild(){
  if (perfGlowCan) return perfGlowCan;
  if (typeof document === 'undefined' || !document.createElement) return null;
  try {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g = c.getContext('2d');
    const rg = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    rg.addColorStop(0, 'rgba(255,255,255,1)');
    rg.addColorStop(0.45, 'rgba(240,246,255,0.55)');
    rg.addColorStop(1, 'rgba(230,240,255,0)');
    g.fillStyle = rg; g.fillRect(0, 0, 128, 128);
    perfGlowCan = c; return c;
  } catch(e){ return null; }
}
/* m22372 B：光晕用的小图（1/6 分辨率） */
let bloomCan = null;
function fogNoiseBuild(){
  if (fogNoiseCan) return fogNoiseCan;
  if (typeof document === 'undefined' || !document.createElement) return null;
  const S = 64, D = 256;
  let small = null;
  try { small = document.createElement('canvas'); small.width = small.height = S; } catch(e){ return null; }
  const sg = small.getContext('2d');
  if (!sg || !sg.getImageData) return null;
  const img = sg.createImageData(S, S);
  for (let i = 0; i < img.data.length; i += 4){
    const v = 90 + Math.random() * 165;
    img.data[i] = v; img.data[i+1] = v; img.data[i+2] = v; img.data[i+3] = 255;
  }
  sg.putImageData(img, 0, 0);
  let big = null;
  try { big = document.createElement('canvas'); big.width = big.height = D; } catch(e){ return null; }
  const bg = big.getContext('2d');
  bg.filter = 'blur(10px)';
  bg.drawImage(small, 0, 0, D, D);
  bg.filter = 'none';
  fogNoiseCan = big;
  return fogNoiseCan;
}

function rainInitDrops(){
  rainDrops.length = 0;
  slashFx.length = 0;
  hurtArcs.length = 0;
  for (let i = 0; i < 240; i++){
    rainDrops.push({
      x: Math.random() * (W + 320), y: Math.random() * H,
      len: 16 + Math.random() * 26,
      spd: 820 + Math.random() * 620,
      a: 0.07 + Math.random() * 0.13
    });
  }
}

/* 当前这一帧的闪电亮度：几个衰减包取最大值（第一下最亮，后面两下是回响） */
function flashLevel(){
  let v = 0;
  for (const p of flashPulses){
    const a = flashT - p.t;
    if (a < 0) continue;
    const val = p.amp * Math.exp(-a / 0.105);
    if (val > v) v = val;
  }
  return Math.min(1, v);
}

/* 闪电：外面一层模糊的辉光，中间半透明，最里面才是亮白的芯；往下越来越细 */
/* 闪电画进一张离屏图层：shadowBlur 是最贵的 2D 操作之一，
   十段三层每帧重画就是三百次带模糊的描边，帧率会当场塌下来。
   打雷的时候画一次，之后每帧只 drawImage 一张图。 */
let boltLayer = null;
function bakeBolt(){
  if (!boltPts || boltPts.length < 2) return;
  if (!boltLayer){
    boltLayer = document.createElement('canvas');
    boltLayer.width = W; boltLayer.height = H;
  }
  const c = boltLayer.getContext('2d');
  c.clearRect(0, 0, W, H);
  c.save();
  c.lineCap = 'round';
  c.globalCompositeOperation = 'lighter';
  const passes = [
    { w: 3.0, col: 'rgba(120,180,255,0.30)', blur: 34 },
    { w: 1.7, col: 'rgba(180,220,255,0.55)', blur: 16 },
    { w: 0.9, col: 'rgba(255,255,255,0.95)', blur: 6 }
  ];
  for (const ps of passes){
    c.shadowColor = 'rgba(150,200,255,0.85)';
    c.shadowBlur = ps.blur;
    c.strokeStyle = ps.col;
    for (let i = 1; i < boltPts.length; i++){
      const w = (boltW ? boltW[i] : 2) * ps.w;
      c.beginPath();
      c.moveTo(boltPts[i-1].x, boltPts[i-1].y);
      c.lineTo(boltPts[i].x, boltPts[i].y);
      c.lineWidth = Math.max(0.6, w);
      c.stroke();
    }
  }
  c.restore();
}

function drawBolt(k){
  if (!boltPts || boltPts.length < 2) return;
  if (!boltLayer) bakeBolt();
  if (!boltLayer) return;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = Math.min(1, k);
  ctx.drawImage(boltLayer, 0, 0);
  ctx.restore();
}

/* 热成像被雷暴干扰：整屏雪花、横向撕裂 */
/* 噪点块也是预生成的：每帧一百多次 fillRect 一样很贵。
   做一张贴图，每帧按随机偏移平铺，看起来是一样的雪花，代价是十几次 drawImage。 */
let glitchTile = null;
function makeGlitchTile(){
  const tw = 420, th = 260;
  const c = document.createElement('canvas');
  c.width = tw; c.height = th;
  const g2 = c.getContext('2d');
  for (let i = 0; i < 70; i++){
    const w = 12 + Math.random() * 150, h = 2 + Math.random() * 14;
    const r = Math.random();
    g2.fillStyle = r < 0.40 ? 'rgba(170,255,225,0.30)'
                 : r < 0.72 ? 'rgba(120,200,255,0.24)'
                            : 'rgba(0,0,0,0.34)';
    g2.fillRect(Math.random() * tw, Math.random() * th, w, h);
  }
  glitchTile = c;
}

function drawHeatGlitch(){
  const k = Math.min(1, heatGlitch / 0.95);
  if (!glitchTile) makeGlitchTile();
  ctx.save();
  /* 整屏发绿：热成像被电磁干扰时那种荧光绿噪点 */
  ctx.fillStyle = 'rgba(40,120,90,' + (0.12 + 0.10 * k).toFixed(3) + ')';
  ctx.fillRect(0, 0, W, H);
  const tw = glitchTile.width, th = glitchTile.height;
  const ox = -Math.floor(Math.random() * tw), oy = -Math.floor(Math.random() * th);
  ctx.globalAlpha = 0.60 + 0.35 * k;
  for (let y = oy; y < H; y += th)
    for (let x = ox; x < W; x += tw) ctx.drawImage(glitchTile, x, y);
  ctx.globalAlpha = 1;
  /* 横向撕裂：亮条 + 错位的暗条 */
  for (let i = 0; i < 9; i++){
    const y = Math.random() * H;
    const th2 = 1 + Math.random() * 5;
    ctx.fillStyle = 'rgba(170,240,255,' + (0.10 + 0.22 * k).toFixed(3) + ')';
    ctx.fillRect(0, y, W, th2);
    ctx.fillStyle = 'rgba(0,0,0,' + (0.10 + 0.14 * k).toFixed(3) + ')';
    ctx.fillRect(0, y + th2 + 1, W, 2 + Math.random() * 4);
  }
  ctx.restore();
}

/* m35424：?nanwatch=1 时给 player.x / player.y 装探针，第一次写进非有限值就把调用栈打出来。
   平时不装（零开销）；排查"坐标什么时候变成 NaN"时用。 */
function installNanWatch(){
  try {
    if (typeof player === 'undefined' || !player || player.__nanWatch) return false;
    player.__nanWatch = true;
    ['x','y'].forEach(function(k){
      let v = player[k];
      Object.defineProperty(player, k, {
        configurable: true,
        get(){ return v; },
        set(nv){
          if (!isFinite(nv) && !player.__nanHit){
            player.__nanHit = true;
            const st = (new Error('player.' + k + ' = ' + nv)).stack || '';
            console.error('[NANWATCH] player.' + k + ' 变成非有限值\n' + st);
            try { if (typeof reportErr === 'function') reportErr('16-frag', new Error('player.' + k + ' 非有限')); } catch(e){}
            try { if (typeof logError === 'function') logError('perf', '玩家坐标非有限（' + k + '）· 栈见控制台'); } catch(e){}
          }
          v = nv;
        }
      });
    });
    return true;
  } catch (e){ return false; }
}
try {
  window.__NANWATCH_WANT = (typeof location !== 'undefined' && /[?&]nanwatch=1/.test(String(location.search)));
} catch (e){}
try { window.installNanWatch = installNanWatch; } catch (e){}   /* 控制台里也能手动开 */

function drawNightRain(L){
  /* m35424：玩家/相机坐标一旦变成 NaN（测试页、传送、坏存档都可能），
     createRadialGradient 会抛 "non-finite"，整帧渲染中断 → 玩家看到黑屏。
     这里先拦一层：这一帧不画夜景，但其它东西照画，并留一条诊断。 */
  if (!player || !isFinite(player.x) || !isFinite(player.y) ||
      !cam || !isFinite(cam.x) || !isFinite(cam.y)){
    if (!drawNightRain._warned){
      drawNightRain._warned = true;
      try { if (typeof reportErr === 'function') reportErr('16-frag', new Error('drawNightRain 跳过：坐标非有限 player=(' + (player && player.x) + ',' + (player && player.y) + ') cam=(' + (cam && cam.x) + ',' + (cam && cam.y) + ')')); } catch (e){}
      if (typeof logWarn === 'function') logWarn('perf', '夜景跳过：玩家坐标非有限');
    }
    return;
  }
  drawNightRain._warned = false;
  /* m22044：大雾雷暴借用 3-4 的黑色遮罩，不再单独画雾 */
  const _fogF = (typeof WXC !== 'undefined' ? Math.min(1, Math.max(0, WXC.fog || 0)) : 0);
  const _nr0  = (L.rules && L.rules.nightR) || 0;
  const _fogR = Math.min(W, H) * 0.11;           /* m22372：用户说圈还是大，再收一档（112 → 88） */
  const r = _nr0 > 0 ? _nr0 : (_fogF > 0.02 ? _fogR : 0);
  const _thermalNow = !!(player && player.thermalOn && player.thermal);
  const sx = player.x - cam.x, sy = player.y - cam.y;

  /* 1. 黑暗：只留脚边一圈 */
  if (r > 0 && !_thermalNow){
    /* nightA：黑得多死。老关不写就是 0.988（几乎全黑），
       6000×6000 这种大图得留一点轮廓，不然连往哪走都看不见 */
    const _baseA = (L.rules && L.rules.nightA !== undefined) ? L.rules.nightA : 0.988;
    const a = Math.min(0.988, Math.max(_baseA * (_nr0 > 0 ? 1 : 0), 0.985 * _fogF)) * (1 - Math.min(0.97, flashK));
    const qx = Math.round(sx / 8) * 8, qy = Math.round(sy / 8) * 8;
    const qa = Math.round(a * 100) / 100;
    const allyPose=allies.filter(e=>!e.dead&&e.hp>0).map(e=>e.x+','+e.y+','+e.ang).join(';');
    /* m22275：朝向/视距/视角也必须进缓存 key —— 否则转身后挖开的锥还留在旧方向 */
    const _aimKey = Math.round(((typeof player.aim === 'number' ? player.aim : 0) + 6.2832) * 57) % 360;
    const key = qx + '|' + qy + '|' + qa + '|' + Math.round(_fogF * 100) + '|' + _aimKey + '|' + Math.round(r) + '|' + (typeof seeFov === 'function' ? Math.round(seeFov(L)) : 0) + (allies.length?'|'+Math.floor(uiT*10)+'|'+cam.x+'|'+cam.y+'|'+allyPose:'');
    /* 整块黑 + 中间挖一个柔边洞，先画在一张离屏图上再整张贴上来。
       以前是"渐变圆 + 整屏补黑"两笔分开画，圆的边缘必然留一条半像素的亮缝，
       就是你看到的那圈"圆框"。一笔画完就没有缝了。 */
    if (!darkCanvas && typeof document !== 'undefined' && document.createElement){
      try {
        const dc = document.createElement('canvas');
        dc.width = W; dc.height = H;
        if (dc.getContext) darkCanvas = dc;
      } catch(e){ darkCanvas = null; }
    }
    if (!darkCanvas){                     /* 兜底：没离屏画布就直接铺一层黑 */
      ctx.fillStyle = 'rgba(3,5,9,' + qa.toFixed(3) + ')';
      ctx.fillRect(0, 0, W, H);
    } else {
      if (darkKey !== key){
        darkKey = key;
        const g2 = darkCanvas.getContext('2d');
        g2.setTransform(1, 0, 0, 1, 0, 0);
        g2.globalCompositeOperation = 'source-over';
        g2.clearRect(0, 0, W, H);
        g2.fillStyle = 'rgba(3,5,9,' + qa.toFixed(3) + ')';
        g2.fillRect(0, 0, W, H);
        g2.globalCompositeOperation = 'destination-out';
        const rg = g2.createRadialGradient(qx, qy, r * 0.30, qx, qy, r);
        rg.addColorStop(0, 'rgba(0,0,0,1)');
        rg.addColorStop(0.55, 'rgba(0,0,0,0.58)');
        rg.addColorStop(1, 'rgba(0,0,0,0)');
        g2.fillStyle = rg;
        g2.beginPath(); g2.arc(qx, qy, r, 0, TAU); g2.fill();
        /* m22044：视野锥完全擦掉，长度是雾圈的 2.6 倍 —— 锥内看清前方，锥外照旧黑 */
        if (_fogF > 0.02){
          /* m22149：锥长取引擎真实视距（比雾圈略远），角度取 seeFov —— 和玩家真正的视野锥完全重合 */
          const _coneR = Math.max(r * 1.10, (typeof seeRange === 'function' ? seeRange(L) : r * 1.3));
          g2.filter = 'blur(10px)';
          const _half = ((typeof seeFov === 'function' ? seeFov(L) : 95) * Math.PI / 360);
          const _aim = (typeof player.aim === 'number') ? player.aim : 0;
          const cg = g2.createRadialGradient(qx, qy, r * 0.55, qx, qy, _coneR);
          cg.addColorStop(0, 'rgba(0,0,0,1)');
          cg.addColorStop(0.82, 'rgba(0,0,0,0.94)');
          cg.addColorStop(1, 'rgba(0,0,0,0)');
          g2.fillStyle = cg;
          g2.beginPath();
          g2.moveTo(qx, qy);
          g2.arc(qx, qy, _coneR, _aim - _half, _aim + _half);
          g2.closePath();
          g2.fill();
          g2.filter = 'none';
        }
        companionNightVision(g2);
        g2.globalCompositeOperation = 'source-over';
      }
      /* m22372 B：光晕 —— 玩家那点光在雾里散开一圈。
         全屏 bloom 会把亮地面一起提起来，画面反而更糊，所以改成"以玩家为中心的一团光"。 */
      if (_fogF > 0.02 && player && perfLv() < 2){
        const _gx = (typeof cam !== 'undefined') ? player.x - cam.x : W / 2;
        const _gy = (typeof cam !== 'undefined') ? player.y - cam.y : H / 2;
        const _glowR = Math.max(120, r * 2.2);
        const _glA = (0.10 + 0.10 * _fogF) * (1 - Math.min(1, flashK * 1.2));
        const _gsp = perfGlowBuild();
        if (_gsp){
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = _glA * 0.62;
          ctx.drawImage(_gsp, _gx - _glowR, _gy - _glowR, _glowR * 2, _glowR * 2);
          ctx.restore();
        }
      }
      ctx.drawImage(darkCanvas, 0, 0);
    }
    /* m22299 A：雾团 —— 几团柔光在漂，远处有厚薄，不再是一块死板的黑（用贴图会有拼接缝，所以用渐变团） */
    if (_fogF > 0.02 && perfLv() < 2){
      const _clearN = 1 - Math.min(1, flashK * 2.0);
      const _gsp = perfGlowBuild();
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (let _i = 0; _i < 5; _i++){
        const _tt = uiT * (12 + _i * 4);
        const _bx = ((_tt + _i * 331) % (W + 480)) - 240;
        const _by = H * 0.5 + Math.sin(uiT * 0.32 + _i * 1.7) * H * 0.34;
        const _rr = Math.min(W, H) * (0.30 + 0.10 * ((_i * 7) % 3));
        if (_gsp){
          ctx.globalAlpha = 0.085 * _fogF * _clearN;
          ctx.drawImage(_gsp, _bx - _rr, _by - _rr, _rr * 2, _rr * 2);
        } else {
          const _ga = ctx.createRadialGradient(_bx, _by, 0, _bx, _by, _rr);
          _ga.addColorStop(0, 'rgba(152,172,198,' + (0.085 * _fogF * _clearN).toFixed(3) + ')');
          _ga.addColorStop(1, 'rgba(140,160,186,0)');
          ctx.fillStyle = _ga;
          ctx.beginPath(); ctx.arc(_bx, _by, _rr, 0, 6.2832); ctx.fill();
        }
      }
      ctx.restore();
    }
  }

  /* 2. 斜着下的雨：靠闪电一起变亮，平时只是一层很淡的白 */
  if (weatherHasRain()){
    if (!rainDrops.length) rainInitDrops();
    /* 雨量决定"看得到的雨有多大"（m20292：小雨和雨以前长得一样，现在按 WXC.rain 缩放数量/亮度/长度）：
       小雨 ≈ 40% 的雨丝、狂风暴雨 ≈ 满屏 240 根。 */
    const _rk = Math.min(1, Math.max(0.10, wVizRain / WMAX.rain));   /* m21975：视觉慢通道 */
    let _want = Math.max(18, Math.round(240 * _rk));
    if (perfLv() >= 1) _want = Math.min(_want, 150);
    if (perfLv() >= 2) _want = Math.min(_want, 80);
    while (rainDrops.length < _want){
      rainDrops.push({ x: Math.random() * (W + 320), y: Math.random() * H,
        len: 16 + Math.random() * 26, spd: 820 + Math.random() * 620, a: 0.07 + Math.random() * 0.13 });
    }
    if (rainDrops.length > _want) rainDrops.length = _want;
    const dt = Math.min(0.05, (typeof lastDt === 'number' && lastDt > 0) ? lastDt : 0.016);
    const bright = (0.55 + 0.45 * Math.min(1, flashK)) * (0.62 + 0.38 * _rk);
    ctx.save();
    ctx.strokeStyle = 'rgba(188,214,240,1)';
    ctx.lineWidth = 1;
    /* 按透明度分三档，一档一次 stroke：240 次 stroke 换成 3 次 */
    const _b0 = [], _b1 = [], _b2 = [];
    const _rsl = (typeof rainSlopeK === 'function') ? rainSlopeK() : 0.32;
    for (const d of rainDrops){
      d.y += d.spd * dt;
      /* m20844：世界里的雨以前固定往左斜 0.32，跟风的方向对不上。
         现在统一读 rainSlopeK()，和镜头前的雨丝同一个斜率。 */
      d.x += d.spd * _rsl * dt;
      if (d.y > H + 40){ d.y = -40 - Math.random() * 140; d.x = Math.random() * (W + 320); }
      if (d.x < -180) d.x += W + 360; else if (d.x > W + 180) d.x -= W + 360;
      (d.a < 0.11 ? _b0 : (d.a < 0.15 ? _b1 : _b2)).push(d);
    }
    const _buckets = [_b0, _b1, _b2];
    /* m21298：先铺一层"虚影"（粗、淡、宽），再叠实线。
       单画实线像 UI 画上去的细线；有了虚影才像在快速移动的水。 */
    const _lenS = 0.55 + 0.45 * _rk;      /* m21298：虚影自己算长度，_lenK 在下面的分档循环里才声明 */
    if (perfLv() < 1){
      ctx.globalAlpha = 0.10 * bright;
      ctx.lineWidth = 3.2;
      ctx.beginPath();
      for (const d of rainDrops){
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - _rsl * d.len * _lenS, d.y - d.len * _lenS);
      }
      ctx.stroke();
    }
    ctx.lineWidth = 1;
    for (let bi = 0; bi < 3; bi++){
      const list = _buckets[bi];
      if (!list.length) continue;
      ctx.globalAlpha = (0.085 + bi * 0.048) * bright;
      ctx.beginPath();
      /* 小雨的雨丝更短更细，大雨拉成长条（m20292） */
      const _lenK = 0.55 + 0.45 * _rk;
      for (const d of list){
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - _rsl * d.len * _lenK, d.y - d.len * _lenK);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  /* 3.5 m21147：雨越大，画面越沉。以前只有水膜那层亮蓝，于是"越下雨越亮"，
     看起来像雨把雾吹散了。这里按雨量补一层冷暗，让"大雨 = 视线更差"读起来对。 */
  if (weatherHasRain()){
    const _gloom = Math.min(1, Math.max(0, (wVizRain - 0.30) / 1.05));
    if (_gloom > 0.01){
      ctx.fillStyle = 'rgba(5,9,16,' + (0.30 * _gloom).toFixed(3) + ')';
      ctx.fillRect(0, 0, W, H);
    }
  }

  /* 3.6 m21449：全局雨雾圈 —— 近处清晰、远处发白，打雷时被压淡（等于"雷光照亮周围"）。
     3-4 有自己的 nightR 机制（黑圈 + 挖洞），这里跳过它，免得叠两层。 */
  {
    const _hasNight = !!(L.rules && L.rules.nightR > 0);
    const _fr = Math.min(1, Math.max(0, (wVizRain - FOG_RAIN.lo) / FOG_RAIN.span));
    if (!_hasNight && _fr > 0.01 && player){
      const _R = Math.min(W, H) * (0.40 + 0.16 * _fr);
      /* 雷闪时雾被吹散一瞬：flashK 越大越透 */
      const _fa = (0.52 * _fr) * Math.max(0, 1 - flashK * 2.2);   /* m22103：从 0 长上来，不再一开就 0.20 */   /* 雷一闪雾就散开，闪电结束再慢慢回来 */
      if (_fa > 0.004){
        const _fg = ctx.createRadialGradient(sx, sy, _R * 0.30, sx, sy, _R);
        _fg.addColorStop(0, 'rgba(154,174,200,0)');
        _fg.addColorStop(0.50, 'rgba(150,170,196,' + (_fa * 0.30).toFixed(3) + ')');
        _fg.addColorStop(0.86, 'rgba(146,166,194,' + (_fa * 0.82).toFixed(3) + ')');
        _fg.addColorStop(1, 'rgba(140,162,192,' + _fa.toFixed(3) + ')');
        ctx.fillStyle = _fg;
        ctx.fillRect(0, 0, W, H);
      }
    }
  }

  /* 3.7 m21653：大雾雷暴 —— 整屏起雾，只有视野锥正前方勉强看清；打雷一下整屏被照亮 */
  /* m22044：大雾已并入上面的 3-4 黑色遮罩，不再单独画雾层 */

  /* 4. 闪电：整屏先亮起来，再画那根会发光的电弧 */
  if (flashK > 0.004){
    const k = Math.min(1, flashK);
    ctx.save();
    ctx.fillStyle = 'rgba(226,240,255,' + (0.34 * k).toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
    drawBolt(k);
    ctx.restore();
  }

  /* 4. 热成像被雷暴干扰（只在戴着它碰上打雷时出现） */
  

  /* 5. 没有地图的关卡：给一个指向最近物资的箭头，捡完了就指撤离点 */
  if (L.rules && L.rules.noMap && !L.rules.noArrow && state === 'play') drawGuideArrow(L);
  drawXrayMarks();
  /* m20681：最后叠一层"糊在脸上"的雨 —— 前景大颗雨丝 + 镜头水珠 + 水汽渐晕 */
  if (perfLv() < 2) drawRainLens(); else drawCheapVeil();   /* m23584：低画质也保留遮挡 */
}

/* ================= 贴脸雨（屏幕空间） =================
   画面里的雨丝在"世界里"，离得远，所以再大也只是背景变糊。
   真正让人觉得"雨打在脸上"的是三件事：
   ① 前景掠过的大颗雨丝（又快又长，明显在镜头前面）
   ② 镜头上的水珠：一小片水渍，慢慢往下淌
   ③ 边角的水汽渐晕（视野被雨水压窄）
   三者的密度/速度/大小都跟雨量走。 */
let lensDrops = [];
let lensAcc = 0, lensLastMs = 0;

/* m20844 新实现的 drawRainLens（贴脸雨重写） */
let fgRain = [], fgRainN = -1;
let lensVeil = null, lensVeilKey = '', lensVig = null, lensVigKey = '';

/* 雨的斜率：镜头前的雨和世界里的雨共用，保证两个方向一致 */
function rainSlopeK(){
  if (WXC.angle === null) return 0;
  /* 水平位移 / 垂直位移。保留来向，倾斜幅度随混合后的风力变化。 */
  return Math.cos(WXC.angle) * (0.32 + 0.55 * clamp(WXC.windK, 0, 1.3));
}

/* 湿玻璃水膜：整张预渲染一次，之后每帧只贴一次图（比每帧画 3 个全屏渐变便宜得多） */
function lensVeilBuild(){
  if (typeof document === 'undefined' || !document.createElement) return null;
  const c = document.createElement('canvas');
  c.width = Math.max(2, W); c.height = Math.max(2, H);
  const g = c.getContext && c.getContext('2d');
  if (!g) return null;
  /* 一片片的"水膜"：中心微亮、靠近边缘先暗一圈再化开 —— 暗边是折射的感觉，
     均匀的灰蒙蒙反而像雾（用户 m21045）。 */
  for (let i = 0; i < 7; i++){
    const cx = W * (0.10 + 0.16 * i % 0.82) + Math.sin(i * 2.1) * W * 0.06;
    const cy = H * (0.14 + 0.21 * ((i * 3) % 4)) + Math.cos(i * 1.7) * H * 0.05;
    const rad = Math.min(W, H) * (0.22 + 0.09 * ((i * 5) % 3));
    const rg = g.createRadialGradient(cx, cy, rad * 0.05, cx, cy, rad);
    rg.addColorStop(0, 'rgba(150,172,198,0.13)');
    rg.addColorStop(0.55, 'rgba(96,116,142,0.13)');
    rg.addColorStop(0.80, 'rgba(40,52,68,0.15)');
    rg.addColorStop(1, 'rgba(120,146,178,0)');
    g.fillStyle = rg;
    g.fillRect(0, 0, W, H);
  }
  return c;
}

/* m21827 大雾雷暴（重做）：
   目标是"跟 3-4 一个观感"——雾要**真的挡住东西**，不是往画面上贴一层浅色。
   做法：离屏画一张雾图（暗色、越远越厚），再用 destination-out 把视野锥**羽化地**擦出来，
   最后整张贴上去。全程用渐变过渡，没有硬切边。打雷那一下整体淡出 = 雷光照亮地形。 */
let fogCan = null, fogCtx = null;
function drawFogWeather(){
  const f = WXC.fog;
  if (!(f > 0.01) || !player || state !== 'play') return;
  const L = cur();
  const clearK = Math.max(0, 1 - Math.min(1, flashK * 2.2));
  if (clearK <= 0.01) return;
  const px = player.x - cam.x, py = player.y - cam.y;
  const R = Math.max(150, (typeof seeRange === 'function' ? seeRange(L) : 420)) * 0.78;   /* m21975：圈小一点 */
  if (typeof document === 'undefined' || !document.createElement) return;
  if (!fogCan || fogCan.width !== W || fogCan.height !== H){
    fogCan = document.createElement('canvas');
    fogCan.width = Math.max(2, W); fogCan.height = Math.max(2, H);
    fogCtx = fogCan.getContext('2d');
  }
  if (!fogCtx) return;
  const c = fogCtx;
  c.setTransform(1, 0, 0, 1, 0, 0);
  c.globalCompositeOperation = 'source-over';
  c.globalAlpha = 1;
  c.clearRect(0, 0, W, H);
  /* 和 3-4 一样的做法：整屏铺一层近乎全黑，再把"脚边那一圈"擦出来。
     以前是往画面上叠灰渐变，所以既不挡东西、也不像雾（用户 m21897 对比图）。 */
  const bodyA = Math.min(0.985, 0.97 * f) * clearK;
  c.fillStyle = 'rgba(10,15,22,' + bodyA.toFixed(3) + ')';   /* 比纯黑亮一点：亮地图上读作浓雾，而不是天黑了 */
  c.fillRect(0, 0, W, H);
  c.globalCompositeOperation = 'destination-out';
  {
    const hole = c.createRadialGradient(px, py, R * 0.26, px, py, R);
    hole.addColorStop(0, 'rgba(0,0,0,1)');
    hole.addColorStop(0.55, 'rgba(0,0,0,0.55)');
    hole.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = hole;
    c.beginPath(); c.arc(px, py, R, 0, 6.2832); c.fill();
  }
  /* 视野锥：三层不同宽度的锥叠加擦除 → 越靠中间擦得越干净，锥边自然羽化 */
  const half = ((typeof seeFov === 'function' ? seeFov(L) : 58) * Math.PI / 360);
  const aim = (typeof player.aim === 'number') ? player.aim : 0;
  for (let i = 0; i < 3; i++){
    const hw = half * (1 + i * 0.18);
    const kk = 0.60 - i * 0.16;          /* m21975：以前 0.34 太弱看不出区别，现在锥内明显更清 */
    const gg = c.createRadialGradient(px, py, R * 0.12, px, py, R * 1.02);
    gg.addColorStop(0,   'rgba(0,0,0,' + kk.toFixed(3) + ')');
    gg.addColorStop(0.62,'rgba(0,0,0,' + (kk * 0.82).toFixed(3) + ')');
    gg.addColorStop(0.90,'rgba(0,0,0,' + (kk * 0.38).toFixed(3) + ')');
    gg.addColorStop(1,   'rgba(0,0,0,0)');
    c.fillStyle = gg;
    c.beginPath();
    c.moveTo(px, py);
    c.arc(px, py, R * 1.04, aim - hw, aim + hw);
    c.closePath();
    c.fill();
  }
  c.globalCompositeOperation = 'source-over';
  /* 洞里留一层薄雾：纯黑挖个洞会显得"干净"，加一点才有雾的味道（m21975） */
  if (f > 0.02){
    const hz = c.createRadialGradient(px, py, R * 0.10, px, py, R * 2.2);
    hz.addColorStop(0, 'rgba(120,138,160,' + (0.10 * f).toFixed(3) + ')');
    hz.addColorStop(0.55, 'rgba(112,130,152,' + (0.05 * f).toFixed(3) + ')');
    hz.addColorStop(1, 'rgba(110,128,150,0)');
    c.fillStyle = hz;
    c.fillRect(0, 0, W, H);
  }
  ctx.save();
  ctx.globalAlpha = 1.00 * clearK;
  ctx.drawImage(fogCan, 0, 0);
  ctx.restore();
}

/* m23584：低画质也得"糊"。
   之前 perfLv>=2 直接把 drawRainLens() 整个跳过，结果低画质比高画质**看得更清楚**——
   在"看不清"本身就是机制的死亡地带里，这就是实打实的信息优势，不能拿画质换。
   做法：把水膜 + 雾团烘成一张静态图，一次 drawImage 贴上；成本约 1 屏写入，
   比原版（约 3 屏 + 5 次 drawImage）便宜得多，遮挡强度基本一致。 */
let cheapVeil = null, cheapVeilKey = '';
function cheapVeilBuild(){
  if (typeof document === 'undefined' || !document.createElement) return null;
  const c = document.createElement('canvas');
  c.width = Math.max(2, W); c.height = Math.max(2, H);
  const g = c.getContext && c.getContext('2d');
  if (!g) return null;
  for (let i = 0; i < 7; i++){
    const cx = W * (0.10 + 0.16 * i % 0.82) + Math.sin(i * 2.1) * W * 0.06;
    const cy = H * (0.14 + 0.21 * ((i * 3) % 4)) + Math.cos(i * 1.7) * H * 0.05;
    const rad = Math.min(W, H) * (0.22 + 0.09 * ((i * 5) % 3));
    const rg = g.createRadialGradient(cx, cy, rad * 0.05, cx, cy, rad);
    rg.addColorStop(0, 'rgba(150,172,198,0.13)');
    rg.addColorStop(0.55, 'rgba(96,116,142,0.13)');
    rg.addColorStop(0.80, 'rgba(40,52,68,0.15)');
    rg.addColorStop(1, 'rgba(120,146,178,0)');
    g.fillStyle = rg;
    g.fillRect(0, 0, W, H);
  }
  for (let i = 0; i < 3; i++){
    const bx = W * (0.20 + 0.30 * i);
    const by = H * (0.30 + 0.22 * ((i * 2) % 2));
    const rr = Math.min(W, H) * (0.34 + 0.08 * i);
    const rg = g.createRadialGradient(bx, by, 0, bx, by, rr);
    rg.addColorStop(0, 'rgba(176,198,222,0.10)');
    rg.addColorStop(1, 'rgba(176,198,222,0)');
    g.fillStyle = rg;
    g.beginPath(); g.arc(bx, by, rr, 0, 6.2832); g.fill();
  }
  return c;
}
function drawCheapVeil(){
  const r = Math.min(1.2, Math.max(0, (typeof wVizRain === 'number' ? wVizRain : 0) / WMAX.rain));
  if (r < 0.02) return;
  if (!cheapVeil || cheapVeilKey !== (W + 'x' + H)){
    cheapVeil = cheapVeilBuild();
    cheapVeilKey = W + 'x' + H;
  }
  if (!cheapVeil) return;
  const vA = Math.max(0, Math.min(1, (r - 0.40) * 1.70));
  const mB = Math.min(1, Math.max(0, (r - 0.28) / 0.95));
  const a = Math.max(vA * 0.72, mB * 0.55);
  if (a < 0.01) return;
  ctx.save();
  ctx.globalAlpha = a;
  ctx.drawImage(cheapVeil, 0, 0);
  ctx.restore();
}

function drawRainLens(){
  const r = Math.min(1.2, Math.max(0, (typeof wVizRain === 'number' ? wVizRain : 0) / WMAX.rain));
  /* m21827：不下雨（比如大雾雷暴）就一根都不画；顺手把残留粒子清掉 */
  if (r < 0.02){ if (fgRain.length) fgRain.length = 0; if (lensDrops.length) lensDrops.length = 0; return; }
  if (r <= 0.03){ if (fgRain.length){ fgRain.length = 0; fgRainN = -1; } if (lensDrops.length) lensDrops.length = 0; return; }
  const nowMs = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  const dt = Math.min(0.12, Math.max(0, (nowMs - (lensLastMs || nowMs)) / 1000));
  lensLastMs = nowMs;
  const tt = nowMs / 1000;

  ctx.save();

  /* ① 镜头前的雨丝：每根自己的斜率/速度/长度/亮度，随机播撒、随机重生 ——
     不再用「按序号取模」的固定位置和固定角度（那正是看着有规律的原因）。 */
  const want = Math.round(34 * r);          /* m21827：没雨就是 0 根，别再在雾里画"蝌蚪" */
  const slide = rainSlopeK();
  while (fgRain.length < want){
    fgRain.push({
      x: Math.random() * (W + 260) - 130,
      y: Math.random() * (H + 260) - 130,
      len: 30 + Math.random() * 46,
      spd: 820 + Math.random() * 780,
      w: 1.0 + Math.random() * 1.2,
      a: 0.07 + Math.random() * 0.15,
      jit: (Math.random() - 0.5) * 0.22
    });
  }
  if (fgRain.length > want) fgRain.length = want;
  fgRainN = want;
  const span = H + 300;
  ctx.lineCap = 'round';
  const buckets = [[], [], []];
  for (const p of fgRain){
    const sl = slide + p.jit;
    p.y += p.spd * dt;
    p.x += p.spd * sl * dt;
    if (p.y > H + 150){ p.y = -150 - Math.random() * 200; p.x = Math.random() * (W + 260) - 130; p.len = 30 + Math.random() * 46; p.a = 0.07 + Math.random() * 0.15; p.jit = (Math.random() - 0.5) * 0.22; }
    if (p.x < -180) p.x += W + 360; else if (p.x > W + 180) p.x -= W + 360;
    const bi = p.a < 0.11 ? 0 : (p.a < 0.16 ? 1 : 2);
    buckets[bi].push(p);
  }
  const lenK = 0.60 + 0.55 * r;
  for (let bi = 0; bi < 3; bi++){
    const list = buckets[bi];
    if (!list.length) continue;
    ctx.strokeStyle = 'rgba(206,228,250,1)';
    ctx.globalAlpha = (0.20 + bi * 0.17) * (0.55 + 0.45 * r);
    ctx.lineWidth = 1.0 + bi * 0.55;
    ctx.beginPath();
    for (const p of list){
      const sl = slide + p.jit;
      const L = p.len * lenK;
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - sl * L, p.y - L);
    }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;

  /* ② 湿玻璃：一张预渲染的水膜，慢慢漂一下 + 按雨量调透明度 */
  if (!lensVeil || lensVeilKey !== (W + 'x' + H)){
    lensVeil = lensVeilBuild();
    lensVeilKey = W + 'x' + H;
  }
  if (lensVeil){
    /* 0.40 以下是"只是下雨"，不该糊；往上按雨量线性拉满，差别一眼能看出来 */
    const vA = Math.max(0, Math.min(1, (r - 0.40) * 1.70));
    if (vA > 0.01){
      ctx.globalAlpha = vA * 0.72;
      ctx.drawImage(lensVeil, Math.sin(tt * 0.035) * 46, Math.cos(tt * 0.027) * 34);
      ctx.globalAlpha = 1;
    }
  }

  /* ②.5 m21298：发白的软雾。压在雨丝下面、水痕上面，形成"远雾 / 近雨"的前后关系。
     每一团都很大很软、边缘完全没有形状，所以像素级看不出边界，只感觉到"糊了一层"。 */
  {
    const mBase = Math.min(1, Math.max(0, (r - 0.28) / 0.95));
    if (mBase > 0.01){
      const tt2 = (typeof uiT === 'number' ? uiT : 0);
      for (let i = 0; i < 6; i++){
        const ph = i * 1.7;
        const cx = ((W * (0.15 + 0.14 * i) + tt2 * (14 + i * 5)) % (W + 520)) - 260;
        const cy = H * (0.30 + 0.14 * ((i * 3) % 4)) + Math.sin(tt2 * 0.22 + ph) * H * 0.06;
        const rad = Math.min(W, H) * (0.34 + 0.10 * ((i * 5) % 3));
        const a2 = mBase * (0.105 + 0.065 * (0.5 + 0.5 * Math.sin(tt2 * 0.35 + ph)));
        if (a2 < 0.004) continue;
        const mg = ctx.createRadialGradient(cx, cy, rad * 0.10, cx, cy, rad);
        mg.addColorStop(0, 'rgba(176,198,222,' + a2.toFixed(3) + ')');
        mg.addColorStop(0.55, 'rgba(160,184,210,' + (a2 * 0.62).toFixed(3) + ')');
        mg.addColorStop(1, 'rgba(140,166,196,0)');
        ctx.fillStyle = mg;
        ctx.fillRect(cx - rad, cy - rad, rad * 2, rad * 2);
      }
    }
  }

  /* ②.6 整屏薄雾：雨越大越"隔一层"，但压得很轻，避免回到"越下雨越亮"
     —— 这里只在已有 gloom 的基础上把暗部提一点，让对比度掉下来。 */
  {
    const mW = Math.min(1, Math.max(0, (r - 0.32) / 0.95));
    if (mW > 0.01){
      ctx.fillStyle = 'rgba(150,174,204,' + (0.035 + 0.075 * mW).toFixed(3) + ')';
      ctx.fillRect(0, 0, W, H);
    }
  }

  /* ③ 细水痕：往下淌的淡痕（不是圆点） */
  lensAcc += dt * (0.9 + 4.6 * r);
  const cap = 3 + Math.round(11 * r);      /* m21653：雨越大，玻璃上的水痕越多 */
  while (lensAcc >= 1){
    lensAcc -= 1;
    if (lensDrops.length < cap){
      lensDrops.push({
        x: Math.random() * W,
        y: Math.random() * H * 0.9,
        r: (14 + Math.random() * 30) * (0.7 + 0.6 * r),
        v: 12 + Math.random() * 30,
        age: 0,
        ttl: 1.6 + Math.random() * 2.4,
        wake: Math.random() < 0.42,      /* 只有一部分珠子在滑，其余是"贴"在玻璃上的 */
        wob: Math.random() * 6.283
      });
    }
  }
  for (let i = lensDrops.length - 1; i >= 0; i--){
    const d = lensDrops[i];
    d.age += dt;
    d.y += d.v * dt;
    if (d.age >= d.ttl || d.y > H + 40){ lensDrops.splice(i, 1); continue; }
    const life = d.age / d.ttl;
    const a = Math.min(1, life * 5) * (1 - Math.max(0, (life - 0.8) / 0.2)) * (0.06 + 0.10 * r);
    if (a <= 0.004) continue;
    /* m21215：圆水珠读起来像气泡，整套去掉。
       只留"往下淌的水痕"：一条很细、两头渐隐、稍微弯一点的水线。 */
    const dR = Math.max(1.8, d.r * 0.14);
    const dRx = dR, dRy = dR * 1.16;
    /* 水痕：贴着水珠往上收成锥形，长度只有 1.4~2.2 个珠径，且根部和水珠同宽 ——
       细长的一根线 + 一个圆，读起来像棒棒糖（用户 m21083）。 */
    if (d.wake){
      const wl = dRy * (1.1 + Math.random() * 0.6);
      const wob2 = Math.sin(d.wob) * dRx * 0.30;
      const wg = ctx.createLinearGradient(d.x, d.y - dRy - wl, d.x, d.y - dRy * 0.20);
      wg.addColorStop(0, 'rgba(190,214,242,0)');
      wg.addColorStop(1, 'rgba(196,218,244,' + (a * 0.42).toFixed(3) + ')');
      ctx.beginPath();
      ctx.moveTo(d.x - dRx * 0.52, d.y - dRy * 0.25);
      ctx.quadraticCurveTo(d.x - dRx * 0.30 + wob2, d.y - dRy - wl * 0.55, d.x + wob2, d.y - dRy - wl);
      ctx.quadraticCurveTo(d.x + dRx * 0.30 + wob2, d.y - dRy - wl * 0.55, d.x + dRx * 0.52, d.y - dRy * 0.25);
      ctx.closePath();
      ctx.fillStyle = wg;
      ctx.fill();
    }
    /* 水痕：一条细线，上端渐隐、下端最实，像水顺着玻璃往下爬 */
    const tl = 26 + d.r * 1.6;
    const w2 = Math.sin(d.wob + d.age * 2.2) * Math.min(6, d.r * 0.22);
    const sg = ctx.createLinearGradient(d.x, d.y - tl, d.x + w2, d.y + 6);
    sg.addColorStop(0, 'rgba(196,216,240,0)');
    sg.addColorStop(0.55, 'rgba(200,220,242,' + (a * 0.30).toFixed(3) + ')');
    sg.addColorStop(1, 'rgba(226,240,255,' + Math.min(1, a * 0.85).toFixed(3) + ')');
    ctx.strokeStyle = sg;
    ctx.lineWidth = Math.max(0.9, dR * 1.5);
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(d.x + Math.sin(d.wob) * 2, d.y - tl);
    ctx.quadraticCurveTo(d.x + w2 * 0.6, d.y - tl * 0.45, d.x + w2, d.y + 6);
    ctx.stroke();
  }

  /* ④ 水汽渐晕（渐变对象按尺寸缓存，别每帧建） */
  const vk = W + 'x' + H;
  if (!lensVig || lensVigKey !== vk){
    lensVigKey = vk;
    lensVig = ctx.createRadialGradient(W * 0.5, H * 0.52, Math.min(W, H) * 0.28, W * 0.5, H * 0.52, Math.max(W, H) * 0.80);
    lensVig.addColorStop(0, 'rgba(120,150,180,0)');
    lensVig.addColorStop(0.7, 'rgba(104,134,168,0.10)');
    lensVig.addColorStop(1, 'rgba(84,110,142,0.22)');
  }
  ctx.globalAlpha = Math.max(0, Math.min(1, (r - 0.22) * 1.15));
  ctx.fillStyle = lensVig;
  ctx.fillRect(0, 0, W, H);
  ctx.globalAlpha = 1;

  ctx.restore();
}

/* 箭头只指个大概方向，不画路线 —— 具体怎么绕过去还是你自己摸 */
function drawXrayMarks(){
  /* 开发者透视：画在黑幕之后面，不然夜里什么都看不到 */
  if (!(CFG.dev && CFG.xray) || !player) return;
  if (!enemies || !enemies.length) return;
  ctx.save();
  ctx.lineWidth = 1.6;
  ctx.font = '10px "Microsoft YaHei",sans-serif';
  for (const e of enemies){
    if (e.dead) continue;
    const sx = e.x - cam.x, sy = e.y - cam.y;
    if (sx < -50 || sx > W + 50 || sy < -50 || sy > H + 50) continue;
    ctx.strokeStyle = e.boss ? 'rgba(255,170,110,0.92)' : 'rgba(120,255,200,0.85)';
    ctx.beginPath(); ctx.arc(sx, sy, e.r + 6, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(150,255,215,0.9)';
    ctx.fillText(Math.round(e.hp === undefined ? 100 : e.hp) + '', sx + e.r + 9, sy + 4);
  }
  ctx.restore();
}

function drawGuideArrow(L){
  if (!player) return;
  let tgt = null, best = 1e9, isLoot = true;
  for (const l of loots){
    if (l.taken) continue;
    const d = dist(player.x, player.y, l.x, l.y);
    if (d < best){ best = d; tgt = l; }
  }
  if (!tgt && L.extract){
    isLoot = false;
    tgt = {x: L.extract.x + L.extract.w / 2, y: L.extract.y + L.extract.h / 2};
    best = dist(player.x, player.y, tgt.x, tgt.y);
  }
  if (!tgt) return;
  const sx = player.x - cam.x, sy = player.y - cam.y;
  const a = Math.atan2(tgt.y - player.y, tgt.x - player.x);
  const r = 76;
  ctx.save();
  ctx.globalAlpha = 0.60 + 0.22 * Math.sin(timeAlive * 3.4);
  ctx.translate(sx + Math.cos(a) * r, sy + Math.sin(a) * r);
  ctx.rotate(a);
  ctx.fillStyle = isLoot ? 'rgba(255,210,74,0.95)' : 'rgba(154,208,255,0.95)';
  ctx.beginPath();
  ctx.moveTo(13, 0); ctx.lineTo(-8, -7); ctx.lineTo(-3, 0); ctx.lineTo(-8, 7);
  ctx.closePath(); ctx.fill();
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = 0.55;
  ctx.font = '11px "Microsoft YaHei",sans-serif';
  ctx.fillStyle = '#e8eef6';
  ctx.textAlign = 'center';
  const _tx = sx + Math.cos(a) * (r + 36), _ty = sy + Math.sin(a) * (r + 36) + 4;
  const _lt = Math.round(best / 10) + ' 米';
  ctx.strokeStyle = 'rgba(4,8,12,0.85)'; ctx.lineWidth = 3; ctx.strokeText(_lt, _tx, _ty);
  ctx.fillStyle = '#e8eef6'; ctx.fillText(_lt, _tx, _ty);
  ctx.restore();
}

/* 玻璃碎裂：只播放录音中的第一声，保留完整尾音。 */

let glassBuf = null, glassDecoding = false;
/* 玻璃碎裂的全局冷却：一次炸开好几块玻璃时，只发一声，否则会叠成"两段不同音高的破碎" */
let glassSndT = 0;
function loadGlass(){
  if (glassBuf || glassDecoding || !actx) return;
  glassDecoding = true;
  try{
    const bin = atob(GLASS_SRC.split(',')[1]);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    actx.decodeAudioData(arr.buffer, function(b){ glassBuf = b; }, function(){ glassDecoding = false; });
  } catch(e){ glassDecoding = false; }
}
/* 第一声在 2.1 秒前已衰减结束，下一声约从 2.2 秒开始。 */
/* ---------------- 手雷爆炸 ----------------
   素材是用户给的 爆炸.mp3（编译成 data/nade_boom.js 里的 base64 mp3）。
   只给手雷用 —— 火箭弹、破片各有自己的声音，不要混着听。 */
let boomBuf = null, boomDecoding = false;
function nadeBoomDecode(){
  if (boomBuf || boomDecoding || !actx || !window.NADE_BOOM_SRC) return;
  boomDecoding = true;
  b64ToBuf(window.NADE_BOOM_SRC,
    x => { boomBuf = x; boomDecoding = false; },
    () => { boomDecoding = false; });
}
function sfxBoom(px, py){
  if (!actx) return;
  if (!boomBuf) nadeBoomDecode();
  let v = 0.85;
  /* 手雷炸得响，传得也远：2.2km 之外才衰减到底 */
  if (px !== undefined && player){
    const d = Math.hypot(px - player.x, py - player.y);
    v *= clamp(1 - d / 2200, 0.30, 1);
  }
  try{
    if (boomBuf){
      const src = actx.createBufferSource();
      src.buffer = boomBuf;
      /* 每颗略微不同音高，连扔几颗不会像复读机 */
      src.playbackRate.value = 0.92 + Math.random() * 0.16;
      const g = actx.createGain();
      const t0 = actx.currentTime;
      g.gain.value = v;
      g.gain.setValueAtTime(v, t0);
      src.connect(g);
      /* 手雷爆炸也按声源位置做左右定位（同一个炸点，左右声道要一致） */
      if (typeof _xsPan === 'function' && px !== undefined) _xsPan(g, px, py); else g.connect(duckBus());
      src.onended = () => { try { src.disconnect(); g.disconnect(); } catch(e){} };
      src.start(t0);
      return;
    }
    /* 素材还没解码完：先用一记低频闷响顶一下，绝不能没声 */
    ensureNoise();
    const t0 = actx.currentTime;
    if (noiseBuf){
      const n = actx.createBufferSource(); n.buffer = noiseBuf;
      n.playbackRate.value = 0.35;
      const lp = actx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 420; lp.Q.value = 0.8;
      const g2 = actx.createGain();
      g2.gain.setValueAtTime(v * 0.9, t0);
      g2.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.55);
      n.connect(lp); lp.connect(g2); g2.connect(duckBus());
      n.start(t0); n.stop(t0 + 0.6);
    }
    const o = actx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(120, t0);
    o.frequency.exponentialRampToValueAtTime(38, t0 + 0.45);
    const og = actx.createGain();
    og.gain.setValueAtTime(v * 0.5, t0);
    og.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.5);
    o.connect(og); og.connect(duckBus());
    o.start(t0); o.stop(t0 + 0.55);
  } catch(e){}
}

function sfxGlass(vol, px, py){
  if (!actx) return;
  if (!glassBuf) loadGlass();
  let v = (vol === undefined) ? 0.55 : vol;
  /* 远了只是轻，不是没声。之前不管距离都是 0.6，远处破玻璃被炸弹声盖掉就像"没声音"。 */
  if (px !== undefined && player){
    const d = Math.hypot(px - player.x, py - player.y);
    v *= clamp(1 - d / 1700, 0.38, 1);
  }
  try{
    if (glassBuf){
      const b = glassBuf;
      const dur = Math.min(2.1, b.duration);
      const src = actx.createBufferSource();
      src.buffer = b;
      src.playbackRate.value = 0.86 + Math.random()*0.34;
      const f = actx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 700;
      const g = actx.createGain();
      const t0 = actx.currentTime, end = t0 + dur / src.playbackRate.value;
      g.gain.value = v;                 /* 立刻生效，也方便测试读取 */
      g.gain.setValueAtTime(v, t0);
      g.gain.setValueAtTime(v, Math.max(t0, end - 0.08));
      g.gain.linearRampToValueAtTime(0, end);
      src.connect(f); f.connect(g); g.connect(duckBus());
      src.onended = () => { src.disconnect(); f.disconnect(); g.disconnect(); };
      src.start(t0, 0, dur);
      return;
    }
    /* 还没解码完：先用短促高频噪声顶一下，不能没声 */
    ensureNoise();
    const t0 = actx.currentTime;
    if (noiseBuf){
      const s2 = actx.createBufferSource(); s2.buffer = noiseBuf;
      s2.playbackRate.value = 1.0 + Math.random()*0.25;
      const f2 = actx.createBiquadFilter(); f2.type = 'highpass'; f2.frequency.value = 2600; f2.Q.value = 0.9;
      const g2 = actx.createGain();
      g2.gain.setValueAtTime(v * 0.9, t0);
      g2.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.34);
      s2.connect(f2); f2.connect(g2); g2.connect(duckBus());
      s2.start();
    }
    for (let i = 0; i < 5; i++){
      const o = actx.createOscillator();
      o.type = 'triangle';
      o.frequency.value = 2400 + Math.random() * 3600;
      const gg = actx.createGain();
      const tt = t0 + Math.random() * 0.09;
      gg.gain.setValueAtTime(0.0001, tt);
      gg.gain.exponentialRampToValueAtTime(v * 0.16, tt + 0.008);
      gg.gain.exponentialRampToValueAtTime(0.0001, tt + 0.06 + Math.random() * 0.12);
      o.connect(gg); gg.connect(duckBus());
      o.start(tt); o.stop(tt + 0.3);
    }
  } catch(e){}
}

function ensureNoise(){
  if (!actx || noiseBuf) return;
  try{
    const len = Math.floor(actx.sampleRate * 0.16);
    noiseBuf = actx.createBuffer(1, len, actx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i=0;i<len;i++) d[i] = (Math.random()*2-1) * (1 - i/len);
  }catch(e){}
}

function beep(freq, dur, type, vol, slideTo){
  if (!actx) return;
  try{
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, actx.currentTime);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(30,slideTo), actx.currentTime+dur);
    g.gain.setValueAtTime(0.0001, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(vol||0.05, actx.currentTime+0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime+dur);
    o.connect(g); g.connect(duckBus());
    o.start(); o.stop(actx.currentTime+dur+0.02);
  }catch(e){}
}

/* 脚步：一段低通白噪，短促 */
const combatSamples = new Map();
function combatSamplesWarm(){
  const Offline = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  if (!actx || !Offline) return;
  ensureNoise();
  if (!noiseBuf) return;
  const sr = actx.sampleRate, noise = noiseBuf;
  const bake = (key, seconds, draw) => {
    try {
      const ctx = new Offline(1, Math.ceil(sr * seconds), sr);
      draw(ctx);
      ctx.startRendering().then(buf => combatSamples.set(key, buf)).catch(() => {});
    } catch (e) {}
  };
  const rpg = gunDef({wid:'rpg'}).sfx;
  bake('rpg', rpg.tail + 0.03, ctx => synthGunShot(ctx, ctx.destination, noise, rpg));
  for (const cut of [240, 250, 330, 380])
    bake(cut, 0.14, ctx => synthStep(ctx, ctx.destination, noise, 1, cut));
}
function combatSamplePlay(key, volume, out){
  const buf = combatSamples.get(key);
  if (!actx || !buf) return false;
  const src = actx.createBufferSource(), gain = actx.createGain();
  src.buffer = buf;
  gain.gain.value = volume;
  src.connect(gain); gain.connect(out);
  src.onended = () => { src.disconnect(); gain.disconnect(); };
  src.start();
  return true;
}
function synthStep(ctx, out, noise, vol, cut){
  const src = ctx.createBufferSource(), filter = ctx.createBiquadFilter(), gain = ctx.createGain();
  const t = ctx.currentTime;
  src.buffer = noise;
  filter.type = 'lowpass'; filter.frequency.value = cut; filter.Q.value = 0.8;
  gain.gain.setValueAtTime(vol, t);
  gain.gain.exponentialRampToValueAtTime(vol * 0.001, t + 0.13);
  src.connect(filter); filter.connect(gain); gain.connect(out);
  src.start(t); src.stop(t + 0.14);
}
/* m33644：isEnemy 为真时不乘「脚步声」滑条 —— 那条滑条只管玩家自己，
   敌人脚步是玩法提示（听见有人摸过来），不能被自己的静音连累。 */
function sfxStep(vol, cut, isEnemy){
  if (!actx) return;
  try {
    const _sk = isEnemy ? 1 : ((typeof stepVolK === 'function') ? stepVolK() : 1);
    if (_sk <= 0.001) return;
    const volume = Math.max(0.001, vol) * _sk, cutoff = cut || 360, out = duckBus();
    if (combatSamplePlay(cutoff, volume, out)) return;
    ensureNoise();
    if (noiseBuf) synthStep(actx, out, noiseBuf, volume, cutoff);
  } catch (e) {}
}

/* 心跳：一下重、一下轻、再加一记更闷的尾巴，配上低频噪声做"胸腔"感 */
function thump(vol, f0, f1){
  if (!actx) return;
  const now = actx.currentTime;
  try{
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(f0 || 70, now);
    o.frequency.exponentialRampToValueAtTime(f1 || 30, now+0.20);
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), now+0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, now+0.26);
    o.connect(g); g.connect(duckBus());
    o.start(now); o.stop(now+0.28);
  }catch(e){}
  try{
    ensureNoise();
    if (!noiseBuf) return;
    const s2 = actx.createBufferSource(); s2.buffer = noiseBuf;
    const f = actx.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = 150; f.Q.value = 0.7;
    const g2 = actx.createGain();
    g2.gain.setValueAtTime(Math.max(0.001, vol*0.6), now);
    g2.gain.exponentialRampToValueAtTime(0.0001, now+0.15);
    s2.connect(f); f.connect(g2); g2.connect(duckBus());
    s2.start(now); s2.stop(now+0.18);
  }catch(e){}
}



const LINE_SRC = 'data:audio/mp4;base64,AAAAHGZ0eXBpc29tAAACAGlzb21pc28ybXA0MQAAAAhmcmVlAAAEym1kYXTcAExhdmM2MS4zLjEwMAAByK9Qy4KiEI7Cuv07h8ZlV8etZvz4tSMlpdZJVWIV/5jEWCMJr+Vmkrxj+23sHgQLaPAYSRp3wfP54EBJ8wOyMH2yfOMCTeIx9iASb7beww+fzj21AeF3bM4fIJf4f4+cAHz66FP6Q+X7de330Hy0Ev8f4j/jQAz6AfP8/jn/x8eHy+f9Mwp/T5aAf4fPMl/i/gUmG3D7H+0hhj84/sReFwA2jsw7urMf0z/4pmAD+j5qQ/x/h/j/G3rEAU+4SJjF+/2P/DJiJj8XYeY+N+L+N+y+y+y+L9H4vD0836PmMs1OxxnbeJ5jmM/wATqe2HvbZLDzZZD7fjMy/GlyLxxGtfv/Zrevj1Elq/H+rW2hNVvr+f+wAAQj+dtM9ElURDKwM0keYPsduQyW4wzuwx/8SfEAiXQ7UgRjYSoSuloKa8y2xbUkbSfGBOeXn5VHdLclDDNpBAILhPl0Djqie1mEKsIhwmfYkkHPlepVOTY29WicImwghLVAPjaHYFeCp2nyyj5do57rBXBZ4IWuCQvfWFguCHhymQ4HhUk4QN9WijYY3W9PCdQYYFrTxve2zNX5K2ZR77xshnafcafbKF2SAFg3UWf10lzE7BDw8bnuASae2slohLVZhPlQyyVHqyWHl+a9cXe5LlQHr/b+wXgTrV/ld+efHHPt5zWs9d+eMyvXH1XUtHHewABx3bAAB6W5fB0xOeqx3EM3dPIzsesnVOmqXzgk8wKKc1oLSXWX1DOi80P8sckwJvtOyih+dFROjkgrlBnUjV8H+HRVlkH+39HgpzDJnPZpARHf7az2gAGAAlXCAbyoBEAA8VeM4PixwqkS36oEkeUEXnMmgkHjfnXAooP2i/IoQjNNYiVEQ7LABYIwKIH9ZZvVCiXXoXVbKzWebBVgg4Sle7gBNJ+1ykZntNlkuHWUjIeXx464rL3L4nDj/NgF8OJ+QA467+B9COl90X1pIvJ8MpZUUgDDBtCCyhtspvU0Vy2Ul/eYL8t4ML83T0aHAYxlNYKCa4LxtsrBpxoYInbjtlURQ4rKla21zipGNKKmm3v1vH679Hb92oRnCOejpSm5nIywbqr3mAtGcI9y6oorAsq4DJHPScBdnJyEsCbdBpREgIA8F7PZRAo1YSi923yzh/e8nmgSJROlJ4o375rKBNZ5uu4y2ucBKp+yyP4sj+LJc7rJdaSiu7hzxk669/N/0nNuN8zzPjvz7fZvU5U/JXmuPP8ceur9Vzx/8ccSJx37jIHHaeBwMKF9AO16Mt6WWRsjUxrR6Duf40wxbPCRYuwHaXpEYP87wF37dM/AAVl2ADdYbSVs3zBWQYKkt9pxwmEwkY2Y4jNi7H9GwFcSAGXxB/QnlPMBbGAZJwqAD9xBaMzP4mPDurutQz/3okYVX2mk6Yz9V61DDsY8bs8NqgOAASCe2vrTZ2H+Q4FhQ/K8LqkJuda5/87r1xntv7F5rz/pr3Hf32rWzqYoM6m7bLpgqq3eYdawjMW4v9X+/1XNlhO+CfVvSn3uuituMP8WV6UdKOaep8HD/UdJlI3Xsg3XWh2XTPwoH0WAA3XGAZvv3oQA6V1sL4u1gAfwgGTEGEHAARiBtHAAAAMqbW9vdgAAAGxtdmhkAAAAAOcD7hHnA+4RAAAD6AAAAOwAAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAlV0cmFrAAAAXHRraGQAAAAD5wPuEecD7hEAAAABAAAAAAAAAOwAAAAAAAAAAAAAAAEBAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAADrAAAEAAABAAAAAAHNbWRpYQAAACBtZGhkAAAAAOcD7hHnA+4RAABdwAAAGgtVxAAAAAAALWhkbHIAAAAAAAAAAHNvdW4AAAAAAAAAAAAAAABTb3VuZEhhbmRsZXIAAAABeG1pbmYAAAAQc21oZAAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAABPHN0YmwAAAB+c3RzZAAAAAAAAAABAAAAbm1wNGEAAAAAAAAAAQAAAAAAAAAAAAEAEAAAAABdwAAAAAAANmVzZHMAAAAAA4CAgCUAAQAEgICAF0AVAAAAAACJBAAAiQQFgICABRMIVuUABoCAgAECAAAAFGJ0cnQAAAAAAACJBAAAiQQAAAAgc3R0cwAAAAAAAAACAAAABgAABAAAAAABAAACCwAAABxzdHNjAAAAAAAAAAEAAAABAAAABwAAAAEAAAAwc3RzegAAAAAAAAAAAAAABwAAAPoAAADkAAAA3QAAAMYAAAC7AAAAgQAAAAUAAAAUc3RjbwAAAAAAAAABAAAALAAAABpzZ3BkAQAAAHJvbGwAAAACAAAAAf//AAAAHHNiZ3AAAAAAcm9sbAAAAAEAAAAHAAAAAQAAAGF1ZHRhAAAAWW1ldGEAAAAAAAAAIWhkbHIAAAAAAAAAAG1kaXJhcHBsAAAAAAAAAAAAAAAALGlsc3QAAAAkqXRvbwAAABxkYXRhAAAAAQAAAABMYXZmNjEuMS4xMDA=';
/* 素材是「咚-咚」两下为一拍，原始约 57 拍/分、一拍 1.06 秒。
   直接用 <audio> 改 playbackRate 会让音调一起变尖，所以拆成两段独立取样，
   由代码按当前血量的 BPM 重新排节奏。 */
const HB_LUB = [0.175, 0.435];
const HB_DUB = [0.435, 0.720];
const HB_CYCLE = 1.060;

let hbBuf = null, hbDecoding = false, hbFailed = false, hbSampleOn = false;
let hbBeatClock = 0, hbLastHit = 99, hbBpm = 0;
let tense = 0;   /* 0=脱战，1=正在被追。上来要快，松下来要慢 */
let hbHumOsc = null, hbHumGain = null;
let hpFx = {f:1, k1:0, k2:0, k3:0};

/* 三档阈值：70% 轻微暗角 / 40% 心跳+明显暗角 / 20% 最快最响+抖动+隧道+嗡鸣 */
function hpLevels(){
  const f = player ? clamp(player.hp / Math.max(1, (ar ? arenaMaxHp() : CFG.hp)), 0, 1) : 1;
  return { f:f,
    k1: clamp((0.70 - f)/0.30, 0, 1),
    k2: clamp((0.40 - f)/0.20, 0, 1),
    k3: clamp((0.20 - f)/0.20, 0, 1) };
}

/* 拉闸音效：素材本身偏大，这里压到 0.34 并淡出尾巴 */
let swBuf = null, swDecoding = false, swFailed = false;
function swDecode(){
  if (swBuf || swDecoding || swFailed || !actx) return;
  swDecoding = true;
  try {
    const b64 = SW_SRC.slice(SW_SRC.indexOf(',') + 1);
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    actx.decodeAudioData(arr.buffer, b => { swBuf = b; }, () => { swFailed = true; });
  } catch(e){ swFailed = true; }
}
function sfxSwitch(){
  if (!actx || swFailed) return;
  swDecode();
  if (!swBuf) return;
  try {
    const src = actx.createBufferSource();
    src.buffer = swBuf;
    const g = actx.createGain();
    const t0 = actx.currentTime + 0.01;
    g.gain.setValueAtTime(0.34, t0);
    src.connect(g); g.connect(duckBus());
    src.start(t0);
  } catch(e){}
}

let alBuf = null, alDecoding = false, alFailed = false, alPending = 0;
const STEP_SRC = 'data:audio/mp4;base64,AAAAHGZ0eXBNNEEgAAACAE00QSBpc29taXNvMgAAAAhmcmVlAAAMtm1kYXTcAExhdmM2MS4zLjEwMAACMEAOARggBwEYIAcBGEAHAN6fNHi0Gv8Ib/N/k43Vz/3r+NZKt1X5zLzn/+z9wn4qGX+v/9z73+uP18eQQJIvkk+LM0FGAXRA/0+39cFFlBnCb9OdpKqohlcgRhWZbtkIcUhMsELULu3OjCEu2QwNIhQtEZ0gnjalQVrEn76IS8cQoQyECHRCyaot9c0fCbIhdN+j/2/qew6ccttxd1j6/1XuTOgMABzRcvE1Xzu+vuHYEUWGgHpwfqDk2C9bwTRkZQiEfKWbOJ4DBytLypmiVQhKkXgZCBHIR3YFGIkfj0mcbdGTUYjAORhy/5nf4sQGm7ZBEkyawEggfkFSms4GUd+53QTQO/+kzY9YHPICDJoiZhEamOIqaQ3UonTUSAOUSzIrUXYff5MZqzAQEXJscmJRBeL2bKJSL1YCLK6CcODdwcAJP04nRTbxtlEhB72vmyfJ+t/R/3c3ZUBkIZI4ZYNRQ5dOTkUObd15gUySI5J0HNPNcC/obp6vl6R0SThyOQzuHARysaTTzK3x5Ms8WdP779crcdZl/ud+/afrTWx4IDB3SgCWDrckTAwtUD7BhRNAuCaB8PSZTbYMht7MtqJ0zTvNsfdRNZidGkr5gJkmE5LpbDzP5VZg/qdeYb2eRc6oI1Zy7rB+G8pmQBAYSaYEnLyEC3jdI0U+1QsVeYIG7gNojgolESLpp9Q0PJwEslUnZwOoNto/ITyDDVgKsB0WQm8mG9vEzOt8VbFu5ROZQyfD26QGwnALl3KyPwsWu8XmNrBJOqEAsx80kM9qQMgEk1dYHwAv92oYhFsqXA8BrM8Rl85GC/zmliQCaUsL/kSAQik90m8lJFPY4CDzVkPnnmT5+zlS0mhl2gK8LQdbzZPB/yycWWRawrYnUHXSzc0tEkrc1gdZLeL/6+NNaR9yaSEG+/OKLDvehQ0vFe04f3DSuoe2eCenU5816rnUHUB3Cc30Yzsu9OABGPeszfKhQADU2885c5eb70071dS8iFzQIQ+GEuS6Gg2ERI5QyCDV2OONvOsvZq+En8YXeTDJ8Yv/Xh/n3omCnwxmKlLkydXVIEWkunpO9EpapCZFO54G98DOxRdyiJywlMgi1zO+y9ZnoghFTXNUjKGRelgFdOTM8i2VlQy1Spdl3wvPTK8kQjACrERCrZLLLXv6rig1NyVZ8mi6VlPe97MISLVQE7sQPWNozi1lWcoCUWgtljqwTQKRKAoT22JIFazq2LOTJMhqLKyKASQFQiQktCQlk8jKOcDaNsU2BK4GmRyDK519klqdSwPaI3d84TENKrKxQMAB1HmIKqDw9EY+J9FH/n+z7wQNI0gD+Q7wuT3z+gMWgxcLvvxG3nxi+w4TP1+oipfuDOpyNgd1iJDvabFTTZ7pGdVZJf9yx/zr3ip8R6A+y/Ypz1q+ARhXrHSW8hQAACySX2l3jrIlVe+JdgnNhEccK+eUdoFY39TW7m3h5+Pe25ZxhQwYRkZIKOkqldll5cu/K4Dll6dnTpnKLlGWWU8TxWJiudK2MkgTvFBHNNa6sEktjSAonFdDxQbq5HVnYeYreRPE+U8+U8OAqNiqY2Kr2KTyW2Od6a2pRQMGACd4GbGbGdojB4FFQ1kmKObzQDHnPYYWHfVWQwdrEkVIZddkx8KLBVEsAQZosulCyDN6EGd2uQ0vKDCneZyTEtII6yq98qyqNZpE4gByGEAr3kttaXLOpWkCGjNSwmrqpswQju8ksKDDUaW8JqhvxsH+RSDP6GZVHAZqBtA6ToLA/2WrBHFWefXefxk04uHRJY3+lupTPHkc+Fcjl5WJ7mlXbg4E1r+EPoaGbrypbEAfuhKCLV0SYYeCnvu9uXABIp7a1GI7r/N/m/y7e11nGnveuNX+n118Xc4qSup7f/0/8eZWt17Xl3xr/+7/vq7e3MzrOK08dGW4AB+3bWeLZ5zIyiGAQgKydlTvGaokk5nUDr4qbVEnnQFWuVVblBAhOSIk0qGotj/ZJmBvzMnFFohOw3mTsWKaS6U33YXX/5JZF4LIP6rHWY1XYDt9e4LHPTZBZf11NL3506pUxpbzPwC1i7LpHmtfe2R53H2J3Fua3iaVkwe9sc3N0hzD+v/z8xQ66lZXA5ZVNQSKxDme6Bkij4x+cmQOJ5AFxZcaW2J8PRSbMLLJfWfU7NCRIzPPROgc48Nz1QsHrj679NpnozqihwYOPv0m0PNNQo7zi9VVMsiVFoj7ls0EqC8e/ZxPeGQA1ABU0v+lIrXKhotzZyhh1CAt0kuo/TbdwNHRuQC9eJsFNKjRkAUZaQfUNZu2fC/vMyw2mMtplOr2RMZbHZP5qBNRZrPF6estD/+1RzWQFbWAfeSARaT7I7351/1RDo9hzNp+8v2uTiQ+lt48cB9vmznvQYCSEPtXrD6hmqnc6E1jBfhVOM8s92cdLrJSxBUQ5dXwjG891oDvvtHnX9fmH0T5ieH3+2lA+GWRQI/S8hB+Mp7IvOvEJCrAFvBz98TvO6hvewc/fcXF1RYw73690jzVh3xxBSiSi6snctP8ZS0D9Y4pWBdou2+q/hvm7n5mrNZREyJeDWBKul0BIY+ZemKnPG/uOFUz3tN2h9H1qK+XjG95E4o/QpTCTGfVVTiuGZh1uX2ygRdP9KVKHvCwKhNv3/n3mREKWA9td1dW8pen2Kn6tQoN4kzncun82EjN9wx6D7RdTe4+s2NR/YsqlJ/I15BgehXO5uhLVIJyXaoPMv6tqAmD98s9hVqCoy/8/68ng8DsNuWMHR3/nzVmdBYwKDBgZaIdgI62TlKig6DbX72zFfUpnFgYSJE2iLIQamV5V1j6DPhZurAXf5MQ8Bh48N9wtcnW8qpIrbur8tGm28zcAS73qEXxaEhaQx6EQo37c8deuLzJxrfGXVaXzStXWXHdN3Spc10Lf57WZX3Z4t/Bncc+YOQHN7iteg7HSs9TnIMd/34h2e6SicmyDrJAbRXaD5n1jO+gJUBz3M+GUrAWAA42tZ+nOQbC2/geNa2LdkmMs5shgZ1YdHHCSZ1163xTNqrFhy4YfFby1csZ8PU1W5sulc0W3LQjTpDBtZca9M/oDgEIN6xpskIYxvHn3te9N2nlgSub1k1eSpUq0yRe/YVqT0s9JVXtX7UfFBUFzlAGiyYH5tGL/V4ijGceBGvepn7iM/QhD3c+7AHAQtDFDy+EuRi2pdt6HRSfdaNBq2/Gzc6zUnbXprZzwONVV9CG63TevyDfn9Utm63aNlBLOeKcDmtyfRRjm9zVZbMUFnvS3A+5ZdwKP0Kjk30ljR5vN2qajJlpx11qvNlh27JmlCC/YTuVc0RVg9JV1GJCYljxl/LjqgR3p1RRLDB6l+sa2Z4ZDo1Z8rma8sZWeylmYZz6qVx5IzE+SI804AEKNyhp8RFQYid9enGvWuOPEXNZOMzJnn1d6qsu8q0XVvYbr8SI2aiiltUbBF41Q7IbFOpeVfHMZkaM2zVr1ajlQbZaedG8KLr6NYLzWdwPWNu6ota0MgVLCazFmLKEiok9r31Zvcdw3O3tGV1K86B7Gj0qa/A3suJWA2wyXoyfCVIHUE2MZupxmNWPQekWbbaBX44c19Nf+0h85YDpVr0ZMz2T1PmbmbKJcz98useTe1aaplVcMjyuTiitA4aEknWB9oVd8j9sLmFLAS8Xk9cF4v4Ql/DxAy+IcAEGNijFZFEZOeGV7d4t9b5vOM1sriq1My5TVTLqw9nV8auRA0kvcDHkt/JOVt7Q2Xp/3pcgJ/dkDj+4n+bJ4rhd5ho+ABnhaiywZTPpSpVbwqjTsuFBuX2qalY6wqm+UgVxJaqlC1XzVEzK4IdK2vVR4VUoSdttzNIU1lq5s8nqmiQU09Zc26mhZnymPmRlQcAHrzK5yToyV/EGgc8OdwP2vtmyPtoDTpAOr+DucxkuZG0w6DBMOfQ77zNn+GxMIUlwAP41qKl2CijI+q9/ruvPv51tKNc5OCZxvV96lZMkrrv8Dgah8f/+67OnCvDkYlrXRMqRtQvahsvxZVPLTqhlsB5xVXe+M8ECJXht1K1DCCmSSWV++5Is6yE29qPTP2gLNBbOpdbBT4FZQX4LR/sghUkl63/5fWaKIa+Ku13oK+xHcwVzTWDxFRVuQoKhJNOahqvCKhVmaOu9oIEihpFEuJbuzW3Xo0UJ9Vrc0AAeD9CTwy2mtzcPK0WLouEAA4AA3DAAKGALBARBARFBbBsLNVU6oJ/5f+YC2TsSxVM3NBC7lNkayDn5mc7dWP50/9nEiNO0QbFJX6lpxiMYNusIyEEjSCUJBJCiSoJKZL4AAAMybW9vdgAAAGxtdmhkAAAAAOcFBN/nBQTfAAAD6AAAAiYAAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAl10cmFrAAAAXHRraGQAAAAD5wUE3+cFBN8AAAABAAAAAAAAAiYAAAAAAAAAAAAAAAEBAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAAImAAAEAAABAAAAAAHVbWRpYQAAACBtZGhkAAAAAOcFBN/nBQTfAABdwAAAN5BVxAAAAAAALWhkbHIAAAAAAAAAAHNvdW4AAAAAAAAAAAAAAABTb3VuZEhhbmRsZXIAAAABgG1pbmYAAAAQc21oZAAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAABRHN0YmwAAABqc3RzZAAAAAAAAAABAAAAWm1wNGEAAAAAAAAAAQAAAAAAAAAAAAEAEAAAAABdwAAAAAAANmVzZHMAAAAAA4CAgCUAAQAEgICAF0AVAAAAAACrJwAAqycFgICABRMIVuUABoCAgAECAAAAIHN0dHMAAAAAAAAAAgAAAA0AAAQAAAAAAQAAA5AAAAAcc3RzYwAAAAAAAAABAAAAAQAAAA4AAAABAAAATHN0c3oAAAAAAAAAAAAAAA4AAAATAAAABAAAAAQAAAAEAAACzAAAAU4AAAFGAAAC+AAAAKMAAADqAAAA2wAAAMIAAAC/AAAATgAAABRzdGNvAAAAAAAAAAEAAAAsAAAAGnNncGQBAAAAcm9sbAAAAAIAAAAB//8AAAAcc2JncAAAAAByb2xsAAAAAQAAAA4AAAABAAAAYXVkdGEAAABZbWV0YQAAAAAAAAAhaGRscgAAAAAAAAAAbWRpcmFwcGwAAAAAAAAAAAAAAAAsaWxzdAAAACSpdG9vAAAAHGRhdGEAAAABAAAAAExhdmY2MS4xLjEwMA==';


/* 有人看见你时循环播的警报：多个摄像头/无人机同时看见也只放一份，
   没人看见就慢慢淡到 0（不是"啪"地掐掉） */
let al2Buf = null, al2Decoding = false, al2Failed = false;
let alarm2Src = null, alarm2Gain = null, alarm2Lvl = 0, alarm2Want = 0;
function al2Decode(){
  if (al2Buf || al2Decoding || al2Failed || !actx) return;
  al2Decoding = true;
  try {
    const b = AL2_SRC.slice(AL2_SRC.indexOf(',') + 1);
    const bin = atob(b);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    actx.decodeAudioData(arr.buffer,
      x => { al2Buf = x; al2Decoding = false; },
      () => { al2Failed = true; al2Decoding = false; });
  } catch(e){ al2Failed = true; al2Decoding = false; }
}
let stepBuf = null, stepDecoding = false, stepFailed = false;
let stepPeak = 0;          /* 采样峰值（0 = 还没量过 / 量失败），用来把音量补到听得见的档 */
/* 把任意峰值的采样归一到目标响度，最多放 6 倍，免得把底噪一起放大 */
function stepGainK(target){
  if (!stepPeak || stepPeak < 0.0005) return 1;
  return Math.min(6, target / stepPeak);
}
function stepDecode(){
  if (stepBuf || stepDecoding || stepFailed || !actx) return;
  stepDecoding = true;
  try {
    const b = STEP_SRC.slice(STEP_SRC.indexOf(',') + 1);
    const bin = atob(b);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    actx.decodeAudioData(arr.buffer,
      x => {
        stepBuf = x;
        /* 内嵌采样是"远处录的脚踩地"，峰值只有 -17dB、平均 -35dB，直接播根本听不见。
           解码完量一次峰值，播的时候按它把音量补回来（见 stepGainK）。 */
        try {
          const ch = x.getChannelData ? x.getChannelData(0) : null;
          if (ch){
            let pk = 0;
            for (let i = 0; i < ch.length; i++){ const v = ch[i] < 0 ? -ch[i] : ch[i]; if (v > pk) pk = v; }
            stepPeak = pk;
          }
        } catch(e){ stepPeak = 0; }
        stepDecoding = false;
      },
      () => { stepFailed = true; stepDecoding = false; });
  } catch(e){ stepFailed = true; stepDecoding = false; }
}
/* 真采样优先；还没解好就退回合成声，不能因为素材没就绪而没声 */
function sfxFoot(){
  if (!actx || !stepBuf) return false;
  /* m33644：自己的脚步采样走的是这条路（不经 sfxStep），所以「脚步声」滑条得在这里也生效。
     静音时返回 true 但不发声 —— 返回 false 会掉进 sfxStep 的合成脚步声，等于没静音。 */
  const _fsk = (typeof stepVolK === 'function') ? stepVolK() : 1;
  if (_fsk <= 0.001) return true;
  try {
    const t0 = actx.currentTime + 0.004;
    const src = actx.createBufferSource();
    src.buffer = stepBuf;
    if (src.playbackRate) src.playbackRate.value = 0.92 + Math.random()*0.16;   /* 每步微调，免得听着像机枪 */
    const g = actx.createGain();
    /* 当环境声处理，不当提示音：压到背景层，再削掉高频的"啪"。
       乘 stepGainK()：把这段本身很轻的采样补回可听范围（蹲/站的比例保持不变）。 */
    /* 直接按"输出峰值"定音量：蹲 0.13 / 站 0.20（约差 3.7dB）。
       BOSS 关（拉闸前只能静步）以前蹲着走几乎没声，就是因为这里按 4 倍衰减压下去；
       静步的"轻"由敌人听不见你决定，不该靠把这声音调到听不见来实现。 */
    g.gain.value = stepGainK(player.crouch ? 0.13 : 0.20) * _fsk;
    let tail = g;
    if (actx.createBiquadFilter){
      const lp = actx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = player.crouch ? 760 : 1100;
      lp.Q.value = 0.6;
      g.connect(lp); tail = lp;
    }
    src.connect(g); tail.connect(duckBus());
    src.start(t0);
    return true;
  } catch(e){ return false; }
}
function alarm2Update(dt){
  /* 暂停 / 看地图 / 不在游戏里的时候，警报不该还在喊 */
  const _live = (state === 'play' && !paused && !mapOpen && !confirmBack && !ui.inv.open && !logOpen);
  const want = _live ? alarm2Want : 0;
  if (!_live){
    /* 暂停（含 ESC 确认框 / 背包 / 日志）时，不光把 gain 压到 0，
       连自己的音量状态也往下收，否则下次一进游戏就是满声量吵上去 */
    alarm2Lvl += (0 - alarm2Lvl) * Math.min(1, dt * 8);
    if (alarm2Lvl < 0.004) alarm2Lvl = 0;
    if (alarm2Src && alarm2Gain){ try { alarm2Gain.gain.setTargetAtTime(0, actx.currentTime, 0.02); } catch(e){} }
    return;
  }
  const rate = want > alarm2Lvl ? 8.0 : 0.7;      /* 上来快、退得慢（约 3 秒淡完） */
  alarm2Lvl += (want - alarm2Lvl) * Math.min(1, dt * rate);
  if (alarm2Lvl < 0.004 && want <= 0){
    alarm2Lvl = 0;
    if (alarm2Src){ try { alarm2Src.stop(); } catch(e){} alarm2Src = null; alarm2Gain = null; }
    return;
  }
  if (!alarm2Src){
    if (alarm2Lvl < 0.02 || !actx || !al2Buf) return;
    try {
      const src = actx.createBufferSource();
      src.buffer = al2Buf; src.loop = true;
      const g = actx.createGain(); g.gain.value = 0;
      src.connect(g); g.connect(duckBus());
      src.start();
      alarm2Src = src; alarm2Gain = g;
    } catch(e){ return; }
  }
  try {
    alarm2Gain.gain.setTargetAtTime(alarm2Lvl * 0.5 * alarmMusicDuck(), actx.currentTime, 0.05);
  } catch(e){}
}
function alarm2Clear(){
  alarm2Want = 0; alarm2Lvl = 0;
  if (alarm2Src){ try { alarm2Src.stop(); } catch(e){} alarm2Src = null; alarm2Gain = null; }
}

/* --- 关卡专属音乐（触发警报时渐入，例：4-1 触红线放 4-1.mp3）
   单独一个播放器：不占用玩家自己导入的背景音乐，也不会被它顶掉 */
let lvlMusicEl = null, lvlMusicVol = 0, lvlMusicWant = 0, lvlMusicPath = '';
/* 浏览器的自动播放策略：没有用户手势时 play() 会被拒。
   这里记下“被拦了”，等玩家下一次点屏幕/按键就重试，而不是静默失败 */
let lvlMusicBlocked = false;
function lvlMusicKick(){
  if (!lvlMusicBlocked) return;
  lvlMusicBlocked = false;
  if (!lvlMusicEl || !lvlMusicWant) return;
  try {
    const pr = lvlMusicEl.play();
    if (pr && pr.catch) pr.catch(function(){ lvlMusicBlocked = true; });
  } catch(e){}
}
if (typeof document !== 'undefined' && document.addEventListener){
  document.addEventListener('pointerdown', lvlMusicKick, true);
  document.addEventListener('keydown', lvlMusicKick, true);
}
function levelMusicStart(path){
  if (!path) return;
  if (!musicOn){ return; }                      /* 关了音乐就一音不发 */
  if (lvlMusicEl && lvlMusicPath === path && !lvlMusicEl.paused){ lvlMusicWant = 1; return; }
  levelMusicStop();
  try {
    const el = new Audio(AUDIO_DIR + path);
    el.loop = true; el.preload = 'auto'; el.volume = 0;
    el.addEventListener('error', ()=>{ setMsg('关卡音乐放不了（文件读不到）', 2.6); });
    lvlMusicEl = el; lvlMusicPath = path; lvlMusicVol = 0; lvlMusicWant = 1;
    lvlMusicBlocked = false;
    const pr = el.play();
    if (pr && pr.catch) pr.catch(function(err){
      lvlMusicBlocked = true;
      if (err && err.name === 'NotAllowedError'){
        setMsg('浏览器拦了自动播放 · 点一下画面就放', 3.2);
      }
    });
  } catch(e){}
}
function levelMusicStop(){
  lvlMusicWant = 0;
  if (lvlMusicEl){ try { lvlMusicEl.pause(); } catch(e){} }
  lvlMusicEl = null; lvlMusicPath = ''; lvlMusicVol = 0;
}
function levelMusicTick(dt){
  if (!lvlMusicEl) return;
  const _live = (state === 'play' && !paused && !mapOpen && musicOn && !confirmBack && !ui.inv.open && !logOpen
                 && !(CFG.dev && CFG.devFreeze));
  const want = _live ? lvlMusicWant : 0;
  const step = dt / 1.6;                        /* 1.6 秒渐入/渐出 */
  if (lvlMusicVol < want) lvlMusicVol = Math.min(want, lvlMusicVol + step);
  else lvlMusicVol = Math.max(want, lvlMusicVol - step);
  try { lvlMusicEl.volume = Math.max(0, Math.min(1, lvlMusicVol * 0.85 * bgmVolume)); } catch(e){}
  if (want > 0 && lvlMusicEl.paused){
    const pr = lvlMusicEl.play();
    if (pr && pr.catch) pr.catch(function(){});
  }
  if (want <= 0 && lvlMusicVol <= 0.002 && !lvlMusicEl.paused){ try { lvlMusicEl.pause(); } catch(e){} }
}
/* 音乐起来的时候，警报自动让位（最低压到 38%），不然两个一起吵 */
function alarmMusicDuck(){ return 1 - 0.62 * lvlMusicVol; }

function alDecode(){
  if (alBuf || alDecoding || alFailed || !actx) return;
  alDecoding = true;
  try {
    const b64 = AL_SRC.slice(AL_SRC.indexOf(',') + 1);
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    actx.decodeAudioData(arr.buffer,
      b => { alBuf = b; alDecoding = false;
              if (alPending){ const v = alPending; alPending = 0; sfxSiren(v); } },
      () => { alFailed = true; alDecoding = false;
              if (alPending){ alPending = 0; synthSiren(0.16); } });
  } catch(e){ alFailed = true; alDecoding = false; }
}
/* 关掉警报：赢、输、重开、回大厅都要调，不然它自己会响满 71 秒 */
function stopSiren(){
  try { alarm2Clear(); } catch(e){}
  try { stopDroneHum(); } catch(e){}
  alPending = 0;   /* 还没解码完就排队的那一发也要取消，否则回家大厅了它才开响 */
  if (sirenSrc){ try { sirenSrc.stop(); } catch(e){} sirenSrc = null; }
  for (const o of sirenSynth){ try { o.stop(); } catch(e){} }
  sirenSynth = [];
}

/* 素材解不出来时的兜底：两路锯齿波 + 慢速上下滑音，听感接近防空警报 */
function synthSiren(vol){
  if (!actx) return;
  try {
    sirenSynth = [];
    const t0 = actx.currentTime + 0.02, dur = 7.0;
    const g = actx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.16, t0 + 0.25);
    g.gain.setValueAtTime(vol || 0.16, t0 + dur - 0.6);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    g.connect(duckBus());
    [0, 7].forEach(function(det){
      const o = actx.createOscillator(), og = actx.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(420, t0);
      o.detune.value = det;
      /* 4 秒一个来回的上下滑音 */
      for (let k = 0; k < 2; k++){
        const b = t0 + k*3.5;
        o.frequency.exponentialRampToValueAtTime(880, b + 1.7);
        o.frequency.exponentialRampToValueAtTime(420, b + 3.4);
      }
      og.gain.value = 0.5;
      o.connect(og); og.connect(g);
      o.start(t0); o.stop(t0 + dur);
      sirenSynth.push(o);
    });
  } catch(e){}
}
/* 防空警报：拉满三个电闸、门一开就响，一直响到你跑出去或者被抓住 */
function sfxSiren(vol){
  if (!actx) return;
  try { if (actx.state === 'suspended') actx.resume(); } catch(e){}
  if (alFailed){ synthSiren(0.16); return; }
  alDecode();
  if (!alBuf){
    alPending = vol || 0.62;    /* 还没解码完，解完自动补放 */
    /* 万一解码卡住（某些环境下 decodeAudioData 会一直不回调），1.4 秒后换合成警笛顶上 */
    setTimeout(function(){
      if (!alBuf && alPending){ alPending = 0; synthSiren(0.16);
        logWarn('audio', '警报素材解码超时，改用合成警笛'); }
    }, 1400);
    return;
  }
  try {
    const src = actx.createBufferSource();
    src.buffer = alBuf;
    const g = actx.createGain();
    const t0 = actx.currentTime + 0.02;
    g.gain.setValueAtTime(vol || 0.62, t0);
    src.connect(g); g.connect(duckBus());
    src.start(t0);
    sirenSrc = src;
  } catch(e){}
}

/* 剧情文字逐行弹出时的"叮"：素材只有 0.235 秒，压到 0.42 免得刺耳 */
let lineBuf = null, lineDecoding = false, lineFailed = false;
function lineDecode(){
  if (lineBuf || lineDecoding || lineFailed || !actx) return;
  lineDecoding = true;
  try {
    const b64 = LINE_SRC.slice(LINE_SRC.indexOf(',') + 1);
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    actx.decodeAudioData(arr.buffer,
      b => { lineBuf = b; lineDecoding = false; },
      () => { lineFailed = true; lineDecoding = false; });
  } catch(e){ lineFailed = true; lineDecoding = false; }
}
function sfxLine(){
  if (!actx) return;
  try { if (actx.state === 'suspended') actx.resume(); } catch(e){}
  lineDecode();
  if (!lineBuf){
    /* 还没解出来就退回到合成的一声短"叮"，保证第一行也不会哑 */
    try {
      const t0 = actx.currentTime + 0.01;
      [1180, 1760].forEach(function(f, i){
        const o = actx.createOscillator(), g = actx.createGain();
        o.type = 'sine'; o.frequency.setValueAtTime(f, t0);
        g.gain.setValueAtTime(0.0001, t0 + i*0.03);
        g.gain.exponentialRampToValueAtTime(0.10, t0 + i*0.03 + 0.008);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + i*0.03 + 0.16);
        o.connect(g); g.connect(duckBus());
        o.start(t0 + i*0.03); o.stop(t0 + i*0.03 + 0.18);
      });
    } catch(e){}
    return;
  }
  try {
    const src = actx.createBufferSource();
    src.buffer = lineBuf;
    const g = actx.createGain();
    const t0 = actx.currentTime + 0.008;
    g.gain.setValueAtTime(0.42, t0);
    src.connect(g); g.connect(duckBus());
    src.start(t0);
  } catch(e){}
}

function hbDecode(){
  if (hbBuf || hbDecoding || hbFailed || !actx) return;
  hbDecoding = true;
  try {
    const b64 = HB_SRC.slice(HB_SRC.indexOf(',') + 1);
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    actx.decodeAudioData(arr.buffer, b => { hbBuf = b; }, () => { hbFailed = true; });
  } catch(e){ hbFailed = true; }
}

function hbPlayAt(seg, when, vol){
  if (!hbBuf || !actx) return;
  try {
    const src = actx.createBufferSource();
    src.buffer = hbBuf;
    const g = actx.createGain();
    g.gain.value = vol;
    src.connect(g); g.connect(duckBus());
    src.start(Math.max(when, actx.currentTime), seg[0], seg[1] - seg[0]);
  } catch(e){}
}

function hbHum(k3, t){
  t = (t === undefined) ? tense : t;
  if (!actx) return;
  if (k3 <= 0.02){
    if (hbHumGain){ try { hbHumGain.gain.value = 0; } catch(e){} }
    return;
  }
  if (!hbHumOsc){
    try {
      hbHumOsc = actx.createOscillator();
      hbHumOsc.type = 'sine'; hbHumOsc.frequency.value = 47;
      hbHumGain = actx.createGain(); hbHumGain.gain.value = 0;
      const o2 = actx.createOscillator();
      o2.type = 'sine'; o2.frequency.value = 94;
      const g2 = actx.createGain(); g2.gain.value = 0.32;
      o2.connect(g2); g2.connect(hbHumGain);
      hbHumOsc.connect(hbHumGain); hbHumGain.connect(duckBus());
      hbHumOsc.start(); o2.start();
    } catch(e){ hbHumOsc = null; return; }
  }
  hbHumGain.gain.value = 0.055*k3*(0.30 + 0.70*clamp(t,0,1))*(0.80 + 0.20*Math.sin(uiT*2.4));
}

function lowHpUpdate(dt){
  /* 第四关：抓到就死，血量没意义，心跳完全交给"猎手离你多远" */
  if (LEVELS[levelIdx] && LEVELS[levelIdx].boss){ lowHpBoss(dt); return; }
  const L = hpLevels();
  hpFx = L;
  /* 紧张度：被追时冲上去，脱战后慢慢掉下来。
     血量低的心跳不会消失，但会明显变慢变轻 —— 有压迫，不烦人。 */
  const t = clamp(tense, 0, 1);
  const lowK = L.k2;
  const on = lowK > 0.001 || t > 0.12;
  hbSampleOn = on;
  if (on && actx && !hbFailed){
    hbDecode();
    hbBpm = clamp(52 + 26*lowK + t*(64 + 12*lowK), 46, 148);
    const period = 60/hbBpm;
    hbBeatClock += dt;
    if (hbBeatClock >= period){
      hbBeatClock -= period;
      hbLastHit = 0;
      const vol = clamp(0.10 + 0.20*lowK + t*(0.26 + 0.22*lowK), 0, 0.82);
      const t0 = actx.currentTime + 0.012;
      hbPlayAt(HB_LUB, t0, vol);
      hbPlayAt(HB_DUB, t0 + Math.min(0.238, period*0.26), vol*0.60);
    }
  } else {
    hbBeatClock = 0;
  }
  hbLastHit += dt;
  hbHum(L.k3, t);
}

/* 离开战斗：立刻收声，血回来了也立刻恢复（hpFx 每帧按当前血量重算） */
function lowHpStop(){
  hpFx = {f:1, k1:0, k2:0, k3:0};
  tense = 0; hbSampleOn = false;
  hbBeatClock = 0; hbLastHit = 99;
  if (hbHumGain){ try { hbHumGain.gain.value = 0; } catch(e){} }
}

function heartbeat(vol){
  thump(vol, 74, 30);
  setTimeout(()=>thump(vol*0.62, 64, 26), 168);
  setTimeout(()=>thump(vol*0.30, 54, 22), 302);
}

const sfxThrow = ()=> beep(220,0.12,'triangle',0.04,90);
const sfxPop   = ()=> beep(150,0.4,'sawtooth',0.05,55);
/* 通用拾取音：有录音就放录音，没解出来才退回原来的电子"叮咚" */
const sfxPick  = ()=>{ if (typeof sfxPickupGeneric === 'function' && sfxPickupGeneric()) return; beep(880,0.09,'square',0.05); setTimeout(()=>beep(1320,0.09,'square',0.05),70); };
const sfxShot  = ()=> beep(420,0.05,'square',0.035,120);
const sfxHurt  = ()=> beep(90,0.14,'sawtooth',0.07,45);
let lastAlarmAt = -99;
const sfxAlarm = ()=>{
  /* 同一时间只许有一个警报在响：一组人同时喊、连着触发冲锋都会走到这里，
     不去重的话就会叠成一片一直叫 */
  if (uiT - lastAlarmAt < 2.5) return;
  lastAlarmAt = uiT;
  beep(660,0.14,'square',0.05); setTimeout(()=>beep(520,0.18,'square',0.05),140);
};
const sfxWin   = ()=> [523,659,784,1046].forEach((f,i)=>setTimeout(()=>beep(f,0.18,'triangle',0.06),i*130));
const sfxLose  = ()=> [400,300,220,150].forEach((f,i)=>setTimeout(()=>beep(f,0.25,'sawtooth',0.06),i*160));

/* ---------------- 按键绑定 ----------------
   局内能改的键都在这张表里。改完存 localStorage，下次打开还在。
   鼠标左键开枪不给改：那是"瞄准即开火"的一部分，不是快捷键。 */
const BIND_DEF = {}, BIND_NAME = {}, BIND_ORDER = [];
const BIND_ROWS = {};
const _customBindRows = DataBINDINGS.filter(b => b && b.grp === 'custom' && b.bindAction)
  .slice().sort((a, b) => a.order - b.order);
for (const b of _customBindRows){
  BIND_ORDER.push(b.bindAction);
  BIND_ROWS[b.bindAction] = b;
  BIND_DEF[b.bindAction] = b.key;
  BIND_NAME[b.bindAction] = b.label;
}
let BINDS = Object.assign({}, BIND_DEF);
let bindTarget = null;      /* 正在等玩家按键的那一条 */

function keyLabel(code){
  if (!code) return '—';
  if (Array.isArray(code)) return code.map(keyLabel).join(' + ');
  const map = {
    mouse0:'鼠标左键', mouse1:'鼠标中键', mouse2:'鼠标右键', mouse3:'鼠标侧键 1', mouse4:'鼠标侧键 2',
    Space:'空格', Tab:'Tab', Escape:'Esc', Enter:'回车', Backspace:'退格',
    ShiftLeft:'左 Shift', ShiftRight:'右 Shift', ControlLeft:'左 Ctrl', ControlRight:'右 Ctrl',
    AltLeft:'左 Alt', AltRight:'右 Alt', CapsLock:'Caps',
    ArrowUp:'↑', ArrowDown:'↓', ArrowLeft:'←', ArrowRight:'→',
    Backquote:'`', Minus:'-', Equal:'=', BracketLeft:'[', BracketRight:']',
    Semicolon:';', Quote:"'", Comma:',', Period:'.', Slash:'/', Backslash:'\\'
  };
  if (map[code]) return map[code];
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code.startsWith('Numpad')) return '小键盘 ' + code.slice(6);
  return code;
}
function loadBinds(){
  try {
    const s = JSON.parse(localStorage.getItem('after5_binds') || 'null');
    if (s && typeof s === 'object'){
      for (const k of BIND_ORDER) if (bindValidValue(BIND_ROWS[k], s[k])) BINDS[k] = s[k];
    }
  } catch(e){}
}
function saveBinds(){
  try { localStorage.setItem('after5_binds', JSON.stringify(BINDS)); } catch(e){}
}
function resetBinds(){
  BINDS = Object.assign({}, BIND_DEF); saveBinds();
}

/* ---------------- 输入 ---------------- */
/* 会被浏览器抢走的键：滚页面、跳焦点、后退、刷新、帮助、全屏……全挡住 */
const KEY_NO_DEFAULT = ['Space', 'Tab', 'Backspace', 'Enter', 'NumpadEnter',
                        'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight',
                        'PageUp', 'PageDown', 'Home', 'End', 'Insert',
                        'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F10'];
const keys = {};
/* 右键在游戏里要用来干别的事，别弹系统菜单，也别触发选中文本 */
addEventListener('contextmenu', e=>{ e.preventDefault(); });
addEventListener('dragstart', e=>{ e.preventDefault(); });

/* 输入层级：返回"盖在游戏最上面"的那层界面（null = 没界面，纯游戏输入）。
   原则：最上面那层先吃键，吃到了下面的层一律不许再处理。
   顺序就是视觉上的上下关系：割草洗牌 > 死亡看画面 > 死亡页 > 等按键绑定 > 抽卡展示
   > 回大厅确认 > 设置面板 > 日志 > 地图 > 背包。 */
function uiTopLayer(){
  if (ar && ar.er && ar.er.stage) return 'er';
  if (ar && ar.shuf) return 'shuffle';
  if (deathView) return 'deathview';
  if (state === 'dead') return 'dead';
  if (bindTarget) return 'bind';
  if (ar && ar.drawShow && !ar.drawShow.closed) return 'drawshow';
  if (confirmBack) return 'confirm';
  if (typeof devGateAsk !== 'undefined' && devGateAsk) return 'devgate';
  /* m35424：仓库面板也是最上层弹窗，键鼠必须先到它（否则会点到下面那层的按钮） */
  if (typeof stashUI !== 'undefined' && stashUI && stashUI.open) return 'stash';
  if (panelOpen()) return 'panel';
  if (logOpen) return 'log';
  if (mapOpen) return 'map';
  if (ui.inv.open) return 'inv';
  if (GACHA.open) return 'gacha';
  return null;
}
/* 有界面盖着的时候，游戏内的按键（开枪/换弹/吃药/换枪/丢枪/烟雾）一律不吃 */
function uiBlocksGameplay(){ return uiTopLayer() !== null; }

function companionMouse(ev){
  const modifier=!!keys[BINDS.commandModifier]||
    (BINDS.commandModifier==='AltLeft'&&ev.altKey)||(BINDS.commandModifier==='AltRight'&&ev.altKey);
  const requested=ev.button===2||(ev.button===0&&modifier);
  if(!requested)return false;
  if(state!=='play'||bindTarget||devSpawnOpen||arenaSlotUI||ar&&(ar.freeze||ar.choices||ar.shuf))return false;
  /* m44040：投放模式 / 指挥层拿着右键时，右键归它们（否则"右键退出投放"会被这里吃掉，
     弹出"当前没有可指挥的队友"，投放模式根本退不出去）。 */
  if(typeof devPlaceKind!=='undefined'&&devPlaceKind)return false;
  /* m20386：布设绊雷时右键归布设取消，别弹"当前没有可指挥的队友" */
  if(typeof player!=='undefined'&&player&&player.tripPhase)return false;
  if(typeof devItemOpen!=='undefined'&&devItemOpen)return false;
  if(paused){ev.preventDefault();mouse.fire=false;mouse.down=false;return true;}
  const layer=uiTopLayer();
  if(layer&&layer!=='map')return false;
  const button=uiHit(mouse.x,mouse.y);
  if(button&&button.overlay)return false;
  // Command clicks never reach weapon or item pickup handlers, including with no allies.
  ev.preventDefault();mouse.fire=false;mouse.down=false;
  if(ev.button===2&&!companionMouseMode){ if(player&&player.tripPhase) return false; return true; }
  if(!allies.some(a=>!a.dead&&a.hp>0)){setMsg('当前没有可指挥的队友',1.5);return true;}
  const p=screenToWorld(mouse.x,mouse.y,mapOpen),L=cur();
  if(!p||p.x<0||p.y<0||p.x>L.w||p.y>L.h)return true;
  let target=null,best=Infinity;
  if(ev.button===2)for(const e of enemies){
    if(e.dead||e.hp<=0||!combatHostile(player,e)||!renderPlayerSees(e))continue;
    if(nightDark()&&flashK<.18&&dist(player.x,player.y,e.x,e.y)>(L.rules.nightR||0)+26&&!companionSharedSees(e))continue;
    const d=dist(e.x,e.y,p.x,p.y),hit=Math.max((e.r||12)+10,mapOpen?10/mapView.k:22);
    if(d<=hit&&d<best){target=e;best=d;}
  }
  if(target){companionCommand('focus',p,target);}
  else{
    const e=allies.find(a=>!a.dead&&a.hp>0);
    if(!bladeWalkLine(L,e.r,p.x,p.y,p.x,p.y)){setMsg('这个位置有障碍，请选择旁边空地',1.5);return true;}
    companionCommand('move',p,null,{arrivalHold:true});
    setMsg('队友前往并坚守标记',1.5);
  }
  companionOrderMarker={x:target?target.x:p.x,y:target?target.y:p.y,targetId:target?combatId(target):null,at:uiT,until:uiT+4};
  return true;
}
function companionKey(ev){
  if(ui.inv.open&&ui.inv.companion&&ev.code==='KeyR'){ev.preventDefault();return true;}
  if(state==='play'&&!paused&&!bindTarget&&(!uiBlocksGameplay()||uiTopLayer()==='map')&&ev.code===BINDS.commandMode){
    ev.preventDefault();if(!ev.repeat){companionMouseMode=!companionMouseMode;mouse.down=false;mouse.fire=false;setMsg('鼠标右键指挥'+(companionMouseMode?'已开启':'已关闭'),1.5);}return true;
  }
  if(ev.code===BINDS.commandModifier&&state==='play'&&!bindTarget&&(!uiBlocksGameplay()||uiTopLayer()==='map')){
    ev.preventDefault();keys[ev.code]=true;return true;
  }
  if(state!=='play'||paused||uiBlocksGameplay()||bindTarget||ev.repeat)return false;
  if(ev.code==='F6'&&isTestZone()){
    ev.preventDefault();companionSpawn();setMsg('队友已加入 · 右键点地坚守 / 点敌集火 · F7 跟随',3);return true;
  }
  const type={F7:'follow',F8:'hold',F9:'move',F10:'focus'}[ev.code];
  if(!type||!allies.length)return false;
  ev.preventDefault();const point=screenToWorld(mouse.x,mouse.y);
  let target=null;
  if(type==='focus'){
    let best=90;
    for(const e of enemies)if(!e.dead&&dist(e.x,e.y,point.x,point.y)<best){target=e;best=dist(e.x,e.y,point.x,point.y);}
    if(!target){setMsg('请把鼠标指向敌人，再按 F10',1.5);return true;}
  }
  companionCommand(type,point,target);return true;
}

/* 快捷整理与键位捕获先于同一个键的单键行为。 */
function bindPriorityKeyDown(e){
  bindHeldKeys.add(e.code);
  if (bindCapturePress(e.code, e)) return true;
  if (bindSwallowedKeys.has(e.code)){ bindConsumeInput(e); return true; }
  return bindInventoryKeyDown(e, false);
}
function handleGameKeyDown(e, singleOnly = false){
  devGateTick();
  if (singleOnly ? bindInventoryKeyDown(e, true) : bindPriorityKeyDown(e)) return;
  /* F8：输入审计面板（绑定冲突 + 最近一次输入被谁接走）。放最前面，免得被别的键吃掉 */
  if (typeof bindKeyHook === 'function' && bindKeyHook(e)) return;
  if (typeof bindStamp === 'function') bindStamp('key', e.code || e.key || '?');
  /* F9：拍照模式，把这一层 UI 全藏掉（在别的按键之前拦，免得被别的东西吃掉） */
  if (e.code === BINDS.hideHud && !e.repeat){ if (typeof uiHideToggle === 'function') uiHideToggle(); e.preventDefault(); return; }
  /* m35424：最上层弹窗（仓库 / 抽卡 / 展示）必须先吃键。
     否则在选图页/娱乐页开着仓库时按 Esc，会先被下面的菜单快捷键抢走，
     仓库就留在屏幕上继续盖着（用户报的复现路径）。 */
  if (typeof stashUI !== 'undefined' && stashUI.open && typeof stashKey === 'function'){ if (stashKey(e)) return; }
  if (ar && ar.er && ar.er.stage && typeof erKey === 'function'){ if (erKey(e)) return; }
  if (ar && ar.drawShow && !ar.drawShow.closed){ if (ar.drawShow.t > 0.12) closeDrawShow(); e.preventDefault(); return; }
  /* 娱乐模式菜单的键盘兜底：鼠标点不到时也能进（D 进死亡地带，C 切经典/随机） */
  if (state === 'dzpick'){
    if (e.code === BINDS.pause){ e.preventDefault(); state = 'arcade'; return; }
  }
  if (state === 'arcade'){
    if (e.code === 'KeyD'){ e.preventDefault(); state = 'dzpick'; return; }
    if (e.code === 'KeyC'){ e.preventDefault(); dzMapMode = (dzMapMode === 'random' ? 'classic' : 'random'); return; }
    if (e.code === BINDS.pause){ e.preventDefault(); goMenu(); return; }
  }
  if (arenaSaveHandleKey(e)) return;
  if (companionKey(e)) return;
  /* 老实抽卡：弹窗开着时它先吃键（摇奖/选卡/结果） */
  /* 洗牌界面：上下键翻页；这个界面不能退，Esc 也吞掉 */
  if (ar && ar.shuf){
    if (e.key === 'ArrowDown' || e.key === 'PageDown'){ e.preventDefault(); shuffleScroll(1); return; }
    if (e.key === 'ArrowUp'   || e.key === 'PageUp'){ e.preventDefault(); shuffleScroll(-1); return; }
    if (e.key === 'Escape'){ e.preventDefault(); return; }
  }
  /* 死亡后的“先看画面”阶段：任意键进入结算 */
  if (deathView){ deathView = false; e.preventDefault(); return; }
  /* 死亡页最高优先级：R 回放 / Esc 结算，别的键一律不动，别被下面那些层截胡 */
  if (state === 'dead'){
    if (e.code === BINDS.pause){ e.preventDefault(); leaveDead(); return; }
    if (e.code === 'KeyR'){ e.preventDefault(); startGreplay('dead'); return; }
    if (e.code === 'KeyV'){ e.preventDefault(); startReplay(); return; }
    return;
  }
  /* 有界面盖在游戏上的时候，下面所有"局内动作"都不许吃键 */
  const _uiBlocked = uiBlocksGameplay();
  /* 这是个浏览器里的游戏：这些键要吃掉浏览器的默认行为，
     不然空格/方向键滚页面、Tab 跳焦点、Backspace 后退、F5 刷新，一按就出事。
     焦点在输入框/滑块上时放行，别把设置面板的正常操作也堵死。 */
  const _tgt = e.target;
  const _inField = _tgt && (_tgt.tagName === 'INPUT' || _tgt.tagName === 'TEXTAREA' ||
                            _tgt.tagName === 'SELECT' || _tgt.isContentEditable);
  if (!_inField){
    if (KEY_NO_DEFAULT.indexOf(e.code) >= 0) e.preventDefault();
    /* Ctrl+R / Ctrl+P 这类一按就重置画面的也挡掉（Ctrl+Shift+I 留给调开发者工具） */
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (e.code === 'KeyR' || e.code === 'KeyP')) e.preventDefault();
  }
  /* F3：帧时间自检，什么时候都能开，不影响存档 */
  if (ar && ar.freeze && state === 'play' && (e.code === 'Digit1' || e.code === 'Digit2' || e.code === 'Digit3')){
    e.preventDefault(); arenaArm(+e.code.slice(5) - 1); return;
  }
  /* 割草专用：N 催场（把下一波也叫上来）。加成一览在 Esc 暂停里看，别在交火中开面板 */
  if (ar && state === 'play' && !ar.freeze && e.code === 'KeyN'){ e.preventDefault(); arenaCallNext(); return; }
  if (e.code === BINDS.perf){ perfOn = !perfOn; if (perfOn && typeof perfLongInstall === 'function') perfLongInstall(); e.preventDefault(); return; }
  /* B：局内直接切难度（测试区 / 割草 / 斗蛐蛐观战图都行，正式关卡不算成绩） */
  if (!_uiBlocked && e.code === 'KeyB' && state === 'play' &&
      (isTestZone() || (ar && CFG.dev) || (typeof cricketOn === 'function' && cricketOn()))){
    const order = DIFF_ORDER;
    const cur = order.indexOf(diffName);
    const next = order[(cur < 0 ? 1 : cur + 1) % order.length];
    applyPreset(next, true);
    setMsg('难度 → ' + (DIFF_LABEL)[next] +
           '　敌人子弹 ' + Math.round(CFG.bulletSpd) + ' px/s', 2.6);
    return;
  }
  if (!uiBlocksGameplay()) keys[e.code] = true;
  if (state === 'select' && (e.code === 'ArrowLeft' || e.code === 'ArrowRight')){
    const ci = Math.max(0, CHAPTERS.findIndex(c => c.n === selChapter));
    const n = CHAPTERS.length;
    if (n > 1){
      const ni = (ci + (e.code === 'ArrowRight' ? 1 : -1) + n) % n;
      selChapter = CHAPTERS[ni].n;
    }
    return;
  }
  if (state === 'greplay'){
    if (e.code === BINDS.pause){ exitGreplay(); return; }
    if (e.code === 'Space'){ gPlaying = !gPlaying; if (gPlaying && gT >= vrecDur()) gT = vrecStart(); return; }
    if (e.code === 'ArrowLeft'){ gT = Math.max(vrecStart(), gT - 1); gPlaying = false; return; }
    if (e.code === 'ArrowRight'){ gT = Math.min(vrecDur(), gT + 1); gPlaying = false; return; }
    if (e.code === 'KeyU'){ gXray = !gXray; return; }
    if (e.code === 'Equal' || e.code === 'NumpadAdd'){ gZoom = clamp(gZoom*1.25, 0.12, 3.2); return; }
    if (e.code === 'Minus' || e.code === 'NumpadSubtract'){ gZoom = clamp(gZoom/1.25, 0.12, 3.2); return; }
    if (e.code === 'KeyR'){ gT = vrecStart(); gPlaying = true; gAutoCam = true; return; }
    if (e.code === 'KeyF'){ gAutoCam = true; return; }
    return;
  }
  if (e.code === BINDS.pause && state === 'replay'){ toDeadFrame(true); return; }
  if (state === 'replay') return;   /* 回放里别的键不推进，免得手滑刷过去（死亡页已在上面统一拦掉） */
  if (state === 'intro'){ introAdvance(); return; }
  if (e.code === 'KeyL'){ toggleLog(); return; }
  if (e.code === BINDS.pause && codexOpen){ toggleCodex(false); return; }
  if (e.code === BINDS.codex && state === 'play'){ e.preventDefault(); toggleCodex(); return; }
  if (codexOpen && !_inField){
    if (e.code === 'ArrowRight'){ codexPage++; e.preventDefault(); return; }
    if (e.code === 'ArrowLeft'){ codexPage = Math.max(0, codexPage - 1); e.preventDefault(); return; }
    return;
  }
  /* 开发者确认框挡在最前面：它开着的时候 Y/Enter = 开、N/Esc = 关，其它键一律不吃 */
  if (typeof devGateAsk !== 'undefined' && devGateAsk){
    if (e.code === 'KeyY' || e.code === 'Enter' || e.code === 'NumpadEnter'){ e.preventDefault(); devGateAnswer(true); return; }
    if (e.code === 'KeyN' || e.code === 'Escape'){ e.preventDefault(); devGateAnswer(false); return; }
    return;
  }
  if (e.code === BINDS.pause && logOpen){ toggleLog(false); return; }
  if (e.code === BINDS.panel || e.code === 'KeyO'){ togglePanel(); return; }
  if (e.code === BINDS.pause && confirmBack){ confirmBack = false; logInfo('ui', '取消回大厅，继续本局'); return; }
  if (e.code === BINDS.pause && state === 'play' && !(player && player.tripPhase)){
    /* 开发面板/放置模式只是工具层，不该吃掉 ESC —— 先收掉它们再照常弹暂停层 */
    if (CFG.dev){
      if (devPlaceKind) devPlaceCancel();
      if (devSpawnOpen) devSpawnOpen = false;
    }
    /* 背包是最上面一层，Esc 先关它 —— 否则会连着弹出暂停层，两层叠在一起点不动 */
    if (ui.inv.open){ inventoryClose(); e.preventDefault(); return; }
    if (typeof GACHA !== 'undefined' && GACHA.open){
      /* 转盘转着的时候关不掉：gachaClose 返回 false 就当我们没处理，别把面板直接抹掉 */
      if (gachaClose() !== false){ e.preventDefault(); return; }
      e.preventDefault(); return;
    }
    if (panelOpen()){ togglePanel(false); return; }
    if (mapOpen){ mapOpen = false; return; }
    confirmBack = true; logInfo('ui', '暂停 · 询问是否回大厅'); return;
  }
  if (e.code === 'KeyR' && (state === 'win' || state === 'clear')){ startGreplay(); return; }
  if (e.code === 'KeyR' && state === 'lose'){ startGreplay('lose'); return; }
  if (e.code === BINDS.map && (state==='play')){
    /* 这一关故意不给地图：迷宫里有地图就等于把答案印在卷子上，
       只留一个大概方向的箭头（drawGuideArrow） */
    if (!mapOpen){ inventoryClose(); logOpen = false; if (panelOpen()) togglePanel(false); }
    mapOpen = !mapOpen; return;
  }
  if (!_uiBlocked && e.code === 'KeyK' && state === 'play' && CFG.dev){
    /* K 先管假人：场上只要有假人，就清假人；没有才走原来的"处决" */
    if (devClearDummies()) return;
    devKillAll(); return;
  }
  if (!_uiBlocked && e.code === 'KeyI' && state === 'play' && CFG.dev){ devToggleSandbox(); return; }
  if (!_uiBlocked && e.code === 'KeyN' && state === 'play' && CFG.dev){ if (e.shiftKey) devToggleNoHealCd(); else devToggleInfAmmo(); return; }
  if (!_uiBlocked && e.code === 'KeyZ' && state === 'play' && CFG.dev){ devToggleInfMed(); return; }
  /* 刷物资：一圈药/弹药/枪/防弹衣直接撒在脚边（测试区专用，正式关不接） */
  if (!_uiBlocked && e.code === 'KeyV' && state === 'play' && CFG.dev){
    /* V = 打开"刷物资"面板（分组 + 数量）；Shift+V 还是全套甲；Ctrl+V 一次全撒 */
    if (e.shiftKey){ giveEliteArmor(); return; }
    if (e.ctrlKey){ devDropLoot(); return; }
    devItemOpen = !devItemOpen;
    devItemSel = 0; devItemQty = 1;
    setMsg(devItemOpen ? '刷物资面板：选好数量再投放' : '关掉刷物资面板', 1.4);
    return;
  }
  if (state === 'play' && !_uiBlocked && !_inField){
    /* Q：拿着盾 = 丢下（带着剩余耐久），没盾 = 捡起脚边那面；所有关卡都能用 */
    /* Q：拿盾时 = 收盾切枪（不再丢地上）；空手且脚边有盾 = 捡起来 */
    if (e.code === BINDS.shieldDrop && player.hasShield){
      e.preventDefault();
      if (!e.repeat){
        if (player.shieldRaised || mouse.fire || mouse.down){
          /* 举着盾按 Q = 收盾并切到下一把枪（真的换枪，不只是把盾放下） */
          switchWeapon(1);
        } else {
          player.shieldRaised = true; mouse.fire = false; mouse.down = false;
          setMsg('举盾 · 正面挡弹 · Q 收盾切枪 / G 收起', 1.5);
        }
      }
      return;
    }
    if (e.code === BINDS.shieldDrop && shieldLootNear()){
      e.preventDefault(); if (!e.repeat) dropPlayerShield(); return;
    }
    if (e.code === BINDS.shield && player.hasShield){
      e.preventDefault();if (!e.repeat) togglePlayerShield();return;
    }
    /* E：一个键三用 —— 正在搜就取消；身边有箱子/门就按最近的来；都不是才捡脚边的东西。
       之前 E 只接了 pickNearestLoot，结果搜刮永远走不到（按了只提示"附近没有战利品"）。 */
    if (e.code === 'KeyE' && !ui.inv.open){
      e.preventDefault();
      if (!e.repeat){
        if (player.mgNest){ dismountMgNest(); }
        else if (typeof towerSeat !== 'undefined' && towerSeat){ leaveTower(); }
        else if (crateSearch){ cancelSearch('手停了 —— 搜刮中断'); }
        else if (player.seat){ standUp(); }
        else {
          const _tr = (typeof traderNear === 'function') ? traderNear(72) : null;
          if (_tr){ gachaOpen(); return; }
          const _it = nearestInteract();
          if (_it && _it.k === 'crate') trySearchCrate();
          else if (_it && _it.k === 'pile') trySearchPile(_it.o);
          else if (_it && _it.k === 'door') toggleDoor(_it.o);
          else {
            const _mg = mgNestNear();
            if (_mg) mountMgNest(_mg);
            else {
              /* 瞭望塔：塔脚下按 E 爬上去（比箱子/椅子优先，塔是立在那儿的大件） */
              const _tw = (typeof towerNear === 'function') ? towerNear() : null;
              if (_tw){ climbTower(_tw); return; }
              const _st2 = (typeof seatNear === 'function') ? seatNear(46) : null;
              if (_st2) sitDown(_st2); else pickNearestLoot();
            }
          }
        }
      }
      return;
    }
  }
  if (e.code === 'KeyJ' && state === 'play' && CFG.dev){
    if (devPlaceKind){ devPlaceCancel(); devSpawnOpen = true; return; }
    devSpawnOpen = !devSpawnOpen;
    setMsg(devSpawnOpen ? '选一个种类投下去 · 数字键' : '关掉投放面板', 1.4);
    return;
  }
  if (devPlaceKind && state === 'play' && CFG.dev && e.code === 'Escape'){ devPlaceCancel(); return; }
  if (devItemOpen && state === 'play' && CFG.dev){
    if (e.code === 'Escape'){ devItemOpen = false; return; }
    if (e.code === 'KeyA' || e.code === 'ArrowLeft'){ devItemGroupStep(-1); e.preventDefault(); return; }
    if (e.code === 'KeyD' || e.code === 'ArrowRight'){ devItemGroupStep(1); e.preventDefault(); return; }
    if (e.code === 'KeyW' || e.code === 'ArrowUp'){ devItemStep(-1); e.preventDefault(); return; }
    if (e.code === 'KeyS' || e.code === 'ArrowDown'){ devItemStep(1); e.preventDefault(); return; }
    if (e.code === 'KeyZ'){ devItemQtyStep(-1); return; }
    if (e.code === 'KeyX'){ devItemQtyStep(1); return; }
    if (e.code === 'Enter' || e.code === 'NumpadEnter'){ devItemFire(); return; }
    const _im = /^Digit([1-9])$/.exec(e.code);
    if (_im){
      const _i2 = (+_im[1]) - 1, _g2 = devItemGroupDef();
      if (_g2.items[_i2]){ devItemSel = _i2; devItemFire(); }
      e.preventDefault(); return;
    }
  }
  /* 放置模式：`[` / `]` 转朝向（m43322）；不在放置模式时，它拿来调"指挥多少秒到达"（m43351） */
  if (state === 'play' && CFG.dev && (e.code === 'BracketLeft' || e.code === 'BracketRight')){
    const _dir = (e.code === 'BracketRight' ? 1 : -1);
    if (devPlaceKind){
      devPlaceRotate(_dir * (e.shiftKey ? 5 : 15) * Math.PI / 180);
      e.preventDefault(); return;
    }
    if (typeof devOrd !== 'undefined' && devOrd.on){
      devOrdSecStep(_dir);
      e.preventDefault(); return;
    }
  }
  if (devSpawnOpen && state === 'play' && CFG.dev){
    if (e.code === 'Escape'){ devSpawnOpen = false; return; }
    if (e.code === 'BracketLeft'){ devGroupStep(-1); e.preventDefault(); return; }
    if (e.code === 'BracketRight'){ devGroupStep(1); e.preventDefault(); return; }
    const _dm = /^Digit([0-9])$/.exec(e.code);
    if (_dm){
      const _num = (+_dm[1]) === 0 ? 10 : (+_dm[1]);      /* 10 号用 0 键 */
      const _g = DEV_SPAWN_GROUPS[devGroupIx] || DEV_SPAWN_GROUPS[0];
      const _it = _g.items[_num - 1];
      if (_it){
        devSpawnKind(_it.k, devMouseWorld(), _it.fac || null);
        if (!DEV_INSTANT[_it.k]) devPlaceKind = _it.k;       /* 接着点地图就能连放 */
        /* 切阵营只是个开关：面板留着，方便马上接着放兵 */
        if (_it.k !== 'playerFaction') devSpawnOpen = false;
        e.preventDefault(); return;
      }
    }
  }
  if (!_uiBlocked && e.code === 'KeyY' && state === 'play' && CFG.dev){ devPullAll(); return; }
  if (!_uiBlocked && e.code === 'KeyP' && state === 'play' && CFG.dev && !e.ctrlKey && !e.metaKey){
    if (e.shiftKey) devCycleTime(); else devToggleFreeze();
    return;
  }
  if (!_uiBlocked && e.code === 'KeyU' && state === 'play' && CFG.dev){ devToggleXray(); return; }
  if (!_uiBlocked && e.code === 'KeyC' && state === 'play' && CFG.dev){ weatherCycle(); e.preventDefault(); return; }
  if ((e.code === 'F2' || e.key === 'F2') && ar && state === 'play' && CFG.dev){
    ar.devOpen = !ar.devOpen;
    if (ar.devOpen) ar.devTarget = Math.min(300, (ar.wave | 0) + 10);
    return;
  }
  /* ---- 层级闸门：只要有任何界面盖在游戏上，局内动作键全部让路 ---- */
  /* 3 = 投掷物栏（手雷/烟雾弹）和枪之间来回切；Q = 手雷 ↔ 烟雾弹 */
  if (state === 'play' && !_uiBlocked && e.code === BINDS.throwToggle){ nadeHoldToggle(); return; }
  if (state === 'play' && !_uiBlocked && e.code === BINDS.throwSwap){ handSwapKind(); return; }
  if (state === 'play' && hasFeat('guns')){
    if (!_uiBlocked && e.code === BINDS.swap){ switchWeapon(e.shiftKey ? -1 : 1); return; }
    if (!_uiBlocked && e.code === BINDS.reload){ reloadGun(); return; }
    if (!_uiBlocked && e.code === BINDS.medSmall){ useMed('small'); return; }
    if (!_uiBlocked && e.code === BINDS.medBig){ useMed('big'); return; }
    if (!_uiBlocked && e.code === BINDS.interact){                      /* 换过键也一样：下塔 → 搜刮 → 翻堆 → 开关门 → 坐椅子 → 捡东西 */
      if (typeof towerSeat !== 'undefined' && towerSeat){ leaveTower(); }
      else if (crateSearch){ cancelSearch('手停了 —— 搜刮中断'); }
      else if (player.seat){ standUp(); }
      else {
        const _it2 = nearestInteract();
        if (_it2 && _it2.k === 'crate') trySearchCrate();
        else if (_it2 && _it2.k === 'pile') trySearchPile(_it2.o);
        else if (_it2 && _it2.k === 'door') toggleDoor(_it2.o);
        else {
          const _tw2 = (typeof towerNear === 'function') ? towerNear() : null;
          if (_tw2){ climbTower(_tw2); }
          else {
            const _st = (typeof seatNear === 'function') ? seatNear(46) : null;
            if (_st) sitDown(_st); else pickNearestLoot();
          }
        }
      }
      return;
    }
    if (!_uiBlocked && e.code === BINDS.cancel){ cancelHeal(); if (typeof heatCellCancel === 'function') heatCellCancel(); return; }
    if (!_uiBlocked && e.code === BINDS.drop){ dropGun(); return; }
  /* T：上车 / 下车（附近有能开的车才上车） */
  if (!_uiBlocked && e.code === BINDS.truckSeat && state === 'play'){
    toggleTruckSeat(); return;
  }
    if (e.code === BINDS.bag){
      e.preventDefault();
      /* 暂停 / 地图 / 日志 / 回大厅确认 开着时，Tab 只负责把背包收起来。
         以前这里能把背包叠在暂停层上，两层同时存在 → 点谁都没反应。 */
      if (!ui.inv.open && confirmBack) return;
      /* 开背包顺手把其它界面收掉，避免两层叠着谁也点不动 */
      if (!ui.inv.open){ mapOpen = false; logOpen = false; if (panelOpen()) togglePanel(false); }
      /* 面板画不出来的时候就别开 —— 割草模式没有背包界面、老关卡没有药品系统。
         以前这里能开出一个看不见的背包：ui.inv.open 变 true，却什么都没画出来，
         点击和按键全被它吃掉，玩家只觉得"按键点不动"。 */
      if (!ui.inv.open && (ar || !hasFeat('meds'))) return;
      if (ui.inv.open) inventoryClose();
      else {
        ui.inv.open = true;
        cargoPanelAttach();
        if (bagGridOn()) bagCompactAmmo();
      }
      if (typeof sfxBagSfx === 'function') sfxBagSfx(ui.inv.open);
      return;
    }
  }
  /* 背包开着时 R = 把手上正在拖的 / 鼠标停着的那件转 90° */
  if (e.code === BINDS.pause && player && player.tripPhase && typeof tripCancel === 'function'){
    tripCancel(); return;
  }
  if (ui.inv.open && e.code === 'KeyR'){
    if (!bagGridOn()){ setMsg('这一关的背包是老式的 · 没有格子，转不了', 1.6); return; }
    e.preventDefault();
    if (ui.inv.carry){ inventoryRotateCursor(); return; }
    const _t = (ui.inv.drag && ui.inv.drag.it) || invHoverIt;
    if (_t && bagRotateItem(_t)){
      bagRebuild();
      setMsg('转过来了：' + bagItemLabel(_t) + '（' + _t.w + '×' + _t.h + '）', 1.4);
    } else if (_t){
      setMsg('这里转不开 · 先挪到空一点的地方', 1.6);
    }
    return;
  }
  /* m34881：R 不再重开本局（太容易误触，而且它和换弹抢同一个键）——R 只换弹 */
  if (e.code === BINDS.pause && (state === 'select' || state === 'win' || state === 'lose' || state === 'clear')){
    goMenu(); return;
  }
  if ((e.code==='Space'||e.code==='Enter')){
    if (confirmBack){ confirmBack = false; logInfo('ui', '确认回大厅'); goMenu(); return; }
    if (panelOpen()) return;
    /* m37450：主界面不再用空格/回车直接开局（用户要求去掉这个操作，避免误触直接进关） */
    if (state === 'clear'){ nextLevel(); return; }
    if (state === 'win' || state === 'lose'){ restartRun(); return; }
  }
}
addEventListener('keydown', handleGameKeyDown);
addEventListener('keydown', e=>{
  if (bindTarget || bindSwallowedKeys.has(e.code) || ui.inv.open) bindPriorityKeyDown(e);
}, true);
function handleGameKeyUp(e){
  const code = e.code, pending = bindDeferredKeys.get(code);
  keys[code] = false; bindHeldKeys.delete(code); bindSwallowedKeys.delete(code);
  bindDeferredKeys.delete(code);
  if (bindCaptureRelease(code, e)) return;
  inventoryInputRelease(code, e);
  if (pending && inventoryInputActive()) handleGameKeyDown(pending, true);
}
addEventListener('keyup', handleGameKeyUp);

function toScreen(ev){
  const r = cv.getBoundingClientRect();
  return { x:(ev.clientX-r.left)*(W/r.width), y:(ev.clientY-r.top)*(H/r.height) };
}
/* Canvas coordinates already include CSS scaling through toScreen. */
function screenToWorld(x,y,onMap=false){
  if(onMap){
    if(!mapView||!(mapView.k>0)||cur().rules?.mapBlank)return null;
    return {x:(x-mapView.ox)/mapView.k,y:(y-mapView.oy)/mapView.k};
  }
  if(spectatorViewOn())return cricketMouseWorld(x,y);
  return {x:x+cam.x,y:y+cam.y};
}
cv.addEventListener('mousedown', ev=>{
  /* 触摸板、自动化、窗口尺寸刚变这几种情况下不一定先来一次 mousemove，
     坐标还停在上一次的位置，按钮就会点空：按下的时候顺手同步一次。 */
  if (typeof ev.clientX === 'number'){ const _p = toScreen(ev); mouse.x = _p.x; mouse.y = _p.y; }
  lastShift = !!ev.shiftKey;
  if (ev.button === 1 && ev.preventDefault) ev.preventDefault();   /* 中键别触发浏览器自动滚动 */
  const buttonCode = 'mouse' + ev.button;
  if (typeof bindStamp === 'function') bindStamp('mouse', buttonCode);
  if (inventoryInputActive()){
    const binding = bindInventoryAction(buttonCode, ev, !!inventoryCargoTruck());
    if (bindExecuteInventory(binding, buttonCode, ev)) return;
    if (ui.inv.carry || ui.inv.sweep){ bindConsumeInput(ev); return; }
  }
  /* 斗蛐蛐观战图：底部卡牌 + 点地图投放，优先于其它一切点击（m40173） */
  if (typeof mobaMouseDown === 'function' && mobaMouseDown(mouse.x, mouse.y, ev.button)) return;
  if (typeof cricketMouseDown === 'function' && cricketMouseDown(mouse.x, mouse.y, ev.button)) return;
  devGateTick();
  /* 开发者模式二次确认（死亡地带）：这一层是 canvas 弹窗，普通对局的鼠标逻辑只会开枪，
     所以必须在这里优先把点击交给它的按钮，否则就是"按钮点不动"（用户 m15862）。 */
  if (typeof devGateAsk !== 'undefined' && devGateAsk){
    const _gb = (typeof uiHit === 'function') ? uiHit(mouse.x, mouse.y) : null;
    if (_gb && _gb.fn) _gb.fn();
    return;                      /* 弹窗期间不许开枪 */
  }
  /* 开发者指挥模式：点单位 → 点地点（m42994） */
  if (typeof devOrderMouse === 'function' && devOrderMouse(mouse.x, mouse.y, ev.button)) return;
  if (arenaSaveHandleMouse(ev)) return;
  if (typeof stashUI !== 'undefined' && stashUI.open && typeof stashClick === 'function'){ stashClick(mouse.x, mouse.y); return; }
  if (ar && ar.er && ar.er.stage && typeof erClick === 'function'){ erClick(mouse.x, mouse.y); return; }
  if (deathView){ deathView = false; return; }
  /* 抽奖面板开着：点击交给面板，别打到人。
     但死了/回放/结算时面板必须先让位，否则死亡页的按钮全被它吃掉（用户 m12253）。 */
  /* 背包是后打开的、画在抽奖页上面，这时点击必须先给背包，
     否则会穿到下面的抽奖页（用户 m33403）。 */
  if (typeof GACHA !== 'undefined' && GACHA.open && !ui.inv.open){
    if (state !== 'play'){ gachaClose(); }
    else { audioInit(); gachaClick(mouse.x, mouse.y, ev.button === 2); return; }
  }
  /* 死亡页最高优先级：抽卡 / 选卡 / 编辑器这些层不管开没开，都不能吃掉结算按钮的点击 */
  if (state === 'dead'){
    if (hitDeadBtn(mouse.x, mouse.y, 'replay')){ startGreplay('dead'); return; }
    if (hitDeadBtn(mouse.x, mouse.y, 'last')){ startReplay(); return; }
    if (hitDeadBtn(mouse.x, mouse.y, 'settle')){ leaveDead(); return; }
    return;
  }
  if (state === 'editor'){
    const eb = uiHit(mouse.x, mouse.y);
    if (eb && eb.fn){ eb.fn(); return; }
    const cell = edCellFromMouse(mouse.x, mouse.y);
    if (cell){ edSnap(); edPaint(cell.c, cell.r); ED.painting = true; }
    return;
  }
  if (ar && ar.drawShow && !ar.drawShow.closed){
    if (ar.drawShow.t > 0.12) closeDrawShow();   /* 翻牌时点一下就是"继续"，不开枪 */
    return;
  }
  if (ar && (ar.freeze || ar.shuf || ar.choices) && state === 'play'){
    /* 刚弹出来的 420ms 不吃点击：挡住"上一下鼠标还在开枪/切页"的连带点击 */
    if (ar.shuf && ar.shuf.openedAt){
      const _now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
      if (_now - ar.shuf.openedAt < 420) return;
    }
    const ab = uiHit(mouse.x, mouse.y);
    if (ab && ab.fn) ab.fn();
    return;                     /* 选卡 / 洗牌的时候不许开枪 */
  }
  /* 布设绊雷：右键取消 / 左键放点（必须排在 companionMouse 前面，
     否则右键会被"指挥队友"那块先吃掉，看起来就是按了没反应） */
  if (player && player.tripPhase && state === 'play' && !ui.inv.open){
    if (ev.button === 2){ if (typeof tripCancel === 'function') tripCancel(); mouse.down = false; return; }
    if (typeof tripClick === 'function' && tripClick()){ return; }
  }
  if(companionMouse(ev))return;
  audioInit();
  if (state === 'greplay'){
    const gb = uiHit(mouse.x, mouse.y);
    if (gb){ gb.fn(); return; }
    /* 时间轴：点哪跳哪 */
    const x0 = 140, x1 = W - 140, ty = H - 56;
    if (mouse.y > ty - 16 && mouse.y < ty + 16 && mouse.x >= x0 - 10 && mouse.x <= x1 + 10){
      const p = clamp((mouse.x - x0) / (x1 - x0), 0, 1);
      const start = vrecStart();
      gT = start + (vrecDur() - start) * p; gPlaying = false; gAutoCam = false;
      return;
    }
    /* 拖拽平移 */
    gDrag = {sx: mouse.x, sy: mouse.y, cx: gCam.x, cy: gCam.y};
    gAutoCam = false;
    return;
  }
  if (state === 'replay'){ if (hitDeadBtn(mouse.x, mouse.y, 'skip')) toDeadFrame(true); return; }
  if (panelOpen()) return;
  /* 回大厅确认框比背包更高一层：先给它，否则点按钮被背包吃掉 */
  if (confirmBack){ const cb0 = uiHit(mouse.x, mouse.y); if (cb0) uiCall(cb0.fn); return; }
  /* 背包开着的时候：点药品格子 = 直接使用；点在面板外面 = 关掉背包，且这一下继续往下走 */
  if (ui.inv.open){
    if(companionBagClick())return;
    /* ver3：网格背包 —— 按下 = 拿起（拖动）；点在面板外面 = 关掉 */
    if (bagGridOn()){
      const G = invGridGeom;
      if (G){
        const _out = mouse.x < G.px - 4 || mouse.y < G.py - 4 ||
                     mouse.x > G.px + G.pw + 4 || mouse.y > G.py + G.ph + 4;
        if (_out){ inventoryClose(); return; }
        let hit = null;
        for (const r of G.items){
          if (mouse.x >= r.x && mouse.x <= r.x + r.w && mouse.y >= r.y && mouse.y <= r.y + r.h){ hit = r; break; }
        }
        const hitIt = hit && (hit.it || hit);
        if (ev.button !== 0){
          if (ev.button === 2 && hitIt?.k === 'tripwire') tripDisarmStart(hitIt);
          return;
        }
        if (!hit){
          const inRect = (r) => !!r && mouse.x >= r.x && mouse.x <= r.x + r.w && mouse.y >= r.y && mouse.y <= r.y + r.h;
          const ghostAnchor = (w, h) => ({
            x: mouse.x - (w * G.cell + (w - 1) * G.gap) / 2,
            y: mouse.y - (h * G.cell + (h - 1) * G.gap) / 2
          });
          /* 配件小格：点一下就把那件取回背包（枪口 / 弹匣各一个格子） */
          const AS = G.attSlots || [];
          for (let gi = 0; gi < AS.length; gi++){
            const list = AS[gi];
            if (!list || !list.length) continue;
            for (let _k = 0; _k < list.length; _k++){
              const ar0 = list[_k];
              if (!ar0) continue;
              if (mouse.x < ar0.x || mouse.x > ar0.x + ar0.w || mouse.y < ar0.y || mouse.y > ar0.y + ar0.h) continue;
              if (!bagDetachFromGun(gi, ar0.slot)) setMsg('把配件拖到上面这一行 = 装上', 1.7);
              return;
            }
          }
          const GS = G.gunSlots || [];
          for (let gi = 0; gi < GS.length; gi++){
            if (GS[gi] && inRect(GS[gi])){
              const gw = gunSlots()[gi];
              /* 按下先记住：松手时没移动 = 切枪；拖到别的栏 = 换位；拖到面板外 = 丢枪 */
              ui.inv.gunDrag = { from: gi, wid: (gw && player.guns && player.guns[gw]) ? gw : null,
                                 sx: mouse.x, sy: mouse.y };
              return;
            }
          }
          if (player.armor && inRect(G.armSlot)){
            const a0 = ghostAnchor(GRID_W.armor, GRID_H.armor);
            bagDragStart({ it:{ k:'armor', ak:player.armor.kind, hp:player.armor.hp, maxHp:player.armor.maxHp,
                               eq:'armor', uid:-1, w:GRID_W.armor, h:GRID_H.armor },
                           x:a0.x, y:a0.y }, mouse.x, mouse.y); return;
          }
          if (player.bag && player.bag.kind && player.bag.kind !== 'none' && inRect(G.bagSlot)){
            const b0 = ghostAnchor(GRID_W.bag, GRID_H.bag);
            bagDragStart({ it:{ k:'bag', bk:player.bag.kind, eq:'bag', uid:-2, w:GRID_W.bag, h:GRID_H.bag },
                           x:b0.x, y:b0.y }, mouse.x, mouse.y); return;
          }
          if (player.hasShield && inRect(G.shieldSlot)){
            const s0 = ghostAnchor(1, 1);
            bagDragStart({ it:{ k:'shield', eq:'shield', uid:-3, w:1, h:1 },
                           x:s0.x, y:s0.y }, mouse.x, mouse.y); return;
          }
          if (player.heatWorn && inRect(G.heatSlot)){
            const t0 = ghostAnchor(GRID_W.thermal, GRID_H.thermal);
            bagDragStart({ it:{ k:'thermal', eq:'thermal', uid:-4, w:GRID_W.thermal, h:GRID_H.thermal },
                           x:t0.x, y:t0.y }, mouse.x, mouse.y); return;
          }
        }
        const _cgHit = (typeof cargoBagHit === 'function') ? cargoBagHit(mouse.x, mouse.y) : null;
        if (_cgHit){
          ui.inv.drag = { it:_cgHit.c, from:'cargo', cellRec:_cgHit, ox:0, oy:0, sx:mouse.x, sy:mouse.y };
          return;
        }
        if (hit) bagDragStart(hit, mouse.x, mouse.y);
        return;                       /* 面板里面：这一下不往下传（别开枪） */
      }
      return;
    }
    const G = invGeom;
    /* 用的是整块面板的框（连右边的说明栏都算在内），点在面板上什么都不做。
       布局还没算出来（G 为空）就什么也别做 —— 不能凭空白关掉背包。 */
    if (G){
      const _out = mouse.x < G.px - 4 || mouse.y < G.py - 4 ||
                   mouse.x > G.px + G.pw + 4 || mouse.y > G.py + G.ph + 4;
      if (_out) inventoryClose();
    }
  }
  if (ui.inv.open && invGeom){
    const G = invGeom;
    for (let i = 0; i < G.cols * G.rows; i++){
      const cx0 = G.gx + (i % G.cols) * (G.cell + G.gap);
      const cy0 = G.gy + Math.floor(i / G.cols) * (G.cell + G.gap);
      if (mouse.x >= cx0 && mouse.x <= cx0 + G.cell && mouse.y >= cy0 && mouse.y <= cy0 + G.cell){
        const it = G.slots[i];
        if (it && it.kind === 'med') useMed(it.rarity);
        return;
      }
    }
    return;
  }
  /* 暂停/回大厅确认层永远最优先：以前它排在开发面板后面，
     面板开着的时候点"回大厅"会被"点面板外面 = 关面板"吃掉，看起来就是按不动 */
  /* 布设绊雷：左键放点、右键取消（排在开枪之前，别把布点打成开枪） */
  if (player && player.tripPhase && state === 'play' && !ui.inv.open){
    if (ev.button === 2){ if (typeof tripCancel === 'function') tripCancel(); mouse.down = false; return; }
    if (typeof tripClick === 'function' && tripClick()){ return; }
  }
  if (devPlaceKind && CFG.dev && state === 'play'){
    if (ev.button === 2){ devPlaceCancel(); mouse.down = false; return; }
    if (ev.button === 1){ return; }                    /* 中键留给"指挥选中"，别在这一层吃掉 */
    /* 地图开着的时候，鼠标是在"缩小的地图"上，必须按地图的 k / ox / oy 反算，
       否则只能投在镜头附近（远处点半天没反应）。 */
    const _wr = (mapOpen && mapView && typeof screenToWorld === 'function')
      ? screenToWorld(mouse.x, mouse.y, true)
      : devMouseWorld();
    /* m43955：按住 Shift 吸附 20px 网格，一排车/一排兵才能摆齐 */
    const _w = (ev.shiftKey && typeof devPlaceSnap === 'function') ? devPlaceSnap(_wr.x, _wr.y) : _wr;
    const _ok = devSpawnKind(devPlaceKind, _w, devPlaceFac);   /* 点一下放一个，放不下会自己提示 */
    if (typeof bindMark === 'function') bindMark(_ok === false ? 'place-fail' : 'place');
    if (_ok !== false && typeof devPlaceApplyAng === 'function') devPlaceApplyAng(_w.x, _w.y);
    return;
  }
  if (devItemOpen && CFG.dev && state === 'play'){
    if (devItemClick(mouse.x, mouse.y)) return;
  }
  if (devSpawnOpen && CFG.dev && state === 'play'){
    const G = devSpawnPanelGeom();
    const px = G.x, py = G.y, pw = G.w, ph = G.h;
    if (mouse.x > px && mouse.x < px + pw && mouse.y > py && mouse.y < py + ph){
      devPanelPickAt(mouse.x, mouse.y);     /* 只选中 / 切组，不在这一步投放 */
      return;
    }
    devSpawnOpen = false;                  /* 点面板外面 = 关掉 */
  }
  if (state === 'intro'){ audioInit(); introAdvance(); return; }   /* 黑屏剧情里点一下 = 下一句 */
  if (ev.button === 2){ mouse.down = false; return; }
  if (ev.button === 1){ mouse.down = false; return; }   /* 中键：指挥层选中用，别喂给开枪（m43500） */
  if (confirmBack){ const cb = uiHit(mouse.x, mouse.y); if (cb) cb.fn(); return; }
  if (mapOpen){
    /* 开发者模式下点地图 = 瞬移过去；普通人点一下就是关掉 */
    if (CFG.dev && mapView){
      const wx = (mouse.x - mapView.ox) / mapView.k;
      const wy = (mouse.y - mapView.oy) / mapView.k;
      if (wx >= 0 && wy >= 0 && wx <= cur().w && wy <= cur().h){
        devTeleport(wx, wy);
        return;                       /* 地图不关，方便连着跳几次 */
      }
    }
    mapOpen = false; return;
  }
  if (state === 'play'){
    /* 开发者面板这类"浮在战斗画面上的热区"要先吃掉点击，不然点按钮就变成开枪 */
    const pb = uiHit(mouse.x, mouse.y);
    if (pb && pb.overlay && pb.fn){ uiCall(pb.fn); return; }
    if (typeof mobaOn === 'function' && mobaOn()) return;
    /* 手动拾取：点在够得着的那件上就只算"捡"。
       捡不动（背包塞满）也不能顺手开一枪 —— 以前这里 return 的条件里带了 pickLoot 的返回值 */
    const _lt = lootUnderPoint(mouse.x, mouse.y);
    if (_lt){ pickLoot(_lt); return; }
    if (playerTruck){ mouse.fire = true; return; }   /* 车上：左键喂给机枪 */
    if (player.hand === 'nade'){ nadeCookStart(); return; }
    if (player.hand === 'smoke'){ handThrowSmoke(); return; }
    if (hasFeat('guns')){ mouse.fire = true; tryShoot(); return; }
    throwGrenade(); return;
  }
  const b = uiHit(mouse.x, mouse.y);
  if (b){ uiCall(b.fn); return; }
});
addEventListener('mousemove', ev=>{
  inventoryInputMove(ev);
  if (state !== 'greplay' || !gDrag) return;
  gCam.x = gDrag.cx - (mouse.x - gDrag.sx) / gZoom;
  gCam.y = gDrag.cy - (mouse.y - gDrag.sy) / gZoom;
  const L = cur();
  gCam.x = clamp(gCam.x, 0, L.w);
  gCam.y = clamp(gCam.y, 0, L.h);
});
addEventListener('mouseup', ev=>{
  if (bindCaptureMouseUp(ev)) return;
  if (ui.inv.open && Number.isFinite(ev.clientX)){
    const p = toScreen(ev);
    mouse.x = p.x; mouse.y = p.y;
  }
  inventoryInputRelease('mouse' + ev.button, ev);
  if (ev.button === 2 && typeof tripDisarmCancel === 'function') tripDisarmCancel();
  /* 武器栏：按下时记住了哪一格，松手在这里结算 */
  if (ev.button === 0 && ui.inv.gunDrag && ui.inv.open && bagGridOn()){
    const gd = ui.inv.gunDrag;
    ui.inv.gunDrag = null;
    const GD = invGridGeom;
    const moved = Math.hypot(mouse.x - gd.sx, mouse.y - gd.sy) > 6;
    if (!moved){
      if (gd.wid) useGun(gd.wid);                 /* 点一下 = 切枪 */
    } else {
      const GS = (GD && GD.gunSlots) || [];
      const inR = (r) => !!r && mouse.x >= r.x && mouse.x <= r.x + r.w && mouse.y >= r.y && mouse.y <= r.y + r.h;
      let to = -1;
      for (let i = 0; i < GS.length; i++) if (inR(GS[i])) { to = i; break; }
      const outside = !GD || mouse.x < GD.px - 4 || mouse.x > GD.px + GD.pw + 4
                          || mouse.y < GD.py - 4 || mouse.y > GD.py + GD.ph + 4;
      if (gd.wid && to >= 0 && to !== gd.from){
        if (gunMoveSlot(gd.from, to)){
          if (player.gun !== player.guns[gd.wid]) useGun(gd.wid);
          setMsg('武器已换位', 1.2);
        }
      } else if (gd.wid && outside){
        if (player.gun !== player.guns[gd.wid]) useGun(gd.wid);
        dropGun();
      }
    }
  }
  /* ver3 网格背包：松手 = 落下（落进空格 / 换甲 / 丢到地上 / 点一下吃药） */
  if (ev.button === 0 && ui.inv.drag && ui.inv.open && bagGridOn()) bagDragDrop(!!ev.shiftKey || lastShift);
  if (ev.button === 0 && player && player.nadeCooking) nadeCookRelease();
  if (ev.button === 0) mouse.fire = false;
  if (ev.button === 2) mouse.down = false;
  if (state === 'greplay') gDrag = null;
});
addEventListener('wheel', ev=>{
  /* 观战图：滚轮缩放（m40173） */
  if (typeof mobaWheel === 'function' && mobaWheel(ev.deltaY)){ ev.preventDefault(); return; }
  if (typeof cricketWheel === 'function' && cricketWheel(ev.deltaY)){ ev.preventDefault(); return; }
  /* 洗牌界面：滚轮翻卡片 */
  if (ar && ar.shuf){ ev.preventDefault(); shuffleScroll(ev.deltaY > 0 ? 1 : -1); return; }
  /* 选牌展示（梭哈多给的卡）：卡多时上下翻 */
  if (typeof drawShowWheel === 'function' && drawShowWheel(ev.deltaY > 0 ? 1 : -1)){ ev.preventDefault(); return; }
  /* 老实抽卡 · 选卡：卡多时上下翻 */
  if (typeof erPickWheel === 'function' && erPickWheel(ev.deltaY > 0 ? 1 : -1)){ ev.preventDefault(); return; }
  /* 割草暂停 · 加成一览：卡的种类多时上下翻 */
  if (typeof arenaPauseWheel === 'function' && arenaPauseWheel(ev.deltaY > 0 ? 1 : -1)){ ev.preventDefault(); return; }
  /* 抽奖面板：滚轮翻"你的东西"列表 */
  if (typeof cargoWheel === 'function' && cargoWheel(ev.deltaY > 0 ? 1 : -1)){ ev.preventDefault(); return; }
    if (typeof gachaWheel === 'function' && gachaWheel(ev.deltaY > 0 ? 1 : -1)){ ev.preventDefault(); return; }
  if (state !== 'greplay') return;
  ev.preventDefault();
  const f = Math.exp(-ev.deltaY * 0.0012);
  const nz = clamp(gZoom * f, 0.12, 3.2);
  /* 以鼠标所在的世界坐标为锚点缩放 */
  const wx = gCam.x + (mouse.x - W/2) / gZoom;
  const wy = gCam.y + (mouse.y - H/2) / gZoom;
  gZoom = nz;
  gCam.x = wx - (mouse.x - W/2) / gZoom;
  gCam.y = wy - (mouse.y - H/2) / gZoom;
}, {passive: false});
cv.addEventListener('contextmenu', ev=>ev.preventDefault());
addEventListener('blur', ()=>{
  mouse.down = false; mouse.fire = false; lastShift = false;
  for (const k in keys) keys[k] = false;
  bindHeldKeys.clear(); bindSwallowedKeys.clear();
  inventoryStopGestures();
  ui.inv.drag = null; ui.inv.gunDrag = null;
  if (bindTarget){ bindCaptureCancel(); refreshKeyRows(); }
});
addEventListener('focus', ()=>{
  audioBackgroundChanged();
  audioTryResume();
});
document.addEventListener('visibilitychange', audioBackgroundChanged);
addEventListener('pagehide', ()=>{
  _audioPageHidden = true;
  audioBackgroundChanged();
});
addEventListener('pageshow', ()=>{
  _audioPageHidden = false;
  audioBackgroundChanged();
});

/* 死亡地带离开本局：只有成功撤离并在结算里存进仓库的物品才能带出。
   死亡页/局内 R 都算放弃本局，先销毁随身套件，再回到出发前选图界面；
   不能再直接 startDeathZone()，否则它会把死亡时的背包拍成“出发装备”贴进下一局。 */
function returnDeathZonePrep(){
  inventoryClose();
  if (typeof devLeaveDz === 'function') devLeaveDz();   /* m32149：回到出发界面 = 离开这一档，dev 还原 */
  if (typeof stashClearRunKit === 'function') stashClearRunKit();
  dzLvl = null;
  dzRestoreDiff();
  if (typeof dzSiegeReset === 'function') dzSiegeReset();
  stopSiren();
  rainWant = false;
  rainStop();
  mapOpen = false;
  confirmBack = false;
  ui.inv.open = false;
  invGeom = null; invGridGeom = null; ui.inv.drag = null;
  state = 'dzpick';
  logInfo('dz', '本局物资已丢失 · 返回出发前界面');
}

/* 重来本局。 */
function restartRun(){
  if (dzLvl){ returnDeathZonePrep(); return; }
  reset();
  state = 'play';
}

function startLevel(i){
  confirmBack = false;
  dzLvl = null; dzRestoreDiff();
  /* 兜一层难度预设：刷新页面后直接进关（没点难度按钮）时 CFG 是出厂默认，
     eVision 之类的键根本没写过 → enemyVisionRange 会退到关卡自己的 seeRange（看起来像"视野突然变大"）。
     只在明显缺失时补；这里直接合并 PRESETS，不走 applyPreset（那边会重绘设置面板，测试环境里没有 DOM）。 */
  if (typeof PRESETS !== 'undefined' && !isFinite(CFG.eVision)){
    const _d = (typeof diffName === 'string' && PRESETS[diffName]) ? diffName : 'normal';
    const _p = PRESETS[_d];
    if (_p){
      /* 只补"完全没写过"的键，别覆盖已有的默认值/玩家调过的值 */
      for (const _k in _p) if (Object.prototype.hasOwnProperty.call(_p, _k) && CFG[_k] === undefined) CFG[_k] = _p[_k];
      if (typeof presetName !== 'undefined') presetName = _d;
    }
  }
  arenaLvl = null; ar = null; arOrbs = [];
  audioInit();
  levelIdx = clamp(i, 0, LEVELS.length - 1);
  mapOpen = false;
  runTimes = [];
  reset();
  initDoors(cur());
  logInfo('level', '切到第 ' + (levelIdx+1) + ' 关');
  if (LEVELS[levelIdx].boss || LEVELS[levelIdx].intro){ startIntro(); }
  else state = 'play';
}
/* m35945：下一关只认"能正常玩的故事关"，测试区/娱乐图不进主线推进
   （以前 3-3 之后 index+1 是「测试区 · 靶场」，点下一关直接被塞进测试地图） */
function nextPlayableIdx(from){
  for (let k = from + 1; k < LEVELS.length; k++){
    if (typeof isPlayableLevel === 'function' ? isPlayableLevel(LEVELS[k]) : !LEVELS[k].devOnly) return k;
  }
  return -1;
}
function nextLevel(){
  const _ni = nextPlayableIdx(levelIdx);
  if (_ni >= 0){
    levelIdx = _ni;
    /* m34146：下一关不要沿用"我刚刚在上一关用的难度"。
       每一关的难度是各自解锁的，进下一关时换成那一关目前能开的最高难度。 */
    if (typeof progDiffUnlocked === 'function' && diffName !== 'custom'){
      const _ORDER = ['nightmare', 'hard', 'normal', 'easy'];
      const _want = _ORDER.find(function(d){ return progDiffUnlocked(levelIdx, d); });
      if (_want && _want !== diffName){
        const _from = diffName;
        applyPreset(_want, true, true);
        logInfo('level', '下一关难度按这一关的进度改成 ' + (DIFF_LABEL[_want] || _want) + '（上一关用的是 ' + (DIFF_LABEL[_from] || _from) + '）');
        setMsg('这一关目前能玩的是「' + (DIFF_LABEL[_want] || _want) + '」难度', 2.6);
      }
    }
    reset();
    initDoors(cur());            /* 自动门要重新生成，不然进门关时门会凭空消失 */
    mapOpen = false; ui.inv.open = false; runTimes = [];
    logInfo('level', '下一关 → ' + ((typeof levelLabelOf === 'function' ? levelLabelOf(levelIdx) : ('第 ' + (levelIdx+1) + ' 关')) + '《' + LEVELS[levelIdx].name + '》'));
    /* 下一关也得走剧情，别只在选关里进去才播 */
    if (LEVELS[levelIdx].boss || LEVELS[levelIdx].intro) startIntro();
    else state = 'play';
  }
  else { state = 'win'; logInfo('win', '全部通关 · 总用时 ' + logGame()); }
}
function goMenu(){
  inventoryClose();
  if (typeof devGateReset === 'function') devGateReset();
  if (typeof devLeaveDz === 'function') devLeaveDz();   /* m32149：离开死亡地带，dev 回到玩家原本的全局设置 */
  /* 离开对局：背包里属于"这一局"的东西清掉（仓库带进来的会退回原仓库），
     下一局从空背包开始。以前这里不清，死了重进还带着上一把的物资。 */
  if (typeof stashClearRunKit === 'function') stashClearRunKit();
  arenaSlotUI = null;
  customLvl = null;
  dzLvl = null; dzRestoreDiff();
  stopSiren();
  rainWant = false;
  rainStop();
  arenaLvl = null; ar = null; arOrbs = [];
  /* 斗蛐蛐/军团推塔：回大厅后要把观战图层一起关掉，否则卡牌还画在标题页上（m41820） */
  if (typeof cricketLeave === 'function') cricketLeave();
  if (typeof mobaLeave === 'function') mobaLeave();
  confirmBack = false; mapOpen = false;
  if (typeof levelMusicStop === 'function') levelMusicStop();
  try { alarm2Clear(); } catch(e){}
  state = 'menu'; logInfo('ui', '回到主菜单'); }
/* 开发者：K 一键处决。
   - 普通敌人直接死（走正常死亡流程，掉东西/计分都照旧）
   - BOSS 第一次按：给头上挂一块"再按一次处决"的牌子；第二次按才真死
   - 没有 boss 在场的第二次按，等于再清一遍小兵 */
function devKillAll(){
  if (!CFG.dev || state !== 'play') return;
  /* BOSS 关卡里"boss"是 hunters 里那只猎手，不在 enemies 里：两边都算 */
  const _hs = (typeof hunters !== 'undefined' && hunters) ? hunters : [];
  const _live = enemies.filter(e => !e.dead).concat(_hs.filter(h => !h.dead));
  const bosses = _live.filter(e => e.bossKind || e.boss || _hs.indexOf(e) >= 0);
  const marked = bosses.filter(e => e.devMark);
  if (marked.length){
    for (const e of marked){ e.hp = 0; e.dead = true; e.devMark = false; }
    /* 割草走计分/掉落，普通关卡只标记死亡 */
    for (const e of marked){ if (typeof killTestEnemy === 'function' && enemies.indexOf(e) >= 0) killTestEnemy(e); }
    enemies = enemies.filter(x => !x.dead);
    if (_hs.length) hunters = hunters.filter(h => !h.dead);
    setMsg('处决 BOSS · ' + marked.length + ' 只', 1.6);
    logWarn('dev', '开发者 · 处决 BOSS ×' + marked.length);
    return;
  }
  if (bosses.length){
    /* 先把小兵清干净，只留 BOSS —— 之前这一支什么都不杀，看着像"小兵免疫处决" */
    let _m = 0;
    for (const e of enemies.slice()){
      if (e.dead || e.bossKind) continue;
      e.hp = 0; e.dead = true;
      if (typeof killTestEnemy === 'function') killTestEnemy(e);
      _m++;
    }
    enemies = enemies.filter(x => x.bossKind ? true : !x.dead);
    poolClearView(bullets);
    for (const e of bosses) e.devMark = true;
    setMsg('小兵已清（' + _m + '）· BOSS 免疫处决，再按一次 K 确认处决（' + bosses.length + ' 只）', 2.6);
    logWarn('dev', '开发者 · BOSS 需要二次确认（' + bosses.length + ' 只）');
    return;
  }
  let n = 0;
  /* 先拍快照：killTestEnemy 会改动 enemies 数组，边遍历边删会漏人 */
  const _killList = enemies.filter(e => !e.dead && !e.bossKind);
  for (const e of _killList){
    if (e.dead || e.bossKind) continue;
    e.hp = 0; e.dead = true;
    if (typeof killTestEnemy === 'function') killTestEnemy(e);
    n++;
  }
  enemies = enemies.filter(x => !x.dead);
  if (_hs.length){
    for (const h of _hs){ if (!h.dead){ h.hp = 0; h.dead = true; n++; } }
    hunters = hunters.filter(h => !h.dead);
  }
  poolClearView(bullets);
  setMsg('处决 · ' + n + ' 个人机下线', 1.6);
  logWarn('dev', '开发者 · 处决所有小兵（' + n + ' 个）');
}
/* 开发者：点地图瞬移。落在墙上会自动挪到最近的空地 */
function devTeleport(wx, wy){
  if (!CFG.dev) return false;
  const L = cur();
  if (!(wx >= 0 && wy >= 0 && wx <= L.w && wy <= L.h)) return false;
  const p = safeSpot(L, {x:wx, y:wy}, 24);
  player.x = p.x; player.y = p.y;
  for (const h of hunters){ h.path = null; h.goal = null; }
  for (const e of enemies){ e.path = null; e.goal = null; }
  setMsg('开发者 · 已瞬移到 ' + Math.round(p.x) + ',' + Math.round(p.y), 1.6);
  logWarn('dev', '瞬移 · ' + Math.round(p.x) + ',' + Math.round(p.y));
  return true;
}

/* 开发者：一键把三个电闸拉满，直接进最后那段追逐（只想测终局时用） */
function devPullAll(){
  if (!CFG.dev) return;
  const L = cur();
  if (!L.boss){ setMsg('只有第四关有电闸', 1.3); return; }
  if (state !== 'play') return;
  if (exitOpen){ setMsg('闸已经全拉过了', 1.2); return; }
  let guard = 0;
  while (swDone < 3 && guard++ < 5){
    swDone++;
    if (switches[swDone-1]) switches[swDone-1].on = true;
    pullSwitch({ quiet: true });
  }
  setMsg('开发者 · 三个电闸一次拉满', 2.2);
  logWarn('dev', '一键全拉闸 · 直接进最后阶段');
}

function spawnCamera(c){
  /* 出生这一刻就按扫视曲线摆好角度，否则第一帧会"啪"地跳一下 */
  const baseA = c.ang || 0;
  const sweep = c.sweep === undefined ? 0.30 : c.sweep;
  const swT = rand(0, 6.28);
  const ang0 = baseA + Math.sin(swT * 0.42) * sweep;
  return {
    type: 'camera', x: c.x, y: c.y, r: enemyType({type:'camera'}).r,
    ang: ang0, baseAng: baseA, visionAbs: c.visionAbs,
    hearMul: c.hearMul,            /* 实例级：-1 = 白天更聋 */
    staticVisMul: c.staticVisMul,  /* 实例级：静止的摄像头比巡逻的守卫看得更远 */
    wp: [[c.x, c.y]], i: 0, wait: 0, mode: 0, sees: false, heard: false,
    lastKnown: null, alertT: 0, ammo: 0, reloading: 0, muzzle: 0, fireCd: 99,
    alarmCd: 0, pulse: 0,
    sweep: sweep,       /* 左右缓慢扫的幅度（弧度） */
    swT: swT
  };
}
/* 无人机的螺旋桨：一声短促的低频"嗡"，音量按离你的距离给，
   每架各自有节拍，听起来就是天上有个东西一直在附近绕 */
let droneHum = null;
function droneHumNode(){
  if (!actx) return null;
  if (droneHum) return droneHum;
  const o1 = actx.createOscillator(), o2 = actx.createOscillator(), o3 = actx.createOscillator();
  const g = actx.createGain(), trem = actx.createGain(), lfo = actx.createOscillator();
  o1.type = 'sawtooth'; o1.frequency.value = 118;
  o2.type = 'triangle'; o2.frequency.value = 236;
  o3.type = 'square';   o3.frequency.value = 470;   /* 桨叶的高频"切风声" */
  const lp = actx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1400;
  const g3 = actx.createGain(); g3.gain.value = 0.18;
  g.gain.value = 0;
  /* 颤音：9Hz 的轻微起伏，听起来才像在转，而不是一根长音 */
  lfo.type = 'sine'; lfo.frequency.value = 9;
  const lfoG = actx.createGain(); lfoG.gain.value = 0.35;
  trem.gain.value = 0.65;
  lfo.connect(lfoG); lfoG.connect(trem.gain);
  o1.connect(lp); o2.connect(lp); o3.connect(g3); g3.connect(lp);
  lp.connect(trem); trem.connect(g); g.connect(duckBus());
  o1.start(); o2.start(); o3.start(); lfo.start();
  droneHum = {o1:o1, o2:o2, o3:o3, lfo:lfo, g:g};
  return droneHum;
}
/* 停止螺旋桨：退出对局/重开/回大厅时必须真的停掉，
   否则节点一直挂在 destination 上，人已经不在关卡里了声音还在响 */
function stopDroneHum(){
  const n = droneHum;
  droneHum = null;
  if (!n) return;
  try { n.g.gain.cancelScheduledValues(actx ? actx.currentTime : 0); } catch(e){}
  try { if (actx) n.g.gain.setTargetAtTime(0, actx.currentTime, 0.03); } catch(e){}
  try { n.o1.stop(); } catch(e){}
  try { n.o2.stop(); } catch(e){}
  try { n.o3.stop(); } catch(e){}
  try { n.lfo.stop(); } catch(e){}
  try { n.g.disconnect(); } catch(e){}
}
function sfxDroneHum(dist2){
  if (!actx || actx.state !== 'running') return;
  const n = droneHumNode(); if (!n) return;
  /* 600px 以内才听得见，越近越响；太远就直接静音 */
  const k = clamp(1 - dist2/700, 0, 1);
  const v = 0.15 * Math.pow(k, 1.15);      /* 之前 0.05 太轻，基本听不见 */
  try {
    n.g.gain.setTargetAtTime(v, actx.currentTime, 0.06);
    /* 靠近时桨叶转速听起来更快、音高更高 */
    n.o1.frequency.setTargetAtTime(96 + k*44, actx.currentTime, 0.1);
    n.o2.frequency.setTargetAtTime(192 + k*88, actx.currentTime, 0.1);
  } catch(e){}
}

/* 无人机：关卡里用 {x,y, wp:[[..],[..]]} 描述它的巡航环 */
function spawnDrone(d){
  const wp = (d.wp && d.wp.length) ? d.wp.slice() : [[d.x, d.y]];
  const T = enemyType({type:'drone'});
  return {
    type: 'drone', x: d.x, y: d.y, r: T.r,
    ang: 0, baseAng: 0, visionAbs: d.visionAbs,
    wp: wp, i: 0, wait: 0, mode: 0, sees: false, heard: false,
    lastKnown: null, alertT: 0, ammo: 0, reloading: 0, muzzle: 0, fireCd: 99,
    alarmCd: 0, pulse: 0, rot: 0,
    home: wp[0].slice()
  };
}
