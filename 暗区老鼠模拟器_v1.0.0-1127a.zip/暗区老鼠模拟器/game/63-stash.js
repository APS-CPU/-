/* ======================= 死亡地带 · 仓库 =======================
   三个难度各一个独立仓库（5 行 × 8 列 = 40 格）。规则：
     · 只有死亡地带能用，别的模式和故事关不碰它；
     · 撤离成功时结算：背包里的东西想留就点进仓库，不点的（关掉时还在背包里）直接消失；
     · 下一局出发前可以从仓库里点名带到背包里；

   数据落 localStorage（键 after5_dzstash），结构：
     { hard:[40], nightmare:[40], core:[40] }，每格是 null 或 { k, w, h, x, y, rot, ...extra }
   ---------------------------------------------------------------- */

const STASH_W = 8, STASH_H = 5, STASH_N = STASH_W * STASH_H;
const STASH_TIERS = ['hard', 'nightmare', 'core'];
const STASH_TIER_NAME = { hard: '困难', nightmare: '噩梦', core: '硬核' };

let dzStash = null;
let dzStashOverflow = null;   /* 旧坏档扩成真实尺寸后放不进 8×5 的，留在待整理区，绝不删物品 */
let dzStashGear = null;       /* 三档各自的装备栏；仓库独立，身上装备也必须独立 */
let stashUI = { open: false, mode: 'pre', confirm: false, msg: '', msgT: 0, hover: -1 };

function stashBlank(){ return new Array(STASH_N).fill(null); }
function stashDefaultGear(){ return { armor:null, bagKind:'none', thermal:null }; }
function stashTierObject(make){ const o = {}; for (const t of STASH_TIERS) o[t] = make(); return o; }
const STASH_VER = 3;                 /* v3：初始小包只在入场时借出，不在仓库阶段生成 */
function stashBaseDims(c){
  if (!c) return { w:1, h:1 };
  if (c.k === 'ammo' && typeof ammoCellSize === 'function') return ammoCellSize(c.t || 'pistol');
  const fw = (typeof GRID_W !== 'undefined' && GRID_W[c.k]) || 1;
  const fh = (typeof GRID_H !== 'undefined' && GRID_H[c.k]) || 1;
  return { w:fw, h:fh };
}
/* 装备尺寸只认物品表：旧档里的 2×1 / 2×2 背包不能继续冒充六格背包。 */
function stashNormalizeDims(c){
  const b = stashBaseDims(c);
  let w = Math.max(1, c.w | 0), h = Math.max(1, c.h | 0);
  const known = (typeof GRID_W !== 'undefined' && GRID_W[c.k]) || c.k === 'ammo';
  if (known){
    const normal = w === b.w && h === b.h;
    const turned = b.w !== b.h && w === b.h && h === b.w;
    if (!normal && !turned){ w = b.w; h = b.h; }
  }
  w = Math.min(STASH_W, w); h = Math.min(STASH_H, h);
  c.w = w; c.h = h;
  if (b.w !== b.h && w === b.h && h === b.w) c.rot = 1;
  else delete c.rot;
  return { w:w, h:h };
}
function stashCanPlaceAt(cells, w, h, x, y, except){
  if (x < 0 || y < 0 || x + w > STASH_W || y + h > STASH_H) return false;
  for (let i = 0; i < STASH_N; i++){
    const c = cells[i]; if (!c || c === except) continue;
    const cw = c.w || 1, ch = c.h || 1, cx = c.x || 0, cy = c.y || 0;
    if (x < cx + cw && x + w > cx && y < cy + ch && y + h > cy) return false;
  }
  return true;
}
function stashPlaceLoaded(cells, c){
  const d = stashNormalizeDims(c);
  let w = d.w, h = d.h;
  let spot = stashCanPlaceAt(cells, w, h, c.x | 0, c.y | 0) ? { x:c.x | 0, y:c.y | 0 } : stashFreeSpot(cells, w, h, -1);
  if (!spot && w !== h){
    spot = stashFreeSpot(cells, h, w, -1);
    if (spot){ const z = w; w = h; h = z; c.rot = c.rot ? 0 : 1; }
  }
  if (!spot) return false;
  c.w = w; c.h = h; c.x = spot.x; c.y = spot.y;
  if (!c.rot) delete c.rot;
  cells[spot.y * STASH_W + spot.x] = c;
  return true;
}
function stashLoad(){
  if (dzStash) return dzStash;
  dzStash = stashTierObject(stashBlank);
  dzStashOverflow = stashTierObject(function(){ return []; });
  dzStashGear = stashTierObject(stashDefaultGear);
  const raw = localStorage.getItem('after5_dzstash');
  if (!raw) return dzStash;
  let s = null;
  try { s = JSON.parse(raw); }
  catch (e){
    /* 存档坏了不能让它把游戏带崩，也不能直接丢掉玩家的东西：原样备份一份再重建 */
    try { localStorage.setItem('after5_dzstash_bad_' + Date.now(), raw); } catch (e2){}
    return dzStash;
  }
  if (!s || typeof s !== 'object') return dzStash;
  for (const t of STASH_TIERS){
    const arr = Array.isArray(s[t]) ? s[t] : null;
    const oldOverflow = s.overflow && Array.isArray(s.overflow[t]) ? s.overflow[t] : [];
    const all = (arr || []).concat(oldOverflow).filter(function(c){
      return !!(c && typeof c.k === 'string' && c.k);
    });
    /* 大件先排，避免几颗 1×1 把完整的 3×3 护甲切碎；放不下的进入可领取待整理区。 */
    all.sort(function(a,b){
      const da = stashNormalizeDims(a), db = stashNormalizeDims(b);
      return db.w * db.h - da.w * da.h;
    });
    for (const c of all){
      if (!stashPlaceLoaded(dzStash[t], c)) dzStashOverflow[t].push(c);
    }
    const g = s.gear && s.gear[t];
    if (g && typeof g === 'object'){
      dzStashGear[t] = {
        armor: g.armor && typeof g.armor === 'object' ? g.armor : null,
        bagKind: (typeof BAG_DEF !== 'undefined' && BAG_DEF[g.bagKind]) || g.bagKind === 'none' ? g.bagKind : 'none',
        thermal: g.thermal && typeof g.thermal === 'object' ? g.thermal : (g.thermal ? { battery:100 } : null)
      };
      /* v2 会在仓库阶段给每档凭空发一个小包。无法和真实小包区分，只迁掉这一种；
         玩家明确装备的战术包/远征包仍原样保留。 */
      if ((s.v | 0) < 3 && dzStashGear[t].bagKind === 'small') dzStashGear[t].bagKind = 'none';
    } else if ((s.v | 0) < 2 && all.some(function(c){ return c.k === 'bag'; })){
      /* v1 没存装备栏。旧逻辑约定“仓库里有背包就不再补发默认包”，迁移时沿用，
         避免玩家已经把初始小包存仓库后，升级存档又凭空复制一只到身上。 */
      dzStashGear[t].bagKind = 'none';
    }
  }
  if (s.dirty && typeof s.dirty === 'object'){
    for (const t of STASH_TIERS) dzStashDirty[t] = !!s.dirty[t];
  }
  return dzStash;
}
function stashSave(){
  try { localStorage.setItem('after5_dzstash', JSON.stringify({
    v: STASH_VER, hard: dzStash.hard, nightmare: dzStash.nightmare, core: dzStash.core,
    overflow: dzStashOverflow, gear: dzStashGear, dirty: dzStashDirty
  })); } catch (e){}
}

/* ---------- 作弊标记：这一档的仓库里混进了开发者模式带出来的东西 ----------
   规则（用户 m15467）：在死亡地带对局里打开开发者模式 → 二次确认；
   确认之后，当前难度的仓库打上"作弊"标记，面板上写明，
   并给一个"清空这个仓库"的按钮让玩家从头再来。 */
let dzStashDirty = { hard: false, nightmare: false, core: false };
function stashDirty(t){
  stashLoad();
  return !!(dzStashDirty[t || stashTierNow()]);
}
function stashMarkDirty(t){
  stashLoad();
  dzStashDirty[t || stashTierNow()] = true;
  stashSave();
}
function stashClearDirty(t){
  stashLoad();
  dzStashDirty[t || stashTierNow()] = false;
  stashSave();
}
/* 一键重制：把这个难度的仓库清空 + 解除作弊标记 */
function stashResetTier(t){
  stashLoad();
  const tier = t || stashTierNow();
  dzStash[tier] = stashBlank();
  dzStashOverflow[tier] = [];
  const activeDevSettlement = stashExtracted && devGatePassed && tier === stashTierNow();
  dzStashDirty[tier] = activeDevSettlement;
  stashSave();
  stashMsg('「' + (STASH_TIER_NAME[tier] || tier) + '」仓库已清空' +
    (activeDevSettlement ? ' · 本局仍有开发者标记' : '，作弊标记也清掉了'));
}

/* ---------- 装备槽：护甲/背包/热成像 可以直接穿上带进场 ---------- */
const STASH_EQUIP_NAME = { armor:'防弹衣', bag:'背包', thermal:'热成像' };
function stashCanEquip(c){ return !!(c && (c.k === 'armor' || c.k === 'bag' || c.k === 'thermal')); }
function stashEquippedOf(k){
  if (k === 'armor') return (player && player.armor) || null;
  if (k === 'bag') return (player && player.bag && !player.bag._starter && player.bag.kind && player.bag.kind !== 'none') ? player.bag : null;
  if (k === 'thermal') return (player && player.heatWorn) ? true : null;
  return null;
}
function stashEquipRecord(c, remove){
  if (!c || typeof remove !== 'function') return false;
  if (c.k === 'armor'){
    if (player.armor){ stashMsg('身上已经有防弹衣了 · 先把它收回仓库再换'); return false; }
    const A = (typeof armorDef === 'function' && armorDef(c.ak || 'light')) || { label:'防弹衣', dur:100, reduce:0.3 };
    player.armor = { kind: c.ak || 'light', label: A.label, hp: c.hp || A.dur, maxHp: c.maxHp || A.dur, reduce: A.reduce, q: c.q || 0 };
  } else if (c.k === 'bag'){
    if (stashEquippedOf('bag')){ stashMsg('身上已经有背包了 · 先把它收回仓库再换'); return false; }
    const k = c.bk || c.bag || 'small';
    const D = (typeof BAG_DEF !== 'undefined' && BAG_DEF[k]) || { id:k, label:'背包', slots:10, ammoK:1 };
    stashWearBag(Object.assign({}, D, { kind: k }));
  } else if (c.k === 'thermal'){
    if (player.heatWorn){ stashMsg('身上已经戴着热成像了'); return false; }
    thermalSetWorn(c, HEAT_CAP_V2);
  }
  remove();
  stashCommitTierGear(stashKitTier || stashTierNow(), false);
  stashSave();
  if (typeof sfxPick === 'function') sfxPick();
  stashMsg('已装备：' + stashLabelOf(c) + ' · 带进这一局');
  return true;
}
function stashEquip(c){
  const cells = stashCells();
  const idx = cells.indexOf(c);
  if (idx < 0) return false;
  return stashEquipRecord(c, function(){ cells[idx] = null; });
}
function stashEquipOverflow(c){
  const arr = stashOverflowCells();
  const idx = arr.indexOf(c);
  if (idx < 0) return false;
  return stashEquipRecord(c, function(){ arr.splice(idx, 1); });
}
/* 反方向：把身上的装备塞回仓库（撤离结算时想保住它就用这个） */
function stashUnequip(k){
  const cells = stashCells();
  let cell = null;
  if (k === 'armor'){
    if (!player.armor) return false;
    const A = player.armor;
    cell = { k:'armor', ak:A.kind, hp:A.hp, maxHp:A.maxHp, q:A.q || 0, w:3, h:3 };
  } else if (k === 'bag'){
    if (!stashEquippedOf('bag')) return false;
    /* 背包里还有东西就不许卸：以前这里直接把包塞进仓库，
       包里那堆格子却还算数 —— 于是"塞满大背包再把包丢仓库"就等于白嫖格子。
       规矩跟现实一样：先把包掏空，再卸包。 */
    const _left = (typeof bagItems === 'function') ? bagItems().length : 0;
    if (_left){ stashMsg('背包里还有 ' + _left + ' 件东西 · 先把它们放进仓库再卸背包'); return false; }
    const bk = player.bag.kind;
    cell = { k:'bag', bk:bk, w:2, h:3 };
  } else if (k === 'thermal'){
    if (!player.heatWorn) return false;
    cell = { k:'thermal', ...thermalPower(player, HEAT_CAP_V2), w:1, h:2 };
  }
  if (!cell) return false;
  const spot = stashFreeSpot(cells, cell.w, cell.h, -1);
  if (!spot){ stashMsg('仓库放不下这件装备了'); return false; }
  cell.x = spot.x; cell.y = spot.y;
  cells[spot.y * STASH_W + spot.x] = cell;
  /* 先确认仓库有完整矩形空位，最后才从身上移除；失败不能把装备吞掉。 */
  if (k === 'armor') player.armor = null;
  else if (k === 'bag') player.bag = Object.assign({}, (typeof BAG_NONE !== 'undefined' ? BAG_NONE : { kind:'none' }));
  else if (k === 'thermal'){
    thermalSetWorn(null);
  }
  stashCommitTierGear(stashKitTier || stashTierNow(), false);
  stashSave();
  stashMsg('已收回仓库：' + stashLabelOf(cell));
  return true;
}

/* 当前该看哪个仓库：死亡地带按三档难度分开，别的模式一律当 hard（也用不到） */
function stashTierNow(){
  const t = (typeof dzTier === 'string' && STASH_TIERS.indexOf(dzTier) >= 0) ? dzTier : 'hard';
  return t;
}
let stashForceTier = null;   /* 非空时所有存取都落到这一档（换难度退东西用） */
function stashCells(t){ stashLoad(); return dzStash[t || stashForceTier || stashTierNow()]; }
function stashOverflowCells(t){ stashLoad(); return dzStashOverflow[t || stashForceTier || stashTierNow()]; }

/* 在仓库里找一块放得下 w×h 的空位（8 宽 5 高） */
function stashFreeSpot(cells, w, h, except){
  const occ = new Array(STASH_N).fill(false);
  for (let i = 0; i < STASH_N; i++){
    const c = cells[i];
    if (!c || i === except) continue;
    const cw = c.w || 1, ch = c.h || 1;
    for (let dy = 0; dy < ch; dy++) for (let dx = 0; dx < cw; dx++){
      const j = (c.y + dy) * STASH_W + (c.x + dx);
      if (j >= 0 && j < STASH_N) occ[j] = true;
    }
  }
  for (let y = 0; y + h <= STASH_H; y++) for (let x = 0; x + w <= STASH_W; x++){
    let ok = true;
    for (let dy = 0; dy < h && ok; dy++) for (let dx = 0; dx < w; dx++){
      if (occ[(y + dy) * STASH_W + (x + dx)]) { ok = false; break; }
    }
    if (ok) return { x: x, y: y };
  }
  return null;
}

/* 空格总数够但被切碎时，自动把整个仓库重新排一遍。只有求出完整布局才会
   真正改坐标，所以失败不会挪乱、覆盖或吞掉任何已有物品。 */
function stashRepackWith(cells, incoming){
  const items = cells.filter(Boolean).concat(incoming ? [incoming] : []);
  let total = 0;
  const work = items.map(function(c, order){
    const d = stashNormalizeDims(Object.assign({}, c));
    total += d.w * d.h;
    const dirs = [{ w:d.w, h:d.h }];
    if (d.w !== d.h) dirs.push({ w:d.h, h:d.w });
    return { c:c, order:order, area:d.w * d.h, dirs:dirs };
  });
  if (total > STASH_N) return false;
  const units = work.filter(q => q.area === 1);
  const rects = work.filter(q => q.area > 1).sort((a,b) => b.area - a.area || a.dirs.length - b.dirs.length || a.order - b.order);
  const plan = new Map(), memo = new Set();
  let nodes = 0;
  function maskAt(x,y,w,h){
    let m = 0n;
    for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) m |= 1n << BigInt(yy * STASH_W + xx);
    return m;
  }
  function solve(i, occ){
    if (++nodes > 250000) return null;  /* 极端坏档兜底：宁可提示放不下，也不能卡死页面 */
    if (i >= rects.length) return occ;
    const key = i + ':' + occ.toString(36);
    if (memo.has(key)) return null;
    const q = rects[i];
    for (const d of q.dirs) for (let y = 0; y + d.h <= STASH_H; y++) for (let x = 0; x + d.w <= STASH_W; x++){
      const m = maskAt(x,y,d.w,d.h);
      if (occ & m) continue;
      plan.set(q, { x:x, y:y, w:d.w, h:d.h });
      const end = solve(i + 1, occ | m);
      if (end !== null) return end;
    }
    plan.delete(q); memo.add(key); return null;
  }
  let occ = solve(0, 0n);
  if (occ === null) return false;
  for (const q of units){
    let idx = -1;
    for (let i = 0; i < STASH_N; i++) if (!(occ & (1n << BigInt(i)))){ idx = i; break; }
    if (idx < 0) return false;
    plan.set(q, { x:idx % STASH_W, y:Math.floor(idx / STASH_W), w:1, h:1 });
    occ |= 1n << BigInt(idx);
  }
  cells.fill(null);
  for (const q of work){
    const p = plan.get(q), c = q.c, base = stashBaseDims(c);
    c.x = p.x; c.y = p.y; c.w = p.w; c.h = p.h;
    if (base.w !== base.h && p.w === base.h && p.h === base.w) c.rot = 1;
    else delete c.rot;
    cells[p.y * STASH_W + p.x] = c;
  }
  return true;
}
function stashIndexOf(cells, item){ return cells.indexOf(item); }

/* 背包 → 仓库 */
function stashPut(it){
  if (!it) return false;
  const cells = stashCells();
  const d = stashNormalizeDims(Object.assign({}, it));
  let w = d.w, h = d.h;
  let spot = stashFreeSpot(cells, w, h);
  let turned = false;
  if (!spot && w !== h){
    spot = stashFreeSpot(cells, h, w);
    if (spot){ const z = w; w = h; h = z; turned = true; }
  }
  const cell = { k: it.k, w: w, h: h, x:spot ? spot.x : 0, y:spot ? spot.y : 0 };
  const wasTurned = !!it.rot;
  if (wasTurned !== turned) cell.rot = 1;
  for (const q in it){ if (q === 'uid' || q === 'x' || q === 'y' || q === 'w' || q === 'h' || q === 'k' || q === 'rot') continue; cell[q] = it[q]; }
  if (spot) cells[spot.y * STASH_W + spot.x] = cell;
  else if (!stashRepackWith(cells, cell)){ stashMsg('仓库满了'); return false; }
  if (typeof bagRemoveItem === 'function') bagRemoveItem(it);
  stashSave();
  return true;
}

/* 仓库 → 背包 */
function stashTake(cell){
  if (!cell) return false;
  const cells = stashCells();
  const idx = cells.indexOf(cell);
  if (idx < 0) return false;
  const extra = {};
  for (const q in cell){ if (q !== 'x' && q !== 'y' && q !== 'w' && q !== 'h') extra[q] = cell[q]; }
  let it = null;
  if (typeof bagAddCell === 'function') it = bagAddCell(cell.k, extra);
  if (!it){ stashMsg('背包放不下了'); return false; }
  cells[idx] = null;
  stashSave();
  /* 打来源标记：换难度时只退"从仓库拿出来的"，
     玩家本来背包里就有的东西（开局配发）不该被一起倒进仓库。 */
  if (it) it._sf = stashForceTier || stashKitTier || stashTierNow();
  return true;
}
function stashTakeOverflow(cell){
  if (!cell) return false;
  const arr = stashOverflowCells();
  const idx = arr.indexOf(cell);
  if (idx < 0) return false;
  const extra = {};
  for (const q in cell){ if (q !== 'x' && q !== 'y' && q !== 'w' && q !== 'h') extra[q] = cell[q]; }
  const it = (typeof bagAddCell === 'function') ? bagAddCell(cell.k, extra) : null;
  if (!it){ stashMsg('背包放不下这件待整理物资'); return false; }
  arr.splice(idx, 1);
  it._sf = stashKitTier || stashTierNow();
  stashSave();
  return true;
}


/* ---------- 随身套件（背包里的东西 + 身上装备）----------
   reset() 会把 player 整个重建一遍，所以"出发前整理"里拿的东西
   必须在 reset 之前拍快照、之后贴回去，否则一进对局就全没了。 */
/* 一局结束（死亡/撤离/回大厅）时清干净随身：
   1) 先从仓库带进来的东西（带 _sf 标记）退回原仓库 —— 这部分不能凭空消失；
   2) 这一局在地图上捡的、打出来的，全部清掉（它们本来就属于本局）；
   3) 装备栏回到空；初始小背包只在真正进入下一局之后发放。
   注意：只在"离开对局"时调用，不能在 startDeathZone 开头调用 ——
   那里玩家刚在出发前整理里把东西装进背包，清了就等于白整理。 */
/* 一局结束（死亡 / 主动退出 / 撤离后的剩余）——**全丢**。
   规则（用户 m15439）：主动退出 = 死亡 = 没带出来，只有"成功撤离并把东西存进仓库"
   才算带出；所以这里不再把 _sf 标记的东西退回仓库。
   （换难度时的退还是在 stashOpenPanel / startDeathZone 里另走 stashReturnKit，与此无关。）*/
let stashExtracted = false;   /* m24812：成功撤离 = 身上穿的装备带得出来（背包里没存的东西照旧丢） */
function stashClearRunKit(){
  let lost = 0;
  const _keepGear = stashExtracted; stashExtracted = false;
  const _gearTier = (typeof stashKitTier !== 'undefined' && stashKitTier) ? stashKitTier : null;
  if (typeof player !== 'undefined' && player){
    lost = (player.bagItems || []).length;
    player.bagItems = [];
    if (!_keepGear){ player.armor = null; player.shield = null; player.heatWorn = false; }
    player.thermal = false;
    /* 免费初始包是本局借出的，不进入撤离结算，也不写进任何难度的装备栏。 */
    if (!_keepGear || (player.bag && player.bag._starter))
      player.bag = Object.assign({}, (typeof BAG_NONE !== 'undefined' ? BAG_NONE : { kind: 'none', label: '（没穿背包）', slots: 0, ammoK: 1 }));
    if (player.thermalOn) player.thermalOn = false;
  }
  if (_gearTier) stashCommitTierGear(_gearTier, true);
  if (typeof stashKitTier !== 'undefined') stashKitTier = null;
  return lost;
}

function stashSnapshotKit(){
  if (typeof player === 'undefined' || !player) return null;
  const items = (typeof bagItems === 'function') ? bagItems().map(it => JSON.parse(JSON.stringify(it))) : [];
  return {
    items: items,
    armor: player.armor ? JSON.parse(JSON.stringify(player.armor)) : null,
    bagKind: (player.bag && player.bag._starter) ? 'none' : ((player.bag && player.bag.kind) || null),
    thermal: player.heatWorn ? thermalPower(player, HEAT_CAP_V2) : null
  };
}
/* 口袋行跟随背包高度，口袋里的物资仍留在原来的列。 */
function stashWearBag(bag){
  const oldRow = bagGridSize().bh;
  player.bag = bag;
  const newRow = bagGridSize().bh;
  for (const it of bagItems()) if (it.y === oldRow) it.y = newRow;
}
function stashEnsureRunBag(){
  if (!player || (player.bag && player.bag.kind && player.bag.kind !== 'none')) return false;
  const bk = (typeof BAG_DEFAULT !== 'undefined') ? BAG_DEFAULT : 'small';
  const D = (typeof BAG_DEF !== 'undefined' && BAG_DEF[bk]) ? BAG_DEF[bk] : { label:'小背包', slots:10, ammoK:1 };
  stashWearBag(Object.assign({}, D, { kind:bk, _starter:true }));
  return true;
}
function stashApplyKit(k){
  if (!k || typeof player === 'undefined' || !player) return;
  if (k.armor) player.armor = k.armor;
  if (k.bagKind === 'none'){
    /* 出发前把背包放进仓库了 —— 就别再偷偷塞一个（否则仓库一个、身上一个） */
    player.bag = Object.assign({}, (typeof BAG_NONE !== 'undefined' ? BAG_NONE : { kind: 'none', label: '（没穿背包）', slots: 0, ammoK: 1 }));
  } else if (k.bagKind && typeof BAG_DEF !== 'undefined' && BAG_DEF[k.bagKind]){
    player.bag = Object.assign({}, BAG_DEF[k.bagKind], { kind: k.bagKind });
  }
  if (k.thermal) thermalSetWorn(k.thermal);
  if (typeof bagAddCell !== 'function') return;
  /* 先清空再贴：reset 之后背包是空的，这里只是保证重开/换关不会叠两份 */
  player.bagItems = [];
  for (const it of (k.items || [])){
    const c2 = Object.assign({}, it); delete c2._sf;
    bagAddCell(c2.k || 'med', c2);
  }
}

/* 三档不仅仓库数组独立，装备栏也各存一份。免费初始小包不属于任何仓库档，
   只在进入对局时临时补给；这里保存的都是玩家真正装备的物品。 */
function stashCommitTierGear(tier, save){
  if (!tier || !player) return;
  stashLoad();
  dzStashGear[tier] = {
    armor: player.armor ? JSON.parse(JSON.stringify(player.armor)) : null,
    bagKind: (player.bag && player.bag._starter) ? 'none' : ((player.bag && player.bag.kind) || 'none'),
    thermal: player.heatWorn ? thermalPower(player, HEAT_CAP_V2) : null
  };
  if (save) stashSave();
}
function stashApplyTierGear(tier){
  if (!tier || !player) return;
  stashLoad();
  const g = dzStashGear[tier] || stashDefaultGear();
  player.armor = g.armor ? JSON.parse(JSON.stringify(g.armor)) : null;
  const bk = g.bagKind || 'none';
  if (bk === 'none') player.bag = Object.assign({}, (typeof BAG_NONE !== 'undefined' ? BAG_NONE : { kind:'none' }));
  else {
    const D = (typeof BAG_DEF !== 'undefined' && BAG_DEF[bk]) || (typeof BAG_DEF !== 'undefined' && BAG_DEF.small) || { label:'小背包', slots:10, ammoK:1 };
    player.bag = Object.assign({}, D, { kind:bk });
  }
  thermalSetWorn(g.thermal, HEAT_CAP_V2);
}

/* 删除一件仓库物品（Shift+点击）。装备/枪也照删，只提示一句，不做二次确认 —— 这是玩家主动操作。 */
function stashDelete(cell){
  if (!cell) return false;
  const cells = stashCells();
  const idx = cells.indexOf(cell);
  if (idx < 0) return false;
  const name = (typeof stashLabelOf === 'function') ? stashLabelOf(cell) : (cell.k || '东西');
  cells[idx] = null;
  stashSave();
  if (typeof sfxPick === 'function') sfxPick();
  stashMsg('已删除：' + name);
  return true;
}
function stashDeleteOverflow(cell){
  const arr = stashOverflowCells();
  const idx = arr.indexOf(cell);
  if (idx < 0) return false;
  const name = stashLabelOf(cell);
  arr.splice(idx, 1); stashSave();
  stashMsg('已删除待整理物资：' + name);
  return true;
}

function stashLabelOf(it){
  try {
    if (typeof bagItemLabel === 'function'){
      const c = Object.assign({}, it);
      if (c.k === 'med' && !c.r && c.rarity) c.r = c.rarity;
      const t = bagItemLabel(c);
      if (t && t !== '东西') return t;
    }
  } catch (e){}
  const m = { med:'药', ammo:'弹药', smoke:'烟雾弹', armor:'护甲', bag:'背包', shield:'盾牌',
              thermal:'热成像', nade:'手雷', heatcell:'电池', rope:'绳子', tripwire:'绊雷', gun:'枪' };
  return m[it.k] || it.k || '东西';
}

function stashMsg(s){ stashUI.msg = s; stashUI.msgT = 2.2; }
function stashBackpackLeft(){
  const arr = (typeof bagItems === 'function') ? bagItems() : [];
  return arr.length;
}
/* 随身物品（背包里的东西 + 身上装备）属于哪一档。
   换难度时如果还带着上一档的东西，先把它们原样退回那一档的仓库
   —— 不然"在 A 档取出来、切到 B 档再存进去"就把两档仓库连通了。 */
let stashKitTier = null;
function stashReturnKit(tier){
  if (!tier) return 0;
  stashForceTier = tier;
  let n = 0;
  try {
    const arr = (typeof bagItems === 'function') ? bagItems().slice() : [];
    for (const it of arr){
      if (!it || !it._sf || it._sf !== tier) continue;   /* 只退从这一档拿出来的 */
      const src = it._sf; delete it._sf;
      if (stashPut(it)) n++;
      else it._sf = src;   /* 原仓库满了就仍归原档，绝不能悄悄变成新难度的物品 */
    }
  } finally { stashForceTier = null; }
  return n;
}
function stashSelectTier(tier){
  if (!tier || STASH_TIERS.indexOf(tier) < 0) tier = 'hard';
  let n = 0;
  if (stashKitTier && stashKitTier !== tier){
    stashCommitTierGear(stashKitTier, false);
    n = stashReturnKit(stashKitTier);
  }
  if (stashKitTier !== tier){
    stashKitTier = tier;
    stashApplyTierGear(tier);
    stashSave();
  }
  return n;
}

function stashOpenPanel(mode){
  stashUI.resetAsk = false;
  stashLoad();
  /* 换了难度就一直线隔离：把上一档的随身物品退回它自己的仓库 */
  const _t = stashTierNow();
  if (mode !== 'settle'){
    const _old = stashKitTier;
    const _n = stashSelectTier(_t);
    if (_n) stashMsg('换难度了 · 上难度带出来的 ' + _n + ' 件已经退回「' + (STASH_TIER_NAME[_old] || _old) + '」仓库');
  } else {
    stashKitTier = _t;
    stashCommitTierGear(_t, true);
  }
  stashUI.open = true;
  stashUI.mode = (mode === 'settle') ? 'settle' : 'pre';
  stashUI.confirm = false;
  stashUI.msg = ''; stashUI.msgT = 0;
  stashUI.btns = [];
  stashUI.resetAsk = false; stashUI.resetTier = null;   /* m35424：本层按钮表，点击只命中这里 */
}
function stashClosePanel(force){
  if (!force && stashUI.mode === 'settle' && stashBackpackLeft() > 0 && !stashUI.confirm){
    stashUI.confirm = true;         /* 背包里还有东西：先问一句 */
    return;
  }
  if (stashKitTier) stashCommitTierGear(stashKitTier, true);
  stashUI.open = false;
  stashUI.confirm = false;
  stashUI.btns = [];
}
/* 撤离成功后调用：进入"结算"模式 */
function stashBeginSettle(){
  stashExtracted = true;
  if (devGatePassed && !stashDirty()) stashMarkDirty();
  /* 借来的背包只用于显示并取出这局物资，装备栏不提供入库按钮。 */
  stashOpenPanel('settle');
  stashMsg('撤离成功 · 把想留的东西点进仓库，剩下的会丢');
}

/* ------------------------------ 画面 ------------------------------ */
const STASH_SKIN = {
  hard:      { bg:'rgba(15,19,25,0.97)', line:'#8d9bab', title:'#e2eaf2', accent:'#9fb0c0', cell:'rgba(160,180,200,0.12)', cellOn:'rgba(160,180,200,0.20)', glow:0,  decor:0 },
  nightmare: { bg:'rgba(19,14,27,0.97)', line:'#a98ce0', title:'#efe4ff', accent:'#c9aef5', cell:'rgba(170,140,230,0.12)', cellOn:'rgba(170,140,230,0.22)', glow:12, decor:1 },
  core:      { bg:'rgba(27,14,11,0.98)', line:'#e8b45a', title:'#ffd98a', accent:'#f0c070', cell:'rgba(232,180,90,0.12)',  cellOn:'rgba(232,180,90,0.22)',  glow:20, decor:2 }
};
function stashFrame(px, py, pw, ph, sk){
  ctx.save();
  if (sk.glow){ ctx.shadowColor = sk.line; ctx.shadowBlur = sk.glow; }
  ctx.fillStyle = sk.bg; roundRect(px, py, pw, ph, 12); ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = sk.line; ctx.lineWidth = sk.decor ? 2.2 : 1.4;
  roundRect(px, py, pw, ph, 12); ctx.stroke();
  if (sk.decor === 2){
    /* 硬核：内衬 + 四角剑纹，像军械库 */
    ctx.strokeStyle = 'rgba(232,180,90,0.35)'; ctx.lineWidth = 1;
    roundRect(px + 6, py + 6, pw - 12, ph - 12, 9); ctx.stroke();
    ctx.strokeStyle = 'rgba(232,180,90,0.85)'; ctx.lineWidth = 2;
    const L = 18;
    const corners = [[px + 8, py + 8, 1, 1], [px + pw - 8, py + 8, -1, 1], [px + 8, py + ph - 8, 1, -1], [px + pw - 8, py + ph - 8, -1, -1]];
    for (const c of corners){
      ctx.beginPath();
      ctx.moveTo(c[0], c[1] + L * c[3]); ctx.lineTo(c[0], c[1]); ctx.lineTo(c[0] + L * c[2], c[1]);
      ctx.stroke();
    }
  } else if (sk.decor === 1){
    ctx.strokeStyle = 'rgba(201,174,245,0.22)'; ctx.lineWidth = 1;
    roundRect(px + 5, py + 5, pw - 10, ph - 10, 9); ctx.stroke();
  }
  ctx.restore();
}
function drawStash(){
  if (!stashUI.open) return;
  stashLoad();
  uiButtons = [];
  const W2 = W, H2 = H;
  const tier = stashTierNow();
  const cells = stashCells(tier);
  const sk = STASH_SKIN[tier] || STASH_SKIN.hard;

  ctx.save();
  ctx.fillStyle = 'rgba(4,7,11,0.88)';
  ctx.fillRect(0, 0, W2, H2);

  const pw = Math.min(1120, W2 - 60), ph = Math.min(566, H2 - 90);
  const px = (W2 - pw) / 2, py = (H2 - ph) / 2;
  stashFrame(px, py, pw, ph, sk);

  ctx.textAlign = 'left';
  ctx.fillStyle = sk.title;
  ctx.font = 'bold 22px "Microsoft YaHei",sans-serif';
  ctx.fillText((stashUI.mode === 'settle' ? '撤离结算 · ' : '出发前整理 · ') + '仓库（' + STASH_TIER_NAME[tier] + '）', px + 24, py + 40);
  /* m34024：解锁提示塞进副标题这一行，不额外占行（以前那行会压到「身上装备」） */
  const _newTierLine = (stashUI.mode === 'settle' && typeof window !== 'undefined' && window.dzUnlockToast) ? window.dzUnlockToast : '';
  if (_newTierLine){
    ctx.fillStyle = 'rgba(255,226,168,0.99)';
    ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
    ctx.fillText('恭喜撤离成功 · 已解锁「' + _newTierLine + '」难度 · 把想留的东西点进仓库', px + 24, py + 64);
  } else {
    ctx.fillStyle = 'rgba(190,200,210,0.75)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText(stashUI.mode === 'settle'
      ? '点背包里的东西 → 存进仓库；关掉时还在背包里的会丢失。'
      : '点东西 → 进背包；护甲 / 背包 / 热成像可以直接穿上带进场。', px + 24, py + 64);
  }

  ctx.fillStyle = sk.accent;
  ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillText('三个难度各有独立仓库，现在看的是「' + STASH_TIER_NAME[tier] + '」', px + 24, py + 86);
  /* 这一个仓库有开发者模式留下的痕迹：写清楚，别让玩家以为是自己带出来的 */
  /* 这个仓库有开发者模式留下的痕迹：做成右上角的角标，比一行小字醒目得多 */
  if (stashDirty(tier)){
    const _txt = '⚠ 开过开发者模式';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    const _tw = ctx.measureText(_txt).width;
    const _bw = _tw + 20, _bh = 26;
    const _bx = px + pw - 16 - _bw, _by = py + 10;
    ctx.fillStyle = 'rgba(150,26,26,0.92)';
    ctx.fillRect(_bx, _by, _bw, _bh);
    ctx.strokeStyle = 'rgba(255,120,100,0.95)';
    ctx.lineWidth = 1.6;
    ctx.strokeRect(_bx + 0.5, _by + 0.5, _bw - 1, _bh - 1);
    ctx.fillStyle = 'rgba(255,196,180,0.98)';
    ctx.textAlign = 'center';
    ctx.fillText(_txt, _bx + _bw / 2, _by + 18);
    ctx.textAlign = 'left';
  }
  let chipX = px + 24;
  for (const t of STASH_TIERS){
    const n = (dzStash[t] ? dzStash[t].filter(Boolean).length : 0) +
              (dzStashOverflow[t] ? dzStashOverflow[t].length : 0);
    const txt = STASH_TIER_NAME[t] + ' ' + n + ' 件';
    const on = (t === tier);
    const tk = STASH_SKIN[t] || STASH_SKIN.hard;
    ctx.font = (on ? 'bold ' : '') + '12px "Microsoft YaHei",sans-serif';
    const tw = ctx.measureText(txt).width + 18;
    ctx.fillStyle = on ? tk.cellOn : 'rgba(255,255,255,0.04)';
    roundRect(chipX, py + 96, tw, 22, 5); ctx.fill();
    ctx.strokeStyle = on ? tk.line : 'rgba(255,255,255,0.10)';
    ctx.lineWidth = on ? 1.4 : 1;
    roundRect(chipX, py + 96, tw, 22, 5); ctx.stroke();
    ctx.fillStyle = on ? tk.title : 'rgba(200,210,220,0.5)';
    ctx.textAlign = 'left';
    ctx.fillText(txt, chipX + 9, py + 112);
    btn(chipX, py + 96, tw, 22, '', () => {
      if (t === tier) return;
      stashMsg('要整理「' + STASH_TIER_NAME[t] + '」的仓库：先回选图界面把难度切成' + STASH_TIER_NAME[t]);
    }, { invisible: true });
    chipX += tw + 8;
  }

  const cellPx = 42, gap = 4;
  const bagX = px + 26;
  const bg = (typeof bagGridSize === 'function') ? bagGridSize() : { w:4, h:6, bw:2, bh:5, pw:4, ph:1 };
  const okCell = function(x, y){ return (typeof bagCellOk === 'function') ? bagCellOk(x, y, bg) : true; };

  /* ---- 装备栏 ---- */
  const eqY = py + 132;
  ctx.textAlign = 'left';
  ctx.fillStyle = sk.accent; ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
  ctx.fillText('身上装备（点了直接穿，不占背包）', bagX, eqY);
  const eqKinds = ['armor', 'bag', 'thermal'];
  const slotW = 146, slotH = 46;
  for (let i = 0; i < eqKinds.length; i++){
    const k = eqKinds[i];
    const sx = bagX + i * (slotW + 10), sy = eqY + 8;
    const cur = stashEquippedOf(k);
    ctx.fillStyle = cur ? 'rgba(120,200,160,0.14)' : sk.cell;
    roundRect(sx, sy, slotW, slotH, 6); ctx.fill();
    ctx.strokeStyle = cur ? 'rgba(140,230,190,0.55)' : 'rgba(255,255,255,0.10)';
    ctx.lineWidth = 1.2; roundRect(sx, sy, slotW, slotH, 6); ctx.stroke();
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(190,200,210,0.6)'; ctx.font = '11px "Microsoft YaHei",sans-serif';
    ctx.fillText(STASH_EQUIP_NAME[k], sx + 10, sy + 16);
    ctx.fillStyle = cur ? 'rgba(220,240,230,0.92)' : 'rgba(150,160,170,0.5)';
    ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
    let label = '空';
    if (k === 'armor' && cur) label = cur.label || '防弹衣';
    else if (k === 'bag' && cur) label = (typeof BAG_DEF !== 'undefined' && BAG_DEF[cur.kind] ? BAG_DEF[cur.kind].label : '背包');
    else if (k === 'thermal' && cur) label = '热成像';
    ctx.fillText(label, sx + 10, sy + 34);
    if (cur){
      ctx.fillStyle = 'rgba(140,230,190,0.85)'; ctx.font = '10px "Microsoft YaHei",sans-serif';
      ctx.textAlign = 'right'; ctx.fillText('收回▸', sx + slotW - 8, sy + 38);
      btn(sx + slotW - 56, sy + 24, 50, 18, '', function(){ stashUnequip(k); }, { invisible: true });
    }
  }

  /* ---- 左：背包（只画真实格子，口袋单独一行） ---- */
  const bagY = py + 236;
  ctx.textAlign = 'left';
  ctx.fillStyle = sk.accent; ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
  const _bagTxt = (bg.bw > 0 ? ('背包 ' + bg.bw + '×' + bg.bh + ' = ' + (bg.bw * bg.bh) + ' 格') : '没穿背包')
                + ' · 口袋 ' + bg.pw + ' 格 · 共 ' + (bg.bw * bg.bh + bg.pw * bg.ph) + ' 格';
  ctx.fillText(_bagTxt, bagX, bagY - 10);
  for (let y = 0; y < bg.h; y++) for (let x = 0; x < bg.w; x++){
    if (!okCell(x, y)) continue;
    const isPocket = y >= bg.bh;
    ctx.fillStyle = isPocket ? 'rgba(120,150,190,0.10)' : 'rgba(255,255,255,0.035)';
    roundRect(bagX + x * (cellPx + gap), bagY + y * (cellPx + gap), cellPx, cellPx, 5); ctx.fill();
    if (isPocket){
      ctx.strokeStyle = 'rgba(120,150,190,0.22)'; ctx.lineWidth = 1;
      roundRect(bagX + x * (cellPx + gap), bagY + y * (cellPx + gap), cellPx, cellPx, 5); ctx.stroke();
    }
  }
  const arr = (typeof bagItems === 'function') ? bagItems() : [];
  for (const it of arr){
    const ix = bagX + (it.x || 0) * (cellPx + gap), iy = bagY + (it.y || 0) * (cellPx + gap);
    const iw = (it.w || 1) * (cellPx + gap) - gap, ih = (it.h || 1) * (cellPx + gap) - gap;
    ctx.fillStyle = 'rgba(120,200,160,0.16)';
    roundRect(ix, iy, iw, ih, 5); ctx.fill();
    ctx.strokeStyle = 'rgba(140,230,190,0.55)'; ctx.lineWidth = 1.2;
    roundRect(ix, iy, iw, ih, 5); ctx.stroke();
    bagDrawItemIcon(it, ix + iw / 2, iy + (ih - 12) / 2, Math.min(iw - 8, ih - 14));
    ctx.fillStyle = 'rgba(220,235,225,0.88)'; ctx.font = '9px "Microsoft YaHei",sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(stashLabelOf(it), ix + iw / 2, iy + ih - 5, iw - 4);
    const _it = it;
    btn(ix, iy, iw, ih, '', function(){ stashPut(_it); }, { invisible: true });
  }

  /* ---- 右：仓库 ---- */
  const _filled = cells.filter(Boolean).length + stashOverflowCells(tier).length;
  const _others = STASH_TIERS.filter(function(t){ return t !== tier && dzStash[t] && (dzStash[t].filter(Boolean).length + stashOverflowCells(t).length); })
                              .map(function(t){ return STASH_TIER_NAME[t] + ' ' + (dzStash[t].filter(Boolean).length + stashOverflowCells(t).length) + ' 件'; });
  if (!_filled && _others.length){
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(255,176,96,0.95)';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.fillText('「' + STASH_TIER_NAME[tier] + '」的仓库是空的（' + _others.join(' / ') + ' 在别的难度里，两边不通用）', bagX, py + ph - 92);
  }

  const stX = px + pw - 26 - (STASH_W * (cellPx + gap) - gap), stY = bagY;
  const overflow = stashOverflowCells(tier);
  if (overflow.length){
    const ovX = bagX + Math.max(220, bg.w * (cellPx + gap) + 18);
    const ovGap = 6, ovCols = 2;
    const ovW = Math.max(90, Math.floor((stX - ovX - 18 - ovGap) / ovCols));
    const ovH = 38;
    ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(255,176,96,0.95)';
    ctx.font = 'bold 12px "Microsoft YaHei",sans-serif';
    ctx.fillText('待整理（旧存档修复）' + overflow.length + ' 件', ovX, stY - 10);
    const showN = Math.min(10, overflow.length);
    for (let i = 0; i < showN; i++){
      const c = overflow[i], col = i % ovCols, row = Math.floor(i / ovCols);
      const ox = ovX + col * (ovW + ovGap), oy = stY + row * (ovH + ovGap);
      ctx.fillStyle = 'rgba(255,150,80,0.10)'; roundRect(ox, oy, ovW, ovH, 5); ctx.fill();
      ctx.strokeStyle = 'rgba(255,176,96,0.55)'; ctx.lineWidth = 1; roundRect(ox, oy, ovW, ovH, 5); ctx.stroke();
      ctx.fillStyle = 'rgba(255,220,185,0.92)'; ctx.font = '10px "Microsoft YaHei",sans-serif'; ctx.textAlign = 'center';
      ctx.fillText(stashLabelOf(c) + ' · ' + c.w + '×' + c.h, ox + ovW / 2, oy + 23);
      const _o = c;
      btn(ox, oy, ovW, ovH, '', function(){
        if (lastShift){ stashDeleteOverflow(_o); return; }
        if (stashCanEquip(_o) && stashUI.mode === 'pre' && !stashEquippedOf(_o.k)) stashEquipOverflow(_o);
        else stashTakeOverflow(_o);
      }, { invisible:true });
    }
    if (overflow.length > showN){
      ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(255,190,130,0.75)'; ctx.font = '11px "Microsoft YaHei",sans-serif';
      ctx.fillText('先取走上面的物资，剩余 ' + (overflow.length - showN) + ' 件随后显示', ovX, stY + 5 * (ovH + ovGap) + 14);
    }
  }
  ctx.textAlign = 'left';
  ctx.fillStyle = sk.accent; ctx.font = 'bold 14px "Microsoft YaHei",sans-serif';
  ctx.fillText('仓库 ' + STASH_W + '×' + STASH_H + ' = ' + STASH_N + ' 格（' + STASH_TIER_NAME[tier] + '）', stX, stY - 10);
  for (let y = 0; y < STASH_H; y++) for (let x = 0; x < STASH_W; x++){
    const cx = stX + x * (cellPx + gap), cy = stY + y * (cellPx + gap);
    ctx.fillStyle = 'rgba(255,255,255,0.03)';
    roundRect(cx, cy, cellPx, cellPx, 5); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.05)'; ctx.lineWidth = 1;
    roundRect(cx, cy, cellPx, cellPx, 5); ctx.stroke();
  }
  for (let i = 0; i < STASH_N; i++){
    const c = cells[i];
    if (!c) continue;
    const cx = stX + (c.x || 0) * (cellPx + gap), cy = stY + (c.y || 0) * (cellPx + gap);
    const cw = (c.w || 1) * (cellPx + gap) - gap, ch = (c.h || 1) * (cellPx + gap) - gap;
    const canEq = stashCanEquip(c) && stashUI.mode === 'pre' && !stashEquippedOf(c.k);
    ctx.fillStyle = canEq ? 'rgba(140,230,190,0.14)' : sk.cellOn;
    roundRect(cx, cy, cw, ch, 5); ctx.fill();
    ctx.strokeStyle = canEq ? 'rgba(140,230,190,0.7)' : sk.line; ctx.lineWidth = 1.2;
    roundRect(cx, cy, cw, ch, 5); ctx.stroke();
    bagDrawItemIcon(c, cx + cw / 2, cy + (ch - 12) / 2, Math.min(cw - 8, ch - 14));
    ctx.fillStyle = canEq ? 'rgba(200,245,220,0.92)' : sk.title;
    ctx.font = '9px "Microsoft YaHei",sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(stashLabelOf(c) + (c.k === 'thermal' ? ' ' + heatPct(thermalPower(c, HEAT_CAP_V2).battery, HEAT_CAP_V2) + '%' : ''),
                 cx + cw / 2, cy + ch - 5, cw - 4);
    const _c = c;
    btn(cx, cy, cw, ch, '', function(){
      /* Shift + 点击 = 删掉这件（仓库里的垃圾总得有个去处） */
      if (lastShift || (typeof keys !== 'undefined' && (keys['ShiftLeft'] || keys['ShiftRight']))){ stashDelete(_c); return; }
      if (stashCanEquip(_c) && stashUI.mode === 'pre' && !stashEquippedOf(_c.k)) stashEquip(_c);
      else stashTake(_c);
    }, { invisible: true });
  }

  /* ---- 底部 ---- */
  const by = py + ph - 50;
  ctx.textAlign = 'left';
  if (stashDirty(tier) || (dzStash[tier] && (dzStash[tier].filter(Boolean).length + stashOverflowCells(tier).length))){
    const _ask = !!stashUI.resetAsk;
    btn(px + 24, by, _ask ? 236 : 150, 38, _ask ? '再点一次：确认清空' : '清空这个仓库', function(){
      /* m35424：确认要绑定「发起时的那一档」，否则点了困难再切到噩梦，第二下会把噩梦一键清掉 */
      if (stashUI.resetAsk && stashUI.resetTier === tier){
        stashUI.resetAsk = false; stashUI.resetTier = null;
        stashResetTier(tier);
        return;
      }
      stashUI.resetAsk = true; stashUI.resetTier = tier;
      stashMsg('再点一次就会清空「' + STASH_TIER_NAME[tier] + '」仓库（不可撤销）');
    }, { dim: true });
  }
  btn(px + pw - 300, by, 120, 38, '完成', function(){ stashClosePanel(false); }, { primary: true });
  if (stashUI.mode === 'settle'){
    btn(px + pw - 170, by, 140, 38, '全部丢进仓库', function(){
      const list = bagItems().slice();
      for (const it of list) stashPut(it);
    });
  }
  ctx.fillStyle = 'rgba(170,186,202,0.55)';
  ctx.font = '12px "Microsoft YaHei",sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Shift + 点击仓库里的东西 = 删除', px + pw - 300, by - 38);
  if (stashUI.msgT > 0){
    /* m34024：原来画在 by-16，正好压在背包口袋那几格上（用户截图贴过来）。
       现在挪到标题区右侧那条空白带，右对齐，绝不压格子。 */
    const _ma = Math.min(1, stashUI.msgT / 0.5);
    ctx.save();
    ctx.globalAlpha = _ma;
    ctx.fillStyle = 'rgba(255,196,128,0.95)';
    ctx.font = 'bold 13px "Microsoft YaHei",sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(stashUI.msg, px + pw - 24, py + 112);
    ctx.restore();
    ctx.textAlign = 'left';
  }

  flushButtons();      /* btn() 只登记，真正画出来要靠这一下 */
  /* 二次确认 */
  if (stashUI.confirm){
    ctx.fillStyle = 'rgba(0,0,0,0.72)';
    ctx.fillRect(0, 0, W2, H2);
    const cw2 = 560, ch2 = 190, cx2 = (W2 - cw2) / 2, cy2 = (H2 - ch2) / 2;
    ctx.fillStyle = 'rgba(20,24,30,0.99)';
    ctx.strokeStyle = '#d88a5a'; ctx.lineWidth = 1.6;
    roundRect(cx2, cy2, cw2, ch2, 12); ctx.fill(); ctx.stroke();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffd9a8';
    ctx.font = 'bold 16px "Microsoft YaHei",sans-serif';
    ctx.fillText('背包里还有 ' + stashBackpackLeft() + ' 件没放进仓库', W2 / 2, cy2 + 52);
    ctx.fillStyle = 'rgba(210,220,230,0.8)';
    ctx.font = '13px "Microsoft YaHei",sans-serif';
    ctx.fillText('关掉之后它们就没了，确认扔掉？', W2 / 2, cy2 + 80);
    btn(W2 / 2 - 190, cy2 + 116, 170, 40, '再想想（回去放）', function(){ stashUI.confirm = false; }, { primary: true });
    btn(W2 / 2 + 20, cy2 + 116, 150, 40, '确认丢掉', function(){ stashUI.confirm = false; stashClosePanel(true); });
    flushButtons();    /* 确认框自己的按钮 */
  }

  ctx.restore();
  /* m35424：本帧画出来的按钮就是仓库这一层的全部可点区域，存一份给 stashClick 用 */
  stashUI.btns = uiButtons.slice();
}

function stashKey(e){
  if (!stashUI.open) return false;
  /* m35424：Esc 先撤掉"待清空/待丢弃"，再按一次才关仓库 */
  if (e.code === 'Escape'){
    if (stashUI.resetAsk){ stashUI.resetAsk = false; stashUI.resetTier = null; stashMsg('已取消清空'); return true; }
    if (stashUI.confirm){ stashUI.confirm = false; return true; }
    stashClosePanel(false); return true;
  }
  if (e.code === 'KeyD' && stashUI.confirm){ stashUI.open = false; stashUI.confirm = false; return true; }
  return true;   /* 面板开着时吃掉所有按键，别让玩家一边整理一边开枪 */
}
/* 鼠标：交给 uiButtons（面板自己有按钮），这里只负责把世界点击挡住 */
function stashClick(mx, my){
  if (!stashUI.open) return false;
  /* m35424：只命中仓库自己这一层的按钮。以前用全局 uiButtons，多层叠着时会点到别层的按钮，
     表现就是"按钮偶发无响应/点错"。 */
  const list = (stashUI.btns && stashUI.btns.length) ? stashUI.btns : uiButtons;
  let b = null;
  for (const it of list){
    if (mx >= it.x && mx <= it.x + it.w && my >= it.y && my <= it.y + it.h){ b = it; break; }
  }
  if (b){ if (typeof uiCall === 'function') uiCall(b.fn); else b.fn(); return true; }
  return true;
}
function stashTick(dt){
  if (stashUI.msgT > 0) stashUI.msgT = Math.max(0, stashUI.msgT - dt);
}
